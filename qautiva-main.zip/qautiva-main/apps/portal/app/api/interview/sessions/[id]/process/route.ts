import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { processSession } from '@/app/_lib/interview/session-processor'
import { getUserTeamIds } from '@/app/_lib/interview/get-user-team-ids'
import { checkBillingEligibility } from '@/app/_lib/billing/check-eligibility'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'
import { waitUntil } from '@vercel/functions'

// maxDuration alto: el procesamiento corre en background vía waitUntil
// y puede tomar hasta 90s en Anthropic. 300s da margen de sobra (Vercel Pro).
export const maxDuration = 300

/**
 * POST /api/interview/sessions/[id]/process
 *
 * Dispara la generación del Brief Estratégico en background y retorna 202 inmediatamente.
 * El cliente pollea GET /sessions/[id] hasta que el estado cambie a COMPLETED o ERROR.
 *
 * Fire-and-forget: usa waitUntil() para que el procesamiento continúe
 * después de enviar la respuesta HTTP. Si falla, processSession actualiza
 * el estado a ERROR o incrementa retryCount, y el cron lo recupera.
 *
 * Idempotente: si la sesión ya está COMPLETED, retorna 200 sin regenerar.
 */
export async function POST(
  _request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  if (
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)
  ) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Verificar ownership
  const teamIds = await getUserTeamIds(user.id)
  if (!teamIds) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const session = await prisma.interviewSession.findFirst({
    where: {
      id: params.id,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: {
      id: true,
      status: true,
      retryCount: true,
      maxRetries: true,
      processingStartedAt: true,
      flowDefinition: true,
      answers: true,
      stageId: true,
      projectId: true,
      teamId: true,
      selectedWebTemplateId: true,
      stage: { select: { stageKey: true } },
      project: { select: { brandKit: true } },
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Fail-closed: si falta teamId es un error de datos. Verificar antes de cualquier guard.
  // InterviewSession.teamId es non-nullable en el schema, pero se verifica defensivamente.
  if (!session.teamId) {
    console.error('[process] session sin teamId — error de datos, bloqueando ejecución', {
      sessionId: params.id,
    })
    return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
  }

  // Guard de permisos: MEMBER solo tiene lectura — ADMIN y OWNER pueden disparar generaciones
  const perm = await checkTeamPermission(user.id, session.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden ejecutar esta operación.' },
      { status: 403 },
    )
  }

  // Idempotente: ya completada
  if (session.status === 'COMPLETED') {
    return NextResponse.json({ ok: true, alreadyCompleted: true })
  }

  // Aceptar PROCESSING (flujo normal) o ERROR (reintento del usuario)
  if (session.status !== 'PROCESSING' && session.status !== 'ERROR') {
    return NextResponse.json(
      { error: `Solo se puede procesar una sesión en estado PROCESSING o ERROR, estado actual: ${session.status}` },
      { status: 409 },
    )
  }

  // Guard de billing: verificar elegibilidad ANTES del lock para no reclamar innecesariamente.
  try {
    const billing = await checkBillingEligibility(session.teamId)
    if (!billing.eligible) {
      return NextResponse.json(
        {
          error: billing.reason ?? 'Tu plan no tiene saldo suficiente para continuar.',
          action: 'Ir a Configuración > Facturación para recargar o actualizar tu plan.',
        },
        { status: 402 },
      )
    }
  } catch (err) {
    console.error('[process] billing check failed — bloqueando ejecución por seguridad', {
      sessionId: params.id,
      teamId: session.teamId,
      err,
    })
    return NextResponse.json(
      { error: 'No se pudo verificar tu cuenta de facturación. Intentá de nuevo en unos segundos. Si el problema persiste, contactá a soporte.' },
      { status: 503 },
    )
  }

  // Límite de reintentos: verificar ANTES del lock para no reclamar el lock innecesariamente
  if (session.retryCount >= session.maxRetries) {
    return NextResponse.json(
      { error: 'Máximo de reintentos alcanzado' },
      { status: 429 },
    )
  }

  // Atomic lock / reset:
  // - Para ERROR: resetear a PROCESSING y tomar el lock en una operación atómica.
  // - Para PROCESSING: tomar el lock solo si no hay un intento reciente (<2min).
  // En ambos casos, claimed.count === 0 significa que otro actor ganó la carrera.
  const PROCESSING_LOCK_MS = 2 * 60 * 1000 // 2 minutos
  const claimed = session.status === 'ERROR'
    ? await prisma.interviewSession.updateMany({
        where: { id: params.id, status: 'ERROR' },
        data: { status: 'PROCESSING', lastError: null, processingStartedAt: new Date() },
      })
    : await prisma.interviewSession.updateMany({
        where: {
          id: params.id,
          status: 'PROCESSING',
          OR: [
            { processingStartedAt: null },
            { processingStartedAt: { lt: new Date(Date.now() - PROCESSING_LOCK_MS) } },
          ],
        },
        data: { processingStartedAt: new Date() },
      })
  if (claimed.count === 0) {
    return NextResponse.json({ ok: true, alreadyProcessing: true }, { status: 202 })
  }

  const stageKey = session.stage?.stageKey ?? 'UNKNOWN'
  console.info('[process] starting generation (background)', {
    sessionId: params.id,
    stageKey,
    answersCount: Object.keys((session.answers as Record<string, unknown>) ?? {}).length,
    flowLength: Array.isArray(session.flowDefinition) ? session.flowDefinition.length : 0,
  })

  // Fire-and-forget: procesar en background, responder inmediatamente.
  // processSession maneja sus propios errores internamente (actualiza status, retryCount, lastError).
  // Si Vercel mata la función, el cron lo recupera en el próximo ciclo.
  waitUntil(
    processSession(
      { ...session, stageKey: session.stage?.stageKey ?? '' },
      'interview/sessions/process',
    ).catch(async (err) => {
      const errorMsg = err instanceof Error ? err.message : String(err)
      console.error('[process] unhandled error in background processing', {
        sessionId: params.id,
        error: errorMsg,
      })
      // Best-effort: transicionar a ERROR para no dejar la sesión pegada en PROCESSING
      try {
        await prisma.interviewSession.update({
          where: { id: params.id, status: 'PROCESSING' },
          data: { status: 'ERROR', lastError: `Unhandled: ${errorMsg}`.slice(0, 500) },
        })
      } catch (updateErr) {
        // P2025: otro actor ya cambió el estado — condición de carrera esperada, no es un error
        console.warn('[process] best-effort ERROR update skipped (otro actor ganó la carrera)', {
          sessionId: params.id,
          updateErr,
        })
      }
    }),
  )

  return NextResponse.json({ ok: true, processing: true }, { status: 202 })
}
