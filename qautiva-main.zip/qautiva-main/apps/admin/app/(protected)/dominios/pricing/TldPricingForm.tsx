'use client'

import { useState } from 'react'

// ── Types ─────────────────────────────────────────────────────────────────────

type TldOption = {
  id: string
  tld: string
  marginType: 'PERCENTAGE' | 'FIXED_ARS'
  marginValue: string
  isActive: boolean
}

type FormState = {
  tld: string
  marginType: 'PERCENTAGE' | 'FIXED_ARS'
  marginValue: string
  isActive: boolean
}

type Status = { type: 'idle' } | { type: 'loading' } | { type: 'success' } | { type: 'error'; message: string }

// ── Component ─────────────────────────────────────────────────────────────────

export function TldPricingForm({ tlds }: { tlds: TldOption[] }) {
  const [selectedId, setSelectedId] = useState<string>('')
  const [form, setForm] = useState<FormState>({
    tld: '',
    marginType: 'PERCENTAGE',
    marginValue: '',
    isActive: true,
  })
  const [status, setStatus] = useState<Status>({ type: 'idle' })

  function handleTldChange(id: string) {
    setSelectedId(id)
    setStatus({ type: 'idle' })
    const found = tlds.find((t) => t.id === id)
    if (!found) return
    setForm({
      tld: found.tld,
      marginType: found.marginType,
      marginValue: found.marginValue,
      isActive: found.isActive,
    })
  }

  function handleFieldChange(field: keyof FormState, value: string | boolean) {
    setForm((prev) => ({ ...prev, [field]: value }))
    setStatus({ type: 'idle' })
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!selectedId) return

    const marginValue = parseFloat(form.marginValue)
    if (isNaN(marginValue) || marginValue < 0) {
      setStatus({ type: 'error', message: 'El margen debe ser un número mayor o igual a 0.' })
      return
    }

    setStatus({ type: 'loading' })

    try {
      const res = await fetch('/api/domains/pricing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedId,
          marginType: form.marginType,
          marginValue,
          isActive: form.isActive,
        }),
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        setStatus({ type: 'error', message: data.error ?? 'Error al guardar.' })
        return
      }

      setStatus({ type: 'success' })
    } catch {
      setStatus({ type: 'error', message: 'Error de red. Intentá de nuevo.' })
    }
  }

  const isLoading = status.type === 'loading'

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-md">
      {/* TLD selector */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="tld-select" className="text-[#94A3B8] text-xs font-medium">
          TLD
        </label>
        <select
          id="tld-select"
          value={selectedId}
          onChange={(e) => handleTldChange(e.target.value)}
          disabled={isLoading}
          className="bg-[#0B0F1A] border border-[#1E293B] text-[#F8FAFC] text-sm rounded-lg px-3 py-2
            focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        >
          <option value="">Seleccioná un TLD…</option>
          {tlds.map((t) => (
            <option key={t.id} value={t.id}>
              .{t.tld}
            </option>
          ))}
        </select>
      </div>

      {selectedId && (
        <>
          {/* Margin type */}
          <div className="flex flex-col gap-1.5">
            <label htmlFor="margin-type" className="text-[#94A3B8] text-xs font-medium">
              Tipo de margen
            </label>
            <select
              id="margin-type"
              value={form.marginType}
              onChange={(e) => handleFieldChange('marginType', e.target.value as 'PERCENTAGE' | 'FIXED_ARS')}
              disabled={isLoading}
              className="bg-[#0B0F1A] border border-[#1E293B] text-[#F8FAFC] text-sm rounded-lg px-3 py-2
                focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
            >
              <option value="PERCENTAGE">Porcentaje</option>
              <option value="FIXED_ARS">Fijo ARS</option>
            </select>
          </div>

          {/* Margin value */}
          <div className="flex flex-col gap-1.5">
            <label htmlFor="margin-value" className="text-[#94A3B8] text-xs font-medium">
              Valor del margen {form.marginType === 'PERCENTAGE' ? '(%)' : '(ARS)'}
            </label>
            <input
              id="margin-value"
              type="number"
              min="0"
              step="0.01"
              value={form.marginValue}
              onChange={(e) => handleFieldChange('marginValue', e.target.value)}
              disabled={isLoading}
              className="bg-[#0B0F1A] border border-[#1E293B] text-[#F8FAFC] text-sm rounded-lg px-3 py-2
                focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
            />
          </div>

          {/* isActive */}
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) => handleFieldChange('isActive', e.target.checked)}
              disabled={isLoading}
              className="w-4 h-4 accent-[#8B5CF6] disabled:opacity-50"
            />
            <span className="text-[#94A3B8] text-sm">TLD activo</span>
          </label>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="self-start px-4 py-2 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium
              hover:bg-[#7C3AED] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Guardando…' : 'Guardar cambios'}
          </button>
        </>
      )}

      {/* Feedback */}
      {status.type === 'success' && (
        <p className="text-sm text-[#10B981]">Cambios guardados correctamente.</p>
      )}
      {status.type === 'error' && (
        <p className="text-sm text-[#F87171]">{status.message}</p>
      )}
    </form>
  )
}
