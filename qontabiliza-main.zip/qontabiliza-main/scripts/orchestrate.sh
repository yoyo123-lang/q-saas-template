#!/usr/bin/env bash
set -euo pipefail

# ── Configuración del proyecto ──
PROJECT_SLUG="qontabiliza"
ORCHESTRATOR_PATH="${ORCHESTRATOR_PATH:-}"

# ── Auto-detectar orquestador ──
# Busca en rutas comunes si no está seteada la variable
if [ -z "$ORCHESTRATOR_PATH" ]; then
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

  # Buscar orchestrator en ubicaciones conocidas
  for candidate in \
    "$REPO_DIR/orchestrator" \
    "$HOME/q-saas-template/scripts/orchestrator" \
    "$HOME/q-saas-template/orchestrator" \
    "/c/Users/$USER/q-saas-template/scripts/orchestrator" \
    ; do
    if [ -f "${candidate}/q-orchestrator.sh" ]; then
      ORCHESTRATOR_PATH="$candidate"
      break
    fi
  done
fi

# ── Verificar orquestador ──
if [ -z "$ORCHESTRATOR_PATH" ] || [ ! -f "${ORCHESTRATOR_PATH}/q-orchestrator.sh" ]; then
  echo "[ERROR] Orquestador no encontrado."
  echo ""
  echo "Opciones:"
  echo "  1. Seteá ORCHESTRATOR_PATH: export ORCHESTRATOR_PATH=/ruta/al/orchestrator"
  echo "  2. Cloná q-saas-template en ~/q-saas-template"
  echo "  3. Copiá la carpeta orchestrator/ a la raíz de este proyecto"
  echo ""
  echo "El orquestador se busca en:"
  echo "  - ./orchestrator/"
  echo "  - ~/q-saas-template/scripts/orchestrator/"
  echo "  - ~/q-saas-template/orchestrator/"
  exit 1
fi

# ── Registrar proyecto automáticamente ──
source "${ORCHESTRATOR_PATH}/lib/projects.sh"
source "${ORCHESTRATOR_PATH}/lib/ui.sh"
ensure_config
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
add_project "$PROJECT_SLUG" "$PROJECT_DIR" "yoyo123-lang/qontabiliza" "main" 2>/dev/null || true

# ── Ejecutar ──
exec bash "${ORCHESTRATOR_PATH}/q-orchestrator.sh" --project "$PROJECT_SLUG" "$@"
