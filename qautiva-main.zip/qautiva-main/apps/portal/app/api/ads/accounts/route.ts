/**
 * GET /api/ads/accounts?projectId=xxx
 *
 * Lista las cuentas de ads conectadas para un proyecto.
 * Solo devuelve campos seguros — nunca tokens.
 */
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'

const SAFE_SELECT = {
  id: true,
  platform: true,
  externalId: true,
  name: true,
  status: true,
  tokenExpiresAt: true,
  metadata: true,
  revokedAt: true,
  createdAt: true,
  // accessToken y refreshToken NUNCA se devuelven al cliente
} as const

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const projectId = searchParams.get('projectId')

  if (!projectId) {
    return NextResponse.json({ error: 'Falta projectId' }, { status: 400 })
  }

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  // Verificar ownership
  const profile = await prisma.userProfile.findFirst({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile) {
    return NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 })
  }

  const teamIds = profile.teamMemberships.map(m => m.teamId)
  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true },
  })

  if (!project) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  const raw = await prisma.adAccount.findMany({
    where: { projectId: project.id },
    select: SAFE_SELECT,
    orderBy: { createdAt: 'asc' },
  })

  // Defense-in-depth: strip sensitive fields even if select is bypassed
  const accounts = raw.map(({ ...account }) => {
    const a = account as Record<string, unknown>
    delete a['accessToken']
    delete a['refreshToken']
    return a
  })

  return NextResponse.json({ accounts })
}

/**
 * DELETE /api/ads/accounts?accountId=xxx
 *
 * Desconecta una cuenta de ads (marca como DISCONNECTED).
 */
export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const accountId = searchParams.get('accountId')

  if (!accountId) {
    return NextResponse.json({ error: 'Falta accountId' }, { status: 400 })
  }

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  // Verificar que la cuenta pertenece al usuario
  const profile = await prisma.userProfile.findFirst({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile) {
    return NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 })
  }

  const teamIds = profile.teamMemberships.map(m => m.teamId)

  const account = await prisma.adAccount.findFirst({
    where: { id: accountId, teamId: { in: teamIds } },
    select: { id: true },
  })

  if (!account) {
    return NextResponse.json({ error: 'Cuenta no encontrada' }, { status: 404 })
  }

  await prisma.adAccount.update({
    where: { id: account.id },
    data: { status: 'DISCONNECTED', revokedAt: new Date() },
  })

  return NextResponse.json({ ok: true })
}
