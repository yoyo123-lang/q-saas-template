'use client'

import { useState } from 'react'
import type { AdCreatives, AdCopyVariant } from '@/app/_lib/interview/types'
import type { DeliverableStatus } from '@qautiva/db'

type Tab = 'google-search' | 'meta-feed' | 'meta-story'

const TAB_LABELS: Record<Tab, string> = {
  'google-search': 'Google Search',
  'meta-feed': 'Meta Feed',
  'meta-story': 'Meta Story',
}

const STATUS_BADGE: Record<string, { label: string; className: string }> = {
  READY: { label: 'Listo para revisar', className: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' },
  SENT_TO_CLIENT: { label: 'Enviado', className: 'bg-violet-500/10 text-violet-400 border border-violet-500/20' },
  CLIENT_APPROVED: { label: 'Aprobado', className: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' },
  REVISION_REQUESTED: { label: 'Revisión solicitada', className: 'bg-amber-500/10 text-amber-400 border border-amber-500/20' },
  GENERATING: { label: 'Generando…', className: 'bg-blue-500/10 text-blue-400 border border-blue-500/20' },
  DRAFT: { label: 'Borrador', className: 'bg-slate-500/10 text-slate-400 border border-slate-500/20' },
}

function CopyVariantCard({ variant, index }: { variant: AdCopyVariant; index: number }) {
  return (
    <div className="p-4 rounded-lg bg-[#0B0F1A] border border-[#1E293B]">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-[#64748B]">Variante {index + 1}</span>
        <span className="text-[10px] text-[#475569] italic">{variant.angle}</span>
      </div>
      <div className="space-y-2">
        <div>
          <span className="text-[10px] text-[#64748B] uppercase tracking-wider">Título</span>
          <p className="text-sm font-medium text-white">{variant.headline}</p>
        </div>
        <div>
          <span className="text-[10px] text-[#64748B] uppercase tracking-wider">Descripción</span>
          <p className="text-sm text-[#94A3B8]">{variant.description}</p>
        </div>
        <div className="pt-1">
          <span className="px-2.5 py-1 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 text-xs text-[#A78BFA] font-medium">
            {variant.callToAction}
          </span>
        </div>
      </div>
    </div>
  )
}

type Props = {
  creatives: AdCreatives
  status: DeliverableStatus
  version: number
}

export function AdCreativesSection({ creatives, status, version }: Props) {
  const availableTabs: Tab[] = [
    ...(creatives.googleAds?.search?.length ? ['google-search' as Tab] : []),
    ...(creatives.metaAds?.feed?.length ? ['meta-feed' as Tab] : []),
    ...(creatives.metaAds?.story?.length ? ['meta-story' as Tab] : []),
  ]

  const [activeTab, setActiveTab] = useState<Tab>(availableTabs[0] ?? 'google-search')

  const badge = STATUS_BADGE[status] ?? { label: status, className: 'bg-slate-500/10 text-slate-400 border border-slate-500/20' }

  const currentVariants: AdCopyVariant[] = (() => {
    if (activeTab === 'google-search') return creatives.googleAds?.search ?? []
    if (activeTab === 'meta-feed') return creatives.metaAds?.feed ?? []
    if (activeTab === 'meta-story') return creatives.metaAds?.story ?? []
    return []
  })()

  if (availableTabs.length === 0) {
    return (
      <section>
        <h2 className="text-lg font-semibold text-white mb-4">Piezas publicitarias</h2>
        <p className="text-[#94A3B8] text-sm">No hay piezas publicitarias disponibles todavía.</p>
      </section>
    )
  }

  return (
    <section>
      {/* Encabezado */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-white">Piezas publicitarias</h2>
        <div className="flex items-center gap-2">
          <span className="text-[#64748B] text-xs">v{version}</span>
          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
            {badge.label}
          </span>
        </div>
      </div>

      {/* Disclaimer */}
      {creatives.disclaimer && (
        <p className="text-xs text-[#64748B] italic mb-6 p-3 rounded-lg border border-[#1E293B] bg-[#0F172A]">
          {creatives.disclaimer}
        </p>
      )}

      {/* Guía de tono */}
      {creatives.guiaDeTono && (
        <div className="mb-6 p-4 rounded-lg bg-[#0F172A] border border-[#1E293B]">
          <p className="text-xs font-semibold text-[#64748B] uppercase tracking-wider mb-2">Tono de voz</p>
          <p className="text-sm text-[#94A3B8] mb-3">{creatives.guiaDeTono.tono}</p>
          {creatives.guiaDeTono.palabrasClave.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {creatives.guiaDeTono.palabrasClave.map((kw, i) => (
                <span key={i} className="px-2 py-0.5 rounded-full bg-[#1E293B] text-[10px] text-[#64748B]">
                  {kw}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tabs de plataforma */}
      <div className="flex gap-1 mb-4 flex-wrap">
        {availableTabs.map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              activeTab === tab
                ? 'bg-white text-black'
                : 'bg-white/10 text-[#94A3B8] hover:bg-white/20'
            }`}
          >
            {TAB_LABELS[tab]}
          </button>
        ))}
      </div>

      {/* Variantes */}
      {currentVariants.length > 0 ? (
        <div className="space-y-3">
          {currentVariants.map((variant, i) => (
            <CopyVariantCard key={i} variant={variant} index={i} />
          ))}
        </div>
      ) : (
        <p className="text-[#94A3B8] text-sm p-4">
          No hay variantes para esta plataforma.
        </p>
      )}
    </section>
  )
}
