import { NextRequest, NextResponse } from 'next/server'
import { prisma, Prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { ALL_INDUSTRIES, TEMPLATE_STYLE_IDS } from '@qautiva/shared'

const VALID_STATUSES = ['QUEUED', 'GENERATING', 'DONE', 'ERROR'] as const
type QueueStatus = (typeof VALID_STATUSES)[number]

/**
 * POST /api/stitch/queue
 *
 * Crea un job en la cola sin ejecutarlo.
 * Body: { industry, styleId, sections?, prompt? }
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: { industry: string; styleId: string; sections?: string[]; prompt?: string }
  try {
    body = (await req.json()) as { industry: string; styleId: string; sections?: string[]; prompt?: string }
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { industry, styleId, sections, prompt } = body

  if (!industry || !industry.trim()) {
    return NextResponse.json({ error: 'industry es requerido' }, { status: 400 })
  }
  if (!ALL_INDUSTRIES.includes(industry as (typeof ALL_INDUSTRIES)[number])) {
    return NextResponse.json({ error: 'industry no válida' }, { status: 400 })
  }
  if (!styleId || !TEMPLATE_STYLE_IDS.includes(styleId as (typeof TEMPLATE_STYLE_IDS)[number])) {
    return NextResponse.json({ error: 'styleId no válido' }, { status: 400 })
  }

  // Verificar que no exista ya un job QUEUED o GENERATING para industria+estilo
  const existingJob = await prisma.webTemplate.findFirst({
    where: {
      compatibleIndustries: { array_contains: [industry] },
      styleId,
      queueStatus: { in: ['QUEUED', 'GENERATING'] },
    },
    select: { id: true, queueStatus: true },
  })

  if (existingJob) {
    return NextResponse.json(
      { error: 'Ya existe un job pendiente para esta industria y estilo', jobId: existingJob.id },
      { status: 409 },
    )
  }

  const sectionsData: Record<string, boolean> = sections
    ? Object.fromEntries(sections.map((s) => [s, true]))
    : {}

  const job = await prisma.webTemplate.create({
    data: {
      name: `__queue__${crypto.randomUUID()}`,
      compatibleIndustries: [industry],
      sections: sectionsData,
      queueStatus: 'QUEUED',
      queuedAt: new Date(),
      styleId,
      ...(prompt?.trim() ? { generationPrompt: prompt.trim() } : {}),
    },
    select: {
      id: true,
      queueStatus: true,
      queuedAt: true,
      styleId: true,
      compatibleIndustries: true,
    },
  })

  return NextResponse.json({ job }, { status: 201 })
}

/**
 * GET /api/stitch/queue
 *
 * Lista jobs de la cola con paginación y filtros.
 * Query params: status, industry, styleId, page (default 1), limit (default 50)
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const statusParam = searchParams.get('status')
  const industry = searchParams.get('industry')
  const styleId = searchParams.get('styleId')
  const page = Math.max(1, parseInt(searchParams.get('page') ?? '1', 10))
  const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') ?? '50', 10)))
  const skip = (page - 1) * limit

  const statusFilter = statusParam && (VALID_STATUSES as ReadonlyArray<string>).includes(statusParam)
    ? (statusParam as QueueStatus)
    : undefined

  const where: Prisma.WebTemplateWhereInput = {
    NOT: { queueStatus: null },
    ...(statusFilter ? { queueStatus: statusFilter } : {}),
    ...(industry ? { compatibleIndustries: { array_contains: [industry] } } : {}),
    ...(styleId ? { styleId } : {}),
  }

  const [jobs, total] = await Promise.all([
    prisma.webTemplate.findMany({
      where,
      select: {
        id: true,
        queueStatus: true,
        queuedAt: true,
        styleId: true,
        compatibleIndustries: true,
        generatingAt: true,
        status: true,
        queueError: true,
        stitchAccount: {
          select: { id: true, label: true },
        },
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { queuedAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.webTemplate.count({ where }),
  ])

  return NextResponse.json({
    jobs,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  })
}
