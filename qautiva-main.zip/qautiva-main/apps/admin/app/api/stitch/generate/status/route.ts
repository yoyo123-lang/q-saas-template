import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

const LOCK_TIMEOUT_MS = 5 * 60 * 1000 // 5 minutos — mismo que en generate/route.ts

/**
 * GET /api/stitch/generate/status?templateId=X
 *
 * Polling endpoint para seguir el progreso de una generación asíncrona con Stitch.
 *
 * Estados posibles:
 * - generating: generatingAt tiene un timestamp reciente
 * - done: generatingAt es null y htmlBase está presente
 * - error: generatingAt es null y htmlBase está vacío, o lock expirado (>5 min)
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const templateId = searchParams.get('templateId')

  if (!templateId || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(templateId)) {
    return NextResponse.json({ error: 'templateId inválido' }, { status: 400 })
  }

  const template = await prisma.webTemplate.findUnique({
    where: { id: templateId },
    select: {
      id: true,
      generatingAt: true,
      htmlBase: true,
      css: true,
      thumbnail: true,
      stitchProjectId: true,
      stitchScreenId: true,
      sections: true,
      variables: true,
      queueError: true,
    },
  })

  if (!template) {
    return NextResponse.json({ error: 'Template no encontrado' }, { status: 404 })
  }

  // Done: generatingAt limpiado y htmlBase presente
  if (template.generatingAt === null && template.htmlBase) {
    return NextResponse.json({
      status: 'done',
      templateId: template.id,
      processedHtml: template.htmlBase,
      thumbnailUrl: template.thumbnail,
      stitchProjectId: template.stitchProjectId,
      stitchScreenId: template.stitchScreenId,
      detectedSections: template.sections,
      extractedVariables: template.variables,
    })
  }

  // Error: lock limpiado pero sin htmlBase, o lock expirado
  if (template.generatingAt === null && !template.htmlBase) {
    return NextResponse.json({ status: 'error', error: template.queueError ?? 'Error al generar el template' })
  }

  const lockAge = Date.now() - template.generatingAt!.getTime()
  if (lockAge >= LOCK_TIMEOUT_MS) {
    return NextResponse.json({ status: 'error', error: 'Timeout: la generación tardó demasiado' })
  }

  // En progreso
  return NextResponse.json({ status: 'generating' })
}
