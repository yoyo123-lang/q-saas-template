/**
 * Genera un slug único a partir del nombre del proyecto.
 * Normaliza el texto, elimina caracteres especiales y agrega un sufijo temporal
 * para garantizar unicidad sin necesidad de consultar la base de datos.
 */
export function buildSlug(name: string): string {
  const base = name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 50)

  return `${base}-${Date.now().toString(36)}`
}
