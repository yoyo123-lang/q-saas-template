-- ============================================================
-- 006 — Favorites
-- Activos guardados por el comprador. 1 por (user, listing).
-- Depende de: 001 (profiles), 003 (listings)
-- Rollback: 006_favorites_rollback.sql
-- ============================================================

CREATE TABLE public.favorites (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID        NOT NULL REFERENCES public.profiles(id)  ON DELETE CASCADE,
  listing_id  UUID        NOT NULL REFERENCES public.listings(id)  ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  UNIQUE (user_id, listing_id)
);

COMMENT ON TABLE public.favorites IS 'Activos guardados como favoritos. Privados al usuario.';
