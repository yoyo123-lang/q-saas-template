'use client'

/**
 * Pantalla de selección de template web para la etapa WEBSITE.
 * Se muestra antes de iniciar la entrevista cuando el cliente aún no eligió un diseño.
 *
 * Flujo:
 * 1. Obtiene/crea la InterviewSession (POST /api/interview/sessions)
 * 2. Carga los templates activos filtrados por industria (GET /api/templates)
 * 3. El usuario selecciona un template
 * 4. Se guarda la selección (PATCH /api/interview/sessions/[id]/template)
 * 5. Se recarga la página: el servidor detecta la selección y renderiza InterviewClient
 */

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { STAGE_LABELS } from '../_types'

// Labels en español para las keys de secciones del template
const SECTION_LABELS: Record<string, string> = {
  hero: 'Hero / Inicio',
  services: 'Servicios / Menú',
  about: 'Sobre nosotros',
  contact: 'Contacto / WhatsApp',
  gallery: 'Galería',
  testimonials: 'Testimonios',
  map: 'Ubicación / Mapa',
  pricing: 'Precios',
}

type TemplateItem = {
  id: string
  name: string
  description: string | null
  thumbnail: string | null
  sections: Record<string, boolean>
  compatibleIndustries: string[]
}

type Props = {
  projectId: string
  stageId: string
  stageNumber: number
  industry: string
}

/**
 * Determina si un template es compatible con la industria del proyecto.
 * Matching flexible: case-insensitive y substring (ej: "Mecánica" matchea "Taller Mecánico").
 */
function isCompatibleWithIndustry(template: TemplateItem, industry: string): boolean {
  if (!industry) return false
  const needle = industry.toLowerCase()
  return template.compatibleIndustries.some((ci) => {
    const hay = ci.toLowerCase()
    return hay.includes(needle) || needle.includes(hay)
  })
}

export function TemplateSelectionClient({ projectId, stageId, stageNumber, industry }: Props) {
  const router = useRouter()

  const [templates, setTemplates] = useState<TemplateItem[]>([])
  const [recommendedId, setRecommendedId] = useState<string | null>(null)
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [loadingTemplates, setLoadingTemplates] = useState(true)
  const [loadingSession, setLoadingSession] = useState(true)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Banderas para evitar doble fetch en React Strict Mode
  const sessionFetched = useRef(false)
  const templatesFetched = useRef(false)
  // Lock inmediato contra doble-submit (antes del re-render que actualiza `saving`)
  const savingLockRef = useRef(false)

  // Crear/retomar la sesión de entrevista
  useEffect(() => {
    if (sessionFetched.current) return
    sessionFetched.current = true

    fetch('/api/interview/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stageId, projectId }),
    })
      .then(async (r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json() as Promise<{ ok?: boolean; session?: { id: string } }>
      })
      .then((data) => {
        if (data.ok && data.session) {
          setSessionId(data.session.id)
        } else {
          setError('No se pudo iniciar la sesión. Recargá la página.')
        }
      })
      .catch(() => {
        setError('No se pudo iniciar la sesión. Verificá tu conexión y recargá la página.')
      })
      .finally(() => setLoadingSession(false))
  }, [stageId, projectId])

  // Cargar catálogo de templates
  useEffect(() => {
    if (templatesFetched.current) return
    templatesFetched.current = true

    const url = `/api/templates${industry ? `?industry=${encodeURIComponent(industry)}` : ''}`
    fetch(url)
      .then(async (r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json() as Promise<{
          ok?: boolean
          templates?: TemplateItem[]
          recommendedId?: string | null
        }>
      })
      .then((data) => {
        if (data.ok && data.templates) {
          setTemplates(data.templates)
          const recId = data.recommendedId ?? null
          setRecommendedId(recId)
          // Pre-seleccionar el recomendado solo si está en la lista activa
          if (recId && data.templates.some((t) => t.id === recId)) {
            setSelectedId(recId)
          }
        }
      })
      .catch(() => setError('No se pudieron cargar los diseños. Recargá la página.'))
      .finally(() => setLoadingTemplates(false))
  }, [industry])

  async function handleConfirm() {
    if (!selectedId) return
    if (!sessionId) {
      setError('Error al obtener la sesión. Recargá la página.')
      return
    }

    if (savingLockRef.current) return
    savingLockRef.current = true

    setSaving(true)
    setError(null)

    try {
      const res = await fetch(`/api/interview/sessions/${sessionId}/template`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ templateId: selectedId }),
      })

      if (!res.ok) {
        const data = (await res.json()) as { error?: string }
        setError(data.error ?? 'Error al guardar el diseño. Intentá de nuevo.')
        setSaving(false)
        savingLockRef.current = false
        return
      }

      // El refresh renderizará InterviewClient (el servidor verá selectedWebTemplateId)
      router.refresh()
      // No reseteamos savingLockRef: el componente se va a re-renderizar con InterviewClient
    } catch {
      setError('Error de red. Verificá tu conexión e intentá de nuevo.')
      setSaving(false)
      savingLockRef.current = false
    }
  }

  const isLoading = loadingTemplates || loadingSession
  const selectedTemplate = templates.find((t) => t.id === selectedId)

  // Separar templates en compatibles con la industria y el resto
  const matched = templates.filter((t) => isCompatibleWithIndustry(t, industry))
  const others = templates.filter((t) => !isCompatibleWithIndustry(t, industry))

  // Si no matchea ninguno por industria, mostrar todos juntos sin secciones
  const hasSections = matched.length > 0 && others.length > 0

  function renderTemplateCard(tpl: TemplateItem) {
    const isSelected = selectedId === tpl.id
    const isRecommended = recommendedId === tpl.id
    const activeSections = Object.entries(tpl.sections as Record<string, boolean>)
      .filter(([, v]) => v)
      .map(([k]) => k)

    return (
      <button
        key={tpl.id}
        type="button"
        role="radio"
        aria-checked={isSelected}
        onClick={() => setSelectedId(tpl.id)}
        className={`text-left bg-[#0F172A] border rounded-xl overflow-hidden transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] ${
          isSelected
            ? 'border-[#8B5CF6] shadow-[0_0_0_1px_#8B5CF6]'
            : 'border-[#1E293B] hover:border-[#334155]'
        }`}
      >
        {/* Thumbnail / Preview */}
        <div className="relative h-40 bg-[#1E293B] overflow-hidden">
          {tpl.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={tpl.thumbnail}
              alt={`Vista previa de ${tpl.name}`}
              loading="lazy"
              className="w-full h-full object-cover"
            />
          ) : (
            <iframe
              src={`/api/templates/${tpl.id}/preview`}
              title={`Vista previa de ${tpl.name}`}
              loading="lazy"
              sandbox="allow-scripts"
              aria-hidden="true"
              tabIndex={-1}
              style={{
                width: '500%',
                height: '500%',
                transform: 'scale(0.2)',
                transformOrigin: 'top left',
                pointerEvents: 'none',
                border: 'none',
              }}
            />
          )}
          {/* Botón ver en nueva pestaña */}
          <a
            href={`/api/templates/${tpl.id}/preview`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 hover:bg-black/80 text-white text-xs rounded flex items-center gap-1 transition-colors"
            title="Abrir en nueva pestaña"
            aria-label={`Abrir preview de ${tpl.name} en nueva pestaña`}
          >
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <polyline points="15 3 21 3 21 9" />
              <line x1="10" y1="14" x2="21" y2="3" />
            </svg>
            Ver
          </a>
          {isRecommended && (
            <div className="absolute top-2 right-2 px-2 py-0.5 bg-[#8B5CF6] text-white text-xs font-semibold rounded-full">
              Recomendado
            </div>
          )}
          {isSelected && (
            <div className="absolute top-2 left-2 w-6 h-6 bg-[#8B5CF6] rounded-full flex items-center justify-center">
              <svg
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="white"
                strokeWidth="3"
                aria-hidden="true"
              >
                <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-4">
          <p className="text-white font-semibold text-sm mb-1">{tpl.name}</p>
          {tpl.description && (
            <p className="text-[#64748B] text-xs mb-3 line-clamp-2">{tpl.description}</p>
          )}
          {/* Secciones activas con labels en español */}
          {activeSections.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {activeSections.slice(0, 3).map((key) => (
                <span
                  key={key}
                  className="px-1.5 py-0.5 bg-[#1E293B] text-[#94A3B8] text-xs rounded"
                >
                  {SECTION_LABELS[key] ?? key}
                </span>
              ))}
              {activeSections.length > 3 && (
                <span className="text-[#475569] text-xs px-1.5 py-0.5">
                  +{activeSections.length - 3}
                </span>
              )}
            </div>
          )}
        </div>
      </button>
    )
  }

  return (
    <div className="p-8 max-w-4xl">
      {/* Breadcrumb / navegación */}
      <Link
        href={`/proyectos/${projectId}/etapas`}
        className="inline-flex items-center gap-1 text-sm text-[#64748B] hover:text-[#94A3B8] mb-6 transition-colors"
      >
        ← Volver a etapas
      </Link>

      {/* Header */}
      <div className="mb-8">
        <p className="text-[#94A3B8] text-sm font-medium mb-1">
          Etapa {stageNumber} · {STAGE_LABELS[stageNumber] ?? 'Sitio Web'}
        </p>
        <h1 className="text-2xl font-bold text-white mb-2">Elegí el diseño de tu sitio</h1>
        <p className="text-[#94A3B8] text-base">
          Seleccioná el estilo visual que mejor representa tu negocio.
          Podés personalizarlo más adelante.
        </p>
      </div>

      {/* Error global */}
      {error && (
        <div className="mb-6 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">
          {error}
        </div>
      )}

      {/* Loading skeleton */}
      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="bg-[#0F172A] border border-[#1E293B] rounded-xl overflow-hidden animate-pulse"
            >
              <div className="h-40 bg-[#1E293B]" />
              <div className="p-4 space-y-2">
                <div className="h-4 bg-[#1E293B] rounded w-3/4" />
                <div className="h-3 bg-[#1E293B] rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Estado vacío — solo si no hay error */}
      {!isLoading && !error && templates.length === 0 && (
        <div className="border border-[#1E293B] rounded-xl p-12 text-center">
          <p className="text-[#64748B] text-sm">
            No hay diseños disponibles por el momento. Contactá a tu equipo de Qautiva.
          </p>
        </div>
      )}

      {/* Templates separados por relevancia */}
      {!isLoading && templates.length > 0 && (
        <div role="radiogroup" aria-label="Diseños disponibles">
          {/* Sección: Diseños para tu negocio */}
          {hasSections && matched.length > 0 && (
            <div className="mb-8">
              <h2 className="text-white font-semibold text-base mb-3">
                Diseños para tu negocio
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {matched.map(renderTemplateCard)}
              </div>
            </div>
          )}

          {/* Sección: Otros diseños / Todos (si no hay secciones) */}
          {hasSections && others.length > 0 && (
            <div className="mb-8">
              <h2 className="text-[#94A3B8] font-medium text-sm mb-3">
                Otros diseños
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {others.map(renderTemplateCard)}
              </div>
            </div>
          )}

          {/* Si no hay secciones (todos matched o ninguno matched), mostrar todo junto */}
          {!hasSections && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {templates.map(renderTemplateCard)}
            </div>
          )}

          {/* CTA */}
          <button
            type="button"
            onClick={handleConfirm}
            disabled={!selectedId || saving}
            className="w-full sm:w-auto px-8 py-3 bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors duration-200 flex items-center justify-center gap-2"
          >
            {saving ? (
              <>
                <svg
                  className="animate-spin"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  aria-hidden="true"
                >
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
                Guardando...
              </>
            ) : (
              <>
                {selectedTemplate
                  ? `Continuar con ${selectedTemplate.name}`
                  : 'Seleccioná un diseño para continuar'}
                {selectedId && (
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    aria-hidden="true"
                  >
                    <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </>
            )}
          </button>
        </div>
      )}
    </div>
  )
}
