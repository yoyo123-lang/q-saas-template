'use client'

import type { RefObject } from 'react'
import { useInView } from '@/lib/use-in-view'

const STEPS = [
  { number: 1, title: 'Nos contás', description: 'Hablás con nuestra IA sobre tu negocio.' },
  { number: 2, title: 'Investigamos', description: 'Analizamos mercado, competencia y oportunidades.' },
  { number: 3, title: 'Creamos tu marca', description: 'Logo, colores y tipografía. Tu identidad lista.' },
  { number: 4, title: 'Armamos tu web', description: 'Sitio profesional publicado y optimizado.' },
  { number: 5, title: 'Lanzamos campañas', description: 'Google y Meta Ads configurados y activos.' },
  { number: 6, title: 'Aparecés en medios', description: 'Notas en portales de noticias reales.' },
] as const

export function HowItWorks() {
  const { ref, isVisible } = useInView()

  return (
    <section
      id="como-funciona"
      ref={ref as RefObject<HTMLElement>}
      className="bg-navy-900 py-20 md:py-24"
    >
      <div className="max-w-6xl mx-auto px-6">
        <h2 className={`text-3xl md:text-4xl font-bold text-white text-center mb-16 reveal ${isVisible ? 'visible' : ''}`}>
          Cómo funciona
        </h2>

        {/* Desktop: fila horizontal con conectores */}
        <div className={`hidden md:flex items-start reveal ${isVisible ? 'visible' : ''}`}>
          {STEPS.map((step, i) => (
            <div key={step.number} className="flex items-start flex-1 min-w-0">
              <div className="flex flex-col items-center text-center flex-1 min-w-0 px-2">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center border-2 font-bold text-sm shrink-0 ${
                    step.number === 3
                      ? 'bg-accent border-accent text-white'
                      : step.number < 3
                      ? 'bg-transparent border-status-success text-status-success'
                      : 'bg-transparent border-accent text-white'
                  }`}
                  style={
                    step.number === 3
                      ? { boxShadow: '0 0 16px rgba(139,92,246,0.5)' }
                      : undefined
                  }
                >
                  {step.number}
                </div>
                <h3 className="text-white font-semibold text-sm mt-3 mb-1">{step.title}</h3>
                <p className="text-slate-400 text-xs leading-relaxed">{step.description}</p>
              </div>

              {i < STEPS.length - 1 && (
                <div className="flex items-center mt-6 shrink-0 w-4">
                  <div
                    className="h-0.5 w-full"
                    style={{
                      background:
                        step.number < 3
                          ? '#10B981'
                          : step.number === 3
                          ? 'linear-gradient(to right, #8B5CF6, #374151)'
                          : '#1E293B',
                    }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Mobile: stack vertical */}
        <div className={`md:hidden flex flex-col gap-6 reveal-stagger ${isVisible ? 'visible' : ''}`}>
          {STEPS.map((step) => (
            <div key={step.number} className="flex items-start gap-4">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center border-2 font-bold text-sm shrink-0 ${
                  step.number === 3
                    ? 'bg-accent border-accent text-white'
                    : step.number < 3
                    ? 'bg-transparent border-status-success text-status-success'
                    : 'bg-transparent border-accent text-white'
                }`}
                style={
                  step.number === 3
                    ? { boxShadow: '0 0 16px rgba(139,92,246,0.4)' }
                    : undefined
                }
              >
                {step.number}
              </div>
              <div className="pt-1">
                <h3 className="text-white font-semibold text-sm mb-1">{step.title}</h3>
                <p className="text-slate-400 text-xs leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
