import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import Link from 'next/link'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { OrderStatusBadge } from '@/lib/order-status'
import { AdvertiserActions } from './AdvertiserActions'
import { OrderChatBox } from '@/components/OrderChatBox'
import { formatARS, formatDate } from '@/lib/format'

export const metadata: Metadata = { title: 'Detalle del pedido — Qautiva' }

export default async function PedidoDetailPage({
  params,
}: {
  params: { orderId: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect(`/login?next=/mis-pedidos/${params.orderId}`)

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true },
  })
  if (!profile) redirect('/login')

  const order = await prisma.order.findUnique({
    where: { id: params.orderId },
    select: {
      id: true,
      advertiserId: true,
      status: true,
      brief: true,
      targetUrl: true,
      anchorText: true,
      price: true,
      commission: true,
      editorPayout: true,
      deliveryUrl: true,
      deliveryNotes: true,
      expiresAt: true,
      deliveryDeadline: true,
      createdAt: true,
      acceptedAt: true,
      deliveredAt: true,
      completedAt: true,
      cancelledAt: true,
      cancellationReason: true,
      product: { select: { id: true, name: true, type: true, deliveryDays: true } },
      medium: { select: { id: true, name: true, platform: true } },
    },
  })

  if (!order) notFound()
  // Solo el anunciante puede ver este pedido
  if (order.advertiserId !== profile.id) notFound()

  return (
    <div className="p-6 max-w-3xl mx-auto flex flex-col gap-6">
      {/* Breadcrumb */}
      <nav aria-label="Navegación" className="text-sm text-[#64748B] flex items-center gap-2 flex-wrap">
        <Link href="/mis-pedidos" className="hover:text-[#94A3B8] transition-colors">Mis Pedidos</Link>
        <span>/</span>
        <span className="text-[#94A3B8] truncate">{order.product.name}</span>
      </nav>

      {/* Header */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
        <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <OrderStatusBadge status={order.status} />
            </div>
            <h1 className="text-white font-bold text-lg">{order.product.name}</h1>
            <Link
              href={`/marketplace/${order.medium.id}`}
              className="text-[#64748B] text-sm hover:text-[#94A3B8] transition-colors"
            >
              en {order.medium.name} ↗
            </Link>
          </div>
          <div className="text-right">
            <p className="text-white font-bold text-xl">{formatARS(order.price?.toNumber() ?? 0)}</p>
            <p className="text-[#475569] text-xs">Creado: {formatDate(order.createdAt)}</p>
          </div>
        </div>

        {/* Fechas clave */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <p className="text-[#64748B]">Expira (aceptación)</p>
            <p className="text-[#94A3B8]">{formatDate(order.expiresAt)}</p>
          </div>
          {order.deliveryDeadline && (
            <div>
              <p className="text-[#64748B]">Entrega límite</p>
              <p className="text-[#94A3B8]">{formatDate(order.deliveryDeadline)}</p>
            </div>
          )}
          {order.completedAt && (
            <div>
              <p className="text-[#64748B]">Completado</p>
              <p className="text-[#34D399]">{formatDate(order.completedAt)}</p>
            </div>
          )}
          {order.cancelledAt && (
            <div>
              <p className="text-[#64748B]">Cancelado</p>
              <p className="text-red-400">{formatDate(order.cancelledAt)}</p>
            </div>
          )}
        </div>
      </div>

      {/* Brief y datos */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4">
        <h2 className="text-white font-semibold">Detalle del pedido</h2>
        <div>
          <p className="text-[#64748B] text-xs mb-1">Brief</p>
          <p className="text-[#94A3B8] text-sm leading-relaxed whitespace-pre-wrap">{order.brief}</p>
        </div>
        {order.targetUrl && (
          <div>
            <p className="text-[#64748B] text-xs mb-1">URL destino</p>
            <a href={order.targetUrl} target="_blank" rel="noopener noreferrer" className="text-[#60A5FA] text-sm hover:underline break-all">
              {order.targetUrl}
            </a>
          </div>
        )}
        {order.anchorText && (
          <div>
            <p className="text-[#64748B] text-xs mb-1">Texto ancla</p>
            <p className="text-[#94A3B8] text-sm">{order.anchorText}</p>
          </div>
        )}
        {order.cancellationReason && (
          <div>
            <p className="text-[#64748B] text-xs mb-1">Motivo de cancelación / correcciones</p>
            <p className="text-orange-400 text-sm leading-relaxed">{order.cancellationReason}</p>
          </div>
        )}
      </div>

      {/* Entrega del editor */}
      {order.deliveryUrl && (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-3">
          <h2 className="text-white font-semibold">Entrega del editor</h2>
          <div>
            <p className="text-[#64748B] text-xs mb-1">URL del contenido publicado</p>
            <a href={order.deliveryUrl} target="_blank" rel="noopener noreferrer" className="text-[#60A5FA] text-sm hover:underline break-all">
              {order.deliveryUrl}
            </a>
          </div>
          {order.deliveryNotes && (
            <div>
              <p className="text-[#64748B] text-xs mb-1">Notas del editor</p>
              <p className="text-[#94A3B8] text-sm leading-relaxed">{order.deliveryNotes}</p>
            </div>
          )}
          <p className="text-[#475569] text-xs">Entregado: {formatDate(order.deliveredAt)}</p>
        </div>
      )}

      {/* Precio */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
        <h2 className="text-white font-semibold mb-3">Financiero</h2>
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Precio del producto</span>
            <span className="text-white">{formatARS(order.price?.toNumber() ?? 0)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Comisión Qautiva (10%)</span>
            <span className="text-white">{formatARS(order.commission?.toNumber() ?? 0)}</span>
          </div>
          <hr className="border-[#1E293B]" />
          <div className="flex justify-between font-semibold">
            <span className="text-white">Total pagado</span>
            <span className="text-white">{formatARS((order.price?.toNumber() ?? 0) + (order.commission?.toNumber() ?? 0))}</span>
          </div>
        </div>
      </div>

      {/* Acciones del anunciante */}
      <AdvertiserActions orderId={order.id} currentStatus={order.status} />

      {/* Chat */}
      <OrderChatBox orderId={order.id} profileId={profile.id} orderStatus={order.status} />
    </div>
  )
}
