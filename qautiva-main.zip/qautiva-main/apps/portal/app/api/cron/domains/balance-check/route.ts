import { NextResponse, type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'
import { createOpenSrsClientFromEnv, OpenSrsProvider } from '@qautiva/domains'

export const maxDuration = 30

/**
 * GET /api/cron/domains/balance-check
 *
 * Consulta el saldo de OpenSRS y lo guarda en OpenSrsBalanceLog.
 * Invocado por Vercel Cron cada 6 horas.
 * Emite warning si el saldo está por debajo del umbral configurado.
 *
 * Autenticación: CRON_SECRET en el header Authorization.
 */
export async function GET(request: NextRequest) {
  const reqId = crypto.randomUUID()

  const authHeader = request.headers.get('authorization')
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let client: ReturnType<typeof createOpenSrsClientFromEnv>
  try {
    client = createOpenSrsClientFromEnv()
  } catch (err) {
    console.error('[cron/domains/balance-check] Failed to initialize OpenSRS client', {
      reqId,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al inicializar el cliente OpenSRS' }, { status: 500 })
  }
  const provider = new OpenSrsProvider(client)

  const result = await provider.getBalance()

  if (!result.success) {
    console.error('[cron/domains/balance-check] GET_BALANCE failed', {
      reqId,
      error: result.error.message,
    })
    return NextResponse.json({ error: 'Error al consultar el saldo de OpenSRS' }, { status: 502 })
  }

  const { balance, holdBalance } = result.data

  await prisma.openSrsBalanceLog.create({
    data: {
      balance,
      holdBalance,
    },
  })

  const threshold = parseFloat(process.env.OPENSRS_LOW_BALANCE_THRESHOLD ?? '50')
  const balanceNum = Number(balance)

  if (balanceNum < threshold) {
    console.warn('[cron/domains/balance-check] LOW BALANCE ALERT', {
      reqId,
      balance: balanceNum,
      threshold,
      holdBalance: Number(holdBalance),
    })
  }

  console.info('[cron/domains/balance-check]', {
    reqId,
    balance: balanceNum,
    holdBalance: Number(holdBalance),
    lowBalanceAlert: balanceNum < threshold,
  })

  return NextResponse.json({
    ok: true,
    balance: balanceNum,
    holdBalance: Number(holdBalance),
  })
}
