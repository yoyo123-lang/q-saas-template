-- ============================================================
-- 010 — Triggers
-- 1. updated_at automático en tablas que lo tienen
-- 2. Auto-crear perfil cuando Supabase Auth registra un usuario nuevo
-- Rollback: 010_triggers_rollback.sql
-- ============================================================

-- ============================================================
-- Función genérica: actualiza updated_at al valor NOW()
-- ============================================================
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Aplicar en profiles
CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Aplicar en listings
CREATE TRIGGER trg_listings_updated_at
  BEFORE UPDATE ON public.listings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Aplicar en inquiries
CREATE TRIGGER trg_inquiries_updated_at
  BEFORE UPDATE ON public.inquiries
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================
-- Trigger: actualizar inquiries.updated_at cuando llega un mensaje nuevo
-- (útil para ordenar la bandeja por actividad reciente)
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_inquiry_on_new_message()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.inquiries
  SET
    updated_at = NOW(),
    status = CASE
      WHEN status = 'OPEN' THEN 'REPLIED'::inquiry_status
      ELSE status
    END
  WHERE id = NEW.inquiry_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_inquiry_message_inserted
  AFTER INSERT ON public.inquiry_messages
  FOR EACH ROW EXECUTE FUNCTION public.update_inquiry_on_new_message();

-- ============================================================
-- Trigger: auto-crear perfil cuando Supabase Auth crea un usuario
-- Se ejecuta en auth.users — requiere permiso de superuser (normal en Supabase)
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', NULL),
    'BUYER'   -- rol por defecto; el usuario puede cambiarlo al registrarse
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- Función RPC: incrementar view_count de un listing
-- Llamada desde Server Action con service_role key (bypasea RLS)
-- ============================================================
CREATE OR REPLACE FUNCTION public.increment_listing_views(listing_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.listings
  SET view_count = view_count + 1
  WHERE id = listing_id
    AND status = 'PUBLISHED';
END;
$$;

COMMENT ON FUNCTION public.increment_listing_views IS
  'Incrementa view_count de un listing publicado. Llamar desde Server Action, no desde cliente.';

-- ============================================================
-- Función RPC: published_at automático al cambiar a PUBLISHED
-- ============================================================
CREATE OR REPLACE FUNCTION public.set_published_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.status = 'PUBLISHED' AND OLD.status != 'PUBLISHED' THEN
    NEW.published_at = NOW();
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_listings_published_at
  BEFORE UPDATE ON public.listings
  FOR EACH ROW EXECUTE FUNCTION public.set_published_at();
