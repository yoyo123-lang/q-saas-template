import { cn } from '@/lib/utils/cn'
import type { ActivityType } from '@/lib/data/listings'

interface ActivityItemProps {
  type: ActivityType
  text: string
  createdAt: Date
}

const dotColors: Record<ActivityType, string> = {
  inquiry: 'bg-blue-500',
  featured: 'bg-amber-500',
  approved: 'bg-emerald-500',
  view: 'bg-slate-400',
  replied: 'bg-slate-400',
}

function formatRelative(date: Date): string {
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMin = Math.floor(diffMs / 60000)
  const diffHr = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMin < 1) return 'ahora'
  if (diffMin < 60) return `hace ${diffMin} min`
  if (diffHr < 24) return `hace ${diffHr} h`
  if (diffDays < 7) return `hace ${diffDays} días`
  return date.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })
}

export function ActivityItem({ type, text, createdAt }: ActivityItemProps) {
  return (
    <div className="flex items-start gap-3 py-2.5">
      <span
        className={cn(
          'size-2 rounded-full mt-1.5 flex-shrink-0',
          dotColors[type]
        )}
      />
      <span className="flex-1 text-sm text-slate-300">{text}</span>
      <span className="text-xs text-slate-500 whitespace-nowrap">{formatRelative(createdAt)}</span>
    </div>
  )
}
