'use client'

import { useState } from 'react'

type AdAccountStatus = 'PENDING_AUTH' | 'ACTIVE' | 'EXPIRED' | 'DISCONNECTED' | 'ERROR'

interface AdAccountCardProps {
  id: string
  platform: 'GOOGLE_ADS' | 'META'
  name: string
  status: AdAccountStatus
  tokenExpiresAt: string | null
  onDisconnect: (accountId: string) => Promise<void>
}

const STATUS_LABEL: Record<AdAccountStatus, { label: string; className: string }> = {
  PENDING_AUTH:  { label: 'Pendiente',     className: 'bg-yellow-500/15 text-yellow-400' },
  ACTIVE:        { label: 'Conectada',     className: 'bg-emerald-500/15 text-emerald-400' },
  EXPIRED:       { label: 'Expirada',      className: 'bg-orange-500/15 text-orange-400' },
  DISCONNECTED:  { label: 'Desconectada',  className: 'bg-zinc-500/15 text-zinc-400' },
  ERROR:         { label: 'Error',         className: 'bg-red-500/15 text-red-400' },
}

const PLATFORM_ICON: Record<string, string> = {
  GOOGLE_ADS: '🔵',
  META: '🟣',
}

const PLATFORM_LABEL: Record<string, string> = {
  GOOGLE_ADS: 'Google Ads',
  META: 'Meta Ads',
}

export function AdAccountCard({ id, platform, name, status, tokenExpiresAt, onDisconnect }: AdAccountCardProps) {
  const [isDisconnecting, setIsDisconnecting] = useState(false)

  const badge = STATUS_LABEL[status]
  const icon = PLATFORM_ICON[platform] ?? '🔗'
  const platformLabel = PLATFORM_LABEL[platform] ?? platform

  const isExpiringSoon = tokenExpiresAt
    ? new Date(tokenExpiresAt).getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000
    : false

  async function handleDisconnect() {
    if (!confirm(`¿Desconectar ${name}? Perdés acceso a métricas en tiempo real.`)) return
    setIsDisconnecting(true)
    try {
      await onDisconnect(id)
    } finally {
      setIsDisconnecting(false)
    }
  }

  return (
    <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 p-4">
      <div className="flex items-center gap-3">
        <span className="text-2xl" role="img" aria-label={platformLabel}>{icon}</span>
        <div>
          <p className="text-sm font-medium text-white">{name}</p>
          <p className="text-xs text-zinc-400">{platformLabel}</p>
          {isExpiringSoon && status === 'ACTIVE' && (
            <p className="mt-0.5 text-xs text-orange-400">⚠ Token expira pronto — reconectá</p>
          )}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${badge.className}`}>
          {badge.label}
        </span>
        {status !== 'DISCONNECTED' && (
          <button
            onClick={handleDisconnect}
            disabled={isDisconnecting}
            className="text-xs text-zinc-400 hover:text-red-400 disabled:opacity-50 transition-colors"
          >
            {isDisconnecting ? 'Desconectando…' : 'Desconectar'}
          </button>
        )}
      </div>
    </div>
  )
}
