'use client'

import { useEffect, useRef, useState } from 'react'

/** Intervalo base de polling mientras la IA procesa respuestas */
const POLL_BASE_MS = 3_000

/** Jitter máximo para distribuir los requests en el tiempo (thundering herd) */
const POLL_JITTER_MAX_MS = 1_000

/**
 * Máximo de polls antes de declarar timeout client-side.
 * 75 intentos × ~3.5s = ~4.4 minutos. Si el backend no responde en ese tiempo,
 * mostramos un mensaje y dejamos de hacer requests.
 */
const MAX_POLL_ATTEMPTS = 75

/** Mensajes progresivos según tiempo transcurrido */
const PROGRESS_MESSAGES = [
  { afterMs: 0, text: 'Analizando tus respuestas...' },
  { afterMs: 10_000, text: 'Organizando la información de tu entrevista...' },
  { afterMs: 25_000, text: 'Nuestra IA está elaborando tu brief estratégico...' },
  { afterMs: 45_000, text: 'Evaluando posicionamiento y estrategia...' },
  { afterMs: 65_000, text: 'Últimos ajustes. Ya casi está listo...' },
  { afterMs: 90_000, text: 'Está tomando un poco más de lo esperado. Esperá un momento...' },
]

type SessionPoll = {
  id: string
  status: string
  currentStep: number
  totalSteps: number
  answersVersion: number
  retryCount?: number
  maxRetries?: number
}

type Props = {
  sessionId: string
  onComplete: (updatedSession: SessionPoll) => void
}

/**
 * Pantalla de procesamiento — visible mientras InterviewSession.status === 'PROCESSING'.
 * Hace polling cada 10s a GET /api/interview/sessions/[id] hasta que el estado cambia.
 * Se detiene automáticamente después de MAX_POLL_ATTEMPTS (5 min) para no generar
 * requests infinitos si el backend se queda colgado.
 * Cuando detecta una transición (COMPLETED/FAILED/etc.), notifica al padre via onComplete.
 *
 * También reintenta POST /process al montar para cubrir el caso donde la llamada
 * original falló silenciosamente (ej: timeout 504 swallowed por fire-and-forget).
 */
export function ProcessingScreen({ sessionId, onComplete }: Props) {
  const [elapsedMs, setElapsedMs] = useState(0)
  const [pollError, setPollError] = useState(false)
  const [timedOut, setTimedOut] = useState(false)
  // Ref para leer timedOut dentro del closure del useEffect de polling sin stale capture
  const timedOutRef = useRef(false)
  const startRef = useRef(Date.now())
  const onCompleteRef = useRef(onComplete)
  onCompleteRef.current = onComplete
  const pollAttemptsRef = useRef(0)

  // Reintentar /process al montar — cubre el caso donde la llamada original falló
  // (ej: 504 swallowed, page reload con sesión stuck en PROCESSING).
  // El route /process es idempotente: si ya está COMPLETED, retorna 200 sin regenerar.
  useEffect(() => {
    fetch(`/api/interview/sessions/${sessionId}/process`, { method: 'POST' })
      .catch((err) => { console.error('[ProcessingScreen] reintento de /process falló — el polling detectará si sigue en PROCESSING:', err) })
  // Solo al montar — sessionId no cambia durante el ciclo de vida del componente
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId])

  // Reloj para actualizar mensajes progresivos (tick cada 3s para transiciones fluidas)
  useEffect(() => {
    const tick = setInterval(() => {
      const elapsed = Date.now() - startRef.current
      setElapsedMs(elapsed)
      // Apagar el tick después de 95s, los mensajes ya no cambian
      if (elapsed > 95_000) clearInterval(tick)
    }, 3_000)
    return () => clearInterval(tick)
  }, [])

  // Polling de estado con límite de intentos
  useEffect(() => {
    let cancelled = false

    async function poll() {
      pollAttemptsRef.current += 1

      // Límite de intentos: 5 minutos de polling sin respuesta → timeout client-side
      if (pollAttemptsRef.current > MAX_POLL_ATTEMPTS) {
        if (!cancelled) {
          timedOutRef.current = true
          setTimedOut(true)
        }
        return
      }

      try {
        const res = await fetch(`/api/interview/sessions/${sessionId}`)
        if (!res.ok) {
          setPollError(true)
          return
        }
        // Éxito de red: limpiar error anterior si lo había
        setPollError(false)
        const data = await res.json()
        if (!cancelled && data.session.status !== 'PROCESSING') {
          onCompleteRef.current(data.session)
        }
      } catch {
        setPollError(true)
      }
    }

    // Primera poll inmediata por si ya terminó
    poll()

    // Intervalo con jitter para distribuir requests cuando hay muchos usuarios en PROCESSING.
    // Cada cliente recibe un intervalo levemente distinto (10s + 0-3s aleatorio).
    const jitter = Math.random() * POLL_JITTER_MAX_MS
    const interval = setInterval(() => {
      if (!cancelled && !timedOutRef.current) poll()
    }, POLL_BASE_MS + jitter)

    return () => {
      cancelled = true
      clearInterval(interval)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId])

  // Pantalla de timeout client-side (5 min sin respuesta)
  if (timedOut) {
    return (
      <div className="p-8 max-w-2xl">
        <div className="bg-[#0F172A] border border-[#F59E0B]/20 rounded-xl p-8 text-center">
          <div className="w-12 h-12 rounded-full bg-[#F59E0B]/10 border border-[#F59E0B]/30 flex items-center justify-center mx-auto mb-4">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" strokeWidth="2" aria-hidden="true">
              <circle cx="12" cy="12" r="10" />
              <path d="M12 8v4m0 4h.01" strokeLinecap="round" />
            </svg>
          </div>
          <p className="text-white font-medium mb-2">El procesamiento está tardando más de lo normal</p>
          <p className="text-[#94A3B8] text-sm mb-5">
            No te preocupes, tus respuestas están guardadas. Podés volver más tarde o intentar recargar la página.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 text-sm bg-[#1E293B] hover:bg-[#334155] text-[#94A3B8] hover:text-white rounded-lg transition-colors"
          >
            Verificar estado
          </button>
        </div>
      </div>
    )
  }

  // Mensaje según tiempo transcurrido
  const found = PROGRESS_MESSAGES.slice().reverse().find((m) => elapsedMs >= m.afterMs)
  const currentMessage = found?.text ?? PROGRESS_MESSAGES[0]!.text

  return (
    <div className="p-8 max-w-2xl">
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8">
        {/* Ícono animado */}
        <div className="flex justify-center mb-6">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 flex items-center justify-center">
              <svg
                className="animate-spin"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#8B5CF6"
                strokeWidth="2"
                aria-hidden="true"
              >
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            </div>
            {/* Pulso externo */}
            <div className="absolute inset-0 rounded-full bg-[#8B5CF6]/5 animate-ping" />
          </div>
        </div>

        {/* Título */}
        <h2 className="text-white text-xl font-bold text-center mb-2">
          Procesando tu entrevista
        </h2>
        <p className="text-[#94A3B8] text-sm text-center mb-8 transition-all duration-500">
          {currentMessage}
        </p>

        {/* Pasos animados */}
        <ProcessingSteps elapsedMs={elapsedMs} />

        {/* Aviso de tiempo */}
        <p className="text-[#475569] text-xs text-center mt-6">
          Esto suele tomar entre 30 segundos y 2 minutos. Esta página se actualiza automáticamente.
        </p>

        {/* Error de conexión transitorio */}
        {pollError && (
          <div className="mt-4 text-center">
            <p className="text-[#F59E0B] text-xs">
              Problema de conexión. Reintentando automáticamente...{' '}
              <button
                onClick={() => window.location.reload()}
                className="underline hover:no-underline"
              >
                Recargar
              </button>
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Indicadores de paso ──────────────────────────────────────────────────────

const STEPS = [
  { label: 'Respuestas recibidas', afterMs: 0 },
  { label: 'Analizando información del negocio', afterMs: 8_000 },
  { label: 'Evaluando mercado y competencia', afterMs: 25_000 },
  { label: 'Definiendo estrategia de posicionamiento', afterMs: 45_000 },
  { label: 'Armando el brief final', afterMs: 65_000 },
]

function ProcessingSteps({ elapsedMs }: { elapsedMs: number }) {
  return (
    <div className="flex flex-col gap-3">
      {STEPS.map((step, i) => {
        const done = elapsedMs > step.afterMs
        const nextStep = STEPS[i + 1]
        const active = done && (i === STEPS.length - 1 || (nextStep !== undefined && elapsedMs < nextStep.afterMs))

        return (
          <div key={step.label} className="flex items-center gap-3">
            <div
              className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-500 ${
                done
                  ? active
                    ? 'bg-[#8B5CF6]/20 border border-[#8B5CF6]'
                    : 'bg-[#10B981]/15 border border-[#10B981]/40'
                  : 'bg-[#1E293B] border border-[#334155]'
              }`}
              aria-hidden="true"
            >
              {done && !active ? (
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="3">
                  <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              ) : active ? (
                <div className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
              ) : null}
            </div>
            <span
              className={`text-sm transition-colors duration-500 ${
                done ? (active ? 'text-[#A78BFA]' : 'text-[#94A3B8]') : 'text-[#475569]'
              }`}
            >
              {step.label}
            </span>
          </div>
        )
      })}
    </div>
  )
}
