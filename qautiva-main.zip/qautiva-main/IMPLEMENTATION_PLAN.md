# Plan de Implementación — Qautiva

> Este documento define el plan de trabajo por etapas.
> Cada etapa debe ser aprobada antes de comenzar la siguiente.
> Última actualización: 2026-03-10

---

## Estado general

| Etapa | Nombre | Estado |
|-------|--------|--------|
| 1 | Foundation | ✅ Completa (2026-03-10) |
| 2 | Landing completa | ✅ Completa (2026-03-10) |
| 3 | Portal del cliente (self-service) | ✅ Completa y revisada (2026-03-11) |
| 4 | Backoffice admin + Telegram Bot | ⏳ Lista para comenzar |
| 5 | Integración y pulido | 🔒 Bloqueada hasta Etapa 4 |

---

## Etapa 1 — Foundation

**Objetivo:** Monorepo funcionando, design system base, auth configurado, layout de las 3 apps + estructura del bot, todo con datos mock.

**Criterio de éxito:** Las 3 apps levantan en local (`pnpm dev`), el design system se importa correctamente, Prisma genera el cliente sin errores, Supabase Auth funciona con Google OAuth, reCAPTCHA verificable en dev.

---

### 1.1 Setup del monorepo

**Archivos a crear:**
- `package.json` (root) — workspace con pnpm
- `pnpm-workspace.yaml` — incluye `packages/*`, `apps/*`, `services/*`
- `.gitignore` — node_modules, .env, .next, dist, .turbo
- `.env.example` — todas las variables documentadas (ver ARCHITECTURE.md sección 5)
- `tsconfig.base.json` — configuración TypeScript base compartida, strict mode

**Tareas:**
1. Inicializar workspace pnpm con `packages/*`, `apps/*` y `services/*`
2. Configurar TypeScript base con paths y strict mode
3. Configurar Vitest en la raíz (workspace config)
4. Verificar que `pnpm install` funciona desde la raíz

---

### 1.2 packages/db — Schema, Auth, RLS

**Archivos a crear:**
- `packages/db/package.json`
- `packages/db/prisma/schema.prisma` — schema completo (ver abajo)
- `packages/db/prisma/rls.sql` — políticas RLS para multi-tenancy
- `packages/db/prisma/seed.ts` — datos de ejemplo realistas
- `packages/db/client.ts` — Prisma client singleton
- `packages/db/supabase.ts` — helpers para crear Supabase client (server + browser)
- `packages/db/index.ts` — re-exports
- `packages/db/.env.example`

**Schema — entidades del spec + auth + telegram:**

```
# Del spec original (sección 6):
Organization, Stage, Deliverable, Message, Metric, AdminNote, Subscription,
AgentConfig, IndustryTemplate

# Auth (Supabase Auth maneja User/Session internamente, pero necesitamos):
UserProfile          — vincula auth.users con Organization + role + preferences
  id                 — uuid, PK
  authUserId         — referencia a auth.users(id) de Supabase
  organizationId     — FK a Organization (nullable para admins sin org)
  role               — CLIENT | ADMIN
  displayName        — nombre visible
  avatarUrl          — URL del avatar (de Google o subido)

# Telegram:
TelegramUser         — whitelist vinculada a Organization
  id, organizationId, telegramUserId (BigInt), telegramUsername,
  telegramChatId, isActive, createdAt

TelegramConfig       — singleton (id=1)
  botEnabled, llmProvider, llmModel, rateLimitPerHour,
  systemPromptOverride, createdAt, updatedAt
```

**RLS policies (rls.sql):**
- `Organization`: `id = get_user_org_id()` para clientes, sin restricción para admins
- `Stage`, `Deliverable`, `Message`, `Metric`, `AdminNote`: `organization_id = get_user_org_id()`
- `AgentConfig`, `IndustryTemplate`, `TelegramConfig`: solo admins
- `UserProfile`: el usuario ve solo su propio perfil; admin ve todos
- Función helper `get_user_org_id()`: extrae `org_id` del JWT de Supabase

**Índices obligatorios:**
- `organization_id` en todas las tablas que lo tengan (RLS lo usa en cada query)
- `Stage.organizationId + Stage.number` (composite, para lookup rápido)
- `Deliverable.stageId`
- `Message.organizationId + Message.createdAt` (consultas ordenadas)
- `TelegramUser.telegramUserId` (lookup por ID de Telegram)

**Datos de seed (argentinos realistas):**
- 3 organizaciones: "Peluquería Verde" (Belleza, Completo, Etapa 3), "Café Aroma" (Gastronomía, Base, Etapa 5), "Estudio García" (Contable, Premium, Etapa 2)
- Stages y deliverables acordes a cada etapa
- 6 AgentConfigs con datos del spec
- Métricas de 30 días para orgs en etapa avanzada
- 2 UserProfiles: 1 admin (admin@qautiva.ar), 1 cliente (vinculado a Peluquería Verde)
- 1 TelegramConfig con valores por defecto

---

### 1.3 packages/ui — Design system

**Archivos a crear:**
- `packages/ui/package.json`
- `packages/ui/tsconfig.json`
- `packages/ui/tokens.ts` — colores, tipografía, spacing, radios (ver spec sección 2)
- `packages/ui/tailwind.config.ts` — config Tailwind base compartida
- `packages/ui/components/Button.tsx`
- `packages/ui/components/Card.tsx`
- `packages/ui/components/Badge.tsx`
- `packages/ui/components/Input.tsx`
- `packages/ui/components/ProgressBar.tsx` — StageProgress (6 nodos)
- `packages/ui/components/Sidebar.tsx` — variantes client/admin
- `packages/ui/index.ts` — re-exports

**Criterios por componente:**
- Props tipadas (sin `any`)
- Estados: default, hover, disabled, loading donde aplica
- Sin lógica de negocio — solo presentación
- Cada componente ≤ 30 líneas de lógica (sin contar markup)

| Componente | Variantes/Props clave |
|---|---|
| `Button` | `variant: primary\|secondary`, `size: sm\|md\|lg`, `loading`, `disabled`, `icon` |
| `Card` | `accentBorder?: boolean`, `hover?: boolean` |
| `Badge` | `variant: completed\|active\|pending\|attention` |
| `Input` | `label`, `error`, `placeholder` |
| `ProgressBar` | `stages: Stage[]`, `activeStage: number` — 6 nodos conectados |
| `Sidebar` | `variant: client\|admin`, `items`, `activeItem`, `footer` |

---

### 1.4 apps/landing — Estructura base + reCAPTCHA

**Archivos a crear:**
- `apps/landing/package.json`
- `apps/landing/next.config.ts`
- `apps/landing/tailwind.config.ts` — extiende config base de `packages/ui`
- `apps/landing/tsconfig.json`
- `apps/landing/app/layout.tsx` — metadata SEO completa + fuentes + script reCAPTCHA
- `apps/landing/app/globals.css` — reset, fuentes, variables CSS
- `apps/landing/app/page.tsx` — importa todos los componentes de sección
- `apps/landing/app/api/contact/route.ts` — endpoint protegido con reCAPTCHA v3
- `apps/landing/components/Navbar.tsx` — placeholder funcional
- `apps/landing/components/Hero.tsx` — placeholder con estructura
- `apps/landing/components/HowItWorks.tsx` — placeholder
- `apps/landing/components/Deliverables.tsx` — placeholder
- `apps/landing/components/WhyDifferent.tsx` — placeholder
- `apps/landing/components/Pricing.tsx` — placeholder con formulario de contacto
- `apps/landing/components/Ecosystem.tsx` — placeholder
- `apps/landing/components/FinalCta.tsx` — placeholder
- `apps/landing/components/Footer.tsx` — placeholder
- `apps/landing/lib/recaptcha.ts` — helper para verificar token en servidor

> **Nota:** Los componentes de landing son placeholders con la sección identificada, fondo correcto, y título. El contenido visual completo es Etapa 2. El endpoint de contacto y la verificación reCAPTCHA sí son funcionales.

---

### 1.5 apps/portal — Layout + Auth + dashboard mock

**Archivos a crear:**
- `apps/portal/package.json`
- `apps/portal/next.config.ts`
- `apps/portal/tailwind.config.ts`
- `apps/portal/tsconfig.json`
- `apps/portal/middleware.ts` — verifica sesión Supabase; si no hay → redirect a `/login`
- `apps/portal/app/layout.tsx` — layout con ClientSidebar (protegido por middleware)
- `apps/portal/app/page.tsx` — redirect a `/progreso`
- `apps/portal/app/login/page.tsx` — botón "Continuar con Google" + form email/password con reCAPTCHA
- `apps/portal/app/auth/callback/route.ts` — handler del callback de OAuth
- `apps/portal/app/progreso/page.tsx` — dashboard principal con datos mock
- `apps/portal/app/entregables/page.tsx` — placeholder
- `apps/portal/app/metricas/page.tsx` — placeholder
- `apps/portal/app/configuracion/page.tsx` — placeholder
- `apps/portal/components/ClientSidebar.tsx` — sidebar completo
- `apps/portal/lib/supabase-server.ts` — crea Supabase client para server components
- `apps/portal/lib/supabase-browser.ts` — crea Supabase client para client components
- `apps/portal/lib/mock-data.ts` — datos mock de "Peluquería Verde" en Etapa 3

**Auth funcional en Etapa 1:**
- Login con Google OAuth funciona de punta a punta
- Login con email/password funciona con reCAPTCHA
- Middleware protege todas las rutas excepto `/login` y `/auth/callback`
- Sesión persiste entre recargas de página

**Pantalla de progreso con datos mock:**
- StageProgress con etapas 1 y 2 completadas, etapa 3 activa
- ActionCard: "Etapa 3 — Tu marca", badge ámbar "Esperando tu aprobación", botón "Ver propuesta de marca"
- Lista de completadas: "Brief estratégico" (3 mar) y "Estudio de mercado" (5 mar)

---

### 1.6 apps/admin — Layout + Auth admin

**Archivos a crear:**
- `apps/admin/package.json`
- `apps/admin/next.config.ts`
- `apps/admin/tailwind.config.ts`
- `apps/admin/tsconfig.json`
- `apps/admin/middleware.ts` — verifica sesión + rol admin
- `apps/admin/app/layout.tsx` — layout con AdminSidebar (protegido)
- `apps/admin/app/page.tsx` — Kanban placeholder (estructura de columnas vacías)
- `apps/admin/app/clientes/page.tsx` — placeholder
- `apps/admin/app/revision/page.tsx` — placeholder
- `apps/admin/app/agentes/page.tsx` — placeholder
- `apps/admin/app/telegram/page.tsx` — placeholder (admin del bot)
- `apps/admin/app/api/health/route.ts` — health check (verifica DB + Supabase)
- `apps/admin/components/AdminSidebar.tsx` — sidebar admin completo

**Auth admin en Etapa 1:**
- Login con Google OAuth (mismo flujo que portal)
- Middleware verifica `role === 'admin'` en `user.app_metadata`
- Si no es admin → 403 o redirect

---

### 1.7 services/telegram-bot — Estructura base

**Archivos a crear:**
- `services/telegram-bot/package.json`
- `services/telegram-bot/tsconfig.json`
- `services/telegram-bot/src/index.ts` — entry point, inicializa bot si `TELEGRAM_BOT_TOKEN` existe
- `services/telegram-bot/src/bot.ts` — config grammY, registra handlers
- `services/telegram-bot/src/commands/start.ts` — `/start` vincula usuario TG con organización
- `services/telegram-bot/src/commands/status.ts` — `/status` devuelve etapa actual
- `services/telegram-bot/src/commands/help.ts` — `/help` lista comandos
- `services/telegram-bot/src/message-bridge.ts` — guarda mensajes en tabla `Message`
- `services/telegram-bot/src/rate-limiter.ts` — ventana deslizante in-memory

**En Etapa 1, el bot:**
- Responde a `/start`, `/status`, `/help` con datos de la DB
- Guarda mensajes del usuario en la tabla `Message(channel: TELEGRAM)`
- Aplica rate limiting
- **No tiene LLM todavía** — responde con templates estáticos ("Tu proyecto está en Etapa 3 — Marca")
- Si `TELEGRAM_BOT_TOKEN` no está, no inicia (sin error, solo log)

---

### 1.8 Testing base

**Archivos a crear:**
- `vitest.config.ts` (raíz) — config workspace
- `packages/ui/__tests__/Button.test.tsx` — test de render + variantes
- `packages/ui/__tests__/Badge.test.tsx` — test de variantes de estado
- `packages/db/__tests__/client.test.ts` — test de que el client se genera
- `apps/landing/__tests__/recaptcha.test.ts` — test de verificación de reCAPTCHA (mock)

**Framework:** Vitest con `@testing-library/react` para componentes UI.

---

### Orden de implementación

```
 1. Monorepo setup (package.json root, pnpm-workspace.yaml, tsconfig.base.json, vitest)
 2. packages/db — schema.prisma + client.ts + supabase.ts + rls.sql
 3. packages/db — seed.ts
 4. packages/ui — tokens.ts + tailwind.config.ts
 5. packages/ui — Button, Card, Badge, Input
 6. packages/ui — ProgressBar (StageProgress)
 7. packages/ui — Sidebar
 8. apps/landing — estructura + reCAPTCHA + API de contacto
 9. apps/portal — layout + auth (OAuth + email) + middleware + login + dashboard mock
10. apps/admin — layout + auth admin + middleware + health check
11. services/telegram-bot — estructura base + comandos + message-bridge
12. Tests base (UI + reCAPTCHA + client)
13. Verificación final: todas las apps levantan, auth funciona, bot responde
```

---

### Checklist de verificación (Etapa 1)

- [x] `pnpm install` desde la raíz sin errores
- [x] `pnpm --filter landing dev` levanta en localhost:3000
- [x] `pnpm --filter portal dev` levanta en localhost:3001
- [x] `pnpm --filter admin dev` levanta en localhost:3002
- [x] `prisma generate` sin errores
- [x] `prisma db push` crea las tablas correctamente
- [x] `prisma db seed` carga los datos de ejemplo
- [x] RLS policies aplicadas y verificadas (cliente no ve datos de otra org)
- [x] Login con Google OAuth funciona en portal
- [x] Login con email/password + reCAPTCHA funciona en portal
- [x] Middleware de portal redirige a `/login` sin sesión
- [x] Middleware de admin verifica rol admin
- [x] Health check de admin responde OK (`/api/health`)
- [x] El portal muestra la página de progreso con datos mock
- [x] El design system se importa en las 3 apps sin errores de tipos
- [x] Bot de Telegram responde a `/start` y `/status` (si hay token configurado)
- [x] Mensajes del bot se guardan en tabla `Message`
- [x] `.env.example` presente y completo en raíz y cada app/servicio
- [x] Tests pasan: `pnpm test`
- [x] No hay errores de TypeScript: `pnpm tsc --noEmit`
- [x] No hay `console.log` de debug ni `any` en el código
- [x] No hay secretos hardcodeados
- [x] `@@index([organizationId])` en todas las tablas con FK a Organization (incluye AdminNote y TelegramUser)

---

---

## Etapa 2 — Landing completa ✅ Completada 2026-03-10

Todos los componentes implementados con animaciones, responsive, SEO, formulario con reCAPTCHA v3. Deploy en Vercel.

**Branch:** `claude/review-qautiva-docs-Tg8ZO` (mergeado)

---

## Etapa 3 — Portal del cliente (self-service) ✅ Completada 2026-03-11

Portal completo con onboarding wizard, dashboard por proyecto, aprobación de entregables, chat con Realtime. Revisión pre-producción completa (6 roles, todos los CRÍTICO/ALTO/MEDIO corregidos).

**Branch:** `claude/qautiva-onboarding-development-K83mS`

**Pendientes BAJO (no bloqueantes):**
- `api-key/client.tsx` — reemplazar `window.location.href` por `router.push()`
- Extraer `BaseSidebar` compartido (`ProjectSidebar` + `ClientSidebar`)
- Mover tipos `BrandOptionContent` / `WebsiteContent` a módulo compartido
- Verificar trigger Supabase para `BillingAccount` (warn en onboarding step4)

---

## Etapa 4 — Backoffice admin + Telegram Bot completo

**Objetivo:** Admin funcional para supervisar clientes + bot Telegram con LLM.

**Criterio de éxito:** Admin puede ver todos los clientes en Kanban, entrar a una ficha, revisar y aprobar un entregable desde la cola, cambiar nivel de automatización de un agente, y el bot responde en lenguaje natural con contexto del proyecto del cliente.

**Renders de referencia:** `renders/09-admin-kanban.png`, `10-admin-ficha-cliente.png`, `11-admin-cola-revision.png`, `12-admin-agentes.png`

---

### 4.1 Dashboard Kanban (`/`)

**Archivos a modificar:**
- `apps/admin/app/page.tsx` — reemplazar placeholder con Kanban real
- `apps/admin/components/KanbanBoard.tsx` — tablero con 7 columnas + filtros
- `apps/admin/components/KanbanColumn.tsx` — columna con header de color + conteo
- `apps/admin/components/ClientCard.tsx` — tarjeta con nombre, rubro, estado, plan, borde pulsante si espera revisión
- `apps/admin/components/MetricsRow.tsx` — 5 tarjetas métricas (clientes activos, cola, lanzamientos, ingreso, campañas)

**Datos:**
- `Organization` con `status` → columna del Kanban
- Filtros: Plan, Rubro (industry), Status
- Columnas: Descubrimiento / Investigación / Marca / Web / Campañas / Medios / Completado
- Click en tarjeta → `/clientes/[id]`

---

### 4.2 Ficha del cliente (`/clientes/[id]`)

**Archivos a modificar:**
- `apps/admin/app/clientes/[id]/page.tsx` — página con tabs
- `apps/admin/components/ClientHeader.tsx` — logo + nombre + badges + botones de acción
- `apps/admin/components/ClientTabs.tsx` — tabs: Progreso | Conversaciones | Entregables | Facturación | Notas

**Tab Progreso:**
- StageProgress con etapas expandibles
- Estado admin por entregable: No revisado / Aprobado / Enviado al cliente
- Estado cliente: No visto / En revisión / Aprobado / Pidió cambios
- Botones: Revisar, Regenerar, Editar manualmente

**Tab Conversaciones:**
- Historial completo (canal WEB + TELEGRAM), filtrable por etapa
- Botón "Intervenir" → envía `Message(sender: ADMIN)`

**Tab Notas:**
- `AdminNote` — texto libre, no visible para cliente

---

### 4.3 Cola de revisión (`/revision`)

**Archivos a modificar:**
- `apps/admin/app/revision/page.tsx` — layout split
- `apps/admin/components/ReviewQueue.tsx` — panel izquierdo (40%): lista de pendientes con badge urgente si >12hs
- `apps/admin/components/ReviewPanel.tsx` — panel derecho (60%): preview + acciones

**Acciones del ReviewPanel:**
- "Aprobar y enviar al cliente" → `Deliverable.status = SENT_TO_CLIENT`
- "Regenerar con instrucciones" → campo de texto + flag al sistema externo
- "Rechazar" → `Deliverable.status = REJECTED`

---

### 4.4 Configuración de agentes (`/agentes` + `/agentes/[id]`)

**Archivos a modificar:**
- `apps/admin/app/agentes/page.tsx` — grid 3×2 de AgentCards
- `apps/admin/app/agentes/[id]/page.tsx` — detalle con prompt editor + historial
- `apps/admin/components/AgentCard.tsx` — tarjeta con toggle 3 estados + stats
- `apps/admin/components/AutomationToggle.tsx` — Manual | Semi-auto | Auto

**Los 6 agentes del spec:**
1. El Estratega — Descubrimiento y brief
2. El Investigador — Estudio de mercado
3. El Director Creativo — Marca e identidad
4. El Arquitecto Web — Diseño y desarrollo web
5. El Media Planner — Campañas Google y Meta
6. El Periodista — Publinotas y medios

---

### 4.5 Bot de Telegram con LLM (`services/telegram-bot`)

**Archivos a modificar:**
- `services/telegram-bot/src/llm-service.ts` — Anthropic SDK (Haiku para FAQ, Sonnet para conversaciones complejas)
- `services/telegram-bot/src/message-bridge.ts` — respuesta LLM si no hay template estático
- `services/telegram-bot/src/commands/start.ts` — vincula `TelegramUser` a `Project` (self-service) o a `Organization` (legacy)

**Lógica de escalado de modelo:**
- Consultas de estado ("¿en qué etapa estoy?") → respuesta desde DB sin LLM
- FAQ simple → Haiku
- Conversación compleja → Sonnet
- Rate limiting: `TelegramConfig.rate_limit_per_hour`

---

### 4.6 Admin del bot (`/telegram`)

**Archivos a modificar:**
- `apps/admin/app/telegram/page.tsx` — config del bot: habilitar/deshabilitar, modelo LLM, rate limit, system prompt override
- API Route para actualizar `TelegramConfig` (singleton id=1)

---

### 4.7 Route Handlers del admin

**Archivos nuevos:**
- `apps/admin/app/api/deliverables/[id]/review/route.ts` — PATCH: approve/reject/regenerate desde la cola
- `apps/admin/app/api/messages/route.ts` — POST: intervención del admin en conversación
- `apps/admin/app/api/agents/[id]/route.ts` — PATCH: actualizar AgentConfig (level, prompt)
- `apps/admin/app/api/telegram/route.ts` — PATCH: actualizar TelegramConfig

---

### 4.8 Tests

- `apps/admin/__tests__/api/deliverable-review.test.ts` — approve/reject/regenerate (auth + estados)
- `apps/admin/__tests__/api/messages.test.ts` — intervención admin (auth + rol)
- `services/telegram-bot/__tests__/llm-service.test.ts` — escalado de modelo (mock Anthropic)

---

### Orden de implementación

```
1. MetricsRow + KanbanBoard (con datos reales de Organization)
2. ClientCard + KanbanColumn (con filtros)
3. ClientHeader + ClientTabs (Progreso + Notas)
4. Tab Conversaciones (historial + intervención)
5. ReviewQueue + ReviewPanel (aprobación/rechazo)
6. AgentCard + AutomationToggle
7. Detalle de agente (prompt editor + historial)
8. Admin del bot (/telegram)
9. LLM en telegram-bot (llm-service.ts)
10. Route Handlers (review, messages, agents, telegram)
11. Tests
```

---

### Checklist de verificación (Etapa 4)

- [ ] Kanban muestra clientes reales agrupados por etapa
- [ ] Filtros de Plan / Rubro / Status funcionan
- [ ] Ficha del cliente muestra progreso real con estados correctos
- [ ] Tab Conversaciones muestra historial WEB + TELEGRAM
- [ ] Admin puede intervenir en conversación (mensaje llega a ChatPanel del portal)
- [ ] Cola de revisión lista entregables con status `ADMIN_REVIEW`
- [ ] Aprobar entregable desde cola cambia status a `SENT_TO_CLIENT`
- [ ] El cliente ve el entregable en su portal tras la aprobación del admin
- [ ] AgentCard muestra los 6 agentes con toggle funcional
- [ ] Cambio de nivel de automatización persiste en DB
- [ ] Bot de Telegram responde con LLM (Haiku para FAQ, Sonnet para complejas)
- [ ] Bot conoce la etapa actual del cliente al responder
- [ ] Rate limiting del bot funciona (respeta `TelegramConfig.rate_limit_per_hour`)
- [ ] Admin puede desactivar el bot desde `/telegram`
- [ ] Tests pasan: `pnpm test`
- [ ] Build sin errores: `pnpm --filter admin build`
- [ ] No hay `any`, no hay `console.log` de debug, no hay secretos hardcodeados

---

## Etapa 5 — Integración y pulido

1. Portal ↔ Admin sync en real-time (Supabase Realtime para cambios de estado)
2. Notificaciones: cuando admin aprueba, el cliente ve el cambio sin recargar
3. Responsive completo en portal y admin
4. Estados vacíos, de carga, y de error en todas las pantallas
5. Auditoría de seguridad final
6. Deploy completo (portal + admin + bot)

---

**Etapas 1, 2 y 3 completadas. Etapa 4 lista para comenzar.**

---

## Feature: Configuración de Usuario — Rediseño completo

**Objetivo**: Reemplazar la página read-only de `/configuracion` con una experiencia completa que permita gestionar cuenta, contraseña, API keys de IA, selección de modelo, y ver plan/facturación. Funciona para usuarios legacy (`org_id`) y self-service (`onboarding_complete`).

**Rama**: `claude/user-account-setup-1gJOZ`

### Decisiones de diseño

1. **Una sola ruta `/configuracion`** — detecta tipo de usuario y adapta contenido
2. **Tabs URL-based** (`?tab=cuenta`, `?tab=ia`, `?tab=plan`) — mismo patrón que `/entregables?filtro=`
3. **Server Component + Client Components por sección** — page.tsx carga datos, delega interactividad
4. **Sin dependencias nuevas** — formularios con useState/useTransition, feedback inline
5. **Sin cambios al schema Prisma** — los modelos existentes cubren todo
6. **Detección de auth provider** — ocultar cambio de contraseña para Google OAuth (`user.app_metadata.provider` o `user.identities[].provider`)

### Estructura de tabs

| Tab | Param | Contenido | Usuarios |
|-----|-------|-----------|----------|
| Mi cuenta | `?tab=cuenta` (default) | Nombre editable, email read-only, cambiar contraseña | Todos |
| Inteligencia Artificial | `?tab=ia` | Modo IA, API keys (listar/agregar/revocar), modelo por defecto | Solo self-service |
| Plan y facturación | `?tab=plan` | Plan actual, uso tokens, balance, trial info | Solo self-service |

> Para legacy: tab "Mi cuenta" incluye sección "Tu negocio" read-only (como hoy). Tabs "IA" y "Plan" no se muestran.

---

### Etapa F1: Infraestructura — Layout con tabs + endpoints de perfil/contraseña

**Archivos**:
- `apps/portal/app/(protected)/configuracion/page.tsx` — REESCRIBIR: Server Component con tabs URL-based, detección legacy/self-service, carga de datos diferenciada
- `apps/portal/app/(protected)/configuracion/_components/TabNav.tsx` — NUEVO: navegación de tabs (links `<a href>` con searchParams)
- `apps/portal/app/api/settings/profile/route.ts` — NUEVO: `PATCH` displayName + avatarUrl
- `apps/portal/app/api/settings/password/route.ts` — NUEVO: `POST` cambio de contraseña

**Qué se hace**:
1. Reescribir `page.tsx`: lee `searchParams.tab`, detecta usuario legacy vs self-service, carga datos con Prisma (UserProfile, Team+ApiKey+Billing para self-service, Organization para legacy), renderiza TabNav + componente de tab activo
2. `TabNav.tsx`: array de tabs, highlight activo con `bg-[#8B5CF6] text-white` / inactivo `text-[#94A3B8]`, filtrar tabs según tipo de usuario
3. `PATCH /api/settings/profile`: auth con `supabase.auth.getUser()`, buscar UserProfile por `authUserId`, actualizar `displayName` y `avatarUrl`, retornar perfil actualizado
4. `POST /api/settings/password`: auth, recibir `{ currentPassword, newPassword }`, usar `supabase.auth.signInWithPassword()` para verificar contraseña actual, luego `supabase.auth.admin.updateUserById()` con service role para actualizar. Retornar éxito o error descriptivo

**Cómo verificar**: Navegar a `/configuracion` muestra tabs. Cambiar tabs via URL funciona. Usuarios legacy ven solo "Mi cuenta". Self-service ven las 3 tabs.

**Riesgos**:
- Cambio de contraseña con service role requiere `SUPABASE_SERVICE_ROLE_KEY` — verificar que está en env
- Usuarios legacy no tienen Team — tabs IA y Plan deben ocultarse sin error

**Estado**: ⬜ Pendiente

---

### Etapa F2: Tab "Mi cuenta" — Perfil editable + cambio de contraseña

**Archivos**:
- `apps/portal/app/(protected)/configuracion/_components/AccountTab.tsx` — NUEVO: Client Component
- `apps/portal/app/(protected)/configuracion/_components/ChangePasswordForm.tsx` — NUEVO: Client Component

**Qué se hace**:
1. `AccountTab.tsx`:
   - Props: `{ displayName, email, avatarUrl, authProvider, isLegacy, orgData? }`
   - Input editable para `displayName` (componente Input del design system)
   - Email como InfoRow read-only
   - Botón "Guardar cambios" → `fetch('/api/settings/profile', { method: 'PATCH', body })` con `useTransition`
   - Si `isLegacy && orgData`: sección "Tu negocio" read-only (nombre, rubro, plan, estado, website) — migrar UI existente
   - Feedback inline: div rojo error `bg-[#EF4444]/10`, div verde success `bg-[#10B981]/10`, auto-hide 3s
   - Componente `ChangePasswordForm` debajo

2. `ChangePasswordForm.tsx`:
   - Visible solo si `authProvider !== 'google'`
   - Si Google: mostrar "Tu cuenta usa Google para iniciar sesión. No necesitás contraseña." en texto `text-[#94A3B8]`
   - 3 campos: contraseña actual (password), nueva (password), confirmar (password)
   - Validación client-side: nueva mín 8 chars, confirmación coincide
   - Submit → `POST /api/settings/password`
   - Loading state con `useTransition`
   - Feedback inline mismo patrón

**Cómo verificar**:
- Editar nombre → guardar → refrescar → nombre persiste
- Contraseña correcta → éxito, campos se limpian
- Contraseña incorrecta → error "La contraseña actual es incorrecta"
- Contraseña nueva < 8 chars → error client-side
- Google user → no ve form, ve mensaje informativo

**Riesgos**:
- `user.app_metadata.provider` puede ser `'email'` o `'google'` — verificar valor exacto en Supabase
- Auto-hide del success necesita cleanup del timer en useEffect return

**Estado**: ⬜ Pendiente

---

### Etapa F3: Endpoints de API keys y modo IA

**Archivos**:
- `apps/portal/app/api/settings/api-keys/route.ts` — NUEVO: `GET` (listar) + `POST` (agregar)
- `apps/portal/app/api/settings/api-keys/[id]/route.ts` — NUEVO: `DELETE` (revocar)
- `apps/portal/app/api/settings/ai-mode/route.ts` — NUEVO: `PATCH` preferredKeySource

**Qué se hace**:
1. Helper compartido `getTeamForUser(authUserId)`: busca UserProfile → teamMemberships[0] → teamId. Retorna `{ teamId, teamRole }` o null. Reusar en todos los endpoints de settings.

2. `GET /api/settings/api-keys`:
   - Auth + getTeamForUser → teamId
   - `prisma.apiKey.findMany({ where: { teamId }, select: { id, provider, keyHint, label, isValid, lastUsedAt, lastError, createdAt } })`
   - NUNCA retornar `encryptedKey`

3. `POST /api/settings/api-keys`:
   - Body: `{ provider: 'ANTHROPIC' | 'OPENAI' | 'GOOGLE_GEMINI', key: string, label?: string }`
   - Validar key con `validateApiKey(provider, key)` (existente en `app/_lib/validate-api-key.ts`)
   - Encriptar con `encrypt(key)` (existente en `lib/encryption.ts`)
   - `prisma.apiKey.create({ data: { teamId, provider, encryptedKey, keyHint: keyHint(key), label, isValid: true } })`
   - Retornar `{ id, provider, keyHint, label, isValid }`

4. `DELETE /api/settings/api-keys/[id]`:
   - Auth + getTeamForUser → teamId
   - `prisma.apiKey.findUnique({ where: { id: params.id } })` → verificar `.teamId === teamId`
   - Si no coincide → 403
   - Si es la última key BYOK y `billingAccount.preferredKeySource === 'BYOK'` → advertir (retornar 409 con mensaje)
   - `prisma.apiKey.delete({ where: { id } })`

5. `PATCH /api/settings/ai-mode`:
   - Body: `{ preferredKeySource: 'BYOK' | 'QAUTIVA_HOSTED' }`
   - Si cambia a BYOK: verificar `prisma.apiKey.count({ where: { teamId, isValid: true } }) > 0`
   - Si no tiene keys válidas → 400 "Necesitás agregar al menos una API key válida antes de cambiar a modo BYOK"
   - `prisma.billingAccount.update({ where: { teamId }, data: { preferredKeySource } })`

**Cómo verificar**:
- GET sin auth → 401
- GET con auth → lista de keys (sin encryptedKey)
- POST con key válida → crea, retorna sin datos sensibles
- POST con key inválida → 400 con error del proveedor
- DELETE de key propia → 200
- DELETE de key de otro team → 403
- DELETE de última key BYOK en modo BYOK → 409
- PATCH ai-mode a BYOK sin keys → 400

**Riesgos**:
- `validateApiKey` hace HTTP al proveedor, puede demorar 2-5s — el client debe manejar loading
- El helper `getTeamForUser` podría fallar si el user no tiene teamMemberships (legacy) — retornar null, endpoint retorna 404

**Estado**: ⬜ Pendiente

---

### Etapa F4: Tab "Inteligencia Artificial" — UI completa

**Archivos**:
- `apps/portal/app/(protected)/configuracion/_components/AiTab.tsx` — NUEVO: Client Component principal
- `apps/portal/app/(protected)/configuracion/_components/ApiKeyCard.tsx` — NUEVO: card de key individual
- `apps/portal/app/(protected)/configuracion/_components/AddApiKeyForm.tsx` — NUEVO: formulario agregar key

**Qué se hace**:
1. `AiTab.tsx`:
   - Props: `{ apiKeys: ApiKeyData[], preferredKeySource, billingPlan }`
   - Sección "Modo de IA": dos cards clickeables (BYOK / Qautiva Hosted), la activa con borde `border-[#8B5CF6]`, la inactiva `border-[#1E293B]`. Click → `PATCH /api/settings/ai-mode`
   - Sección "Tus API keys": mapea `apiKeys` a `ApiKeyCard`, + botón "Agregar API key" que muestra `AddApiKeyForm` (toggle con useState)
   - Estado local `keys` inicializado con props, se actualiza al agregar/revocar sin refrescar página

2. `ApiKeyCard.tsx`:
   - Props: `{ id, provider, keyHint, label, isValid, lastUsedAt, lastError, onRevoke }`
   - Layout: icono de provider (Anthropic/OpenAI/Gemini con Lucide), `...${keyHint}`, label en gris, badge verde "Válida" / rojo "Inválida"
   - Si `lastError`: tooltip o texto pequeño con el error
   - Botón "Revocar" en rojo, al click → confirm dialog nativo → `onRevoke(id)`

3. `AddApiKeyForm.tsx`:
   - Select: provider (3 opciones)
   - Input type=password: API key
   - Input text: label (opcional)
   - Botón "Agregar" → `POST /api/settings/api-keys`
   - Loading: "Validando..." con spinner (Button loading prop)
   - On success: llama `onAdded(newKey)`, limpia form
   - On error: muestra mensaje inline

**Cómo verificar**:
- Cambiar modo IA → card activa cambia, persiste tras refresh
- Ver keys existentes con datos correctos
- Agregar key válida → aparece en lista sin refresh de página
- Agregar key inválida → error en form, lista no cambia
- Revocar → confirm → desaparece de lista
- Sin keys → mensaje "No tenés API keys configuradas"

**Riesgos**:
- Estado optimista vs pesimista: usar pesimista (esperar respuesta del server antes de actualizar UI) para evitar inconsistencias
- Provider icons: usar texto/emoji si no hay iconos de Lucide para las marcas

**Estado**: ⬜ Pendiente

---

### Etapa F5: Tab "Plan y facturación" — Read-only

**Archivos**:
- `apps/portal/app/(protected)/configuracion/_components/PlanTab.tsx` — NUEVO: componente presentacional

**Qué se hace**:
1. Props desde page.tsx (server): `{ billingPlan, preferredKeySource, trialTokensTotal, trialTokensUsed, trialExpiresAt, tokenQuota, tokensUsed, currentPeriodStart, currentPeriodEnd, balanceUsd }`
2. Sección "Tu plan": card con nombre del plan (label amigable), fuente de keys
3. Si `billingPlan === 'FREE_TRIAL'`:
   - Barra de progreso: `trialTokensUsed / trialTokensTotal` (ProgressBar del design system)
   - Texto: "Usaste X de Y tokens"
   - Fecha de expiración: "Tu prueba gratuita vence el {fecha}"
   - Si expiró: badge rojo "Expirado"
4. Si plan pago (PREPAID/MONTHLY/YEARLY):
   - Tokens: `tokensUsed / tokenQuota` con barra
   - Período: "{start} — {end}"
   - Balance: "${balanceUsd}"
5. Para legacy: datos de Organization.plan + Subscription (si existe)
6. Pie: "¿Necesitás cambiar de plan? Escribinos a hola@qautiva.ar" con link mailto

**Cómo verificar**:
- Trial user ve barra de tokens con progreso correcto
- Plan pago ve cuota y período
- Legacy ve su plan de Organization
- Sin datos de billing → mensaje amigable "No hay información de facturación disponible"
- Números formateados correctamente (locale es-AR)

**Riesgos**:
- `Decimal` de Prisma viene como string — convertir a number para mostrar
- Si `trialTokensTotal` es 0 → evitar división por cero en la barra

**Estado**: ⬜ Pendiente

---

### Etapa F6: Tests, build y QA

**Archivos**:
- `apps/portal/app/api/settings/profile/__tests__/route.test.ts` — NUEVO
- `apps/portal/app/api/settings/password/__tests__/route.test.ts` — NUEVO
- `apps/portal/app/api/settings/api-keys/__tests__/route.test.ts` — NUEVO
- `apps/portal/app/api/settings/ai-mode/__tests__/route.test.ts` — NUEVO

**Qué se hace**:
1. Tests unitarios por endpoint:
   - Sin auth → 401
   - Auth OK, happy path → respuesta correcta
   - Ownership violation → 403
   - Body inválido → 400
   - Edge: usuario legacy sin team → 404 / manejo correcto
   - Edge: DELETE última key BYOK → 409
   - Edge: PATCH ai-mode a BYOK sin keys → 400
2. `pnpm --filter portal build` → sin errores
3. `pnpm test` → todo pasa
4. Lint: sin warnings/errors
5. QA manual:
   - [ ] Self-service: editar nombre, guardar, verificar persistencia
   - [ ] Self-service: cambiar contraseña (email/password user)
   - [ ] Google OAuth user: no ve form contraseña, ve mensaje informativo
   - [ ] Self-service: agregar API key válida → aparece en lista
   - [ ] Self-service: agregar API key inválida → error
   - [ ] Self-service: revocar key → desaparece
   - [ ] Self-service: cambiar modo IA BYOK ↔ Hosted
   - [ ] Self-service: ver plan y tokens
   - [ ] Legacy: ve solo tab "Mi cuenta" con datos de negocio read-only
   - [ ] Legacy: no ve tabs IA ni Plan

**Riesgos**: Mock de Supabase auth en tests — usar patrón existente del proyecto si hay, sino crear helper.

**Estado**: ⬜ Pendiente

---

### Resumen de archivos

| Archivo | Acción |
|---------|--------|
| `(protected)/configuracion/page.tsx` | Reescribir |
| `(protected)/configuracion/_components/TabNav.tsx` | Nuevo |
| `(protected)/configuracion/_components/AccountTab.tsx` | Nuevo |
| `(protected)/configuracion/_components/ChangePasswordForm.tsx` | Nuevo |
| `(protected)/configuracion/_components/AiTab.tsx` | Nuevo |
| `(protected)/configuracion/_components/ApiKeyCard.tsx` | Nuevo |
| `(protected)/configuracion/_components/AddApiKeyForm.tsx` | Nuevo |
| `(protected)/configuracion/_components/PlanTab.tsx` | Nuevo |
| `api/settings/profile/route.ts` | Nuevo |
| `api/settings/password/route.ts` | Nuevo |
| `api/settings/api-keys/route.ts` | Nuevo |
| `api/settings/api-keys/[id]/route.ts` | Nuevo |
| `api/settings/ai-mode/route.ts` | Nuevo |
| Tests (4 archivos) | Nuevo |

**Total**: 1 modificado, ~13 nuevos. Sin migraciones de DB. Sin dependencias nuevas.

### Cosas que NO se tocan

- Schema Prisma (no se necesitan migraciones)
- Middleware (la ruta ya está protegida)
- TopBar (el link ya existe)
- Onboarding (flujo separado)
- Admin backoffice (fuera de alcance)
- Stripe (Plan tab es read-only)
- TeamInvite (futuro)
- Upload de avatar (se edita URL, upload requiere storage — futuro)

---

*Última actualización: 2026-03-13*

---

## Feature: Entrevista Conversacional con IA — Stage 1

**Objetivo**: Reemplazar el cuestionario estático por una entrevista conversacional donde la IA genera preguntas dinámicamente, adapta el flujo según respuestas, y produce un Brief Estratégico estructurado que sirve como herramienta de toma de decisiones comunicacionales para todas las etapas siguientes.

**Rama**: `claude/debug-interview-loading-dpat6`

**Filosofía**: La entrevista es consultoría guiada, no extracción de datos. La IA asesora sobre posicionamiento (bajo costo / diferenciación / enfoque en nicho), desafía respuestas genéricas, y construye valor real para la empresa del cliente. El brief resultante es el sistema operativo de todo el proyecto.

### Decisiones de diseño

1. **`interviewPrompt` vuelve a ser texto** — instrucciones para la IA (personalidad + checklist de temas), no un JSON de preguntas
2. **`flowDefinition` se construye dinámicamente** — arranca vacío, se agregan QuestionBlocks a medida que la IA genera preguntas
3. **La IA decide la siguiente pregunta** basándose en respuestas anteriores y temas pendientes
4. **La IA decide cuándo tiene suficiente info** — no hay un número fijo de preguntas
5. **El output es un `StrategicBrief` tipado** — estructura que las etapas 2-6 consumen como input
6. **Navegación hacia atrás**: se permite para revisar, pero editar una respuesta anterior invalida las preguntas subsiguientes (se regeneran)
7. **El SDK de Anthropic** se agrega como dependencia del portal (`@anthropic-ai/sdk`, ya usado en telegram-bot)
8. **La API key se lee de `ANTHROPIC_API_KEY`** env var en Vercel (mismo patrón que telegram-bot)

### Checklist de información obligatoria (lo que la IA debe obtener)

**Nivel 1 — Hechos del negocio** (el cliente sabe y puede contar):
- Qué hace: producto/servicio concreto, estado (operando / por lanzar / pivoteando)
- Dónde opera: zona geográfica, alcance real
- A quién le vende: perfil del cliente actual o deseado
- Cómo le llega el cliente hoy: canal de adquisición principal
- Qué cobra: rango de precios, ticket promedio
- Contra quién compite: competidores directos en su zona/nicho
- Con qué recursos cuenta: presupuesto, equipo, tiempo, materiales
- Qué restricciones tiene: cosas que no puede o no quiere hacer

**Nivel 2 — Análisis estratégico** (la IA infiere y propone):
- Posicionamiento competitivo: bajo costo, diferenciación, o enfoque en nicho
- Oportunidad de ser primero: ¿hay un espacio vacío en su mercado/zona?
- Ventaja sostenible: ¿qué tiene que la competencia no puede copiar fácil?
- Brecha entre lo que es y lo que podría ser

---

### Etapa I1: Prompt del Estratega + tipo StrategicBrief

**Archivos**:
- `packages/db/prisma/seed.ts` — revertir interviewPrompt agente 1 a texto (instrucciones + checklist)
- `apps/portal/app/_lib/interview/types.ts` — agregar tipo `StrategicBrief`

**Qué se hace**:
1. Redefinir `interviewPrompt` del agente 1 como prompt de sistema para Claude:
   - Personalidad: El Estratega — directo, honesto, no complaciente, con visión de negocio
   - Formato de output: debe devolver un QuestionBlock JSON para renderizar en la UI
   - Checklist de temas obligatorios del Nivel 1 (la IA marca internamente qué cubrió)
   - Instrucciones de análisis del Nivel 2 (posicionamiento, oportunidad, ventaja)
   - Señal de cierre: tool call `interview_complete` cuando tiene toda la info necesaria
   - Instrucciones anti-complacencia: no aceptar "calidad" como diferencial sin profundizar
2. Definir `StrategicBrief`:
   ```typescript
   type StrategicBrief = {
     negocio: {
       descripcion: string       // Qué hace, en una oración
       estado: 'operando' | 'lanzamiento' | 'pivoteando'
       antiguedad: string | null // "3 años" o null si no aplica
       recursosDisponibles: string
     }
     mercado: {
       zonaGeografica: string
       alcance: string
       competidores: Array<{ nombre: string; fortaleza: string; debilidad: string }>
       espaciosVacios: string[]   // Oportunidades detectadas
     }
     audiencia: {
       perfilCliente: string
       comoCompra: string
       dolorPrincipal: string
     }
     posicionamiento: {
       estrategia: 'bajo_costo' | 'diferenciacion' | 'enfoque'
       nichoEspecifico: string
       ventajaCompetitiva: string
       riesgos: string[]
       justificacion: string     // Por qué la IA recomienda esta estrategia
     }
     direccionComunicacional: {
       mensajeCentral: string    // Una frase
       tonoSugerido: string
       queNoDecir: string[]
       territoriosTematicos: string[]
     }
     decisionesPendientes: Array<{
       tema: string
       opciones: Array<{ opcion: string; pro: string; contra: string }>
     }>
   }
   ```

**Cómo verificar**: TypeScript compila, tipo es coherente con la estructura acordada
**Riesgos**: El prompt necesitará iteración después de probar con Claude real
**Estado**: ⬜ Pendiente

---

### Etapa I2: Endpoint de generación de próxima pregunta

**Archivos**:
- `apps/portal/app/api/interview/sessions/[id]/next-question/route.ts` — NUEVO
- `apps/portal/app/_lib/interview/ai-interviewer.ts` — NUEVO
- `apps/portal/package.json` — agregar `@anthropic-ai/sdk`

**Qué se hace**:
1. Agregar `@anthropic-ai/sdk` al portal
2. Crear `ai-interviewer.ts` — módulo core:
   - `generateNextQuestion(systemPrompt, qaPairs, coveredTopics)`:
     - Construye mensajes para Claude: system prompt + historial Q&A
     - Usa tool_use con dos tools:
       - `ask_question`: devuelve un QuestionBlock (id, question, inputType, options, etc.)
       - `interview_complete`: señala que tiene toda la info, devuelve summary + coveredTopics
     - Parsea y valida la respuesta
     - Retorna `{ type: 'question', question: QuestionBlock }` o `{ type: 'complete', summary: string }`
   - Modelo: `claude-sonnet-4-6` (balance costo/calidad para entrevistas)
   - Max tokens: 1024 (una pregunta no necesita más)

3. Crear endpoint `POST /api/interview/sessions/[id]/next-question`:
   - Auth + ownership verification (mismo patrón que advance route)
   - Valida que la sesión está en IN_PROGRESS
   - Lee AgentConfig para obtener interviewPrompt
   - Arma historial Q&A desde `answers` + `flowDefinition`
   - Llama a `generateNextQuestion()`
   - Si devuelve pregunta:
     - Append a `flowDefinition` (Prisma JSON update)
     - Incrementa `totalSteps`
     - Retorna `{ type: 'question', question, step: newIndex }`
   - Si devuelve complete:
     - Guarda summary en `contextSummary`
     - Retorna `{ type: 'complete', summary }`

**Cómo verificar**: Llamar endpoint manualmente con curl/Postman, verificar que Claude genera preguntas adaptativas
**Riesgos**:
- Latencia: 2-5s por llamada a Claude → UI necesita loading state
- `ANTHROPIC_API_KEY` debe estar en env vars de Vercel
- Claude podría generar inputTypes no soportados por el UI → validar contra InputType union
**Estado**: ⬜ Pendiente

---

### Etapa I3: Adaptar cliente para flujo conversacional

**Archivos**:
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx` — modificar
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/NavigationButtons.tsx` — modificar
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/ThinkingIndicator.tsx` — NUEVO

**Qué se hace**:
1. `ThinkingIndicator.tsx`: Componente visual "El Estratega está pensando..." con animación sutil (no un spinner genérico, sino algo que sugiera que la IA está analizando)

2. Modificar `client.tsx` — flujo principal:
   - Al iniciar (NOT_STARTED → start): llamar `next-question` para obtener la primera pregunta
   - Después de guardar cada respuesta (PATCH /answer success):
     - Si es la última pregunta respondida (currentStep === flowDefinition.length - 1):
       - Mostrar ThinkingIndicator
       - Llamar `POST /next-question`
       - Si devuelve question → agregar a flowDefinition local, avanzar currentStep
       - Si devuelve complete → mostrar resumen del análisis con botón "Generar brief"
     - Si no es la última (el usuario está navegando hacia atrás): avanzar normal sin llamar a la IA
   - Al hacer "back": navegar normal (la pregunta ya existe en flowDefinition)
   - Al hacer "next" en pregunta ya existente: avanzar sin llamar IA

3. Modificar `NavigationButtons.tsx`:
   - El botón "Enviar respuestas" se reemplaza por "Generar brief" y solo aparece cuando la IA señaló `complete`
   - Mientras la IA está generando la siguiente pregunta, deshabilitar navegación

4. Edición de respuestas anteriores:
   - Si el usuario navega atrás y modifica una respuesta, las preguntas subsiguientes se invalidan
   - Al avanzar desde esa pregunta editada, se vuelve a llamar next-question (regenera el flujo desde ese punto)
   - Se trunca flowDefinition desde el punto editado

**Cómo verificar**: Flujo completo en browser — la IA adapta preguntas al contexto
**Riesgos**:
- UX de espera entre preguntas: ~3s puede sentirse lento → el ThinkingIndicator debe ser informativo
- Editar respuesta y regenerar puede ser confuso → agregar copy explicativo
**Estado**: ⬜ Pendiente

---

### Etapa I4: Generación del Brief Estratégico (processing)

**Archivos**:
- `apps/portal/app/api/interview/sessions/[id]/process/route.ts` — NUEVO
- `apps/portal/app/_lib/interview/brief-generator.ts` — NUEVO
- `apps/portal/app/api/interview/sessions/[id]/advance/route.ts` — modificar submit

**Qué se hace**:
1. Crear `brief-generator.ts`:
   - `generateStrategicBrief(systemPrompt, allQAPairs, summary)`:
     - Llama a Claude con un prompt específico para análisis estratégico
     - Usa tool_use con tool `generate_brief` que tiene el schema de StrategicBrief
     - Modelo: `claude-sonnet-4-6` (necesita capacidad de análisis)
     - Max tokens: 4096 (el brief es largo y estructurado)
     - El prompt enfatiza: ser directo, no complaciente, identificar posicionamiento competitivo real
   - Retorna un StrategicBrief tipado

2. Crear endpoint `POST /api/interview/sessions/[id]/process`:
   - Valida que sesión está en PROCESSING
   - Lee AgentConfig + todas las Q&A
   - Llama a `generateStrategicBrief()`
   - Crea Deliverable:
     ```prisma
     prisma.deliverable.create({
       data: {
         organizationId: project.organizationId ?? project.teamId,
         projectId: session.projectId,
         teamId: session.teamId,
         stageId: session.stageId,
         type: 'BRIEF',
         title: `Brief Estratégico — ${projectName}`,
         content: strategicBrief, // JSON tipado
         version: 1,
         status: 'READY',
         isActive: true,
       }
     })
     ```
   - Actualiza InterviewSession: `status: 'COMPLETED'`, `completedAt: now()`
   - Si falla: `status: 'ERROR'`, `lastError`, `retryCount++`

3. Modificar `advance/route.ts` — después de poner PROCESSING:
   - Hacer un `fetch()` fire-and-forget al endpoint `/process` (no esperar respuesta)
   - El ProcessingScreen existente ya hace polling y detectará el cambio de status

**Cómo verificar**: Submit → processing → brief generado → Deliverable en DB → UI muestra completado
**Riesgos**:
- Timeout: Claude puede tardar 15-30s para un brief completo → Vercel function timeout (default 10s en free, 60s en pro). Considerar si necesitan plan Pro de Vercel.
- El fire-and-forget puede fallar silenciosamente → agregar logging y manejo de errores robusto
**Estado**: ⬜ Pendiente

---

### Etapa I5: Visualización del Brief + aprobación

**Archivos**:
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/BriefView.tsx` — NUEVO
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx` — modificar pantalla COMPLETED

**Qué se hace**:
1. Crear `BriefView.tsx` — renderiza el StrategicBrief:
   - Secciones colapsables con headers claros:
     - **Tu Negocio**: descripción, estado, recursos
     - **Tu Mercado**: zona, competidores (tabla), espacios vacíos detectados
     - **Tu Cliente**: perfil, cómo compra, dolor principal
     - **Posicionamiento Recomendado** (destacado visualmente con borde morado):
       - Estrategia recomendada con justificación
       - Nicho específico identificado
       - Ventaja competitiva sostenible
       - Riesgos a considerar
     - **Dirección Comunicacional**: mensaje central (grande, destacado), tono, qué evitar, territorios
     - **Decisiones Pendientes**: cada una con opciones y pros/contras
   - Estilo consistente con el design system existente (dark theme, colores del proyecto)

2. Modificar pantalla COMPLETED en `client.tsx`:
   - Cargar Deliverable desde la DB (nuevo endpoint GET o incluir en session GET)
   - Renderizar BriefView con el contenido del Deliverable
   - Botón "Aprobar brief y avanzar" → actualiza Stage.status, habilita siguiente etapa
   - Botón "Solicitar cambios" → permite agregar feedback, dispara regeneración

**Cómo verificar**: Flujo end-to-end: entrevista → procesamiento → brief visible → aprobación
**Riesgos**: El diseño del BriefView necesita iteración visual
**Estado**: ⬜ Pendiente

---

### Etapa I6: Tests y QA

**Archivos**:
- `apps/portal/app/_lib/interview/__tests__/ai-interviewer.test.ts` — NUEVO
- `apps/portal/app/_lib/interview/__tests__/brief-generator.test.ts` — NUEVO
- `apps/portal/app/api/interview/sessions/[id]/next-question/__tests__/route.test.ts` — NUEVO

**Qué se hace**:
1. Tests unitarios con mock de Anthropic SDK:
   - ai-interviewer: mock de tool_use response, validación de QuestionBlock, señal de cierre
   - brief-generator: mock de respuesta, validación de StrategicBrief schema
   - next-question route: auth, ownership, estados válidos, append a flowDefinition
2. `pnpm --filter portal build` → sin errores
3. `pnpm test` → todo pasa
4. QA manual:
   - [ ] Primera pregunta se genera al iniciar entrevista
   - [ ] Preguntas se adaptan a respuestas anteriores
   - [ ] Si el usuario dice "estoy por lanzar", la IA no pregunta antigüedad
   - [ ] La IA desafía respuestas genéricas ("mi diferencial es la calidad")
   - [ ] La IA señala cierre cuando tiene suficiente info
   - [ ] El brief se genera correctamente con todas las secciones
   - [ ] El posicionamiento recomendado tiene justificación coherente
   - [ ] El brief se muestra visualmente en la UI
   - [ ] Aprobar brief habilita siguiente etapa
   - [ ] Back navigation funciona (review de preguntas anteriores)
   - [ ] Editar respuesta anterior regenera preguntas subsiguientes

**Estado**: ⬜ Pendiente

---

### Etapa I7: Revisión pre-producción por roles (docs/roles/)

Feature nueva importante → aplican los 6 roles en orden. Cada rol genera informe en `docs/reviews/`, se corrigen CRÍTICOS y ALTOS antes de pasar al siguiente.

#### Rol 1 — Code Reviewer (Tech Lead)

Foco específico para esta feature:
- [ ] `ai-interviewer.ts` y `brief-generator.ts` < 300 líneas cada uno
- [ ] Separación clara: módulo AI (sin HTTP) vs route (sin lógica AI)
- [ ] Todos los `catch` en llamadas a Claude manejan errores descriptivamente (no catch vacío)
- [ ] Promesas de Anthropic SDK tienen manejo de error explícito
- [ ] Nombres descriptivos: no `data`, `result`, `response` genéricos
- [ ] Código nuevo sigue patrones existentes del proyecto (advance route como referencia)
- [ ] No hay `console.log` de debug ni `any` en tipos

#### Rol 2 — QA Engineer

Foco específico para esta feature:
- [ ] ¿Qué pasa si Claude devuelve JSON inválido o mal formado?
- [ ] ¿Qué pasa si Claude devuelve un inputType no soportado por QuestionCard?
- [ ] ¿Qué pasa si la API key es inválida o la cuota está agotada?
- [ ] ¿Qué pasa si el usuario cierra el browser a mitad de entrevista y vuelve?
- [ ] ¿Qué pasa con respuestas extremadamente largas (5000+ chars)?
- [ ] ¿Qué pasa con respuestas vacías en preguntas skippable?
- [ ] ¿Qué pasa si el usuario hace doble click en "Siguiente" mientras la IA está generando?
- [ ] ¿Qué pasa si Claude decide que la entrevista está completa con solo 3 preguntas?
- [ ] ¿El brief se genera correctamente con datos de distintas industrias?
- [ ] ¿Los textos de la UI están en español argentino natural?
- [ ] ¿El ThinkingIndicator desaparece correctamente al recibir respuesta?

#### Rol 3 — Security Auditor

Foco específico para esta feature:
- [ ] `ANTHROPIC_API_KEY` NUNCA se expone al cliente (solo server-side)
- [ ] Rate limiting en `/next-question` para prevenir abuso de API (costos)
- [ ] Validar output de Claude antes de guardar en DB (la IA podría generar contenido inesperado)
- [ ] El contenido generado por IA que se renderiza en el UI se escapa correctamente (prevenir XSS vía output de Claude)
- [ ] El endpoint `/process` valida ownership de la sesión (no procesar sesión ajena)
- [ ] No se loguean datos sensibles del negocio del usuario en los logs
- [ ] El fire-and-forget a `/process` no puede ser disparado externamente sin auth
- [ ] Validación de UUID en params antes de queries a DB

#### Rol 4 — Performance Engineer

Foco específico para esta feature:
- [ ] Latencia de Claude API (2-5s por pregunta) → UX aceptable con ThinkingIndicator
- [ ] No llamar a Claude innecesariamente (si el usuario navega back/forward sin editar, no regenerar)
- [ ] Timeout de Vercel function para `/process` (brief generation ~15-30s) → ¿necesita plan Pro?
- [ ] El historial Q&A crece en cada llamada → verificar que el payload a Claude no sea excesivo en entrevistas largas (>15 preguntas)
- [ ] No hacer N+1: cargar AgentConfig + sesión en una sola query o Promise.all
- [ ] ProcessingScreen polling con jitter (ya implementado) → verificar que sigue funcionando

#### Rol 5 — DevOps / SRE

Foco específico para esta feature:
- [ ] `ANTHROPIC_API_KEY` configurada en env vars de Vercel (no solo en .env local)
- [ ] Logging de llamadas a Claude: timestamp, sessionId, modelo, tokens usados, latencia (para tracking de costos)
- [ ] Si Claude API está caída, el error es descriptivo para el usuario ("El servicio está temporalmente no disponible. Tus respuestas están guardadas.")
- [ ] Timeout configurable para llamadas a Claude (no hardcodeado)
- [ ] Reintentos con backoff para errores transient de Claude (429, 529)
- [ ] El endpoint `/process` tiene manejo de timeout de Vercel (si se corta, el status queda en PROCESSING → necesita mecanismo de recuperación o timeout checker)
- [ ] Health check: verificar que ANTHROPIC_API_KEY es válida al inicio

#### Rol 6 — Product Reviewer (UX)

Foco específico para esta feature:
- [ ] ¿El usuario entiende que está hablando con una IA estratega, no llenando un formulario?
- [ ] ¿La espera de 2-5s entre preguntas es aceptable? ¿El ThinkingIndicator comunica bien qué está pasando?
- [ ] ¿El brief es entendible para un dueño de PyME no técnico?
- [ ] ¿La recomendación de posicionamiento es clara y accionable?
- [ ] ¿Las "Decisiones pendientes" del brief tienen opciones claras con pros/contras?
- [ ] ¿El usuario puede guardar y volver después? (PAUSED funciona con el flujo nuevo)
- [ ] ¿El copy del ThinkingIndicator es natural en español argentino?
- [ ] ¿El botón "Generar brief" deja claro que es el paso final?
- [ ] ¿Después de aprobar el brief, el usuario sabe qué sigue?
- [ ] ¿Si la IA dice algo que el usuario no entiende, hay forma de pedir aclaración?

**Proceso**: Ejecutar los 6 roles en orden. Para cada uno: revisar, reportar en `docs/reviews/`, corregir CRÍTICOS y ALTOS, pasar al siguiente.

**Estado**: ⬜ Pendiente

---

### Cosas que NO se tocan

- Stages 2-6 (mantienen flujo estático por ahora)
- IndustryTemplate / merge-flow (se mantiene para otros stages, Stage 1 lo bypasea)
- Admin panel
- Schema Prisma (los campos existentes de InterviewSession cubren todo)
- Autenticación / RLS
- Email notifications
- FeedbackForm

### Dependencias nuevas

- `@anthropic-ai/sdk` en `apps/portal/package.json` (misma versión que telegram-bot: ^0.78.0)
- `ANTHROPIC_API_KEY` en env vars de Vercel

### Resumen de archivos

| Archivo | Acción |
|---------|--------|
| `apps/portal/package.json` | Modificar (agregar SDK) |
| `packages/db/prisma/seed.ts` | Modificar (interviewPrompt agente 1) |
| `apps/portal/app/_lib/interview/types.ts` | Modificar (agregar StrategicBrief) |
| `apps/portal/app/_lib/interview/ai-interviewer.ts` | Nuevo |
| `apps/portal/app/_lib/interview/brief-generator.ts` | Nuevo |
| `apps/portal/app/api/interview/sessions/[id]/next-question/route.ts` | Nuevo |
| `apps/portal/app/api/interview/sessions/[id]/process/route.ts` | Nuevo |
| `apps/portal/app/api/interview/sessions/[id]/advance/route.ts` | Modificar (trigger process) |
| `apps/portal/app/proyectos/.../interview/client.tsx` | Modificar (flujo conversacional) |
| `apps/portal/app/proyectos/.../interview/_components/NavigationButtons.tsx` | Modificar |
| `apps/portal/app/proyectos/.../interview/_components/ThinkingIndicator.tsx` | Nuevo |
| `apps/portal/app/proyectos/.../interview/_components/BriefView.tsx` | Nuevo |
| Tests (3 archivos) | Nuevo |

**Total**: 5 modificados, 8 nuevos.

*Última actualización: 2026-03-14*

---

## Feature: Stitch como "Fábrica de Templates" — Integración híbrida

**Objetivo**: Integrar Google Stitch en Qautiva con enfoque híbrido: (1) operadores del backoffice usan Stitch para crear templates base por rubro iterando con prompts, y (2) en el onboarding del cliente, Stitch personaliza el template elegido con datos de su marca. Reemplaza la creación manual de HTML+CSS por generación asistida por IA, manteniendo el pipeline existente de Handlebars como fallback.

**Rama**: `claude/stitch-template-factory-s9q7t`

### Contexto técnico

- **Templates actuales**: `WebTemplate` con `htmlBase` (HTML + Handlebars `{{variables}}`), `css`, `sections`, `variables`. El `website-generator.ts` genera copy con LLM y lo aplica con Handlebars via `applyWebsiteCopy()`.
- **Stitch SDK**: `@google/stitch-sdk` — crear proyectos, generar screens desde prompts, editar screens, generar variantes, obtener HTML/screenshots. Auth via `STITCH_API_KEY`.
- **DESIGN.md**: Stitch soporta un archivo DESIGN.md para mantener consistencia de diseño. Qautiva no tiene uno — hay que crearlo.
- **Flujo actual de personalización**: `buildTemplateContext()` arma variables → Handlebars compila `htmlBase` → inyecta copy generado por LLM. Secciones activas vienen de `WebTemplate.sections` (v1) o respuestas del usuario (v2).

### Decisiones de arquitectura (ADR requerido — escribir ADR-0022 ANTES de S2)

1. **Nuevo package `packages/stitch`**: Encapsula toda interacción con Stitch SDK. Aísla al resto del codebase del SDK experimental.
2. **Stitch genera HTML, Prisma es la fuente de verdad**: Stitch produce `htmlBase` + `css` + `thumbnail`, que se persisten en `WebTemplate`. La DB manda, Stitch es herramienta.
3. **Dos flujos sobre el mismo package**: "Crear template" (admin) y "Personalizar template" (portal). Mismas funciones del SDK, distinto contexto.
4. **DESIGN.md como constante embebida**: Los tokens de diseño se mantienen en `docs/DESIGN.md` como documentación, pero se embeben como string constante en `design-context.ts` (NO `fs.readFileSync` — falla en Vercel serverless).
5. **Templates manuales intactos**: Todo template con `source: MANUAL` sigue funcionando exactamente igual. Stitch es aditivo, no reemplaza.
6. **Bridge HTML siempre obligatorio**: Al guardar un template Stitch, el procesamiento Handlebars se aplica SIEMPRE automáticamente (sin toggle opcional). Esto garantiza que el fallback Handlebars funcione.
7. **Sanitización con DOMPurify**: El HTML de Stitch se sanitiza con `isomorphic-dompurify` (lista blanca, no lista negra) antes de guardar. NO sanitizar con regex manual — es insuficiente y quebrable. Stitch + `noEscape: true` en Handlebars = riesgo XSS real. Además, escapar `{{` y `}}` literales del HTML de Stitch antes de inyectar placeholders propios para prevenir Handlebars injection.
11. **Iframes con sandbox restrictivo**: Todos los iframes que muestren HTML de Stitch (admin y portal) deben usar `sandbox="allow-scripts"` (sin `allow-same-origin`). Fix previo requerido: cambiar `TemplateSelectionClient.tsx` de `sandbox="allow-same-origin"` a `sandbox="allow-scripts"`.
12. **Privacidad de datos**: Los datos del cliente (nombre del negocio, servicios, colores) se envían a la API de Google via Stitch. Documentar en ADR-0022. Revisar ToS de Stitch antes de producción. No endpoint HTTP de Stitch expuesto al browser del portal — toda personalización es server-side.
13. **Versión exacta del SDK**: Usar versión exacta de `@google/stitch-sdk` (no `^`), correr `npm audit` en CI.

### Ajustes post-merge de main (2026-03-19)

> Main incorporó: billing completo (fases 1-7), roles y permisos (`checkTeamPermission`), stage activation, reorganización de docs/roles, migraciones 016-020, nuevos ADRs (0019-0021).

- **ADR renumerado**: ADR-0022 ya existe (billing). El ADR de Stitch es **ADR-0022**.
- **Billing guard**: `processSession()` ya llama `checkBillingEligibility()` antes de despachar a cualquier generator. Stitch hereda este guard automáticamente. NO agregar lógica de billing explícita en `stitch-personalizer.ts` — pasar el `BillingContext` que ya se construye en `processWebsiteSession()`.
- **Permission guard**: El endpoint `/process/route.ts` ya llama `checkTeamPermission(['ADMIN', 'OWNER'])`. Los endpoints de Stitch en admin deben replicar: auth → UUID validation → team ownership → permission check → billing → lock.
- **Stage activation**: `processSession()` verifica `stage.activation` (ACTIVE/SKIP/PROVIDED_BY_CLIENT) antes de llamar generators. Stitch hereda esto.
- **Deliverable constraint**: Migración 019 agrega constraint de unicidad sobre deliverables activos por stage. La transacción de Stitch debe mantener el invariante `updateMany({ isActive: false })` antes del `create`.
- **Roles reorganizados**: docs/roles se dividió en `tech/` y `business/`. Las rutas en el review report ya no son válidas — actualizar si se corre revisión post-implementación.
- **`SECTION_KEYS` en `website-generator.ts`**: Si Stitch genera templates con secciones nuevas (ej: `testimonials`, `gallery`), agregarlas a `SECTION_KEYS` (línea 58-61) para que el LLM genere copy para ellas.
8. **Personalización async en portal**: La personalización con Stitch en el onboarding usa fire-and-forget + polling (mismo patrón que el brief), NO es sincrónica. Esto evita timeout de Vercel (10-30s).
9. **Reutilizar helpers existentes**: `stitch-personalizer.ts` reutiliza `buildInterviewContent()` y `buildTemplateContext()` de `website-generator.ts`. NO duplicar lógica de construcción de contexto.
10. **Plan de contingencia Stitch**: Si Google discontinúa Stitch, los templates existentes sobreviven porque `htmlBase` está en DB. La pérdida es solo la capacidad de generar/editar via Stitch. El equipo puede volver a crear templates manualmente. Documentado en ADR-0022.

### Correcciones post-revisión de roles

> Revisión completa en `docs/reviews/2026-03-19_plan-stitch-template-factory.md`

Se aplicaron correcciones a los siguientes hallazgos CRÍTICOS y ALTOS identificados por los 6 roles de revisión:

- **[CRÍTICO] XSS**: Sanitización con `isomorphic-dompurify`, no regex (decisión 7)
- **[CRÍTICO] fs.readFileSync en serverless**: DESIGN.md embebido como constante (decisión 4)
- **[CRÍTICO] Toggle Handlebars opcional → falla silenciosa**: Eliminado, procesamiento siempre automatorio (decisión 6)
- **[CRÍTICO] Stitch experimental sin plan**: Plan de contingencia documentado (decisión 10)
- **[CRÍTICO] Timeout Vercel en personalización**: Async con fire-and-forget + polling (decisión 8)
- **[ALTO] Duplicación de lógica**: Reutilizar helpers existentes (decisión 9)
- **[ALTO] STITCH_API_KEY sin documentar**: Agregar a `.env.example` en S2
- **[ALTO] Sin logging de Stitch**: Logging obligatorio en `packages/stitch`
- **[ALTO] Auth en Route Handlers**: Patrón explícito (ver S5)
- **[ALTO] Sin flujo de rechazo del cliente**: Decisión explícita de scope (ver S6)
- **[ALTO] Bridge HTML puede fallar**: Validación + advertencia al operador (ver S4)
- **[CRÍTICO-QA] Fallback Handlebars sin validar compilación**: Validar `Handlebars.compile(htmlBase)` antes de guardar como ACTIVE (ver S4)
- **[CRÍTICO-QA] `stitchScreenId` puede no existir en Stitch**: Verificar existencia antes de mostrar StitchEditor (ver S5)
- **[CRÍTICO-QA] Concurrencia sin lock en generación**: Lock optimista con `generatingAt` en WebTemplate (ver S5)
- **[ALTO-QA] brandKit parcial/null en personalización**: Manejar campos faltantes explícitamente (ver S6)
- **[ALTO-QA] Bifurcación MANUAL/STITCH debe estar en `processWebsiteSession`**: No modificar `applyWebsiteCopy()` (ver S6)
- **[ALTO-QA] Generación en admin sync vs async no definida**: Definir explícitamente (ver S5)
- **[CRÍTICO-SEC] `TemplateSelectionClient.tsx` iframe con `allow-same-origin`**: Cambiar a `sandbox=""` o `sandbox="allow-scripts"` — vector XSS activo con templates Stitch (fix existente, no nuevo)
- **[ALTO-SEC] Datos del cliente enviados a Google sin mención en ToS**: Documentar en ADR-0022 que brandKit/businessData se envían a API de Google. Revisar ToS de Stitch.
- **[ALTO-SEC] Sin rate limiting explícito en pipeline Stitch del portal**: Confirmar que el rate limiting del `advance` route protege suficientemente
- **[MEDIO-SEC] Handlebars injection via `{{}}` en HTML de Stitch**: Escapar `{{` y `}}` literales antes de inyectar placeholders propios
- **[MEDIO-SEC] `generateVariants` sin límite de `count`**: Max 5 variantes
- **[BAJO-SEC] iframe de admin sin sandbox explícito en el plan**: Especificar `sandbox="allow-scripts"` en StitchGenerator y StitchEditor
- **[BAJO-SEC] `@google/stitch-sdk` sin versión pinneada**: Usar versión exacta, no `^`
- **[CRÍTICO-PERF] ProcessingScreen mensajes hardcodeados para BRIEF**: Agregar mensajes específicos para WEBSITE+Stitch (ver S6)
- **[ALTO-PERF] Routes de admin Stitch sin `maxDuration`**: Agregar `export const maxDuration = 120` (ver S5)
- **[ALTO-PERF] Sin timeout explícito en llamadas al SDK**: Agregar AbortSignal con 60s (ver S2)
- **[MEDIO-PERF] Download HTML + screenshot secuenciales**: Usar `Promise.all()` (ver S2)

---

### Etapa S1: DESIGN.md — Sistema de diseño para Stitch

**Archivos**:
- `docs/DESIGN.md` — NUEVO

**Qué se hace**:
1. Crear `docs/DESIGN.md` basado en tokens existentes de `packages/ui/tokens.ts` y `ARCHITECTURE.md`:
   - Paleta: dark mode (zinc-950 fondo, zinc-900 cards, amber-400 acento, emerald-400 éxito, violet-500 interactivo)
   - Tipografías: Inter (body), Plus Jakarta Sans (headings)
   - Espaciado, border-radius, sombras
   - Reglas de layout: responsive breakpoints, max-widths
   - Tono visual: dark, profesional, tech-forward
   - Instrucciones explícitas para Stitch: "Usar Tailwind CSS", "Dark mode obligatorio", "Sin JavaScript inline", "data-section attributes en cada sección"
2. Este archivo se pasa como contexto en cada prompt a Stitch para garantizar consistencia on-brand.

**Cómo verificar**: Revisión manual del contenido. Debe ser coherente con `packages/ui/tokens.ts`.
**Riesgos**: Ninguno — es documentación.
**Estado**: ⬜ Pendiente

---

### Etapa S2: Package `packages/stitch` — Wrapper del SDK

**Archivos**:
- `packages/stitch/package.json`
- `packages/stitch/tsconfig.json`
- `packages/stitch/src/index.ts` — re-exports
- `packages/stitch/src/client.ts` — singleton autenticado
- `packages/stitch/src/types.ts` — tipos internos
- `packages/stitch/src/generate-template.ts` — generar template base
- `packages/stitch/src/personalize-template.ts` — personalizar template con datos de marca
- `packages/stitch/src/design-context.ts` — carga DESIGN.md como contexto de prompt
- `packages/stitch/src/__tests__/generate-template.test.ts`
- `packages/stitch/src/__tests__/personalize-template.test.ts`

**Qué se hace**:
1. `client.ts`: Singleton que inicializa `stitch` con `STITCH_API_KEY` del env. Funciones:
   - `getOrCreateProject(title: string): Promise<Project>` — crea proyecto en Stitch
   - `getProject(projectId: string): Project` — referencia sin API call

2. `design-context.ts`:
   - `DESIGN_CONTEXT: string` — constante embebida con el contenido de `docs/DESIGN.md` (NO `fs.readFileSync` — falla en Vercel serverless)
   - `getDesignContext(): string` — retorna la constante formateada como prefijo de prompt
   - Al actualizar `docs/DESIGN.md`, hay que actualizar también esta constante (script o nota en el archivo)

3. `generate-template.ts`:
   - `generateTemplate(params: GenerateTemplateParams): Promise<GenerateTemplateResult>`
   - Params: `{ industry: string, sections: string[], prompt: string, deviceType?: 'DESKTOP' | 'MOBILE' }`
   - Flujo: crea proyecto → genera screen con prompt + design context → descarga HTML + screenshot
   - Result: `{ html: string, css: string, thumbnailUrl: string, stitchProjectId: string, stitchScreenId: string }`
   - **Download HTML + screenshot en paralelo**: `const [html, screenshot] = await Promise.all([getHtml(), getImage()])`
   - **Timeout explícito**: `AbortSignal.timeout(60_000)` en todas las llamadas al SDK para evitar hangs silenciosos
   - Retry con backoff exponencial (2s, 4s, 8s) para errores transient (429, 503, timeout — NO reintentar 400/401/403)
   - **Logging obligatorio**: cada llamada loguea `{ timestamp, stitchProjectId, stitchScreenId, latencyMs, success: boolean, htmlSizeBytes, error? }`

4. `personalize-template.ts`:
   - `personalizeTemplate(params: PersonalizeParams): Promise<PersonalizeResult>`
   - Params: `{ stitchProjectId: string, stitchScreenId: string, brandKit: BrandKit, businessData: BusinessData, designContext: string }`
   - Flujo: obtiene screen → `screen.edit()` con prompt de personalización (colores, logo, copy, nombre) → descarga HTML actualizado
   - Usa `creativeRange: "REFINE"` para cambios conservadores (no reinventar el diseño)
   - Result: `{ html: string, css: string }`

5. `generate-variants.ts`:
   - `generateVariants(params: VariantParams): Promise<VariantResult[]>`
   - Params: `{ stitchProjectId: string, stitchScreenId: string, prompt: string, count?: number, aspects?: string[] }`
   - Usa `screen.variants()` del SDK
   - Result: array de `{ html, css, thumbnailUrl, screenId }`

6. `logger.ts`:
   - Logger centralizado para todas las llamadas a Stitch API
   - Formato: `{ timestamp, operation, stitchProjectId?, stitchScreenId?, latencyMs, success, htmlSizeBytes?, error? }`
   - Sin datos sensibles (no loguear prompts completos ni contenido HTML)

7. Tests con mock del SDK (patrón: vi.mock de `@google/stitch-sdk`).

8. Agregar `STITCH_API_KEY` a `.env.example` de raíz, admin y portal con instrucciones:
   ```
   # Google Stitch — generación de templates con IA
   # Obtener en: stitch.withgoogle.com → Profile → Stitch Settings → API Keys
   # Requerido en: admin (Railway) y portal (Vercel)
   STITCH_API_KEY=
   ```

**Cómo verificar**: `pnpm --filter stitch test`
**Riesgos**:
- SDK experimental — puede cambiar API. Mitigación: wrapper aísla cambios a un solo package.
- Rate limits no documentados. Mitigación: retry + logging de respuestas.
- Latencia 10-30s por generación. Mitigación: fire-and-forget + polling (patrón existente en el proyecto).
**Estado**: ⬜ Pendiente

---

### Etapa S3: Schema — Campos Stitch en WebTemplate

**Archivos**:
- `packages/db/prisma/schema.prisma` — agregar campos y enum
- Nueva migración Prisma

**Qué se hace**:
1. Crear enum `WebTemplateSource`:
   ```prisma
   enum WebTemplateSource {
     MANUAL   // HTML escrito a mano (flujo actual)
     STITCH   // Generado con Google Stitch
   }
   ```

2. Agregar campos a `WebTemplate`:
   ```prisma
   source            WebTemplateSource @default(MANUAL)
   stitchProjectId   String?           // ID del proyecto en Stitch (para re-editar)
   stitchScreenId    String?           // ID del screen principal
   generationPrompt  String?  @db.Text // Prompt usado para generar (reproducibilidad)
   generatingAt      DateTime?         // Lock optimista para generación concurrente (2 min TTL)
   ```

3. Migración no-destructiva: todos los campos nuevos son nullable o tienen default. Templates existentes quedan como `source: MANUAL` automáticamente.

**Cómo verificar**: `pnpm db:generate` + `pnpm db:migrate` sin errores. Queries existentes no afectadas.
**Riesgos**: Mínimos — migración aditiva. No rompe datos existentes.
**Estado**: ⬜ Pendiente

---

### Etapa S4: Bridge HTML — Post-procesamiento Stitch → Handlebars

**Archivos**:
- `packages/stitch/src/html-processor.ts` — NUEVO
- `packages/stitch/src/__tests__/html-processor.test.ts` — NUEVO

**Dependencia nueva**: `isomorphic-dompurify` (sanitización HTML probada, funciona en Node.js)

**Qué se hace**:
1. `sanitizeStitchHtml(rawHtml: string): string`
   - Usa `isomorphic-dompurify` para sanitizar el HTML de Stitch
   - Remueve: `<script>`, event handlers (`onclick`, `onerror`, etc.), `javascript:` URIs, tracking pixels, scripts de terceros
   - Permite: HTML semántico, CSS inline, `data-*` attributes, imágenes con URLs seguras
   - Se ejecuta ANTES del procesamiento de secciones

2. `escapeHandlebarsLiterals(html: string): string`
   - Escapa `{{` y `}}` literales que vengan del HTML de Stitch (no los que inyecta el bridge)
   - Previene Handlebars injection: si Stitch genera `{{#if admin}}secreto{{/if}}`, no se ejecuta

3. `processStitchHtml(rawHtml: string, targetSections: string[]): ProcessedHtml`
   - Primero sanitiza con `sanitizeStitchHtml()`
   - Luego escapa Handlebars literales con `escapeHandlebarsLiterals()`
   - Identifica secciones por `data-section` attributes (el prompt a Stitch instruye usarlos)
   - Inyecta placeholders Handlebars en puntos clave:
     - Título principal → `{{hero_title}}`
     - Subtítulo → `{{hero_subtitle}}`
     - Nombre del negocio → `{{business_name}}`
     - Secciones de servicios → `{{#each services}}...{{/each}}`
     - Textos de sección → `{{about_text}}`, `{{pricing_title}}`, etc.
   - Extrae variables detectadas para guardar en `WebTemplate.variables`
   - **Validación**: verifica que al menos 1 placeholder Handlebars fue inyectado. Si no → retorna `{ success: false, reason: 'no_sections_detected' }`
   - Retorna `{ success: true, processedHtml: string, extractedVariables: Record<string, string>, detectedSections: Record<string, boolean> }` o `{ success: false, reason: string }`

3. Si la detección falla (`success: false`):
   - El admin muestra advertencia al operador: "No se pudieron detectar las secciones automáticamente. Podés editar el HTML manualmente o regenerar con un prompt más específico."
   - El operador puede: editar en TabCodigo (existente), re-generar con prompt más explícito, o mapear secciones manualmente
   - **NO se permite guardar un template sin al menos `{{business_name}}`** — el fallback Handlebars necesita al menos eso

4. `validateHandlebarsCompilation(processedHtml: string, sampleVariables: Record<string, string>): { valid: boolean, error?: string }`
   - Intenta `Handlebars.compile(processedHtml)(sampleVariables)` con datos de ejemplo
   - Si falla → retorna `{ valid: false, error: "El HTML procesado no compila correctamente con Handlebars: {error}" }`
   - Se ejecuta antes de permitir guardar como `status: ACTIVE` — un template con Handlebars inválido no puede activarse
   - Esto garantiza que el fallback Handlebars siempre funcione para templates guardados

5. Tests con HTML de ejemplo simulando output de Stitch (con y sin `data-section`, HTML vacío, HTML sin `</body>`, HTML en inglés).

**Cómo verificar**: `pnpm --filter stitch test` — tests de procesamiento, sanitización, y validación
**Riesgos**:
- HTML de Stitch es variado — la detección heurística puede fallar. Mitigación: prompt instruye estructura, validación bloquea guardado sin placeholders, operador puede ajustar manualmente.
- XSS mitigado por DOMPurify (no regex manual).
**Estado**: ⬜ Pendiente

---

### Etapa S5: Backoffice — UI de generación de templates con Stitch

**Archivos**:
- `apps/admin/app/(protected)/templates/nuevo/page.tsx` — NUEVO: página de creación
- `apps/admin/app/(protected)/templates/nuevo/_components/StitchGenerator.tsx` — NUEVO: client component
- `apps/admin/app/(protected)/templates/[id]/editar/_components/StitchEditor.tsx` — NUEVO: editor via Stitch
- `apps/admin/app/api/stitch/generate/route.ts` — NUEVO: endpoint generación
- `apps/admin/app/api/stitch/edit/route.ts` — NUEVO: endpoint edición
- `apps/admin/app/api/stitch/variants/route.ts` — NUEVO: endpoint variantes
- Tests correspondientes

**Qué se hace**:
1. **`StitchGenerator.tsx`** — Formulario + preview:
   - Select de industria (catálogo existente de `compatibleIndustries`)
   - Checkboxes de secciones (`hero`, `about`, `services`, `pricing`, `contact`, etc.)
   - Textarea de prompt libre con sugerencias por industria
   - Botón "Generar con Stitch" → loading state → preview en iframe con `sandbox="allow-scripts"` (sin `allow-same-origin`)
   - Botón "Generar variantes" (3 opciones lado a lado)
   - Botón "Editar con prompt" (refinar resultado actual)
   - Botón "Guardar como template" → aplica `processStitchHtml()` SIEMPRE antes de guardar → persiste en `WebTemplate` con `source: STITCH`
   - Si `processStitchHtml()` retorna `success: false` → mostrar advertencia, no guardar hasta que se resuelva
   - **Loading state informativo**: "Stitch está generando tu template, esto tarda entre 15 y 30 segundos" con tiempo estimado visible. Botón deshabilitado durante generación. Si tarda >45s → mostrar opción de cancelar.
   - Post-guardado: redirigir a `/templates/[id]` con banner "Template guardado. Podés editarlo o activarlo para clientes."

2. **`StitchEditor.tsx`** — Para templates Stitch existentes:
   - **Verificar existencia del screen en Stitch** antes de mostrar el editor. Si `stitchScreenId` ya no existe → mostrar mensaje: "El screen de Stitch asociado a este template ya no está disponible. Podés re-generarlo o editarlo manualmente en TabCodigo."
   - Preview del template actual
   - Campo de prompt para editar via `screen.edit()`
   - Botón "Aplicar cambios" → actualiza `htmlBase`, `css`, y `generationPrompt` (mantener reproducibilidad)
   - Mantiene `stitchProjectId` y `stitchScreenId` para ediciones futuras

3. **API routes** (todos con auth explícita — NO asumir que `requireAdminSession()` funciona en Route Handlers):
   - `export const maxDuration = 120` en todos los routes de Stitch (Stitch tarda 10-30s, default de 10s en Hobby falla)
   - Patrón de auth: `createSupabaseServerClient(cookies()) → getUser() → verificar role === 'ADMIN'` (verificar compatibilidad con Route Handler context)
   - `POST /api/stitch/generate`: **async con polling** — inicia generación, retorna `{ jobId }`, el admin hace polling hasta que el resultado esté listo. Esto evita timeout de Vercel/Railway para generaciones de 10-30s. Mismo patrón que `/process` del brief.
   - **Lock optimista**: antes de generar, verificar que no haya otra generación en curso para el mismo template (campo `generatingAt` nullable en `WebTemplate`, lock de 2 min como `InterviewSession.processingStartedAt`)
   - `POST /api/stitch/edit`: llama `personalizeTemplate()` con prompt de edición (async)
   - `POST /api/stitch/variants`: llama `generateVariants()` → retorna array de opciones (async). **Máximo 5 variantes** — rechazar `count > 5` con 400.
   - Al guardar: `prisma.webTemplate.create()` con `source: 'STITCH'`, IDs de Stitch, prompt, `status: DRAFT` (NO ACTIVE inmediatamente — requiere activación explícita del operador)
   - Validación pre-activación: `validateHandlebarsCompilation()` pasa antes de permitir `status: ACTIVE`

**Cómo verificar**:
- `pnpm --filter admin build` sin errores
- Test manual: crear template → preview → guardar → verificar en DB
- Tests unitarios de API routes con mock de Stitch
**Riesgos**:
- Latencia de Stitch (10-30s). Mitigación: loading state claro, fire-and-forget si es viable.
- El HTML generado puede requerir ajustes manuales. Mitigación: TabCodigo ya existe para edición manual.
**Estado**: ✅ Completado

---

### Etapa S6: Portal — Personalización con Stitch en onboarding

**Archivos**:
- `apps/portal/app/_lib/interview/stitch-personalizer.ts` — NUEVO
- `apps/portal/app/_lib/interview/website-generator.ts` — MODIFICAR
- `apps/portal/app/_lib/interview/session-processor.ts` — MODIFICAR (case WEBSITE)
- Tests correspondientes

**Qué se hace**:
1. **`stitch-personalizer.ts`**:
   - `personalizeWithStitch(webTemplate, brandKit, businessData, answers): Promise<{ html, css }>`
   - Solo aplica si `webTemplate.source === 'STITCH'` y tiene `stitchProjectId`
   - **Reutiliza** `buildInterviewContent()` y `buildTemplateContext()` de `website-generator.ts` para construir el contexto (NO duplicar esta lógica)
   - Construye prompt de personalización a partir del contexto:
     - Colores del `brandKit` (primario, secundario, acento)
     - Logo URL del `brandKit`
     - Nombre del negocio, descripción, servicios
     - Copy generado por LLM (hero, about, etc.)
   - **Manejo de brandKit parcial/null**: si `logoUrl` es null → omitir del prompt. Si `primaryColor` falta → usar colores del DESIGN.md como fallback. Si brandKit completo es null (cliente no completó etapa BRAND) → usar solo datos de negocio + DESIGN.md (el template queda con los colores base).
   - Llama a `personalizeTemplate()` del package `stitch` con timeout de 30s
   - Retorna HTML/CSS personalizados

2. **Modificar `website-generator.ts`**: NO modificar `applyWebsiteCopy()` (para no romper tests existentes).

3. **Modificar `session-processor.ts`**:
   - La bifurcación MANUAL vs STITCH se hace en `processWebsiteSession()` (o equivalente en el case `WEBSITE`), ANTES de llamar a `applyWebsiteCopy()`:
     - Si `webTemplate.source === 'STITCH'` y tiene `stitchProjectId` → llamar a `personalizeWithStitch()` directamente
     - Si `source === 'MANUAL'` o no tiene `stitchProjectId` → flujo existente (`generateWebsiteCopy()` → `applyWebsiteCopy()`) sin cambios
   - Esto mantiene `applyWebsiteCopy()` intacta y evita regresiones
   - **La personalización Stitch es ASYNC**: usa el mismo patrón fire-and-forget + polling que el brief (PROCESSING → COMPLETED). NO es sincrónica — evita timeout de Vercel.
   - El `ProcessingScreen` existente ya hace polling y detectará el cambio de status.
   - **Mensajes de ProcessingScreen específicos para WEBSITE**: Los mensajes actuales están hardcodeados para BRIEF ("Evaluando posicionamiento..."). Agregar mensajes para `stageKey === 'WEBSITE'` (ej: "Diseñando tu sitio web...", "Aplicando tu marca al template...", "Generando la versión personalizada..."). Parametrizar desde el caller o agregar switch por stageKey.

4. **Fallback explícito**: Si Stitch falla (API down, timeout), se intenta el flujo Handlebars sobre el `htmlBase` guardado en DB. El template Stitch tiene `htmlBase` con Handlebars placeholders gracias al bridge obligatorio (Etapa S4).
   - **Visibilidad del fallback**: cuando se usa el fallback, se guarda `{ usedFallback: true }` en el metadata del Deliverable. El admin puede ver un badge "Personalización Stitch no disponible — se usó template base" en la ficha del cliente.

5. **Flujo de rechazo del cliente**: En esta iteración, el cliente NO puede pedir cambios al website personalizado por Stitch (mismo comportamiento que hoy con templates manuales). El flujo de iteración del website es scope de una iteración futura. **Decisión explícita documentada en ADR-0022.**

**Cómo verificar**:
- Tests unitarios con mock de Stitch SDK
- Test integración: crear template Stitch en admin → elegirlo en onboarding → verificar personalización
- Test fallback: simular Stitch caída → verificar que Handlebars funciona y badge de fallback aparece
- `pnpm --filter portal build`
**Riesgos**:
- Doble latencia: LLM copy (2-5s) + Stitch personalización (10-30s). Mitigación: async con polling, el usuario ve `ProcessingScreen` con progreso.
- Stitch es generativo, no determinístico — el resultado puede divergir del template base. Mitigación: `creativeRange: "REFINE"`.
- Si Stitch API está caída: el fallback Handlebars funciona porque el template tiene `htmlBase` procesado + badge visible en admin.
**Estado**: ⬜ Pendiente

---

### Etapa S7: Tests E2E y documentación final

**Archivos**:
- `docs/ARCHITECTURE.md` — MODIFICAR (sección integraciones + tabla 2.5 + env vars)
- `docs/claude-context/ESTADO-ACTUAL.md` — MODIFICAR
- `apps/admin/app/api/health/route.ts` — MODIFICAR (agregar verificación Stitch)
- `SESSION_LOG.md` — MODIFICAR
- Tests de integración

**Nota**: El ADR-0022 se escribe ANTES de S2 como prerequisito (ver Etapa S0 abajo).

**Qué se hace**:
1. **Tests de integración**:
   - Admin: crear template con Stitch → sanitizar → procesar HTML → validar placeholders → guardar → verificar campos en DB
   - Portal: elegir template Stitch → completar onboarding → verificar que personalización async genera HTML válido
   - Fallback: template `source: MANUAL` sigue funcionando idénticamente
   - Fallback: template Stitch con API caída → fallback a Handlebars + badge visible
2. **Health check**: Agregar verificación lightweight de Stitch API al health check de admin (listar proyectos o ping).
3. **Actualizar docs**:
   - ARCHITECTURE.md: nueva integración en tabla 2.5 (`Servicio=Google Stitch, Uso=Generación de templates, Riesgo=Alto (experimental/Labs), Fallback=Templates MANUAL + Handlebars`)
   - ARCHITECTURE.md: `STITCH_API_KEY` en sección de env vars
   - ESTADO-ACTUAL.md
4. `pnpm test` + `pnpm build` completo.

**Cómo verificar**: Todos los tests pasan. Build exitoso. Docs actualizados. Health check incluye Stitch.
**Riesgos**: Ninguno significativo.
**Estado**: ⬜ Pendiente

---

### Etapa S0: ADR y prerequisitos (ANTES de implementar)

**Archivos**:
- `docs/decisions/ADR-0022-stitch-template-factory.md` — NUEVO

**Qué se hace**:
0. **Fix de seguridad previo**: Cambiar `TemplateSelectionClient.tsx` línea 219: `sandbox="allow-same-origin"` → `sandbox="allow-scripts"`. Este iframe muestra HTML de templates — con templates Stitch (HTML generativo) el `allow-same-origin` es un vector XSS activo.
1. Escribir ADR-0022 con:
   - Decisión: integrar Google Stitch como fábrica de templates con enfoque híbrido
   - Alternativas: (a) 100% manual, (b) 100% Stitch, (c) híbrido (elegida)
   - Consecuencias: dependencia de servicio experimental, plan de contingencia
   - Plan de contingencia: si Stitch se discontinúa, templates existentes sobreviven en DB, se vuelve a creación manual
   - Scope explícito: flujo de rechazo del cliente sobre website NO incluido en esta iteración
   - Costos: Stitch API actualmente gratuita (Google Labs), puede cambiar
   - **Privacidad**: datos del cliente (nombre, servicios, colores) se envían a API de Google. Revisar ToS de Stitch y documentar si es compatible con Ley 25.326 (protección de datos personales Argentina)
2. Auditar `@google/stitch-sdk`: licencia, tamaño bundle, dependencias, compatibilidad serverless
3. Agregar `STITCH_API_KEY` a `.env.example` de raíz, admin, y portal

**Estado**: ⬜ Pendiente

---

### Orden de implementación recomendado

```
0. S0 — ADR-0022 + prerequisitos (ANTES de todo)
1. S1 — DESIGN.md (sin dependencias)
2. S2 — packages/stitch + env vars (base para todo lo demás)
3. S3 — Schema Prisma (necesario antes de persistir)
4. S4 — Bridge HTML + sanitización (necesario antes de guardar templates)
5. S5 — Backoffice UI (depende de S2, S3, S4)
6. S6 — Portal personalización async (depende de S2, S3, S4)
7. S7 — Tests E2E + health check + docs finales
```

S5 y S6 son independientes entre sí y podrían desarrollarse en paralelo.

### Cosas que NO se van a tocar

- **Brand Generator**: OpenAI + Gemini siguen igual. Stitch es solo para templates web.
- **Flujo de entrevista**: Preguntas `tpl_*` y wizard no cambian.
- **Templates manuales existentes**: Funcionan exactamente igual. Stitch es aditivo.
- **WebPreview component**: Se reutiliza — el output de Stitch es HTML, igual que el actual.
- **Deliverable/Stage schema**: No cambia. `WEBSITE_PREVIEW` sigue siendo el mismo tipo.
- **Bot de Telegram**: No afectado.
- **Landing page**: No afectada.
- **Auth/RLS**: No afectados.

### Dependencias nuevas

- `@google/stitch-sdk` — SDK oficial de Google Labs (en `packages/stitch`) — auditar licencia/tamaño en S0
- `isomorphic-dompurify` — sanitización HTML (en `packages/stitch`) — necesario para XSS
- Variable de entorno: `STITCH_API_KEY` (en admin y portal) — documentar en `.env.example` desde S0

### Resumen de archivos

| Archivo | Acción |
|---------|--------|
| `docs/DESIGN.md` | Nuevo |
| `packages/stitch/` (8 archivos src + tests) | Nuevo (package completo) |
| `packages/db/prisma/schema.prisma` | Modificar (enum + 4 campos) |
| `apps/admin/.../templates/nuevo/` (2 archivos) | Nuevo |
| `apps/admin/.../templates/[id]/editar/_components/StitchEditor.tsx` | Nuevo |
| `apps/admin/app/api/stitch/` (3 routes) | Nuevo |
| `apps/portal/app/_lib/interview/stitch-personalizer.ts` | Nuevo |
| `apps/portal/app/_lib/interview/website-generator.ts` | Modificar |
| `apps/portal/app/_lib/interview/session-processor.ts` | Modificar |
| `docs/decisions/ADR-0022-stitch-template-factory.md` | Nuevo |
| `docs/ARCHITECTURE.md` | Modificar |
| Tests (~6 archivos) | Nuevo |

**Total**: ~20 archivos nuevos, 4 modificados. 1 dependencia nueva. 1 migración de DB no-destructiva.

*Última actualización: 2026-03-19 — Plan revisado por 6 roles (Product, Code, QA, Security, Performance, DevOps). Correcciones de 5 CRÍTICOS y 10 ALTOS aplicadas. Informe completo en `docs/reviews/2026-03-19_plan-stitch-template-factory.md`.*
