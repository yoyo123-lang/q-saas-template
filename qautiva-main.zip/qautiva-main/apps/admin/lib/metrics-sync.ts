/**
 * Orquestador de sincronización de métricas de campañas.
 *
 * Carga la cuenta de ads de la DB, desencripta tokens, refresca si es necesario,
 * llama a la API de la plataforma y hace upsert de CampaignMetric en la DB.
 *
 * Solo server-side. No importar en Client Components.
 */
import { prisma } from '@qautiva/db'
import { decryptToken, encryptToken } from '@qautiva/ads/shared'
import { refreshGoogleToken, fetchGoogleCampaignMetrics } from '@qautiva/ads/google'
import { fetchMetaCampaignMetrics } from '@qautiva/ads/meta'
import { AdsAuthError, formatAdsError } from '@qautiva/ads/shared'

// ── Types ──────────────────────────────────────────────────────────────────────

export interface SyncResult {
  ok: boolean
  platform: string
  accountId: string
  rowsUpserted: number
  error?: string
}

// Margen de refresh: refrescar token si vence en menos de 5 minutos
const TOKEN_REFRESH_MARGIN_MS = 5 * 60 * 1000

// ── Función principal ──────────────────────────────────────────────────────────

/**
 * Sincroniza métricas de todos los campañas de una cuenta de ads.
 * Incluye refresh automático de token para cuentas de Google.
 *
 * @param adAccountId - ID interno (UUID) de la AdAccount
 * @returns SyncResult con cantidad de filas procesadas o error
 */
export async function syncAdAccountMetrics(adAccountId: string): Promise<SyncResult> {
  const account = await prisma.adAccount.findUnique({
    where: { id: adAccountId },
    select: {
      id: true,
      platform: true,
      externalId: true,
      accessToken: true,
      refreshToken: true,
      tokenExpiresAt: true,
      status: true,
      campaigns: {
        where: { externalId: { not: null } },
        select: { id: true, externalId: true },
      },
    },
  })

  if (!account) {
    return { ok: false, platform: 'UNKNOWN', accountId: adAccountId, rowsUpserted: 0, error: 'Cuenta no encontrada' }
  }

  if (account.status === 'DISCONNECTED' || account.status === 'ERROR') {
    return { ok: false, platform: account.platform, accountId: adAccountId, rowsUpserted: 0, error: `La cuenta está ${account.status === 'DISCONNECTED' ? 'desconectada' : 'en error'} — el cliente debe reconectarla` }
  }

  // Desencriptar tokens
  let accessToken: string
  let refreshToken: string
  try {
    accessToken = decryptToken(account.accessToken)
    refreshToken = decryptToken(account.refreshToken)
  } catch {
    return {
      ok: false,
      platform: account.platform,
      accountId: adAccountId,
      rowsUpserted: 0,
      error: 'Error al desencriptar tokens — la clave de encriptación puede haber cambiado',
    }
  }

  // Refresh de token de Google si está próximo a vencer
  if (account.platform === 'GOOGLE_ADS') {
    const expiresAt = account.tokenExpiresAt
    const needsRefresh = !expiresAt || expiresAt.getTime() - Date.now() < TOKEN_REFRESH_MARGIN_MS

    if (needsRefresh) {
      try {
        const refreshed = await refreshGoogleToken(refreshToken)
        accessToken = refreshed.accessToken
        // refreshToken puede rotar — actualizar en DB
        await prisma.adAccount.update({
          where: { id: adAccountId },
          data: {
            accessToken: encryptToken(refreshed.accessToken),
            refreshToken: encryptToken(refreshed.refreshToken),
            tokenExpiresAt: refreshed.expiresAt,
          },
        })
        console.info('[metrics-sync] Token de Google refrescado', { adAccountId })
      } catch (err) {
        if (err instanceof AdsAuthError) {
          // Token revocado — marcar cuenta como REVOKED
          await prisma.adAccount.update({
            where: { id: adAccountId },
            data: { status: 'DISCONNECTED' },
          })
          return {
            ok: false,
            platform: account.platform,
            accountId: adAccountId,
            rowsUpserted: 0,
            error: 'Token revocado — el cliente debe reconectar su cuenta de Google Ads',
          }
        }
        return {
          ok: false,
          platform: account.platform,
          accountId: adAccountId,
          rowsUpserted: 0,
          error: `Error refrescando token: ${formatAdsError(err)}`,
        }
      }
    }
  }

  // Fetch de métricas según plataforma
  try {
    if (account.platform === 'GOOGLE_ADS') {
      return await syncGoogleMetrics(adAccountId, account.externalId, accessToken, refreshToken, account.campaigns)
    } else if (account.platform === 'META') {
      return await syncMetaMetrics(adAccountId, account.externalId, accessToken, account.campaigns)
    } else {
      return { ok: false, platform: account.platform, accountId: adAccountId, rowsUpserted: 0, error: `Plataforma no soportada: ${account.platform}` }
    }
  } catch (err) {
    return {
      ok: false,
      platform: account.platform,
      accountId: adAccountId,
      rowsUpserted: 0,
      error: formatAdsError(err),
    }
  }
}

// ── Google Ads sync ────────────────────────────────────────────────────────────

async function syncGoogleMetrics(
  adAccountId: string,
  customerId: string,
  accessToken: string,
  refreshToken: string,
  campaigns: Array<{ id: string; externalId: string | null }>,
): Promise<SyncResult> {
  const metrics = await fetchGoogleCampaignMetrics({
    customerId,
    accessToken,
    refreshToken,
  })

  // Mapear externalId → campaignId interno
  const externalToInternal = new Map(
    campaigns
      .filter((c) => c.externalId !== null)
      .map((c) => [c.externalId as string, c.id]),
  )

  let rowsUpserted = 0

  for (const m of metrics) {
    const internalCampaignId = externalToInternal.get(m.campaignId)
    if (!internalCampaignId) continue // Campaña no existe en nuestra DB

    // costMicros → centavos: dividir por 10000 (1 centavo = 10000 micros)
    const spendCents = Math.round(m.costMicros / 10_000)

    await prisma.campaignMetric.upsert({
      where: {
        campaignId_date_source: {
          campaignId: internalCampaignId,
          date: new Date(m.date),
          source: 'API_SYNC',
        },
      },
      create: {
        campaignId: internalCampaignId,
        date: new Date(m.date),
        source: 'API_SYNC',
        impressions: m.impressions,
        clicks: m.clicks,
        conversions: Math.round(m.conversions),
        spend: spendCents,
        ctr: m.ctr,
        cpc: m.averageCpc > 0 ? m.averageCpc / 1_000_000 : null, // micros → unidades
        cpa: m.conversions > 0 ? spendCents / Math.round(m.conversions) : null,
      },
      update: {
        impressions: m.impressions,
        clicks: m.clicks,
        conversions: Math.round(m.conversions),
        spend: spendCents,
        ctr: m.ctr,
        cpc: m.averageCpc > 0 ? m.averageCpc / 1_000_000 : null,
        cpa: m.conversions > 0 ? spendCents / Math.round(m.conversions) : null,
      },
    })
    rowsUpserted++
  }

  console.info('[metrics-sync] Google Ads sync completado', { adAccountId, rowsUpserted })
  return { ok: true, platform: 'GOOGLE_ADS', accountId: adAccountId, rowsUpserted }
}

// ── Meta sync ─────────────────────────────────────────────────────────────────

async function syncMetaMetrics(
  adAccountId: string,
  accountId: string,
  accessToken: string,
  campaigns: Array<{ id: string; externalId: string | null }>,
): Promise<SyncResult> {
  const metrics = await fetchMetaCampaignMetrics({
    accountId,
    accessToken,
  })

  const externalToInternal = new Map(
    campaigns
      .filter((c) => c.externalId !== null)
      .map((c) => [c.externalId as string, c.id]),
  )

  let rowsUpserted = 0

  for (const m of metrics) {
    const internalCampaignId = externalToInternal.get(m.campaignId)
    if (!internalCampaignId) continue

    // Meta devuelve spend en moneda (float), convertir a centavos
    const spendCents = Math.round(m.spend * 100)

    await prisma.campaignMetric.upsert({
      where: {
        campaignId_date_source: {
          campaignId: internalCampaignId,
          date: new Date(m.dateStart),
          source: 'API_SYNC',
        },
      },
      create: {
        campaignId: internalCampaignId,
        date: new Date(m.dateStart),
        source: 'API_SYNC',
        impressions: m.impressions,
        clicks: m.clicks,
        conversions: Math.round(m.conversions),
        spend: spendCents,
        ctr: m.ctr,
        cpc: m.cpc > 0 ? m.cpc : null,
        cpa: m.costPerConversion > 0 ? m.costPerConversion : null,
      },
      update: {
        impressions: m.impressions,
        clicks: m.clicks,
        conversions: Math.round(m.conversions),
        spend: spendCents,
        ctr: m.ctr,
        cpc: m.cpc > 0 ? m.cpc : null,
        cpa: m.costPerConversion > 0 ? m.costPerConversion : null,
      },
    })
    rowsUpserted++
  }

  console.info('[metrics-sync] Meta sync completado', { adAccountId, rowsUpserted })
  return { ok: true, platform: 'META', accountId: adAccountId, rowsUpserted }
}
