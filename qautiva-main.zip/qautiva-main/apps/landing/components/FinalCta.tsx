'use client'

import type { RefObject } from 'react'
import { useInView } from '@/lib/use-in-view'

const WHATSAPP_FALLBACK = '5491100000000'
const rawWhatsappNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? WHATSAPP_FALLBACK
// Validar que sea solo dígitos (10-15 chars) para evitar inyección de URL
const whatsappNumber = /^\d{10,15}$/.test(rawWhatsappNumber) ? rawWhatsappNumber : WHATSAPP_FALLBACK
const whatsappUrl = `https://wa.me/${whatsappNumber}`

export function FinalCta() {
  const { ref, isVisible } = useInView()

  return (
    <section
      id="lanzar"
      ref={ref as RefObject<HTMLElement>}
      className="py-24"
      style={{
        background:
          'radial-gradient(ellipse 80% 60% at 50% 50%, rgba(139,92,246,0.12) 0%, #0B0F1A 70%)',
      }}
    >
      <div className="max-w-2xl mx-auto px-6 text-center">
        <h2 className={`text-4xl md:text-5xl font-bold text-white mb-8 reveal ${isVisible ? 'visible' : ''}`}>
          ¿Listo para lanzar?
        </h2>

        <div className={`reveal delay-200 ${isVisible ? 'visible' : ''}`}>
          <a
            href="#precios"
            className="inline-flex items-center justify-center bg-white text-accent font-bold px-8 py-4 rounded-lg text-lg hover:bg-slate-100 transition-colors duration-200 mb-6"
          >
            Empezá ahora
          </a>

          <p className="text-slate-500 text-sm">
            O{' '}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors duration-200 underline underline-offset-2"
            >
              escribinos por WhatsApp
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
