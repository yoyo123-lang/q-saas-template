# QA Engineer Review
**Fecha:** 2026-03-25
**Archivos revisados:**
- `src/lib/tenant.ts`
- `tests/unit/tenant.test.ts`
- `prisma/schema.prisma`
- `prisma/seed.ts`

---

## Hallazgos

### CRÍTICO

#### QA-01 — `withTenant()` no tiene ni un solo test
**Archivo:** `tests/unit/tenant.test.ts`
**Descripción:** Los tests cubren `applyTenantFilter` (función pura, fácil de testear) y `TENANT_SCOPED_MODELS` (set estático). Pero `withTenant()` — la función que realmente se va a usar en producción para aislar tenants — no tiene ningún test. Si `withTenant` falla silenciosamente (por ejemplo, en el bug CR-01 de Organization), ningún test lo detecta.
**Fix sugerido:** Agregar tests de integración con Prisma mock o una DB en memoria que verifiquen que `withTenant(id).invoice.findMany()` solo retorna registros del tenant correcto, y que `withTenant(id).invoice.findMany()` con registros de otro tenant no los incluye.

#### QA-02 — No hay test que verifique que `Organization` en `TENANT_SCOPED_MODELS` causa error
**Archivo:** `tests/unit/tenant.test.ts` + `src/lib/tenant.ts:8`
**Descripción:** El bug CR-01 (Organization sin organizationId pero incluida en el Set) es detectable con un test. Actualmente no existe ningún test que ejecute `withTenant` contra el modelo Organization para detectar el fallo.
**Fix sugerido:** Test de integración: `await withTenant('org_id').organization.findMany()` debería lanzar, o retornar resultados correctos, sin error de "campo desconocido".

---

### ALTO

#### QA-03 — No se testea comportamiento con `organizationId` vacío o inválido
**Archivo:** `tests/unit/tenant.test.ts`
**Descripción:** No hay tests para:
- `applyTenantFilter("")` — debería filtrar por string vacío
- `applyTenantFilter(null as any)` — ¿tira error o pasa null al query?
- `withTenant("")` — crea un cliente que filtra por `organizationId = ''`
Estos son casos borde reales: si por algún bug de sesión `organizationId` llega como string vacío, el sistema podría retornar datos inesperados o todos los registros sin organizationId.
**Fix sugerido:** Agregar validación en `withTenant()` que tire error si `organizationId` es falsy. Agregar tests para ese guard.

#### QA-04 — No hay tests para operaciones de escritura con tenant
**Archivo:** `tests/unit/tenant.test.ts`
**Descripción:** No hay tests que verifiquen el comportamiento de `withTenant` en `create`, `update`, `delete`, `findUnique`. Como estas operaciones no son interceptadas (ver CR-02), un developer que asuma que el cliente es "seguro" para todas las operaciones va a introducir bugs silenciosos.
**Fix sugerido:** Agregar tests que documenten explícitamente qué operaciones son y NO son interceptadas.

---

### MEDIO

#### QA-05 — El test de "no muta el where original" no cubre objetos anidados
**Archivo:** `tests/unit/tenant.test.ts:33-38`
**Descripción:** `applyTenantFilter` hace spread del objeto `where`, lo cual es shallow copy. Si `where` contiene objetos anidados (ej: `{ price: { gte: 100 } }`), las referencias internas se comparten. El test actual solo verifica el caso simple con `{ name: "Test" }`.
**Fix sugerido:** Agregar test con `where` que tenga un objeto anidado y verificar que la mutación del anidado no afecta el original.

#### QA-06 — Seed no es idempotente para todos los recursos
**Archivo:** `prisma/seed.ts:84-90`
**Descripción:** Los planes hacen upsert con `update: plan` (destructivo si los precios cambiaron). Los demás recursos hacen `update: {}` (seguro). La inconsistencia hace el seed parcialmente destructivo, lo cual es un comportamiento sorpresivo.
**Fix sugerido:** Documentar explícitamente qué resources son actualizados en cada ejecución y cuáles no.

#### QA-07 — No se testea que el schema SQL y el schema Prisma son equivalentes
**Archivo:** `supabase/migrations/20260325000000_add_domain_models.sql` + `prisma/schema.prisma`
**Descripción:** Existen dos definiciones del schema. No hay ningún test automatizado que verifique que ambos están sincronizados. Una discrepancia entre ellos (ej: un campo en el schema Prisma que no existe en la migración SQL) causaría errores en producción.
**Fix sugerido:** Usar `prisma db pull` post-migración y comparar con el schema actual, o adoptar solo Prisma Migrate y eliminar el archivo SQL manual.

---

### BAJO

#### QA-08 — El test de TENANT_SCOPED_MODELS no detecta modelos faltantes dinámicamente
**Archivo:** `tests/unit/tenant.test.ts:42-65`
**Descripción:** El test hardcodea la lista de modelos esperados. Si se agrega un nuevo modelo con `organizationId` al schema pero se olvida agregarlo a `TENANT_SCOPED_MODELS`, el test no lo detecta.
**Fix sugerido:** Idear una forma de derivar los modelos esperados desde el schema (ej: con introspección de Prisma DMMF) o al menos documentar que el test debe actualizarse manualmente cuando se agrega un modelo.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 2        |
| ALTO      | 2        |
| MEDIO     | 3        |
| BAJO      | 1        |
| **Total** | **8**    |
