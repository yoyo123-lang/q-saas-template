'use client'

/**
 * Preview visual de la pantalla de bienvenida del portal.
 * Simula un teléfono a 360px de ancho para ver cómo se verá en mobile.
 */

import type { PreviewFields } from '@/components/forms/StageWelcomeForm'

type Props = {
  fields: PreviewFields
  /** Si true, muestra el frame del teléfono (mobile). Si false, muestra desktop ancho. */
  mobile: boolean
}

export function StageWelcomePreview({ fields, mobile }: Props) {
  const { title, description, estimatedTime, whatYouGet, icon, fastTrackText } = fields

  const content = (
    <div className="bg-[#0B0F1A] min-h-full p-4 flex items-start justify-center">
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 w-full">
        {/* Ícono */}
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 text-xl"
          style={{ backgroundColor: '#8B5CF615', border: '1px solid #8B5CF630' }}
        >
          {icon || '📋'}
        </div>

        {/* Header */}
        <p className="text-[#94A3B8] text-xs font-medium mb-1">Vista previa</p>
        <h1 className="text-xl font-bold text-white mb-2 leading-snug">
          {title || <span className="text-[#475569] italic">Sin título</span>}
        </h1>
        <p className="text-[#94A3B8] text-sm leading-relaxed mb-5">
          {description || <span className="italic text-[#475569]">Sin descripción</span>}
        </p>

        {/* Info chips */}
        <div className="flex items-center gap-3 mb-5 pb-5 border-b border-[#1E293B]">
          <Chip icon="⏱" label={estimatedTime || '—'} />
          <Chip icon="🎯" label={whatYouGet || '—'} />
        </div>

        {/* Mensaje de confianza */}
        <div className="flex items-start gap-2 mb-5">
          <span className="text-emerald-400 text-sm mt-0.5">🛡</span>
          <p className="text-[#94A3B8] text-xs">
            Podés pausar y retomar en cualquier momento. Tus respuestas se guardan automáticamente.
          </p>
        </div>

        {/* Fast-track */}
        {fastTrackText && (
          <p className="text-[#64748B] text-xs mb-4 italic">
            {fastTrackText}
          </p>
        )}

        {/* CTA */}
        <button
          disabled
          className="w-full py-2.5 bg-[#8B5CF6] text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 opacity-90"
        >
          Comenzar entrevista →
        </button>
      </div>
    </div>
  )

  if (mobile) {
    return (
      <div className="flex flex-col items-center gap-2">
        <p className="text-xs text-[#475569] font-medium">Mobile (360px)</p>
        {/* Phone frame */}
        <div
          className="relative rounded-[2rem] border-4 border-[#1E293B] overflow-hidden shadow-xl"
          style={{ width: 360, height: 640 }}
        >
          {/* Notch */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-5 bg-[#1E293B] rounded-b-xl z-10" />
          <div className="overflow-y-auto h-full pt-5">
            {content}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-2">
      <p className="text-xs text-[#475569] font-medium">Desktop</p>
      <div className="rounded-xl border border-[#1E293B] overflow-hidden" style={{ maxWidth: 560 }}>
        {content}
      </div>
    </div>
  )
}

function Chip({ icon, label }: { icon: string; label: string }) {
  return (
    <div className="flex items-center gap-1 text-[#64748B] text-xs">
      <span>{icon}</span>
      <span className="truncate max-w-[120px]">{label}</span>
    </div>
  )
}
