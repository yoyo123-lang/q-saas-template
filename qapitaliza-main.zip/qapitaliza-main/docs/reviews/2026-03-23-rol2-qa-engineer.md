# Informe de Revisión — ROL 2: QA Engineer
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol 2 - QA Engineer

---

## Resumen ejecutivo

Las páginas públicas cubren los estados de vacío, cargando y error en los listados. Se detectaron dos issues funcionales — uno crítico que podía romper la página de detalle y otro alto de UX en los filtros de precio.

---

## Hallazgos

### [CRÍTICO → CORREGIDO] `incrementListingViews` puede tirar y romper la página de detalle

**Archivo:** `src/app/(public)/explorar/[slug]/page.tsx`

**Problema original:** La llamada a `incrementListingViews(listing.id)` no estaba envuelta en try/catch. Si la DB fallaba durante el UPDATE, el usuario veía un 500 en lugar del detalle del activo.

**Fix aplicado:** La llamada se envuelve en un IIFE async con try/catch y `void` para que sea completamente no-bloqueante. Un error de DB ya no puede afectar el renderizado de la página.

```typescript
void (async () => {
  try {
    const cookieStore = await cookies()
    const cookieKey = `viewed_${listing.id}`
    if (!cookieStore.has(cookieKey)) {
      cookieStore.set(cookieKey, '1', { maxAge: 3600, httpOnly: true, path: '/' })
      await incrementListingViews(listing.id)
    }
  } catch (e) {
    console.error('[ListingDetail] Failed to increment view count:', e)
  }
})()
```

---

### [ALTO → CORREGIDO] Price filter inputs navegaban en cada keystroke

**Archivo:** `src/components/listings/filter-sidebar.tsx`

**Problema original:** Los inputs de precio tenían `onChange` que llamaba `router.push()` en cada tecla. Esto provocaba una navegación por carácter — mala UX y potenciales errores de concurrencia.

**Fix aplicado:** Se usan `useState` local (`localPriceMin`, `localPriceMax`) para los inputs, con `onChange` que solo actualiza el estado local y `onBlur` que dispara el `router.push()`. La navegación solo ocurre cuando el usuario termina de escribir.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| incrementListingViews rompe página | CRÍTICO | Corregido |
| Price filter navega en cada keystroke | ALTO | Corregido |
