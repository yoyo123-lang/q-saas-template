'use client'

import { useState, useTransition } from 'react'
import { retryInterviewSession } from '@/app/actions/interview'

interface RetrySessionButtonProps {
  sessionId: string
  orgId: string
}

/**
 * Botón de reintento para sesiones en estado PROCESSING o ERROR.
 * Llama a la Server Action retryInterviewSession y muestra feedback.
 */
export function RetrySessionButton({ sessionId, orgId }: RetrySessionButtonProps) {
  const [isPending, startTransition] = useTransition()
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null)

  function handleRetry() {
    // Antes de ejecutar la acción, pedir confirmación
    if (!confirm('¿Confirmar reprocesamiento de esta sesión? Esta acción llama a la IA y puede tardar hasta 1 minuto.')) {
      return
    }
    setResult(null)
    startTransition(async () => {
      const res = await retryInterviewSession(sessionId, orgId)
      setResult(res)
    })
  }

  return (
    <div className="flex-shrink-0 flex flex-col items-end gap-1.5">
      <button
        onClick={handleRetry}
        disabled={isPending}
        className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/30 text-[#A78BFA] border border-[#8B5CF6]/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
      >
        {isPending ? 'Procesando...' : 'Reintentar'}
      </button>
      {result && (
        <p className={`text-[10px] text-right max-w-[140px] ${result.ok ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
          {result.message}
        </p>
      )}
    </div>
  )
}
