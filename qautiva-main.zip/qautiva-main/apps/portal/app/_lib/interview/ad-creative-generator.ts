import { executeToolCall, type BillingContext, type ToolDefinition } from './ai-tool-call'
import type { AdCreatives, AdCopyVariant, BrandOptions, CampaignPlan, QuestionBlock, StrategicBrief } from './types'
import { buildInterviewSummary } from './brief-generator'

// ── Character limits by platform ─────────────────────────────────────────────

const LIMITS = {
  GOOGLE_SEARCH: { headline: 30, description: 90 },
  META_FEED: { headline: 40, description: 125 },
  META_STORY: { headline: 40, description: 125 },
} as const

// ── Types ─────────────────────────────────────────────────────────────────────

export type PreviousDeliverable =
  | { type: 'BRIEF'; content: StrategicBrief }
  | { type: 'CAMPAIGN_PLAN'; content: CampaignPlan }
  | { type: 'BRAND_OPTIONS'; content: BrandOptions }
  | { type: string; content: unknown }

export type GenerateAdCreativesInput = {
  flowDefinition: QuestionBlock[]
  answers: Record<string, unknown>
  project: { name: string; industry: string | null; country: string | null }
  previousDeliverables: PreviousDeliverable[]
  /** Plataformas conectadas — solo generar copy para las que el cliente tiene cuenta */
  connectedPlatforms: Array<'GOOGLE_ADS' | 'META'>
  billingContext?: BillingContext
}

// ── Tool definition ───────────────────────────────────────────────────────────

// Schema for a single copy variant (reused across platforms)
const AD_COPY_VARIANT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    headline: { type: 'string' },
    description: { type: 'string' },
    callToAction: { type: 'string' },
    angle: { type: 'string' },
  },
  required: ['headline', 'description', 'callToAction', 'angle'],
} as const

const GENERATE_AD_CREATIVES_TOOL: ToolDefinition = {
  name: 'generate_ad_creatives',
  description:
    'Genera variantes de copy publicitario para Google Ads (Search) y Meta Ads (Feed y Story). ' +
    'Exactamente 3 variantes por formato. Respeta límites de caracteres de cada plataforma.',
  input_schema: {
    type: 'object' as const,
    additionalProperties: false,
    properties: {
      googleAds: {
        type: ['object', 'null'],
        additionalProperties: false,
        properties: {
          search: {
            type: 'array',
            items: AD_COPY_VARIANT_SCHEMA,
            minItems: 2,
            maxItems: 3,
          },
        },
        required: ['search'],
      },
      metaAds: {
        type: ['object', 'null'],
        additionalProperties: false,
        properties: {
          feed: {
            type: 'array',
            items: AD_COPY_VARIANT_SCHEMA,
            minItems: 2,
            maxItems: 3,
          },
          story: {
            type: 'array',
            items: AD_COPY_VARIANT_SCHEMA,
            minItems: 2,
            maxItems: 3,
          },
        },
        required: ['feed', 'story'],
      },
      guiaDeTono: {
        type: 'object',
        additionalProperties: false,
        properties: {
          tono: { type: 'string' },
          palabrasClave: { type: 'array', items: { type: 'string' } },
          evitar: { type: 'array', items: { type: 'string' } },
        },
        required: ['tono', 'palabrasClave', 'evitar'],
      },
      disclaimer: { type: 'string' },
    },
    required: ['googleAds', 'metaAds', 'guiaDeTono', 'disclaimer'],
  },
}

// ── Prompt ───────────────────────────────────────────────────────────────────

const SYNTHESIS_SYSTEM_PROMPT = `Sos el Redactor Creativo de Qautiva. Tu trabajo es escribir copy publicitario efectivo para PyMEs en Argentina que aparece en Google Ads y Meta Ads.

Límites de caracteres ESTRICTOS que NO podés exceder:
- Google Search: headline máximo 30 caracteres, description máximo 90 caracteres
- Meta Feed: headline máximo 40 caracteres, description (primary text) máximo 125 caracteres
- Meta Story: iguales a Meta Feed

Instrucciones:
1. Generá exactamente 3 variantes por formato activo — cada una con un ángulo diferente
2. Cada headline debe ser conciso y generar urgencia o curiosidad dentro del límite
3. Cada descripción debe incluir el beneficio principal y el CTA en los caracteres disponibles
4. El copy debe ser coherente con el tono de marca del Brief — no uses jerga técnica si el negocio es local
5. Para Google Search: el usuario ya tiene intención de búsqueda — vendé directo, no te presentes
6. Para Meta Feed/Story: el usuario NO está buscando — despertá curiosidad o mostrá un problema que resuelve el negocio
7. Si una plataforma no está conectada, devolvé null para ese objeto
8. El callToAction debe ser específico: no "Hacé click" sino "Pedí tu turno", "Probá 30 días gratis", etc.

Acción: Llamá a generate_ad_creatives con las piezas completas.`

// Disclaimer mínimo garantizado por código — idéntico al patrón de campaign-strategy-generator
const MIN_DISCLAIMER_PREFIX = 'Este copy fue generado por inteligencia artificial como propuesta inicial. ' +
  'Revisá que los caracteres se ajusten a los límites de cada plataforma antes de publicar. '

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Genera variantes de copy publicitario a partir del plan de campaña y deliverables anteriores.
 *
 * @param input - Proyecto, plataformas conectadas, deliverables anteriores
 * @returns AdCreatives con variantes por plataforma/formato
 * @throws Error si el modelo falla o devuelve output inválido
 */
export async function generateAdCreatives(input: GenerateAdCreativesInput): Promise<AdCreatives> {
  const context = buildContextSummary(input)
  const interviewContent = buildInterviewSummary(input.flowDefinition, input.answers)

  const platformsNote = input.connectedPlatforms.length > 0
    ? `Plataformas conectadas (generar solo para estas): ${input.connectedPlatforms.join(', ')}`
    : 'No hay plataformas conectadas — generá para ambas como referencia'

  const userMessage = [
    `CONTEXTO DEL NEGOCIO:\n${context}`,
    `PLATAFORMAS: ${platformsNote}`,
    interviewContent.length > 0 && input.flowDefinition.length > 0
      ? `PREFERENCIAS DEL CLIENTE:\n${interviewContent}`
      : null,
    'Generá las piezas publicitarias.',
  ]
    .filter(Boolean)
    .join('\n\n---\n\n')

  const result = await executeToolCall({
    system: SYNTHESIS_SYSTEM_PROMPT,
    userMessage,
    tool: GENERATE_AD_CREATIVES_TOOL,
    maxTokens: 8192,
    logPrefix: 'ad-creative-generator',
    billingContext: input.billingContext ? { ...input.billingContext, operation: 'ad_creatives' } : undefined,
  })

  const creatives = structuredClone(validateAdCreatives(result.input))

  // Enforce character limits — trim if model exceeded them
  if (creatives.googleAds) {
    creatives.googleAds.search = creatives.googleAds.search.map((v) =>
      enforceCharLimits(v, LIMITS.GOOGLE_SEARCH),
    )
  }
  if (creatives.metaAds) {
    creatives.metaAds.feed = creatives.metaAds.feed.map((v) =>
      enforceCharLimits(v, LIMITS.META_FEED),
    )
    creatives.metaAds.story = creatives.metaAds.story.map((v) =>
      enforceCharLimits(v, LIMITS.META_STORY),
    )
  }

  // Set null for unconnected platforms when platforms were specified
  if (input.connectedPlatforms.length > 0) {
    if (!input.connectedPlatforms.includes('GOOGLE_ADS')) {
      creatives.googleAds = null
    }
    if (!input.connectedPlatforms.includes('META')) {
      creatives.metaAds = null
    }
  }

  creatives.disclaimer = MIN_DISCLAIMER_PREFIX + creatives.disclaimer

  return creatives
}

// ── Validación runtime ────────────────────────────────────────────────────────

/**
 * Valida que el output del modelo tenga la estructura esperada de AdCreatives.
 * Lanza Error descriptivo si falta algún campo estructural.
 */
function validateAdCreatives(raw: unknown): AdCreatives {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error('[ad-creative-generator] Output no es un objeto')
  }
  const obj = raw as Record<string, unknown>

  // googleAds puede ser null (si no hay cuenta Google)
  if (obj['googleAds'] !== null) {
    if (typeof obj['googleAds'] !== 'object') {
      throw new Error('[ad-creative-generator] googleAds debe ser objeto o null')
    }
    const google = obj['googleAds'] as Record<string, unknown>
    if (!Array.isArray(google['search'])) {
      throw new Error('[ad-creative-generator] googleAds.search debe ser array')
    }
    if (google['search'].length < 2) {
      throw new Error('[ad-creative-generator] googleAds.search debe tener mínimo 2 variantes')
    }
    for (const v of google['search'] as unknown[]) {
      validateCopyVariant(v, 'googleAds.search')
    }
  }

  // metaAds puede ser null (si no hay cuenta Meta)
  if (obj['metaAds'] !== null) {
    if (typeof obj['metaAds'] !== 'object') {
      throw new Error('[ad-creative-generator] metaAds debe ser objeto o null')
    }
    const meta = obj['metaAds'] as Record<string, unknown>
    if (!Array.isArray(meta['feed'])) {
      throw new Error('[ad-creative-generator] metaAds.feed debe ser array')
    }
    if (meta['feed'].length < 2) {
      throw new Error('[ad-creative-generator] metaAds.feed debe tener mínimo 2 variantes')
    }
    for (const v of meta['feed'] as unknown[]) {
      validateCopyVariant(v, 'metaAds.feed')
    }
    if (!Array.isArray(meta['story'])) {
      throw new Error('[ad-creative-generator] metaAds.story debe ser array')
    }
    if (meta['story'].length < 2) {
      throw new Error('[ad-creative-generator] metaAds.story debe tener mínimo 2 variantes')
    }
    for (const v of meta['story'] as unknown[]) {
      validateCopyVariant(v, 'metaAds.story')
    }
  }

  // guiaDeTono
  if (typeof obj['guiaDeTono'] !== 'object' || obj['guiaDeTono'] === null) {
    throw new Error('[ad-creative-generator] Falta guiaDeTono')
  }
  const guia = obj['guiaDeTono'] as Record<string, unknown>
  if (typeof guia['tono'] !== 'string') {
    throw new Error('[ad-creative-generator] guiaDeTono.tono debe ser string')
  }
  if (!Array.isArray(guia['palabrasClave'])) {
    throw new Error('[ad-creative-generator] guiaDeTono.palabrasClave debe ser array')
  }
  if (!Array.isArray(guia['evitar'])) {
    throw new Error('[ad-creative-generator] guiaDeTono.evitar debe ser array')
  }

  // disclaimer
  if (typeof obj['disclaimer'] !== 'string') {
    throw new Error('[ad-creative-generator] disclaimer debe ser string')
  }

  return raw as AdCreatives
}

function validateCopyVariant(raw: unknown, path: string): void {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error(`[ad-creative-generator] ${path}[*] debe ser objeto`)
  }
  const v = raw as Record<string, unknown>
  if (typeof v['headline'] !== 'string') {
    throw new Error(`[ad-creative-generator] ${path}[*].headline debe ser string`)
  }
  if (typeof v['description'] !== 'string') {
    throw new Error(`[ad-creative-generator] ${path}[*].description debe ser string`)
  }
  if (typeof v['callToAction'] !== 'string') {
    throw new Error(`[ad-creative-generator] ${path}[*].callToAction debe ser string`)
  }
  if (typeof v['angle'] !== 'string') {
    throw new Error(`[ad-creative-generator] ${path}[*].angle debe ser string`)
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Trunca headline y description si exceden los límites de la plataforma.
 * Preferimos truncar que rechazar — el operador puede ajustar manualmente.
 */
function enforceCharLimits(
  variant: AdCopyVariant,
  limits: { headline: number; description: number },
): AdCopyVariant {
  return {
    ...variant,
    headline: variant.headline.slice(0, limits.headline),
    description: variant.description.slice(0, limits.description),
  }
}

/**
 * Construye el contexto del negocio para el prompt del generador.
 */
function buildContextSummary(input: GenerateAdCreativesInput): string {
  const sections: string[] = []

  sections.push(`Negocio: ${input.project.name}`)
  if (input.project.industry) sections.push(`Industria: ${input.project.industry}`)
  if (input.project.country) sections.push(`País: ${input.project.country}`)

  for (const d of input.previousDeliverables) {
    if (d.type === 'BRIEF' && d.content) {
      const brief = d.content as StrategicBrief
      sections.push(
        `\n## Brief Estratégico\n` +
        `- Descripción: ${brief.negocio?.descripcion ?? 'N/A'}\n` +
        `- Mensaje central: ${brief.direccionComunicacional?.mensajeCentral ?? 'N/A'}\n` +
        `- Tono: ${brief.direccionComunicacional?.tonoSugerido ?? 'N/A'}\n` +
        `- Perfil cliente: ${brief.audiencia?.perfilCliente ?? 'N/A'}\n` +
        `- Ventaja competitiva: ${brief.posicionamiento?.ventajaCompetitiva ?? 'N/A'}`
      )
    }

    if (d.type === 'CAMPAIGN_PLAN' && d.content) {
      const plan = d.content as CampaignPlan
      sections.push(
        `\n## Plan de Campaña\n` +
        `- Mensaje principal: ${plan.oferta?.mensajePrincipal ?? 'N/A'}\n` +
        `- CTA: ${plan.oferta?.callToAction ?? 'N/A'}\n` +
        `- Audiencia: ${plan.audiencias?.[0]?.nombre ?? 'N/A'}`
      )
    }
  }

  return sections.join('\n')
}
