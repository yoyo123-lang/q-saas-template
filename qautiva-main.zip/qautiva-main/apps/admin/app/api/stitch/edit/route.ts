import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { personalizeTemplate, getDesignContext } from '@qautiva/stitch'
import { processStitchHtml } from '@qautiva/stitch'

export const maxDuration = 120

interface EditBody {
  templateId: string
  prompt: string
}

function isValidUUID(id: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
}

/**
 * POST /api/stitch/edit
 * Aplica cambios a un template existente de Stitch usando personalizeTemplate.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: EditBody
  try {
    body = (await req.json()) as EditBody
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { templateId, prompt } = body

  if (!templateId || !isValidUUID(templateId)) {
    return NextResponse.json({ error: 'templateId debe ser un UUID válido' }, { status: 400 })
  }
  if (!prompt || !prompt.trim()) {
    return NextResponse.json({ error: 'prompt es requerido' }, { status: 400 })
  }

  const template = await prisma.webTemplate.findUnique({
    where: { id: templateId },
    select: {
      id: true,
      name: true,
      source: true,
      stitchProjectId: true,
      stitchScreenId: true,
      sections: true,
    },
  })

  if (!template) {
    return NextResponse.json({ error: 'Template no encontrado' }, { status: 404 })
  }
  if (template.source !== 'STITCH') {
    return NextResponse.json(
      { error: 'Este template no fue creado con Stitch' },
      { status: 400 },
    )
  }
  if (!template.stitchProjectId || !template.stitchScreenId) {
    return NextResponse.json(
      { error: 'El template no tiene stitchProjectId o stitchScreenId' },
      { status: 400 },
    )
  }

  try {
    const result = await personalizeTemplate({
      stitchProjectId: template.stitchProjectId,
      stitchScreenId: template.stitchScreenId,
      brandKit: null,
      businessData: { name: template.name },
      designContext: getDesignContext(),
    })

    const existingSections = (template.sections as Record<string, boolean>) ?? {}
    const targetSections = Object.keys(existingSections).filter((k) => existingSections[k])

    const processResult = processStitchHtml(result.html, targetSections)
    if (!processResult.success) {
      return NextResponse.json(
        { error: 'El HTML editado no pudo procesarse', reason: processResult.reason },
        { status: 422 },
      )
    }

    await prisma.webTemplate.update({
      where: { id: templateId },
      data: {
        htmlBase: processResult.processedHtml,
        css: result.css,
        generationPrompt: prompt,
      },
    })

    return NextResponse.json({
      processedHtml: processResult.processedHtml,
      detectedSections: processResult.detectedSections,
    })
  } catch (err) {
    console.error('[stitch:edit] error', err instanceof Error ? err.message : String(err))
    return NextResponse.json({ error: 'Error interno al editar template' }, { status: 500 })
  }
}
