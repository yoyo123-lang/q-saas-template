'use client'

export const dynamic = 'force-dynamic'

import { useState } from 'react'
import Link from 'next/link'
import { createSupabaseBrowserClient } from '@/lib/supabase-browser'
import { getRecaptchaToken } from '@/lib/recaptcha'
import LoadingSpinner from './_components/LoadingSpinner'

type PageState = 'idle' | 'loading-google' | 'loading-email' | 'email-confirmation' | 'error'

export default function OnboardingPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [state, setState] = useState<PageState>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  const supabase = createSupabaseBrowserClient()

  function clearError() {
    if (state === 'error') {
      setState('idle')
      setErrorMessage('')
    }
  }

  async function handleGoogleSignup() {
    setState('loading-google')
    setErrorMessage('')

    const origin = window.location.origin
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${origin}/auth/callback?next=/onboarding/api-key`,
      },
    })

    if (error) {
      setState('error')
      setErrorMessage('No se pudo iniciar el registro con Google. Intentá de nuevo.')
    }
  }

  async function handleEmailSignup(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!email.trim() || !password.trim()) {
      setState('error')
      setErrorMessage('Completá todos los campos.')
      return
    }

    if (password.length < 8) {
      setState('error')
      setErrorMessage('La contraseña debe tener al menos 8 caracteres.')
      return
    }

    setState('loading-email')
    setErrorMessage('')

    try {
      await getRecaptchaToken('signup')
    } catch {
      if (process.env.NODE_ENV === 'production') {
        setState('error')
        setErrorMessage('Error de verificación de seguridad. Intentá de nuevo.')
        return
      }
    }

    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback?next=/onboarding/api-key`,
      },
    })

    if (error) {
      setState('error')
      if (error.message.includes('already registered') || error.message.includes('already been registered')) {
        setErrorMessage('Ya existe una cuenta con ese email. ¿Querés ingresar?')
      } else {
        setErrorMessage('No se pudo crear la cuenta. Intentá de nuevo.')
      }
      return
    }

    if (!data.session) {
      setState('email-confirmation')
      return
    }

    window.location.href = '/onboarding/api-key'
  }

  const isLoadingGoogle = state === 'loading-google'
  const isLoadingEmail = state === 'loading-email'
  const isLoading = isLoadingGoogle || isLoadingEmail

  if (state === 'email-confirmation') {
    return (
      <div className="w-full max-w-sm text-center">
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8">
          <div className="text-4xl mb-4">📧</div>
          <h1 className="text-xl font-bold text-white mb-3">Revisá tu email</h1>
          <p className="text-[#94A3B8] text-sm">
            Te enviamos un link de confirmación a <strong className="text-white">{email}</strong>.
            Hacé click en el link para activar tu cuenta y continuar.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-sm">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Creá tu cuenta</h1>
        <p className="text-[#94A3B8] text-sm">Lanzá tu negocio digital con IA.</p>
      </div>

      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
        {state === 'error' && errorMessage && (
          <div className="mb-4 p-3 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm">
            {errorMessage}
            {errorMessage.includes('Ya existe') && (
              <> <Link href="/login" className="underline hover:text-red-300">Ingresá acá</Link>.</>
            )}
          </div>
        )}

        {/* Google */}
        <button
          type="button"
          onClick={handleGoogleSignup}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-3 px-4 py-2.5 rounded-lg border border-[#1E293B] bg-[#1E293B] text-white text-sm font-medium hover:border-[#8B5CF6]/50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoadingGoogle ? <LoadingSpinner /> : <GoogleIcon />}
          {isLoadingGoogle ? 'Redirigiendo...' : 'Continuar con Google'}
        </button>

        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-[#1E293B]" />
          <span className="text-[#64748B] text-xs">o</span>
          <div className="flex-1 h-px bg-[#1E293B]" />
        </div>

        <form onSubmit={handleEmailSignup} noValidate>
          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm text-[#94A3B8] mb-1.5">Email</label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); clearError() }}
                placeholder="tu@email.com"
                className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200"
                disabled={isLoading}
                maxLength={254}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm text-[#94A3B8] mb-1.5">Contraseña</label>
              <input
                id="password"
                type="password"
                autoComplete="new-password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); clearError() }}
                placeholder="Mínimo 8 caracteres"
                className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200"
                disabled={isLoading}
                maxLength={128}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoadingEmail ? <><LoadingSpinner /> Creando cuenta...</> : 'Crear cuenta'}
            </button>
          </div>
        </form>

        <p className="text-center text-[#64748B] text-xs mt-5">
          ¿Ya tenés cuenta?{' '}
          <Link href="/login" className="text-[#A78BFA] hover:underline">Ingresá</Link>
        </p>
      </div>
    </div>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
      <path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z" />
      <path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18Z" />
      <path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332Z" />
      <path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58Z" />
    </svg>
  )
}
