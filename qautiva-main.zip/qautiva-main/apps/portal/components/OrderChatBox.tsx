'use client'

import { useState, useEffect, useRef } from 'react'
import { OrderStatus } from '@qautiva/db/types'

const MESSAGING_CLOSED: OrderStatus[] = [OrderStatus.COMPLETED, OrderStatus.CANCELLED]

type Message = {
  id: string
  senderId: string
  senderDisplayName: string | null
  content: string
  createdAt: string
}

export function OrderChatBox({
  orderId,
  profileId,
  orderStatus,
}: {
  orderId: string
  profileId: string
  orderStatus: OrderStatus
}) {
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [content, setContent] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)

  const isClosed = MESSAGING_CLOSED.includes(orderStatus)

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch(`/api/marketplace/orders/${orderId}/messages?take=50`)
        if (!res.ok) return
        const data = (await res.json()) as { messages: Message[] }
        setMessages(data.messages)
      } finally {
        setLoading(false)
      }
    }

    load()

    if (isClosed) return

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/marketplace/orders/${orderId}/messages?take=50`)
        if (!res.ok) return
        const data = (await res.json()) as { messages: Message[] }
        setMessages(data.messages)
      } catch {
        // polling failure is silent — user can still see cached messages
      }
    }, 15_000)

    return () => clearInterval(interval)
  }, [orderId, isClosed])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault()
    if (!content.trim()) return
    setError(null)
    setSending(true)
    try {
      const res = await fetch(`/api/marketplace/orders/${orderId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: content.trim() }),
      })
      const data = (await res.json()) as { error?: string; message?: Message }
      if (!res.ok) {
        setError(data.error ?? 'No se pudo enviar el mensaje.')
        return
      }
      if (data.message) {
        setMessages((prev) => [...prev, data.message!])
        setContent('')
      }
    } catch {
      setError('No se pudo conectar con el servidor.')
    } finally {
      setSending(false)
    }
  }

  return (
    <section aria-label="Chat de la orden" className="flex flex-col gap-3">
      <h2 className="text-white font-semibold">Mensajes</h2>

      {/* Historial */}
      <div className="bg-[#0B0F1A] border border-[#1E293B] rounded-xl p-4 flex flex-col gap-3 min-h-[160px] max-h-[360px] overflow-y-auto">
        {loading && <p className="text-[#64748B] text-xs text-center m-auto">Cargando mensajes…</p>}
        {!loading && messages.length === 0 && (
          <p className="text-[#64748B] text-xs text-center m-auto">Sin mensajes aún.</p>
        )}
        {messages.map((msg) => {
          const isOwn = msg.senderId === profileId
          return (
            <div key={msg.id} className={`flex flex-col gap-0.5 ${isOwn ? 'items-end' : 'items-start'}`}>
              <p className="text-[#475569] text-xs">
                {isOwn ? 'Vos' : (msg.senderDisplayName ?? 'Sin nombre')}
                {' · '}
                {new Date(msg.createdAt).toLocaleString('es-AR', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
              <div
                className={`max-w-[80%] rounded-xl px-3 py-2 text-sm leading-relaxed break-words ${
                  isOwn
                    ? 'bg-[#1E3A5F] text-[#93C5FD]'
                    : 'bg-[#1E293B] text-[#94A3B8]'
                }`}
              >
                {msg.content}
              </div>
            </div>
          )
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      {isClosed ? (
        <p className="text-[#475569] text-xs text-center">
          El chat está cerrado para órdenes {orderStatus === OrderStatus.COMPLETED ? 'completadas' : 'canceladas'}.
        </p>
      ) : (
        <form onSubmit={sendMessage} className="flex gap-2">
          <input
            type="text"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            disabled={sending}
            maxLength={5000}
            placeholder="Escribí un mensaje…"
            aria-label="Escribir mensaje"
            className="flex-1 bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-2 focus:outline-none focus:border-[#334155] placeholder-[#475569] disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={sending || !content.trim()}
            aria-busy={sending}
            className="px-4 py-2 rounded-xl text-sm font-medium bg-[#1E3A5F] text-[#60A5FA] hover:bg-[#1E4D8C] disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
          >
            {sending ? '…' : 'Enviar'}
          </button>
        </form>
      )}

      {error && (
        <p role="alert" className="text-red-400 text-xs">{error}</p>
      )}
    </section>
  )
}
