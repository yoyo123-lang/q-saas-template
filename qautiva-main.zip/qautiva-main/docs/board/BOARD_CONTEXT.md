# Conexión con Q Company Board — Qautiva

> **Este archivo explica por qué y cómo Qautiva se conecta al Board central de Q Company.**
> Debe estar referenciado en el `CLAUDE.md` de Qautiva para que cualquier sesión de Claude Code
> entienda el contexto del grupo empresarial.
>
> **Sincronizado** con el repo de qautiva.ar (`docs/board/`) y con `docs/bu/qautiva/` en q-company.

---

## Contexto del grupo

Qautiva es una unidad de negocio del grupo **Q Company**. El grupo opera un Board central
que funciona como directorio ejecutivo con roles de IA especializados (CFO, CTO, CRO, CSO,
VP Product, VP Engineering).

El Board:
- **Analiza** las métricas de negocio que cada BU reporta
- **Genera** reportes semanales con recomendaciones estratégicas
- **Emite** directivas (instrucciones de negocio) que la BU debe ejecutar
- **Monitorea** la salud operativa de cada BU via heartbeats

### Rol de Qautiva en el ecosistema

Qautiva es la unidad de marketing y publicidad del grupo. Ofrece presencia digital completa
(marca, web, campañas, medios) a emprendedores no-técnicos mediante agentes de IA especializados
que ejecutan frameworks probados de estrategia, marca y comunicación.

**Modelo de ingresos**: utility pricing con créditos en ARS por uso de agentes IA, venta de
dominios, y (futuro) comisión sobre inversión publicitaria.

### Otras BUs del grupo

| BU | Dominio | Qué hace | Relación con Qautiva |
|----|---------|----------|---------------------|
| Qobra | qobra.ar | Cobros recurrentes y suscripciones | Qautiva puede diseñar campañas para clientes de Qobra |
| Qontacta | qontacta.ar | CRM y gestión de clientes | Los leads de Qautiva pueden gestionarse en Qontacta |
| Qapitaliza | qapitaliza.ar | Compraventa de negocios | Qautiva puede crear presencia digital para negocios listados |

---

## Qué métricas enviás y por qué

Las métricas que Qautiva envía al Board son consumidas por roles AI que las analizan
semanalmente. Cada métrica tiene un propósito concreto en la toma de decisiones del grupo.

> **Detalle completo en `METRICS_MAP.md`** — ahí se mapea cada métrica al rol que la consume
> y la decisión que informa.

### Resumen de métricas

| Key | Frecuencia | Rol principal |
|-----|-----------|---------------|
| `monthly_revenue` | monthly | CFO |
| `active_clients` | monthly | CRO |
| `avg_project_value` | monthly | CFO |
| `client_retention_rate` | quarterly | CRO |
| `projects_in_progress` | weekly | VP Product |
| `projects_completed` | monthly | VP Product |
| `avg_project_duration` | monthly | CTO |

### Métricas específicas de Qautiva (del modelo de negocio)

Además de las métricas genéricas de agencia, Qautiva debería reportar estas métricas
específicas de su modelo (utility pricing + agentes IA):

| Key | Label | Frecuencia | Rol principal |
|-----|-------|-----------|---------------|
| `trial_conversion_rate` | Tasa conversión trial→pago | monthly | CRO |
| `arpu` | Revenue promedio por usuario | monthly | CFO |
| `avg_tokens_per_launch` | Consumo promedio por lanzamiento | monthly | CFO + VP Product |
| `credits_revenue` | Revenue por créditos IA | monthly | CFO |
| `domains_revenue` | Revenue por dominios | monthly | CFO |

### Cómo enviarlas

Las métricas se envían via `POST /api/v1/bu/{buId}/metrics` con header `x-api-key`.

Variables de entorno requeridas:

```env
BOARD_API_KEY=qb_qautiva_{key}
BOARD_BU_ID={buId}
BOARD_URL=https://q-company.vercel.app
```

Ejemplo de envío:

```typescript
await fetch(`${BOARD_URL}/api/v1/bu/${BOARD_BU_ID}/metrics`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': BOARD_API_KEY,
  },
  body: JSON.stringify({
    metrics: [
      { key: 'monthly_revenue', value: 150000, period: '2026-03-01' },
      { key: 'active_clients', value: 12, period: '2026-03-01' },
    ],
  }),
})
```

---

## Qué son las directivas

Las directivas son instrucciones que el Board envía a Qautiva. Pueden originarse en:
- Un reporte semanal de un rol AI (ej: el CFO detecta caída de revenue)
- Una decisión estratégica del CEO
- Una alerta automática por threshold

### Cómo llegan

El Board hace `POST` al webhook de Qautiva (`/api/v1/directives/receive`).
Qautiva debe verificar la firma HMAC-SHA256 del header `X-Board-Signature`.

### Cómo responder

1. Recibir la directiva → responder `200 OK` con `{ acknowledged: true }`
2. Actualizar el status a `in_progress` via `PATCH /api/v1/bu/{buId}/directives/{id}/status`
3. Ejecutar lo que la directiva pide
4. Reportar `completed`, `failed`, o `rejected` con notas

### Tipos de directivas que Qautiva podría recibir

| Tipo | Ejemplo concreto para Qautiva |
|------|------------------------------|
| `OPERATIONAL` | "Activar marketplace de medios para clientes enterprise" |
| `STRATEGIC` | "Priorizar retención de clientes con trial por vencer sobre adquisición" |
| `TECHNICAL` | "Implementar cache para reducir costos de API de agentes IA" |
| `FINANCIAL` | "Revisar pricing — el ARPU está por debajo del target" |
| `PROMOTION` | "Lanzar campaña de referral para aumentar base de usuarios" |
| `INVESTIGATION` | "Analizar por qué el consumo promedio por lanzamiento bajó un 30%" |

---

## Eventos a reportar

Los eventos se envían en near-real-time via `POST /api/v1/bu/{buId}/events`.

| Evento | Cuándo se dispara | Prioridad |
|--------|-------------------|-----------|
| `lead_captured` | Formulario en landing completado | Alta |
| `signup_completed` | Usuario se registra en el portal | Alta |
| `intake_completed` | Entrevista de intake finalizada | Alta |
| `first_deliverable_generated` | Primer entregable generado | Alta |
| `trial_credits_exhausted` | Créditos de trial llegan a 0 | Crítica |
| `plan_selected` | Usuario elige plan pago | Crítica |
| `trial_converted` | Trial → plan pago exitoso | Crítica |
| `project_completed` | Todas las etapas activas finalizadas | Alta |
| `domain_purchased` | Usuario compra un dominio | Media |

---

## Heartbeat

Qautiva debe enviar un heartbeat cada 5 minutos via `POST /api/v1/bu/{buId}/heartbeat`.
Si pasan más de 15 minutos sin heartbeat, el Board genera una alerta.

```env
BOARD_WEBHOOK_SECRET={secret}
```

---

## Sincronización de archivos

Este archivo, `BUSINESS_MODEL.md` y `METRICS_MAP.md` están sincronizados entre:
- **Repo de Qautiva**: `docs/board/`
- **Repo de q-company**: `docs/bu/qautiva/`

Cuando se modifica uno, debe actualizarse el otro. Ver `.github/workflows/sync-bu-docs.yml`.

---

## Referencia en CLAUDE.md de Qautiva

Agregar al `CLAUDE.md` de qautiva.ar:

```markdown
## Conexión con Q Company Board

Esta BU pertenece al grupo Q Company y reporta al Board central.
Ver `docs/board/BOARD_CONTEXT.md` para entender la conexión.
Archivos sincronizados con el Board:
- `docs/board/BUSINESS_MODEL.md` — modelo de negocio (fuente de verdad)
- `docs/board/BOARD_CONTEXT.md` — contexto de conexión y directivas
- `docs/board/METRICS_MAP.md` — mapeo de métricas a roles AI del Board
```

---

## Historial de cambios

| Fecha | Qué cambió | Por qué |
|-------|-----------|---------|
| 2026-03-22 | Documento inicial | Onboarding de Qautiva al Board |
