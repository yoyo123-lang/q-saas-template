import Anthropic from '@anthropic-ai/sdk'
import OpenAI from 'openai'
import { getAiConfig } from './ai-config'
import type { QuestionBlock } from './types'

// ── Singletons ───────────────────────────────────────────────────────────────

let _anthropicClient: Anthropic | null = null
function getAnthropicClient(): Anthropic {
  if (!_anthropicClient) _anthropicClient = new Anthropic({ timeout: 25_000 })
  return _anthropicClient
}

let _openaiClient: OpenAI | null = null
function getOpenAIClient(): OpenAI {
  if (!_openaiClient) {
    const apiKey = process.env['OPENAI_API_KEY']
    if (!apiKey) throw new Error('[ai-interviewer] OPENAI_API_KEY no está configurada')
    _openaiClient = new OpenAI({ apiKey, timeout: 25_000 })
  }
  return _openaiClient
}

// ── Tool schemas (provider-agnostic) ─────────────────────────────────────────

const ASK_QUESTION_SCHEMA = {
  name: 'ask_question',
  description:
    'Hace una pregunta al usuario. Llamala cada vez que necesitás más información.',
  input_schema: {
    type: 'object' as const,
    additionalProperties: false,
    properties: {
      id: {
        type: 'string',
        description: 'Identificador único en snake_case sin espacios (ej: negocio_descripcion)',
      },
      question: {
        type: 'string',
        description: 'Texto de la pregunta que verá el usuario',
      },
      inputType: {
        type: 'string',
        enum: ['text', 'textarea', 'multiple_choice'],
        description:
          'text para respuestas cortas, textarea para respuestas largas, multiple_choice para opciones predefinidas',
      },
      options: {
        type: 'array',
        description: 'Solo para multiple_choice. Array de { value: string, label: string }',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            value: { type: 'string' },
            label: { type: 'string' },
          },
          required: ['value', 'label'],
        },
      },
      helpText: {
        type: 'string',
        description: 'Texto de ayuda adicional opcional',
      },
      placeholder: {
        type: 'string',
        description: 'Placeholder del input (opcional)',
      },
    },
    required: ['id', 'question', 'inputType'],
  },
}

const INTERVIEW_COMPLETE_SCHEMA = {
  name: 'interview_complete',
  description:
    'Señala que la entrevista está completa y tenés suficiente información de todos los temas para construir el Brief Estratégico. Llamala solo cuando tengas info de todos los temas requeridos.',
  input_schema: {
    type: 'object' as const,
    additionalProperties: false,
    properties: {
      summary: {
        type: 'string',
        description: 'Resumen de 1-2 oraciones de lo que aprendiste del negocio.',
      },
    },
    required: ['summary'],
  },
}

// ── Tipos públicos ─────────────────────────────────────────────────────────────

export type AiInterviewerResult =
  | { type: 'question'; block: QuestionBlock }
  | { type: 'complete' }

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Obtiene la próxima pregunta de la entrevista conversacional.
 * Usa el provider/modelo configurado en TrialConfig (admin panel).
 *
 * El historial de la conversación se reconstruye desde `flowDefinition` + `answers`,
 * por lo que no se necesita almacenar mensajes por separado en la DB.
 *
 * @param systemPrompt - El prompt de sistema del AgentConfig (El Estratega)
 * @param flowDefinition - Preguntas generadas hasta ahora (en orden cronológico)
 * @param answers - Respuestas del usuario { questionId: value }
 * @returns La próxima pregunta a mostrar, o señal de finalización
 * @throws Error si la API falla o el modelo no llama ninguna tool
 */
export async function getNextQuestion(
  systemPrompt: string,
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
): Promise<AiInterviewerResult> {
  const config = await getAiConfig()

  console.info(`[ai-interviewer] provider=${config.provider}, model=${config.model}`)

  if (config.provider === 'ANTHROPIC') {
    return callAnthropicInterviewer(systemPrompt, flowDefinition, answers, config.model)
  }

  return callOpenAIInterviewer(systemPrompt, flowDefinition, answers, config.model)
}

// ── Anthropic implementation ─────────────────────────────────────────────────

async function callAnthropicInterviewer(
  systemPrompt: string,
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
  model: string,
): Promise<AiInterviewerResult> {
  const client = getAnthropicClient()

  const tools: Anthropic.Tool[] = [
    {
      name: ASK_QUESTION_SCHEMA.name,
      description: ASK_QUESTION_SCHEMA.description,
      input_schema: ASK_QUESTION_SCHEMA.input_schema as Anthropic.Tool['input_schema'],
    },
    {
      name: INTERVIEW_COMPLETE_SCHEMA.name,
      description: INTERVIEW_COMPLETE_SCHEMA.description,
      input_schema: INTERVIEW_COMPLETE_SCHEMA.input_schema as Anthropic.Tool['input_schema'],
    },
  ]

  const messages = buildAnthropicMessages(flowDefinition, answers)

  const response = await client.messages.create({
    model,
    max_tokens: 1024,
    system: systemPrompt,
    tools,
    tool_choice: { type: 'any' },
    messages,
  })

  const toolUseBlock = response.content.find(
    (b): b is Anthropic.ToolUseBlock => b.type === 'tool_use',
  )

  if (!toolUseBlock) {
    throw new Error('[ai-interviewer] Claude respondió sin llamar una tool — stop_reason: ' + response.stop_reason)
  }

  return parseToolResult(toolUseBlock.name, toolUseBlock.input as Record<string, unknown>)
}

// ── OpenAI implementation ────────────────────────────────────────────────────

/**
 * Detecta modelos de razonamiento de OpenAI (o-series, gpt-5 family).
 */
function isReasoningModel(model: string): boolean {
  return /^(o[1-9]|gpt-5)/.test(model)
}

async function callOpenAIInterviewer(
  systemPrompt: string,
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
  model: string,
): Promise<AiInterviewerResult> {
  const client = getOpenAIClient()
  const reasoning = isReasoningModel(model)

  const tools: OpenAI.ChatCompletionTool[] = [
    {
      type: 'function',
      function: {
        name: ASK_QUESTION_SCHEMA.name,
        description: ASK_QUESTION_SCHEMA.description,
        parameters: ASK_QUESTION_SCHEMA.input_schema,
      },
    },
    {
      type: 'function',
      function: {
        name: INTERVIEW_COMPLETE_SCHEMA.name,
        description: INTERVIEW_COMPLETE_SCHEMA.description,
        parameters: INTERVIEW_COMPLETE_SCHEMA.input_schema,
      },
    },
  ]

  const messages = buildOpenAIMessages(systemPrompt, flowDefinition, answers, reasoning)

  const response = await client.chat.completions.create({
    model,
    ...(reasoning
      ? { max_completion_tokens: 1024 }
      : { max_tokens: 1024 }
    ),
    messages,
    tools,
    tool_choice: 'required',
  })

  const choice = response.choices[0]
  if (!choice) {
    throw new Error('[ai-interviewer] OpenAI no devolvió choices')
  }

  const toolCall = choice.message?.tool_calls?.[0]
  if (!toolCall || toolCall.type !== 'function') {
    throw new Error(
      `[ai-interviewer] OpenAI no llamó ninguna tool — finish_reason: ${choice.finish_reason}`,
    )
  }

  let parsed: unknown
  try {
    parsed = JSON.parse(toolCall.function.arguments)
  } catch {
    throw new Error('[ai-interviewer] OpenAI devolvió JSON inválido en tool_call arguments')
  }

  return parseToolResult(toolCall.function.name, parsed as Record<string, unknown>)
}

// ── Shared parsing ───────────────────────────────────────────────────────────

function parseToolResult(
  toolName: string,
  input: Record<string, unknown>,
): AiInterviewerResult {
  if (toolName === 'interview_complete') {
    return { type: 'complete' }
  }

  if (toolName === 'ask_question') {
    const block: QuestionBlock = {
      id: String(input.id),
      question: String(input.question),
      inputType: (input.inputType as QuestionBlock['inputType']) ?? 'textarea',
      options: Array.isArray(input.options)
        ? (input.options as QuestionBlock['options'])
        : undefined,
      helpText: input.helpText ? String(input.helpText) : undefined,
      placeholder: input.placeholder ? String(input.placeholder) : undefined,
      validation: { required: true },
    }
    return { type: 'question', block }
  }

  throw new Error(`[ai-interviewer] Tool desconocida: ${toolName}`)
}

// ── Message builders ─────────────────────────────────────────────────────────

/**
 * Reconstruye el historial de mensajes en formato Anthropic desde flowDefinition + answers.
 *
 * Patrón:
 *   user:      "Iniciá la entrevista."
 *   assistant: tool_use ask_question { block_0 }
 *   user:      tool_result answer_0
 *   ...
 */
/** @internal Exportada para tests */
export function buildAnthropicMessages(
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
): Anthropic.MessageParam[] {
  if (flowDefinition.length === 0) {
    return [{ role: 'user', content: 'Iniciá la entrevista.' }]
  }

  const messages: Anthropic.MessageParam[] = [
    { role: 'user', content: 'Iniciá la entrevista.' },
  ]

  for (const q of flowDefinition) {
    const answer = answers[q.id]
    if (answer === undefined) break

    messages.push({
      role: 'assistant',
      content: [
        {
          type: 'tool_use',
          id: q.id,
          name: 'ask_question',
          input: q as unknown as Record<string, unknown>,
        },
      ],
    })

    const rawText = typeof answer === 'string' ? answer : JSON.stringify(answer)
    const answerText = `<respuesta_usuario>${rawText}</respuesta_usuario>`
    messages.push({
      role: 'user',
      content: [
        {
          type: 'tool_result',
          tool_use_id: q.id,
          content: answerText,
        },
      ],
    })
  }

  return messages
}

/**
 * Reconstruye el historial de mensajes en formato OpenAI Chat Completions.
 *
 * OpenAI usa un patrón diferente para tool_use:
 *   system/developer: system prompt
 *   user:             "Iniciá la entrevista."
 *   assistant:        tool_calls: [{ function: { name, arguments } }]
 *   tool:             { tool_call_id, content: answer }
 *   ...
 */
function buildOpenAIMessages(
  systemPrompt: string,
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
  reasoning: boolean,
): OpenAI.ChatCompletionMessageParam[] {
  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: reasoning ? 'developer' : 'system', content: systemPrompt },
    { role: 'user', content: 'Iniciá la entrevista.' },
  ]

  for (const q of flowDefinition) {
    const answer = answers[q.id]
    if (answer === undefined) break

    // Assistant llamó a ask_question
    messages.push({
      role: 'assistant',
      tool_calls: [
        {
          id: q.id,
          type: 'function',
          function: {
            name: 'ask_question',
            arguments: JSON.stringify(q),
          },
        },
      ],
    })

    // Tool response con la respuesta del usuario
    const rawText = typeof answer === 'string' ? answer : JSON.stringify(answer)
    messages.push({
      role: 'tool',
      tool_call_id: q.id,
      content: `<respuesta_usuario>${rawText}</respuesta_usuario>`,
    })
  }

  return messages
}

// ── Backwards compatibility alias ────────────────────────────────────────────

/**
 * @deprecated Usar buildAnthropicMessages directamente. Alias mantenido para tests existentes.
 */
export const buildMessages = buildAnthropicMessages
