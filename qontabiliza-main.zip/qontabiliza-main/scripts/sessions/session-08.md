# Sesión 8: Ventas y POS (backend) + Tesorería básica

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 8
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Modelo de venta completo con descuento de stock automático, emisión de factura, y registro en caja.

## Pre-requisitos

Sesiones 5, 6, 7 completadas (facturación ARCA + stock).

## Etapas

### Etapa 1: Servicio de ventas (transacción atómica)
- Crear venta → descontar stock → emitir factura ARCA → registrar pago
- Todo en una transacción: si algo falla, rollback completo
- Validaciones: stock suficiente, cliente válido, datos fiscales completos
- Calcular totales con IVA

### Etapa 2: API routes de ventas
- POST /api/sales — crear venta completa
- GET /api/sales — listar ventas (con filtros)
- GET /api/sales/:id — detalle de venta
- Medios de pago: efectivo, tarjeta débito, tarjeta crédito, transferencia, QR

### Etapa 3: Tesorería básica
- CashRegister: apertura con monto inicial, cierre con arqueo
- PaymentRecord: registro de cada pago asociado a una venta
- API routes para abrir/cerrar caja, listar movimientos de caja
- Resumen de caja: total por medio de pago

### Etapa 4: Mock Qobra
- Interfaz `PaymentProvider` con métodos: processPayment, refund, getStatus
- Implementación mock que simula cobro exitoso con delay
- Preparada para reemplazar con integración real de Qobra en Fase 2
- Tests que verifican la interfaz

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
