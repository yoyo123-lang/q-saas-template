import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { unstable_cache } from 'next/cache'
import type { AutomationLevel } from '@qautiva/db'
import { prisma } from '@qautiva/db'
import { getAgentDefault } from '@/lib/agent-defaults'
import { UpdateAgentForm } from '@/components/forms/UpdateAgentForm'
import { InterviewPromptForm } from '@/components/forms/InterviewPromptForm'
import { OutputTemplateForm } from '@/components/forms/OutputTemplateForm'
import dynamicImport from 'next/dynamic'
import { FlujoMergeadoSection } from '@/components/FlujoMergeadoSection'
import { DELIVERABLE_STATUS_BADGE } from '@/lib/badges'

const AgentPerformanceChart = dynamicImport(
  () => import('@/components/AgentPerformanceChart').then((m) => ({ default: m.AgentPerformanceChart })),
  { ssr: false, loading: () => <div className="h-[220px] bg-[#1E293B] animate-pulse rounded-lg" /> },
)

export const dynamic = 'force-dynamic'

// ── Tipos ──────────────────────────────────────────────────────────────────────

interface AgentData {
  id: string
  agentNumber: number
  name: string
  description: string
  automationLevel: AutomationLevel
  prompt: string
  interviewPrompt: string | null
  outputTemplate: unknown
}

interface PerformancePoint {
  month: string
  aprobados: number
  rechazados: number
}

interface RecentDeliverable {
  id: string
  title: string
  status: string
  createdAt: Date
  orgName: string
}

// ── Queries ────────────────────────────────────────────────────────────────────

/**
 * Carga la configuración de un agente por ID (UUID de DB o "agent-N" para defaults).
 * Cachea la respuesta de DB por 60s — se invalida desde updateAgentConfig via revalidatePath.
 */
const getAgentFromDb = unstable_cache(
  async (agentId: string) => {
    return prisma.agentConfig.findUnique({
      where: { id: agentId },
      select: {
        id: true,
        agentNumber: true,
        name: true,
        description: true,
        automationLevel: true,
        prompt: true,
        interviewPrompt: true,
        outputTemplate: true,
      },
    })
  },
  ['agent-config'],
  { revalidate: 60 },
)

async function getAgent(agentId: string): Promise<AgentData | null> {
  // ID con formato "agent-N" → no hay registro en DB aún, usar defaults
  const defaultMatch = agentId.match(/^agent-(\d+)$/)
  if (defaultMatch) {
    const num = parseInt(defaultMatch[1] ?? '0', 10)
    const def = getAgentDefault(num)
    if (!def) return null
    return {
      id: agentId,
      agentNumber: def.agentNumber,
      name: def.name,
      description: def.description,
      automationLevel: def.automationLevel,
      prompt: def.defaultPrompt,
      interviewPrompt: null,
      outputTemplate: null,
    }
  }

  // UUID real de DB
  try {
    return await getAgentFromDb(agentId)
  } catch (err) {
    console.error(`[admin:agentes] error cargando agente agentId=${agentId}:`, err)
    return null
  }
}

async function getPerformanceData(agentNumber: number): Promise<PerformancePoint[]> {
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

  try {
    const deliverables = await prisma.deliverable.findMany({
      where: {
        stage: { number: agentNumber },
        createdAt: { gte: sixMonthsAgo },
      },
      select: {
        status: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
      take: 500,
    })

    const byMonth: Record<string, { aprobados: number; rechazados: number }> = {}

    for (const d of deliverables) {
      const key = d.createdAt.toLocaleDateString('es-AR', { month: 'short', year: '2-digit' })
      if (!byMonth[key]) byMonth[key] = { aprobados: 0, rechazados: 0 }
      if (d.status === 'CLIENT_APPROVED' || d.status === 'ADMIN_APPROVED') {
        byMonth[key].aprobados++
      } else if (d.status === 'REVISION_REQUESTED' || d.status === 'FAILED') {
        byMonth[key].rechazados++
      }
    }

    return Object.entries(byMonth).map(([month, counts]) => ({ month, ...counts }))
  } catch (err) {
    console.error(`[admin:agentes] error cargando performance agentNumber=${agentNumber}:`, err)
    return []
  }
}

async function getRecentDeliverables(agentNumber: number): Promise<RecentDeliverable[]> {
  try {
    const deliverables = await prisma.deliverable.findMany({
      where: {
        stage: { number: agentNumber },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: {
        id: true,
        title: true,
        status: true,
        createdAt: true,
        organization: {
          select: { name: true },
        },
      },
    })

    return deliverables
      .filter((d) => d.organization !== null)
      .map((d) => ({
        id: d.id,
        title: d.title,
        status: d.status,
        createdAt: d.createdAt,
        orgName: d.organization?.name ?? '(sin nombre)',
      }))
  } catch (err) {
    console.error(`[admin:agentes] error cargando entregables agentNumber=${agentNumber}:`, err)
    return []
  }
}

// ── Metadata ──────────────────────────────────────────────────────────────────

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  // Evitar doble fetch: para defaults usamos datos estáticos directamente
  const defaultMatch = params.id.match(/^agent-(\d+)$/)
  if (defaultMatch) {
    const num = parseInt(defaultMatch[1] ?? '0', 10)
    const def = getAgentDefault(num)
    return { title: def ? `${def.name} | Agentes | Qautiva Admin` : 'Agente | Qautiva Admin' }
  }

  try {
    const config = await prisma.agentConfig.findUnique({
      where: { id: params.id },
      select: { name: true },
    })
    return {
      title: config ? `${config.name} | Agentes | Qautiva Admin` : 'Agente | Qautiva Admin',
    }
  } catch {
    return { title: 'Agente | Qautiva Admin' }
  }
}

// ── Página ─────────────────────────────────────────────────────────────────────

export default async function AgentDetailPage({ params }: { params: { id: string } }) {
  const agent = await getAgent(params.id)
  if (!agent) notFound()

  let performanceData: PerformancePoint[] = []
  let recentDeliverables: RecentDeliverable[] = []
  let industries: { id: string; name: string; questions: unknown }[] = []

  try {
    ;[performanceData, recentDeliverables, industries] = await Promise.all([
      getPerformanceData(agent.agentNumber),
      getRecentDeliverables(agent.agentNumber),
      prisma.industryTemplate.findMany({
        select: { id: true, name: true, questions: true },
        orderBy: { name: 'asc' },
      }),
    ])
  } catch (err) {
    // Cada función ya tiene su propio try/catch; esto solo atrapa casos inesperados
    console.error(`[admin:agentes] error inesperado en Promise.all agentNumber=${agent.agentNumber}:`, err)
  }

  return (
    <div className="flex flex-col gap-6 p-6 max-w-3xl">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#64748B]">
        <Link href="/agentes" className="hover:text-[#94A3B8] transition-colors">
          ← Agentes
        </Link>
        <span>/</span>
        <span className="text-[#94A3B8]">{agent.name}</span>
      </nav>

      {/* Header */}
      <div>
        <p className="text-xs text-[#64748B] font-mono">{agent.agentNumber} —</p>
        <h1 className="text-white text-xl font-bold">{agent.name}</h1>
        <p className="text-[#94A3B8] text-sm mt-0.5">{agent.description}</p>
      </div>

      {/* Formulario de configuración */}
      <section className="flex flex-col gap-4 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B]">
        <h2 className="text-white font-semibold text-sm">Configuración</h2>
        <UpdateAgentForm
          agentNumber={agent.agentNumber}
          automationLevel={agent.automationLevel}
          prompt={agent.prompt}
        />
      </section>

      {/* Interview prompt */}
      <section className="flex flex-col gap-4 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B]">
        <h2 className="text-white font-semibold text-sm">Interview prompt</h2>
        <InterviewPromptForm
          agentNumber={agent.agentNumber}
          interviewPrompt={agent.interviewPrompt}
        />
      </section>

      {/* Output template */}
      <section className="flex flex-col gap-4 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B]">
        <h2 className="text-white font-semibold text-sm">Output template</h2>
        <OutputTemplateForm
          agentNumber={agent.agentNumber}
          outputTemplate={agent.outputTemplate}
        />
      </section>

      {/* Historial de rendimiento */}
      <section className="flex flex-col gap-4 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B]">
        <h2 className="text-white font-semibold text-sm">
          Historial de rendimiento — últimos 6 meses
        </h2>
        <AgentPerformanceChart data={performanceData} />
        <p className="text-[#64748B] text-xs">
          Solo se muestran entregables con resultado definitivo (aprobados o rechazados).
        </p>
      </section>

      {/* Últimos entregables */}
      <section className="flex flex-col gap-4 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B]">
        <h2 className="text-white font-semibold text-sm">Últimos 10 entregables</h2>
        {recentDeliverables.length === 0 ? (
          <p className="text-[#64748B] text-sm">Sin entregables generados aún.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[#64748B] text-xs border-b border-[#1E293B]">
                  <th className="text-left pb-2 font-medium">Negocio</th>
                  <th className="text-left pb-2 font-medium">Entregable</th>
                  <th className="text-left pb-2 font-medium">Resultado</th>
                  <th className="text-left pb-2 font-medium">Fecha</th>
                </tr>
              </thead>
              <tbody>
                {recentDeliverables.map((d) => {
                  const badge = DELIVERABLE_STATUS_BADGE[d.status as keyof typeof DELIVERABLE_STATUS_BADGE]
                  return (
                    <tr key={d.id} className="border-b border-[#1E293B]/50 last:border-0">
                      <td className="py-2.5 text-[#94A3B8] pr-4 whitespace-nowrap">{d.orgName}</td>
                      <td className="py-2.5 text-[#94A3B8] pr-4 max-w-[180px] truncate">{d.title}</td>
                      <td className="py-2.5 pr-4">
                        {badge ? (
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
                            {badge.label}
                          </span>
                        ) : (
                          <span className="text-[#64748B] text-xs">{d.status}</span>
                        )}
                      </td>
                      <td className="py-2.5 text-[#64748B] text-xs whitespace-nowrap">
                        {d.createdAt.toLocaleDateString('es-AR', {
                          day: '2-digit',
                          month: 'short',
                          year: '2-digit',
                        })}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Flujo mergeado */}
      <section className="flex flex-col gap-4 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B]">
        <div>
          <h2 className="text-white font-semibold text-sm">Flujo mergeado</h2>
          <p className="text-[#64748B] text-xs mt-0.5">
            Vista previa del flujo de preguntas combinando el agente con una industria.
          </p>
        </div>
        <FlujoMergeadoSection
          agentNumber={agent.agentNumber}
          interviewPrompt={agent.interviewPrompt}
          industries={industries}
        />
      </section>
    </div>
  )
}
