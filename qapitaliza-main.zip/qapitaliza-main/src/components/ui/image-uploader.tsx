'use client'

import { useCallback, useRef, useState } from 'react'
import { X, Upload, ImageIcon } from 'lucide-react'
import { DndContext, closestCenter, DragEndEvent, PointerSensor, useSensor, useSensors } from '@dnd-kit/core'
import { SortableContext, horizontalListSortingStrategy, useSortable, arrayMove } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { cn } from '@/lib/utils/cn'

interface ImageUploaderProps {
  value: string[]
  onChange: (urls: string[]) => void
  onUpload?: (file: File) => Promise<string>
  label?: string
  error?: string
  maxImages?: number
  maxSizeMb?: number
  className?: string
}

const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp']

function SortableImage({ url, onRemove }: { url: string; onRemove: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: url })

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={cn(
        'relative group size-20 rounded-lg overflow-hidden border border-slate-700',
        isDragging && 'opacity-50 ring-2 ring-amber-500'
      )}
      {...attributes}
      {...listeners}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={url} alt="" className="w-full h-full object-cover" />
      <button
        type="button"
        onClick={(e) => { e.stopPropagation(); onRemove() }}
        className="absolute top-1 right-1 size-5 bg-black/70 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity"
        aria-label="Eliminar imagen"
      >
        <X className="size-3" />
      </button>
      <div className="absolute inset-0 cursor-grab active:cursor-grabbing" />
    </div>
  )
}

export function ImageUploader({
  value = [],
  onChange,
  onUpload,
  label,
  error,
  maxImages = 5,
  maxSizeMb = 2,
  className,
}: ImageUploaderProps) {
  const [draggingOver, setDraggingOver] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const sensors = useSensors(useSensor(PointerSensor))

  const handleFiles = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return
    setUploadError(null)

    const remaining = maxImages - value.length
    const toProcess = Array.from(files).slice(0, remaining)

    const errors: string[] = []
    const validFiles: File[] = []

    for (const file of toProcess) {
      if (!ACCEPTED_TYPES.includes(file.type)) {
        errors.push(`${file.name}: formato no válido (JPG, PNG o WebP)`)
        continue
      }
      if (file.size > maxSizeMb * 1024 * 1024) {
        errors.push(`${file.name}: supera ${maxSizeMb}MB`)
        continue
      }
      validFiles.push(file)
    }

    if (errors.length > 0) {
      setUploadError(errors[0])
      return
    }

    if (onUpload) {
      setUploading(true)
      try {
        const urls = await Promise.all(validFiles.map((f) => onUpload(f)))
        onChange([...value, ...urls])
      } catch {
        setUploadError('Error al subir las imágenes. Intentá de nuevo.')
      } finally {
        setUploading(false)
      }
    } else {
      // Preview mode: convert to object URLs
      const urls = validFiles.map((f) => URL.createObjectURL(f))
      onChange([...value, ...urls])
    }
  }, [value, onChange, onUpload, maxImages, maxSizeMb])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDraggingOver(false)
    handleFiles(e.dataTransfer.files)
  }, [handleFiles])

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event
    if (over && active.id !== over.id) {
      const oldIdx = value.indexOf(active.id as string)
      const newIdx = value.indexOf(over.id as string)
      onChange(arrayMove(value, oldIdx, newIdx))
    }
  }

  const removeImage = (url: string) => {
    onChange(value.filter((u) => u !== url))
  }

  const canAdd = value.length < maxImages

  return (
    <div className={cn('flex flex-col gap-3', className)}>
      {label && <label className="text-sm font-medium text-slate-400">{label}</label>}

      {value.length > 0 && (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={value} strategy={horizontalListSortingStrategy}>
            <div className="flex flex-wrap gap-2">
              {value.map((url) => (
                <SortableImage key={url} url={url} onRemove={() => removeImage(url)} />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}

      {canAdd && (
        <div
          className={cn(
            'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors',
            draggingOver ? 'border-amber-500 bg-amber-500/5' : 'border-slate-800 hover:border-slate-600',
            uploading && 'opacity-50 pointer-events-none'
          )}
          onDragOver={(e) => { e.preventDefault(); setDraggingOver(true) }}
          onDragLeave={() => setDraggingOver(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
        >
          <div className="flex flex-col items-center gap-2 text-slate-400">
            {uploading ? (
              <div className="size-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Upload className="size-8" />
            )}
            <p className="text-sm font-medium text-slate-300">
              {uploading ? 'Subiendo...' : 'Arrastá o hacé click para subir'}
            </p>
            <p className="text-xs text-slate-500">
              Máximo {maxImages} imágenes · {maxSizeMb}MB cada una · JPG, PNG o WebP
            </p>
            {value.length > 0 && (
              <p className="text-xs text-slate-500">{value.length}/{maxImages} imágenes</p>
            )}
          </div>
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPTED_TYPES.join(',')}
            multiple
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />
        </div>
      )}

      {(error || uploadError) && (
        <span className="text-xs text-red-400">{error || uploadError}</span>
      )}
    </div>
  )
}
