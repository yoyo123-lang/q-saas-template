'use server'

import { revalidatePath } from 'next/cache'
import { prisma, Prisma } from '@qautiva/db'
import type { AutomationLevel, StageWelcome } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { logAudit } from '@/lib/audit'

// ── Helpers ────────────────────────────────────────────────────────────────────

/**
 * Verifica que la organización existe. Lanza error descriptivo si no.
 */
async function assertOrgExists(orgId: string): Promise<void> {
  const org = await prisma.organization.findUnique({
    where: { id: orgId },
    select: { id: true },
  })
  if (!org) {
    throw new Error(`Organización no encontrada: ${orgId}`)
  }
}

// ── Notas de admin ─────────────────────────────────────────────────────────────

export async function createAdminNote(formData: FormData): Promise<void> {
  // 1. Autenticación y autorización
  await requireAdminSession()

  // 2. Validar inputs
  const orgId = formData.get('orgId')
  const content = formData.get('content')

  if (typeof orgId !== 'string' || !orgId.trim()) {
    throw new Error('orgId requerido')
  }
  if (typeof content !== 'string' || !content.trim()) {
    throw new Error('Contenido requerido')
  }
  if (content.length > 5000) {
    throw new Error('La nota no puede superar los 5000 caracteres')
  }

  // 3. Verificar existencia de la org (previene FK error críptico + IDOR)
  await assertOrgExists(orgId)

  // 4. Persistir
  try {
    await prisma.adminNote.create({
      data: {
        organizationId: orgId,
        content: content.trim(),
      },
    })
    console.info(`[admin:actions] nota creada — org=${orgId}`)
  } catch (err) {
    console.error('[admin:actions] error creando nota:', err instanceof Error ? err.message : err)
    throw new Error('No se pudo guardar la nota. Intentá de nuevo.')
  }

  revalidatePath(`/clientes/${orgId}`)
}

// ── Mensajes de admin (intervención) ──────────────────────────────────────────

export async function sendAdminMessage(formData: FormData): Promise<void> {
  // 1. Autenticación y autorización
  await requireAdminSession()

  // 2. Validar inputs
  const orgId = formData.get('orgId')
  const content = formData.get('content')
  const stageNumberRaw = formData.get('stageNumber')

  if (typeof orgId !== 'string' || !orgId.trim()) {
    throw new Error('orgId requerido')
  }
  if (typeof content !== 'string' || !content.trim()) {
    throw new Error('Contenido requerido')
  }
  if (content.length > 2000) {
    throw new Error('El mensaje no puede superar los 2000 caracteres')
  }

  const stageNumberParsed =
    stageNumberRaw && typeof stageNumberRaw === 'string'
      ? parseInt(stageNumberRaw, 10)
      : null
  // stageNumber debe ser entre 1 y 6 (etapas del modelo de negocio)
  const stageNumber =
    stageNumberParsed !== null && !isNaN(stageNumberParsed) && stageNumberParsed >= 1 && stageNumberParsed <= 6
      ? stageNumberParsed
      : null

  // 3. Verificar existencia de la org (previene FK error críptico + IDOR)
  await assertOrgExists(orgId)

  // 4. Persistir
  try {
    await prisma.message.create({
      data: {
        organizationId: orgId,
        sender: 'ADMIN',
        channel: 'WEB',
        content: content.trim(),
        ...(stageNumber !== null ? { stageNumber } : {}),
      },
    })
    console.info(`[admin:actions] mensaje admin enviado — org=${orgId} stage=${stageNumber ?? 'n/a'}`)
  } catch (err) {
    console.error('[admin:actions] error enviando mensaje:', err instanceof Error ? err.message : err)
    throw new Error('No se pudo enviar el mensaje. Intentá de nuevo.')
  }

  revalidatePath(`/clientes/${orgId}`)
}

// ── Revisión de etapas ────────────────────────────────────────────────────────

/**
 * Aprueba una etapa: adminApproved=true, status → CLIENT_REVIEW.
 * El cliente podrá ver los entregables y decidir.
 */
export async function approveStage(formData: FormData): Promise<void> {
  await requireAdminSession()

  const stageId = formData.get('stageId')
  const orgId = formData.get('orgId')

  if (typeof stageId !== 'string' || !stageId.trim()) {
    throw new Error('stageId requerido')
  }
  if (typeof orgId !== 'string' || !orgId.trim()) {
    throw new Error('orgId requerido')
  }

  // Verificar que la etapa existe, pertenece a la org y está en ADMIN_REVIEW
  const stage = await prisma.stage.findUnique({
    where: { id: stageId },
    select: { id: true, status: true, number: true, organizationId: true },
  })
  if (!stage) {
    throw new Error('Etapa no encontrada')
  }
  if (stage.organizationId !== orgId) {
    throw new Error('La etapa no pertenece a la organización indicada')
  }
  if (stage.status !== 'ADMIN_REVIEW') {
    throw new Error('La etapa ya no está pendiente de revisión admin')
  }

  try {
    await prisma.stage.update({
      where: { id: stageId },
      data: {
        adminApproved: true,
        adminApprovedAt: new Date(),
        status: 'CLIENT_REVIEW',
      },
    })
    console.info(`[admin:actions] etapa aprobada — stageId=${stageId} org=${orgId} stage=${stage.number}`)
  } catch (err) {
    console.error('[admin:actions] error aprobando etapa:', err instanceof Error ? err.message : err)
    throw new Error('No se pudo aprobar la etapa. Intentá de nuevo.')
  }

  revalidatePath('/revision')
  revalidatePath(`/clientes/${orgId}`)
}

/**
 * Rechaza una etapa: status → REVISION.
 * Crea una AdminNote con el feedback para trazabilidad.
 */
export async function rejectStage(formData: FormData): Promise<void> {
  await requireAdminSession()

  const stageId = formData.get('stageId')
  const orgId = formData.get('orgId')
  const feedback = formData.get('feedback')

  if (typeof stageId !== 'string' || !stageId.trim()) {
    throw new Error('stageId requerido')
  }
  if (typeof orgId !== 'string' || !orgId.trim()) {
    throw new Error('orgId requerido')
  }
  if (typeof feedback !== 'string' || !feedback.trim()) {
    throw new Error('El motivo de rechazo es requerido')
  }
  if (feedback.length > 1000) {
    throw new Error('El motivo no puede superar los 1000 caracteres')
  }

  const stage = await prisma.stage.findUnique({
    where: { id: stageId },
    select: { id: true, status: true, number: true, name: true, organizationId: true },
  })
  if (!stage) {
    throw new Error('Etapa no encontrada')
  }
  if (stage.organizationId !== orgId) {
    throw new Error('La etapa no pertenece a la organización indicada')
  }
  if (stage.status !== 'ADMIN_REVIEW') {
    throw new Error('La etapa ya no está pendiente de revisión admin')
  }

  try {
    await prisma.$transaction([
      prisma.stage.update({
        where: { id: stageId },
        data: { status: 'REVISION' },
      }),
      prisma.adminNote.create({
        data: {
          organizationId: orgId,
          content: `[Rechazo etapa ${stage.number} — ${stage.name}] ${feedback.trim()}`,
        },
      }),
    ])
    console.info(`[admin:actions] etapa rechazada — stageId=${stageId} org=${orgId} stage=${stage.number}`)
  } catch (err) {
    console.error('[admin:actions] error rechazando etapa:', err instanceof Error ? err.message : err)
    throw new Error('No se pudo procesar el rechazo. Intentá de nuevo.')
  }

  revalidatePath('/revision')
  revalidatePath(`/clientes/${orgId}`)
}

// ── Configuración de agentes ───────────────────────────────────────────────────

const VALID_AUTOMATION_LEVELS: AutomationLevel[] = ['MANUAL', 'SEMI_AUTO', 'AUTO']

/**
 * Crea o actualiza la configuración de un agente (upsert por agentNumber).
 * Valida prompt (max 10000 chars) y automationLevel.
 * name y description se toman de los defaults del servidor (nunca del cliente).
 */
export async function updateAgentConfig(formData: FormData): Promise<void> {
  // Importación lazy para evitar circular si agent-defaults usa @qautiva/db
  const { getAgentDefault } = await import('@/lib/agent-defaults')

  const { userId } = await requireAdminSession()

  const agentNumber = formData.get('agentNumber')
  const prompt = formData.get('prompt')
  const automationLevel = formData.get('automationLevel')

  if (typeof agentNumber !== 'string' || !agentNumber.trim()) {
    throw new Error('agentNumber requerido')
  }
  const agentNum = parseInt(agentNumber, 10)
  if (isNaN(agentNum) || agentNum < 1 || agentNum > 6) {
    throw new Error('agentNumber debe ser entre 1 y 6')
  }

  if (typeof prompt !== 'string' || !prompt.trim()) {
    throw new Error('El prompt es requerido')
  }
  // Validar longitud sobre el valor ya trimeado (consistente con lo que se persiste)
  const promptTrimmed = prompt.trim()
  if (promptTrimmed.length > 10000) {
    throw new Error('El prompt no puede superar los 10000 caracteres')
  }

  if (
    typeof automationLevel !== 'string' ||
    !VALID_AUTOMATION_LEVELS.includes(automationLevel as AutomationLevel)
  ) {
    throw new Error('Nivel de automatización inválido')
  }

  // name y description vienen de los defaults del servidor — no del FormData (seguridad)
  const agentDefault = getAgentDefault(agentNum)
  const name = agentDefault?.name ?? `Agente ${agentNum}`
  const description = agentDefault?.description ?? ''

  // Capturar estado previo para el audit trail (select explícito para no loguear campos futuros)
  const previousAgent = await prisma.agentConfig.findUnique({
    where: { agentNumber: agentNum },
    select: { agentNumber: true, automationLevel: true, prompt: true, name: true, description: true },
  })

  try {
    await prisma.agentConfig.upsert({
      where: { agentNumber: agentNum },
      create: {
        agentNumber: agentNum,
        name,
        description,
        automationLevel: automationLevel as AutomationLevel,
        prompt: promptTrimmed,
      },
      update: {
        automationLevel: automationLevel as AutomationLevel,
        prompt: promptTrimmed,
      },
    })
    console.info(`[admin:actions] agente actualizado — agentNumber=${agentNum}`)
  } catch (err) {
    console.error(`[admin:actions] error actualizando agente agentNumber=${agentNum}:`, err instanceof Error ? err.message : err)
    throw new Error('No se pudo guardar la configuración. Intentá de nuevo.')
  }

  logAudit({
    userId,
    action: 'CONFIG_UPDATE',
    targetEntity: 'AgentConfig',
    targetId: agentNum.toString(),
    previousState: previousAgent,
    newState: { agentNumber: agentNum, automationLevel, prompt: promptTrimmed, name, description },
  })

  // Revalidar lista y el patrón de todas las rutas de detalle
  revalidatePath('/agentes')
  revalidatePath('/agentes/[id]', 'page')
}

// ── Moderación de medios del marketplace ───────────────────────────────────────

/**
 * Aprueba un medio: PENDING_REVIEW → ACTIVE.
 * Solo ejecutable por admins autenticados.
 */
export async function approveMedia(formData: FormData): Promise<void> {
  await requireAdminSession()

  const mediumId = formData.get('mediumId')
  if (typeof mediumId !== 'string' || !mediumId.trim()) {
    throw new Error('mediumId requerido')
  }

  const medium = await prisma.medium.findUnique({
    where: { id: mediumId },
    select: { id: true, status: true, name: true },
  })
  if (!medium) {
    throw new Error('Medio no encontrado')
  }
  if (medium.status !== 'PENDING_REVIEW') {
    throw new Error('El medio ya no está pendiente de revisión')
  }

  try {
    // Optimistic lock: status=PENDING_REVIEW en el WHERE previene doble procesamiento.
    await prisma.medium.update({
      where: { id: mediumId, status: 'PENDING_REVIEW' },
      data: { status: 'ACTIVE' },
    })
    console.info(`[admin:actions] medio aprobado — mediumId=${mediumId} name="${medium.name}"`)
  } catch (err) {
    if (
      err instanceof Error &&
      'code' in err &&
      (err as { code: string }).code === 'P2025'
    ) {
      throw new Error('El medio ya fue procesado por otro admin')
    }
    console.error('[admin:actions] error aprobando medio:', err instanceof Error ? err.message : err)
    throw new Error('No se pudo aprobar el medio. Intentá de nuevo.')
  }

  revalidatePath('/medios')
  revalidatePath(`/medios/${mediumId}`)
}

/**
 * Rechaza un medio: PENDING_REVIEW → REJECTED, guarda motivo.
 * Solo ejecutable por admins autenticados.
 */
export async function rejectMedia(formData: FormData): Promise<void> {
  await requireAdminSession()

  const mediumId = formData.get('mediumId')
  const reason = formData.get('reason')

  if (typeof mediumId !== 'string' || !mediumId.trim()) {
    throw new Error('mediumId requerido')
  }
  if (typeof reason !== 'string' || !reason.trim()) {
    throw new Error('El motivo de rechazo es requerido')
  }
  if (reason.trim().length > 1000) {
    throw new Error('El motivo no puede superar los 1000 caracteres')
  }

  const medium = await prisma.medium.findUnique({
    where: { id: mediumId },
    select: { id: true, status: true, name: true },
  })
  if (!medium) {
    throw new Error('Medio no encontrado')
  }
  if (medium.status !== 'PENDING_REVIEW') {
    throw new Error('El medio ya no está pendiente de revisión')
  }

  try {
    // Optimistic lock: status=PENDING_REVIEW en el WHERE previene doble procesamiento.
    await prisma.medium.update({
      where: { id: mediumId, status: 'PENDING_REVIEW' },
      data: { status: 'REJECTED', rejectionReason: reason.trim() },
    })
    console.info(`[admin:actions] medio rechazado — mediumId=${mediumId} name="${medium.name}"`)
  } catch (err) {
    if (
      err instanceof Error &&
      'code' in err &&
      (err as { code: string }).code === 'P2025'
    ) {
      throw new Error('El medio ya fue procesado por otro admin')
    }
    console.error('[admin:actions] error rechazando medio:', err instanceof Error ? err.message : err)
    throw new Error('No se pudo rechazar el medio. Intentá de nuevo.')
  }

  revalidatePath('/medios')
  revalidatePath(`/medios/${mediumId}`)
}

// ── Configuración de interview prompt ─────────────────────────────────────────

/**
 * Crea o actualiza el interviewPrompt de un agente (upsert por agentNumber).
 * Campo opcional: si se envía vacío, se persiste como null.
 */
export async function updateInterviewPrompt(formData: FormData): Promise<void> {
  const { getAgentDefault } = await import('@/lib/agent-defaults')

  const { userId } = await requireAdminSession()

  const agentNumberRaw = formData.get('agentNumber')
  const interviewPromptRaw = formData.get('interviewPrompt')

  if (typeof agentNumberRaw !== 'string' || !agentNumberRaw.trim()) {
    throw new Error('agentNumber requerido')
  }
  const agentNum = parseInt(agentNumberRaw, 10)
  if (isNaN(agentNum) || agentNum < 1 || agentNum > 6) {
    throw new Error('agentNumber debe ser entre 1 y 6')
  }

  if (typeof interviewPromptRaw !== 'string') {
    throw new Error('interviewPrompt inválido')
  }
  const interviewPromptTrimmed = interviewPromptRaw.trim()
  if (interviewPromptTrimmed.length > 15000) {
    throw new Error('El interview prompt no puede superar los 15000 caracteres')
  }

  const agentDefault = getAgentDefault(agentNum)
  const name = agentDefault?.name ?? `Agente ${agentNum}`
  const description = agentDefault?.description ?? ''

  const previousAgent = await prisma.agentConfig.findUnique({
    where: { agentNumber: agentNum },
    select: { interviewPrompt: true },
  })

  try {
    await prisma.agentConfig.upsert({
      where: { agentNumber: agentNum },
      create: {
        agentNumber: agentNum,
        name,
        description,
        // Usar el prompt default para no dejar el agente con prompt vacío si se crea aquí
        prompt: agentDefault?.defaultPrompt ?? '',
        interviewPrompt: interviewPromptTrimmed || null,
      },
      update: {
        interviewPrompt: interviewPromptTrimmed || null,
      },
    })
    console.info(`[admin:actions] interviewPrompt actualizado — agentNumber=${agentNum}`)
  } catch (err) {
    console.error(`[admin:actions] error actualizando interviewPrompt agentNumber=${agentNum}:`, err instanceof Error ? err.message : err)
    throw new Error('No se pudo guardar el interview prompt. Intentá de nuevo.')
  }

  logAudit({
    userId,
    action: 'CONFIG_UPDATE',
    targetEntity: 'AgentConfig',
    targetId: agentNum.toString(),
    previousState: { interviewPrompt: previousAgent?.interviewPrompt ?? null },
    newState: { interviewPrompt: interviewPromptTrimmed || null },
  })

  revalidatePath('/agentes', 'layout')
}

// ── Configuración de output template ──────────────────────────────────────────

/**
 * Crea o actualiza el outputTemplate de un agente (upsert por agentNumber).
 * El valor debe ser un JSON válido. Si se envía vacío, se persiste como null.
 */
export async function updateOutputTemplate(formData: FormData): Promise<void> {
  const { getAgentDefault } = await import('@/lib/agent-defaults')

  const { userId } = await requireAdminSession()

  const agentNumberRaw = formData.get('agentNumber')
  const outputTemplateRaw = formData.get('outputTemplate')

  if (typeof agentNumberRaw !== 'string' || !agentNumberRaw.trim()) {
    throw new Error('agentNumber requerido')
  }
  const agentNum = parseInt(agentNumberRaw, 10)
  if (isNaN(agentNum) || agentNum < 1 || agentNum > 6) {
    throw new Error('agentNumber debe ser entre 1 y 6')
  }

  if (typeof outputTemplateRaw !== 'string') {
    throw new Error('outputTemplate inválido')
  }

  const outputTemplateTrimmed = outputTemplateRaw.trim()
  let parsedTemplate: unknown = null

  if (outputTemplateTrimmed) {
    try {
      parsedTemplate = JSON.parse(outputTemplateTrimmed)
    } catch {
      throw new Error('El output template no es un JSON válido. Revisá la sintaxis.')
    }
  }

  const agentDefault = getAgentDefault(agentNum)
  const name = agentDefault?.name ?? `Agente ${agentNum}`
  const description = agentDefault?.description ?? ''

  const previousAgent = await prisma.agentConfig.findUnique({
    where: { agentNumber: agentNum },
    select: { outputTemplate: true },
  })

  try {
    await prisma.agentConfig.upsert({
      where: { agentNumber: agentNum },
      create: {
        agentNumber: agentNum,
        name,
        description,
        // Usar el prompt default para no dejar el agente con prompt vacío si se crea aquí
        prompt: agentDefault?.defaultPrompt ?? '',
        outputTemplate: parsedTemplate ?? Prisma.JsonNull,
      },
      update: {
        outputTemplate: parsedTemplate ?? Prisma.JsonNull,
      },
    })
    console.info(`[admin:actions] outputTemplate actualizado — agentNumber=${agentNum}`)
  } catch (err) {
    console.error(`[admin:actions] error actualizando outputTemplate agentNumber=${agentNum}:`, err instanceof Error ? err.message : err)
    throw new Error('No se pudo guardar el output template. Intentá de nuevo.')
  }

  logAudit({
    userId,
    action: 'CONFIG_UPDATE',
    targetEntity: 'AgentConfig',
    targetId: agentNum.toString(),
    previousState: { outputTemplate: previousAgent?.outputTemplate ?? null },
    newState: { outputTemplate: parsedTemplate },
  })

  revalidatePath('/agentes', 'layout')
}

// ── StageWelcome ────────────────────────────────────────────────────────────────

const VALID_STAGE_KEYS = ['DISCOVERY', 'RESEARCH', 'BRAND', 'WEBSITE', 'CAMPAIGNS', 'MEDIA'] as const
type StageKey = (typeof VALID_STAGE_KEYS)[number]

function assertValidStageKey(key: unknown): asserts key is StageKey {
  if (typeof key !== 'string' || !(VALID_STAGE_KEYS as readonly string[]).includes(key)) {
    throw new Error(`stageKey inválido. Debe ser uno de: ${VALID_STAGE_KEYS.join(', ')}`)
  }
}

/**
 * Devuelve todas las StageWelcome, ordenadas por stageKey (orden canónico).
 */
export async function getStageWelcomes(): Promise<StageWelcome[]> {
  await requireAdminSession()
  const rows = await prisma.stageWelcome.findMany()
  const order = VALID_STAGE_KEYS
  return rows.sort((a, b) => order.indexOf(a.stageKey as StageKey) - order.indexOf(b.stageKey as StageKey))
}

/**
 * Crea o actualiza la pantalla de bienvenida de una etapa (upsert por stageKey).
 */
export async function upsertStageWelcome(formData: FormData): Promise<void> {
  const { userId } = await requireAdminSession()

  const stageKey = formData.get('stageKey')
  assertValidStageKey(stageKey)

  const title = formData.get('title')
  const description = formData.get('description')
  const estimatedTime = formData.get('estimatedTime')
  const whatYouGet = formData.get('whatYouGet')
  const icon = formData.get('icon')
  const fastTrackText = formData.get('fastTrackText')

  if (typeof title !== 'string' || !title.trim()) throw new Error('Título requerido')
  if (title.trim().length > 200) throw new Error('Título demasiado largo (máx. 200 caracteres)')
  if (typeof description !== 'string' || !description.trim()) throw new Error('Descripción requerida')
  if (description.trim().length > 2000) throw new Error('Descripción demasiado larga (máx. 2000 caracteres)')
  if (typeof estimatedTime !== 'string' || !estimatedTime.trim()) throw new Error('Tiempo estimado requerido')
  if (estimatedTime.trim().length > 50) throw new Error('Tiempo estimado demasiado largo (máx. 50 caracteres)')
  if (typeof whatYouGet !== 'string' || !whatYouGet.trim()) throw new Error('Campo "Qué obtenés" requerido')
  if (whatYouGet.trim().length > 500) throw new Error('Campo "Qué obtenés" demasiado largo (máx. 500 caracteres)')
  if (typeof fastTrackText === 'string' && fastTrackText.trim().length > 300) {
    throw new Error('Texto fast-track demasiado largo (máx. 300 caracteres)')
  }

  const data = {
    title: title.trim(),
    description: description.trim(),
    estimatedTime: estimatedTime.trim(),
    whatYouGet: whatYouGet.trim(),
    icon: typeof icon === 'string' && icon.trim() ? icon.trim() : null,
    fastTrackText: typeof fastTrackText === 'string' && fastTrackText.trim() ? fastTrackText.trim() : null,
  }

  const previousWelcome = await prisma.stageWelcome.findUnique({ where: { stageKey } })

  try {
    await prisma.stageWelcome.upsert({
      where: { stageKey },
      create: { stageKey, ...data },
      update: data,
    })
    console.info(`[admin:actions] stageWelcome upserted — stageKey=${stageKey}`)
  } catch (err) {
    console.error(`[admin:actions] error upserting stageWelcome stageKey=${stageKey}:`, err instanceof Error ? err.message : err)
    throw new Error('No se pudo guardar la pantalla de bienvenida. Intentá de nuevo.')
  }

  logAudit({
    userId,
    action: 'CONFIG_UPDATE',
    targetEntity: 'StageWelcome',
    targetId: stageKey,
    previousState: previousWelcome,
    newState: { stageKey, ...data },
  })

  revalidatePath('/bienvenidas')
}
