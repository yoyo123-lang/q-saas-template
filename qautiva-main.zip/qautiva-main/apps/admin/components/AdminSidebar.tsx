'use client'

import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  AlertTriangle,
  Bot,
  Building2,
  CreditCard,
  Globe,
  LayoutDashboard,
  LayoutTemplate,
  Layers,
  ListChecks,
  MessageSquare,
  MonitorSmartphone,
  Newspaper,
  Settings,
  ShoppingCart,
  Tag,
  Users,
} from 'lucide-react'

type NavItem = {
  label: string
  href: string
  icon: React.ElementType
  badge?: number
}

function buildNavItems(reviewQueueCount: number): NavItem[] {
  return [
  { label: 'Dashboard', href: '/', icon: LayoutDashboard },
  { label: 'Clientes', href: '/clientes', icon: Users },
  { label: 'Cola de revisión', href: '/revision', icon: ListChecks, badge: reviewQueueCount > 0 ? reviewQueueCount : undefined },
  { label: 'Sesiones', href: '/sesiones', icon: AlertTriangle },
  { label: 'Agentes', href: '/agentes', icon: Bot },
  { label: 'Industrias', href: '/industrias', icon: Building2 },
  { label: 'Bienvenidas', href: '/bienvenidas', icon: MonitorSmartphone },
  { label: 'Templates', href: '/templates', icon: LayoutTemplate },
  { label: 'Cola Stitch', href: '/templates/cola', icon: Layers },
  { label: 'Medios', href: '/medios', icon: Newspaper },
  { label: 'Órdenes', href: '/ordenes', icon: ShoppingCart },
  { label: 'Dominios', href: '/dominios', icon: Globe },
  { label: 'Precios TLD', href: '/dominios/pricing', icon: Tag },
  { label: 'Saldo OpenSRS', href: '/dominios/balance', icon: CreditCard },
  { label: 'Bot Telegram', href: '/telegram', icon: MessageSquare },
  { label: 'Configuración', href: '/configuracion', icon: Settings },
  ]
}

function NavLink({ item, isActive }: { item: NavItem; isActive: boolean }) {
  const Icon = item.icon

  return (
    <Link
      href={item.href}
      className={`
        relative flex items-center gap-3 px-4 py-2.5 text-sm font-medium
        transition-colors duration-200
        ${isActive
          ? 'text-[#8B5CF6]'
          : 'text-[#94A3B8] hover:text-[#F8FAFC]'
        }
      `}
    >
      {isActive && (
        <span
          className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-[#8B5CF6] rounded-r-full"
          aria-hidden="true"
        />
      )}
      <Icon size={18} aria-hidden="true" />
      <span className="flex-1">{item.label}</span>
      {item.badge !== undefined && (
        <span className="flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-[#EF4444] text-white text-[10px] font-bold leading-none">
          {item.badge}
        </span>
      )}
    </Link>
  )
}

export function AdminSidebar({ reviewQueueCount = 0 }: { reviewQueueCount?: number }) {
  const pathname = usePathname()
  const navItems = buildNavItems(reviewQueueCount)

  function isItemActive(item: NavItem): boolean {
    if (item.href === '/') return pathname === '/'
    return pathname === item.href || pathname.startsWith(`${item.href}/`)
  }

  return (
    <aside
      className="flex flex-col w-[280px] min-h-screen border-r border-[#1E293B] bg-[#0B0F1A] flex-shrink-0"
      aria-label="Navegación del admin"
    >
      {/* Logo + badge Admin */}
      <div className="px-4 pt-5 pb-4">
        <div className="flex items-center gap-2">
          <Image src="/logo.png" alt="Qautiva Marketing" width={480} height={160} className="h-32 w-auto" priority />
          <span className="px-2 py-0.5 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#A78BFA] text-[10px] font-medium">
            Admin
          </span>
        </div>
      </div>

      {/* Separador */}
      <div className="mx-4 mb-2 h-px bg-[#1E293B]" />

      {/* Navegación */}
      <nav className="flex-1 flex flex-col gap-0.5 py-2">
        {navItems.map((item) => (
          <NavLink key={item.href} item={item} isActive={isItemActive(item)} />
        ))}
      </nav>
    </aside>
  )
}
