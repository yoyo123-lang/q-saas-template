import { prisma } from '@qautiva/db'
import { notFound } from 'next/navigation'
import { StitchEditor } from './_components/StitchEditor'

export default async function EditarTemplatePage({ params }: { params: { id: string } }) {
  const template = await prisma.webTemplate.findUnique({
    where: { id: params.id },
    select: {
      id: true,
      name: true,
      source: true,
      stitchProjectId: true,
      stitchScreenId: true,
      htmlBase: true,
    },
  })

  if (!template) notFound()

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold text-white mb-6">
        Editar con Stitch: {template.name}
      </h1>
      <StitchEditor template={template} />
    </div>
  )
}
