'use client'

import { useCallback, useEffect, useState } from 'react'
import type { StrategicBrief } from '@/app/_lib/interview/types'

/** Ensures value is always an array — handles null, undefined, AND wrong types from AI output */
function safeArray<T>(value: T[] | null | undefined): T[] {
  return Array.isArray(value) ? value : []
}

type Props = {
  sessionId: string
}

/**
 * Carga y renderiza el Brief Estratégico generado por El Estratega.
 * Se muestra en la pantalla de COMPLETED de la etapa 1.
 */
export function BriefView({ sessionId }: Props) {
  const [brief, setBrief] = useState<StrategicBrief | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/interview/sessions/${sessionId}/brief`)
      if (!res.ok) {
        const err = await res.json().catch(() => null)
        setError(err?.error ?? 'No se pudo cargar el Brief')
        return
      }
      const data = await res.json()
      setBrief(data.brief as StrategicBrief)
    } catch {
      setError('No se pudo cargar el Brief')
    } finally {
      setLoading(false)
    }
  }, [sessionId])

  useEffect(() => {
    load()
  }, [load])

  if (loading) {
    return (
      <div className="mt-6 flex items-center gap-2 text-[#64748B] text-sm">
        <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M21 12a9 9 0 1 1-6.219-8.56" />
        </svg>
        Cargando Brief...
      </div>
    )
  }

  if (error || !brief) {
    return (
      <div className="mt-6">
        <p className="text-[#64748B] text-sm mb-3">{error || 'Brief no disponible'}</p>
        <button
          onClick={load}
          className="px-4 py-1.5 text-sm bg-[#1E293B] text-white rounded-lg hover:bg-[#334155] transition-colors"
        >
          Reintentar
        </button>
      </div>
    )
  }

  const estrategiaLabels: Record<string, string> = {
    bajo_costo: 'Bajo costo',
    diferenciacion: 'Diferenciación',
    enfoque: 'Enfoque en nicho',
  }

  return (
    <div className="mt-8 space-y-6">
      <div className="flex items-center gap-3 mb-2">
        <div className="h-px flex-1 bg-[#1E293B]" />
        <h3 className="text-[#64748B] text-xs font-medium uppercase tracking-wider">
          Brief Estratégico
        </h3>
        <div className="h-px flex-1 bg-[#1E293B]" />
      </div>

      {/* Mensaje central — destacado */}
      <div className="bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 rounded-xl p-5">
        <p className="text-[#8B5CF6] text-xs font-medium uppercase tracking-wide mb-2">
          Mensaje central
        </p>
        <p className="text-white text-xl font-semibold leading-snug">
          {brief.direccionComunicacional?.mensajeCentral ?? ''}
        </p>
        <p className="text-[#94A3B8] text-sm mt-2">{brief.direccionComunicacional?.tonoSugerido ?? ''}</p>
      </div>

      {/* Posicionamiento */}
      <BriefSection title="Posicionamiento">
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-[#8B5CF6]/15 text-[#A78BFA]">
            {estrategiaLabels[brief.posicionamiento?.estrategia ?? ''] ?? brief.posicionamiento?.estrategia ?? ''}
          </span>
        </div>
        <BriefRow label="Nicho específico" value={brief.posicionamiento?.nichoEspecifico ?? ''} />
        <BriefRow label="Ventaja competitiva" value={brief.posicionamiento?.ventajaCompetitiva ?? ''} />
        <BriefRow label="Justificación" value={brief.posicionamiento?.justificacion ?? ''} />
        {safeArray(brief.posicionamiento?.riesgos).length > 0 && (
          <BriefList label="Riesgos" items={safeArray(brief.posicionamiento?.riesgos)} />
        )}
      </BriefSection>

      {/* Negocio */}
      <BriefSection title="Tu negocio">
        <BriefRow label="Descripción" value={brief.negocio?.descripcion ?? ''} />
        <BriefRow label="Estado" value={brief.negocio?.estado ?? ''} />
        {brief.negocio?.antiguedad && (
          <BriefRow label="Antigüedad" value={brief.negocio.antiguedad} />
        )}
        <BriefRow label="Recursos disponibles" value={brief.negocio?.recursosDisponibles ?? ''} />
        {safeArray(brief.negocio?.restricciones).length > 0 && (
          <BriefList label="Restricciones" items={safeArray(brief.negocio?.restricciones)} />
        )}
      </BriefSection>

      {/* Audiencia */}
      <BriefSection title="Tu cliente">
        <BriefRow label="Perfil" value={brief.audiencia?.perfilCliente ?? ''} />
        <BriefRow label="Cómo compra" value={brief.audiencia?.comoCompra ?? ''} />
        <BriefRow label="Dolor principal" value={brief.audiencia?.dolorPrincipal ?? ''} />
        <BriefRow label="Canal de adquisición" value={brief.audiencia?.canalAdquisicion ?? ''} />
      </BriefSection>

      {/* Mercado */}
      <BriefSection title="Mercado">
        <BriefRow label="Zona geográfica" value={brief.mercado?.zonaGeografica ?? ''} />
        <BriefRow label="Alcance" value={brief.mercado?.alcance ?? ''} />
        {safeArray(brief.mercado?.competidores).length > 0 && (
          <div className="mt-3">
            <p className="text-[#64748B] text-xs mb-2">Competidores</p>
            <div className="space-y-2">
              {safeArray(brief.mercado?.competidores).map((c, i) => (
                <div key={i} className="bg-[#0B0F1A] rounded-lg p-3">
                  <p className="text-white text-sm font-medium">{c.nombre}</p>
                  <p className="text-[#10B981] text-xs mt-1">✓ {c.fortaleza}</p>
                  <p className="text-[#EF4444] text-xs mt-0.5">✗ {c.debilidad}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        {safeArray(brief.mercado?.espaciosVacios).length > 0 && (
          <BriefList label="Espacios vacíos" items={safeArray(brief.mercado?.espaciosVacios)} />
        )}
        {safeArray(brief.mercado?.tendencias).length > 0 && (
          <BriefList label="Tendencias" items={safeArray(brief.mercado?.tendencias)} />
        )}
      </BriefSection>

      {/* Dirección comunicacional */}
      <BriefSection title="Dirección comunicacional">
        {safeArray(brief.direccionComunicacional?.territoriosTematicos).length > 0 && (
          <BriefList
            label="Territorios temáticos"
            items={safeArray(brief.direccionComunicacional?.territoriosTematicos)}
          />
        )}
        {safeArray(brief.direccionComunicacional?.queNoDecir).length > 0 && (
          <BriefList
            label="Qué NO decir"
            items={safeArray(brief.direccionComunicacional?.queNoDecir)}
            variant="negative"
          />
        )}
        <BriefRow label="Rango de precios a comunicar" value={brief.direccionComunicacional?.rangoPrecios ?? ''} />
      </BriefSection>

      {/* Decisiones pendientes */}
      {safeArray(brief.decisionesPendientes).length > 0 && (
        <BriefSection title="Decisiones pendientes">
          <div className="space-y-4">
            {safeArray(brief.decisionesPendientes).map((d, i) => (
              <div key={i}>
                <p className="text-white text-sm font-medium mb-2">{d.tema}</p>
                <div className="space-y-2">
                  {safeArray(d.opciones).map((o, j) => (
                    <div key={j} className="bg-[#0B0F1A] rounded-lg p-3">
                      <p className="text-[#A78BFA] text-xs font-medium">{o.opcion}</p>
                      <p className="text-[#10B981] text-xs mt-1">+ {o.pro}</p>
                      <p className="text-[#EF4444] text-xs mt-0.5">- {o.contra}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </BriefSection>
      )}
    </div>
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function BriefSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <h4 className="text-white text-sm font-semibold mb-4">{title}</h4>
      <div className="space-y-3">{children}</div>
    </div>
  )
}

function BriefRow({ label, value }: { label: string; value: string | string[] }) {
  // No renderizar si no hay contenido
  if (!value || (Array.isArray(value) && value.length === 0) || (typeof value === 'string' && value.trim() === '')) {
    return null
  }
  return (
    <div>
      <p className="text-[#64748B] text-xs mb-0.5">{label}</p>
      <p className="text-[#94A3B8] text-sm leading-relaxed">{Array.isArray(value) ? value.join(', ') : value}</p>
    </div>
  )
}

function BriefList({
  label,
  items,
  variant = 'neutral',
}: {
  label: string
  items: string[]
  variant?: 'neutral' | 'negative'
}) {
  const safeItems = safeArray(items)
  if (safeItems.length === 0) return null
  return (
    <div>
      <p className="text-[#64748B] text-xs mb-1.5">{label}</p>
      <ul className="space-y-1">
        {safeItems.map((item, i) => (
          <li key={i} className="flex items-start gap-2">
            <span
              className={`flex-shrink-0 mt-1.5 w-1 h-1 rounded-full ${
                variant === 'negative' ? 'bg-[#EF4444]' : 'bg-[#8B5CF6]'
              }`}
              aria-hidden="true"
            />
            <span className="text-[#94A3B8] text-sm leading-relaxed">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
