# Modelo de Negocio

> Este archivo documenta las reglas de negocio del proyecto.
> Es la fuente de verdad para los roles de revisión de capa 2 (Business Logic, Data/Analytics).
> Sin este archivo completo, esos roles no pueden funcionar.

---

## Tipo de proyecto

- [x] SaaS con billing
- [x] Marketplace (marketplace de medios, en desarrollo)

---

## Propuesta de valor

### ¿Qué problema resuelve?

Emprendedores y negocios que necesitan presencia digital completa (marca, web, campañas, medios) pero no tienen tiempo, dinero ni conocimiento para contratar agencias tradicionales o hacerlo por cuenta propia.

### ¿Para quién? (segmentos de usuario)

Emprendedores no-técnicos que quieren lanzar o profesionalizar su negocio digital. No saben de branding, marketing ni tecnología. Priorizan facilidad de uso sobre control granular.

### ¿Cómo se diferencia de alternativas?

- **Conocimiento de negocio empaquetado**: no es "IA que hace cosas". Son frameworks probados de estrategia, marca y comunicación convertidos en templates que los agentes ejecutan.
- **El usuario no construye de cero**: se apalanca en templates pre-hechos (estrategia competitiva, manual de marca, manual de comunicación, web). La IA aplica reglas pre-hechas, no improvisa.
- **Llave en mano**: el resultado es un negocio digital completo (marca + web + campañas + medios), no piezas sueltas.
- **Agentes de IA especializados**: El Estratega, El Analista, El Director Creativo — cada uno experto en su etapa.

---

## Monetización

### Modelo de ingresos

**Utility pricing con descuento por compromiso.** Tres fuentes de ingreso:

1. **Principal — Créditos por uso de agentes IA (USD)**
   - El metering interno es por tokens (1 token Qautiva = 1 token del provider)
   - La UX muestra **créditos en USD** y/o **entregables restantes estimados** — el usuario nunca ve tokens
   - Precio diferenciado por dos ejes:
     - **Fuente de API key**: BYOK (el usuario trae su key) vs Qautiva-hosted (Qautiva provee la infra)
     - **Modalidad de plan**: Prepaid / Monthly / Yearly
   - BYOK paga por el orquestador + los templates/frameworks de negocio (no por la infra de IA)

2. **Secundario — Venta de dominios**
   - Registro y renovación vía OpenSRS con margen sobre el costo

3. **Futuro — Comisión sobre inversión publicitaria** [POR DEFINIR — requiere definir % y lógica de lectura de spend desde Google/Meta Ads API]

### Planes y límites

| Plan | Crédito base | Precio por token hosted | Precio por token BYOK | Excedente |
|------|-------------|------------------------|-----------------------|-----------|
| FREE_TRIAL | Limitado (configurable desde admin) | N/A | N/A | No — se bloquea |
| PREPAID | Recarga manual (balanceUsd) | [POR DEFINIR — tests de consumo] | [POR DEFINIR] | No aplica — consume saldo |
| MONTHLY | Incluido en suscripción | Descuento vs prepaid | Descuento vs prepaid | Se cobra aparte |
| YEARLY | Mayor crédito incluido | Mayor descuento | Mayor descuento | Se cobra aparte |

> **Nota**: Los precios exactos están pendientes de tests de consumo real punta a punta de un lanzamiento completo.

### Ciclo de billing

- Período: prepaid (sin ciclo) / mensual / anual
- Trial: sí — tokens limitados + duración en días, ambos configurables desde admin sin redeploy
- Qué pasa al acabarse los créditos del trial: **se bloquea el acceso a los agentes**. El usuario debe elegir un plan para continuar
- Qué pasa al vencer el trial (por tiempo): **se fuerza a elegir plan o se bloquea**
- Qué pasa al acabarse los créditos de un plan pago: se cobra excedente (monthly/yearly) o se bloquea hasta recarga (prepaid)
- Qué pasa al downgrade: datos se mantienen, features del plan superior se deshabilitan [POR DEFINIR — política de retención exacta]
- Qué pasa si falla el pago: [POR DEFINIR — requiere pasarela integrada]
- Pasarela de pago: [POR DEFINIR — Stripe recomendado por soporte internacional]

---

## Reglas de negocio

> Estas son las reglas que el CÓDIGO debe cumplir. El Business Logic Reviewer valida contra esta lista.

### Autenticación y acceso

- Quién puede registrarse: cualquier persona con email o cuenta Google
- Métodos de login:
  - **Portal**: Google OAuth + email/password
  - **Admin**: solo Google OAuth (restringido a admins)
- Roles de sistema (`UserRole`):
  - `ADMIN` — acceso total al backoffice. Se valida por `app_metadata.role` en JWT
  - `CLIENT` — usuario del portal
- Roles de equipo (`TeamRole`):
  - `OWNER` — creado automáticamente al registrarse. Full control del team
  - `ADMIN` — mismos permisos que OWNER (actualmente sin diferenciación)
  - `MEMBER` — solo lectura

### Reglas por plan/rol

1. CUANDO usuario se registra ENTONCES se crea automáticamente: UserProfile → Team → TeamMember(OWNER) → BillingAccount(FREE_TRIAL)
2. CUANDO créditos del trial llegan a 0 ENTONCES se bloquean los agentes IA, el usuario ve pantalla de selección de plan
3. CUANDO trial expira por tiempo ENTONCES mismo comportamiento que créditos agotados
4. CUANDO usuario elige plan pago ENTONCES se desbloquean agentes y se aplica la tabla de precios correspondiente
5. CUANDO créditos de plan Monthly/Yearly se agotan ENTONCES se cobra excedente al precio del plan
6. CUANDO créditos de plan Prepaid se agotan ENTONCES se bloquean agentes hasta recarga
7. CUANDO usuario usa BYOK ENTONCES el costo por token es menor (paga solo orquestador + templates)
8. CUANDO usuario usa Qautiva-hosted ENTONCES el costo por token incluye infra + orquestador + templates

### Reglas de dominio específicas

1. **Ingreso flexible a etapas**: el cliente puede ingresar en cualquier punto del proceso (tiene logo pero no estrategia, tiene web pero no marca, etc.). Una entrevista de intake inicial evalúa qué tiene y qué necesita, activando solo las etapas relevantes.
2. Un Project tiene 6 etapas posibles (DISCOVERY → MARKET_STUDY → BRAND → WEBSITE → ADS → MEDIA), pero cada una puede estar en estado: `active` / `skip` / `provided_by_client`
3. Solo un Deliverable activo por stage (`isActive=true`); los anteriores quedan como historial
4. Las órdenes del marketplace tienen 3 días para ser aceptadas (`expiresAt`); si expiran, se cancelan automáticamente
5. El deadline de entrega se calcula como `acceptedAt + product.deliveryDays`
6. Dominios tienen renovación automática configurable (`autoRenew`)
7. API keys de integraciones encriptadas con AES-256-GCM en DB (`IntegrationConfig.encryptedKey`)
8. API keys del usuario (BYOK) encriptadas con `ENCRYPTION_SECRET` separado
9. El provider/modelo de IA es configurable desde admin con cache de 5 min — cambios sin redeploy
10. Si Serper no tiene key configurada, el Estudio de Mercado se genera sin datos de internet (degradación elegante)
11. Todo el metering de tokens se registra en `TokenUsage` con `costUsd` calculado — es la base del billing

### Principio rector de UX

> **La facilidad de uso es prioridad sobre todo.** El usuario target es un emprendedor no-técnico. Cada decisión de producto debe evaluarse con: "¿un emprendedor que no sabe de tecnología puede hacer esto sin ayuda?"

---

## Entidades de dominio

```
Team (organización del usuario)
  ├── TeamMember (OWNER / ADMIN / MEMBER)
  ├── BillingAccount (1:1 con Team)
  │     ├── plan: FREE_TRIAL | PREPAID | MONTHLY | YEARLY
  │     ├── balanceUsd: saldo disponible
  │     └── tokensUsed / tokensLimit: metering interno
  ├── Project (negocio digital del cliente)
  │     ├── Stage (1-6, cada una puede ser active/skip/provided_by_client)
  │     │     ├── InterviewSession (entrevista con agente IA)
  │     │     └── Deliverable (Brief, Estudio, Brand, Web, etc.)
  │     ├── TokenUsage (registro de consumo por operación, con costUsd)
  │     ├── AdAccount → Campaign → AdSet → Ad
  │     └── Domain (registro vía OpenSRS)
  └── ApiKey (BYOK del usuario, encriptada)

User
  ├── UserProfile (datos personales)
  └── UserRole (ADMIN | CLIENT)

Marketplace:
  Medium (publicador) → Product → Order (anunciante compra)

Configuración (admin):
  TrialConfig (tokens, duración, provider/modelo IA)
  FeeConfig (precio por token según plan × fuente)
  IntegrationConfig (API keys de servicios, encriptadas)
  TelegramConfig (config del bot)
```

### Invariantes de datos

1. Todo User pertenece a exactamente un Team (vía TeamMember)
2. Todo Team tiene exactamente un BillingAccount
3. No puede haber dos BillingAccounts activas para el mismo Team
4. `TokenUsage.costUsd` nunca puede ser negativo
5. `BillingAccount.balanceUsd` nunca puede ser negativo (las operaciones deben validar saldo antes de ejecutar)
6. Solo un Deliverable por Stage puede tener `isActive=true`
7. Todo TeamMember con rol OWNER es exactamente uno por Team

---

## Métricas clave

> El Data/Analytics Reviewer valida que estas métricas estén siendo medidas.

### Métricas de negocio

| Métrica | Definición | Dónde se mide |
|---------|-----------|---------------|
| Revenue por créditos | Suma de costUsd de TokenUsage por período | TokenUsage + BillingAccount |
| Revenue por dominios | Suma de ventas de dominios - costo OpenSRS | Domain + órdenes |
| Consumo promedio por lanzamiento | Tokens/USD consumidos punta a punta de un proyecto completo | TokenUsage agrupado por Project |
| Tasa de conversión trial→pago | % de trials que pasan a plan pago | BillingAccount (cambio de plan) |
| ARPU | Revenue promedio por usuario activo por mes | TokenUsage + BillingAccount |

### Eventos de funnel

| Evento | Cuándo se dispara | Prioridad |
|--------|-------------------|-----------|
| lead_captured | Formulario de contacto en landing completado | Alta |
| signup_completed | Usuario se registra en el portal | Alta |
| intake_completed | Entrevista de intake finalizada (mapa de necesidades generado) | Alta |
| first_deliverable_generated | Primer entregable generado por un agente | Alta |
| trial_credits_exhausted | Créditos de trial llegan a 0 | Crítica |
| plan_selected | Usuario elige plan pago | Crítica |
| trial_converted | Usuario pasa de trial a plan pago exitosamente | Crítica |
| project_completed | Todas las etapas activas del proyecto finalizadas | Alta |
| domain_purchased | Usuario compra un dominio | Media |

### Alertas de negocio

1. Trial vencido sin conversión a plan pago (posible churn)
2. Créditos agotados sin recarga en 48hs (usuario bloqueado, posible abandono)
3. Saldo de OpenSRS bajo (alerta existente en cron `balance-check`)
4. Error en provider de IA (operaciones fallidas, afecta experiencia directa)

---

## Integraciones externas

| Servicio | Para qué se usa | Criticidad |
|----------|-----------------|------------|
| Supabase | Auth (Google OAuth + email/password) + DB (Postgres vía Prisma) | Alta |
| OpenAI (gpt-4o) | Entrevistas IA + Brand Generator (provider default) | Alta |
| Anthropic (Claude) | Bot Telegram + entrevistas (provider alternativo) | Alta |
| Google Gemini | Generación de imágenes de logos | Alta |
| Serper API | Búsqueda web para Estudio de Mercado | Media (degrada sin key) |
| OpenSRS | Registro y renovación de dominios | Media |
| Google Ads API | Conexión de cuentas publicitarias (OAuth) | Media |
| Meta Ads API | Conexión de cuentas Meta (OAuth + long-lived tokens) | Media |
| Telegram Bot (grammY) | Notificaciones de leads + bot conversacional | Media |
| reCAPTCHA v3 | Protección de formularios (landing + onboarding portal) | Media |
| Resend | Email transaccional | Baja (declarado, sin implementación) |
| GA4 / Meta Pixel | Analytics client-side | Baja (declarado en DB, sin implementación) |

---

## Historial de cambios

| Fecha | Qué cambió | Por qué |
|-------|-----------|---------|
| 2026-03-18 | Documento generado desde cero con /project:descubrimiento | Onboarding de modelo de negocio — decisión de utility pricing en USD con abstracción de tokens, ingreso flexible a etapas |
