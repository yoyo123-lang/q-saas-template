/**
 * Rate limiting simple en memoria.
 *
 * LIMITACIÓN CONOCIDA: Este store es por instancia. En producción multi-instancia
 * (Vercel Serverless con múltiples workers) cada instancia tiene su propio store.
 * Para protección real multi-instancia, migrar a @upstash/ratelimit + @upstash/redis.
 * Ver docs/KNOWN_ISSUES.md para el tracking de esta deuda técnica.
 *
 * Lo que sí protege: ráfagas dentro de la misma instancia (uso típico en dev y
 * despliegues single-instance).
 */

interface RateLimitEntry {
  count: number
  resetAt: number
}

const store = new Map<string, RateLimitEntry>()

/**
 * Elimina entradas expiradas del store para evitar memory leak en instancias
 * de larga vida. Se llama en cada checkRateLimit con probabilidad 1/100.
 */
function gcExpiredEntries(now: number): void {
  for (const [key, entry] of store) {
    if (entry.resetAt < now) store.delete(key)
  }
}

interface RateLimitConfig {
  /** Máximo de intentos permitidos en la ventana */
  limit: number
  /** Duración de la ventana en segundos */
  windowSeconds: number
}

interface RateLimitResult {
  success: boolean
  /** Tiempo en segundos hasta que se resetea el límite */
  retryAfter: number
}

export function checkRateLimit(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now()

  // GC probabilístico: 1% de las llamadas limpia entradas expiradas
  if (Math.random() < 0.01) gcExpiredEntries(now)

  const entry = store.get(key)

  if (!entry || entry.resetAt < now) {
    store.set(key, { count: 1, resetAt: now + config.windowSeconds * 1000 })
    return { success: true, retryAfter: 0 }
  }

  if (entry.count >= config.limit) {
    const retryAfter = Math.ceil((entry.resetAt - now) / 1000)
    return { success: false, retryAfter }
  }

  entry.count++
  return { success: true, retryAfter: 0 }
}

/** 5 intentos de login por IP por minuto */
export const loginRateLimit = (ip: string) =>
  checkRateLimit(`login:${ip}`, { limit: 5, windowSeconds: 60 })

/** 3 intentos de registro por IP por hora */
export const registerRateLimit = (ip: string) =>
  checkRateLimit(`register:${ip}`, { limit: 3, windowSeconds: 3600 })

/** 3 intentos de recuperación de contraseña por IP por hora */
export const recuperarRateLimit = (ip: string) =>
  checkRateLimit(`recuperar:${ip}`, { limit: 3, windowSeconds: 3600 })
