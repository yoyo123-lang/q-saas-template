# Panel de Administración — Especificación Frontend

> Cubre las rutas bajo `/admin`. Acceso restringido a usuarios con `role = ADMIN`.
> Guard en `app/(admin)/layout.tsx` — si role !== ADMIN → redirect a `/dashboard`.

---

## Rutas

| Ruta | Descripción |
|---|---|
| `/admin` | Dashboard general del marketplace |
| `/admin/listados` | Moderación de todos los listados |
| `/admin/listados/[id]` | Revisión individual de un listado |
| `/admin/usuarios` | Gestión de usuarios |
| `/admin/usuarios/[id]` | Perfil detallado de un usuario |

---

## Layout Admin

**Archivo:** `app/(admin)/layout.tsx`

Igual que dashboard pero con `<Sidebar variant="admin" />`.

La sidebar admin tiene badge `"Admin"` junto al logo:
```tsx
<LogoQ showText adminBadge />
```

Nav items admin:
```ts
const adminNavItems = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/admin/listados', label: 'Listados', icon: Package, badge: pendingCount, badgeColor: 'danger' },
  { href: '/admin/usuarios', label: 'Usuarios', icon: Users },
  { href: '/admin/reportes', label: 'Reportes', icon: BarChart3 },
  // divider
  { href: '/admin/configuracion', label: 'Configuración', icon: Settings },
]
```

El badge de "Listados" es un número rojo que se actualiza con el conteo de `PENDING_REVIEW`.

---

## 1. Dashboard Admin (`/admin`)

**Archivo:** `app/(admin)/admin/page.tsx`

### Datos a fetchear

```ts
const [stats, charts, pendingListings, recentActivity, categoryDist] = await Promise.all([
  getMarketplaceStats(),          // totales globales
  getChartsData({ period: '30d' }),
  getListings({ status: 'PENDING_REVIEW', limit: 5 }),
  getRecentAdminActivity({ limit: 5 }),
  getCategoryDistribution(),
])
```

### Selector de período

`<Select>` en el header: "Últimos 7 días" | "Últimos 30 días" | "Este mes" | "Este año".
Al cambiar: refetch de charts con `router.push` + searchParam `?period=`.

### Stat Cards — 4 columnas

```ts
const adminStats = [
  { label: 'Listados totales', value: stats.totalListings, trend: '+8 este mes', icon: Package },
  { label: 'Usuarios registrados', value: stats.totalUsers, trend: '+24 este mes', icon: Users },
  { label: 'Consultas activas', value: stats.activeInquiries, trend: '+15 esta semana', icon: MessageCircle },
  { label: 'Volumen listado', value: `$${formatM(stats.totalVolume)} USD`, icon: DollarSign, highlight: true },
]
```

### Gráficos — 2 columnas

**Gráfico izquierdo:** `<BarChart>` — "Nuevos listados por semana"
```tsx
<BarChart data={weeklyListings}>
  <Bar dataKey="count" fill="#F59E0B" radius={[4, 4, 0, 0]} />
</BarChart>
```

**Gráfico derecho:** `<AreaChart>` — "Registros de usuarios"
```tsx
<AreaChart data={dailyRegistrations}>
  <Area dataKey="count" stroke="#F59E0B" fill="rgba(245,158,11,0.1)" />
</AreaChart>
```

Ambos usan Recharts. Fondo del gráfico: `bg-navy-950`. Grid lines: `stroke="#1E293B"`.

### Pendientes de revisión

```tsx
<Card className="p-6">
  <div className="flex items-center justify-between mb-4">
    <div className="flex items-center gap-2">
      <h2 className="font-semibold text-slate-50">Listados pendientes de revisión</h2>
      <Badge variant="danger">{pendingListings.total}</Badge>
    </div>
    <Link href="/admin/listados?status=pending">Ver todos →</Link>
  </div>
  <PendingListingsTable listings={pendingListings.items} />
</Card>
```

Tabla compacta con columnas: Activo | Vendedor | Tipo | Precio | Enviado | Acciones.
Botón "Revisar" → navega a `/admin/listados/{id}`.

### Distribución por categoría

```tsx
<Card className="p-6">
  <h2 className="font-semibold text-slate-50 mb-4">Distribución por categoría</h2>
  {categoryDist.map(cat => (
    <div key={cat.slug} className="flex items-center gap-3 mb-3">
      <span className="text-sm text-slate-400 w-24">{cat.label}</span>
      <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
        <div
          className="h-full bg-amber-500 rounded-full"
          style={{ width: `${cat.percentage}%` }}
        />
      </div>
      <span className="text-sm text-slate-50 w-12 text-right">{cat.count}</span>
      <span className="text-xs text-slate-500 w-10 text-right">({cat.percentage}%)</span>
    </div>
  ))}
</Card>
```

---

## 2. Moderación de Listados (`/admin/listados`)

**Archivo:** `app/(admin)/admin/listados/page.tsx`

### searchParams

| Param | Valores |
|---|---|
| `status` | `all` \| `pending` \| `published` \| `featured` \| `rejected` \| `sold` |
| `type` | `website` \| `domain` \| `saas` \| `ecommerce` \| `project` |
| `sort` | `newest` \| `oldest` \| `price_asc` \| `price_desc` |
| `q` | string |
| `page` | number |

### Tabs

```tsx
const tabs = [
  { label: 'Todos', status: 'all', count: listings.total },
  { label: 'Pendientes', status: 'pending', count: listings.pendingCount, dotColor: 'danger' },
  { label: 'Publicados', status: 'published', count: listings.publishedCount },
  { label: 'Destacados', status: 'featured', count: listings.featuredCount },
  { label: 'Rechazados', status: 'rejected', count: listings.rejectedCount },
  { label: 'Vendidos', status: 'sold', count: listings.soldCount },
]
```

Tab "Pendientes" tiene dot rojo pulsante.

### Tabla con selección masiva

```tsx
<AdminListingsTable
  listings={listings.items}
  onApprove={handleApprove}
  onReject={handleReject}
  onView={handleView}
  onSelect={handleSelect}
  selectedIds={selectedIds}
/>
```

**Columnas:** checkbox | thumbnail | Activo | Vendedor | Tipo | Precio | Estado | Fecha | Acciones

- Checkbox → selección individual
- Thumbnail → 40x40px `rounded-lg object-cover`
- Botón "Aprobar ✓" → `variant="outline-success" size="sm"`
- Botón "Rechazar ✗" → `variant="outline-danger" size="sm"`
- Botón "Ver" → `variant="ghost" size="sm"`

**Barra de acciones masivas** (visible cuando `selectedIds.length > 0`):
```tsx
<div className="flex items-center gap-3 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mb-4">
  <span className="text-sm text-amber-500">{selectedIds.length} seleccionados</span>
  <Button variant="outline-success" size="sm">Aprobar todos</Button>
  <Button variant="outline-danger" size="sm">Rechazar todos</Button>
  <Button variant="ghost" size="sm" onClick={() => setSelectedIds([])}>Cancelar</Button>
</div>
```

### Slide-in Panel de Preview

**Archivo:** `src/components/admin/ListingPreviewPanel.tsx`

Se abre desde la derecha al hacer click en "Ver". No navega.

```tsx
<div className={cn(
  "fixed right-0 top-0 h-screen w-[420px] bg-navy-900 border-l border-slate-800",
  "transform transition-transform duration-300",
  isOpen ? "translate-x-0" : "translate-x-full"
)}>
  {/* contenido del panel */}
</div>
```

Contenido del panel:
1. Header con botón X para cerrar
2. Screenshot grande (`w-full h-48 object-cover rounded-xl`)
3. Título + tipo + precio
4. Descripción completa (scroll)
5. Métricas reportadas
6. Tech stack pills
7. Info vendedor con link a perfil
8. Footer sticky con botones de acción:

```tsx
<div className="sticky bottom-0 border-t border-slate-800 bg-navy-900 p-4 space-y-3">
  <Button variant="solid" className="w-full bg-emerald-500 hover:bg-emerald-400 text-white"
    onClick={() => approve(listing.id)}>
    Aprobar y publicar
  </Button>
  <Button variant="outline-danger" className="w-full"
    onClick={() => setShowRejectField(true)}>
    Rechazar
  </Button>
  {showRejectField && (
    <Textarea
      placeholder="Motivo del rechazo (requerido)..."
      value={rejectReason}
      onChange={setRejectReason}
      rows={3}
    />
  )}
  {showRejectField && (
    <Button variant="outline-danger" className="w-full"
      disabled={!rejectReason.trim()}
      onClick={() => reject(listing.id, rejectReason)}>
      Confirmar rechazo
    </Button>
  )}
</div>
```

**Validación:** el motivo de rechazo es requerido (mínimo 20 caracteres). No permitir confirmar sin él.

---

## 3. Revisión Individual (`/admin/listados/[id]`)

**Archivo:** `app/(admin)/admin/listados/[id]/page.tsx`

Vista de revisión full-page. Similar a `/explorar/[slug]` pero con panel de moderación al lado.

Diferencias respecto al detalle público:
- Sin "Consultar al vendedor"
- Sin "Guardar en favoritos"
- Sidebar con acciones admin: Aprobar / Rechazar / Destacar / Quitar destacado / Marcar vendido
- Historial de moderación (si fue rechazado antes, mostrar razón anterior)
- Link "Ver perfil del vendedor" → `/admin/usuarios/{sellerId}`

---

## 4. Gestión de Usuarios (`/admin/usuarios`)

**Archivo:** `app/(admin)/admin/usuarios/page.tsx`

### Stat Cards mini — 4 columnas

```ts
[
  { label: 'Total', value: stats.total },
  { label: 'Vendedores', value: stats.sellers },
  { label: 'Compradores', value: stats.buyers },
  { label: 'Suspendidos', value: stats.suspended, highlight: 'danger' },
]
```

Cards compactas: `p-4 bg-navy-900 border border-slate-800 rounded-xl`

### Tabla de usuarios

**Columnas:** Avatar | Nombre | Email | Rol | Listados | Registrado | Estado | Acciones

**Avatar:** círculo 36px con iniciales. Color por rol:
- Vendedor: `bg-amber-500 text-navy-950`
- Comprador: `bg-blue-500 text-white`
- Admin: `bg-purple-500 text-white`

**Rol pill:**
```tsx
const roleBadgeVariant = {
  SELLER: 'info',
  BUYER: 'muted',  // usar violeta custom
  ADMIN: 'amber',
}
```

**Menú ⋯:**
```ts
const userMenuItems = [
  { label: 'Ver perfil', href: `/admin/usuarios/${id}`, icon: User },
  { label: 'Cambiar rol', action: 'changeRole', icon: RefreshCw },
  { label: 'Suspender', action: 'suspend', icon: Ban, danger: true },
  { label: 'Eliminar', action: 'delete', icon: Trash2, danger: true },
]
```

**Suspender:** Modal de confirmación con campo de motivo.
**Eliminar:** Modal de confirmación con advertencia de borrado suave (90 días retención).

---

## 5. Server Actions — Admin

Todos en `src/app/(admin)/admin/actions.ts`. Verificar `role === 'ADMIN'` al inicio de cada action.

```ts
export async function approveListing(listingId: string): Promise<ActionResult>
export async function rejectListing(listingId: string, reason: string): Promise<ActionResult>
export async function featureListing(listingId: string): Promise<ActionResult>
export async function unfeatureListing(listingId: string): Promise<ActionResult>
export async function markAsSold(listingId: string): Promise<ActionResult>
export async function suspendUser(userId: string, reason: string): Promise<ActionResult>
export async function changeUserRole(userId: string, role: 'BUYER' | 'SELLER' | 'ADMIN'): Promise<ActionResult>
export async function deleteUser(userId: string): Promise<ActionResult>
```

Cada action:
1. Verifica sesión y rol ADMIN
2. Registra en `AuditLog` con `{ adminId, action, targetId, reason?, metadata }`
3. Retorna `{ success: boolean; error?: string }`

### AuditLog — tipos de acción

| Action | Descripción |
|---|---|
| `LISTING_APPROVED` | Listado aprobado y publicado |
| `LISTING_REJECTED` | Listado rechazado con motivo |
| `LISTING_FEATURED` | Listado marcado como destacado |
| `LISTING_UNFEATURED` | Destacado removido |
| `LISTING_SOLD` | Marcado como vendido por admin |
| `USER_SUSPENDED` | Usuario suspendido |
| `USER_ROLE_CHANGED` | Rol de usuario modificado |
| `USER_DELETED` | Usuario eliminado (soft delete) |

---

## 6. Alertas operativas

La sidebar admin muestra alertas visuales cuando:

| Condición | Alerta |
|---|---|
| Listados en revisión > 48hs sin acción | Badge rojo en "Listados" pulsante |
| Más de 10 listados pendientes | Dot rojo en dashboard stat card |
| Usuario reportado | Badge en "Usuarios" (fase 2) |

Implementar con polling cada 5 minutos: `useInterval(() => fetchPendingCount(), 5 * 60 * 1000)`.
