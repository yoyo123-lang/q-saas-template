'use client'

import { cn } from '@/lib/utils/cn'

interface PasswordStrengthProps {
  password: string
}

function getStrength(password: string): { score: number; label: string; color: string } {
  if (!password) return { score: 0, label: '', color: 'bg-slate-800' }

  let score = 0
  if (password.length >= 8) score++
  if (/[A-Z]/.test(password)) score++
  if (/[0-9]/.test(password)) score++
  if (/[^A-Za-z0-9]/.test(password)) score++

  const levels = [
    { score: 0, label: '', color: 'bg-slate-800' },
    { score: 1, label: 'Débil', color: 'bg-red-500' },
    { score: 2, label: 'Media', color: 'bg-amber-500' },
    { score: 3, label: 'Fuerte', color: 'bg-emerald-500' },
  ]

  return levels[Math.min(score, 3)]
}

export function PasswordStrength({ password }: PasswordStrengthProps) {
  const { score, label, color } = getStrength(password)

  if (!password) return null

  return (
    <div className="space-y-1.5">
      <div className="flex gap-1.5">
        {[1, 2, 3].map((segment) => (
          <div
            key={segment}
            className={cn(
              'h-1 flex-1 rounded-full transition-colors duration-300',
              score >= segment ? color : 'bg-slate-800'
            )}
          />
        ))}
      </div>
      {label && (
        <p className={cn('text-xs', score === 1 && 'text-red-400', score === 2 && 'text-amber-400', score >= 3 && 'text-emerald-400')}>
          {label}
        </p>
      )}
    </div>
  )
}
