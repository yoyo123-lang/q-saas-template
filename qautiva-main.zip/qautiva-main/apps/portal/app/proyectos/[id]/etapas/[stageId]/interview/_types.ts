/**
 * Tipos y constantes compartidos del módulo de entrevista por etapa.
 */

export type WelcomeData = {
  title: string
  description: string
  estimatedTime: string
  whatYouGet: string
  icon?: string
  fastTrackText?: string
}

// ── Metadatos de etapas ────────────────────────────────────────────────────────

export const STAGE_LABELS: Record<number, string> = {
  1: 'Tu negocio',
  2: 'Mercado',
  3: 'Marca',
  4: 'Web',
  5: 'Campañas',
  6: 'Medios',
}

export const STAGE_ICONS: Record<number, { emoji: string; color: string; bg: string }> = {
  1: { emoji: '🏢', color: '#8B5CF6', bg: '#8B5CF6' },
  2: { emoji: '🔍', color: '#06B6D4', bg: '#06B6D4' },
  3: { emoji: '🎨', color: '#EC4899', bg: '#EC4899' },
  4: { emoji: '🌐', color: '#10B981', bg: '#10B981' },
  5: { emoji: '📣', color: '#F59E0B', bg: '#F59E0B' },
  6: { emoji: '📺', color: '#EF4444', bg: '#EF4444' },
}

export const STAGE_DESCRIPTIONS: Record<number, string> = {
  1: 'Vamos a conocer tu negocio en profundidad. Tus respuestas son la base de todo lo que viene.',
  2: 'Analizamos tu mercado y competencia para identificar oportunidades reales.',
  3: 'Definimos la identidad visual y el tono de comunicación de tu marca.',
  4: 'Creamos tu presencia web optimizada para convertir visitantes en clientes.',
  5: 'Diseñamos una estrategia de campañas para llegar a tu audiencia ideal.',
  6: 'Expandimos tu alcance con presencia en medios y plataformas relevantes.',
}
