'use client'

import { useState, useEffect } from 'react'
import { updateTemplateInfo } from '../../actions'
import type { ActionState } from '../../actions'

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar'}
    </button>
  )
}

interface TabInfoProps {
  templateId: string
  name: string
  description: string
  thumbnail: string
  status: 'DRAFT' | 'ACTIVE'
  compatibleIndustries: string[]
}

export function TabInfo({
  templateId,
  name: initialName,
  description: initialDescription,
  thumbnail: initialThumbnail,
  status: initialStatus,
  compatibleIndustries: initialIndustries,
}: TabInfoProps) {
  const [industries, setIndustries] = useState<string[]>(initialIndustries)
  const [inputValue, setInputValue] = useState('')
  const [showSuccess, setShowSuccess] = useState(false)
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  useEffect(() => {
    if (state?.ok) {
      setShowSuccess(true)
      const t = setTimeout(() => setShowSuccess(false), 3000)
      return () => clearTimeout(t)
    }
  }, [state])

  function addIndustry() {
    const trimmed = inputValue.trim()
    if (!trimmed || industries.includes(trimmed)) {
      setInputValue('')
      return
    }
    setIndustries((prev) => [...prev, trimmed])
    setInputValue('')
  }

  function removeIndustry(index: number) {
    setIndustries((prev) => prev.filter((_, i) => i !== index))
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      e.preventDefault()
      addIndustry()
    }
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', templateId)
    formData.set('compatibleIndustries', JSON.stringify(industries))
    try {
      const result = await updateTemplateInfo(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-5">
      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-5 flex flex-col gap-4">
        {/* Nombre */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="name" className="text-sm font-medium text-[#94A3B8]">
            Nombre <span className="text-red-400">*</span>
          </label>
          <input
            id="name"
            name="name"
            type="text"
            required
            maxLength={200}
            defaultValue={initialName}
            className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
          />
        </div>

        {/* Descripción */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="description" className="text-sm font-medium text-[#94A3B8]">
            Descripción
          </label>
          <input
            id="description"
            name="description"
            type="text"
            maxLength={500}
            defaultValue={initialDescription}
            placeholder="Breve descripción del template..."
            className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
          />
        </div>

        {/* Thumbnail */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="thumbnail" className="text-sm font-medium text-[#94A3B8]">
            URL del thumbnail
          </label>
          <input
            id="thumbnail"
            name="thumbnail"
            type="url"
            defaultValue={initialThumbnail}
            placeholder="https://..."
            className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
          />
        </div>

        {/* Estado */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="status" className="text-sm font-medium text-[#94A3B8]">
            Estado
          </label>
          <select
            id="status"
            name="status"
            defaultValue={initialStatus}
            className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm focus:outline-none focus:border-[#8B5CF6] transition-colors"
          >
            <option value="DRAFT">Borrador</option>
            <option value="ACTIVE">Activo</option>
          </select>
        </div>

        {/* Industrias compatibles */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-[#94A3B8]">Industrias compatibles</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ej: Gastronomía"
              maxLength={100}
              className="flex-1 px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
            />
            <button
              type="button"
              onClick={addIndustry}
              className="px-3 py-2 bg-[#1E293B] text-[#94A3B8] text-sm rounded-lg hover:text-white hover:bg-[#334155] transition-colors"
            >
              Agregar
            </button>
          </div>

          {industries.length === 0 ? (
            <p className="text-[#64748B] text-xs">Sin industrias. Agregá las compatibles.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {industries.map((ind) => (
                <span
                  key={ind}
                  className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#1E293B] text-[#94A3B8] text-sm rounded-full"
                >
                  {ind}
                  <button
                    type="button"
                    onClick={() => removeIndustry(industries.indexOf(ind))}
                    className="text-[#64748B] hover:text-red-400 transition-colors leading-none"
                    aria-label={`Eliminar industria ${ind}`}
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <SaveButton pending={isPending} />
        {showSuccess && <p className="text-sm text-green-400">Guardado correctamente.</p>}
        {state && !state.ok && <p className="text-sm text-red-400">{state.error}</p>}
      </div>
    </form>
  )
}
