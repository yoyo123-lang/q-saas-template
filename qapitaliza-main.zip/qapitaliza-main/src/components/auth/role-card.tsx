'use client'

import { cn } from '@/lib/utils/cn'

interface RoleCardProps {
  value: string
  selected: boolean
  onClick: () => void
  icon: React.ReactNode
  title: string
  description: string
}

export function RoleCard({ value, selected, onClick, icon, title, description }: RoleCardProps) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      aria-label={title}
      value={value}
      onClick={onClick}
      className={cn(
        'flex flex-col items-center text-center gap-2 p-4 rounded-xl border transition-all duration-150',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2 focus-visible:ring-offset-navy-900',
        selected
          ? 'border-amber-500 bg-amber-500/[0.08] shadow-[0_0_0_1px_rgba(245,158,11,0.3)]'
          : 'border-slate-800 bg-slate-800/50 hover:border-slate-700'
      )}
    >
      <span className={cn('transition-colors', selected ? 'text-amber-500' : 'text-slate-400')}>
        {icon}
      </span>
      <span className="text-sm font-medium text-slate-50">{title}</span>
      <span className="text-xs text-slate-500 leading-snug">{description}</span>
    </button>
  )
}
