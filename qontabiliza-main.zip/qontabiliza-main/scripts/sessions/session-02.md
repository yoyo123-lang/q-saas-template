# Sesión 2: Multi-tenancy (frontend) y onboarding

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 2
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md → formato de IMPLEMENTATION_PLAN.md
- docs/MULTI-AGENT.md → flujo de sub-agentes
- docs/TDD.md → test primero, código después
- docs/CONVENTIONS.md → convenciones del proyecto

## Objetivo

Flujo de creación de organización, selector de tenant, contexto de tenant en toda la app. Wizard de onboarding básico.

## Pre-requisitos

Sesión 1 completada (schema Prisma, withTenant, migración, seeds).

## Etapas

### Etapa 1: API routes para Organization y Membership
- CRUD de Organization (crear, leer, actualizar)
- Gestión de Membership (invitar, listar miembros, cambiar rol)
- Todas las queries usando withTenant()

### Etapa 2: TenantProvider (context React)
- Context que resuelve el tenant activo desde la URL o la sesión del usuario
- Hook `useTenant()` que retorna { organization, membership, isLoading }
- Toda la app envuelta en el provider

### Etapa 3: UI de selector de organización
- Selector de organización en el sidebar
- Página de crear nueva organización
- Redirect automático si el usuario solo tiene una org

### Etapa 4: Wizard de onboarding
- Paso 1: Datos fiscales del negocio (razón social, CUIT, condición IVA)
- Paso 2: Primer producto de ejemplo
- Paso 3: Primer cliente de ejemplo
- Al completar, redirigir al dashboard

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Micro-revisión después de cada tarea
5. Al terminar: build + lint + test deben pasar
