'use client'

import { useEffect, useState, useTransition } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import { createClient } from '@/lib/supabase/client'
import { nuevaContrasenaSchema, type NuevaContrasenaData } from '@/lib/schemas/auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { PasswordStrength } from '@/components/ui/password-strength'

export default function NuevaContrasenaPage() {
  const router = useRouter()
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [sessionReady, setSessionReady] = useState(false)
  const [isPending, startTransition] = useTransition()

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, touchedFields },
  } = useForm<NuevaContrasenaData>({
    resolver: zodResolver(nuevaContrasenaSchema),
    mode: 'onBlur',
  })

  const watchPassword = watch('password') ?? ''

  useEffect(() => {
    const supabase = createClient()
    let redirected = false

    // Supabase procesa el token del hash automáticamente y emite PASSWORD_RECOVERY.
    // onAuthStateChange es la fuente de verdad — no usar setTimeout para evitar
    // race conditions en conexiones lentas.
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY' && session) {
        setSessionReady(true)
        return
      }

      // Si recibimos SIGNED_OUT o el evento inicial sin sesión de recovery, redirigir.
      // Usamos un flag para evitar doble redirección si el evento se emite dos veces.
      if (!redirected && (event === 'SIGNED_OUT' || event === 'INITIAL_SESSION') && !session) {
        redirected = true
        toast.error('El enlace de recuperación es inválido o expiró.')
        router.push('/recuperar')
      }
    })

    return () => subscription.unsubscribe()
  }, [router])

  const onSubmit = (data: NuevaContrasenaData) => {
    startTransition(async () => {
      const supabase = createClient()
      const { error } = await supabase.auth.updateUser({ password: data.password })

      if (error) {
        toast.error('Error al actualizar la contraseña. Intentá de nuevo.')
        return
      }

      toast.success('Contraseña actualizada correctamente.')
      router.push('/dashboard')
    })
  }

  if (!sessionReady) {
    return (
      <div className="w-full max-w-sm flex items-center justify-center">
        <p className="text-sm text-slate-400">Verificando enlace...</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-sm space-y-4">
      <div>
        <h1 className="text-2xl font-semibold text-slate-50">Nueva contraseña</h1>
        <p className="text-sm text-slate-400 mt-1">
          Elegí una contraseña segura para tu cuenta.
        </p>
      </div>

      <div className="space-y-1.5">
        <Input
          label="Nueva contraseña"
          type={showPassword ? 'text' : 'password'}
          autoComplete="new-password"
          suffix={
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="text-slate-400 hover:text-slate-200 transition-colors"
              aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          {...register('password')}
          error={touchedFields.password ? errors.password?.message : undefined}
        />
        <PasswordStrength password={watchPassword} />
      </div>

      <Input
        label="Confirmar contraseña"
        type={showConfirm ? 'text' : 'password'}
        autoComplete="new-password"
        suffix={
          <button
            type="button"
            onClick={() => setShowConfirm((v) => !v)}
            className="text-slate-400 hover:text-slate-200 transition-colors"
            aria-label={showConfirm ? 'Ocultar contraseña' : 'Mostrar contraseña'}
          >
            {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        }
        {...register('confirmPassword')}
        error={touchedFields.confirmPassword ? errors.confirmPassword?.message : undefined}
      />

      <Button type="submit" variant="solid" size="full" loading={isPending}>
        Guardar nueva contraseña
      </Button>
    </form>
  )
}
