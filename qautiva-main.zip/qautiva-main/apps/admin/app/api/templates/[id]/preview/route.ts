import { NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

/**
 * GET /api/templates/[id]/preview
 * Sirve el HTML del template como página completa (draft o activo).
 * Solo accesible para admins autenticados.
 */
export async function GET(
  _req: Request,
  { params }: { params: { id: string } },
) {
  try {
    await requireAdminSession()
  } catch {
    return new NextResponse('No autorizado', { status: 401 })
  }

  const template = await prisma.webTemplate.findUnique({
    where: { id: params.id },
    select: { name: true, htmlBase: true, css: true },
  })

  if (!template || !template.htmlBase) {
    return new NextResponse('Template no encontrado o sin HTML generado todavía', { status: 404 })
  }

  let html = template.htmlBase

  if (template.css) {
    const styleTag = `<style>${template.css}</style>`
    if (html.includes('</head>')) {
      html = html.replace('</head>', `${styleTag}</head>`)
    } else {
      html = styleTag + html
    }
  }

  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'X-Frame-Options': 'SAMEORIGIN',
      'Cache-Control': 'private, no-store',
    },
  })
}
