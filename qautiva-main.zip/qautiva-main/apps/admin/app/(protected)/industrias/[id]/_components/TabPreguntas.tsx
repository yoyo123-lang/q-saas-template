'use client'

import { useState } from 'react'
import { updateQuestions } from '../../actions'
import type { ActionState } from '../../actions'

type InputType =
  | 'text'
  | 'textarea'
  | 'multiple_choice'
  | 'multi_select'
  | 'rating'
  | 'url_input'
  | 'file_upload'
  | 'color_picker'
  | 'budget_range'
  | 'date'

type Option = { value: string; label: string }

type QuestionBlock = {
  id: string
  question: string
  helpText?: string
  inputType: InputType
  options?: Option[]
  placeholder?: string
  skippable?: boolean
}

type QuestionsMap = Record<string, QuestionBlock[]>

const STAGES: { key: string; label: string }[] = [
  { key: '1', label: 'Tu negocio' },
  { key: '2', label: 'Mercado y competencia' },
  { key: '3', label: 'Marca y estilo' },
  { key: '4', label: 'Presencia web' },
  { key: '5', label: 'Campañas publicitarias' },
  { key: '6', label: 'Medios y publicaciones' },
]

const INPUT_TYPES: { value: InputType; label: string }[] = [
  { value: 'text', label: 'Texto corto' },
  { value: 'textarea', label: 'Texto largo' },
  { value: 'multiple_choice', label: 'Opción única' },
  { value: 'multi_select', label: 'Múltiple selección' },
  { value: 'rating', label: 'Calificación' },
  { value: 'url_input', label: 'URL' },
  { value: 'file_upload', label: 'Archivo' },
  { value: 'color_picker', label: 'Color' },
  { value: 'budget_range', label: 'Rango de presupuesto' },
  { value: 'date', label: 'Fecha' },
]

const TYPES_WITH_OPTIONS: InputType[] = ['multiple_choice', 'multi_select']

function hasOptions(inputType: InputType): boolean {
  return TYPES_WITH_OPTIONS.includes(inputType)
}

function createEmptyQuestion(): QuestionBlock {
  return {
    id: crypto.randomUUID(),
    question: '',
    inputType: 'text',
  }
}

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar preguntas'}
    </button>
  )
}

interface StageEditorProps {
  stageKey: string
  label: string
  questions: QuestionBlock[]
  onChange: (stageKey: string, questions: QuestionBlock[]) => void
}

function StageEditor({ stageKey, label, questions, onChange }: StageEditorProps) {
  const [collapsed, setCollapsed] = useState(false)

  function updateQuestion(index: number, updated: Partial<QuestionBlock>) {
    const next = questions.map((q, i) => (i === index ? { ...q, ...updated } : q))
    onChange(stageKey, next)
  }

  function removeQuestion(index: number) {
    onChange(stageKey, questions.filter((_, i) => i !== index))
  }

  function moveQuestion(index: number, direction: 'up' | 'down') {
    const next = [...questions]
    const target = direction === 'up' ? index - 1 : index + 1
    if (target < 0 || target >= next.length) return
    const temp = next[index]
    next[index] = next[target]!
    next[target] = temp!
    onChange(stageKey, next)
  }

  function addQuestion() {
    onChange(stageKey, [...questions, createEmptyQuestion()])
  }

  return (
    <div className="border border-[#1E293B] rounded-lg overflow-hidden">
      <button
        type="button"
        onClick={() => setCollapsed(!collapsed)}
        className="w-full flex items-center justify-between px-4 py-3 bg-[#0F172A] text-left"
      >
        <span className="text-sm font-medium text-white">
          Etapa {stageKey}: {label}
          <span className="ml-2 text-[#64748B] text-xs font-normal">({questions.length} preguntas)</span>
        </span>
        <span className="text-[#64748B] text-xs">{collapsed ? '▼' : '▲'}</span>
      </button>

      {!collapsed && (
        <div className="p-4 flex flex-col gap-3 bg-[#0B0F1A]">
          {questions.length === 0 && (
            <p className="text-[#64748B] text-xs text-center py-2">Sin preguntas en esta etapa.</p>
          )}

          {questions.map((q, idx) => (
            <div key={q.id} className="border border-[#1E293B] rounded-lg p-3 flex flex-col gap-2 bg-[#0F172A]">
              <div className="flex items-center gap-2">
                <div className="flex flex-col gap-0.5">
                  <button
                    type="button"
                    onClick={() => moveQuestion(idx, 'up')}
                    disabled={idx === 0}
                    className="text-[#64748B] hover:text-white disabled:opacity-30 text-xs leading-none"
                    aria-label="Mover arriba"
                  >
                    ↑
                  </button>
                  <button
                    type="button"
                    onClick={() => moveQuestion(idx, 'down')}
                    disabled={idx === questions.length - 1}
                    className="text-[#64748B] hover:text-white disabled:opacity-30 text-xs leading-none"
                    aria-label="Mover abajo"
                  >
                    ↓
                  </button>
                </div>

                <input
                  type="text"
                  value={q.question}
                  onChange={(e) => updateQuestion(idx, { question: e.target.value })}
                  placeholder="Pregunta..."
                  maxLength={500}
                  className="flex-1 px-2 py-1.5 bg-[#0B0F1A] border border-[#1E293B] rounded text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6]"
                />

                <select
                  value={q.inputType}
                  onChange={(e) => updateQuestion(idx, { inputType: e.target.value as InputType })}
                  className="px-2 py-1.5 bg-[#0B0F1A] border border-[#1E293B] rounded text-white text-sm focus:outline-none focus:border-[#8B5CF6]"
                >
                  {INPUT_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => removeQuestion(idx)}
                  className="text-red-400 hover:text-red-300 text-sm px-1"
                  aria-label="Eliminar pregunta"
                >
                  ×
                </button>
              </div>

              {hasOptions(q.inputType) && (
                <div className="ml-8">
                  <label className="text-xs text-[#64748B] block mb-1">
                    Opciones (separadas por coma):
                  </label>
                  <input
                    type="text"
                    value={q.options?.map((o) => o.label).join(', ') ?? ''}
                    onChange={(e) => {
                      const opts = e.target.value
                        .split(',')
                        .map((s) => s.trim())
                        .filter(Boolean)
                        .map((label) => ({ value: label.toLowerCase().replace(/\s+/g, '_'), label }))
                      updateQuestion(idx, { options: opts })
                    }}
                    placeholder="Opción 1, Opción 2, Opción 3"
                    className="w-full px-2 py-1.5 bg-[#0B0F1A] border border-[#1E293B] rounded text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
              )}
            </div>
          ))}

          <button
            type="button"
            onClick={addQuestion}
            className="self-start text-xs text-[#8B5CF6] hover:text-[#A78BFA] transition-colors"
          >
            + Agregar pregunta
          </button>
        </div>
      )}
    </div>
  )
}

interface TabPreguntasProps {
  industryId: string
  questions: Record<string, unknown>
}

export function TabPreguntas({ industryId, questions }: TabPreguntasProps) {
  const initialMap: QuestionsMap = {}
  for (const stage of STAGES) {
    const raw = questions[stage.key]
    initialMap[stage.key] = Array.isArray(raw) ? (raw as QuestionBlock[]) : []
  }

  const [questionsMap, setQuestionsMap] = useState<QuestionsMap>(initialMap)
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  function handleStageChange(stageKey: string, updated: QuestionBlock[]) {
    setQuestionsMap((prev) => ({ ...prev, [stageKey]: updated }))
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', industryId)
    formData.set('questions', JSON.stringify(questionsMap))
    try {
      const result = await updateQuestions(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-4">
      {STAGES.map((stage) => (
        <StageEditor
          key={stage.key}
          stageKey={stage.key}
          label={stage.label}
          questions={questionsMap[stage.key] ?? []}
          onChange={handleStageChange}
        />
      ))}

      <div className="flex items-center gap-3 pt-2">
        <SaveButton pending={isPending} />
        {state && (
          state.ok
            ? <p className="text-sm text-green-400">Guardado correctamente.</p>
            : <p className="text-sm text-red-400">{state.error}</p>
        )}
      </div>
    </form>
  )
}
