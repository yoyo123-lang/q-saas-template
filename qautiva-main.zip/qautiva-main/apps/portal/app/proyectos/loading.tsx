export default function ProyectosLoading() {
  return (
    <div className="p-6 max-w-4xl mx-auto animate-pulse">
      <div className="mb-6">
        <div className="h-8 w-40 bg-[#1E293B] rounded-lg mb-2" />
        <div className="h-4 w-60 bg-[#1E293B] rounded" />
      </div>
      <div className="flex flex-col gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex items-center justify-between">
            <div className="flex flex-col gap-2 flex-1">
              <div className="h-5 w-48 bg-[#1E293B] rounded" />
              <div className="h-3 w-32 bg-[#1E293B] rounded" />
            </div>
            <div className="h-6 w-20 bg-[#1E293B] rounded-full" />
          </div>
        ))}
      </div>
    </div>
  )
}
