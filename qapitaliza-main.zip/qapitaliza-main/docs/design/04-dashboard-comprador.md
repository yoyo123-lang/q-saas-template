# Prompts para Gemini — Dashboard Comprador

> Cada prompt es autocontenido. Copiá y pegá uno a la vez en Gemini.

---

## PROMPT 1: Favoritos (`/favoritos`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales (sitios web, dominios, MVPs, proyectos).

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A | Fondo cards/sidebar: #0F172A | Fondo hover: #1E293B
- Acento primario: #F59E0B (amber/dorado) | Hover: #FBBF24
- Texto: #F8FAFC (primario), #94A3B8 (secundario), #64748B (apagado)
- Bordes: #1E293B | Success: #10B981 | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans (400, 500, 600, 700). Mono: JetBrains Mono.
Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" oscuro. Idioma: español argentino.

PÁGINA: Favoritos — activos guardados por el comprador

ESTRUCTURA: Sidebar fija izquierda (280px) + contenido principal

SIDEBAR (280px, fondo #0B0F1A, borde derecho #1E293B):
- Logo Q amber + "qapitaliza"
- Nav: Dashboard | Mis activos | Consultas (badge "3") | Favoritos (ACTIVO — barra izquierda 3px amber, texto amber) | Perfil
- Abajo: avatar + "Laura García" + "compradora"

CONTENIDO (padding 32px):

a) HEADER
   - "Mis favoritos" (28px semibold #F8FAFC)
   - "5 activos guardados" (#94A3B8)

b) GRILLA DE CARDS (2 columnas)

Cada card tiene: screenshot placeholder arriba, debajo título, tipo badge, precio, métricas, tech stack pills, y botón "♥ Guardado" (amber sólido) + botón "Consultar" (outline amber).

Card 1: "CryptoAlerts.io" — SaaS — $18,000 USD — badge "Verificado" verde — $2,100 MRR — Next.js, Stripe
Card 2: "DevTools.pro" — Tool — $32,000 USD — badge "Destacado" amber — $4,800 MRR — React, Node.js
Card 3: "TuMascota.shop" — E-commerce — $7,200 USD — 340 orders/mes — Shopify
Card 4: "Viajeros.com.ar" — Dominio — $15,000 USD — DA 52 — Reg. 2008
Card 5: "FitnessPlan.app" — MVP — $2,800 USD — 1,200 usuarios — React Native

Cada card: fondo #0F172A, borde #1E293B, rounded 12px. Hover: shadow + borde amber 30%.
El ícono de corazón en cada card es sólido amber (está guardado). Click lo remueve.
```

---

## PROMPT 2: Bandeja de consultas (`/consultas`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards/sidebar: #0F172A | Hover: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Info: #3B82F6

Tipografía: DM Sans. Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q". Idioma: español argentino.

PÁGINA: Bandeja de consultas — lista de conversaciones

ESTRUCTURA: Sidebar (280px, "Consultas" activo con barra amber) + contenido

CONTENIDO:

a) HEADER
   - "Consultas" (28px semibold #F8FAFC)
   - Tabs: "Todas (5)" | "Abiertas (3)" | "Respondidas (1)" | "Cerradas (1)"
   - Tab activo con borde inferior amber

b) LISTA DE CONSULTAS (cards apilados verticalmente, full width)

Cada card: fondo #0F172A, borde #1E293B, rounded 12px, padding 20px, hover fondo #1E293B.

Consulta 1 (NO LEÍDA — borde izquierdo 3px amber):
- Avatar + "Martín Rodríguez" (vendedor) · "CryptoAlerts.io" (link amber)
- Preview: "Hola Laura, gracias por tu interés. El proyecto incluye toda la base de datos de usuarios..."
- Timestamp: "Hace 2 horas" en #64748B
- Badge: "● Abierta" (verde)
- Dot amber indicando no leído

Consulta 2 (NO LEÍDA — borde izquierdo 3px amber):
- Avatar + "Carlos Méndez" (vendedor) · "DevTools.pro"
- Preview: "Sí, puedo compartirte acceso al analytics. ¿Te sirve un link de solo lectura?"
- "Hace 5 horas"
- Badge: "● Abierta" (verde)

Consulta 3:
- Avatar + "Ana López" (vendedor) · "TuMascota.shop"
- Preview: "Perfecto, quedamos en contacto. Cualquier duda..."
- "Hace 2 días"
- Badge: "● Respondida" (azul)

Consulta 4:
- Avatar + "Federico Ruiz" (vendedor) · "Viajeros.com.ar"
- Preview: "Te envié la documentación por email. Revisá y..."
- "Hace 3 días"
- Badge: "● Abierta" (verde)

Consulta 5:
- Avatar + "Pedro Martínez" (vendedor) · "NotiTech.com"
- Preview: "Gracias por tu consulta pero decidimos no vender por ahora."
- "Hace 1 semana"
- Badge: "● Cerrada" (gris #64748B)
```

---

## PROMPT 3: Detalle de consulta / chat (`/consultas/[id]`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards: #0F172A | Inputs: #1E293B
- Acento: #F59E0B | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Info: #3B82F6

Tipografía: DM Sans. Cards: rounded 12px. Buttons/Inputs: rounded 8px.
Logo: cuadrado amber con "Q". Idioma: español argentino.

PÁGINA: Detalle de consulta — conversación sobre "CryptoAlerts.io"

ESTRUCTURA: Sidebar (280px) + contenido 2 columnas (chat 65% + info activo 35%)

COLUMNA PRINCIPAL — CHAT:

a) HEADER DEL CHAT
   - Breadcrumb: "Consultas > CryptoAlerts.io"
   - "Consulta sobre CryptoAlerts.io" (24px semibold)
   - Badge "● Abierta" (verde)
   - Botón "Cerrar consulta" (outline gris, pequeño)

b) THREAD DE MENSAJES (scroll vertical, fondo #0B0F1A)

   Mensaje 1 (Laura — yo, alineado derecha):
   - Burbuja fondo #F59E0B al 15%, borde amber al 20%, rounded 12px
   - "Hola Martín! Vi tu listado de CryptoAlerts.io y me interesa mucho. ¿Podrías compartirme más detalles sobre el churn rate y la adquisición de usuarios? También me gustaría saber si el precio es negociable."
   - Timestamp: "20 mar, 14:30" en #64748B

   Mensaje 2 (Martín — vendedor, alineado izquierda):
   - Burbuja fondo #0F172A, borde #1E293B, rounded 12px
   - Avatar pequeño + "Martín Rodríguez" en 12px #94A3B8
   - "Hola Laura! Claro, con gusto. El churn está en 4.2% mensual, que es bastante bueno para un SaaS en este nicho. La adquisición es 100% orgánica — SEO + content marketing. No hice ninguna inversión en ads hasta ahora."
   - "20 mar, 15:45"

   Mensaje 3 (Martín):
   - "Respecto al precio, tengo algo de margen. Si te interesa podemos hablar. ¿Querés que te comparta acceso al dashboard de analytics?"
   - "20 mar, 15:47"

   Mensaje 4 (Laura — yo):
   - "Sí, me encantaría ver los analytics. Y una pregunta más: ¿la transferencia incluye las cuentas de redes sociales y la lista de email?"
   - "21 mar, 10:15"

   Mensaje 5 (Martín):
   - "Sí, incluye todo: dominio, código, base de datos, cuentas de Stripe, redes sociales (Twitter con 2.3k followers) y la lista de email (4,200 suscriptores). Te mando el link de analytics por acá."
   - "22 mar, 09:30"

c) INPUT DE MENSAJE (abajo, sticky)
   - Textarea fondo #1E293B, borde #1E293B, placeholder "Escribí tu mensaje...", 2 rows
   - Botón "Enviar" (amber, ícono Send) a la derecha

COLUMNA DERECHA — INFO DEL ACTIVO (sidebar, 35%):

Card (fondo #0F172A, borde #1E293B, rounded 12px, padding 20px):
- Screenshot mini del activo
- "CryptoAlerts.io" (18px semibold)
- Precio: "$18,000 USD" (amber)
- Badge "Verificado" (verde)
- Divider
- Métricas mini:
  - MRR: $2,100
  - Usuarios: 1,247
  - Churn: 4.2%
- Divider
- Vendedor: avatar + "Martín Rodríguez" + "Vendedor verificado ✓"
- Botón "Ver listado completo →" (link amber)
```

---

## PROMPT 4: Mi perfil (`/perfil`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards: #0F172A | Inputs: #1E293B
- Acento: #F59E0B | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Error: #EF4444

Tipografía: DM Sans. Cards: rounded 12px. Inputs/Buttons: rounded 8px.
Logo: cuadrado amber con "Q". Idioma: español argentino.

PÁGINA: Mi perfil — editar información personal

ESTRUCTURA: Sidebar (280px, "Perfil" activo) + contenido

CONTENIDO:

a) HEADER
   - "Mi perfil" (28px semibold #F8FAFC)
   - "Gestioná tu información personal" (#94A3B8)

b) CARD AVATAR (fondo #0F172A, borde #1E293B, rounded 12px, padding 24px)
   - Layout horizontal: avatar circular grande (80px) placeholder con iniciales "LG" fondo amber
   - Al lado: "Laura García" (20px semibold), "laura@email.com" en #94A3B8, "Miembro desde marzo 2025" en #64748B
   - Botón "Cambiar foto" (outline amber, pequeño)

c) FORMULARIO — Información personal (card fondo #0F172A, rounded 12px, padding 32px)
   - Heading: "Información personal" (16px semibold)
   - 2 columnas:
     - "Nombre completo": input pre-llenado "Laura García"
     - "Email": input pre-llenado "laura@email.com" — disabled con candado, texto "Verificado ✓" verde
   - 2 columnas:
     - "Empresa / Nombre comercial": input pre-llenado "García Ventures"
     - "Sitio web": input pre-llenado "https://garciaventures.com"
   - "Bio" (textarea):
     Pre-llenado: "Inversora en activos digitales. Busco proyectos SaaS con revenue recurrente y potencial de crecimiento."
   - Botón "Guardar cambios" (amber sólido) alineado derecha

d) CARD SEGURIDAD (fondo #0F172A, rounded 12px, padding 32px)
   - Heading: "Seguridad"
   - "Contraseña": "Última actualización: hace 3 meses" en #94A3B8
   - Botón "Cambiar contraseña" (outline amber)
   - Divider
   - "Sesiones activas": "Este dispositivo · Buenos Aires, Argentina · Chrome" en #94A3B8
   - Botón "Cerrar todas las sesiones" (outline rojo, pequeño)

e) CARD NOTIFICACIONES (fondo #0F172A, rounded 12px, padding 32px)
   - Heading: "Notificaciones"
   - Toggles (switch amber cuando activo, #1E293B cuando inactivo):
     - "Nuevas consultas sobre mis activos" — ON
     - "Respuestas a mis consultas" — ON
     - "Nuevos activos en mis categorías favoritas" — OFF
     - "Newsletter de Qapitaliza" — ON
```
