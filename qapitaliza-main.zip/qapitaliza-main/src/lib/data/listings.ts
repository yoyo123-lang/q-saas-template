import { getPrisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'
import { trackEvent } from '@/lib/analytics/events'

const PAGE_SIZE = 20
const MAX_PAGE_SIZE = 100

// ─── Seller-specific types ────────────────────────────────────

export interface SellerStats {
  publishedCount: number
  totalViews: number
  activeInquiries: number
  totalListedRevenue: number
  draftCount: number
  pendingCount: number
  soldCount: number
}

export type ActivityType = 'inquiry' | 'featured' | 'approved' | 'view' | 'replied'

export interface Activity {
  id: string
  type: ActivityType
  text: string
  createdAt: Date
}

export interface SellerListingParams {
  status?: 'all' | 'published' | 'draft' | 'pending' | 'sold'
  q?: string
  page?: number
  limit?: number
}

export interface PaginatedListings {
  items: SellerListingItem[]
  total: number
  publishedCount: number
  draftCount: number
  pendingCount: number
  soldCount: number
}

export interface ListingQueryParams {
  q?: string
  category?: string
  priceMin?: number
  priceMax?: number
  revenueMin?: number
  verified?: boolean
  tech?: string[]
  sort?: 'newest' | 'price_asc' | 'price_desc' | 'views'
  page?: number
  limit?: number
}

export type ListingWithSeller = Prisma.ListingGetPayload<{
  include: { seller: true; metrics: true; category: true }
}>

export type SellerListingItem = Prisma.ListingGetPayload<{
  include: {
    seller: true
    metrics: true
    category: true
    _count: { select: { inquiries: true } }
  }
}>

/**
 * Fetches published listings matching the given filter params.
 * Uses full-text search on title+description when `q` is provided.
 */
export async function getListings(
  params: ListingQueryParams = {}
): Promise<{ items: ListingWithSeller[]; total: number }> {
  const {
    q,
    category,
    priceMin,
    priceMax,
    revenueMin,
    verified,
    tech,
    sort = 'newest',
    page = 1,
    limit,
  } = params

  const pageSize = Math.min(limit ?? PAGE_SIZE, MAX_PAGE_SIZE)
  const skip = (Math.max(page, 1) - 1) * pageSize

  const where: Prisma.ListingWhereInput = {
    status: 'PUBLISHED',
  }

  // Full-text search using Postgres tsvector
  if (q && q.trim()) {
    where.OR = [
      { title: { contains: q, mode: 'insensitive' } },
      { description: { contains: q, mode: 'insensitive' } },
    ]
  }

  // Category filter via slug
  if (category) {
    where.category = { slug: category }
  }

  // Price range
  if (priceMin != null || priceMax != null) {
    where.askingPrice = {}
    if (priceMin != null) (where.askingPrice as Prisma.DecimalFilter).gte = new Prisma.Decimal(priceMin)
    if (priceMax != null) (where.askingPrice as Prisma.DecimalFilter).lte = new Prisma.Decimal(priceMax)
  }

  // Revenue filter
  if (revenueMin != null) {
    where.monthlyRevenue = { gte: new Prisma.Decimal(revenueMin) }
  }

  // Verified filter
  if (verified) {
    where.verificationStatus = 'VERIFIED'
  }

  // Tech stack filter — listing must contain ALL specified techs
  if (tech && tech.length > 0) {
    // Prisma doesn't support @> for arrays natively; use raw for contains-all
    // We'll filter client-side after fetching OR use a workaround:
    // Filter each tech as an array member check
    where.AND = tech.map((t) => ({
      techStack: { has: t },
    }))
  }

  const orderBy: Prisma.ListingOrderByWithRelationInput =
    sort === 'price_asc'
      ? { askingPrice: 'asc' }
      : sort === 'price_desc'
        ? { askingPrice: 'desc' }
        : sort === 'views'
          ? { viewCount: 'desc' }
          : { publishedAt: 'desc' }

  const [items, total] = await Promise.all([
    getPrisma().listing.findMany({
      where,
      include: { seller: true, metrics: true, category: true },
      orderBy,
      skip,
      take: pageSize,
    }),
    getPrisma().listing.count({ where }),
  ])

  return { items, total }
}

/**
 * Fetches a single published listing by slug.
 * Returns null if not found or not published.
 */
export async function getListing(slug: string): Promise<ListingWithSeller | null> {
  return getPrisma().listing.findFirst({
    where: { slug, status: 'PUBLISHED' },
    include: { seller: true, metrics: true, category: true },
  })
}

/**
 * Fetches related listings of the same type, excluding the given listing.
 */
export async function getRelatedListings(
  listingId: string,
  type: string,
  limit = 3
): Promise<ListingWithSeller[]> {
  return getPrisma().listing.findMany({
    where: {
      status: 'PUBLISHED',
      type: type as Prisma.EnumListingTypeFilter['equals'],
      id: { not: listingId },
    },
    include: { seller: true, metrics: true, category: true },
    orderBy: { publishedAt: 'desc' },
    take: limit,
  })
}

/**
 * Returns aggregated stats for a seller's dashboard.
 */
export async function getSellerStats(sellerId: string): Promise<SellerStats> {
  const prisma = getPrisma()

  const [published, draft, pending, sold, viewsAgg, inquiriesAgg] = await Promise.all([
    prisma.listing.count({ where: { sellerId, status: 'PUBLISHED' } }),
    prisma.listing.count({ where: { sellerId, status: 'DRAFT' } }),
    prisma.listing.count({ where: { sellerId, status: 'PENDING_REVIEW' } }),
    prisma.listing.count({ where: { sellerId, status: 'SOLD' } }),
    prisma.listing.aggregate({
      where: { sellerId },
      _sum: { viewCount: true },
    }),
    prisma.inquiry.count({
      where: {
        listing: { sellerId },
        status: { in: ['OPEN', 'REPLIED'] },
      },
    }),
  ])

  // Sum asking prices of active listings as "total listed revenue"
  const revenueAgg = await prisma.listing.aggregate({
    where: { sellerId, status: 'PUBLISHED' },
    _sum: { askingPrice: true },
  })

  return {
    publishedCount: published,
    totalViews: viewsAgg._sum.viewCount ?? 0,
    activeInquiries: inquiriesAgg,
    totalListedRevenue: Number(revenueAgg._sum.askingPrice ?? 0),
    draftCount: draft,
    pendingCount: pending,
    soldCount: sold,
  }
}

/**
 * Returns the last N audit log entries for a seller as activity items.
 */
export async function getRecentActivity(sellerId: string, limit = 5): Promise<Activity[]> {
  const prisma = getPrisma()

  const logs = await prisma.auditLog.findMany({
    where: {
      actorId: sellerId,
      action: { in: ['INQUIRY_SENT', 'LISTING_FEATURED', 'LISTING_PUBLISHED', 'LISTING_VIEWED', 'INQUIRY_REPLIED'] },
    },
    orderBy: { createdAt: 'desc' },
    take: limit,
  })

  return logs.map((log) => {
    let type: ActivityType = 'view'
    let text = 'Actividad registrada'

    switch (log.action) {
      case 'INQUIRY_SENT':
        type = 'inquiry'
        text = 'Nueva consulta recibida'
        break
      case 'LISTING_FEATURED':
        type = 'featured'
        text = 'Activo destacado'
        break
      case 'LISTING_PUBLISHED':
        type = 'approved'
        text = 'Activo aprobado y publicado'
        break
      case 'LISTING_VIEWED':
        type = 'view'
        text = 'Nueva vista en tu activo'
        break
      case 'INQUIRY_REPLIED':
        type = 'replied'
        text = 'Consulta respondida'
        break
    }

    return { id: log.id, type, text, createdAt: log.createdAt }
  })
}

/**
 * Returns paginated listings for a seller with status counts.
 */
export async function getSellerListings(
  sellerId: string,
  params: SellerListingParams = {}
): Promise<PaginatedListings> {
  const prisma = getPrisma()
  const { status = 'all', q, page = 1, limit = PAGE_SIZE } = params

  const pageSize = Math.min(limit, MAX_PAGE_SIZE)
  const skip = (Math.max(page, 1) - 1) * pageSize

  const statusMap: Record<string, string[]> = {
    published: ['PUBLISHED'],
    draft: ['DRAFT'],
    pending: ['PENDING_REVIEW'],
    sold: ['SOLD'],
    all: [],
  }

  const where: Prisma.ListingWhereInput = { sellerId }

  const statusValues = statusMap[status] ?? []
  if (statusValues.length > 0) {
    where.status = { in: statusValues as Prisma.EnumListingStatusFilter['in'] }
  }

  if (q?.trim()) {
    where.title = { contains: q.trim(), mode: 'insensitive' }
  }

  const [items, total, publishedCount, draftCount, pendingCount, soldCount] = await Promise.all([
    prisma.listing.findMany({
      where,
      include: {
        seller: true,
        metrics: true,
        category: true,
        _count: { select: { inquiries: true } },
      },
      orderBy: { updatedAt: 'desc' },
      skip,
      take: pageSize,
    }),
    prisma.listing.count({ where }),
    prisma.listing.count({ where: { sellerId, status: 'PUBLISHED' } }),
    prisma.listing.count({ where: { sellerId, status: 'DRAFT' } }),
    prisma.listing.count({ where: { sellerId, status: 'PENDING_REVIEW' } }),
    prisma.listing.count({ where: { sellerId, status: 'SOLD' } }),
  ])

  return { items, total, publishedCount, draftCount, pendingCount, soldCount }
}

/**
 * Increments the view count of a listing and records an audit log entry.
 * Called from Server Components — not exposed to clients.
 * Fire-and-forget: errors are logged but not propagated.
 */
export async function incrementListingViews(id: string): Promise<void> {
  const prisma = getPrisma()
  await Promise.all([
    prisma.listing.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    }),
    // TODO (Sesión 05): pass actorId from SSR session once auth is available
    trackEvent('LISTING_VIEWED', 'listing', id, null),
  ])
}
