'use client'

import { useState } from 'react'
import { CreativePreview } from './CreativePreview'
import type { AdCreatives, AdCopyVariant } from '../../app/_lib/interview/types'

interface AdCreativesStepProps {
  creatives: AdCreatives
  businessName?: string
}

type Tab = 'google_search' | 'meta_feed' | 'meta_story'

/**
 * Muestra las piezas publicitarias generadas por IA, agrupadas por plataforma/formato.
 * Permite al cliente revisar los copies antes de que el equipo los active.
 */
export function AdCreativesStep({ creatives, businessName }: AdCreativesStepProps) {
  const availableTabs: Tab[] = []
  if (creatives.googleAds?.search?.length) availableTabs.push('google_search')
  if (creatives.metaAds?.feed?.length) availableTabs.push('meta_feed')
  if (creatives.metaAds?.story?.length) availableTabs.push('meta_story')

  const [activeTab, setActiveTab] = useState<Tab>(availableTabs[0] ?? 'google_search')

  if (availableTabs.length === 0) {
    return (
      <div className="rounded-lg bg-zinc-800/50 px-4 py-6 text-center">
        <p className="text-sm text-zinc-400">No hay piezas generadas aún.</p>
      </div>
    )
  }

  const variants = getVariantsForTab(creatives, activeTab)
  const [platform, format] = getFormatForTab(activeTab)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-white">Tus piezas publicitarias</h2>
        <p className="mt-1 text-sm text-zinc-400">
          Revisá los copies generados para cada plataforma. El equipo los va a ajustar antes de activar.
        </p>
      </div>

      {/* Tab selector */}
      {availableTabs.length > 1 && (
        <div className="flex gap-2 flex-wrap">
          {availableTabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                activeTab === tab
                  ? 'bg-white text-black'
                  : 'bg-white/10 text-zinc-300 hover:bg-white/15'
              }`}
            >
              {getTabLabel(tab)}
            </button>
          ))}
        </div>
      )}

      {/* Variantes */}
      <div className="space-y-4">
        {variants.map((variant, i) => (
          <div key={i} className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium uppercase tracking-wide text-zinc-500">
                Variante {i + 1}
              </span>
              <span className="rounded bg-zinc-700/50 px-2 py-0.5 text-xs text-zinc-400">
                {variant.angle}
              </span>
            </div>
            <CreativePreview
              variant={variant}
              platform={platform}
              format={format}
              businessName={businessName}
            />
          </div>
        ))}
      </div>

      {/* Guía de tono */}
      <div className="rounded-lg bg-zinc-800/50 px-4 py-3 space-y-2">
        <p className="text-xs font-medium text-zinc-300">Guía de tono para el diseño</p>
        <p className="text-sm text-zinc-400">{creatives.guiaDeTono.tono}</p>
        {creatives.guiaDeTono.palabrasClave.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {creatives.guiaDeTono.palabrasClave.map((kw) => (
              <span key={kw} className="rounded bg-emerald-500/10 px-2 py-0.5 text-xs text-emerald-400">
                {kw}
              </span>
            ))}
          </div>
        )}
        {creatives.guiaDeTono.evitar.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            <span className="text-xs text-zinc-500">Evitar:</span>
            {creatives.guiaDeTono.evitar.map((term) => (
              <span key={term} className="rounded bg-red-500/10 px-2 py-0.5 text-xs text-red-400">
                {term}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Disclaimer */}
      <p className="text-xs text-zinc-600 leading-relaxed">{creatives.disclaimer}</p>
    </div>
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function getVariantsForTab(creatives: AdCreatives, tab: Tab): AdCopyVariant[] {
  switch (tab) {
    case 'google_search': return creatives.googleAds?.search ?? []
    case 'meta_feed': return creatives.metaAds?.feed ?? []
    case 'meta_story': return creatives.metaAds?.story ?? []
  }
}

function getFormatForTab(tab: Tab): [platform: 'GOOGLE_ADS' | 'META', format: 'SEARCH' | 'FEED' | 'STORY'] {
  switch (tab) {
    case 'google_search': return ['GOOGLE_ADS', 'SEARCH']
    case 'meta_feed': return ['META', 'FEED']
    case 'meta_story': return ['META', 'STORY']
  }
}

function getTabLabel(tab: Tab): string {
  switch (tab) {
    case 'google_search': return 'Google Search'
    case 'meta_feed': return 'Meta Feed'
    case 'meta_story': return 'Meta Story'
  }
}
