-- ============================================================
-- ROLLBACK 007 — Audit Log
-- ============================================================

DROP TABLE IF EXISTS public.audit_log CASCADE;

DROP TYPE IF EXISTS audit_action CASCADE;
