'use client'

import { useState } from 'react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import { Select } from '@/components/ui/select'

const periodOptions = [
  { value: '7', label: 'Últimos 7 días' },
  { value: '30', label: 'Últimos 30 días' },
  { value: '90', label: 'Últimos 90 días' },
]

interface ViewsDataPoint {
  date: string
  vistas: number
}

interface ViewsChartProps {
  data?: ViewsDataPoint[]
}

export function ViewsChart({ data }: ViewsChartProps) {
  const [period, setPeriod] = useState('30')

  const isEmpty = !data || data.length === 0

  return (
    <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="font-semibold text-slate-50">Vistas de tus activos</h2>
        <div className="w-44">
          <Select
            options={periodOptions}
            value={period}
            onChange={setPeriod}
          />
        </div>
      </div>

      {isEmpty ? (
        <div className="h-[200px] flex items-center justify-center">
          <p className="text-sm text-slate-500">
            Los datos de vistas estarán disponibles próximamente.
          </p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="amberGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#F59E0B" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
            <XAxis
              dataKey="date"
              tick={{ fill: '#64748B', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tick={{ fill: '#64748B', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0B0F1A',
                border: '1px solid #1E293B',
                borderRadius: '8px',
                color: '#F8FAFC',
              }}
              labelStyle={{ color: '#94A3B8', fontSize: 12 }}
              itemStyle={{ color: '#F59E0B' }}
            />
            <Area
              type="monotone"
              dataKey="vistas"
              stroke="#F59E0B"
              strokeWidth={2}
              fill="url(#amberGradient)"
              dot={false}
              activeDot={{ r: 4, fill: '#F59E0B', stroke: '#0B0F1A', strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}
