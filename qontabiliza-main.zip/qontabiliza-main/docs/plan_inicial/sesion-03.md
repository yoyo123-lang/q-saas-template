# Sesión 03: Productos y catálogo

## Objetivo
CRUD completo de categorías y productos con variantes. Listado con filtros, búsqueda, y formularios de alta/edición. Al terminar, el usuario puede gestionar su catálogo completo de productos.

## Pre-requisitos
- Sesión 02 completada (TenantProvider, API de orgs, onboarding)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/lib/get-tenant-from-request.ts` (patrón de tenant en API routes)
3. Leer `src/app/api/v1/projects/` como patrón de CRUD API
4. Leer `src/app/dashboard/projects/` como patrón de páginas CRUD
5. Leer `src/components/shared/data-table.tsx` para entender la DataTable existente

---

## Etapa 1: Validaciones Zod y tipos

### Tarea 1.1: Validaciones de Category
**Archivo nuevo**: `src/lib/validations/category.ts`

Schemas:
- `createCategorySchema`: name (string, min 1, max 100), description (optional), parentId (optional cuid)
- `updateCategorySchema`: parcial de create
- `categoryFilterSchema`: search (optional), parentId (optional)

### Tarea 1.2: Validaciones de Product
**Archivo nuevo**: `src/lib/validations/product.ts`

Schemas:
- `createProductSchema`:
  - name (string, min 1, max 200, requerido)
  - description (optional)
  - sku (optional string)
  - barcode (optional string)
  - basePrice (number, min 0, requerido)
  - costPrice (optional number, min 0)
  - ivaRate (enum: 0, 2.5, 5, 10.5, 21, 27 — tasas válidas de IVA argentino)
  - categoryId (optional cuid)
  - trackStock (boolean, default true)
  - minStock (number, min 0, default 0)
  - variants (optional array de { name, sku?, barcode?, priceAdjustment? })
- `updateProductSchema`: parcial de create
- `productFilterSchema`: search, categoryId, isActive, minPrice, maxPrice, page, perPage

### Tarea 1.3: Tipos TypeScript
**Archivo nuevo**: `src/types/product.ts`

Tipos para las respuestas de API:
- `CategoryResponse` — category con count de productos
- `ProductResponse` — product con category name, variants, stock actual (calculado)
- `ProductListResponse` — paginado con items, total, page, perPage

**Commit**: `feat(products): add Zod validations and TypeScript types for products and categories`

---

## Etapa 2: API routes

### Tarea 2.1: API routes de Category
**Archivos nuevos**:
- `src/app/api/v1/categories/route.ts` — GET (list con count), POST (crear)
- `src/app/api/v1/categories/[id]/route.ts` — GET, PUT, DELETE

Todas las routes:
- Usar `getTenantFromRequest()` para validar tenant
- Usar `withTenant(tenantId)` para filtrar queries
- Soft delete en DELETE
- GET list: incluir count de productos por categoría
- GET list: soportar filtro por parentId para categorías anidadas

### Tarea 2.2: API routes de Product
**Archivos nuevos**:
- `src/app/api/v1/products/route.ts` — GET (list paginado), POST (crear con variantes)
- `src/app/api/v1/products/[id]/route.ts` — GET (con variantes y stock), PUT, DELETE

Comportamiento:
- GET list: paginado, filtros por categoría/estado/búsqueda, incluir stock actual
- POST: crear producto + variantes en transacción
- PUT: actualizar producto, crear/actualizar/eliminar variantes (upsert)
- DELETE: soft delete
- Búsqueda: por name, sku, barcode (insensitive)
- Calcular stock actual: `SUM(stockMovements.quantity) WHERE productId = x`

### Tarea 2.3: Tests de integración
**Archivo nuevo**: `src/app/api/v1/categories/__tests__/categories.test.ts`
**Archivo nuevo**: `src/app/api/v1/products/__tests__/products.test.ts`

Tests clave:
- CRUD completo de categorías
- CRUD completo de productos
- Crear producto con variantes
- Filtros y búsqueda
- Tenant isolation (un tenant no ve productos de otro)
- Soft delete funciona
- Validaciones rechazan datos inválidos

**Commit**: `feat(api): add Category and Product CRUD endpoints with tests`

---

## Etapa 3: Frontend — Listado de productos

### Tarea 3.1: Hook useCategories
**Archivo nuevo**: `src/hooks/use-categories.ts`

Hook que expone:
- `categories`: lista de categorías
- `isLoading`, `error`
- `createCategory(data)`, `updateCategory(id, data)`, `deleteCategory(id)`
- `refetch()`

### Tarea 3.2: Hook useProducts
**Archivo nuevo**: `src/hooks/use-products.ts`

Hook que expone:
- `products`: lista paginada de productos
- `pagination`: { page, perPage, total }
- `filters`: { search, categoryId, isActive }
- `setFilters(filters)`, `setPage(page)`
- `isLoading`, `error`
- `createProduct(data)`, `updateProduct(id, data)`, `deleteProduct(id)`
- `refetch()`

### Tarea 3.3: Página de listado de productos
**Archivo nuevo**: `src/app/dashboard/products/page.tsx`

Layout:
- Título "Productos" con breadcrumb
- Botón "Nuevo producto" (arriba a la derecha)
- Barra de filtros: búsqueda por texto, dropdown de categoría, toggle activos/todos
- DataTable con columnas: Nombre, SKU, Categoría, Precio, Stock, Estado, Acciones
- Acciones por fila: Editar, Eliminar (con confirmación)
- Empty state si no hay productos
- Paginación

Usar componentes existentes: `DataTable`, `EmptyState`, `LoadingState`, `ConfirmDialog`

Precios formateados con `formatNumber()` (formato argentino: $1.234,56)

**Commit**: `feat(ui): add products list page with filters and pagination`

---

## Etapa 4: Frontend — Formularios

### Tarea 4.1: Página de gestión de categorías
**Archivo nuevo**: `src/app/dashboard/products/categories/page.tsx`

Vista simple:
- Lista de categorías en una tabla/lista
- Inline create (input + botón)
- Inline edit (click para editar nombre)
- Delete con confirmación
- Drag and drop para reordenar (sortOrder) — si es complejo, omitir y dejar botones arriba/abajo

### Tarea 4.2: Formulario de crear/editar producto
**Archivo nuevo**: `src/app/dashboard/products/new/page.tsx`
**Archivo nuevo**: `src/app/dashboard/products/[id]/edit/page.tsx`

Formulario con secciones:
1. **Información básica**: nombre, descripción, SKU, código de barras
2. **Categoría**: dropdown con categorías existentes + opción "Sin categoría"
3. **Precios**: precio base, precio de costo, tasa de IVA (dropdown: 0%, 2.5%, 5%, 10.5%, 21%, 27%)
4. **Stock**: toggle trackStock, stock mínimo
5. **Variantes**: sección dinámica — agregar/quitar variantes con nombre, SKU, barcode, ajuste de precio

Usar react-hook-form + zod resolver para validación client-side.

El formulario de editar carga datos existentes y hace PUT.

### Tarea 4.3: Página de detalle de producto
**Archivo nuevo**: `src/app/dashboard/products/[id]/page.tsx`

Vista de solo lectura con:
- Datos del producto
- Lista de variantes
- Stock actual
- Últimos movimientos de stock (si hay)
- Botón "Editar"

**Commit**: `feat(ui): add product forms (create, edit, detail) and category management`

---

## Checklist de cierre de sesión

- [ ] API routes de categorías con CRUD completo
- [ ] API routes de productos con CRUD, variantes, filtros y paginación
- [ ] Listado de productos con DataTable, filtros y búsqueda
- [ ] Formularios de crear/editar producto con variantes
- [ ] Gestión de categorías
- [ ] Página de detalle de producto
- [ ] Tests de integración para APIs
- [ ] Tenant isolation verificado
- [ ] Formato argentino en precios
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
