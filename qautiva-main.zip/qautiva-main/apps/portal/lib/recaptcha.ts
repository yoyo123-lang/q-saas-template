declare global {
  interface Window {
    grecaptcha: {
      ready: (cb: () => void) => void
      execute: (siteKey: string, options: { action: string }) => Promise<string>
    }
  }
}

export async function getRecaptchaToken(action: string): Promise<string> {
  const siteKey = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY

  if (!siteKey) {
    if (process.env.NODE_ENV !== 'production') {
      console.warn('[reCAPTCHA] NEXT_PUBLIC_RECAPTCHA_SITE_KEY no configurada — devolviendo token vacío en dev')
      return 'dev-token'
    }
    throw new Error('reCAPTCHA site key no configurada')
  }

  return new Promise((resolve, reject) => {
    window.grecaptcha.ready(() => {
      window.grecaptcha.execute(siteKey, { action })
        .then(resolve)
        .catch(reject)
    })
  })
}
