'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import { Heart } from 'lucide-react'
import { toast } from 'sonner'
import { toggleFavorite } from '@/lib/actions/favorites'
import { ListingCard } from '@/components/listings/listing-card'
import { EmptyState } from '@/components/shared/empty-state'
import type { FavoriteListing } from '@/lib/data/favorites'

interface FavoritesGridProps {
  initialFavorites: FavoriteListing[]
}

export function FavoritesGrid({ initialFavorites }: FavoritesGridProps) {
  const [favorites, setFavorites] = useState(initialFavorites)
  const [removingIds, setRemovingIds] = useState<Set<string>>(new Set())
  const [, startTransition] = useTransition()

  function handleToggle(listingId: string) {
    // Animate out
    setRemovingIds((prev) => new Set(prev).add(listingId))

    startTransition(async () => {
      const result = await toggleFavorite(listingId)
      if (!result.success) {
        // Revert animation
        setRemovingIds((prev) => {
          const next = new Set(prev)
          next.delete(listingId)
          return next
        })
        toast.error(result.error ?? 'Error al actualizar favoritos.')
        return
      }
      // Remove from list after animation completes
      setTimeout(() => {
        setFavorites((prev) => prev.filter((f) => f.id !== listingId))
        setRemovingIds((prev) => {
          const next = new Set(prev)
          next.delete(listingId)
          return next
        })
      }, 300)
      toast.success('Eliminado de favoritos')
    })
  }

  if (favorites.length === 0) {
    return (
      <EmptyState
        icon={<Heart className="size-6" />}
        title="Todavía no guardaste activos"
        description="Explorá el catálogo y guardá los que te interesen."
        cta={
          <Link
            href="/explorar"
            className="px-4 py-2 rounded-lg bg-amber-500 text-navy-950 text-sm font-semibold hover:bg-amber-400 transition-colors"
          >
            Explorar activos
          </Link>
        }
      />
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {favorites.map((item) => {
        const isRemoving = removingIds.has(item.id)
        const badges: ('verified' | 'featured' | 'premium')[] = []
        if (item.verificationStatus === 'VERIFIED') badges.push('verified')
        if (item.featuredUntil && new Date(item.featuredUntil) > new Date()) badges.push('featured')

        return (
          <div
            key={item.id}
            className="transition-all duration-300"
            style={{
              opacity: isRemoving ? 0 : 1,
              transform: isRemoving ? 'scale(0.95)' : 'scale(1)',
            }}
          >
            <ListingCard
              id={item.id}
              slug={item.slug}
              title={item.title}
              type={item.type}
              priceUsd={parseFloat(item.askingPrice)}
              screenshot={item.screenshotUrls[0]}
              metrics={{
                mrr: item.monthlyRevenue ? parseFloat(item.monthlyRevenue) : undefined,
                monthlyVisits: item.monthlyTraffic ?? undefined,
              }}
              techStack={item.techStack}
              badges={badges}
              isFavorited={true}
              onFavoriteToggle={handleToggle}
            />
          </div>
        )
      })}
    </div>
  )
}
