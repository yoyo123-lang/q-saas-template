import { cn } from '@/lib/utils/cn'

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  helper?: string
  error?: string
  rows?: number
}

export function Textarea({
  label,
  helper,
  error,
  rows = 4,
  maxLength,
  value,
  defaultValue,
  id,
  className,
  onChange,
  ...props
}: TextareaProps) {
  const textareaId = id ?? label?.toLowerCase().replace(/\s+/g, '-')
  const errorId = textareaId ? `${textareaId}-error` : undefined
  const helperId = textareaId ? `${textareaId}-helper` : undefined

  const currentLength =
    typeof value === 'string'
      ? value.length
      : typeof defaultValue === 'string'
        ? defaultValue.length
        : 0

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label
          htmlFor={textareaId}
          className="text-sm font-medium text-slate-400 block"
        >
          {label}
        </label>
      )}

      <textarea
        id={textareaId}
        rows={rows}
        maxLength={maxLength}
        value={value}
        defaultValue={defaultValue}
        onChange={onChange}
        aria-invalid={!!error}
        aria-describedby={error ? errorId : helper ? helperId : undefined}
        className={cn(
          'w-full bg-slate-800 border border-slate-800 rounded-lg px-3 py-2.5',
          'text-sm text-slate-50 placeholder:text-slate-500 resize-y',
          'focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent',
          'transition-all duration-150',
          error && 'border-red-500 focus:ring-red-500',
          className
        )}
        {...props}
      />

      <div className="flex justify-between items-center">
        <span>
          {error ? (
            <span id={errorId} className="text-xs text-red-400">
              {error}
            </span>
          ) : helper ? (
            <span id={helperId} className="text-xs text-slate-500">
              {helper}
            </span>
          ) : null}
        </span>
        {maxLength && (
          <span className="text-xs text-slate-500 ml-auto">
            {currentLength} / {maxLength} caracteres
          </span>
        )}
      </div>
    </div>
  )
}
