-- Migración: Modelos de dominio Qontabiliza (Sesión 1)
-- Fecha: 2026-03-25
-- Agrega: Organization, Membership, Plan, Subscription, Category, Product,
--         ProductVariant, PriceList, PriceListItem, Contact, Invoice, InvoiceItem,
--         Sale, SaleItem, Warehouse, StockMovement, CashRegister, PaymentRecord

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE "MemberRole" AS ENUM ('OWNER', 'ADMIN', 'MEMBER');

CREATE TYPE "PlanSlug" AS ENUM ('MICRO', 'STARTER', 'PRO', 'MAX');

CREATE TYPE "SubscriptionStatus" AS ENUM ('TRIAL', 'ACTIVE', 'SUSPENDED', 'CANCELLED');

CREATE TYPE "IvaCondition" AS ENUM (
  'RESPONSABLE_INSCRIPTO',
  'MONOTRIBUTISTA',
  'EXENTO',
  'CONSUMIDOR_FINAL',
  'NO_CATEGORIZADO'
);

CREATE TYPE "ContactType" AS ENUM ('CUSTOMER', 'SUPPLIER', 'BOTH');

CREATE TYPE "InvoiceType" AS ENUM (
  'FACTURA_A', 'FACTURA_B', 'FACTURA_C',
  'NOTA_CREDITO_A', 'NOTA_CREDITO_B', 'NOTA_CREDITO_C',
  'NOTA_DEBITO_A', 'NOTA_DEBITO_B', 'NOTA_DEBITO_C'
);

CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT', 'ISSUED', 'CANCELLED');

CREATE TYPE "SaleStatus" AS ENUM ('COMPLETED', 'CANCELLED', 'REFUNDED');

CREATE TYPE "MovementType" AS ENUM (
  'PURCHASE', 'SALE', 'ADJUSTMENT', 'TRANSFER_IN', 'TRANSFER_OUT', 'RETURN'
);

CREATE TYPE "CashRegisterStatus" AS ENUM ('OPEN', 'CLOSED');

CREATE TYPE "PaymentMethod" AS ENUM (
  'CASH', 'CARD_DEBIT', 'CARD_CREDIT', 'TRANSFER', 'QOBRA', 'CHECK', 'OTHER'
);

-- ============================================================
-- MULTI-TENANCY
-- ============================================================

CREATE TABLE IF NOT EXISTS "Organization" (
  "id"          TEXT NOT NULL,
  "name"        TEXT NOT NULL,
  "slug"        TEXT NOT NULL,
  "fiscalData"  JSONB NOT NULL DEFAULT '{}',
  "settings"    JSONB NOT NULL DEFAULT '{}',
  "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"   TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Organization_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Organization_slug_key" ON "Organization"("slug");

CREATE TABLE IF NOT EXISTS "Membership" (
  "id"             TEXT NOT NULL,
  "userId"         TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "role"           "MemberRole" NOT NULL DEFAULT 'MEMBER',
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Membership_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Membership_userId_organizationId_key" ON "Membership"("userId", "organizationId");
CREATE INDEX IF NOT EXISTS "Membership_userId_idx" ON "Membership"("userId");
CREATE INDEX IF NOT EXISTS "Membership_organizationId_idx" ON "Membership"("organizationId");

ALTER TABLE "Membership"
  ADD CONSTRAINT "Membership_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "Membership_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE;

-- ============================================================
-- PLANES Y SUSCRIPCIONES
-- ============================================================

CREATE TABLE IF NOT EXISTS "Plan" (
  "id"                     TEXT NOT NULL,
  "name"                   TEXT NOT NULL,
  "slug"                   "PlanSlug" NOT NULL,
  "maxUsers"               INTEGER NOT NULL,
  "maxMonthlyComprobantes" INTEGER NOT NULL,
  "priceMonthly"           DECIMAL(10,2) NOT NULL,
  "features"               JSONB NOT NULL DEFAULT '[]',
  "isActive"               BOOLEAN NOT NULL DEFAULT true,
  "createdAt"              TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"              TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Plan_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Plan_slug_key" ON "Plan"("slug");

CREATE TABLE IF NOT EXISTS "Subscription" (
  "id"                 TEXT NOT NULL,
  "organizationId"     TEXT NOT NULL,
  "planId"             TEXT NOT NULL,
  "status"             "SubscriptionStatus" NOT NULL DEFAULT 'TRIAL',
  "trialEndsAt"        TIMESTAMP(3),
  "currentPeriodStart" TIMESTAMP(3),
  "currentPeriodEnd"   TIMESTAMP(3),
  "createdAt"          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"          TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Subscription_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Subscription_organizationId_idx" ON "Subscription"("organizationId");
CREATE INDEX IF NOT EXISTS "Subscription_planId_idx" ON "Subscription"("planId");

ALTER TABLE "Subscription"
  ADD CONSTRAINT "Subscription_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES "Plan"("id");

-- ============================================================
-- CATÁLOGO
-- ============================================================

CREATE TABLE IF NOT EXISTS "Category" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "name"           TEXT NOT NULL,
  "slug"           TEXT NOT NULL,
  "description"    TEXT,
  "parentId"       TEXT,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Category_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Category_organizationId_slug_key" ON "Category"("organizationId", "slug");
CREATE INDEX IF NOT EXISTS "Category_organizationId_idx" ON "Category"("organizationId");
CREATE INDEX IF NOT EXISTS "Category_parentId_idx" ON "Category"("parentId");

ALTER TABLE "Category"
  ADD CONSTRAINT "Category_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "Category_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "Category"("id");

CREATE TABLE IF NOT EXISTS "Product" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "categoryId"     TEXT,
  "name"           TEXT NOT NULL,
  "sku"            TEXT,
  "description"    TEXT,
  "barcode"        TEXT,
  "unit"           TEXT NOT NULL DEFAULT 'unidad',
  "basePrice"      DECIMAL(12,2) NOT NULL,
  "minStock"       DECIMAL(12,3) NOT NULL DEFAULT 0,
  "isActive"       BOOLEAN NOT NULL DEFAULT true,
  "deletedAt"      TIMESTAMP(3),
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Product_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Product_organizationId_sku_key" ON "Product"("organizationId", "sku");
CREATE INDEX IF NOT EXISTS "Product_organizationId_idx" ON "Product"("organizationId");
CREATE INDEX IF NOT EXISTS "Product_categoryId_idx" ON "Product"("categoryId");
CREATE INDEX IF NOT EXISTS "Product_organizationId_barcode_idx" ON "Product"("organizationId", "barcode");
CREATE INDEX IF NOT EXISTS "Product_organizationId_deletedAt_createdAt_idx" ON "Product"("organizationId", "deletedAt", "createdAt");

ALTER TABLE "Product"
  ADD CONSTRAINT "Product_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "Category"("id");

CREATE TABLE IF NOT EXISTS "ProductVariant" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "productId"      TEXT NOT NULL,
  "name"           TEXT NOT NULL,
  "sku"            TEXT,
  "barcode"        TEXT,
  "basePrice"      DECIMAL(12,2),
  "isActive"       BOOLEAN NOT NULL DEFAULT true,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ProductVariant_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ProductVariant_organizationId_idx" ON "ProductVariant"("organizationId");
CREATE INDEX IF NOT EXISTS "ProductVariant_productId_idx" ON "ProductVariant"("productId");

ALTER TABLE "ProductVariant"
  ADD CONSTRAINT "ProductVariant_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "ProductVariant_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS "PriceList" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "name"           TEXT NOT NULL,
  "description"    TEXT,
  "isDefault"      BOOLEAN NOT NULL DEFAULT false,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PriceList_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PriceList_organizationId_idx" ON "PriceList"("organizationId");

ALTER TABLE "PriceList"
  ADD CONSTRAINT "PriceList_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS "PriceListItem" (
  "id"               TEXT NOT NULL,
  "organizationId"   TEXT NOT NULL,
  "priceListId"      TEXT NOT NULL,
  "productId"        TEXT NOT NULL,
  "productVariantId" TEXT,
  "price"            DECIMAL(12,2) NOT NULL,
  "createdAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"        TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PriceListItem_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "PriceListItem_priceListId_productId_productVariantId_key"
  ON "PriceListItem"("priceListId", "productId", "productVariantId");
CREATE INDEX IF NOT EXISTS "PriceListItem_organizationId_idx" ON "PriceListItem"("organizationId");
CREATE INDEX IF NOT EXISTS "PriceListItem_priceListId_idx" ON "PriceListItem"("priceListId");
CREATE INDEX IF NOT EXISTS "PriceListItem_productId_idx" ON "PriceListItem"("productId");

ALTER TABLE "PriceListItem"
  ADD CONSTRAINT "PriceListItem_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "PriceListItem_priceListId_fkey" FOREIGN KEY ("priceListId") REFERENCES "PriceList"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "PriceListItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "PriceListItem_productVariantId_fkey" FOREIGN KEY ("productVariantId") REFERENCES "ProductVariant"("id");

-- ============================================================
-- CONTACTOS
-- ============================================================

CREATE TABLE IF NOT EXISTS "Contact" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "type"           "ContactType" NOT NULL DEFAULT 'CUSTOMER',
  "name"           TEXT NOT NULL,
  "email"          TEXT,
  "phone"          TEXT,
  "cuit"           TEXT,
  "ivaCondition"   "IvaCondition" NOT NULL DEFAULT 'CONSUMIDOR_FINAL',
  "fiscalAddress"  JSONB NOT NULL DEFAULT '{}',
  "isActive"       BOOLEAN NOT NULL DEFAULT true,
  "deletedAt"      TIMESTAMP(3),
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Contact_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Contact_organizationId_idx" ON "Contact"("organizationId");
CREATE INDEX IF NOT EXISTS "Contact_organizationId_type_idx" ON "Contact"("organizationId", "type");
CREATE INDEX IF NOT EXISTS "Contact_organizationId_cuit_idx" ON "Contact"("organizationId", "cuit");

ALTER TABLE "Contact"
  ADD CONSTRAINT "Contact_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE;

-- ============================================================
-- FACTURACIÓN
-- ============================================================

CREATE TABLE IF NOT EXISTS "Invoice" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "invoiceType"    "InvoiceType" NOT NULL,
  "number"         INTEGER NOT NULL,
  "series"         TEXT NOT NULL DEFAULT '0001',
  "contactId"      TEXT,
  "subtotal"       DECIMAL(12,2) NOT NULL,
  "taxAmount"      DECIMAL(12,2) NOT NULL DEFAULT 0,
  "total"          DECIMAL(12,2) NOT NULL,
  "status"         "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
  "arcaData"       JSONB,
  "issuedAt"       TIMESTAMP(3),
  "dueAt"          TIMESTAMP(3),
  "cancelledAt"    TIMESTAMP(3),
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Invoice_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "Invoice_organizationId_invoiceType_series_number_key"
  ON "Invoice"("organizationId", "invoiceType", "series", "number");
CREATE INDEX IF NOT EXISTS "Invoice_organizationId_idx" ON "Invoice"("organizationId");
CREATE INDEX IF NOT EXISTS "Invoice_contactId_idx" ON "Invoice"("contactId");
CREATE INDEX IF NOT EXISTS "Invoice_organizationId_status_idx" ON "Invoice"("organizationId", "status");
CREATE INDEX IF NOT EXISTS "Invoice_organizationId_issuedAt_idx" ON "Invoice"("organizationId", "issuedAt");

ALTER TABLE "Invoice"
  ADD CONSTRAINT "Invoice_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "Invoice_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES "Contact"("id");

CREATE TABLE IF NOT EXISTS "InvoiceItem" (
  "id"              TEXT NOT NULL,
  "organizationId"  TEXT NOT NULL,
  "invoiceId"       TEXT NOT NULL,
  "productId"       TEXT,
  "description"     TEXT NOT NULL,
  "quantity"        DECIMAL(12,3) NOT NULL,
  "unitPrice"       DECIMAL(12,2) NOT NULL,
  "discountPercent" DECIMAL(5,2) NOT NULL DEFAULT 0,
  "taxPercent"      DECIMAL(5,2) NOT NULL DEFAULT 21,
  "subtotal"        DECIMAL(12,2) NOT NULL,
  "total"           DECIMAL(12,2) NOT NULL,
  "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "InvoiceItem_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "InvoiceItem_organizationId_idx" ON "InvoiceItem"("organizationId");
CREATE INDEX IF NOT EXISTS "InvoiceItem_invoiceId_idx" ON "InvoiceItem"("invoiceId");

ALTER TABLE "InvoiceItem"
  ADD CONSTRAINT "InvoiceItem_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "InvoiceItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "Invoice"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "InvoiceItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id");

-- ============================================================
-- VENTAS
-- ============================================================

CREATE TABLE IF NOT EXISTS "Sale" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "contactId"      TEXT,
  "invoiceId"      TEXT,
  "cashRegisterId" TEXT,
  "total"          DECIMAL(12,2) NOT NULL,
  "discountAmount" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "status"         "SaleStatus" NOT NULL DEFAULT 'COMPLETED',
  "notes"          TEXT,
  "soldAt"         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Sale_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Sale_organizationId_idx" ON "Sale"("organizationId");
CREATE INDEX IF NOT EXISTS "Sale_contactId_idx" ON "Sale"("contactId");
CREATE INDEX IF NOT EXISTS "Sale_invoiceId_idx" ON "Sale"("invoiceId");
CREATE INDEX IF NOT EXISTS "Sale_cashRegisterId_idx" ON "Sale"("cashRegisterId");
CREATE INDEX IF NOT EXISTS "Sale_organizationId_soldAt_idx" ON "Sale"("organizationId", "soldAt");

ALTER TABLE "Sale"
  ADD CONSTRAINT "Sale_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "Sale_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES "Contact"("id"),
  ADD CONSTRAINT "Sale_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "Invoice"("id");

CREATE TABLE IF NOT EXISTS "SaleItem" (
  "id"               TEXT NOT NULL,
  "organizationId"   TEXT NOT NULL,
  "saleId"           TEXT NOT NULL,
  "productId"        TEXT NOT NULL,
  "productVariantId" TEXT,
  "quantity"         DECIMAL(12,3) NOT NULL,
  "unitPrice"        DECIMAL(12,2) NOT NULL,
  "discountPercent"  DECIMAL(5,2) NOT NULL DEFAULT 0,
  "total"            DECIMAL(12,2) NOT NULL,
  "createdAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "SaleItem_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "SaleItem_organizationId_idx" ON "SaleItem"("organizationId");
CREATE INDEX IF NOT EXISTS "SaleItem_saleId_idx" ON "SaleItem"("saleId");
CREATE INDEX IF NOT EXISTS "SaleItem_productId_idx" ON "SaleItem"("productId");

ALTER TABLE "SaleItem"
  ADD CONSTRAINT "SaleItem_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "SaleItem_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES "Sale"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "SaleItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id"),
  ADD CONSTRAINT "SaleItem_productVariantId_fkey" FOREIGN KEY ("productVariantId") REFERENCES "ProductVariant"("id");

-- ============================================================
-- STOCK
-- ============================================================

CREATE TABLE IF NOT EXISTS "Warehouse" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "name"           TEXT NOT NULL,
  "description"    TEXT,
  "isDefault"      BOOLEAN NOT NULL DEFAULT false,
  "isActive"       BOOLEAN NOT NULL DEFAULT true,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Warehouse_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "Warehouse_organizationId_idx" ON "Warehouse"("organizationId");

ALTER TABLE "Warehouse"
  ADD CONSTRAINT "Warehouse_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS "StockMovement" (
  "id"               TEXT NOT NULL,
  "organizationId"   TEXT NOT NULL,
  "warehouseId"      TEXT NOT NULL,
  "productId"        TEXT NOT NULL,
  "productVariantId" TEXT,
  "type"             "MovementType" NOT NULL,
  "quantity"         DECIMAL(12,3) NOT NULL,
  "previousStock"    DECIMAL(12,3) NOT NULL,
  "newStock"         DECIMAL(12,3) NOT NULL,
  "referenceId"      TEXT,
  "referenceType"    TEXT,
  "notes"            TEXT,
  "movedAt"          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "StockMovement_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "StockMovement_organizationId_idx" ON "StockMovement"("organizationId");
CREATE INDEX IF NOT EXISTS "StockMovement_warehouseId_idx" ON "StockMovement"("warehouseId");
CREATE INDEX IF NOT EXISTS "StockMovement_productId_idx" ON "StockMovement"("productId");
CREATE INDEX IF NOT EXISTS "StockMovement_organizationId_movedAt_idx" ON "StockMovement"("organizationId", "movedAt");

ALTER TABLE "StockMovement"
  ADD CONSTRAINT "StockMovement_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "StockMovement_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES "Warehouse"("id"),
  ADD CONSTRAINT "StockMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id"),
  ADD CONSTRAINT "StockMovement_productVariantId_fkey" FOREIGN KEY ("productVariantId") REFERENCES "ProductVariant"("id");

-- ============================================================
-- TESORERÍA
-- ============================================================

CREATE TABLE IF NOT EXISTS "CashRegister" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "name"           TEXT NOT NULL,
  "openedAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "closedAt"       TIMESTAMP(3),
  "openingBalance" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "closingBalance" DECIMAL(12,2),
  "status"         "CashRegisterStatus" NOT NULL DEFAULT 'OPEN',
  "openedById"     TEXT NOT NULL,
  "closedById"     TEXT,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CashRegister_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "CashRegister_organizationId_idx" ON "CashRegister"("organizationId");
CREATE INDEX IF NOT EXISTS "CashRegister_organizationId_status_idx" ON "CashRegister"("organizationId", "status");

ALTER TABLE "CashRegister"
  ADD CONSTRAINT "CashRegister_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE;

-- FK de Sale a CashRegister (agregada aquí para evitar dependencia circular)
ALTER TABLE "Sale"
  ADD CONSTRAINT "Sale_cashRegisterId_fkey" FOREIGN KEY ("cashRegisterId") REFERENCES "CashRegister"("id");

CREATE TABLE IF NOT EXISTS "PaymentRecord" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "saleId"         TEXT NOT NULL,
  "cashRegisterId" TEXT,
  "method"         "PaymentMethod" NOT NULL,
  "amount"         DECIMAL(12,2) NOT NULL,
  "reference"      TEXT,
  "processedAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PaymentRecord_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PaymentRecord_organizationId_idx" ON "PaymentRecord"("organizationId");
CREATE INDEX IF NOT EXISTS "PaymentRecord_saleId_idx" ON "PaymentRecord"("saleId");
CREATE INDEX IF NOT EXISTS "PaymentRecord_cashRegisterId_idx" ON "PaymentRecord"("cashRegisterId");

ALTER TABLE "PaymentRecord"
  ADD CONSTRAINT "PaymentRecord_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "PaymentRecord_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES "Sale"("id") ON DELETE CASCADE,
  ADD CONSTRAINT "PaymentRecord_cashRegisterId_fkey" FOREIGN KEY ("cashRegisterId") REFERENCES "CashRegister"("id");
