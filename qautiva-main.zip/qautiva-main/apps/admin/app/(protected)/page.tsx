import type { Metadata } from 'next'
import { prisma, OrgStatus, StageStatus, Plan } from '@qautiva/db'
import type { AuditAction } from '@qautiva/db'
import { unstable_cache } from 'next/cache'
import Link from 'next/link'
import { relativeTime, deriveClientStatus } from '@/lib/org-utils'
import { MetricsRow, type MetricData } from '@/components/MetricsRow'
import { KanbanFilters } from '@/components/KanbanFilters'
import { KanbanColumn } from '@/components/KanbanColumn'
import type { ClientCardData } from '@/components/ClientCard'

export const metadata: Metadata = {
  title: 'Dashboard | Qautiva Admin',
  description: 'Visión general de clientes activos',
}

// ── Tipos ─────────────────────────────────────────────────────────────────────

type KanbanStage = ClientCardData['stage']
type ClientStatus = ClientCardData['status']
type ClientPlan = ClientCardData['plan']

interface OrgRow {
  id: string
  name: string
  industry: string
  plan: Plan
  status: OrgStatus
  updatedAt: Date | string
  stages: { status: StageStatus }[]
}

interface DashboardData {
  orgs: OrgRow[]
  reviewCount: number
  launchCount: number
  monthlyRevenue: number
  campaignStages: number
}

// ── Constantes ────────────────────────────────────────────────────────────────

const KANBAN_STAGES: KanbanStage[] = [
  'Descubrimiento',
  'Investigación',
  'Marca',
  'Web',
  'Campañas',
  'Medios',
  'Completado',
]

// Tipado exhaustivo: si se agrega un valor a OrgStatus, TypeScript exigirá
// que esté en este mapa.
const ORG_STATUS_TO_STAGE: Record<OrgStatus, KanbanStage | null> = {
  [OrgStatus.DISCOVERY]:  'Descubrimiento',
  [OrgStatus.RESEARCH]:   'Investigación',
  [OrgStatus.BRAND]:      'Marca',
  [OrgStatus.WEBSITE]:    'Web',
  [OrgStatus.CAMPAIGNS]:  'Campañas',
  [OrgStatus.MEDIA]:      'Medios',
  [OrgStatus.LAUNCHED]:   'Completado',
  [OrgStatus.PAUSED]:     null,
}

const PLAN_LABEL: Record<Plan, ClientPlan> = {
  [Plan.BASE]:     'Base',
  [Plan.COMPLETO]: 'Completo',
  [Plan.PREMIUM]:  'Premium',
}

// Valores válidos de searchParams; silencia filtros con valores desconocidos.
const VALID_PLANS    = new Set(['BASE', 'COMPLETO', 'PREMIUM'])
const VALID_STATUSES = new Set<ClientStatus>(['En proceso', 'Espera cliente', 'Espera revisión'])

// ── Helpers (funciones puras) ─────────────────────────────────────────────────

/** Formatea un Date como "DD/MM HH:MM" sin depender del locale del servidor. */
function fmtDateTime(date: Date): string {
  const d = new Date(date)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

// relativeTime y deriveClientStatus importados desde @/lib/org-utils

/** Mapea orgs de Prisma al formato de tarjeta Kanban. */
function mapOrgsToCards(orgs: OrgRow[]): ClientCardData[] {
  return orgs.flatMap((org) => {
    const stage = ORG_STATUS_TO_STAGE[org.status]
    if (!stage) return []
    return [{
      id: org.id,
      businessName: org.name,
      industry: org.industry,
      updatedLabel: relativeTime(org.updatedAt),
      status: deriveClientStatus(org.stages.map((s) => s.status)),
      plan: PLAN_LABEL[org.plan] ?? 'Base',
      stage,
    }]
  })
}

/** Construye las 5 métricas del dashboard a partir de los datos crudos. */
function buildMetrics(data: DashboardData): MetricData[] {
  return [
    { label: 'Clientes activos',      value: String(data.orgs.length) },
    { label: 'En cola de revisión',   value: String(data.reviewCount), highlight: data.reviewCount > 0 ? 'warning' : 'default' },
    { label: 'Lanzamientos este mes', value: String(data.launchCount) },
    {
      label: 'MRR activo',
      value: `$${data.monthlyRevenue.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
    },
    { label: 'Campañas gestionadas',  value: String(data.campaignStages) },
  ]
}

// ── Carga de datos (cacheada 30s) ─────────────────────────────────────────────

const fetchDashboardData = unstable_cache(
  async (): Promise<DashboardData> => {
    const t0 = Date.now()
    const startOfMonth = new Date()
    startOfMonth.setDate(1)
    startOfMonth.setHours(0, 0, 0, 0)

    const [orgs, reviewCount, launchCount, subscriptions, campaignStages] = await Promise.all([
      prisma.organization.findMany({
        where: { status: { not: 'PAUSED' } },
        select: {
          id: true,
          name: true,
          industry: true,
          plan: true,
          status: true,
          updatedAt: true,
          stages: { select: { status: true } },
        },
        orderBy: { updatedAt: 'desc' },
        take: 500,
      }),
      prisma.organization.count({
        where: { stages: { some: { status: 'ADMIN_REVIEW' } } },
      }),
      prisma.organization.count({
        where: { status: 'LAUNCHED', updatedAt: { gte: startOfMonth } },
      }),
      // Solo suscripciones de orgs no pausadas (consistencia con el Kanban)
      prisma.subscription.findMany({
        where: { status: 'ACTIVE', organization: { status: { not: 'PAUSED' } } },
        select: { planAmount: true },
      }),
      prisma.stage.count({
        where: { number: 5, status: { not: 'PENDING' } },
      }),
    ])

    const monthlyRevenue = subscriptions.reduce((sum, s) => sum + s.planAmount, 0)
    console.info(`[admin:dashboard] datos cargados en ${Date.now() - t0}ms — ${orgs.length} orgs`)

    return { orgs: orgs as OrgRow[], reviewCount, launchCount, monthlyRevenue, campaignStages }
  },
  ['admin-dashboard-data'],
  { revalidate: 30 },
)

// ── Filtrado ──────────────────────────────────────────────────────────────────

interface Filters {
  plan?: string
  industry?: string
  status?: string
  q?: string
}

function applyFilters(cards: ClientCardData[], filters: Filters): ClientCardData[] {
  const { plan, industry, status, q } = filters
  return cards.filter((card) => {
    if (plan && VALID_PLANS.has(plan) && card.plan !== PLAN_LABEL[plan as Plan]) return false
    if (industry && card.industry !== industry) return false
    if (status && VALID_STATUSES.has(status as ClientStatus) && card.status !== status) return false
    if (q && !card.businessName.toLowerCase().includes(q.toLowerCase())) return false
    return true
  })
}

// ── Checklist de setup inicial ────────────────────────────────────────────────

type SetupItem = {
  id: string
  label: string
  description: string
  done: boolean
  href?: string
  required: boolean // false = solo necesario para funcionalidades opcionales
}

type SetupStatus = {
  items: SetupItem[]
  allDone: boolean
}

// Datos de DB cacheados 60s — las configs cambian muy infrecuentemente.
// El check de process.env.ANTHROPIC_API_KEY se evalúa fuera del cache
// para no congelar un valor que solo cambia en deploy.
type SetupDbData = {
  agentsWithPrompt: number
  agentsWithInterviewPrompt: number
  stageWelcomeCount: number
  industryCount: number
  hasSerper: boolean
}

const fetchSetupDbStatus = unstable_cache(
  async (): Promise<SetupDbData> => {
    const [agentConfigs, stageWelcomeCount, industryCount, serperConfig] = await Promise.all([
      prisma.agentConfig.findMany({
        select: { agentNumber: true, prompt: true, interviewPrompt: true },
      }),
      prisma.stageWelcome.count(),
      prisma.industryTemplate.count(),
      prisma.integrationConfig.findFirst({
        where: { service: 'SERPER', isActive: true },
        select: { id: true },
      }),
    ])
    return {
      agentsWithPrompt: agentConfigs.filter((a) => a.prompt.trim().length > 0).length,
      agentsWithInterviewPrompt: agentConfigs.filter((a) => a.interviewPrompt).length,
      stageWelcomeCount,
      industryCount,
      hasSerper: !!serperConfig,
    }
  },
  ['admin-setup-db-status'],
  { revalidate: 60 },
)

async function fetchSetupStatus(): Promise<SetupStatus> {
  const db = await fetchSetupDbStatus()
  // Evaluado en cada render (fuera del cache) para reflejar cambios de deploy
  const anthropicOk = !!process.env.ANTHROPIC_API_KEY

  const items: SetupItem[] = [
    {
      id: 'anthropic-key',
      label: 'API Key Anthropic',
      description: anthropicOk
        ? 'Configurada en variables de entorno'
        : 'Falta ANTHROPIC_API_KEY en las variables de entorno del servidor',
      done: anthropicOk,
      required: true,
    },
    {
      id: 'agents-prompt',
      label: 'Prompts de agentes',
      description: `${db.agentsWithPrompt}/6 agentes con prompt configurado`,
      done: db.agentsWithPrompt >= 6,
      href: '/agentes',
      required: true,
    },
    {
      id: 'interview-prompts',
      label: 'Interview prompts',
      description: `${db.agentsWithInterviewPrompt}/6 agentes con prompt de entrevista`,
      done: db.agentsWithInterviewPrompt >= 6,
      href: '/agentes',
      required: true,
    },
    {
      id: 'stage-welcomes',
      label: 'Pantallas de bienvenida',
      description: `${db.stageWelcomeCount}/6 etapas configuradas`,
      done: db.stageWelcomeCount >= 6,
      href: '/bienvenidas',
      required: true,
    },
    {
      id: 'industry-templates',
      label: 'Templates de industria',
      description:
        db.industryCount > 0
          ? `${db.industryCount} template${db.industryCount !== 1 ? 's' : ''} cargado${db.industryCount !== 1 ? 's' : ''}`
          : 'Sin templates — el sistema no puede asignar industrias',
      done: db.industryCount > 0,
      href: '/industrias',
      required: true,
    },
    {
      id: 'serper-integration',
      label: 'Integración Serper',
      description: db.hasSerper
        ? 'Activa'
        : 'Sin configurar — necesaria para investigación web (Etapa 2)',
      done: db.hasSerper,
      href: '/configuracion',
      required: false,
    },
  ]

  return { items, allDone: items.every((i) => i.done) }
}

function SetupChecklistItem({ item }: { item: SetupItem }) {
  return (
    <div
      className={`flex items-start gap-2.5 px-3 py-2 rounded-lg ${
        item.done ? 'bg-[#10B981]/10' : 'bg-[#0B0F1A] border border-[#1E293B]'
      }`}
    >
      <span
        className={`text-sm leading-none mt-0.5 flex-shrink-0 ${
          item.done ? 'text-[#10B981]' : 'text-[#475569]'
        }`}
      >
        {item.done ? '✓' : '○'}
      </span>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`text-xs font-medium ${item.done ? 'text-[#10B981]' : 'text-[#94A3B8]'}`}>
            {item.label}
          </span>
          {item.href && !item.done && (
            <Link href={item.href} className="text-[10px] text-[#8B5CF6] hover:text-[#A78BFA] transition-colors">
              Configurar →
            </Link>
          )}
        </div>
        <p className="text-[10px] text-[#475569] mt-0.5 line-clamp-2">{item.description}</p>
      </div>
    </div>
  )
}

function SetupChecklist({ status }: { status: SetupStatus }) {
  if (status.allDone) return null

  const required = status.items.filter((i) => i.required)
  const optional = status.items.filter((i) => !i.required)
  const doneCount = status.items.filter((i) => i.done).length

  return (
    <section className="rounded-xl border border-[#F59E0B]/30 bg-[#F59E0B]/5 p-4 space-y-3">
      <div>
        <h2 className="text-sm font-semibold text-[#F59E0B]">Setup inicial</h2>
        <p className="text-xs text-[#94A3B8] mt-0.5">
          {doneCount}/{status.items.length} pasos completados — esta sección desaparece al finalizar
        </p>
      </div>

      <div>
        <p className="text-[10px] font-semibold text-[#64748B] uppercase tracking-wider mb-1.5">
          Obligatorios
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {required.map((item) => <SetupChecklistItem key={item.id} item={item} />)}
        </div>
      </div>

      {optional.length > 0 && (
        <div>
          <p className="text-[10px] font-semibold text-[#64748B] uppercase tracking-wider mb-1.5">
            Opcionales
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {optional.map((item) => <SetupChecklistItem key={item.id} item={item} />)}
          </div>
        </div>
      )}
    </section>
  )
}

// ── Actividad reciente (AuditLog) ─────────────────────────────────────────────

type AuditEntry = {
  id: string
  action: AuditAction
  targetEntity: string
  targetId: string
  createdAt: Date
}

const ACTION_LABEL: Record<AuditAction, string> = {
  SESSION_RESET:       'Sesión reseteada',
  SESSION_FORCE_STATE: 'Estado forzado',
  CONFIG_UPDATE:       'Configuración actualizada',
  INTEGRATION_UPDATE:  'Integración actualizada',
  TEMPLATE_UPDATE:     'Template actualizado',
  TEMPLATE_IMPORT:     'Template importado',
  DELIVERABLE_REGEN:   'Entregable regenerado',
}

const ACTION_COLOR: Record<AuditAction, string> = {
  SESSION_RESET:       'text-[#EF4444]',
  SESSION_FORCE_STATE: 'text-[#F59E0B]',
  CONFIG_UPDATE:       'text-[#8B5CF6]',
  INTEGRATION_UPDATE:  'text-[#06B6D4]',
  TEMPLATE_UPDATE:     'text-[#10B981]',
  TEMPLATE_IMPORT:     'text-[#10B981]',
  DELIVERABLE_REGEN:   'text-[#EF4444]',
}

// Mapas para presentar targets con nombres legibles en lugar de IDs técnicos
const AGENT_NAMES: Record<string, string> = {
  '1': 'El Estratega', '2': 'El Investigador', '3': 'Director Creativo',
  '4': 'El Arquitecto', '5': 'El Activador', '6': 'El Conector',
}
const STAGE_NAMES: Record<string, string> = {
  DISCOVERY: 'Descubrimiento', RESEARCH: 'Investigación', BRAND: 'Marca',
  WEBSITE: 'Web', CAMPAIGNS: 'Campañas', MEDIA: 'Medios',
}

function fmtTarget(entity: string, id: string): string {
  if (entity === 'AgentConfig') return `Agente · ${AGENT_NAMES[id] ?? `#${id}`}`
  if (entity === 'StageWelcome') return `Bienvenida · ${STAGE_NAMES[id] ?? id}`
  return `${entity} · ${id}`
}

const fetchRecentActivity = unstable_cache(
  async (): Promise<AuditEntry[]> =>
    prisma.auditLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: { id: true, action: true, targetEntity: true, targetId: true, createdAt: true },
    }),
  ['admin-recent-activity'],
  { revalidate: 30 },
)

function RecentActivity({ entries }: { entries: AuditEntry[] }) {
  if (entries.length === 0) {
    return (
      <section>
        <h2 className="text-sm font-semibold text-[#94A3B8] mb-2">Actividad reciente</h2>
        <p className="text-xs text-[#475569]">Sin actividad registrada.</p>
      </section>
    )
  }

  return (
    <section>
      <h2 className="text-sm font-semibold text-[#94A3B8] mb-2">Actividad reciente</h2>
      <div className="rounded-xl border border-[#1E293B] bg-[#0B0F1A] divide-y divide-[#1E293B]">
        {entries.map((e) => (
          <div key={e.id} className="flex items-center gap-3 px-4 py-2.5 text-xs">
            <span className={`font-medium min-w-[180px] ${ACTION_COLOR[e.action]}`}>
              {ACTION_LABEL[e.action]}
            </span>
            <span className="text-[#64748B] truncate">
              {fmtTarget(e.targetEntity, e.targetId)}
            </span>
            <span className="ml-auto text-[#475569] whitespace-nowrap">
              {fmtDateTime(e.createdAt)}
            </span>
          </div>
        ))}
      </div>
    </section>
  )
}

// ── Componentes de estado ─────────────────────────────────────────────────────

function DashboardError() {
  return (
    <div className="flex flex-col items-center justify-center flex-1 gap-3">
      <p className="text-[#EF4444] font-semibold">Error al cargar el dashboard</p>
      <p className="text-[#64748B] text-sm">No se pudo conectar con la base de datos.</p>
    </div>
  )
}

function EmptyFilters() {
  return (
    <div className="flex flex-col items-center justify-center flex-1 gap-3">
      <p className="text-[#94A3B8]">Sin clientes para los filtros seleccionados.</p>
      <Link
        href="/"
        className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
      >
        Limpiar filtros
      </Link>
    </div>
  )
}

// ── Página ────────────────────────────────────────────────────────────────────

interface PageProps {
  searchParams: { plan?: string; industry?: string; status?: string; q?: string }
}

export default async function DashboardPage({ searchParams }: PageProps) {
  let data: DashboardData
  try {
    data = await fetchDashboardData()
  } catch (err) {
    console.error('[admin:dashboard] error cargando datos:', err)
    return <DashboardError />
  }

  const [allCards, recentActivity, setupStatus] = await Promise.all([
    Promise.resolve(mapOrgsToCards(data.orgs)),
    fetchRecentActivity().catch((err: unknown) => {
      console.error('[admin:dashboard] error cargando actividad reciente:', err)
      return [] as AuditEntry[]
    }),
    fetchSetupStatus().catch((err: unknown) => {
      console.error('[admin:dashboard] error cargando setup status:', err)
      return { items: [], allDone: true } satisfies SetupStatus
    }),
  ])
  const filteredCards = applyFilters(allCards, searchParams)
  const industries = Array.from(new Set(data.orgs.map((o) => o.industry))).sort()
  const hasFilters = !!(searchParams.plan || searchParams.industry || searchParams.status || searchParams.q)

  return (
    <div className="flex flex-col h-full p-6 gap-5">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-[#94A3B8] text-sm mt-0.5">
          Visión general de todos los clientes activos.
        </p>
      </div>

      <MetricsRow metrics={buildMetrics(data)} />
      <SetupChecklist status={setupStatus} />
      <RecentActivity entries={recentActivity} />
      <KanbanFilters industries={industries} />

      {filteredCards.length === 0 && hasFilters ? (
        <EmptyFilters />
      ) : (
        <div className="flex gap-3 overflow-x-auto pb-4 flex-1">
          {KANBAN_STAGES.map((stage) => (
            <KanbanColumn
              key={stage}
              stage={stage}
              cards={filteredCards.filter((c) => c.stage === stage)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
