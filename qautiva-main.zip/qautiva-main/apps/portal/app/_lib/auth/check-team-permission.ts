import { prisma } from '@qautiva/db'
import type { TeamRole } from '@qautiva/db'

export interface TeamPermissionResult {
  authorized: boolean
  /** Rol del usuario en el team, o null si no es miembro. */
  role: TeamRole | null
}

/**
 * Verifica si el usuario autenticado tiene alguno de los roles requeridos en el team.
 *
 * @param authUserId - ID de Supabase auth (user.id de supabase.auth.getUser())
 * @param teamId - ID del team a verificar
 * @param requiredRoles - Roles que permiten el acceso (ej: ['ADMIN', 'OWNER'])
 * @returns { authorized, role } — authorized=false si no es miembro o el rol no está en requiredRoles
 */
export async function checkTeamPermission(
  authUserId: string,
  teamId: string,
  requiredRoles: TeamRole[],
): Promise<TeamPermissionResult> {
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId },
    select: {
      teamMemberships: {
        where: { teamId },
        select: { role: true },
      },
    },
  })

  if (!profile || profile.teamMemberships.length === 0) {
    return { authorized: false, role: null }
  }

  const role = profile.teamMemberships[0]!.role
  return {
    authorized: requiredRoles.includes(role),
    role,
  }
}
