import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// ── Mocks ──────────────────────────────────────────────────────────────────────

const mockGetProfileOrUnauthorized = vi.fn()
const mockSerializeOrder = vi.fn()
const mockIsValidHttpUrl = vi.fn()

const mockProductFindUnique = vi.fn()
const mockOrderFindFirst = vi.fn()
const mockOrderCreate = vi.fn()
const mockOrderFindMany = vi.fn()
const mockOrderCount = vi.fn()
const mockTransaction = vi.fn()

const mockFilterOrderByRole = vi.fn()

vi.mock('@/lib/api/marketplace-helpers', () => ({
  getProfileOrUnauthorized: mockGetProfileOrUnauthorized,
  serializeOrder: mockSerializeOrder,
  isValidHttpUrl: mockIsValidHttpUrl,
  filterOrderByRole: mockFilterOrderByRole,
  ORDER_RESPONSE_SELECT: {},
  ORDER_RESPONSE_SELECT_ADVERTISER: {},
  ORDER_RESPONSE_SELECT_EDITOR: {},
}))

vi.mock('@qautiva/db', () => {
  // Minimal Decimal que cubre las operaciones usadas en la ruta de órdenes
  function MockDecimal(v: string | number) {
    const n = typeof v === 'string' ? parseFloat(v) : Number(v)
    const self = {
      toNumber: () => n,
      greaterThan: (x: number | { toNumber(): number }) =>
        n > (typeof x === 'number' ? x : x.toNumber()),
      mul: (other: { toNumber(): number }) => MockDecimal(n * other.toNumber()),
      sub: (other: { toNumber(): number }) => MockDecimal(n - other.toNumber()),
      toDecimalPlaces: (dp: number) => {
        const factor = Math.pow(10, dp)
        return MockDecimal(Math.round(n * factor) / factor)
      },
      toFixed: (dp: number) => n.toFixed(dp),
      toString: () => String(n),
    }
    return self
  }

  return {
    prisma: {
      product: { findUnique: mockProductFindUnique },
      order: {
        findFirst: mockOrderFindFirst,
        create: mockOrderCreate,
        findMany: mockOrderFindMany,
        count: mockOrderCount,
      },
      $transaction: mockTransaction,
    },
    Prisma: { Decimal: MockDecimal },
    OrderStatus: {
      PENDING: 'PENDING',
      ACCEPTED: 'ACCEPTED',
      REJECTED: 'REJECTED',
      COMPLETED: 'COMPLETED',
      EXPIRED: 'EXPIRED',
      CANCELLED: 'CANCELLED',
    },
  }
})

// ── Helpers de test ────────────────────────────────────────────────────────────

/**
 * Simula un objeto Prisma.Decimal con las operaciones que usa la ruta.
 */
function makeDecimal(value: number) {
  return {
    toNumber: () => value,
    greaterThan: (v: number) => value > v,
    mul: (other: { toNumber: () => number }) => makeDecimal(value * other.toNumber()),
    sub: (other: { toNumber: () => number }) => makeDecimal(value - other.toNumber()),
    toDecimalPlaces: (dp: number) => {
      const factor = Math.pow(10, dp)
      return makeDecimal(Math.round(value * factor) / factor)
    },
  }
}

function makePostRequest(body: unknown): NextRequest {
  return new NextRequest('http://localhost:3000/api/marketplace/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

/** Producto activo con medio activo y precio $100 */
function makeActiveProduct(overrides?: Record<string, unknown>) {
  return {
    id: 'prod-1',
    mediumId: 'medium-1',
    price: makeDecimal(100),
    deliveryDays: 5,
    active: true,
    medium: {
      id: 'medium-1',
      userId: 'editor-profile-id',
      deletedAt: null,
      status: 'ACTIVE',
    },
    ...overrides,
  }
}

const ADVERTISER_PROFILE_ID = 'advertiser-profile-id'

function mockAuthOk() {
  mockGetProfileOrUnauthorized.mockResolvedValueOnce({
    profile: { id: ADVERTISER_PROFILE_ID },
    unauthorized: false,
  })
}

function mockAuthFail() {
  mockGetProfileOrUnauthorized.mockResolvedValueOnce({
    profile: null,
    unauthorized: true,
    response: new Response(JSON.stringify({ error: 'No autorizado' }), { status: 401 }),
  })
}

describe('POST /api/marketplace/orders', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetProfileOrUnauthorized.mockReset()
    mockProductFindUnique.mockReset()
    mockOrderFindFirst.mockReset()
    mockOrderCreate.mockReset()
    mockSerializeOrder.mockReset()
    mockIsValidHttpUrl.mockReset()
    mockTransaction.mockReset()
    // Por defecto, isValidHttpUrl aprueba todo
    mockIsValidHttpUrl.mockReturnValue(true)
    // serializeOrder retorna el objeto con campos numéricos
    mockSerializeOrder.mockImplementation((o: Record<string, unknown>) => ({
      ...o,
      price: (o.price as { toNumber: () => number })?.toNumber?.() ?? o.price,
      commission: (o.commission as { toNumber: () => number })?.toNumber?.() ?? o.commission,
      editorPayout: (o.editorPayout as { toNumber: () => number })?.toNumber?.() ?? o.editorPayout,
    }))
    // $transaction ejecuta el callback con un tx que apunta a los mismos mocks
    mockTransaction.mockImplementation(async (cb: (tx: unknown) => unknown) => {
      const tx = {
        order: { findFirst: mockOrderFindFirst, create: mockOrderCreate },
      }
      return cb(tx)
    })
  })

  // ── Auth ──────────────────────────────────────────────────────────────────────

  it('devuelve 401 si el usuario no está autenticado', async () => {
    mockAuthFail()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief de test' }))

    expect(res.status).toBe(401)
  })

  // ── Validación del body ───────────────────────────────────────────────────────

  it('devuelve 400 si el body no es JSON válido', async () => {
    mockAuthOk()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const req = new NextRequest('http://localhost:3000/api/marketplace/orders', {
      method: 'POST',
      body: 'not-json',
    })
    const res = await POST(req)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/inválido/i)
  })

  it('devuelve 400 si falta productId', async () => {
    mockAuthOk()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ brief: 'Brief con suficiente longitud' }))

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/productId/i)
  })

  it('devuelve 400 si el brief tiene menos de 10 caracteres', async () => {
    mockAuthOk()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Corto' }))

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/10/i)
  })

  it('devuelve 400 si el brief supera 5000 caracteres', async () => {
    mockAuthOk()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'x'.repeat(5001) }))

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/5000/i)
  })

  it('devuelve 400 si targetUrl no es una URL válida', async () => {
    mockAuthOk()
    mockIsValidHttpUrl.mockReturnValueOnce(false)

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(
      makePostRequest({ productId: 'p-1', brief: 'Brief válido con longitud', targetUrl: 'not-a-url' }),
    )

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/url/i)
  })

  it('devuelve 400 si anchorText supera 200 caracteres', async () => {
    mockAuthOk()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(
      makePostRequest({
        productId: 'p-1',
        brief: 'Brief válido con longitud',
        anchorText: 'x'.repeat(201),
      }),
    )

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/200/i)
  })

  // ── Validaciones de producto y medio ─────────────────────────────────────────

  it('devuelve 404 si el producto no existe', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(null)

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(404)
  })

  it('devuelve 404 si el medio del producto fue eliminado (soft delete)', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      ...makeActiveProduct(),
      medium: { id: 'm-1', userId: 'editor-id', deletedAt: new Date(), status: 'ACTIVE' },
    })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(404)
  })

  it('devuelve 409 si el producto no está activo', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({ ...makeActiveProduct(), active: false })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.error).toMatch(/disponible/i)
  })

  it('devuelve 409 si el medio no está activo', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      ...makeActiveProduct(),
      medium: { id: 'm-1', userId: 'editor-id', deletedAt: null, status: 'PAUSED' },
    })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.error).toMatch(/medio.*activo/i)
  })

  it('devuelve 409 si el precio del producto es 0', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      ...makeActiveProduct(),
      price: makeDecimal(0),
    })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.error).toMatch(/precio/i)
  })

  it('devuelve 409 si el editor intenta comprar su propio producto', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      ...makeActiveProduct(),
      medium: { id: 'm-1', userId: ADVERTISER_PROFILE_ID, deletedAt: null, status: 'ACTIVE' },
    })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.error).toMatch(/propio/i)
  })

  it('devuelve 409 si ya existe una orden PENDING del mismo usuario para el mismo producto', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(makeActiveProduct())
    mockOrderFindFirst.mockResolvedValueOnce({ id: 'existing-order-id' })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.orderId).toBe('existing-order-id')
  })

  // ── Cálculo de comisión ───────────────────────────────────────────────────────

  it('calcula correctamente comisión (10%) y pago al editor para precio $100', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(makeActiveProduct())
    mockOrderFindFirst.mockResolvedValueOnce(null)

    const createdOrder = {
      id: 'order-new',
      price: makeDecimal(100),
      commission: makeDecimal(10),
      editorPayout: makeDecimal(90),
    }
    mockOrderCreate.mockResolvedValueOnce(createdOrder)

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    const callData = mockOrderCreate.mock.calls[0]![0].data
    expect(callData.price.toNumber()).toBe(100)
    expect(callData.commission.toNumber()).toBe(10)
    expect(callData.editorPayout.toNumber()).toBe(90)
  })

  it('redondea comisión a 2 decimales para precio $33', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      ...makeActiveProduct(),
      price: makeDecimal(33),
    })
    mockOrderFindFirst.mockResolvedValueOnce(null)

    const createdOrder = {
      id: 'order-new',
      price: makeDecimal(33),
      commission: makeDecimal(3.3),
      editorPayout: makeDecimal(29.7),
    }
    mockOrderCreate.mockResolvedValueOnce(createdOrder)

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    await POST(makePostRequest({ productId: 'p-1', brief: 'Brief suficientemente largo' }))

    const callData = mockOrderCreate.mock.calls[0]![0].data
    // $33 * 10% = $3.30 → 2 decimales
    expect(callData.commission.toNumber()).toBe(3.3)
    // $33 - $3.30 = $29.70
    expect(callData.editorPayout.toNumber()).toBe(29.7)
  })

  // ── Happy path ────────────────────────────────────────────────────────────────

  it('crea la orden y devuelve 201 con la orden serializada', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(makeActiveProduct())
    mockOrderFindFirst.mockResolvedValueOnce(null)

    const createdOrder = {
      id: 'order-new',
      advertiserId: ADVERTISER_PROFILE_ID,
      mediumId: 'medium-1',
      productId: 'prod-1',
      brief: 'Brief suficientemente largo',
      status: 'PENDING',
      price: makeDecimal(100),
      commission: makeDecimal(10),
      editorPayout: makeDecimal(90),
    }
    mockOrderCreate.mockResolvedValueOnce(createdOrder)

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(
      makePostRequest({ productId: 'prod-1', brief: 'Brief suficientemente largo' }),
    )

    expect(res.status).toBe(201)
    expect(mockOrderCreate).toHaveBeenCalledOnce()

    // Verifica que el advertiser sea el usuario autenticado
    const callData = mockOrderCreate.mock.calls[0]![0].data
    expect(callData.advertiserId).toBe(ADVERTISER_PROFILE_ID)
  })

  it('guarda targetUrl y anchorText cuando se proveen', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(makeActiveProduct())
    mockOrderFindFirst.mockResolvedValueOnce(null)
    mockOrderCreate.mockResolvedValueOnce({
      id: 'o-1',
      price: makeDecimal(100),
      commission: makeDecimal(10),
      editorPayout: makeDecimal(90),
    })

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    await POST(
      makePostRequest({
        productId: 'prod-1',
        brief: 'Brief suficientemente largo',
        targetUrl: 'https://ejemplo.com',
        anchorText: 'Mi empresa',
      }),
    )

    const callData = mockOrderCreate.mock.calls[0]![0].data
    expect(callData.targetUrl).toBe('https://ejemplo.com')
    expect(callData.anchorText).toBe('Mi empresa')
  })

  it('establece expiresAt en 3 días desde ahora', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(makeActiveProduct())
    mockOrderFindFirst.mockResolvedValueOnce(null)
    mockOrderCreate.mockResolvedValueOnce({
      id: 'o-1',
      price: makeDecimal(100),
      commission: makeDecimal(10),
      editorPayout: makeDecimal(90),
    })

    const before = Date.now()

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    await POST(makePostRequest({ productId: 'prod-1', brief: 'Brief suficientemente largo' }))

    const after = Date.now()
    const callData = mockOrderCreate.mock.calls[0]![0].data
    const expiresAt: Date = callData.expiresAt

    const threeDaysMs = 3 * 24 * 60 * 60 * 1000
    expect(expiresAt.getTime()).toBeGreaterThanOrEqual(before + threeDaysMs)
    expect(expiresAt.getTime()).toBeLessThanOrEqual(after + threeDaysMs)
  })

  it('devuelve 500 si prisma.order.create lanza un error', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(makeActiveProduct())
    mockOrderFindFirst.mockResolvedValueOnce(null)
    mockOrderCreate.mockRejectedValueOnce(new Error('DB error'))

    const { POST } = await import('../../../app/api/marketplace/orders/route')
    const res = await POST(makePostRequest({ productId: 'prod-1', brief: 'Brief suficientemente largo' }))

    expect(res.status).toBe(500)
  })
})

// ── GET /api/marketplace/orders ───────────────────────────────────────────────

function makeGetRequest(params: Record<string, string> = {}): NextRequest {
  const url = new URL('http://localhost:3000/api/marketplace/orders')
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, v)
  }
  return new NextRequest(url.toString(), { method: 'GET' })
}

describe('GET /api/marketplace/orders', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetProfileOrUnauthorized.mockReset()
    mockOrderFindMany.mockReset()
    mockOrderCount.mockReset()
    mockSerializeOrder.mockReset()
    mockFilterOrderByRole.mockReset()
    // Por defecto serializeOrder devuelve el objeto tal cual
    mockSerializeOrder.mockImplementation((o: unknown) => o)
    // filterOrderByRole devuelve el objeto tal cual
    mockFilterOrderByRole.mockImplementation((o: unknown) => o)
  })

  // ── Auth ──────────────────────────────────────────────────────────────────────

  it('devuelve 401 si el usuario no está autenticado', async () => {
    mockAuthFail()

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest())

    expect(res.status).toBe(401)
  })

  // ── Validación de parámetros ──────────────────────────────────────────────────

  it('devuelve 400 si role no es "advertiser" ni "editor"', async () => {
    mockAuthOk()

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest({ role: 'admin' }))

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/advertiser.*editor/i)
  })

  it('devuelve 400 si status es un valor no válido del enum', async () => {
    mockAuthOk()

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest({ status: 'INVALID_STATUS' }))

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/estado/i)
  })

  // ── Aislamiento de datos por usuario ─────────────────────────────────────────

  it('filtra órdenes con el profileId del usuario autenticado (no devuelve órdenes de otros)', async () => {
    mockAuthOk()
    mockOrderFindMany.mockResolvedValueOnce([
      { id: 'order-1', advertiserId: ADVERTISER_PROFILE_ID },
    ])
    mockOrderCount.mockResolvedValueOnce(1)

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest())
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.orders).toHaveLength(1)
    // Verifica que el where incluye el profileId del usuario autenticado
    expect(mockOrderFindMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          OR: expect.arrayContaining([
            expect.objectContaining({ advertiserId: ADVERTISER_PROFILE_ID }),
          ]),
        }),
      }),
    )
  })

  it('filtra solo como advertiser cuando role=advertiser', async () => {
    mockAuthOk()
    mockOrderFindMany.mockResolvedValueOnce([{ id: 'order-2', advertiserId: ADVERTISER_PROFILE_ID }])
    mockOrderCount.mockResolvedValueOnce(1)

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest({ role: 'advertiser' }))

    expect(res.status).toBe(200)
    expect(mockOrderFindMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ advertiserId: ADVERTISER_PROFILE_ID }),
      }),
    )
  })

  it('devuelve paginación correcta', async () => {
    mockAuthOk()
    mockOrderFindMany.mockResolvedValueOnce([])
    mockOrderCount.mockResolvedValueOnce(0)

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest({ page: '2', take: '10' }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.pagination).toMatchObject({ page: 2, take: 10, total: 0 })
  })

  it('devuelve 500 si prisma.order.findMany lanza un error', async () => {
    mockAuthOk()
    mockOrderFindMany.mockRejectedValueOnce(new Error('DB error'))
    mockOrderCount.mockResolvedValueOnce(0)

    const { GET } = await import('../../../app/api/marketplace/orders/route')
    const res = await GET(makeGetRequest())

    expect(res.status).toBe(500)
  })
})
