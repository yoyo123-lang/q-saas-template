'use client'

import { useState, useEffect } from 'react'
import { updateTemplateSections } from '../../actions'
import { SECTION_LABELS } from '../../_constants'
import type { ActionState } from '../../actions'

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar secciones'}
    </button>
  )
}

interface TabSeccionesProps {
  templateId: string
  sections: Record<string, boolean>
}

export function TabSecciones({ templateId, sections: initialSections }: TabSeccionesProps) {
  const [sections, setSections] = useState<Record<string, boolean>>(initialSections)
  const [showSuccess, setShowSuccess] = useState(false)
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  useEffect(() => {
    if (state?.ok) {
      setShowSuccess(true)
      const t = setTimeout(() => setShowSuccess(false), 3000)
      return () => clearTimeout(t)
    }
  }, [state])

  function toggle(key: string) {
    if (key === 'hero') return // Hero es obligatorio
    setSections((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', templateId)
    formData.set('sections', JSON.stringify(sections))
    try {
      const result = await updateTemplateSections(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  const sectionKeys = Object.keys(SECTION_LABELS)

  return (
    <form action={handleSubmit} className="flex flex-col gap-4">
      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-5">
        <p className="text-[#64748B] text-xs mb-4">
          Seleccioná las secciones que incluye este template. Hero es obligatorio.
        </p>
        <div className="flex flex-col gap-3">
          {sectionKeys.map((key) => {
            const isHero = key === 'hero'
            const isEnabled = sections[key] ?? false
            return (
              <label
                key={key}
                className={`flex items-center gap-3 cursor-pointer ${isHero ? 'cursor-default' : ''}`}
              >
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={isEnabled}
                    onChange={() => toggle(key)}
                    disabled={isHero}
                    className="sr-only"
                  />
                  <div
                    className={`w-10 h-5 rounded-full transition-colors ${
                      isEnabled ? 'bg-[#8B5CF6]' : 'bg-[#1E293B]'
                    } ${isHero ? 'opacity-70' : ''}`}
                  >
                    <div
                      className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${
                        isEnabled ? 'translate-x-5' : 'translate-x-0.5'
                      }`}
                    />
                  </div>
                </div>
                <span className="text-sm text-[#94A3B8]">
                  {SECTION_LABELS[key]}
                  {isHero && (
                    <span className="ml-2 text-xs text-[#8B5CF6]">(siempre activo)</span>
                  )}
                </span>
              </label>
            )
          })}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <SaveButton pending={isPending} />
        {showSuccess && <p className="text-sm text-green-400">Guardado correctamente.</p>}
        {state && !state.ok && <p className="text-sm text-red-400">{state.error}</p>}
      </div>
    </form>
  )
}
