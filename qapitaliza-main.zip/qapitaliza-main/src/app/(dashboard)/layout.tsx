import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getPrisma } from '@/lib/prisma'
import { Sidebar } from '@/components/layout/sidebar'
import { DashboardShell } from '@/components/layout/dashboard-shell'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  // Fetch profile for sidebar
  let sidebarUser = {
    name: user.email ?? 'Usuario',
    email: user.email ?? '',
    role: 'BUYER',
    avatarInitials: 'U',
  }

  let unreadInquiries = 0

  try {
    const prisma = getPrisma()
    const [profile, inquiriesCount] = await Promise.all([
      prisma.profile.findUnique({
        where: { id: user.id },
        select: { fullName: true, email: true, role: true },
      }),
      prisma.inquiry.count({
        where: {
          listing: { sellerId: user.id },
          status: 'OPEN',
        },
      }),
    ])

    if (profile) {
      const name = profile.fullName ?? profile.email ?? user.email ?? 'Usuario'
      const initials = name
        .split(' ')
        .slice(0, 2)
        .map((n: string) => n[0]?.toUpperCase() ?? '')
        .join('')

      sidebarUser = {
        name,
        email: profile.email,
        role: profile.role,
        avatarInitials: initials || 'U',
      }
    }
    unreadInquiries = inquiriesCount
  } catch {
    // Non-blocking: sidebar still renders without profile data
  }

  return (
    <DashboardShell
      sidebar={<Sidebar variant="dashboard" user={sidebarUser} unreadInquiries={unreadInquiries} />}
    >
      {children}
    </DashboardShell>
  )
}
