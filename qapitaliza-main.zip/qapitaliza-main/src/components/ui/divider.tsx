import { cn } from '@/lib/utils/cn'

interface DividerProps {
  label?: string
  className?: string
}

export function Divider({ label, className }: DividerProps) {
  if (!label) {
    return <hr className={cn('border-slate-800', className)} />
  }

  return (
    <div className={cn('flex items-center gap-3', className)}>
      <hr className="flex-1 border-slate-800" />
      <span className="text-xs text-slate-500 whitespace-nowrap">{label}</span>
      <hr className="flex-1 border-slate-800" />
    </div>
  )
}
