import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// ── Mocks ──────────────────────────────────────────────────────────────────────

const mockGetUser = vi.fn()
const mockUserProfileFindUnique = vi.fn()
const mockInterviewSessionFindFirst = vi.fn()
const mockInterviewSessionUpdate = vi.fn()

vi.mock('@supabase/ssr', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: { findUnique: mockUserProfileFindUnique },
    interviewSession: {
      findFirst: mockInterviewSessionFindFirst,
      update: mockInterviewSessionUpdate,
    },
  },
  Prisma: {
    PrismaClientKnownRequestError: class PrismaClientKnownRequestError extends Error {
      code: string
      constructor(message: string, { code }: { code: string }) {
        super(message)
        this.code = code
      }
    },
  },
}))

vi.mock('@/app/_lib/interview/merge-flow', () => ({
  isAnswerEmpty: (v: unknown) => {
    if (v === null || v === undefined) return true
    if (typeof v === 'string') return v.trim().length === 0
    if (Array.isArray(v)) return v.length === 0
    return false
  },
}))

// ── Constantes y helpers ───────────────────────────────────────────────────────

// UUID v4 válido
const SESSION_UUID = '00000000-0000-4000-a000-000000000001'
const USER_ID = 'user-auth-id'
const PROFILE_ID = 'profile-1'
const TEAM_ID = 'team-1'

function makeRequest(
  body: unknown,
  sessionId = SESSION_UUID,
): [NextRequest, { params: { id: string } }] {
  const req = new NextRequest(
    `http://localhost:3001/api/interview/sessions/${sessionId}/answer`,
    {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
  )
  return [req, { params: { id: sessionId } }]
}

function mockAuthOk() {
  mockGetUser.mockResolvedValueOnce({ data: { user: { id: USER_ID } } })
}

function mockAuthFail() {
  mockGetUser.mockResolvedValueOnce({ data: { user: null } })
}

function mockProfileOk() {
  // Primera llamada: ownership check en answer/route.ts (necesita teamId)
  mockUserProfileFindUnique.mockResolvedValueOnce({
    id: PROFILE_ID,
    teamMemberships: [{ teamId: TEAM_ID }],
  })
  // Segunda llamada: checkTeamPermission (necesita role)
  mockUserProfileFindUnique.mockResolvedValueOnce({
    teamMemberships: [{ role: 'ADMIN' }],
  })
}

/** Sesión activa en estado IN_PROGRESS con versión 0 y sin respuestas previas */
function makeActiveSession(overrides?: Record<string, unknown>) {
  return {
    id: SESSION_UUID,
    teamId: TEAM_ID,
    answers: {},
    answersVersion: 0,
    answerHistory: [],
    flowDefinition: [],
    status: 'IN_PROGRESS',
    startedAt: new Date(),
    ...overrides,
  }
}

describe('PATCH /api/interview/sessions/[id]/answer', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockInterviewSessionFindFirst.mockReset()
    mockInterviewSessionUpdate.mockReset()
  })

  // ── Auth ──────────────────────────────────────────────────────────────────────

  it('devuelve 401 si no hay usuario autenticado', async () => {
    mockAuthFail()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(401)
    const data = await res.json()
    expect(data.error).toMatch(/no autorizado/i)
  })

  // ── Validación de sessionId ────────────────────────────────────────────────────

  it('devuelve 404 si el sessionId no es un UUID v4 válido', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest(
      { questionId: 'q1', answer: 'respuesta', answersVersion: 0 },
      'not-a-valid-uuid',
    )
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(404)
    const data = await res.json()
    expect(data.error).toMatch(/no encontrada/i)
  })

  it('devuelve 404 si el sessionId es un UUID v1 (no v4)', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    // UUID v1: el tercer grupo empieza con 1
    const [req, ctx] = makeRequest(
      { questionId: 'q1', answer: 'respuesta', answersVersion: 0 },
      '00000000-0000-1000-a000-000000000001',
    )
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(404)
  })

  // ── Validación del body ───────────────────────────────────────────────────────

  it('devuelve 400 si el body no es JSON válido', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const req = new NextRequest(
      `http://localhost:3001/api/interview/sessions/${SESSION_UUID}/answer`,
      { method: 'PATCH', body: 'not-json' },
    )
    const res = await PATCH(req, { params: { id: SESSION_UUID } })

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/inválido/i)
  })

  it('devuelve 400 si answer es una cadena vacía', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: '', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/vacío/i)
  })

  it('devuelve 400 si answer es null', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: null, answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/vacío/i)
  })

  it('devuelve 400 si answer es un array vacío', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: [], answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
  })

  it('devuelve 400 si falta questionId', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/questionId/i)
  })

  it('devuelve 400 si answersVersion no es un entero no negativo', async () => {
    mockAuthOk()

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: -1 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/answersVersion/i)
  })

  // ── Verificación de ownership / estado de sesión ──────────────────────────────

  it('devuelve 404 si la sesión no existe (o no pertenece al usuario)', async () => {
    mockAuthOk()
    mockProfileOk()
    mockInterviewSessionFindFirst.mockResolvedValueOnce(null)

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(404)
    const data = await res.json()
    expect(data.error).toMatch(/no encontrada/i)
  })

  it('devuelve 409 si la sesión está en estado COMPLETED', async () => {
    mockAuthOk()
    mockProfileOk()
    mockInterviewSessionFindFirst.mockResolvedValueOnce(
      makeActiveSession({ status: 'COMPLETED' }),
    )

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.error).toMatch(/estado/i)
  })

  it('devuelve 409 si la sesión está en estado CANCELLED', async () => {
    mockAuthOk()
    mockProfileOk()
    mockInterviewSessionFindFirst.mockResolvedValueOnce(
      makeActiveSession({ status: 'CANCELLED' }),
    )

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(409)
  })

  it('devuelve 403 si el usuario no tiene team membership', async () => {
    mockAuthOk()
    mockUserProfileFindUnique.mockResolvedValueOnce({
      id: PROFILE_ID,
      teamMemberships: [],
    })

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(403)
  })

  // ── Happy path ────────────────────────────────────────────────────────────────

  it('guarda la respuesta y retorna 200 con la sesión actualizada', async () => {
    mockAuthOk()
    mockProfileOk()
    mockInterviewSessionFindFirst.mockResolvedValueOnce(makeActiveSession())
    const updatedSession = {
      id: SESSION_UUID,
      answers: { q1: 'respuesta' },
      answersVersion: 1,
      currentStep: 1,
      status: 'IN_PROGRESS',
      startedAt: new Date(),
    }
    mockInterviewSessionUpdate.mockResolvedValueOnce(updatedSession)

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    const res = await PATCH(req, ctx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(data.session.id).toBe(SESSION_UUID)
  })

  it('auto-transiciona a IN_PROGRESS si la sesión estaba en NOT_STARTED', async () => {
    mockAuthOk()
    mockProfileOk()
    mockInterviewSessionFindFirst.mockResolvedValueOnce(
      makeActiveSession({ status: 'NOT_STARTED', startedAt: null }),
    )
    mockInterviewSessionUpdate.mockResolvedValueOnce({
      id: SESSION_UUID,
      answers: { q1: 'respuesta' },
      answersVersion: 1,
      currentStep: 0,
      status: 'IN_PROGRESS',
      startedAt: new Date(),
    })

    const { PATCH } = await import('../../../app/api/interview/sessions/[id]/answer/route')
    const [req, ctx] = makeRequest({ questionId: 'q1', answer: 'respuesta', answersVersion: 0 })
    await PATCH(req, ctx)

    expect(mockInterviewSessionUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'IN_PROGRESS' }),
      }),
    )
  })
})
