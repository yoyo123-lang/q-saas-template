import Link from 'next/link'

type ClientStatus = 'En proceso' | 'Espera cliente' | 'Espera revisión'
type ClientPlan = 'Base' | 'Completo' | 'Premium'
type KanbanStage =
  | 'Descubrimiento'
  | 'Investigación'
  | 'Marca'
  | 'Web'
  | 'Campañas'
  | 'Medios'
  | 'Completado'

export interface ClientCardData {
  id: string
  businessName: string
  industry: string
  updatedLabel: string
  status: ClientStatus
  plan: ClientPlan
  stage: KanbanStage
}

interface IndustryBadge {
  label: string
  className: string
}

const KNOWN_INDUSTRY_BADGES: Record<string, IndustryBadge> = {
  Belleza:      { label: 'Belleza',      className: 'bg-[#EC4899]/15 text-[#F472B6] border border-[#EC4899]/30' },
  Gastronomía:  { label: 'Gastronomía',  className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  Contable:     { label: 'Contable',     className: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30' },
  Retail:       { label: 'Retail',       className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  Servicios:    { label: 'Servicios',    className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  Tecnología:   { label: 'Tecnología',   className: 'bg-[#06B6D4]/15 text-[#22D3EE] border border-[#06B6D4]/30' },
  Salud:        { label: 'Salud',        className: 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30' },
  Educación:    { label: 'Educación',    className: 'bg-[#84CC16]/15 text-[#A3E635] border border-[#84CC16]/30' },
}

const FALLBACK_BADGE: IndustryBadge = {
  label: '',
  className: 'bg-[#1E293B] text-[#94A3B8] border border-[#334155]',
}

const STATUS_BADGE: Record<ClientStatus, { label: string; className: string; pulse?: boolean }> = {
  'En proceso':      { label: 'En proceso',      className: 'bg-[#1E293B] text-[#94A3B8]' },
  'Espera cliente':  { label: 'Espera cliente',  className: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30' },
  'Espera revisión': { label: 'Espera revisión', className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30', pulse: true },
}

const PLAN_BADGE: Record<ClientPlan, string> = {
  Base:     'bg-[#1E293B] text-[#64748B]',
  Completo: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30',
  Premium:  'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30',
}

export function ClientCard({ data }: { data: ClientCardData }) {
  const industryBadge = KNOWN_INDUSTRY_BADGES[data.industry] ?? {
    ...FALLBACK_BADGE,
    label: data.industry,
  }
  const statusBadge = STATUS_BADGE[data.status]
  const planBadgeClass = PLAN_BADGE[data.plan]

  const isCompleted = data.stage === 'Completado'
  const isWaitingReview = data.status === 'Espera revisión'

  const cardBorderClass = isCompleted
    ? 'border-l-4 border-l-[#10B981] border border-[#1E293B]'
    : isWaitingReview
      ? 'border border-[#F59E0B]/50 animate-pulse'
      : 'border border-[#1E293B]'

  return (
    <Link href={`/clientes/${data.id}`}>
      <div
        className={`
          bg-[#0F172A] rounded-lg p-3 cursor-pointer hover:border-[#334155] transition-colors
          ${cardBorderClass}
        `}
      >
        {/* Nombre del negocio */}
        <p className="text-white font-semibold text-sm leading-tight mb-2">
          {data.businessName}
        </p>

        {/* Rubro */}
        <span
          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-medium mb-2 ${industryBadge.className}`}
        >
          {industryBadge.label}
        </span>

        {/* Tiempo */}
        <p className="text-[#64748B] text-xs mb-3">{data.updatedLabel}</p>

        {/* Badges de estado y plan */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span
            className={`
              inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium
              ${statusBadge.className}
            `}
          >
            {statusBadge.pulse && (
              <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] animate-pulse" aria-hidden="true" />
            )}
            {statusBadge.label}
          </span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${planBadgeClass}`}>
            {data.plan}
          </span>
        </div>
      </div>
    </Link>
  )
}
