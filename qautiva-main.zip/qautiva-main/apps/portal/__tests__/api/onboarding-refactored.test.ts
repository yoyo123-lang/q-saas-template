import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockGetUser = vi.fn()
const mockAdminUpdateUserById = vi.fn()
const mockUserProfileFindUnique = vi.fn()
const mockBillingAccountUpdate = vi.fn()
const mockTrialConfigFindUnique = vi.fn()
const mockApiKeyCreate = vi.fn()
const mockUserProfileUpdate = vi.fn()
const mockTransaction = vi.fn()

vi.mock('@supabase/ssr', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('@/lib/encryption', () => ({
  encrypt: vi.fn().mockReturnValue('encrypted-key'),
  keyHint: vi.fn().mockReturnValue('****1234'),
}))

vi.mock('@/app/_lib/validate-api-key', () => ({
  validateApiKey: vi.fn().mockResolvedValue(true),
}))

const mockBilling = { id: 'billing-1', teamId: 'team-1' }
const mockTeam = { id: 'team-1', billing: mockBilling }
const mockMembership = { team: mockTeam }
const mockProfile = { id: 'profile-1', teamMemberships: [mockMembership] }

vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: { findUnique: mockUserProfileFindUnique },
    $transaction: mockTransaction,
  },
  createServiceClient: vi.fn().mockReturnValue({
    auth: {
      admin: { updateUserById: mockAdminUpdateUserById },
    },
  }),
  Prisma: {},
}))

function makeRequest(body: unknown) {
  return new Request('http://localhost:3001/api/onboarding', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

describe('POST /api/onboarding (refactored — solo step 2)', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockBillingAccountUpdate.mockReset()
    mockTrialConfigFindUnique.mockReset()
    mockApiKeyCreate.mockReset()
    mockUserProfileUpdate.mockReset()
    mockAdminUpdateUserById.mockReset()
    mockTransaction.mockReset()

    mockAdminUpdateUserById.mockResolvedValue({})

    // Por defecto la transacción ejecuta el callback
    mockTransaction.mockImplementation(async (cb: (tx: unknown) => unknown) => {
      const tx = {
        billingAccount: { update: mockBillingAccountUpdate },
        trialConfig: { findUnique: mockTrialConfigFindUnique },
        apiKey: { create: mockApiKeyCreate },
        userProfile: { update: mockUserProfileUpdate },
      }
      return cb(tx)
    })

    mockTrialConfigFindUnique.mockResolvedValue({
      id: 1,
      maxDurationDays: 14,
      tokenAmount: 50000,
    })
    mockBillingAccountUpdate.mockResolvedValue({})
    mockApiKeyCreate.mockResolvedValue({})
    mockUserProfileUpdate.mockResolvedValue({})
  })

  it('devuelve 401 si no hay usuario autenticado', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: null } })
    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 2, mode: 'trial' }))
    expect(res.status).toBe(401)
  })

  it('devuelve 400 si el step es inválido', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1', app_metadata: {} } } })
    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 99 }))
    expect(res.status).toBe(400)
  })

  it('devuelve 400 si falta mode', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1' } } })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)
    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 2 }))
    expect(res.status).toBe(400)
  })

  it('trial: actualiza BillingAccount con FREE_TRIAL y llama onboarding_complete', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1' } } })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)

    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 2, mode: 'trial' }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(mockBillingAccountUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ plan: 'FREE_TRIAL' }),
      }),
    )
    expect(mockAdminUpdateUserById).toHaveBeenCalledWith('u-1', {
      app_metadata: { onboarding_complete: true },
    })
  })

  it('hosted: actualiza BillingAccount con PREPAID y llama onboarding_complete', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1' } } })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)

    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 2, mode: 'hosted' }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(mockBillingAccountUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ plan: 'PREPAID', preferredKeySource: 'QAUTIVA_HOSTED' }),
      }),
    )
  })

  it('byok sin apiKey: retorna 400, no actualiza BillingAccount', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1' } } })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)

    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 2, mode: 'byok', provider: 'ANTHROPIC' }))

    expect(res.status).toBe(400)
    expect(mockBillingAccountUpdate).not.toHaveBeenCalled()
    expect(mockAdminUpdateUserById).not.toHaveBeenCalled()
  })

  it('byok con clave válida: crea ApiKey encriptada y llama onboarding_complete', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1' } } })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)

    const { POST } = await import('../../app/api/onboarding/route')
    const res = await POST(makeRequest({ step: 2, mode: 'byok', provider: 'ANTHROPIC', apiKey: 'sk-ant-real-key' }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(mockApiKeyCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          provider: 'ANTHROPIC',
          encryptedKey: 'encrypted-key',
        }),
      }),
    )
    expect(mockAdminUpdateUserById).toHaveBeenCalledWith('u-1', {
      app_metadata: { onboarding_complete: true },
    })
  })

  it('no crea Project ni Organization en ningún modo', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: { id: 'u-1' } } })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)

    const { POST } = await import('../../app/api/onboarding/route')
    await POST(makeRequest({ step: 2, mode: 'trial' }))

    // La transacción no debe crear proyectos ni organizaciones
    const txCalls = mockTransaction.mock.calls
    expect(txCalls.length).toBe(1)
    // Verificar que el tx no tiene project.create ni organization.create
    const txArg = mockTransaction.mock.calls[0]![0]
    const mockTx = {
      billingAccount: { update: vi.fn().mockResolvedValue({}) },
      trialConfig: { findUnique: vi.fn().mockResolvedValue({ maxDurationDays: 14, tokenAmount: 50000 }) },
      userProfile: { update: vi.fn().mockResolvedValue({}) },
      project: { create: vi.fn() },
      organization: { create: vi.fn() },
    }
    await txArg(mockTx)
    expect(mockTx.project.create).not.toHaveBeenCalled()
    expect(mockTx.organization.create).not.toHaveBeenCalled()
  })
})
