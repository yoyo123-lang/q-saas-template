'use server'

import { revalidatePath } from 'next/cache'
import { prisma, Prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

// ── Types ──────────────────────────────────────────────────────────────────────

export type ActionState = { ok: true } | { ok: false; error: string }
export type CreateActionState = { ok: true; id: string } | { ok: false; error: string }

type InputType =
  | 'text'
  | 'textarea'
  | 'multiple_choice'
  | 'multi_select'
  | 'rating'
  | 'url_input'
  | 'file_upload'
  | 'color_picker'
  | 'budget_range'
  | 'date'

type Option = { value: string; label: string }
type Validation = {
  required?: boolean
  minLength?: number
  maxLength?: number
  min?: number
  max?: number
  pattern?: string
}

type QuestionBlock = {
  id: string
  question: string
  helpText?: string
  context?: string
  inputType: InputType
  options?: Option[]
  placeholder?: string
  defaultValue?: string
  validation?: Validation
  skippable?: boolean
}

type ColorPalette = { name: string; colors: string[] }

type CampaignBase = {
  presupuestoMin: number
  presupuestoMax: number
  presupuestoTipico: number
  plataformas: string[]
  keywords: string[]
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function parseJsonField<T>(raw: FormDataEntryValue | null, fieldName: string): T {
  if (typeof raw !== 'string' || !raw.trim()) {
    throw new Error(`${fieldName} es requerido`)
  }
  try {
    return JSON.parse(raw) as T
  } catch {
    throw new Error(`${fieldName} tiene formato JSON inválido`)
  }
}

function parsePositiveNumber(value: FormDataEntryValue | null, fieldName: string): number {
  const raw = typeof value === 'string' ? parseFloat(value) : NaN
  if (isNaN(raw) || raw < 0) {
    throw new Error(`${fieldName} debe ser un número positivo`)
  }
  return raw
}

function validateName(value: FormDataEntryValue | null): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error('El nombre es requerido')
  }
  if (value.trim().length > 200) {
    throw new Error('El nombre no puede superar los 200 caracteres')
  }
  return value.trim()
}

// ── createIndustry ─────────────────────────────────────────────────────────────

/**
 * Crea una IndustryTemplate nueva con questions/keywords/colorPalettes vacíos.
 */
export async function createIndustry(
  prevState: CreateActionState | null,
  formData: FormData,
): Promise<CreateActionState> {
  await requireAdminSession()

  try {
    const name = validateName(formData.get('name'))

    const existing = await prisma.industryTemplate.findUnique({
      where: { name },
      select: { id: true },
    })
    if (existing) {
      return { ok: false, error: `Ya existe una industria con el nombre "${name}"` }
    }

    const industry = await prisma.industryTemplate.create({
      data: {
        name,
        questions: {},
        keywords: [],
        colorPalettes: [],
      },
      select: { id: true },
    })

    console.info(`[admin:industrias] industria creada — id=${industry.id} name=${name}`)
    revalidatePath('/industrias')
    return { ok: true, id: industry.id }
  } catch (err) {
    console.error('[admin:industrias] error en createIndustry:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }
}

// ── updateIndustryInfo ─────────────────────────────────────────────────────────

/**
 * Actualiza name y webTemplate de una IndustryTemplate.
 */
export async function updateIndustryInfo(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const name = validateName(formData.get('name'))
    const webTemplateRaw = formData.get('webTemplate')
    const webTemplate =
      typeof webTemplateRaw === 'string' && webTemplateRaw.trim()
        ? webTemplateRaw.trim()
        : null

    const existing = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'Industria no encontrada' }
    }

    await prisma.industryTemplate.update({
      where: { id: id.trim() },
      data: { name, webTemplate },
    })

    console.info(`[admin:industrias] info actualizada — id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en updateIndustryInfo:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}

// ── updateQuestions ────────────────────────────────────────────────────────────

/**
 * Actualiza el JSON de questions de una IndustryTemplate.
 */
export async function updateQuestions(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const questions = parseJsonField<Record<string, QuestionBlock[]>>(
      formData.get('questions'),
      'questions',
    )

    const existing = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'Industria no encontrada' }
    }

    await prisma.industryTemplate.update({
      where: { id: id.trim() },
      data: { questions },
    })

    console.info(`[admin:industrias] questions actualizadas — id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en updateQuestions:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}

// ── updateKeywords ─────────────────────────────────────────────────────────────

/**
 * Actualiza el array de keywords de una IndustryTemplate.
 */
export async function updateKeywords(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const keywords = parseJsonField<string[]>(formData.get('keywords'), 'keywords')
    if (!Array.isArray(keywords)) {
      return { ok: false, error: 'keywords debe ser un array' }
    }

    const existing = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'Industria no encontrada' }
    }

    await prisma.industryTemplate.update({
      where: { id: id.trim() },
      data: { keywords },
    })

    console.info(`[admin:industrias] keywords actualizadas — id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en updateKeywords:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}

// ── updateColorPalettes ────────────────────────────────────────────────────────

/**
 * Actualiza el array de paletas de color de una IndustryTemplate.
 */
export async function updateColorPalettes(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const colorPalettes = parseJsonField<ColorPalette[]>(
      formData.get('colorPalettes'),
      'colorPalettes',
    )
    if (!Array.isArray(colorPalettes)) {
      return { ok: false, error: 'colorPalettes debe ser un array' }
    }

    const existing = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'Industria no encontrada' }
    }

    await prisma.industryTemplate.update({
      where: { id: id.trim() },
      data: { colorPalettes },
    })

    console.info(`[admin:industrias] colorPalettes actualizadas — id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en updateColorPalettes:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}

// ── updateCampaignBase ─────────────────────────────────────────────────────────

/**
 * Actualiza la campaña base de una IndustryTemplate desde campos individuales del form.
 */
export async function updateCampaignBase(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const presupuestoMin = parsePositiveNumber(formData.get('presupuestoMin'), 'presupuestoMin')
    const presupuestoMax = parsePositiveNumber(formData.get('presupuestoMax'), 'presupuestoMax')
    const presupuestoTipico = parsePositiveNumber(
      formData.get('presupuestoTipico'),
      'presupuestoTipico',
    )

    if (presupuestoMin > presupuestoMax) {
      return { ok: false, error: 'presupuestoMin no puede ser mayor a presupuestoMax' }
    }

    const plataformas = formData.getAll('plataformas').filter(
      (v): v is string => typeof v === 'string',
    )

    const keywordsRaw = formData.get('keywordsCampana')
    const keywords =
      typeof keywordsRaw === 'string' && keywordsRaw.trim()
        ? keywordsRaw
            .split('\n')
            .map((k) => k.trim())
            .filter(Boolean)
        : []

    const existing = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'Industria no encontrada' }
    }

    const campaignBase: CampaignBase = {
      presupuestoMin,
      presupuestoMax,
      presupuestoTipico,
      plataformas,
      keywords,
    }

    await prisma.industryTemplate.update({
      where: { id: id.trim() },
      data: { campaignBase },
    })

    console.info(`[admin:industrias] campaignBase actualizado — id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en updateCampaignBase:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}

// ── deleteIndustry ─────────────────────────────────────────────────────────────

/**
 * Elimina una IndustryTemplate. Solo si clientCount === 0.
 */
export async function deleteIndustry(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const existing = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true, name: true, clientCount: true },
    })
    if (!existing) {
      return { ok: false, error: 'Industria no encontrada' }
    }
    if (existing.clientCount > 0) {
      return {
        ok: false,
        error: `No se puede eliminar "${existing.name}" porque tiene ${existing.clientCount} cliente(s) asociado(s)`,
      }
    }

    await prisma.industryTemplate.delete({ where: { id: id.trim() } })

    console.info(`[admin:industrias] industria eliminada — id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en deleteIndustry:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}

// ── duplicateIndustry ──────────────────────────────────────────────────────────

/**
 * Clona una IndustryTemplate con name = "{original} (copia)".
 */
export async function duplicateIndustry(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }

    const original = await prisma.industryTemplate.findUnique({
      where: { id: id.trim() },
    })
    if (!original) {
      return { ok: false, error: 'Industria no encontrada' }
    }

    const newName = `${original.name} (copia)`
    const nameExists = await prisma.industryTemplate.findUnique({
      where: { name: newName },
      select: { id: true },
    })
    if (nameExists) {
      return { ok: false, error: `Ya existe una industria con el nombre "${newName}"` }
    }

    await prisma.industryTemplate.create({
      data: {
        name: newName,
        questions: original.questions as Prisma.InputJsonValue,
        keywords: original.keywords as Prisma.InputJsonValue,
        colorPalettes: original.colorPalettes as Prisma.InputJsonValue,
        webTemplate: original.webTemplate,
        campaignBase: original.campaignBase != null
          ? (original.campaignBase as Prisma.InputJsonValue)
          : undefined,
      },
    })

    console.info(`[admin:industrias] industria duplicada desde id=${id}`)
  } catch (err) {
    console.error('[admin:industrias] error en duplicateIndustry:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/industrias')
  return { ok: true }
}
