'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { MarketStudy } from '@/app/_lib/interview/types'

/** Ensures value is always an array — handles null, undefined, AND wrong types from AI output */
function safeArray<T>(value: T[] | null | undefined): T[] {
  return Array.isArray(value) ? value : []
}

type Props = {
  deliverableId: string
  projectId: string
  title: string
  study: MarketStudy | null
  canApprove: boolean
}

/** Valida que una URL use protocolo http/https (bloquea javascript:, data:, etc.) */
function isSafeUrl(url: string | null): url is string {
  if (!url) return false
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'http:' || parsed.protocol === 'https:'
  } catch {
    return false
  }
}

/** Extrae el hostname de una URL para mostrar como texto visible */
function displayUrl(url: string): string {
  try {
    return new URL(url).hostname
  } catch {
    return url
  }
}

const nivelCompetenciaLabels: Record<string, string> = {
  baja: 'Baja',
  media: 'Media',
  alta: 'Alta',
  saturada: 'Saturada',
}

const nivelCompetenciaColors: Record<string, string> = {
  baja: 'bg-[#10B981]/15 text-[#10B981]',
  media: 'bg-[#F59E0B]/15 text-[#F59E0B]',
  alta: 'bg-[#EF4444]/15 text-[#EF4444]',
  saturada: 'bg-[#EF4444]/20 text-[#EF4444]',
}

const impactoColors: Record<string, string> = {
  positivo: 'bg-[#10B981]/15 text-[#10B981]',
  negativo: 'bg-[#EF4444]/15 text-[#EF4444]',
  neutro: 'bg-[#64748B]/15 text-[#94A3B8]',
}

const prioridadColors: Record<string, string> = {
  alta: 'bg-[#8B5CF6]/15 text-[#A78BFA]',
  media: 'bg-[#F59E0B]/15 text-[#F59E0B]',
  baja: 'bg-[#64748B]/15 text-[#94A3B8]',
}

const severidadColors: Record<string, string> = {
  alta: 'bg-[#EF4444]/15 text-[#EF4444]',
  media: 'bg-[#F59E0B]/15 text-[#F59E0B]',
  baja: 'bg-[#64748B]/15 text-[#94A3B8]',
}

/**
 * Renderiza el Estudio de Mercado (tipo MARKET_STUDY) en la vista del cliente.
 * Permite aprobar o pedir cambios, igual que BriefDeliverable.
 */
export function MarketStudyDeliverable({ deliverableId, projectId, title, study: studyRaw, canApprove }: Props) {
  const study = (studyRaw ?? {}) as MarketStudy
  const router = useRouter()
  const [feedback, setFeedback] = useState('')
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  async function handleAction(action: 'approve' | 'reject') {
    if (action === 'reject' && feedback.trim().length === 0) {
      setError('Escribí tu feedback antes de pedir cambios.')
      return
    }
    setError(null)

    startTransition(async () => {
      const res = await fetch(`/api/deliverables/${deliverableId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, feedback: feedback.trim() }),
      })

      if (!res.ok) {
        const data = await res.json() as { error?: string }
        setError(data.error ?? 'Ocurrió un error. Intentalo de nuevo.')
        return
      }

      router.push(`/proyectos/${projectId}/progreso`)
    })
  }

  return (
    <div className="p-8 max-w-3xl space-y-6">
      <h1 className="text-2xl font-bold text-white">{title}</h1>
      <p className="text-[#475569] text-xs">
        Los ratings ★, URLs y datos de Maps provienen de búsquedas reales de Google (Serper). El análisis, interpretaciones y recomendaciones son generados por IA.
      </p>

      {/* Resumen ejecutivo — destacado */}
      <div className="bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 rounded-xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <p className="text-[#8B5CF6] text-xs font-medium uppercase tracking-wide">
            Panorama competitivo
          </p>
          <span
            className={`px-2.5 py-1 rounded-full text-xs font-medium ${
              nivelCompetenciaColors[study.resumenEjecutivo?.nivelCompetencia ?? ''] ?? 'bg-[#64748B]/15 text-[#94A3B8]'
            }`}
          >
            Competencia {nivelCompetenciaLabels[study.resumenEjecutivo?.nivelCompetencia ?? ''] ?? study.resumenEjecutivo?.nivelCompetencia ?? ''}
          </span>
        </div>
        <p className="text-white text-base leading-relaxed mb-3">
          {study.resumenEjecutivo?.panorama ?? ''}
        </p>
        <div className="border-t border-[#8B5CF6]/20 pt-3">
          <p className="text-[#8B5CF6] text-xs font-medium uppercase tracking-wide mb-1">
            Oportunidad principal
          </p>
          <p className="text-[#A78BFA] text-sm leading-relaxed">
            {study.resumenEjecutivo?.oportunidadPrincipal ?? ''}
          </p>
        </div>
      </div>

      {/* Competidores */}
      {(study.competidores?.length ?? 0) > 0 && (
        <StudySection title="Competidores">
          <div className="space-y-4">
            {safeArray(study.competidores).map((c, i) => (
              <div key={i} className="bg-[#0B0F1A] rounded-lg p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <p className="text-white text-sm font-medium">{c.nombre}</p>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {c.googleRating !== null && (
                      <span className="text-[#F59E0B] text-xs">★ {c.googleRating}/5</span>
                    )}
                    {c.googleReviews !== null && (
                      <span className="text-[#64748B] text-xs">({c.googleReviews} reseñas)</span>
                    )}
                  </div>
                </div>
                {isSafeUrl(c.website) && (
                  <a
                    href={c.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#8B5CF6] text-xs hover:underline block mb-2 truncate"
                  >
                    {displayUrl(c.website)}
                  </a>
                )}
                <p className="text-[#94A3B8] text-xs mb-2">{c.posicionamiento}</p>
                {(c.fortalezasDigitales?.length ?? 0) > 0 && (
                  <ul className="space-y-0.5 mb-1">
                    {safeArray(c.fortalezasDigitales).map((f, j) => (
                      <li key={j} className="text-[#10B981] text-xs flex items-start gap-1.5">
                        <span className="flex-shrink-0 mt-0.5">✓</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                )}
                {(c.debilidadesDigitales?.length ?? 0) > 0 && (
                  <ul className="space-y-0.5">
                    {safeArray(c.debilidadesDigitales).map((d, j) => (
                      <li key={j} className="text-[#EF4444] text-xs flex items-start gap-1.5">
                        <span className="flex-shrink-0 mt-0.5">✗</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </StudySection>
      )}

      {/* Presencia digital — solo si hay contenido */}
      {study.presenciaDigital && (
        study.presenciaDigital.resultadosBusqueda ||
        (study.presenciaDigital.keywordsCompetidores?.length ?? 0) > 0 ||
        (study.presenciaDigital.keywordsOportunidad?.length ?? 0) > 0 ||
        study.presenciaDigital.googleMapsPropio
      ) && (
      <StudySection title="Presencia digital">
        <div className="space-y-3">
          {study.presenciaDigital?.resultadosBusqueda && (
            <div>
              <p className="text-[#64748B] text-xs mb-0.5">Resultados de búsqueda</p>
              <p className="text-[#94A3B8] text-sm leading-relaxed">
                {study.presenciaDigital.resultadosBusqueda}
              </p>
            </div>
          )}
          {(study.presenciaDigital?.keywordsCompetidores?.length ?? 0) > 0 && (
            <StudyList label="Keywords de competidores" items={safeArray(study.presenciaDigital?.keywordsCompetidores)} />
          )}
          {(study.presenciaDigital?.keywordsOportunidad?.length ?? 0) > 0 && (
            <StudyList
              label="Keywords con oportunidad"
              items={safeArray(study.presenciaDigital?.keywordsOportunidad)}
              variant="positive"
            />
          )}
          {study.presenciaDigital?.googleMapsPropio && (
            <div>
              <p className="text-[#64748B] text-xs mb-1">Google Maps propio</p>
              <div className="bg-[#0B0F1A] rounded-lg p-3">
                <div className="flex items-center gap-3 mb-1">
                  <span
                    className={`text-xs font-medium ${
                      study.presenciaDigital.googleMapsPropio.encontrado
                        ? 'text-[#10B981]'
                        : 'text-[#EF4444]'
                    }`}
                  >
                    {study.presenciaDigital.googleMapsPropio.encontrado ? 'Encontrado en Maps' : 'No encontrado en Maps'}
                  </span>
                  {study.presenciaDigital.googleMapsPropio.rating !== null && (
                    <span className="text-[#F59E0B] text-xs">
                      ★ {study.presenciaDigital.googleMapsPropio.rating}/5
                      {study.presenciaDigital.googleMapsPropio.reviews !== null &&
                        ` (${study.presenciaDigital.googleMapsPropio.reviews} reseñas)`}
                    </span>
                  )}
                </div>
                {study.presenciaDigital.googleMapsPropio.sugerenciaMejora && (
                  <p className="text-[#94A3B8] text-xs leading-relaxed">
                    {study.presenciaDigital.googleMapsPropio.sugerenciaMejora}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </StudySection>
      )}

      {/* Tendencias */}
      {(study.tendencias?.length ?? 0) > 0 && (
        <StudySection title="Tendencias del sector">
          <div className="space-y-3">
            {safeArray(study.tendencias).map((t, i) => (
              <div key={i} className="flex items-start gap-3">
                <span
                  className={`flex-shrink-0 px-2 py-0.5 rounded-full text-xs font-medium ${
                    impactoColors[t.impacto] ?? 'bg-[#64748B]/15 text-[#94A3B8]'
                  }`}
                >
                  Impacto {t.impacto}
                </span>
                <div>
                  <p className="text-white text-sm">{t.tendencia}</p>
                  <p className="text-[#64748B] text-xs mt-0.5">{t.accion}</p>
                </div>
              </div>
            ))}
          </div>
        </StudySection>
      )}

      {/* Oportunidades */}
      {(study.oportunidades?.length ?? 0) > 0 && (
        <StudySection title="Oportunidades">
          <div className="space-y-3">
            {safeArray(study.oportunidades).map((o, i) => (
              <div key={i} className="bg-[#0B0F1A] rounded-lg p-3">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <p className="text-white text-sm">{o.descripcion}</p>
                  <span
                    className={`flex-shrink-0 px-2 py-0.5 rounded-full text-xs font-medium ${
                      prioridadColors[o.prioridad] ?? 'bg-[#64748B]/15 text-[#94A3B8]'
                    }`}
                  >
                    Prioridad {o.prioridad}
                  </span>
                </div>
                <p className="text-[#10B981] text-xs mb-1">→ {o.accionRecomendada}</p>
                <p className="text-[#64748B] text-xs">{o.evidencia}</p>
              </div>
            ))}
          </div>
        </StudySection>
      )}

      {/* Amenazas */}
      {(study.amenazas?.length ?? 0) > 0 && (
        <StudySection title="Amenazas">
          <div className="space-y-3">
            {safeArray(study.amenazas).map((a, i) => (
              <div key={i} className="flex items-start gap-3">
                <span
                  className={`flex-shrink-0 px-2 py-0.5 rounded-full text-xs font-medium ${
                    severidadColors[a.severidad] ?? 'bg-[#64748B]/15 text-[#94A3B8]'
                  }`}
                >
                  Severidad {a.severidad}
                </span>
                <div>
                  <p className="text-white text-sm">{a.descripcion}</p>
                  <p className="text-[#64748B] text-xs mt-0.5">{a.mitigacion}</p>
                </div>
              </div>
            ))}
          </div>
        </StudySection>
      )}

      {/* Recomendaciones */}
      {study.recomendaciones && (
        <StudySection title="Recomendaciones">
          <div className="space-y-3">
            {(study.recomendaciones?.inmediatas?.length ?? 0) > 0 && (
              <StudyList label="Acciones inmediatas (próximas 2 semanas)" items={study.recomendaciones.inmediatas} variant="positive" />
            )}
            {(study.recomendaciones?.medianoPlazo?.length ?? 0) > 0 && (
              <StudyList label="Mediano plazo (1-3 meses)" items={study.recomendaciones.medianoPlazo} />
            )}
            {(study.recomendaciones?.metricasClave?.length ?? 0) > 0 && (
              <StudyList label="Métricas a trackear" items={study.recomendaciones.metricasClave} />
            )}
          </div>
        </StudySection>
      )}

      {/* Acciones */}
      {canApprove && (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 space-y-4">
          <p className="text-white text-sm font-medium">¿Estás de acuerdo con este análisis?</p>
          <textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="Si querés pedir cambios, escribí tu feedback aquí..."
            rows={3}
            maxLength={2000}
            className="w-full bg-[#0B0F1A] border border-[#1E293B] rounded-lg px-3 py-2.5 text-[#94A3B8] text-sm placeholder:text-[#475569] focus:outline-none focus:border-[#8B5CF6]/50 resize-none"
          />
          {error && <p className="text-[#EF4444] text-sm">{error}</p>}
          <div className="flex gap-3">
            <button
              type="button"
              disabled={isPending}
              onClick={() => handleAction('approve')}
              className="px-5 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Aprobar estudio
            </button>
            <button
              type="button"
              disabled={isPending}
              onClick={() => handleAction('reject')}
              className="px-5 py-2 bg-[#1E293B] text-[#94A3B8] text-sm font-medium rounded-lg hover:bg-[#334155] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Pedir cambios
            </button>
          </div>
        </div>
      )}

      {!canApprove && (
        <div className="bg-[#10B981]/10 border border-[#10B981]/30 rounded-xl px-5 py-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-[#10B981] text-sm font-medium">Estudio aprobado</p>
            <p className="text-[#94A3B8] text-xs mt-1">Ya aprobaste este análisis. Avanzamos a la siguiente etapa.</p>
          </div>
          <button
            type="button"
            onClick={() => router.push(`/proyectos/${projectId}/progreso`)}
            className="flex-shrink-0 px-4 py-2 bg-[#10B981]/20 text-[#10B981] text-xs font-medium rounded-lg hover:bg-[#10B981]/30 transition-colors"
          >
            Ver progreso →
          </button>
        </div>
      )}
    </div>
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function StudySection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <h4 className="text-white text-sm font-semibold mb-4">{title}</h4>
      <div className="space-y-3">{children}</div>
    </div>
  )
}

function StudyList({
  label,
  items,
  variant = 'neutral',
}: {
  label: string
  items: string[]
  variant?: 'neutral' | 'positive' | 'negative'
}) {
  const safeItems = safeArray(items)
  if (safeItems.length === 0) return null
  const dotColor =
    variant === 'positive' ? 'bg-[#10B981]' : variant === 'negative' ? 'bg-[#EF4444]' : 'bg-[#8B5CF6]'
  return (
    <div>
      <p className="text-[#64748B] text-xs mb-1.5">{label}</p>
      <ul className="space-y-1">
        {safeItems.map((item, i) => (
          <li key={i} className="flex items-start gap-2">
            <span
              className={`flex-shrink-0 mt-1.5 w-1 h-1 rounded-full ${dotColor}`}
              aria-hidden="true"
            />
            <span className="text-[#94A3B8] text-sm leading-relaxed">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
