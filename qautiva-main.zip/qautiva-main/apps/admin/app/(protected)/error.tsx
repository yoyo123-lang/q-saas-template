'use client'

// Error boundary de Next.js para la sección protegida del admin.
// Se activa si un Server Component lanza una excepción no capturada.

import { useEffect } from 'react'

interface ErrorBoundaryProps {
  error: Error & { digest?: string }
  reset: () => void
}

export default function DashboardErrorBoundary({ error, reset }: ErrorBoundaryProps) {
  useEffect(() => {
    console.error('[admin:error-boundary]', error)
  }, [error])

  return (
    <div className="flex flex-col items-center justify-center h-full gap-4">
      <div className="text-center">
        <p className="text-[#EF4444] font-semibold text-lg mb-1">
          No se pudo cargar el dashboard
        </p>
        <p className="text-[#64748B] text-sm">
          Ocurrió un error inesperado. Intentá recargar la página.
        </p>
        {error.digest && (
          <p className="text-[#475569] text-xs mt-2 font-mono">
            Ref: {error.digest}
          </p>
        )}
      </div>
      <button
        onClick={reset}
        className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
      >
        Reintentar
      </button>
    </div>
  )
}
