'use client'

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'

interface PerformanceDataPoint {
  month: string
  aprobados: number
  rechazados: number
}

interface AgentPerformanceChartProps {
  data: PerformanceDataPoint[]
}

/**
 * Gráfico de barras (Recharts) con aprobaciones vs rechazos por mes del agente.
 */
export function AgentPerformanceChart({ data }: AgentPerformanceChartProps) {
  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-40 text-[#64748B] text-sm">
        Sin datos de rendimiento registrados aún.
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 4, right: 0, left: -20, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
        <XAxis
          dataKey="month"
          tick={{ fill: '#64748B', fontSize: 12 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fill: '#64748B', fontSize: 12 }}
          axisLine={false}
          tickLine={false}
          allowDecimals={false}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: '#0F172A',
            border: '1px solid #1E293B',
            borderRadius: '8px',
            color: '#F8FAFC',
            fontSize: 13,
          }}
          cursor={{ fill: '#1E293B' }}
        />
        <Legend
          wrapperStyle={{ fontSize: 12, color: '#94A3B8', paddingTop: 8 }}
        />
        <Bar dataKey="aprobados" name="Aprobados" fill="#10B981" radius={[4, 4, 0, 0]} maxBarSize={32} />
        <Bar dataKey="rechazados" name="Rechazados" fill="#EF4444" radius={[4, 4, 0, 0]} maxBarSize={32} />
      </BarChart>
    </ResponsiveContainer>
  )
}
