import type { Metadata } from 'next'
import { prisma } from '@qautiva/db'

export const metadata: Metadata = { title: 'Saldo OpenSRS | Qautiva Admin' }
export const dynamic = 'force-dynamic'

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000

// ── Data ─────────────────────────────────────────────────────────────────────

async function getBalanceLogs() {
  const since = new Date(Date.now() - THIRTY_DAYS_MS)
  return prisma.openSrsBalanceLog.findMany({
    where: { checkedAt: { gte: since } },
    orderBy: { checkedAt: 'desc' },
    select: {
      id: true,
      balance: true,
      holdBalance: true,
      checkedAt: true,
    },
  })
}

// ── Page ─────────────────────────────────────────────────────────────────────

export default async function BalancePage() {
  const threshold = parseFloat(process.env.OPENSRS_LOW_BALANCE_THRESHOLD ?? '50')
  const rawLogs = await getBalanceLogs()

  const logs = rawLogs.map((l) => ({
    ...l,
    balance: Number(l.balance),
    holdBalance: Number(l.holdBalance),
  }))

  const latest = logs[0] ?? null
  const isLow = latest !== null && latest.balance < threshold

  return (
    <div className="flex flex-col p-6 gap-6">
      {/* Header */}
      <div>
        <h1 className="text-white text-xl font-bold">Saldo OpenSRS</h1>
        <p className="text-[#64748B] text-sm mt-0.5">Últimos 30 días</p>
      </div>

      {/* Empty state */}
      {logs.length === 0 && (
        <div className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-8 text-center">
          <p className="text-[#64748B] text-sm">Sin datos de saldo.</p>
          <p className="text-[#64748B] text-xs mt-1">
            Los registros aparecen una vez que el job de sincronización corra.
          </p>
        </div>
      )}

      {/* Latest balance card */}
      {latest && (
        <div
          className={`bg-[#0F172A] rounded-lg border p-5 ${
            isLow ? 'border-[#EF4444]/50' : 'border-[#1E293B]'
          }`}
        >
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-[#F8FAFC] text-sm font-semibold">Saldo actual</h2>
            {isLow && (
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-[#EF4444]/15 text-[#F87171]">
                Saldo bajo
              </span>
            )}
          </div>
          <div className="flex gap-8">
            <div>
              <p className="text-[#64748B] text-xs mb-1">Disponible</p>
              <p className="text-[#F8FAFC] text-2xl font-bold">
                ${latest.balance.toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                <span className="text-[#64748B] text-sm font-normal ml-1">USD</span>
              </p>
            </div>
            <div>
              <p className="text-[#64748B] text-xs mb-1">En retención</p>
              <p className="text-[#94A3B8] text-2xl font-bold">
                ${latest.holdBalance.toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                <span className="text-[#64748B] text-sm font-normal ml-1">USD</span>
              </p>
            </div>
          </div>
          <p className="text-[#64748B] text-xs mt-3">
            Actualizado el{' '}
            {latest.checkedAt.toLocaleDateString('es-AR')}{' '}
            a las{' '}
            {latest.checkedAt.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}
          </p>
          {isLow && (
            <p className="text-[#F87171] text-xs mt-2">
              El saldo está por debajo del umbral de alerta (${threshold.toLocaleString('es-AR')} USD).
            </p>
          )}
        </div>
      )}

      {/* History table */}
      {logs.length > 0 && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-5">
          <h2 className="text-[#F8FAFC] text-sm font-semibold mb-4">
            Historial ({logs.length} registros)
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[#64748B] border-b border-[#1E293B]">
                  <th className="pb-2 pr-6 font-medium">Fecha y hora</th>
                  <th className="pb-2 pr-6 font-medium">Saldo USD</th>
                  <th className="pb-2 font-medium">Retención USD</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log) => (
                  <tr key={log.id} className="border-b border-[#1E293B] last:border-0">
                    <td className="py-2.5 pr-6 text-[#94A3B8] text-xs">
                      {log.checkedAt.toLocaleDateString('es-AR')}{' '}
                      {log.checkedAt.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-2.5 pr-6 text-[#F8FAFC]">
                      ${log.balance.toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 text-[#94A3B8]">
                      ${log.holdBalance.toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  )
}
