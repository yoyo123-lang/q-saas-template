'use client'

import { useState } from 'react'
import LoadingSpinner from '@/app/onboarding/_components/LoadingSpinner'
import { INDUSTRIES } from '@/app/onboarding/_constants/industries'

type FormState = 'idle' | 'loading' | 'error'

export default function NegocioClient() {
  const [nombre, setNombre] = useState('')
  const [industria, setIndustria] = useState('')
  const [descripcion, setDescripcion] = useState('')
  const [ciudad, setCiudad] = useState('')
  const [state, setState] = useState<FormState>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!nombre.trim()) {
      setState('error')
      setErrorMessage('El nombre del negocio es obligatorio.')
      return
    }
    if (!industria) {
      setState('error')
      setErrorMessage('Seleccioná el rubro de tu negocio.')
      return
    }

    setState('loading')
    setErrorMessage('')

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          step: 1,
          name: nombre.trim(),
          industry: industria,
          description: descripcion.trim() || undefined,
          city: ciudad.trim() || undefined,
        }),
      })

      if (!res.ok) {
        const data = await res.json().catch((err: unknown) => { console.error('[NegocioClient] Failed to parse error response', err); return {} })
        setState('error')
        setErrorMessage(data.error ?? 'Error al guardar. Intentá de nuevo.')
        return
      }

      const { projectId } = await res.json()
      window.location.href = `/proyectos/nuevo/servicios?pid=${projectId}`
    } catch {
      setState('error')
      setErrorMessage('Error de red. Verificá tu conexión e intentá de nuevo.')
    }
  }

  const isLoading = state === 'loading'

  return (
    <div className="w-full max-w-md">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Tu negocio</h1>
        <p className="text-[#94A3B8] text-sm">Contanos sobre tu empresa para personalizar el contenido.</p>
      </div>

      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
        {state === 'error' && errorMessage && (
          <div className="mb-4 p-3 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="space-y-4">
            <div>
              <label htmlFor="nombre" className="block text-sm text-[#94A3B8] mb-1.5">
                Nombre del negocio <span className="text-[#EF4444]">*</span>
              </label>
              <input
                id="nombre"
                type="text"
                value={nombre}
                onChange={(e) => { setNombre(e.target.value); if (state === 'error') setState('idle') }}
                placeholder="Ej: Peluquería Verde"
                className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200"
                disabled={isLoading}
                maxLength={100}
              />
            </div>

            <div>
              <label htmlFor="industria" className="block text-sm text-[#94A3B8] mb-1.5">
                Rubro / industria <span className="text-[#EF4444]">*</span>
              </label>
              <select
                id="industria"
                value={industria}
                onChange={(e) => { setIndustria(e.target.value); if (state === 'error') setState('idle') }}
                className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200 disabled:opacity-50"
                disabled={isLoading}
              >
                <option value="" disabled>Seleccioná tu rubro</option>
                {INDUSTRIES.map((ind) => (
                  <option key={ind} value={ind}>{ind}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="descripcion" className="block text-sm text-[#94A3B8] mb-1.5">
                Descripción corta <span className="text-[#64748B] text-xs">(opcional)</span>
              </label>
              <textarea
                id="descripcion"
                value={descripcion}
                onChange={(e) => { setDescripcion(e.target.value); if (state === 'error') setState('idle') }}
                placeholder="¿Qué hace tu negocio? ¿A quién ayuda? (2-3 oraciones)"
                rows={3}
                className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200 resize-none"
                disabled={isLoading}
                maxLength={500}
              />
            </div>

            <div>
              <label htmlFor="ciudad" className="block text-sm text-[#94A3B8] mb-1.5">
                Ciudad / país <span className="text-[#64748B] text-xs">(opcional)</span>
              </label>
              <input
                id="ciudad"
                type="text"
                value={ciudad}
                onChange={(e) => { setCiudad(e.target.value); if (state === 'error') setState('idle') }}
                placeholder="Ej: Buenos Aires, Argentina"
                className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200"
                disabled={isLoading}
                maxLength={100}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <LoadingSpinner />
                  Guardando...
                </>
              ) : 'Continuar →'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
