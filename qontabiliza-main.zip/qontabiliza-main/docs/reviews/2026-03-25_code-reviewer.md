# Code Review — Tech Lead
**Fecha:** 2026-03-25
**Archivos revisados:**
- `src/lib/tenant.ts`
- `tests/unit/tenant.test.ts`
- `prisma/schema.prisma`
- `prisma/seed.ts`
- `supabase/migrations/20260325000000_add_domain_models.sql`

---

## Hallazgos

### CRÍTICO

#### CR-01 — `Organization` en `TENANT_SCOPED_MODELS` pero no tiene campo `organizationId`
**Archivo:** `src/lib/tenant.ts:8`
**Descripción:** `TENANT_SCOPED_MODELS` incluye `"organization"`, pero el modelo `Organization` en el schema NO tiene campo `organizationId`. Cuando se llame `withTenant("org_123").organization.findMany()`, el helper inyectará `WHERE organizationId = 'org_123'` sobre un campo que no existe → error de runtime garantizado.
**Fix sugerido:** Remover `"organization"` de `TENANT_SCOPED_MODELS`. Para acceder a la propia organización, usar `prisma.organization.findUnique({ where: { id: organizationId } })` directamente.

---

### ALTO

#### CR-02 — `withTenant` no intercepta operaciones de escritura ni `findUnique`
**Archivo:** `src/lib/tenant.ts:53-89`
**Descripción:** `withTenant` intercepta `findMany`, `findFirst`, `findFirstOrThrow`, `updateMany`, `deleteMany`. No intercepta: `create`, `createMany`, `update`, `delete`, `upsert`, `findUnique`, `findUniqueOrThrow`, `count`, `aggregate`, `groupBy`. Esto significa:
- `create` sin `organizationId` en `data` crea registros sin tenant → datos huérfanos.
- `findUnique` / `findUniqueOrThrow` no filtran por tenant → IDOR (ver Security).
- `update` / `delete` por ID no verifican que el registro pertenezca al tenant → modificación cruzada de tenants.
**Fix sugerido:** Interceptar al menos `findUnique`, `findUniqueOrThrow`, `create`, `update`, `delete`, `upsert` en el bloque `$allModels`.

#### CR-03 — Modelo `Project` (plantilla) nunca eliminado del schema
**Archivo:** `prisma/schema.prisma:33-56`
**Descripción:** El modelo `Project` tiene el comentario "Modelo de ejemplo: Project". Es código muerto del template base. Quedó en el schema junto con los 17 modelos de dominio reales. Contamina el Prisma Client generado y confunde a quien lea el schema.
**Fix sugerido:** Eliminar `enum ProjectStatus` y `model Project` del schema. Correr migración correspondiente.

#### CR-04 — `CashRegister.openedById` y `closedById` son strings sin FK
**Archivo:** `prisma/schema.prisma:549-550`
**Descripción:** Los campos `openedById String` y `closedById String?` guardan user IDs pero no tienen `@relation` a `User`. No hay integridad referencial: se pueden guardar IDs de usuarios inexistentes, o los IDs quedarán colgados si el usuario es eliminado.
**Fix sugerido:** Agregar relaciones explícitas `openedBy User @relation(...)` con `onDelete: Restrict` (no permitir eliminar usuario si tiene cajas abiertas).

#### CR-05 — `seed.ts` usa `update: plan` en upsert de planes — destructivo en producción
**Archivo:** `prisma/seed.ts:87`
**Descripción:** `await prisma.plan.upsert({ ..., update: plan })` sobreescribe precio y límites del plan en cada ejecución del seed. Si alguien ajustó precios en la DB (por inflación, por ejemplo), el seed los revierte al valor hardcodeado.
**Fix sugerido:** Usar `update: {}` para planes existentes, o separar la creación de planes de la lógica del seed en un script dedicado de configuración inicial.

---

### MEDIO

#### CR-06 — `withTenant()` crea una nueva Prisma extension en cada llamada
**Archivo:** `src/lib/tenant.ts:53-54`
**Descripción:** Cada invocación de `withTenant(organizationId)` ejecuta `prisma.$extends({...})`, que crea un nuevo objeto extendido. En una request típica esto se llama una vez, pero si se llama múltiples veces (middlewares, helpers) el overhead se acumula.
**Fix sugerido:** Memoizar por `organizationId` usando un `Map<string, ReturnType<typeof withTenant>>` con TTL corto, o documentar explícitamente que debe usarse una sola vez por request.

#### CR-07 — `Sale` no tiene `subtotal` pero `Invoice` sí — inconsistencia entre entidades
**Archivo:** `prisma/schema.prisma:429-455` vs `prisma/schema.prisma:369-397`
**Descripción:** `Invoice` tiene `subtotal`, `taxAmount`, `total`. `Sale` solo tiene `total` y `discountAmount` sin `subtotal`. `SaleItem` tiene `total` sin `subtotal`. `InvoiceItem` tiene ambos. No hay consistencia en qué campos de totales se persisten.
**Fix sugerido:** Definir un modelo de "resumen de totales" consistente para Sale: `subtotal`, `discountAmount`, `taxAmount`, `total`.

#### CR-08 — IDs construidos manualmente en seed con template strings
**Archivo:** `prisma/seed.ts:124, 140`
**Descripción:** `const warehouseId = \`warehouse-demo-${demoOrg.id}\`` y `pricelist-default-${demoOrg.id}`. Estos IDs hardcodeados en el código son frágiles. Si la lógica de ID cambia, el seed rompe el `where` del upsert buscando un ID que ya no existe.
**Fix sugerido:** Usar campos naturales únicos como `where` en el upsert (e.g., `{ organizationId_isDefault: { organizationId: demoOrg.id, isDefault: true } }` si se agrega unique constraint), o dejar que Prisma genere el ID y controlar duplicados por otro campo.

#### CR-09 — `StockMovement.referenceId / referenceType` polimórfico sin documentación
**Archivo:** `prisma/schema.prisma:516-517`
**Descripción:** `referenceId String?` y `referenceType String?` implementan una asociación polimórfica sin documentación de los valores válidos para `referenceType`. Quien use el modelo no sabe qué poner ahí.
**Fix sugerido:** Agregar comentario de schema o enum con los tipos de referencia válidos (`"sale"`, `"purchase"`, `"adjustment"`).

---

### BAJO

#### CR-10 — `TENANT_SCOPED_MODELS` es `Set<string>` sin validación en compile-time
**Archivo:** `src/lib/tenant.ts:7`
**Descripción:** Un typo en un nombre de modelo (ej: `"invoceItem"` en vez de `"invoiceItem"`) sería silencioso: el modelo quedaría sin tenant-filtering y ningún test lo detectaría salvo el hardcodeado en `tenant.test.ts`.
**Fix sugerido:** Tipar el Set usando los nombres de modelos de Prisma: `Set<Prisma.ModelName>` (de `@prisma/client`).

#### CR-11 — `maxUsers: 9999` y `maxMonthlyComprobantes: 9999` como magic numbers para "ilimitado"
**Archivo:** `prisma/seed.ts:77-78`
**Descripción:** El plan MAX usa `9999` como proxy de ilimitado. Esto es un magic number sin documentación. Un sistema que acumule 10.000 usuarios en un tenant MAX fallaría el chequeo de límites si ese chequeo se implementa naïvamente.
**Fix sugerido:** Usar `null` para ilimitado y ajustar el schema a `maxUsers Int?`, o agregar un campo `Boolean unlimited` explícito.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 1        |
| ALTO      | 4        |
| MEDIO     | 4        |
| BAJO      | 2        |
| **Total** | **11**   |
