/**
 * Tipos del Interview Engine — compartidos entre portal y admin.
 * Corresponden a la definición de QuestionBlock del plan.md.
 */

export type InputType =
  | 'text'
  | 'textarea'
  | 'multiple_choice'
  | 'multi_select'
  | 'rating'
  | 'url_input'
  | 'file_upload'
  | 'color_picker'
  | 'budget_range'
  | 'date'

export type Option = {
  value: string
  label: string
}

export type Validation = {
  required?: boolean
  minLength?: number
  maxLength?: number
  min?: number
  max?: number
  pattern?: string
}

export type DependsOn = {
  questionId: string
  operator: 'eq' | 'neq' | 'includes'
  value: string | string[]
}

export type QuestionBlock = {
  id: string
  question: string
  helpText?: string
  context?: string
  inputType: InputType
  options?: Option[]
  placeholder?: string
  defaultValue?: string
  /** De dónde viene el default: 'onboarding:industry', 'stage1:location', etc. */
  defaultSource?: string
  validation?: Validation
  dependsOn?: DependsOn
  /** Si true, la IA puede hacer una pregunta de seguimiento */
  aiFollowUp?: boolean
  category?: string
  skippable?: boolean
  fastTrackHint?: string
}

/** Entrada del historial de cambios (InterviewSession.answerHistory) */
export type AnswerHistoryEntry = {
  questionId: string
  oldValue: unknown
  newValue: unknown
  changedAt: string // ISO 8601
}

/** Entrada del historial de follow-ups (InterviewSession.followUpHistory) */
export type FollowUpEntry = {
  questionId: string
  aiQuestion: string
  userAnswer: string
  timestamp: string // ISO 8601
}

// ─── Strategic Brief ──────────────────────────────────────────────────────────

/**
 * Output estructurado del Stage 1 (El Estratega).
 * Se guarda en Deliverable.content y sirve como input para las etapas 2-6.
 * La IA infiere el posicionamiento — no se le pregunta directamente al cliente.
 */
export type StrategicBrief = {
  negocio: {
    /** Qué hace el negocio, en una oración concreta */
    descripcion: string
    /** Estado operativo al momento de la entrevista */
    estado: 'operando' | 'lanzamiento' | 'pivoteando'
    /** Antigüedad del negocio ("3 años") o null si aún no lanzó */
    antiguedad: string | null
    /** Recursos disponibles: equipo, presupuesto, materiales */
    recursosDisponibles: string
    /** Restricciones identificadas: qué no puede o no quiere hacer */
    restricciones: string[]
  }
  mercado: {
    /** Zona geográfica de operación */
    zonaGeografica: string
    /** Alcance real del negocio */
    alcance: string
    /** Competidores directos identificados */
    competidores: Array<{
      nombre: string
      fortaleza: string
      debilidad: string
    }>
    /** Espacios vacíos o nichos sin cubrir detectados por la IA */
    espaciosVacios: string[]
    /** Tendencias relevantes del sector */
    tendencias: string[]
  }
  audiencia: {
    /** Perfil del cliente real (no el aspiracional que el cliente quiere) */
    perfilCliente: string
    /** Cómo busca y compra este cliente */
    comoCompra: string
    /** Dolor principal que el negocio resuelve */
    dolorPrincipal: string
    /** Canal de adquisición principal actual */
    canalAdquisicion: string
  }
  posicionamiento: {
    /** Estrategia competitiva recomendada por la IA */
    estrategia: 'bajo_costo' | 'diferenciacion' | 'enfoque'
    /** Nicho específico donde el negocio puede ser primero o dominante */
    nichoEspecifico: string
    /** Ventaja competitiva sostenible (algo que la competencia no puede copiar fácil) */
    ventajaCompetitiva: string
    /** Riesgos de esta estrategia de posicionamiento */
    riesgos: string[]
    /**
     * Justificación de la IA para esta recomendación.
     * Puede contradecir la percepción del cliente — es intencional.
     */
    justificacion: string
  }
  direccionComunicacional: {
    /** Mensaje central: una frase que resume la propuesta de valor */
    mensajeCentral: string
    /** Tono de comunicación sugerido */
    tonoSugerido: string
    /** Territorios temáticos a explorar en la comunicación */
    territoriosTematicos: string[]
    /** Qué NO debe decir la comunicación */
    queNoDecir: string[]
    /** Modelo de precios sugerido para comunicar */
    rangoPrecios: string
  }
  /**
   * Puntos donde el cliente debe tomar una decisión estratégica.
   * La IA presenta opciones con pros/contras — no decide por él.
   */
  decisionesPendientes: Array<{
    tema: string
    opciones: Array<{
      opcion: string
      pro: string
      contra: string
    }>
  }>
}

// ─── Market Study ──────────────────────────────────────────────────────────────

/**
 * Output estructurado del Stage 2 (El Investigador).
 * Generado con datos de Serper API + síntesis de Claude.
 * Se guarda en Deliverable.content (type: 'MARKET_STUDY').
 */
// ─── Brand Options ────────────────────────────────────────────────────────────

/**
 * Un color de la paleta de marca.
 * hex es validado en runtime: /^#[0-9A-Fa-f]{6}$/
 */
export type ColorSwatch = {
  hex: string
  name: string
}

/**
 * Una opción de marca generada por OpenAI (uso interno del brand-generator).
 * Incluye logoPrompt que se pasa a Gemini pero NO se guarda en el deliverable.
 */
export type BrandConceptOption = {
  id: string
  /** Nombre descriptivo del concepto, ej: "Elegante Contemporáneo" */
  label: string
  /** Paleta de 4-5 colores */
  colors: ColorSwatch[]
  /** Fuente de titulares — debe existir en Google Fonts */
  headingFont: string
  /** Fuente de cuerpo — debe existir en Google Fonts */
  bodyFont: string
  /** 2-3 adjetivos que definen la personalidad de marca */
  brandPersonality: string[]
  /** Prompt en inglés para generar el logo con Gemini (no se persiste) */
  logoPrompt: string
}

/**
 * Una opción de marca lista para mostrar en BrandApproval.tsx.
 * Derivada de BrandConceptOption; sin logoPrompt, con logoUrl opcional.
 */
export type BrandOption = {
  id: string
  label: string
  /** URL pública en Supabase Storage (bucket: brand-logos). Omitido si Gemini falló para esta opción. */
  logoUrl?: string
  colors: ColorSwatch[]
  headingFont: string
  bodyFont: string
  brandPersonality: string[]
}

/**
 * Contenido del Deliverable de tipo BRAND_OPTIONS.
 * Se guarda en Deliverable.content como JSON.
 */
export type BrandOptions = {
  options: BrandOption[]
  /** Texto de disclaimer de IA a mostrar antes de las opciones */
  disclaimer: string
}

// ─── Campaign Plan ────────────────────────────────────────────────────────────

/**
 * Output estructurado del Stage 5 (Campañas).
 * Generado a partir de los deliverables de etapas 1-4 + respuestas del cliente.
 * Se guarda en Deliverable.content (type: 'CAMPAIGN_PLAN').
 */
export type CampaignPlan = {
  resumen: {
    /** Qué se busca lograr con la campaña (2-3 oraciones) */
    objetivos: string
    /** Duración estimada de la campaña, ej: "3 meses" */
    duracionEstimada: string
    presupuestoRecomendado: {
      /** Presupuesto mínimo sugerido en pesos ARS */
      min: number
      /** Presupuesto máximo sugerido en pesos ARS */
      max: number
      /** Por qué se recomienda este rango */
      justificacion: string
    }
  }

  plataformas: Array<{
    nombre: 'GOOGLE_ADS' | 'META'
    /** Por qué esta plataforma es adecuada para el negocio */
    razon: string
    formatos: Array<{
      /** Tipo de formato publicitario */
      tipo: string
      /** Descripción del formato y cómo usarlo */
      descripcion: string
      /** Presupuesto sugerido para este formato en ARS */
      presupuestoSugerido: number
    }>
  }>

  audiencias: Array<{
    /** Nombre descriptivo del segmento, ej: "Mujeres 25-40 en CABA" */
    nombre: string
    descripcion: string
    /** Tamaño estimado, ej: "150K usuarios" */
    tamanioEstimado: string
    /** Criterios de segmentación principales */
    criterios: string[]
  }>

  oferta: {
    /** Mensaje publicitario principal */
    mensajePrincipal: string
    /** 2-3 variantes de ángulo creativo */
    variantesCreativas: string[]
    /** CTA principal, ej: "Solicitá tu turno gratis" */
    callToAction: string
  }

  calendario: Array<{
    /** Nombre de la fase, ej: "Lanzamiento" */
    fase: string
    /** Duración, ej: "Semanas 1-2" */
    duracion: string
    actividades: string[]
    /** Presupuesto asignado a esta fase en ARS */
    presupuesto: number
  }>

  metricas: {
    kpisObjetivo: Array<{
      /** Nombre del KPI, ej: "CPA", "CTR", "ROAS" */
      nombre: string
      /** Meta cuantitativa, ej: "Máximo $150 por conversión" */
      meta: string
      /** Por qué este KPI es relevante */
      razon: string
    }>
    /** Frecuencia de reporte, ej: "Semanal" */
    reportingFrecuencia: string
  }

  riesgos: Array<{
    riesgo: string
    probabilidad: 'alta' | 'media' | 'baja'
    mitigacion: string
  }>

  /** Texto de disclaimer de IA que se muestra antes del plan */
  disclaimer: string
}

export type MarketStudy = {
  resumenEjecutivo: {
    /** Síntesis del panorama competitivo en 2-3 oraciones */
    panorama: string
    /** Nivel de competencia: baja / media / alta / saturada */
    nivelCompetencia: 'baja' | 'media' | 'alta' | 'saturada'
    /** Oportunidad principal detectada */
    oportunidadPrincipal: string
  }

  competidores: Array<{
    nombre: string
    /** URL del sitio web (dato real de Serper, no inventado) */
    website: string | null
    /** Rating en Google Maps (dato real) */
    googleRating: number | null
    /** Cantidad de reseñas en Google Maps */
    googleReviews: number | null
    /** Qué hacen bien (análisis de su presencia digital) */
    fortalezasDigitales: string[]
    /** Dónde fallan o tienen oportunidad */
    debilidadesDigitales: string[]
    /** Posicionamiento percibido */
    posicionamiento: string
  }>

  presenciaDigital: {
    /** Análisis de qué aparece cuando alguien busca las keywords del cliente */
    resultadosBusqueda: string
    /** Keywords que dominan los competidores */
    keywordsCompetidores: string[]
    /** Keywords con oportunidad (baja competencia, alta intención) */
    keywordsOportunidad: string[]
    /** Estado del negocio en Google Maps */
    googleMapsPropio: {
      encontrado: boolean
      rating: number | null
      reviews: number | null
      sugerenciaMejora: string
    }
  }

  tendencias: Array<{
    /** Tendencia identificada */
    tendencia: string
    /** Impacto para el negocio: positivo / negativo / neutro */
    impacto: 'positivo' | 'negativo' | 'neutro'
    /** Cómo aprovecharla o protegerse */
    accion: string
  }>

  oportunidades: Array<{
    /** Descripción de la oportunidad */
    descripcion: string
    /** Prioridad: alta / media / baja */
    prioridad: 'alta' | 'media' | 'baja'
    /** Acción concreta recomendada */
    accionRecomendada: string
    /** Evidencia que soporta esta oportunidad */
    evidencia: string
  }>

  amenazas: Array<{
    descripcion: string
    severidad: 'alta' | 'media' | 'baja'
    mitigacion: string
  }>

  recomendaciones: {
    /** Top 3 acciones inmediatas (próximas 2 semanas) */
    inmediatas: string[]
    /** Acciones a mediano plazo (1-3 meses) */
    medianoPlazo: string[]
    /** Métricas sugeridas para trackear */
    metricasClave: string[]
  }
}

// ─── Ad Creatives ─────────────────────────────────────────────────────────────

/**
 * Un copy creativo para una pieza publicitaria.
 * Respeta los límites de caracteres de cada plataforma/formato.
 */
export type AdCopyVariant = {
  /** Título del anuncio — límites: Google Search 30 chars, Meta Feed/Story 40 chars */
  headline: string
  /** Descripción o texto principal — Google 90 chars, Meta 125 chars */
  description: string
  /** Llamada a la acción, ej: "Probá gratis", "Contactanos" */
  callToAction: string
  /** Ángulo creativo que diferencia esta variante */
  angle: string
}

/**
 * Output estructurado del Stage 5 (generador de piezas publicitarias).
 * Se guarda en Deliverable.content (type: 'AD_CREATIVES').
 * Contiene 2-3 variantes de copy por plataforma/formato.
 */
export type AdCreatives = {
  googleAds: {
    /** Variantes para Google Search (intención de búsqueda directa) */
    search: AdCopyVariant[]
  } | null

  metaAds: {
    /** Variantes para Meta Feed (Facebook/Instagram feed) */
    feed: AdCopyVariant[]
    /** Variantes para Meta Story/Reels (vertical, contenido efímero) */
    story: AdCopyVariant[]
  } | null

  /** Notas de guía de tono para el equipo de diseño */
  guiaDeTono: {
    /** Tono de voz a mantener en todas las piezas */
    tono: string
    /** Palabras clave a incluir */
    palabrasClave: string[]
    /** Frases y términos a evitar */
    evitar: string[]
  }

  /** Texto de disclaimer de IA a mostrar antes de las piezas */
  disclaimer: string
}

// ─── Ad Visuals ───────────────────────────────────────────────────────────────

/**
 * Formato de una pieza gráfica para Meta Ads.
 * Determina el aspect ratio y las dimensiones recomendadas.
 */
export type AdVisualFormat = 'feed_square' | 'feed_portrait' | 'story'

/**
 * Una pieza gráfica generada por IA para Meta Ads.
 * La URL apunta al bucket privado ad-visuals en Supabase Storage.
 *
 * NOTA: el prompt de generación NO se persiste aquí — ver ADR-0024.
 * Es lógica interna de Qautiva, no debe enviarse al cliente.
 */
export type AdVisual = {
  /** Formato de la pieza — determina el aspect ratio */
  format: AdVisualFormat
  /** Aspect ratio real de la pieza */
  aspectRatio: '1:1' | '4:5' | '9:16'
  /** Dimensiones recomendadas, ej: "1080x1080" */
  resolution: string
  /** Signed URL de Supabase Storage (TTL: 1 año) */
  imageUrl: string
  /** Ángulo creativo usado — "hero shot" | "lifestyle" */
  angle: string
  /** Timestamp de generación en ISO 8601 */
  generatedAt: string
  /** Número de intento (1 = primera generación, 2 = regeneración) */
  attempt: number
  /** Score de validación 0-100. Ausente si la validación fue saltada por error. */
  validationScore?: number
}

/**
 * Contexto de marca usado durante la generación visual.
 * Permite auditar qué datos se usaron para generar las piezas.
 */
export type AdVisualBrandContext = {
  /** Colores hex dominantes de la paleta de marca */
  dominantColors: string[]
  /** Estilo visual inferido de BrandOptions */
  style: string
  /** Si se usó el logo del cliente como input de Gemini */
  logoUsed: boolean
}

/**
 * Output estructurado del Stage 5 — piezas gráficas para Meta Ads.
 * Se guarda en Deliverable.content (type: 'AD_VISUALS').
 * Complementa a AD_CREATIVES (copy) con las imágenes correspondientes.
 */
export type AdVisuals = {
  /** Piezas generadas. Puede ser parcial si hubo degradación aceptable. */
  visuals: AdVisual[]
  /** Contexto de marca usado durante la generación */
  brandContext: AdVisualBrandContext
  /** Texto de disclaimer de IA */
  disclaimer: string
}
