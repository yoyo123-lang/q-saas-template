import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { getUserTeamIds } from '@/app/_lib/interview/get-user-team-ids'

/**
 * GET /api/interview/sessions/[id]/brief
 *
 * Retorna el Brief Estratégico generado para esta sesión.
 * Solo disponible cuando session.status === 'COMPLETED'.
 *
 * Returns: { ok: true, brief: StrategicBrief }
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } },
) {
  if (
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)
  ) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const teamIds = await getUserTeamIds(user.id)
  if (!teamIds) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const session = await prisma.interviewSession.findFirst({
    where: {
      id: params.id,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: {
      status: true,
      stageId: true,
      teamId: true,
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  if (session.status !== 'COMPLETED') {
    return NextResponse.json(
      { error: 'El Brief todavía no está disponible' },
      { status: 409 },
    )
  }

  const deliverable = await prisma.deliverable.findFirst({
    where: {
      stageId: session.stageId,
      type: 'BRIEF',
      isActive: true,
      ...(session.teamId ? { teamId: session.teamId } : {}),
    },
    select: { content: true },
    orderBy: { createdAt: 'desc' },
  })

  if (!deliverable) {
    return NextResponse.json({ error: 'Brief no encontrado' }, { status: 404 })
  }

  return NextResponse.json({ ok: true, brief: deliverable.content })
}
