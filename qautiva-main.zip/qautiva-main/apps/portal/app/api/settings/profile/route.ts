import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'

/**
 * PATCH /api/settings/profile
 * Actualiza displayName y/o avatarUrl del usuario autenticado.
 */
export async function PATCH(request: Request) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const displayName = typeof body.displayName === 'string' ? body.displayName.trim() : undefined
  const avatarUrl = typeof body.avatarUrl === 'string' ? body.avatarUrl.trim() : undefined

  if (!displayName && !avatarUrl) {
    return NextResponse.json({ error: 'No hay campos para actualizar' }, { status: 400 })
  }

  if (displayName !== undefined && displayName.length === 0) {
    return NextResponse.json({ error: 'El nombre no puede estar vacío' }, { status: 400 })
  }

  if (displayName !== undefined && displayName.length > 150) {
    return NextResponse.json({ error: 'El nombre no puede superar los 150 caracteres' }, { status: 400 })
  }

  if (avatarUrl !== undefined && avatarUrl.length > 0) {
    try {
      const parsed = new URL(avatarUrl)
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
        return NextResponse.json({ error: 'La URL del avatar debe ser http o https' }, { status: 400 })
      }
    } catch {
      return NextResponse.json({ error: 'La URL del avatar no es válida' }, { status: 400 })
    }
  }

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true },
  })

  if (!profile) {
    return NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 })
  }

  const updated = await prisma.userProfile.update({
    where: { id: profile.id },
    data: {
      ...(displayName !== undefined && { displayName }),
      ...(avatarUrl !== undefined && { avatarUrl }),
    },
    select: { displayName: true, avatarUrl: true, email: true },
  })

  revalidatePath('/configuracion')

  return NextResponse.json({ ok: true, profile: updated })
}
