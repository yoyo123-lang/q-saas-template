import { prisma } from '@qautiva/db'

// ── Types ────────────────────────────────────────────────────────────────────

export type AiProviderType = 'ANTHROPIC' | 'OPENAI'

export interface AiConfig {
  provider: AiProviderType
  model: string
}

// ── Defaults ─────────────────────────────────────────────────────────────────

const DEFAULT_CONFIG: AiConfig = {
  provider: 'OPENAI',
  model: 'gpt-4o',
}

// ── Cache ────────────────────────────────────────────────────────────────────

const CACHE_TTL_MS = 5 * 60 * 1000 // 5 minutos

let _cachedConfig: AiConfig | null = null
let _cachedAt = 0

// ── Public API ───────────────────────────────────────────────────────────────

/**
 * Lee el provider y modelo de IA configurados en TrialConfig (singleton id=1).
 * Cache en memoria con TTL de 5 minutos para no golpear la DB en cada generación.
 *
 * Si TrialConfig no existe o el provider no es soportado para generadores (GOOGLE_GEMINI),
 * retorna el default (OpenAI gpt-4o).
 */
export async function getAiConfig(): Promise<AiConfig> {
  const now = Date.now()
  if (_cachedConfig && now - _cachedAt < CACHE_TTL_MS) {
    return _cachedConfig
  }

  try {
    const trial = await prisma.trialConfig.findUnique({
      where: { id: 1 },
      select: { qautivaProvider: true, qautivaModel: true },
    })

    if (!trial) {
      _cachedConfig = DEFAULT_CONFIG
      _cachedAt = now
      return DEFAULT_CONFIG
    }

    const provider = trial.qautivaProvider as string
    if (provider !== 'ANTHROPIC' && provider !== 'OPENAI') {
      // GOOGLE_GEMINI no soportado para tool-call generators (no tiene tool_use equivalente robusto)
      console.warn(`[ai-config] Provider "${provider}" no soportado para generators — usando default`)
      _cachedConfig = DEFAULT_CONFIG
      _cachedAt = now
      return DEFAULT_CONFIG
    }

    _cachedConfig = {
      provider,
      model: trial.qautivaModel || DEFAULT_CONFIG.model,
    }
    _cachedAt = now
    return _cachedConfig
  } catch (err) {
    console.error('[ai-config] Error leyendo TrialConfig — usando default', {
      error: err instanceof Error ? err.message : String(err),
    })
    // No cachear errores — reintentar en la próxima llamada
    return _cachedConfig ?? DEFAULT_CONFIG
  }
}

// ── Gemini Image Model ──────────────────────────────────────────────────────

const DEFAULT_GEMINI_IMAGE_MODEL = 'gemini-2.5-flash-image'

let _cachedGeminiModel: string | null = null
let _geminiCachedAt = 0

/**
 * Lee el modelo de Gemini para generación de imágenes desde TrialConfig.
 * Cache en memoria con TTL de 5 minutos.
 */
export async function getGeminiImageModel(): Promise<string> {
  const now = Date.now()
  if (_cachedGeminiModel && now - _geminiCachedAt < CACHE_TTL_MS) {
    return _cachedGeminiModel
  }

  try {
    const trial = await prisma.trialConfig.findUnique({
      where: { id: 1 },
      select: { geminiImageModel: true },
    })

    _cachedGeminiModel = trial?.geminiImageModel || DEFAULT_GEMINI_IMAGE_MODEL
    _geminiCachedAt = now
    return _cachedGeminiModel
  } catch (err) {
    console.error('[ai-config] Error leyendo geminiImageModel — usando default', {
      error: err instanceof Error ? err.message : String(err),
    })
    return _cachedGeminiModel ?? DEFAULT_GEMINI_IMAGE_MODEL
  }
}

/**
 * Invalida el cache forzando una re-lectura de DB en la próxima llamada.
 * Útil para tests.
 */
export function invalidateAiConfigCache(): void {
  _cachedConfig = null
  _cachedAt = 0
  _cachedGeminiModel = null
  _geminiCachedAt = 0
}
