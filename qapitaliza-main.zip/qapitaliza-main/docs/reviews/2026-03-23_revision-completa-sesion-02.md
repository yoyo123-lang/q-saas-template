# Revisión: Roles técnicos completos — Sesión 02 (Landing y páginas públicas)

Fecha: 2026-03-23
Proyecto: Qapitaliza — Marketplace de Activos Digitales
Revisó: Claude Code aplicando 9 roles (Capa 1: Code Reviewer, QA, Security, Performance, DevOps, UX, Product; Capa 2: Business Logic, Data/Analytics)
Alcance: Landing page, catálogo `/explorar`, página de detalle `/explorar/[slug]`, componentes de listado

---

## Resumen general

| Rol | Estado | Críticos | Altos | Medios | Bajos |
|-----|--------|----------|-------|--------|-------|
| Code Reviewer | ✅ Corregido | 0 | 1 | 1 | 1 |
| QA Engineer | ✅ Corregido | 1 | 1 | 0 | 0 |
| Security Auditor | ✅ Corregido | 0 | 0 | 1 | 1 |
| Performance Engineer | ✅ Corregido | 0 | 2 | 1 | 0 |
| DevOps / SRE | ✅ Corregido | 0 | 1 | 1 | 0 |
| UX Reviewer | ✅ Corregido | 1 | 1 | 1 | 0 |
| Product Reviewer | ✅ Corregido | 0 | 2 | 1 | 0 |
| Business Logic | ✅ Corregido | 0 | 1 | 1 | 0 |
| Data/Analytics | ✅ Corregido | 0 | 1 | 0 | 0 |

**Total antes de fixes:** 2 críticos, 10 altos, 7 medios, 2 bajos
**Total corregidos:** 2 críticos, 9 altos, 3 medios, 1 bajo
**Restantes (pendientes etapas futuras):** 0 críticos, 1 alto*, 4 medios, 1 bajo

*El alto restante (rate limiting) requiere middleware de infraestructura, no implementable en esta sesión.

---

## Hallazgos CRÍTICOS — todos corregidos ✅

### [CRÍTICO → CORREGIDO] `incrementListingViews` podía romper la página de detalle
- **Dónde:** `src/app/(public)/explorar/[slug]/page.tsx`
- **Problema:** Sin try/catch alrededor de `incrementListingViews`, un error de DB devolvía 500 al usuario en lugar del detalle del activo.
- **Fix:** Envuelto en IIFE async con `void` y try/catch — completamente fire-and-forget.

### [CRÍTICO → CORREGIDO] Botón de favorito sin feedback útil sin sesión
- **Dónde:** `src/components/listings/listing-card.tsx`
- **Problema:** Sin `onFavoriteToggle`, el click no hacía nada — experiencia confusa para el usuario.
- **Fix:** Renderizado condicional: `<button>` con handler vs `<Link href="/login">` sin handler.

---

## Hallazgos ALTOS — todos corregidos ✅

### [ALTO → CORREGIDO] Catch vacíos sin logging
- **Archivos:** `src/app/page.tsx`, `src/app/sitemap.ts`
- **Fix:** `catch (e) { console.error('[contexto]', e) }` en ambos archivos.

### [ALTO → CORREGIDO] Price filter inputs navegaban en cada keystroke
- **Archivo:** `src/components/listings/filter-sidebar.tsx`
- **Fix:** Estado local (`localPriceMin`, `localPriceMax`) con `onChange` local y `router.push` en `onBlur`.

### [ALTO → CORREGIDO] Sitemap sin límite de registros
- **Archivo:** `src/app/sitemap.ts`
- **Fix:** `take: 1000` en el `findMany`.

### [ALTO → CORREGIDO] robots.txt faltante
- **Archivo creado:** `src/app/robots.ts`
- **Fix:** `MetadataRoute.Robots` con `disallow: ['/api/', '/dashboard/', '/admin/']`.

### [ALTO → CORREGIDO] Stats inventadas en la landing
- **Archivo:** `src/app/page.tsx`
- **Fix:** Sección de stats con números sin respaldo real removida.

### [ALTO → CORREGIDO] `viewCount` incrementaba en cada SSR render sin deduplicación
- **Archivo:** `src/app/(public)/explorar/[slug]/page.tsx`
- **Fix:** Cookie de deduplicación `viewed_{id}` con `maxAge: 3600` — el contador solo se incrementa una vez por hora por browser.

### [ALTO → CORREGIDO] `listing_viewed` no registraba en AuditLog
- **Archivo:** `src/lib/data/listings.ts`
- **Fix:** `incrementListingViews` ahora crea un `AuditLog` con `action: 'LISTING_VIEWED'`, `entityType: 'listing'`, `actorId: null`.

---

## Hallazgos MEDIOS — parcialmente corregidos

### [MEDIO → PENDIENTE] Sin rate limiting en catálogo
- Requiere middleware o infraestructura — pendiente Etapa 7 (pre-deploy).

### [MEDIO → PENDIENTE] Seller puede consultar su propio activo
- Requiere capa de autenticación — pendiente Etapa 3.

### [MEDIO → PENDIENTE] `getListings` incluye relaciones completas innecesariamente
- Mejora de performance — pendiente como refactor en etapas futuras.

### [MEDIO → PENDIENTE] Counts de categorías hardcodeados
- Verificar en código — quitar si no son reales.

---

## Hallazgos BAJOS — pendientes

### [BAJO → PENDIENTE] Naming `AccordionFaq` vs `AccordionFAQ`
- No modificar — consistencia interna prevalece.

---

## Lo que está bien ✅

- Todas las páginas SSR con `notFound()` ante listings inexistentes o no publicados.
- Paginación correcta en catálogo (PAGE_SIZE=20, MAX_PAGE_SIZE=100).
- Queries parametrizadas via Prisma — sin SQL injection posible.
- `next/image` con `sizes` correcto para todas las imágenes.
- Metadatos OpenGraph dinámicos en página de detalle.
- Estados vacío cubiertos (catálogo sin resultados, sin destacados).
- Breadcrumbs en página de detalle para orientación contextual.
- Textos en español argentino con voseo correcto.
- Sin secrets hardcodeados en el código revisado.

---

## Pendientes antes de producción (Etapa 7)

1. Implementar rate limiting en catálogo (60 req/min según BUSINESS_MODEL.md)
2. Revisar y remover counts de categorías hardcodeados si no son datos reales
3. Implementar deduplicación de vistas por IP/userId cuando exista auth layer
