export default function DashboardLoading() {
  return (
    <div className="space-y-8">
      {/* Header skeleton */}
      <div className="space-y-2">
        <div className="h-8 w-64 bg-slate-800 rounded-lg animate-pulse" />
        <div className="h-4 w-48 bg-slate-800 rounded animate-pulse" />
      </div>

      {/* StatCards skeleton */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-navy-900 border border-slate-800 rounded-xl p-5 space-y-3 animate-pulse">
            <div className="h-4 w-28 bg-slate-800 rounded" />
            <div className="h-8 w-20 bg-slate-700 rounded" />
            <div className="h-3 w-24 bg-slate-800 rounded" />
          </div>
        ))}
      </div>

      {/* Content skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-navy-900 border border-slate-800 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 w-40 bg-slate-800 rounded" />
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-16 bg-slate-800 rounded-lg" />
          ))}
        </div>
        <div className="bg-navy-900 border border-slate-800 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 w-32 bg-slate-800 rounded" />
          <div className="h-48 bg-slate-800 rounded-lg" />
        </div>
      </div>
    </div>
  )
}
