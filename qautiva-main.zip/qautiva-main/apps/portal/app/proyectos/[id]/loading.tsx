export default function ProyectoLoading() {
  return (
    <div className="p-6 max-w-3xl mx-auto animate-pulse">
      <div className="mb-6">
        <div className="h-7 w-52 bg-[#1E293B] rounded-lg mb-2" />
        <div className="h-4 w-36 bg-[#1E293B] rounded" />
      </div>
      <div className="flex flex-col gap-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
            <div className="h-5 w-32 bg-[#1E293B] rounded mb-3" />
            <div className="h-3 w-full bg-[#1E293B] rounded mb-2" />
            <div className="h-3 w-3/4 bg-[#1E293B] rounded" />
          </div>
        ))}
      </div>
    </div>
  )
}
