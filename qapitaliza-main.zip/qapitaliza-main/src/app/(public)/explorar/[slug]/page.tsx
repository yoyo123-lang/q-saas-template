import { notFound } from 'next/navigation'
import { cookies } from 'next/headers'
import Link from 'next/link'
import Image from 'next/image'
import type { Metadata } from 'next'
import { Check, Calendar, Eye } from 'lucide-react'
import { getListing, getRelatedListings, incrementListingViews } from '@/lib/data/listings'
import { isFavorited } from '@/lib/data/favorites'
import { createClient } from '@/lib/supabase/server'
import { Breadcrumb } from '@/components/shared/breadcrumb'
import { Badge } from '@/components/ui/badge'
import { TechPill } from '@/components/listings/tech-pill'
import { ListingCard } from '@/components/listings/listing-card'
import { LogoQ } from '@/components/shared/logo-q'
import { GalleryClient } from '@/components/listings/gallery-client'
import { ListingActions } from '@/components/listings/listing-actions'

const typeLabels: Record<string, string> = {
  WEBSITE: 'Sitio Web',
  DOMAIN: 'Dominio',
  SAAS: 'SaaS',
  ECOMMERCE: 'E-commerce',
  PROJECT: 'Proyecto',
  OTHER: 'Otro',
}

function daysAgo(date: Date | string): string {
  const diff = Math.floor((Date.now() - new Date(date).getTime()) / 86400000)
  if (diff === 0) return 'hoy'
  if (diff === 1) return 'hace 1 día'
  return `hace ${diff} días`
}

interface ListingDetailPageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: ListingDetailPageProps): Promise<Metadata> {
  const { slug } = await params
  const listing = await getListing(slug)
  if (!listing) return {}

  return {
    title: listing.title,
    description: listing.description.slice(0, 160),
    openGraph: {
      title: listing.title,
      description: listing.description.slice(0, 160),
      images: listing.screenshotUrls[0] ? [listing.screenshotUrls[0]] : [],
    },
  }
}

export default async function ListingDetailPage({ params }: ListingDetailPageProps) {
  const { slug } = await params
  const listing = await getListing(slug)

  if (!listing) notFound()

  // Increment view count — fire-and-forget with cookie deduplication (1h TTL)
  // Wrapping in void+try/catch so a DB failure never breaks the page render
  void (async () => {
    try {
      const cookieStore = await cookies()
      const cookieKey = `viewed_${listing.id}`
      if (!cookieStore.has(cookieKey)) {
        cookieStore.set(cookieKey, '1', { maxAge: 3600, httpOnly: true, secure: process.env.NODE_ENV === 'production', path: '/' })
        await incrementListingViews(listing.id)
      }
    } catch (e) {
      console.error('[ListingDetail] Failed to increment view count:', e)
    }
  })()

  const relatedListings = await getRelatedListings(listing.id, listing.type, 3)

  // Auth state for interactive buttons
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const currentUserId = user?.id ?? null
  const isOwnListing = currentUserId === listing.sellerId
  const initialIsFavorited = currentUserId
    ? await isFavorited(currentUserId, listing.id)
    : false

  const price = parseFloat(listing.askingPrice.toString())
  const isVerified = listing.verificationStatus === 'VERIFIED'
  const isFeatured = listing.featuredUntil && new Date(listing.featuredUntil) > new Date()

  const sellerInitials = (listing.seller.fullName ?? listing.seller.email)
    .split(' ')
    .map((w) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)

  const sellerYear = new Date(listing.seller.createdAt).getFullYear()
  const mrr = listing.monthlyRevenue ? parseFloat(listing.monthlyRevenue.toString()) : null

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: 'Explorar', href: '/explorar' },
          { label: typeLabels[listing.type] ?? listing.type, href: `/explorar?category=${listing.category?.slug ?? listing.type.toLowerCase()}` },
          { label: listing.title },
        ]}
      />

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8 items-start">
        {/* ── Left column ── */}
        <div className="flex flex-col gap-8">
          {/* Header */}
          <div>
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant="info">{typeLabels[listing.type] ?? listing.type}</Badge>
              {isVerified && <Badge variant="success" dot>Verificado</Badge>}
              {isFeatured && <Badge variant="amber">Destacado</Badge>}
            </div>
            <h1 className="text-3xl font-semibold text-slate-50 leading-snug">{listing.title}</h1>
            <div className="flex items-center gap-4 mt-2 text-sm text-slate-500">
              <span className="flex items-center gap-1">
                <Calendar className="size-3.5" />
                Publicado {daysAgo(listing.publishedAt ?? listing.createdAt)} por{' '}
                <span className="text-slate-400">{listing.seller.fullName ?? 'Vendedor'}</span>
              </span>
              <span className="flex items-center gap-1">
                <Eye className="size-3.5" />
                {listing.viewCount} vistas
              </span>
            </div>
            <p className="text-2xl font-bold text-amber-500 mt-3">
              ${price.toLocaleString('en-US')} USD
            </p>
          </div>

          {/* Gallery */}
          <GalleryClient
            screenshots={listing.screenshotUrls}
            title={listing.title}
          />

          {/* Description */}
          <div>
            <h2 className="text-lg font-semibold text-slate-50 mb-3">Descripción</h2>
            <p className="text-sm text-slate-400 leading-relaxed whitespace-pre-line">
              {listing.description}
            </p>
          </div>

          {/* Tech Stack */}
          {listing.techStack.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-slate-50 mb-3">Tech Stack</h2>
              <div className="flex flex-wrap gap-2">
                {listing.techStack.map((tech) => (
                  <TechPill key={tech} tech={tech} />
                ))}
              </div>
            </div>
          )}

          {/* Métricas */}
          <div>
            <h2 className="text-lg font-semibold text-slate-50 mb-3">Métricas</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {mrr != null && (
                <MetricCard label="Revenue Mensual" value={`$${mrr.toLocaleString('en-US')}`} />
              )}
              {listing.monthlyTraffic != null && (
                <MetricCard
                  label="Tráfico Mensual"
                  value={`${listing.monthlyTraffic.toLocaleString('en-US')} visitas`}
                />
              )}
              {listing.domainAge != null && (
                <MetricCard label="Antigüedad" value={`${listing.domainAge} meses`} />
              )}
              {listing.metrics.map((metric) => (
                <MetricCard
                  key={metric.id}
                  label={metric.metricType.replace(/_/g, ' ')}
                  value={parseFloat(metric.value.toString()).toLocaleString('en-US')}
                />
              ))}
            </div>
            {isVerified && (
              <p className="text-sm text-emerald-500 mt-3 flex items-center gap-1.5">
                <Check className="size-4" />
                Métricas verificadas por Qapitaliza ✓
              </p>
            )}
          </div>
        </div>

        {/* ── Right sidebar (sticky) ── */}
        <div className="sticky top-24 flex flex-col gap-4">
          {/* Action card */}
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-6 flex flex-col gap-4">
            <div>
              <p className="text-sm text-slate-500 mb-1">Precio de venta</p>
              <p className="text-2xl font-bold text-amber-500">
                ${price.toLocaleString('en-US')} USD
              </p>
            </div>

            {currentUserId ? (
              <ListingActions
                listingId={listing.id}
                slug={listing.slug}
                isOwnListing={isOwnListing}
                initialIsFavorited={initialIsFavorited}
              />
            ) : (
              <>
                <Link
                  href={`/login?redirect=/explorar/${listing.slug}&message=Para+consultar+al+vendedor+necesit%C3%A1s+una+cuenta`}
                  className="flex items-center justify-center w-full px-4 py-3 rounded-lg bg-amber-500 text-navy-950 font-semibold text-base hover:bg-amber-400 transition-colors"
                >
                  Consultar al vendedor
                </Link>
                <Link
                  href={`/login?redirect=/explorar/${listing.slug}&message=Para+guardar+favoritos+necesit%C3%A1s+una+cuenta`}
                  className="flex items-center justify-center w-full px-4 py-3 rounded-lg border border-amber-500 text-amber-500 font-medium text-base hover:bg-amber-500/10 transition-colors"
                >
                  ♡ Guardar en favoritos
                </Link>
              </>
            )}

            <div className="h-px bg-slate-800" />

            {/* Seller info */}
            <div className="flex items-start gap-3">
              <div className="size-10 rounded-full bg-slate-700 flex items-center justify-center text-sm font-semibold text-slate-50 flex-shrink-0">
                {sellerInitials}
              </div>
              <div className="flex flex-col gap-0.5">
                <p className="text-sm font-medium text-slate-50">
                  {listing.seller.fullName ?? 'Vendedor'}
                </p>
                {isVerified && (
                  <p className="text-xs text-emerald-500">Vendedor verificado ✓</p>
                )}
                <p className="text-xs text-slate-500">Miembro desde {sellerYear}</p>
                <Link
                  href={`/perfil/${listing.seller.id}`}
                  className="text-xs text-amber-500 hover:underline mt-1"
                >
                  Ver perfil →
                </Link>
              </div>
            </div>
          </div>

          {/* Security card */}
          <div className="bg-navy-900 border border-amber-500/20 rounded-xl p-4">
            <p className="text-sm font-medium text-slate-50 mb-3">🔒 Transacción segura</p>
            <ul className="flex flex-col gap-2">
              {[
                'Vendedores verificados por Qapitaliza',
                'Soporte durante todo el proceso',
                'Proceso de transferencia guiado',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-xs text-slate-400">
                  <Check className="size-3.5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* ── Activos relacionados ── */}
      {relatedListings.length > 0 && (
        <section className="mt-16">
          <h2 className="text-xl font-semibold text-slate-50 mb-6">Activos relacionados</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedListings.map((rel) => {
              const relBadges: ('verified' | 'featured' | 'premium')[] = []
              if (rel.verificationStatus === 'VERIFIED') relBadges.push('verified')
              if (rel.featuredUntil && new Date(rel.featuredUntil) > new Date())
                relBadges.push('featured')

              return (
                <ListingCard
                  key={rel.id}
                  id={rel.id}
                  slug={rel.slug}
                  title={rel.title}
                  type={rel.type}
                  priceUsd={parseFloat(rel.askingPrice.toString())}
                  screenshot={rel.screenshotUrls[0]}
                  metrics={{
                    mrr: rel.monthlyRevenue
                      ? parseFloat(rel.monthlyRevenue.toString())
                      : undefined,
                    monthlyVisits: rel.monthlyTraffic ?? undefined,
                  }}
                  techStack={rel.techStack}
                  badges={relBadges}
                />
              )
            })}
          </div>
        </section>
      )}
    </div>
  )
}

function MetricCard({ label, value, trend }: { label: string; value: string; trend?: string }) {
  return (
    <div className="bg-navy-900 border border-slate-800 rounded-xl p-4">
      <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">{label}</p>
      <p className="text-xl font-bold text-slate-50">{value}</p>
      {trend && <p className="text-xs text-emerald-500 mt-1">{trend}</p>}
    </div>
  )
}
