'use server'

import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { syncAdAccountMetrics as syncMetrics } from '@/lib/metrics-sync'
import type { SyncResult } from '@/lib/metrics-sync'

const CAMPAIGN_DELIVERABLE_TYPES = ['CAMPAIGN_PLAN', 'AD_CREATIVES'] as const

/**
 * Envía un deliverable de campaña al cliente (DRAFT/ADMIN_APPROVED → SENT_TO_CLIENT).
 * Solo aplica a CAMPAIGN_PLAN y AD_CREATIVES.
 */
export async function sendCampaignDeliverableToClient(
  deliverableId: string,
  orgId: string,
): Promise<{ ok: boolean; error?: string }> {
  await requireAdminSession()

  if (!deliverableId?.trim()) return { ok: false, error: 'deliverableId requerido' }
  if (!orgId?.trim()) return { ok: false, error: 'orgId requerido' }

  const deliverable = await prisma.deliverable.findUnique({
    where: { id: deliverableId },
    select: { id: true, type: true, status: true, organizationId: true },
  })

  if (!deliverable) {
    return { ok: false, error: 'Entregable no encontrado' }
  }
  if (deliverable.organizationId !== orgId) {
    return { ok: false, error: 'El entregable no pertenece a la organización indicada' }
  }
  if (!CAMPAIGN_DELIVERABLE_TYPES.includes(deliverable.type as typeof CAMPAIGN_DELIVERABLE_TYPES[number])) {
    return { ok: false, error: `Tipo de entregable inválido: ${deliverable.type}` }
  }
  if (deliverable.status === 'SENT_TO_CLIENT' || deliverable.status === 'CLIENT_APPROVED') {
    return { ok: false, error: 'El entregable ya fue enviado al cliente' }
  }

  try {
    await prisma.deliverable.update({
      where: { id: deliverableId },
      data: { status: 'SENT_TO_CLIENT' },
    })
    console.info('[campaign-actions] deliverable enviado al cliente', {
      deliverableId,
      orgId,
      type: deliverable.type,
    })
  } catch (err) {
    console.error('[campaign-actions] error al enviar deliverable:', err instanceof Error ? err.message : err)
    return { ok: false, error: 'No se pudo enviar el entregable. Intentá de nuevo.' }
  }

  revalidatePath(`/clientes/${orgId}`)
  return { ok: true }
}

/**
 * Dispara sincronización manual de métricas para una cuenta de ads.
 * Verifica que la cuenta pertenezca a la organización antes de sincronizar.
 */
export async function triggerAdAccountMetricsSync(
  adAccountId: string,
  orgId: string,
): Promise<SyncResult> {
  await requireAdminSession()

  if (!adAccountId?.trim()) {
    return { ok: false, platform: 'UNKNOWN', accountId: adAccountId, rowsUpserted: 0, error: 'adAccountId requerido' }
  }

  // Verificar que la cuenta existe (el admin session ya garantiza autorización)
  const exists = await prisma.adAccount.findUnique({
    where: { id: adAccountId },
    select: { id: true },
  })

  if (!exists) {
    return { ok: false, platform: 'UNKNOWN', accountId: adAccountId, rowsUpserted: 0, error: 'Cuenta no encontrada' }
  }

  const result = await syncMetrics(adAccountId)

  if (result.ok) {
    revalidatePath(`/clientes/${orgId}`)
  }

  return result
}
