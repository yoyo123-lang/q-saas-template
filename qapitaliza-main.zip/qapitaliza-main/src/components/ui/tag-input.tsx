'use client'

import { useRef, useState, KeyboardEvent } from 'react'
import { X } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

interface TagInputProps {
  value: string[]
  onChange: (tags: string[]) => void
  label?: string
  error?: string
  helper?: string
  placeholder?: string
  maxTags?: number
  maxLength?: number
  suggestions?: string[]
  className?: string
}

export function TagInput({
  value = [],
  onChange,
  label,
  error,
  helper,
  placeholder = 'Escribí y presioná Enter',
  maxTags = 10,
  maxLength = 30,
  suggestions = [],
  className,
}: TagInputProps) {
  const [input, setInput] = useState('')
  const [showSuggestions, setShowSuggestions] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const addTag = (tag: string) => {
    const trimmed = tag.trim()
    if (!trimmed || value.length >= maxTags || value.includes(trimmed)) return
    if (trimmed.length > maxLength) return
    onChange([...value, trimmed])
    setInput('')
    setShowSuggestions(false)
  }

  const removeTag = (tag: string) => {
    onChange(value.filter((t) => t !== tag))
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault()
      addTag(input)
    } else if (e.key === 'Backspace' && input === '' && value.length > 0) {
      onChange(value.slice(0, -1))
    }
  }

  const filteredSuggestions = suggestions.filter(
    (s) => s.toLowerCase().includes(input.toLowerCase()) && !value.includes(s)
  )

  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      {label && (
        <label className="text-sm font-medium text-slate-400 block">{label}</label>
      )}

      <div
        className={cn(
          'min-h-[42px] flex flex-wrap gap-1.5 p-2 bg-slate-800 border rounded-lg',
          'focus-within:ring-2 focus-within:ring-amber-500 focus-within:border-transparent',
          'transition-all duration-150 cursor-text',
          error ? 'border-red-500' : 'border-slate-800'
        )}
        onClick={() => inputRef.current?.focus()}
      >
        {value.map((tag) => (
          <span
            key={tag}
            className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-700 rounded-md text-xs text-slate-200 font-medium"
          >
            {tag}
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); removeTag(tag) }}
              className="text-slate-400 hover:text-slate-50 transition-colors"
              aria-label={`Eliminar ${tag}`}
            >
              <X className="size-3" />
            </button>
          </span>
        ))}

        {value.length < maxTags && (
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => {
              setInput(e.target.value)
              setShowSuggestions(suggestions.length > 0 && e.target.value.length > 0)
            }}
            onKeyDown={handleKeyDown}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
            placeholder={value.length === 0 ? placeholder : ''}
            className="flex-1 min-w-[120px] bg-transparent text-sm text-slate-50 placeholder:text-slate-500 outline-none"
          />
        )}
      </div>

      {showSuggestions && filteredSuggestions.length > 0 && (
        <div className="border border-slate-800 rounded-lg bg-navy-900 overflow-hidden shadow-xl">
          {filteredSuggestions.slice(0, 8).map((s) => (
            <button
              key={s}
              type="button"
              className="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-slate-50 transition-colors"
              onMouseDown={(e) => { e.preventDefault(); addTag(s) }}
            >
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="flex justify-between">
        {error ? (
          <span className="text-xs text-red-400">{error}</span>
        ) : helper ? (
          <span className="text-xs text-slate-500">{helper}</span>
        ) : <span />}
        <span className="text-xs text-slate-500">{value.length}/{maxTags}</span>
      </div>
    </div>
  )
}
