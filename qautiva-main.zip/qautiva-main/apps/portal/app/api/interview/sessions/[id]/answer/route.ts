import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma, Prisma } from '@qautiva/db'
import type { AnswerHistoryEntry } from '@/app/_lib/interview/types'
import { isAnswerEmpty } from '@/app/_lib/interview/merge-flow'
import {
  isCommercialLeadAnswer,
  buildCommercialLead,
  notifyCommercialLeadTelegram,
  type CommercialLead,
} from '@/app/_lib/interview/commercial-leads'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

type AnswerBody = {
  questionId: string
  answer: unknown
  answersVersion: number
}

/** Estados que permiten guardar respuestas */
const ANSWERABLE_STATUSES = ['NOT_STARTED', 'IN_PROGRESS', 'PAUSED'] as const

/**
 * PATCH /api/interview/sessions/[id]/answer
 * Guarda una respuesta con MERGE parcial y locking optimista.
 *
 * Locking optimista (CR2):
 * - Se valida la versión al leer (soft check para mensaje claro al usuario)
 * - Se incluye answersVersion en el WHERE del update (hard check atómico)
 * - Si el hard check falla (P2025), significa que otra pestaña actualizó entre
 *   nuestro read y nuestro write → se retorna 409 VERSION_CONFLICT
 *
 * Body: { questionId, answer, answersVersion }
 * Returns: { ok: true, session: { id, answers, answersVersion, currentStep, status } }
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  // CRÍTICO-SEC: validar que params.id sea un UUID v4 antes de usarlo en queries
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  let body: AnswerBody
  try {
    body = (await request.json()) as AnswerBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { questionId, answer, answersVersion } = body

  if (!questionId || typeof questionId !== 'string') {
    return NextResponse.json({ error: 'questionId es obligatorio' }, { status: 400 })
  }
  // Validar formato de questionId para prevenir inyección en JSON paths
  if (!/^[a-zA-Z0-9_-]{1,100}$/.test(questionId)) {
    return NextResponse.json({ error: 'questionId inválido' }, { status: 400 })
  }
  // CRÍTICO-QA: rechazar respuestas vacías (string vacío, array vacío, null/undefined)
  // para que el submit no acepte preguntas requeridas "respondidas" con valor vacío
  if (isAnswerEmpty(answer)) {
    return NextResponse.json({ error: 'answer no puede estar vacío' }, { status: 400 })
  }
  // Límite de tamaño del payload de answer para prevenir almacenamiento abusivo
  const answerSerialized = JSON.stringify(answer)
  if (answerSerialized.length > 50_000) {
    return NextResponse.json({ error: 'La respuesta supera el tamaño máximo permitido' }, { status: 413 })
  }
  if (
    typeof answersVersion !== 'number' ||
    !Number.isInteger(answersVersion) ||
    answersVersion < 0
  ) {
    return NextResponse.json(
      { error: 'answersVersion debe ser un entero no negativo' },
      { status: 400 },
    )
  }

  // Verificar ownership: usuario → team → sesión
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  // Busca sesión verificando ownership en una sola query
  const session = await prisma.interviewSession.findFirst({
    where: {
      id: params.id,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: {
      id: true,
      projectId: true,
      teamId: true,
      answers: true,
      answersVersion: true,
      answerHistory: true,
      flowDefinition: true,
      status: true,
      startedAt: true,
      importedData: true,
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Fail-closed: verificar teamId antes de cualquier guard (non-nullable en schema, pero defensivo)
  if (!session.teamId) {
    console.error('[answer] session sin teamId — error de datos, bloqueando ejecución', {
      sessionId: params.id,
    })
    return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
  }

  // Guard de permisos: MEMBER solo tiene lectura
  const perm = await checkTeamPermission(user.id, session.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden realizar esta acción.' },
      { status: 403 },
    )
  }

  if (!(ANSWERABLE_STATUSES as readonly string[]).includes(session.status)) {
    return NextResponse.json(
      { error: 'Acción no permitida en el estado actual de la sesión' },
      { status: 409 },
    )
  }

  // Validar que questionId existe en el flowDefinition (si el flujo está definido).
  // El flujo de DISCOVERY arranca vacío — en ese caso se omite la validación.
  const flow = (session.flowDefinition ?? []) as { id: string }[]
  if (flow.length > 0 && !flow.some((q) => q.id === questionId)) {
    return NextResponse.json({ error: 'Pregunta no encontrada en esta sesión' }, { status: 400 })
  }

  const currentAnswers = (session.answers ?? {}) as Record<string, unknown>
  const keyExists = questionId in currentAnswers
  const versionMismatch = session.answersVersion !== answersVersion

  // Soft check: rechazar solo si la misma key fue modificada en otra pestaña.
  // Previene conflictos obvios antes de llegar al DB.
  if (versionMismatch && keyExists) {
    return NextResponse.json(
      {
        error: 'Tus respuestas se actualizaron en otra pestaña. Recargando...',
        code: 'VERSION_CONFLICT',
        currentVersion: session.answersVersion,
      },
      { status: 409 },
    )
  }

  // Merge parcial: solo actualiza la key enviada
  const newAnswers = { ...currentAnswers, [questionId]: answer }

  // Registrar en historial si está sobreescribiendo una respuesta existente.
  // Cap de 100 entradas para prevenir crecimiento sin límite (descarta las más antiguas).
  const MAX_HISTORY_ENTRIES = 100
  const currentHistory = (session.answerHistory ?? []) as AnswerHistoryEntry[]
  let newHistory: AnswerHistoryEntry[] = currentHistory
  if (keyExists) {
    const entry: AnswerHistoryEntry = {
      questionId,
      oldValue: currentAnswers[questionId],
      newValue: answer,
      changedAt: new Date().toISOString(),
    }
    const appended = [...currentHistory, entry]
    newHistory = appended.length > MAX_HISTORY_ENTRIES
      ? appended.slice(appended.length - MAX_HISTORY_ENTRIES)
      : appended
  }

  // Auto-transición de estado
  const isFirstAnswer = session.status === 'NOT_STARTED'
  const isResuming = session.status === 'PAUSED'

  // Leads comerciales: detectar si esta respuesta genera un lead y
  // preparar los datos para incluirlos en el update atómico (sin race condition).
  let commercialLeadData: Prisma.InputJsonValue | undefined
  let newLeadService: CommercialLead | undefined

  if (isCommercialLeadAnswer(questionId, answer)) {
    const importedData = (session.importedData ?? {}) as Record<string, unknown>
    const existingLeads = (importedData.commercialLeads ?? []) as CommercialLead[]
    const updatedLeads = buildCommercialLead(questionId, existingLeads)

    if (updatedLeads) {
      newLeadService = updatedLeads[updatedLeads.length - 1]
      commercialLeadData = {
        ...importedData,
        commercialLeads: updatedLeads,
      } as Prisma.InputJsonValue
    }
  }

  let updated
  try {
    // CR2: Hard check atómico — answersVersion en WHERE garantiza que si otra pestaña
    // actualizó entre nuestro read y este write, el update falla con P2025 en lugar
    // de sobreescribir silenciosamente la respuesta del usuario.
    updated = await prisma.interviewSession.update({
      where: { id: params.id, answersVersion: answersVersion },
      data: {
        answers: newAnswers as Prisma.InputJsonValue,
        answersVersion: { increment: 1 },
        answerHistory: newHistory as unknown as Prisma.InputJsonValue,
        // Incluir lead comercial en el mismo update atómico (si aplica)
        ...(commercialLeadData ? { importedData: commercialLeadData } : {}),
        ...(isFirstAnswer
          ? { status: 'IN_PROGRESS', startedAt: new Date() }
          : isResuming
            ? { status: 'IN_PROGRESS' }
            : {}),
      },
      select: {
        id: true,
        answers: true,
        answersVersion: true,
        currentStep: true,
        status: true,
        startedAt: true,
      },
    })
  } catch (err) {
    // Hard check de versión falló: otra pestaña actualizó entre nuestro read y este write
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      return NextResponse.json(
        {
          error: 'Tus respuestas se actualizaron en otra pestaña. Recargando...',
          code: 'VERSION_CONFLICT',
        },
        { status: 409 },
      )
    }

    console.error('[interview/sessions/answer] update failed', {
      sessionId: params.id,
      questionId,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al guardar la respuesta' }, { status: 500 })
  }

  // Telegram notification (fire-and-forget, no bloquea la respuesta)
  if (newLeadService) {
    notifyCommercialLeadTelegram({
      service: newLeadService.service,
      label: newLeadService.label,
      projectId: session.projectId,
      sessionId: params.id,
    }).catch(() => {
      // Already logged inside notifyCommercialLeadTelegram
    })
  }

  return NextResponse.json({ ok: true, session: updated })
}
