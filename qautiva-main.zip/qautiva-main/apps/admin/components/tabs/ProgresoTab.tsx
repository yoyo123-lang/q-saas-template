import Link from 'next/link'
import { STAGE_STATUS_BADGE, DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL } from '@/lib/badges'
import type { OrgWithDetails, OrgStage, OrgDeliverable } from '@/lib/types'

// ── Sub-componentes ────────────────────────────────────────────────────────────

function DeliverableRow({ deliverable }: { deliverable: OrgDeliverable }) {
  const badge = DELIVERABLE_STATUS_BADGE[deliverable.status]
  return (
    <div className="flex items-start gap-3 py-2 px-3 rounded-lg bg-[#0A0F1A] border border-[#1E293B]">
      <div className="flex-1 min-w-0">
        <p className="text-white text-sm leading-snug">{deliverable.title}</p>
        <p className="text-[#64748B] text-xs mt-0.5">
          {DELIVERABLE_TYPE_LABEL[deliverable.type]} · v{deliverable.version}
        </p>
        {deliverable.feedback && (
          <p className="text-[#F87171] text-xs mt-1 italic">&ldquo;{deliverable.feedback}&rdquo;</p>
        )}
      </div>
      <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
        {badge.label}
      </span>
    </div>
  )
}

function StageCard({ stage, orgId }: { stage: OrgStage; orgId: string }) {
  const badge = STAGE_STATUS_BADGE[stage.status]
  const isAdminReview = stage.status === 'ADMIN_REVIEW'
  const isCompleted = stage.status === 'COMPLETED'

  return (
    <div
      className={`rounded-xl border p-4 ${
        isAdminReview
          ? 'border-[#F59E0B]/50 bg-[#F59E0B]/5'
          : isCompleted
            ? 'border-[#10B981]/30 bg-[#0F172A]'
            : 'border-[#1E293B] bg-[#0F172A]'
      }`}
    >
      {/* Encabezado de etapa */}
      <div className="flex items-center gap-3 mb-3">
        <span className="text-[#64748B] text-sm font-mono w-5 text-center">{stage.number}</span>
        <p className="text-white font-medium text-sm flex-1">{stage.name}</p>
        <span
          className={`
            px-2 py-0.5 rounded-full text-[10px] font-medium flex items-center gap-1
            ${badge.className}
          `}
        >
          {badge.pulse && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] animate-pulse" aria-hidden="true" />
          )}
          {badge.label}
        </span>
        {isAdminReview && (
          <Link
            href={`/revision?org=${orgId}&stage=${stage.id}`}
            className="px-3 py-1 rounded-lg bg-[#F59E0B]/15 text-[#FBBF24] text-xs font-medium border border-[#F59E0B]/30 hover:bg-[#F59E0B]/25 transition-colors"
          >
            Revisar
          </Link>
        )}
      </div>

      {/* Aprobaciones */}
      <div className="flex gap-3 mb-3 text-[11px]">
        <span className={stage.adminApproved ? 'text-[#34D399]' : 'text-[#64748B]'}>
          {stage.adminApproved ? '✓' : '○'} Admin aprobó
        </span>
        <span className={stage.clientApproved ? 'text-[#34D399]' : 'text-[#64748B]'}>
          {stage.clientApproved ? '✓' : '○'} Cliente aprobó
        </span>
      </div>

      {/* Entregables */}
      {stage.deliverables.length > 0 ? (
        <div className="flex flex-col gap-1.5">
          {stage.deliverables.map((d) => (
            <DeliverableRow key={d.id} deliverable={d} />
          ))}
        </div>
      ) : (
        <p className="text-[#475569] text-xs">Sin entregables aún.</p>
      )}
    </div>
  )
}

// ── Tab principal ──────────────────────────────────────────────────────────────

interface ProgresoTabProps {
  stages: OrgWithDetails['stages']
  orgId: string
}

export function ProgresoTab({ stages, orgId }: ProgresoTabProps) {
  if (stages.length === 0) {
    return (
      <p className="text-[#64748B] text-sm">No hay etapas registradas para este cliente.</p>
    )
  }

  return (
    <div className="flex flex-col gap-3 overflow-y-auto flex-1 pb-4">
      {stages.map((stage) => (
        <StageCard key={stage.id} stage={stage} orgId={orgId} />
      ))}
    </div>
  )
}
