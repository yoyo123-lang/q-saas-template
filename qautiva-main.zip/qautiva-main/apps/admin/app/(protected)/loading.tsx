// Skeleton mostrado por Next.js mientras el dashboard async Server Component carga.
// Se activa automáticamente en navegaciones y cambios de filtros.

function SkeletonBlock({ className }: { className?: string }) {
  return (
    <div className={`bg-[#1E293B] rounded-lg animate-pulse ${className ?? ''}`} />
  )
}

export default function DashboardLoading() {
  return (
    <div className="flex flex-col h-full p-6 gap-5">
      {/* Encabezado */}
      <div className="flex flex-col gap-1.5">
        <SkeletonBlock className="h-8 w-36" />
        <SkeletonBlock className="h-4 w-64" />
      </div>

      {/* Métricas — 5 cards */}
      <div className="flex flex-wrap gap-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <SkeletonBlock key={i} className="h-[68px] flex-1 min-w-[140px]" />
        ))}
      </div>

      {/* Filtros */}
      <div className="flex gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <SkeletonBlock key={i} className="h-9 w-28 rounded-lg" />
        ))}
      </div>

      {/* Columnas Kanban */}
      <div className="flex gap-3 overflow-x-auto pb-4 flex-1">
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} className="flex flex-col flex-shrink-0 w-[220px] gap-2">
            <SkeletonBlock className="h-9 w-full rounded-lg" />
            {Array.from({ length: i % 3 === 0 ? 2 : i % 3 === 1 ? 3 : 1 }).map((_, j) => (
              <SkeletonBlock key={j} className="h-24 w-full rounded-lg" />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
