'use client'

import { useState, useEffect, useRef } from 'react'
import { createSupabaseBrowserClient } from '@/lib/supabase-browser'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { X, Send } from 'lucide-react'

type MessageSender = 'CLIENT' | 'AI' | 'ADMIN'

type Message = {
  id: string
  content: string
  sender: MessageSender
  createdAt: string
}

type ChatPanelProps = {
  onClose: () => void
  /** Si se provee, el chat se asocia al proyecto (self-service). Si no, usa org_id del JWT (legacy). */
  projectId?: string
}

function MessageBubble({ message }: { message: Message }) {
  const isClient = message.sender === 'CLIENT'
  const time = new Date(message.createdAt).toLocaleTimeString('es-AR', {
    hour: '2-digit',
    minute: '2-digit',
  })

  return (
    <div className={`flex gap-2 ${isClient ? 'justify-end' : 'justify-start'}`}>
      {!isClient && (
        <div className="w-7 h-7 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/30 flex items-center justify-center flex-shrink-0 mt-1">
          <span className="text-[#A78BFA] text-xs font-bold">Q</span>
        </div>
      )}
      <div className="max-w-[75%]">
        {!isClient && (
          <p className="text-[#64748B] text-[10px] mb-1 ml-1">
            {message.sender === 'ADMIN' ? 'Equipo Qautiva' : 'Qautiva AI'}
          </p>
        )}
        <div
          className={`
            px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed
            ${isClient
              ? 'bg-[#1E293B] text-white rounded-br-sm'
              : 'bg-[#0F172A] border border-[#1E293B] text-[#F8FAFC] rounded-bl-sm'
            }
          `}
        >
          {message.content}
        </div>
        <p className={`text-[#64748B] text-[10px] mt-1 ${isClient ? 'text-right mr-1' : 'ml-1'}`}>
          {time}
        </p>
      </div>
    </div>
  )
}

/**
 * Panel de chat flotante (400px, fixed derecha) con el equipo de Qautiva.
 * Carga el historial de los últimos 50 mensajes de la org al montar.
 * Se suscribe a Supabase Realtime (postgres_changes INSERT en Message) para recibir
 * respuestas en tiempo real sin polling. El envío usa optimistic UI con deduplicación
 * por ID para no duplicar el mensaje cuando llega el INSERT de Realtime.
 * Usa supabase-browser.ts (NO @qautiva/db que tiene server-only guard).
 */
export function ChatPanel({ onClose, projectId }: ChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  // contextId es el ID que se usa para filtrar mensajes: orgId (legacy) o projectId (self-service)
  const [contextId, setContextId] = useState<string | null>(projectId ?? null)
  const [isSending, setIsSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const bottomRef = useRef<HTMLDivElement>(null)
  const channelRef = useRef<RealtimeChannel | null>(null)
  const supabaseRef = useRef(createSupabaseBrowserClient())

  // Cargar historial y suscribir a Realtime
  useEffect(() => {
    const supabase = supabaseRef.current
    let isMounted = true

    async function init() {
      // Si ya tenemos projectId, lo usamos directamente sin consultar el JWT
      let cid = projectId
      let filterField = 'projectId'

      if (!cid) {
        // Legacy: obtener org_id del JWT
        const { data: { user } } = await supabase.auth.getUser()
        const oid = user?.app_metadata?.org_id as string | undefined
        if (!oid) { if (isMounted) setLoading(false); return }
        cid = oid
        filterField = 'organizationId'
      }

      if (!isMounted) return

      setContextId(cid)

      // Cargar últimos 50 mensajes (order desc + reverse para mostrar cronológico)
      const { data, error: historialError } = await supabase
        .from('Message')
        .select('id, content, sender, createdAt')
        .eq(filterField, cid)
        .order('createdAt', { ascending: false })
        .limit(50)

      if (!isMounted) return

      if (historialError) {
        setError('No se pudo cargar el historial. Intentá recargar la página.')
      } else {
        setMessages(((data as Message[]) ?? []).reverse())
      }
      setLoading(false)

      // Suscribir a mensajes nuevos via Realtime
      const channel = supabase
        .channel(`messages:${cid}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'Message',
            filter: `${filterField}=eq.${cid}`,
          },
          (payload) => {
            // Validar que el payload tiene la estructura esperada antes de usarlo
            const raw = payload.new
            if (
              !raw || typeof raw !== 'object' ||
              typeof (raw as Record<string, unknown>).id !== 'string' ||
              typeof (raw as Record<string, unknown>).content !== 'string' ||
              typeof (raw as Record<string, unknown>).sender !== 'string' ||
              typeof (raw as Record<string, unknown>).createdAt !== 'string'
            ) return

            const msg = raw as Message
            setMessages((prev) => {
              // Evitar duplicados (el mensaje real ya reemplazó el optimista por ID)
              if (prev.some((m) => m.id === msg.id)) return prev
              return [...prev, msg]
            })
          },
        )
        .subscribe()

      if (!isMounted) {
        void supabase.removeChannel(channel)
        return
      }
      channelRef.current = channel
    }

    void init()

    return () => {
      isMounted = false
      if (channelRef.current) {
        void supabase.removeChannel(channelRef.current)
        channelRef.current = null
      }
    }
  // projectId no cambia durante el ciclo de vida del panel
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Scroll al último mensaje
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  function handleSend() {
    const content = input.trim()
    if (!content || !contextId) return
    setInput('')
    setError(null)

    // Agregar mensaje optimistamente
    const tempId = `temp-${Date.now()}`
    const tempMessage: Message = {
      id: tempId,
      content,
      sender: 'CLIENT',
      createdAt: new Date().toISOString(),
    }
    setMessages((prev) => [...prev, tempMessage])

    // Si tenemos projectId, incluirlo en el body para la ruta self-service
    const messageBody = projectId ? { content, projectId } : { content }

    setIsSending(true)
    fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(messageBody),
    })
      .then(async (res) => {
        const data = await res.json() as { error?: string; message?: Message }
        if (!res.ok) {
          setError(data.error ?? 'No se pudo enviar el mensaje.')
          setMessages((prev) => prev.filter((m) => m.id !== tempId))
          return
        }
        // Reemplazar el mensaje temporal con el real para que la deduplicación
        // de Realtime funcione correctamente (compara por ID)
        if (data.message) {
          setMessages((prev) => prev.map((m) => m.id === tempId ? data.message! : m))
        }
      })
      .catch(() => {
        setError('Error de red. Revisá tu conexión.')
        setMessages((prev) => prev.filter((m) => m.id !== tempId))
      })
      .finally(() => { setIsSending(false) })
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div
      className="fixed right-0 top-0 bottom-0 w-full max-w-[400px] bg-[#0B0F1A] border-l border-[#1E293B] flex flex-col z-50 shadow-2xl"
      role="dialog"
      aria-label="Chat con Qautiva"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E293B]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/30 flex items-center justify-center">
            <span className="text-[#A78BFA] text-sm font-bold">Q</span>
          </div>
          <div>
            <p className="text-white text-sm font-semibold">Qautiva</p>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#10B981]" aria-hidden="true" />
              <p className="text-[#10B981] text-xs">En línea</p>
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="text-[#64748B] hover:text-white transition-colors duration-200"
          aria-label="Cerrar chat"
        >
          <X size={18} aria-hidden="true" />
        </button>
      </div>

      {/* Mensajes */}
      <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3">
        {loading && (
          <p className="text-[#64748B] text-sm text-center mt-8">Cargando mensajes...</p>
        )}

        {!loading && messages.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center px-4">
            <div className="w-12 h-12 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 flex items-center justify-center">
              <span className="text-[#A78BFA] text-xl font-bold">Q</span>
            </div>
            <div>
              <p className="text-white font-medium text-sm">¡Hola! Soy el asistente de Qautiva.</p>
              <p className="text-[#64748B] text-xs mt-1">Escribime cualquier pregunta sobre tu proyecto.</p>
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {error && (
          <p className="text-[#EF4444] text-xs text-center">{error}</p>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-4 pb-4 pt-3 border-t border-[#1E293B]">
        <div className="flex gap-2 items-end">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Escribí tu mensaje..."
            rows={1}
            maxLength={2000}
            className="flex-1 bg-[#1E293B] border border-[#1E293B] focus:border-[#8B5CF6] rounded-xl px-3.5 py-2.5 text-white text-sm placeholder-[#64748B] resize-none outline-none transition-colors duration-200 max-h-[120px]"
            style={{ fieldSizing: 'content' } as React.CSSProperties}
            aria-label="Escribir mensaje"
          />
          <button
            type="button"
            onClick={handleSend}
            disabled={isSending || input.trim().length === 0}
            className="flex-shrink-0 w-9 h-9 rounded-xl bg-[#8B5CF6] hover:bg-[#A78BFA] text-white flex items-center justify-center transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Enviar mensaje"
          >
            <Send size={16} aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  )
}
