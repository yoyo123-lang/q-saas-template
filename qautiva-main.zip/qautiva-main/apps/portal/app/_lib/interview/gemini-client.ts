import { GoogleGenerativeAI } from '@google/generative-ai'

let _geminiClient: GoogleGenerativeAI | null = null

/**
 * Singleton del cliente Gemini (Google Generative AI).
 * Sólo configura el transporte (API key). Toda lógica de negocio,
 * timeouts individuales (AbortController 30s) y validación de imágenes
 * viven en brand-generator.ts — ver ADR-0017.
 */
export function getGeminiClient(): GoogleGenerativeAI {
  if (!_geminiClient) {
    const apiKey = process.env['GOOGLE_GEMINI_API_KEY']
    if (!apiKey) {
      throw new Error('[gemini-client] GOOGLE_GEMINI_API_KEY no está configurada')
    }
    _geminiClient = new GoogleGenerativeAI(apiKey)
  }
  return _geminiClient
}
