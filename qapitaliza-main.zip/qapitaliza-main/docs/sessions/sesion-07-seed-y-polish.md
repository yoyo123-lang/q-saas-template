# Sesión 07 — Seed, Polish y Deploy

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 06 — Panel admin completo con moderación, gestión de usuarios y analytics.

Esta es la sesión final. Objetivo: dejar el MVP listo para producción. Cubre el seed de datos reales, los estados de UI faltantes, responsive, tests E2E y deploy a Vercel.

Leer antes de empezar:
- `PLAN.md` — Etapa 8
- `docs/frontend/06-auth-y-formularios.md` — §7 (breakpoints responsive)
- `docs/frontend/02-componentes-base.md` — §13 (estados obligatorios)
- `docs/PRE_DEPLOY_AND_QA.md` — checklist de pre-deploy

## Estado actual

La app tiene todas las funcionalidades implementadas. Esta sesión es de consolidación y calidad.

## Tarea de esta sesión

### BLOQUE A — Auditoría de botones y placeholders

Recorrer TODAS las páginas y verificar que **ningún botón queda sin acción real**. Lista de verificación:

**Páginas públicas:**
- [ ] "Explorar" en navbar → `/explorar` ✓
- [ ] "Cómo funciona" en navbar → `/como-funciona` ✓
- [ ] Barra de búsqueda hero → navega a `/explorar?q=` ✓
- [ ] CategoryPill × 5 → `/explorar?category=` ✓
- [ ] "Ver todos →" en activos destacados → `/explorar` ✓
- [ ] "Publicá gratis" en CTA → `/registro?rol=seller` ✓
- [ ] Links del Footer (Explorar, Cómo funciona, Términos, Privacidad) → rutas correctas
- [ ] "♡ Guardar" en ListingCard → toggle favorito o redirect login ✓
- [ ] "Consultar" en ListingCard → redirect a detalle o login
- [ ] "Consultar al vendedor" en detalle → crear consulta o login ✓
- [ ] "♡ Guardar en favoritos" en detalle → toggle favorito o login ✓
- [ ] "Ver perfil" del vendedor en detalle → `/admin/usuarios/{id}` (solo admin) o placeholder
- [ ] Activos relacionados — cada card clickeable → `/explorar/{slug}`

**Auth:**
- [ ] "Continuar con Google" → OAuth flow ✓
- [ ] "¿Olvidaste tu contraseña?" → `/recuperar` ✓
- [ ] "Registrate" en login → `/registro` ✓
- [ ] "Iniciá sesión" en registro → `/login` ✓
- [ ] Checkbox términos con links → `/terminos` y `/privacidad` (crear páginas mínimas si no existen)

**Dashboard vendedor:**
- [ ] Todos los items del sidebar → rutas correctas ✓
- [ ] Botón logout → `signOut()` y redirect a `/`
- [ ] "Nuevo listado" en sidebar → `/mis-activos/nuevo` ✓
- [ ] Todos los tabs en `/mis-activos` → filtran correctamente ✓
- [ ] Menú ⋯ en tabla: Editar → editar, Ver página → abrir en nueva tab, Pausar → pausar, Eliminar → modal + eliminar ✓
- [ ] Todos los pasos del wizard avanzan y retroceden correctamente ✓
- [ ] "Guardar borrador" y "Enviar a revisión" en wizard ✓
- [ ] Tabs en edición → muestran el formulario correcto ✓
- [ ] Botones en sidebar de edición (Pausar, Marcar vendido, Eliminar) ✓

**Dashboard comprador:**
- [ ] "♥ Guardado" en favoritos → desfavoritar con animación ✓
- [ ] Tabs en `/consultas` → filtran correctamente ✓
- [ ] Click en InquiryCard → navega a `/consultas/{id}` ✓
- [ ] Enter en textarea del chat → enviar ✓
- [ ] "Cerrar consulta" → modal + cierre ✓

**Admin:**
- [ ] Selector de período → cambia datos del dashboard ✓
- [ ] "Revisar" en tabla de pendientes → `/admin/listados/{id}` ✓
- [ ] Selección masiva + "Aprobar todos" / "Rechazar todos" ✓
- [ ] Slide-in panel "Aprobar y publicar" ✓
- [ ] Slide-in panel "Rechazar" con motivo mínimo 20 chars ✓
- [ ] Menú ⋯ en usuarios: todas las opciones funcionales ✓

Para cada ítem que no está completo: implementarlo ahora.

---

### BLOQUE B — Páginas mínimas faltantes

Crear páginas básicas que eviten 404:

`src/app/(public)/terminos/page.tsx` — texto genérico de términos y condiciones.
`src/app/(public)/privacidad/page.tsx` — texto genérico de política de privacidad.
`src/app/not-found.tsx` — página 404 custom con el design system, botón "Volver al inicio".
`src/app/error.tsx` — página de error global con botón "Reintentar".

---

### BLOQUE C — Estados de UI faltantes

Auditar cada página y completar los 4 estados obligatorios:

**Loading states:**
- Catálogo `/explorar`: mientras carga → `<SkeletonCard />` × 6 en grid
- Dashboard: mientras carga stats → skeletons de StatCard
- Chat: mientras carga mensajes → skeletons de mensaje
- Tablas admin: `<Skeleton />` de filas

**Empty states:**
- `/favoritos` sin favoritos ✓
- `/mis-activos` sin activos ✓
- `/consultas` sin consultas ✓
- `/explorar` sin resultados con los filtros actuales ✓
- Dashboard admin sin listados pendientes

**Error states:**
- Catálogo: error de fetch → `<ErrorState message="No pudimos cargar los activos" retry />` con botón "Reintentar"
- Detalle de activo no encontrado → redirect a `/not-found` o mostrar 404
- Chat: error al enviar mensaje → revertir optimistic update + `toast.error`

**Success states:**
- Guardar cambios en perfil → `toast.success("Cambios guardados")`
- Publicar listado → `toast.success("Listado enviado a revisión. Te avisamos cuando sea aprobado.")`
- Aprobar listado (admin) → `toast.success("Listado publicado")`
- Rechazar listado (admin) → `toast.success("Listado rechazado")`
- Enviar mensaje → el mensaje aparece (optimistic) ✓

---

### BLOQUE D — Responsive

Implementar breakpoints según `docs/frontend/06-auth-y-formularios.md` §7:

**`md` (768px):**
- Layout auth: ocultar columna decorativa, mostrar solo formulario (`hidden md:block` en columna izq)
- Sidebar: pasar a drawer lateral. Agregar botón hamburguesa en navbar del dashboard. Estado abierto/cerrado con overlay negro.

**`lg` (1024px):**
- Catálogo: 3 columnas → 2 columnas (`grid-cols-1 md:grid-cols-2 xl:grid-cols-3`)
- FilterSidebar: en mobile se colapsa detrás de un botón "Filtros" (drawer o accordion)

**`xl` (1280px):**
- StatCards: `grid-cols-2 xl:grid-cols-4`
- Sidebar visible `hidden xl:block` (en desktop siempre visible)

**Grids estándar aplicar en todas las páginas:**
```tsx
// ListingCards
<div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
// StatCards
<div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
// Favoritos
<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
```

---

### BLOQUE E — Seed de datos de producción

`prisma/seed.ts` — seed completo de ~50 activos reales de Federico.

Si los datos de Federico no están disponibles, crear seed con 20 activos de ejemplo representativos con:
- Datos verosímiles (precios reales de mercado, métricas coherentes)
- Variedad de tipos (WEBSITE, DOMAIN, SAAS, ECOMMERCE, PROJECT)
- Mix de estados (la mayoría PUBLISHED, algunos FEATURED)
- Screenshots placeholder de Supabase Storage o URLs públicas
- Al menos 2 usuarios vendedor (para probar el marketplace) + 1 usuario admin

```bash
npx prisma db seed
```

---

### BLOQUE F — Tests E2E

Instalar Playwright:
```bash
npm install -D @playwright/test
npx playwright install
```

Crear `e2e/` en la raíz. Flujos críticos a cubrir:

**`e2e/01-registro-y-login.spec.ts`:**
- Registro con email → verificar redirect a dashboard con banner de verificación
- Login con email → verificar redirect a dashboard
- Login con credenciales incorrectas → verificar mensaje de error

**`e2e/02-catalogo.spec.ts`:**
- Landing → click "Explorar" → catálogo visible con activos
- Aplicar filtro de categoría → resultados filtrados
- Click en activo → página de detalle con título, precio, métricas

**`e2e/03-crear-listado.spec.ts`:**
- Login como vendedor → ir a "Nuevo listado"
- Completar los 4 pasos del wizard
- "Enviar a revisión" → redirige a `/mis-activos` con toast de éxito
- El activo aparece con estado "En revisión"

**`e2e/04-flujo-consulta.spec.ts`:**
- Login como comprador → ir a detalle de activo publicado
- Click "Consultar al vendedor" → crea consulta, redirige a chat
- Escribir mensaje → aparece en el thread
- Login como vendedor (nueva pestaña) → ver la consulta, responder

**`e2e/05-admin-moderacion.spec.ts`:**
- Login como admin → ir a `/admin/listados`
- Aprobar el listado de la Sesión 03 → estado cambia a "Publicado"
- Verificar que aparece en el catálogo público

---

### BLOQUE G — Verificación pre-deploy

Seguir `docs/PRE_DEPLOY_AND_QA.md`. Checklist:

```bash
npm run build          # debe pasar sin errores ni warnings
npm run lint           # 0 errores
npx tsc --noEmit       # 0 errores de TypeScript
```

Verificar en el build output:
- Todas las rutas dinámicas tienen sus params tipados
- No hay `any` implicitos
- No hay `console.log` en código de producción

Verificar headers de seguridad en respuesta del servidor:
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy` presente

---

### BLOQUE H — Deploy a Vercel

1. Crear proyecto en Vercel conectado al repo
2. Configurar variables de entorno en Vercel (todas las del `.env.example`)
3. Configurar dominio custom si está disponible
4. Verificar que el build de producción funciona
5. Probar el flujo completo en producción: registro → publicar activo → consultar → responder
6. Verificar que las migraciones SQL están aplicadas en la DB de producción (Supabase)

---

## Reglas

- No hacer deploy hasta que `npm run build` pase limpio
- El seed de producción solo se ejecuta una vez — verificar que no hay datos duplicados
- Los tests E2E se corren contra la versión local antes del deploy

## Checkpoint

La sesión está completa cuando:
- [ ] Auditoría de botones completada — ningún placeholder en la app
- [ ] Páginas 404, error, términos y privacidad existen
- [ ] Loading/empty/error states en todas las páginas críticas
- [ ] Responsive funciona en 768px, 1024px y 1280px
- [ ] Seed ejecutado — catálogo con al menos 20 activos reales
- [ ] Tests E2E de los 5 flujos pasan
- [ ] `npm run build` limpio
- [ ] Deploy a Vercel exitoso
- [ ] Flujo completo funciona en producción
