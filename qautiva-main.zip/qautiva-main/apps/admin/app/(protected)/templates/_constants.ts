export const DEFAULT_SECTIONS: Record<string, boolean> = {
  hero: true,
  services: false,
  about: false,
  contact: false,
  gallery: false,
  testimonials: false,
  map: false,
  pricing: false,
  booking: false,
  payments: false,
  careers: false,
  blog: false,
}

export const SECTION_LABELS: Record<string, string> = {
  hero: 'Hero con CTA (obligatorio)',
  services: 'Servicios / Menú',
  about: 'Sobre nosotros',
  contact: 'Contacto / WhatsApp',
  gallery: 'Galería de fotos',
  testimonials: 'Testimonios',
  map: 'Ubicación / Mapa',
  pricing: 'Precios',
  booking: 'Reserva de turnos (Qontacta)',
  payments: 'Pagos online (Qobra)',
  careers: 'Portal de empleo (Qontrata)',
  blog: 'Blog',
}
