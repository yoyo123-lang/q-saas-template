/**
 * Seed script — Sesión 07 (actualizado)
 * Creates test profiles and 20 sample listings covering all types and status variants.
 * Run with: npx tsx prisma/seed.ts
 * Safe to re-run — listings are upserted by slug, profiles by id.
 */

import { PrismaClient, ListingType, ListingStatus, VerificationStatus } from '@prisma/client'

const prisma = new PrismaClient()

const SELLER_A_ID = '00000000-0000-0000-0000-000000000001'
const SELLER_B_ID = '00000000-0000-0000-0000-000000000002'
const ADMIN_ID = '00000000-0000-0000-0000-000000000099'

const FEATURED_UNTIL = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)

const listings: Array<{
  sellerId: string
  title: string
  slug: string
  description: string
  type: ListingType
  askingPrice: number
  monthlyRevenue: number | null
  monthlyTraffic: number | null
  domainAge: number | null
  techStack: string[]
  tags: string[]
  screenshotUrls: string[]
  verificationStatus: VerificationStatus
  featuredUntil: Date | null
  viewCount: number
}> = [
  // ── WEBSITES ──────────────────────────────────────────────────────────────
  {
    sellerId: SELLER_A_ID,
    title: 'Blog de finanzas personales — 40k visitas/mes',
    slug: 'blog-finanzas-personales-40k',
    description:
      'Blog establecido sobre finanzas personales en español. Monetizado con AdSense y afiliados de brokers. Audiencia fiel de clase media argentina. Dominio 5 años, DA 28, 40k visitas orgánicas mensuales. Facturación estable.',
    type: ListingType.WEBSITE,
    askingPrice: 12000,
    monthlyRevenue: 800,
    monthlyTraffic: 40000,
    domainAge: 60,
    techStack: ['WordPress', 'Google AdSense', 'Google Analytics'],
    tags: ['finanzas', 'blog', 'argentina', 'seo'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.VERIFIED,
    featuredUntil: FEATURED_UNTIL,
    viewCount: 412,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'Newsletter de tecnología — 8.000 suscriptores activos',
    slug: 'newsletter-tecnologia-8000-suscriptores',
    description:
      'Newsletter semanal sobre tech y startups con 8.000 suscriptores activos. Tasa de apertura del 38%. Monetizado con sponsors (2 sponsors fijos x $600 USD/mes). Lista segmentada por perfil profesional.',
    type: ListingType.WEBSITE,
    askingPrice: 15000,
    monthlyRevenue: 1200,
    monthlyTraffic: 12000,
    domainAge: 36,
    techStack: ['Ghost', 'Mailchimp', 'Stripe'],
    tags: ['newsletter', 'tech', 'b2b', 'sponsors'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.VERIFIED,
    featuredUntil: FEATURED_UNTIL,
    viewCount: 289,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'Directorio de restaurantes CABA con SEO orgánico',
    slug: 'directorio-restaurantes-caba-seo',
    description:
      'Directorio de restaurantes de Buenos Aires con 25k visitas mensuales orgánicas. Monetizado con listados premium ($30 USD/mes por restaurante). 20 restaurantes pagos activos. Cero dependencia de ads.',
    type: ListingType.WEBSITE,
    askingPrice: 9000,
    monthlyRevenue: 600,
    monthlyTraffic: 25000,
    domainAge: 48,
    techStack: ['WordPress', 'Yoast SEO', 'WooCommerce'],
    tags: ['directorio', 'local', 'seo', 'caba'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 178,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'Portal de empleos tech LATAM — 15k visitas/mes',
    slug: 'portal-empleos-tech-latam',
    description:
      'Portal de búsqueda de empleo tech en LATAM con 15k visitas mensuales. 3 años online. Monetizado con posteos premium de empresas ($150 USD/aviso). Promedio 8 avisos pagos/mes. Base de datos de 2.000 CVs.',
    type: ListingType.WEBSITE,
    askingPrice: 18000,
    monthlyRevenue: 1200,
    monthlyTraffic: 15000,
    domainAge: 36,
    techStack: ['Next.js', 'PostgreSQL', 'Stripe'],
    tags: ['empleo', 'tech', 'latam', 'b2b'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 203,
  },

  // ── SAAS ──────────────────────────────────────────────────────────────────
  {
    sellerId: SELLER_A_ID,
    title: 'SaaS de gestión de turnos para clínicas',
    slug: 'saas-gestion-turnos-clinicas',
    description:
      'Plataforma SaaS con 35 clínicas activas. Facturación recurrente mensual de $2.800 USD. Churn < 3% mensual. Tech stack moderno, código bien documentado con tests. Integración con WhatsApp para recordatorios.',
    type: ListingType.SAAS,
    askingPrice: 45000,
    monthlyRevenue: 2800,
    monthlyTraffic: 8000,
    domainAge: null,
    techStack: ['Next.js', 'Supabase', 'Stripe', 'Tailwind CSS'],
    tags: ['saas', 'salud', 'b2b', 'turnos'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.VERIFIED,
    featuredUntil: FEATURED_UNTIL,
    viewCount: 534,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'SaaS de facturación electrónica AFIP — 80 clientes',
    slug: 'saas-facturacion-electronica-pymes',
    description:
      'Integración con AFIP para generar facturas electrónicas (tipos A, B, C). 80 clientes activos pymes. Precio promedio $26 USD/mes. Alto potencial de escala en LATAM (AFIP + Colombia DIAN en roadmap).',
    type: ListingType.SAAS,
    askingPrice: 35000,
    monthlyRevenue: 2100,
    monthlyTraffic: 5000,
    domainAge: null,
    techStack: ['Next.js', 'Prisma', 'Stripe', 'Node.js'],
    tags: ['saas', 'facturación', 'afip', 'pymes'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.VERIFIED,
    featuredUntil: null,
    viewCount: 321,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'App de seguimiento de hábitos — 2.000 usuarios activos',
    slug: 'app-seguimiento-habitos-2000-usuarios',
    description:
      'Aplicación web de tracking de hábitos con 2.000 usuarios activos mensuales. Plan freemium con 120 usuarios pagos ($8 USD/mes). Roadmap activo. Stack liviano, fácil de mantener.',
    type: ListingType.SAAS,
    askingPrice: 18000,
    monthlyRevenue: 960,
    monthlyTraffic: 6000,
    domainAge: null,
    techStack: ['Vue.js', 'Laravel', 'MySQL', 'Stripe'],
    tags: ['saas', 'productividad', 'freemium', 'habitos'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 156,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'Herramienta de reportes SEO para agencias',
    slug: 'herramienta-reportes-seo-agencias',
    description:
      'SaaS que automatiza la generación de reportes SEO en PDF white-label para agencias. 22 agencias activas. Precio $49 USD/mes por agencia. Integra con Google Search Console y Ahrefs API.',
    type: ListingType.SAAS,
    askingPrice: 28000,
    monthlyRevenue: 1078,
    monthlyTraffic: 3500,
    domainAge: null,
    techStack: ['React', 'Node.js', 'PostgreSQL', 'Puppeteer'],
    tags: ['saas', 'seo', 'agencias', 'reportes'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 94,
  },

  // ── ECOMMERCE ─────────────────────────────────────────────────────────────
  {
    sellerId: SELLER_A_ID,
    title: 'Tienda de ropa sustentable — 120 órdenes/mes',
    slug: 'tienda-ropa-sustentable-120-ordenes',
    description:
      'E-commerce de indumentaria sustentable con marca establecida. 120 órdenes mensuales promedio. Ticket promedio $29 USD. Proveedor directo con exclusividad regional. Redes sociales con 12k seguidores.',
    type: ListingType.ECOMMERCE,
    askingPrice: 22000,
    monthlyRevenue: 3500,
    monthlyTraffic: 15000,
    domainAge: 24,
    techStack: ['Shopify', 'Meta Ads', 'Klaviyo'],
    tags: ['ecommerce', 'moda', 'sustentable', 'shopify'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: FEATURED_UNTIL,
    viewCount: 267,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'Tienda dropshipping electrónica — 60 órdenes/mes',
    slug: 'tienda-dropshipping-electronica-automatizada',
    description:
      'Tienda e-commerce de electrónica con dropshipping automatizado. 60 órdenes mensuales. Operación casi hands-free con DSers. Margen neto 22%. Google Ads rentable con ROAS 3.2x.',
    type: ListingType.ECOMMERCE,
    askingPrice: 11000,
    monthlyRevenue: 1800,
    monthlyTraffic: 9000,
    domainAge: 18,
    techStack: ['Shopify', 'DSers', 'Google Ads'],
    tags: ['ecommerce', 'dropshipping', 'electronica', 'automatizado'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 189,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'Tienda de suplementos deportivos — suscripción mensual',
    slug: 'tienda-suplementos-deportivos-suscripcion',
    description:
      'E-commerce de suplementos deportivos con modelo de suscripción mensual. 85 suscriptores activos a $45 USD/mes. LTV alto. Fórmula propia, certificada. Proveedor establecido con contrato.',
    type: ListingType.ECOMMERCE,
    askingPrice: 32000,
    monthlyRevenue: 3825,
    monthlyTraffic: 7500,
    domainAge: 30,
    techStack: ['WooCommerce', 'Stripe', 'Mailchimp'],
    tags: ['ecommerce', 'suplementos', 'suscripcion', 'salud'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.VERIFIED,
    featuredUntil: null,
    viewCount: 143,
  },

  // ── DOMAIN ────────────────────────────────────────────────────────────────
  {
    sellerId: SELLER_A_ID,
    title: 'Dominio premium: inversion.com.ar',
    slug: 'dominio-inversioncomAr',
    description:
      'Dominio de alto valor en el nicho de inversiones. Ideal para fintech, broker o plataforma de activos. Registrado hace 8 años. DA 12 con algunos backlinks naturales.',
    type: ListingType.DOMAIN,
    askingPrice: 3500,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: 96,
    techStack: [],
    tags: ['dominio', 'fintech', 'inversiones', 'premium'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 88,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'Dominio brandable: TechLab.app',
    slug: 'dominio-brandable-techlab-app',
    description:
      'Dominio brandable de 2 palabras en extensión .app. Perfecto para SaaS, herramienta developer o producto tech. Corto, memorable, fácil de pronunciar en inglés y español.',
    type: ListingType.DOMAIN,
    askingPrice: 2800,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: 24,
    techStack: [],
    tags: ['dominio', 'brandable', 'app', 'tech'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 61,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'Portafolio de 5 dominios .com.ar nicho finanzas',
    slug: 'portfolio-dominios-comAr-finanzas',
    description:
      'Pack de 5 dominios .com.ar relacionados con finanzas personales, inversiones y ahorro. Venta en conjunto. Incluye: ahorroya.com.ar, invertirya.com.ar, finanzasya.com.ar y 2 más.',
    type: ListingType.DOMAIN,
    askingPrice: 4200,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: 72,
    techStack: [],
    tags: ['dominio', 'portafolio', 'finanzas', 'argentina'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 47,
  },

  // ── PROJECT / MVP ─────────────────────────────────────────────────────────
  {
    sellerId: SELLER_B_ID,
    title: 'MVP de marketplace de servicios freelance',
    slug: 'mvp-marketplace-servicios-freelance',
    description:
      'MVP funcional de un marketplace de freelancers con autenticación, perfiles y sistema de pagos integrado. 2 meses de desarrollo. Busca co-fundador técnico o comprador para escalar.',
    type: ListingType.PROJECT,
    askingPrice: 8000,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: null,
    techStack: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
    tags: ['mvp', 'freelance', 'marketplace', 'react'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 112,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'Código base SaaS multi-tenant con Next.js + Stripe',
    slug: 'codebase-saas-multitenant-nextjs-stripe',
    description:
      'Boilerplate completo para SaaS multi-tenant: auth con roles, billing con Stripe (planes, trials, upgrades), dashboard de admin, onboarding wizard, emails transaccionales. Documentación incluida.',
    type: ListingType.PROJECT,
    askingPrice: 5500,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: null,
    techStack: ['Next.js', 'Prisma', 'Stripe', 'Resend', 'Tailwind CSS'],
    tags: ['boilerplate', 'saas', 'nextjs', 'multitenant'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 95,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'App móvil de delivery local — Flutter + Firebase',
    slug: 'app-movil-delivery-local-flutter',
    description:
      'Aplicación móvil de delivery para negocios locales (similar a Pedidos Ya pero para una sola ciudad). Flutter + Firebase. Funciona en iOS y Android. Incluye panel admin web. Lista para customizar.',
    type: ListingType.PROJECT,
    askingPrice: 12000,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: null,
    techStack: ['Flutter', 'Firebase', 'Dart', 'Google Maps API'],
    tags: ['mobile', 'delivery', 'flutter', 'firebase'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 78,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'Bot de trading automatizado con backtesting',
    slug: 'bot-trading-automatizado-backtesting',
    description:
      'Sistema de trading automatizado para criptomonedas con módulo de backtesting sobre datos históricos. Estrategias configurables. Conecta con Binance y Bybit via API. Python + FastAPI.',
    type: ListingType.PROJECT,
    askingPrice: 9500,
    monthlyRevenue: null,
    monthlyTraffic: null,
    domainAge: null,
    techStack: ['Python', 'FastAPI', 'PostgreSQL', 'Pandas'],
    tags: ['trading', 'crypto', 'automatización', 'python'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 134,
  },
  {
    sellerId: SELLER_B_ID,
    title: 'SaaS de gestión de redes sociales para PyMEs',
    slug: 'saas-gestion-redes-sociales-pymes',
    description:
      'Herramienta de scheduling y analítica de redes sociales orientada a pymes latinoamericanas. Integra Instagram, Facebook y TikTok. 15 clientes de prueba activos. Busca buyer para escalar con ventas.',
    type: ListingType.SAAS,
    askingPrice: 14000,
    monthlyRevenue: 750,
    monthlyTraffic: 4000,
    domainAge: null,
    techStack: ['Next.js', 'Supabase', 'Meta API', 'TikTok API'],
    tags: ['saas', 'social-media', 'pymes', 'scheduling'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.UNVERIFIED,
    featuredUntil: null,
    viewCount: 67,
  },
  {
    sellerId: SELLER_A_ID,
    title: 'Comunidad online de inversores con membresía',
    slug: 'comunidad-online-inversores-membresia',
    description:
      'Comunidad privada de inversores retail en Argentina con 320 miembros activos ($15 USD/mes). Foro, señales de inversión semanales y calls mensuales en vivo. Alto engagement. Churn < 5%.',
    type: ListingType.WEBSITE,
    askingPrice: 20000,
    monthlyRevenue: 4800,
    monthlyTraffic: 5000,
    domainAge: 18,
    techStack: ['Ghost', 'Memberful', 'Zoom', 'Stripe'],
    tags: ['comunidad', 'inversores', 'membresia', 'finanzas'],
    screenshotUrls: [],
    verificationStatus: VerificationStatus.VERIFIED,
    featuredUntil: FEATURED_UNTIL,
    viewCount: 398,
  },
]

async function main() {
  console.log('🌱 Starting seed...')

  // Upsert profiles
  await Promise.all([
    prisma.profile.upsert({
      where: { id: SELLER_A_ID },
      update: {},
      create: {
        id: SELLER_A_ID,
        email: 'vendedor.a@test.qapitaliza.com',
        fullName: 'Federico Martínez',
        role: 'SELLER',
        bio: 'Emprendedor serial con 8 años en activos digitales. Especializado en SaaS y newsletters de nicho.',
        website: 'https://federicosell.com',
      },
    }),
    prisma.profile.upsert({
      where: { id: SELLER_B_ID },
      update: {},
      create: {
        id: SELLER_B_ID,
        email: 'vendedor.b@test.qapitaliza.com',
        fullName: 'Laura Gómez',
        role: 'SELLER',
        bio: 'Desarrolladora fullstack y emprendedora. Vendo proyectos cuando terminan su ciclo útil para mí.',
      },
    }),
    prisma.profile.upsert({
      where: { id: ADMIN_ID },
      update: {},
      create: {
        id: ADMIN_ID,
        email: 'admin@qapitaliza.com',
        fullName: 'Admin Qapitaliza',
        role: 'ADMIN',
        bio: 'Administrador de la plataforma.',
      },
    }),
  ])
  console.log('✅ Profiles upserted')

  // Create listings (skip if slug already exists)
  let created = 0
  let skipped = 0

  for (const data of listings) {
    const existing = await prisma.listing.findUnique({ where: { slug: data.slug } })
    if (existing) {
      skipped++
      continue
    }

    await prisma.listing.create({
      data: {
        ...data,
        status: ListingStatus.PUBLISHED,
        publishedAt: new Date(),
        currency: 'USD',
        url: null,
        rejectionReason: null,
      },
    })
    created++
    console.log(`✅ Created: ${data.title}`)
  }

  console.log(`\n🎉 Seed complete — ${created} listings created, ${skipped} skipped.`)
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(() => prisma.$disconnect())
