/**
 * Tests TDD para updateBillingConsumption().
 *
 * Estrategia: mocks completos de @qautiva/db (prisma).
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockBillingAccountUpdate = vi.fn()

vi.mock('@qautiva/db', () => ({
  prisma: {
    billingAccount: { update: mockBillingAccountUpdate },
  },
  UsageSource: {
    TRIAL: 'TRIAL',
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
}))

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('updateBillingConsumption', () => {
  beforeEach(() => {
    mockBillingAccountUpdate.mockReset()
  })

  it('caso TRIAL: incrementa trialTokensUsed por tokensIn + tokensOut', async () => {
    const { updateBillingConsumption } = await import('../update-billing')

    mockBillingAccountUpdate.mockResolvedValueOnce({ id: 'ba-1' })

    await updateBillingConsumption({
      teamId: 'team-abc',
      source: 'TRIAL',
      tokensIn: 1000,
      tokensOut: 500,
      totalUsd: 0.0126,
    })

    expect(mockBillingAccountUpdate).toHaveBeenCalledOnce()
    const updateArgs = mockBillingAccountUpdate.mock.calls[0][0]
    expect(updateArgs.where.teamId).toBe('team-abc')
    expect(updateArgs.data.trialTokensUsed).toEqual({ increment: 1500 }) // 1000 + 500
    expect(updateArgs.data.balanceUsd).toBeUndefined()
  })

  it('caso QAUTIVA_HOSTED (prepaid): decrementa balanceUsd por totalUsd', async () => {
    const { updateBillingConsumption } = await import('../update-billing')

    mockBillingAccountUpdate.mockResolvedValueOnce({ id: 'ba-1' })

    await updateBillingConsumption({
      teamId: 'team-abc',
      source: 'QAUTIVA_HOSTED',
      tokensIn: 1000,
      tokensOut: 500,
      totalUsd: 0.0126,
    })

    expect(mockBillingAccountUpdate).toHaveBeenCalledOnce()
    const updateArgs = mockBillingAccountUpdate.mock.calls[0][0]
    expect(updateArgs.where.teamId).toBe('team-abc')
    expect(updateArgs.data.balanceUsd).toEqual({ decrement: 0.0126 })
    expect(updateArgs.data.trialTokensUsed).toBeUndefined()
  })

  it('caso BYOK: no modifica BillingAccount', async () => {
    const { updateBillingConsumption } = await import('../update-billing')

    await updateBillingConsumption({
      teamId: 'team-abc',
      source: 'BYOK',
      tokensIn: 1000,
      tokensOut: 500,
      totalUsd: 0.0126,
    })

    expect(mockBillingAccountUpdate).not.toHaveBeenCalled()
  })

  it('edge case: saldo insuficiente (QAUTIVA_HOSTED) lanza error ruidoso, no silencioso', async () => {
    const { updateBillingConsumption } = await import('../update-billing')

    // Simulamos constraint violation de DB (balanceUsd >= 0)
    const dbError = new Error('violates check constraint "BillingAccount_balanceUsd_check"')
    mockBillingAccountUpdate.mockRejectedValueOnce(dbError)

    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
    await expect(
      updateBillingConsumption({
        teamId: 'team-abc',
        source: 'QAUTIVA_HOSTED',
        tokensIn: 1000,
        tokensOut: 500,
        totalUsd: 999.99,
      }),
    ).rejects.toThrow()
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('CRITICAL:'),
      expect.anything(),
    )
    consoleSpy.mockRestore()
  })

  it('caso teamId null: no modifica BillingAccount', async () => {
    const { updateBillingConsumption } = await import('../update-billing')

    await updateBillingConsumption({
      teamId: null,
      source: 'TRIAL',
      tokensIn: 1000,
      tokensOut: 500,
      totalUsd: 0.0105,
    })

    expect(mockBillingAccountUpdate).not.toHaveBeenCalled()
  })
})
