import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'

/**
 * GET /api/templates/[id]/preview
 * Sirve el HTML del template como página completa para preview en iframe o nueva pestaña.
 * Solo accesible para usuarios autenticados.
 */
export async function GET(
  _req: Request,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return new NextResponse('No autorizado', { status: 401 })
  }

  const template = await prisma.webTemplate.findFirst({
    where: { id: params.id, status: 'ACTIVE' },
    select: { name: true, htmlBase: true, css: true },
  })

  if (!template || !template.htmlBase) {
    return new NextResponse('Template no encontrado', { status: 404 })
  }

  let html = template.htmlBase

  // Inyectar CSS si existe y el HTML no lo incluye ya
  if (template.css) {
    const styleTag = `<style>${template.css}</style>`
    if (html.includes('</head>')) {
      html = html.replace('</head>', `${styleTag}</head>`)
    } else if (html.includes('<body')) {
      html = `${styleTag}${html}`
    } else {
      html = `${styleTag}${html}`
    }
  }

  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      // Solo permitir en iframes del mismo origen
      'X-Frame-Options': 'SAMEORIGIN',
      'Cache-Control': 'private, max-age=300',
    },
  })
}
