# Qautiva — Arquitectura y Stack Técnico

> Documento para conversaciones con Claude que involucren decisiones técnicas,
> debugging, o diseño de features.

---

## Stack tecnológico

| Componente | Tecnología | Versión |
|---|---|---|
| Lenguaje | TypeScript | 5.x |
| Framework | Next.js (App Router) | 14+ |
| Estilos | Tailwind CSS | 3.x |
| Gráficos | Recharts | 2.x |
| Iconos | Lucide React | latest |
| Base de datos | PostgreSQL (Supabase) | 15.x |
| ORM | Prisma | 5.x |
| Auth | Supabase Auth + `@supabase/ssr` | — |
| reCAPTCHA | Google reCAPTCHA v3 | — |
| Bot Telegram | grammY | 1.x |
| LLM SDK | @anthropic-ai/sdk | latest |
| Testing | Vitest | 2.x |
| Package manager | pnpm workspaces | 8.x |
| Deploy (landing+portal) | Vercel | — |
| Deploy (admin+bot) | Railway | — |
| Tipografía | Satoshi + JetBrains Mono | — |

### Tecnologías prohibidas

- `any` en TypeScript
- `SELECT *` en queries
- `console.log` de debug en código commiteado
- `@supabase/auth-helpers-nextjs` (deprecado, usar `@supabase/ssr`)
- `eval()`, `exec()`, `Function()` con datos del usuario
- NextAuth / next-auth (usamos Supabase Auth)
- Light mode / toggle de tema

---

## Estructura del monorepo

```
qautiva/
├── packages/
│   ├── ui/                  # Design system compartido
│   │   ├── components/      # Button, Card, Badge, Input, ProgressBar, Sidebar
│   │   ├── tokens.ts        # Colores, tipografía, spacing
│   │   └── tailwind.config.ts
│   └── db/                  # Schema + clientes de DB
│       ├── prisma/
│       │   ├── schema.prisma
│       │   ├── seed.ts
│       │   └── rls.sql
│       ├── client.ts        # Prisma client singleton
│       └── supabase.ts      # Supabase client helpers
├── apps/
│   ├── landing/             # qautiva.ar — SSG puro
│   ├── portal/              # app.qautiva.ar — App Router SSR
│   └── admin/               # admin.qautiva.ar — App Router SSR
├── services/
│   └── telegram-bot/        # Bot grammY + Anthropic SDK
├── docs/                    # Documentación completa
├── package.json             # Workspace root
├── pnpm-workspace.yaml
├── tsconfig.base.json
└── vitest.config.ts
```

---

## Diagrama de arquitectura

```
[Visitante] ──▶ apps/landing  (Next.js SSG, reCAPTCHA v3)
[Cliente]   ──▶ apps/portal   (Next.js SSR, Supabase Auth, reCAPTCHA)  ──▶ Supabase
[Cliente]   ──▶ services/telegram-bot (grammY + Anthropic SDK)          ──▶ (PostgreSQL
[Admin]     ──▶ apps/admin    (Next.js SSR, rol admin verificado)       ──▶  Auth + RLS
                                                                        ──▶  Realtime
                packages/ui   (design system)                           ──▶  Storage)
                packages/db   (Prisma schema + RLS policies)            ──▶ Prisma ORM

Deploy: Vercel (landing + portal) | Railway (admin + telegram-bot)
```

---

## Modelo de datos (entidades principales)

```
Organization        — Empresa cliente (nombre, plan, status)
Project             — Proyecto self-service (nombre, status, teamId)
Team                — Equipo que agrupa usuarios a un proyecto
Stage               — Etapa del proceso (BRAND, WEBSITE, CAMPAIGNS, MEDIA)
Deliverable         — Entregable de una etapa (tipo, status, contenido)
Message             — Mensaje multicanal (sender, channel: WEB|TELEGRAM)
Metric              — Métricas de rendimiento (diarias por org)
AdminNote           — Notas internas del admin sobre un cliente
Subscription        — Suscripción del cliente (plan, monto ARS)
AgentConfig         — Configuración de agentes IA
IndustryTemplate    — Templates por industria
TelegramUser        — Whitelist de usuarios TG vinculados a Organization
TelegramConfig      — Singleton de configuración del bot
UserProfile         — Vincula auth.users con Organization + role
ApiKey              — API keys BYOK encriptadas (AES-256-GCM)
BillingAccount      — Cuenta de facturación
TrialConfig         — Config de trial (tokens, TTL)
```

---

## Autenticación y autorización

### Auth — Supabase Auth

- **Login cliente:** Google OAuth o email/password (con reCAPTCHA v3)
- **Registro self-service:** Wizard de 4 pasos (sign up → datos negocio → servicios → modo IA)
- **Usuarios legacy:** tienen `app_metadata.org_id` (modelo agencia, sin wizard)
- **Middleware portal:** Verifica sesión → redirige a `/login` o `/onboarding` según estado
- **Middleware admin:** Verifica sesión + `app_metadata.role === 'admin'`

### Autorización — Row Level Security (RLS)

- Cada tabla con datos de cliente tiene `organization_id`
- RLS policy: `organization_id = (auth.jwt() ->> 'org_id')::uuid`
- Tablas admin: `auth.jwt() ->> 'role' = 'admin'`
- **Server Actions admin:** llaman `requireAdminSession()` como primer paso (verifica sesión + rol ADMIN)
- **Doble check de ownership:** JWT + query Prisma con orgId — dos capas además de RLS

### reCAPTCHA v3

- Landing: protege formulario de contacto
- Portal: protege login email/password (no OAuth)
- Dev: se saltea si falta `RECAPTCHA_SECRET_KEY`
- Prod: fail-closed (bloquea si falta la key)

---

## Patrones y convenciones clave

### Server Components por defecto
Solo `'use client'` cuando hay interactividad real (forms, charts, chat, tabs).

### Naming
- Variables/funciones: camelCase
- Componentes: PascalCase
- Constantes: SCREAMING_SNAKE
- Archivos: camelCase o kebab-case

### Funciones
- Máximo 30 líneas
- Una responsabilidad
- Early return siempre
- Nombres con verbo: get, create, validate, send

### Base de datos
- Queries parametrizadas siempre
- Soft-delete obligatorio (toda query incluye `deletedAt: null`)
- `take` en todas las queries de listado
- Índices en toda columna usada en RLS o filtros

### UI
- Formularios: validación en cliente Y servidor
- Botones: se deshabilitan mientras procesan
- Listados: estado vacío visible
- Carga: indicador si tarda >300ms
- Éxito: feedback visible al usuario
- Formato argentino: números (1.000,50), fechas (DD/MM/AAAA)

---

## Design system — tokens principales

| Token | Valor | Uso |
|---|---|---|
| `bg.primary` | `#0B0F1A` | Fondo principal |
| `bg.secondary` | `#0F172A` | Tarjetas, paneles |
| `bg.tertiary` | `#1E293B` | Inputs, hovers |
| `accent.DEFAULT` | `#8B5CF6` | Botones primarios |
| `accent.light` | `#A78BFA` | Hover, bordes activos |
| `text.primary` | `#F8FAFC` | Títulos |
| `text.secondary` | `#94A3B8` | Descripciones |
| `status.success` | `#10B981` | Completado |
| `status.warning` | `#F59E0B` | Pendiente |
| `status.error` | `#EF4444` | Error |

Tipografía: Satoshi (display + body) / JetBrains Mono (datos, código).

---

## Bot de Telegram

- **Framework:** grammY (TypeScript-first)
- **LLM:** Anthropic SDK — Haiku para consultas simples, Sonnet para complejas
- **Runtime:** Long-polling, proceso persistente en Railway
- **Optimización de costos:**
  - Cache de consultas de estado → sin LLM (ahorro 40-60%)
  - Modelo escalonado Haiku/Sonnet (ahorro 70% por call)
  - Templates para estados conocidos (ahorro 20-30%)
  - Rate limiting por plan

---

## Variables de entorno requeridas

```bash
# Supabase
DATABASE_URL, DIRECT_URL
NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY         # solo server

# reCAPTCHA
RECAPTCHA_SECRET_KEY              # solo server

# Telegram Bot
TELEGRAM_BOT_TOKEN
ANTHROPIC_API_KEY

# Landing
NEXT_PUBLIC_WHATSAPP_NUMBER
```

---

## ADRs (decisiones de arquitectura registradas)

1. **ADR-0001** — Sistema de documentación modular
2. **ADR-0002** — Decisiones arquitectónicas v1 (Supabase Auth en lugar de NextAuth, etc.)
3. **ADR-0003** — selectedOptionId en feedback (opción de marca elegida)
4. **ADR-0004** — SaaS self-service con BYOK (Bring Your Own Key)
5. **ADR-0005** — Server Actions auth pattern (requireAdminSession)
6. **ADR-0006** — URL-based tabs en admin (deep links)
