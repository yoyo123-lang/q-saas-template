# Informe de Revisión — ROL 1: Code Reviewer
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol 1 - Code Reviewer

---

## Resumen ejecutivo

El código de la Sesión 02 es funcional y sigue los patrones del proyecto. Se detectaron issues de robustez menores pero corregibles.

---

## Hallazgos

### [ALTO] Catch vacíos sin logging

**Archivos:**
- `src/app/page.tsx:29` — `catch {}` silencia el error sin trazabilidad
- `src/app/sitemap.ts:31` — mismo patrón

**Impacto:** En producción, si la DB falla, no hay trazabilidad del problema. Los errores se tragan silenciosamente.

**Fix aplicado:** Reemplazados con `catch (e) { console.error('[contexto]', e) }`.

---

### [MEDIO] `incrementListingViews` sincrónico en SSR

**Archivo:** `src/app/(public)/explorar/[slug]/page.tsx:57`

**Impacto:** Si el DB falla durante el UPDATE de viewCount, la página lanza un 500 en lugar de degradar graciosamente.

**Fix aplicado:** Envuelto en bloque no-bloqueante (ver ROL 2 y ROL 4).

---

### [BAJO] Naming inconsistente de componente

**Archivo:** `src/components/shared/accordion-faq.tsx`

El componente exportado es `AccordionFaq` pero la convención del proyecto usa PascalCase para acrónimos (`AccordionFAQ`). Sin embargo, el uso en el codebase es consistente con `AccordionFaq`.

**Decisión:** No modificar — consistencia interna prevalece sobre la convención de acrónimos.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| Catch vacíos sin logging | ALTO | Corregido |
| incrementListingViews sincrónico | MEDIO | Corregido (ROL 2/4) |
| Naming AccordionFaq | BAJO | No modificado (intencional) |
