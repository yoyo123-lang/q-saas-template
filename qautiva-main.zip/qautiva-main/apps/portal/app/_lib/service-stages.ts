/**
 * Stages core que se crean SIEMPRE para todo proyecto, independientemente de los servicios.
 * Stage 1 = "Tu negocio" (DISCOVERY): relevamiento del negocio del cliente.
 * Stage 2 = "Mercado" (RESEARCH): análisis de mercado y competencia.
 */
export const CORE_STAGES = [
  { number: 1, name: 'Tu negocio', stageKey: 'DISCOVERY' },
  { number: 2, name: 'Mercado', stageKey: 'RESEARCH' },
] as const

/**
 * Mapa de servicios a sus stages correspondientes.
 * sortOrder: para ordenar entre sí; el número real en DB se calcula dinámicamente
 * (siempre después de los 2 core stages, empezando desde 3).
 */
export const SERVICE_STAGES: Record<string, { sortOrder: number; name: string; stageKey: string }> = {
  BRAND:     { sortOrder: 1, name: 'Marca',                stageKey: 'BRAND'     },
  WEBSITE:   { sortOrder: 2, name: 'Sitio web',            stageKey: 'WEBSITE'   },
  CAMPAIGNS: { sortOrder: 3, name: 'Campañas',             stageKey: 'CAMPAIGNS' },
  MEDIA:     { sortOrder: 4, name: 'Contenido para medios', stageKey: 'MEDIA'    },
}

export const VALID_SERVICES = ['BRAND', 'WEBSITE', 'CAMPAIGNS', 'MEDIA'] as const
export type ServiceType = typeof VALID_SERVICES[number]
