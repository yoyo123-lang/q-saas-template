# Sesión 01: Schema base y multi-tenancy (backend)

## Objetivo
Crear todos los modelos de dominio de Fase 1 en Prisma, implementar el helper de multi-tenancy `withTenant()`, correr migración, y crear seed con datos de demo.

## Pre-requisitos
- Ninguno (primera sesión)

## Contexto
El template tiene modelos de auth (User, Account, Session, AllowedEmail) y un modelo de ejemplo (Project) que NO se usa en Qontabiliza. El modelo Project sirve como referencia de patrones (soft delete, índices, relaciones) pero NO se borra — es parte del template.

## Al iniciar
1. Leer `ROADMAP.md` para contexto general
2. Leer `prisma/schema.prisma` para ver el estado actual
3. Leer `src/lib/db.ts` para entender el cliente Prisma actual
4. Leer `docs/ARCHITECTURE.md` para respetar convenciones

---

## Etapa 1: Modelos de organización y membresía

### Tarea 1.1: Modelo Organization
**Archivo**: `prisma/schema.prisma`

Agregar modelo `Organization`:
```prisma
model Organization {
  id          String   @id @default(cuid())
  name        String                          // Nombre comercial
  legalName   String?                         // Razón social
  cuit        String?                         // CUIT de la empresa
  ivaCondition String?                        // Responsable Inscripto, Monotributista, etc.
  address     String?                         // Domicilio fiscal
  phone       String?
  email       String?
  logo        String?                         // URL del logo

  // Configuración ARCA
  arcaCert        String?   @db.Text          // Certificado digital (PEM)
  arcaKey         String?   @db.Text          // Clave privada (PEM)
  arcaPointOfSale Int?                        // Punto de venta habilitado en ARCA
  arcaEnvironment String    @default("testing") // "testing" o "production"

  // Suscripción
  planId      String?
  plan        Plan?    @relation(fields: [planId], references: [id])

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  deletedAt   DateTime?

  // Relaciones
  memberships   Membership[]
  categories    Category[]
  products      Product[]
  priceLists    PriceList[]
  contacts      Contact[]
  invoices      Invoice[]
  sales         Sale[]
  warehouses    Warehouse[]
  stockMovements StockMovement[]
  cashRegisters CashRegister[]
  paymentRecords PaymentRecord[]

  @@index([deletedAt])
}
```

### Tarea 1.2: Modelo Membership
**Archivo**: `prisma/schema.prisma`

```prisma
enum MemberRole {
  OWNER       // Dueño, acceso total
  ADMIN       // Administrador
  SELLER      // Vendedor (solo POS y ventas)
  VIEWER      // Solo lectura
}

model Membership {
  id             String     @id @default(cuid())
  userId         String
  organizationId String
  role           MemberRole @default(SELLER)

  user         User         @relation(fields: [userId], references: [id], onDelete: Cascade)
  organization Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)

  createdAt    DateTime     @default(now())
  updatedAt    DateTime     @updatedAt

  @@unique([userId, organizationId])
  @@index([organizationId])
  @@index([userId])
}
```

Agregar relación en `User`:
```prisma
// En el modelo User existente, agregar:
memberships Membership[]
```

### Tarea 1.3: Modelo Plan
**Archivo**: `prisma/schema.prisma`

```prisma
model Plan {
  id              String   @id @default(cuid())
  name            String                    // Micro, Starter, Pro, Max
  slug            String   @unique          // micro, starter, pro, max
  priceMonthly    Int                       // En centavos ARS
  maxUsers        Int                       // Límite de usuarios
  maxInvoices     Int                       // Comprobantes por mes (0 = ilimitado)
  maxProducts     Int                       // Productos totales (0 = ilimitado)
  features        Json     @default("[]")   // Features adicionales como JSON array
  isActive        Boolean  @default(true)

  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  organizations   Organization[]
}
```

**Commit**: `feat(schema): add Organization, Membership and Plan models`

---

## Etapa 2: Modelos de catálogo (productos)

### Tarea 2.1: Modelo Category
**Archivo**: `prisma/schema.prisma`

```prisma
model Category {
  id             String       @id @default(cuid())
  organizationId String
  name           String
  description    String?
  parentId       String?      // Categorías anidadas
  sortOrder      Int          @default(0)

  organization   Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  parent         Category?    @relation("CategoryTree", fields: [parentId], references: [id])
  children       Category[]   @relation("CategoryTree")
  products       Product[]

  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt
  deletedAt      DateTime?

  @@index([organizationId, deletedAt])
  @@index([parentId])
}
```

### Tarea 2.2: Modelo Product
**Archivo**: `prisma/schema.prisma`

```prisma
model Product {
  id             String       @id @default(cuid())
  organizationId String
  categoryId     String?

  name           String
  description    String?
  sku            String?                    // Código interno
  barcode        String?                    // Código de barras EAN/UPC

  // Precio base (sin lista de precios)
  basePrice      Decimal      @db.Decimal(12, 2)
  costPrice      Decimal?     @db.Decimal(12, 2)

  // IVA
  ivaRate        Decimal      @default(21) @db.Decimal(5, 2)  // 21%, 10.5%, 27%, 0%

  // Stock
  trackStock     Boolean      @default(true)
  minStock       Int          @default(0)   // Alerta de stock bajo

  isActive       Boolean      @default(true)

  organization   Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  category       Category?    @relation(fields: [categoryId], references: [id])
  variants       ProductVariant[]
  priceListItems PriceListItem[]
  invoiceItems   InvoiceItem[]
  saleItems      SaleItem[]
  stockMovements StockMovement[]

  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt
  deletedAt      DateTime?

  @@index([organizationId, deletedAt])
  @@index([organizationId, barcode])
  @@index([organizationId, sku])
  @@index([categoryId])
}
```

### Tarea 2.3: Modelo ProductVariant
**Archivo**: `prisma/schema.prisma`

```prisma
model ProductVariant {
  id          String   @id @default(cuid())
  productId   String

  name        String                        // Ej: "Talle M", "Color Rojo"
  sku         String?
  barcode     String?

  priceAdjustment Decimal @default(0) @db.Decimal(12, 2) // Ajuste sobre precio base

  isActive    Boolean  @default(true)

  product     Product  @relation(fields: [productId], references: [id], onDelete: Cascade)

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@index([productId])
  @@index([barcode])
}
```

### Tarea 2.4: Modelos PriceList y PriceListItem
**Archivo**: `prisma/schema.prisma`

```prisma
model PriceList {
  id             String       @id @default(cuid())
  organizationId String

  name           String                    // Ej: "Mayorista", "Minorista", "Empleados"
  description    String?
  isDefault      Boolean      @default(false)
  isActive       Boolean      @default(true)

  organization   Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  items          PriceListItem[]

  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  @@index([organizationId])
}

model PriceListItem {
  id          String    @id @default(cuid())
  priceListId String
  productId   String

  price       Decimal   @db.Decimal(12, 2)  // Precio específico en esta lista

  priceList   PriceList @relation(fields: [priceListId], references: [id], onDelete: Cascade)
  product     Product   @relation(fields: [productId], references: [id], onDelete: Cascade)

  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt

  @@unique([priceListId, productId])
  @@index([productId])
}
```

**Commit**: `feat(schema): add Category, Product, ProductVariant, PriceList models`

---

## Etapa 3: Modelos de contactos, facturación, ventas, stock y tesorería

### Tarea 3.1: Modelo Contact (clientes y proveedores)
**Archivo**: `prisma/schema.prisma`

```prisma
enum ContactType {
  CUSTOMER      // Cliente
  SUPPLIER      // Proveedor
  BOTH          // Ambos
}

enum IvaCondition {
  RESPONSABLE_INSCRIPTO
  MONOTRIBUTISTA
  EXENTO
  CONSUMIDOR_FINAL
  NO_RESPONSABLE
}

model Contact {
  id             String       @id @default(cuid())
  organizationId String

  type           ContactType  @default(CUSTOMER)

  // Datos básicos
  name           String                    // Razón social o nombre
  tradeName      String?                   // Nombre de fantasía
  email          String?
  phone          String?
  address        String?
  city           String?
  province       String?
  zipCode        String?

  // Datos fiscales
  cuit           String?                   // CUIT/CUIL/DNI
  ivaCondition   IvaCondition @default(CONSUMIDOR_FINAL)

  notes          String?

  organization   Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  invoices       Invoice[]
  sales          Sale[]

  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt
  deletedAt      DateTime?

  @@index([organizationId, deletedAt])
  @@index([organizationId, type])
  @@index([organizationId, cuit])
}
```

### Tarea 3.2: Modelos Invoice e InvoiceItem
**Archivo**: `prisma/schema.prisma`

```prisma
enum InvoiceType {
  FACTURA_A
  FACTURA_B
  FACTURA_C
  NOTA_CREDITO_A
  NOTA_CREDITO_B
  NOTA_CREDITO_C
  NOTA_DEBITO_A
  NOTA_DEBITO_B
  NOTA_DEBITO_C
}

enum InvoiceStatus {
  DRAFT         // Borrador (no enviado a ARCA)
  AUTHORIZED    // Autorizado por ARCA (tiene CAE)
  REJECTED      // Rechazado por ARCA
  CANCELLED     // Anulado (tiene nota de crédito asociada)
}

model Invoice {
  id             String        @id @default(cuid())
  organizationId String
  contactId      String
  saleId         String?       @unique       // Relación 1:1 con venta (si aplica)

  // Tipo y numeración
  type           InvoiceType
  pointOfSale    Int                         // Punto de venta (ej: 00001)
  number         Int                         // Número de comprobante

  // ARCA
  cae            String?                     // Código de Autorización Electrónico
  caeExpiration  DateTime?                   // Vencimiento del CAE
  arcaResult     Json?                       // Respuesta completa de ARCA

  // Montos
  subtotal       Decimal       @db.Decimal(12, 2)
  ivaAmount      Decimal       @db.Decimal(12, 2)
  otherTaxes     Decimal       @default(0) @db.Decimal(12, 2)
  total          Decimal       @db.Decimal(12, 2)

  // Datos del comprador (snapshot al momento de emisión)
  buyerName      String
  buyerCuit      String?
  buyerIvaCondition IvaCondition @default(CONSUMIDOR_FINAL)
  buyerAddress   String?

  // Relación con nota de crédito/débito
  relatedInvoiceId String?                   // Factura original (si es NC/ND)

  status         InvoiceStatus @default(DRAFT)
  issuedAt       DateTime      @default(now())

  organization   Organization  @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  contact        Contact       @relation(fields: [contactId], references: [id])
  sale           Sale?         @relation(fields: [saleId], references: [id])
  relatedInvoice Invoice?      @relation("InvoiceRelation", fields: [relatedInvoiceId], references: [id])
  relatedNotes   Invoice[]     @relation("InvoiceRelation")
  items          InvoiceItem[]

  createdAt      DateTime      @default(now())
  updatedAt      DateTime      @updatedAt

  @@unique([organizationId, type, pointOfSale, number])
  @@index([organizationId, status])
  @@index([organizationId, contactId])
  @@index([organizationId, issuedAt])
}

model InvoiceItem {
  id          String   @id @default(cuid())
  invoiceId   String
  productId   String?                      // Null si es ítem libre

  description String
  quantity    Decimal  @db.Decimal(12, 4)
  unitPrice   Decimal  @db.Decimal(12, 2)
  ivaRate     Decimal  @db.Decimal(5, 2)    // 21, 10.5, 27, 0
  ivaAmount   Decimal  @db.Decimal(12, 2)
  subtotal    Decimal  @db.Decimal(12, 2)   // quantity * unitPrice
  total       Decimal  @db.Decimal(12, 2)   // subtotal + ivaAmount

  invoice     Invoice  @relation(fields: [invoiceId], references: [id], onDelete: Cascade)
  product     Product? @relation(fields: [productId], references: [id])

  createdAt   DateTime @default(now())

  @@index([invoiceId])
  @@index([productId])
}
```

### Tarea 3.3: Modelos Sale y SaleItem
**Archivo**: `prisma/schema.prisma`

```prisma
enum SaleStatus {
  PENDING       // En proceso (carrito del POS)
  COMPLETED     // Completada y cobrada
  CANCELLED     // Cancelada
}

model Sale {
  id             String       @id @default(cuid())
  organizationId String
  contactId      String?                    // Consumidor final puede no tener contacto
  cashRegisterId String?

  status         SaleStatus   @default(PENDING)

  subtotal       Decimal      @db.Decimal(12, 2)
  discount       Decimal      @default(0) @db.Decimal(12, 2)
  ivaAmount      Decimal      @db.Decimal(12, 2)
  total          Decimal      @db.Decimal(12, 2)

  notes          String?

  completedAt    DateTime?

  organization   Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  contact        Contact?     @relation(fields: [contactId], references: [id])
  cashRegister   CashRegister? @relation(fields: [cashRegisterId], references: [id])
  items          SaleItem[]
  invoice        Invoice?                   // Relación inversa 1:1
  paymentRecords PaymentRecord[]

  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  @@index([organizationId, status])
  @@index([organizationId, completedAt])
  @@index([contactId])
}

model SaleItem {
  id         String   @id @default(cuid())
  saleId     String
  productId  String

  productName String                       // Snapshot del nombre al momento de la venta
  quantity   Decimal  @db.Decimal(12, 4)
  unitPrice  Decimal  @db.Decimal(12, 2)
  ivaRate    Decimal  @db.Decimal(5, 2)
  ivaAmount  Decimal  @db.Decimal(12, 2)
  subtotal   Decimal  @db.Decimal(12, 2)
  discount   Decimal  @default(0) @db.Decimal(12, 2)
  total      Decimal  @db.Decimal(12, 2)

  sale       Sale     @relation(fields: [saleId], references: [id], onDelete: Cascade)
  product    Product  @relation(fields: [productId], references: [id])

  createdAt  DateTime @default(now())

  @@index([saleId])
  @@index([productId])
}
```

### Tarea 3.4: Modelos de Stock
**Archivo**: `prisma/schema.prisma`

```prisma
enum StockMovementType {
  PURCHASE      // Compra / ingreso
  SALE          // Venta / egreso
  ADJUSTMENT    // Ajuste manual
  RETURN        // Devolución
  INITIAL       // Carga inicial
}

model Warehouse {
  id             String       @id @default(cuid())
  organizationId String

  name           String       @default("Principal")
  address        String?
  isDefault      Boolean      @default(true)

  organization   Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  stockMovements StockMovement[]

  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  @@index([organizationId])
}

model StockMovement {
  id             String            @id @default(cuid())
  organizationId String
  warehouseId    String
  productId      String

  type           StockMovementType
  quantity       Decimal           @db.Decimal(12, 4)  // Positivo = entrada, Negativo = salida

  reference      String?                                // Ej: "Venta #123", "Ajuste inventario"
  referenceId    String?                                // ID de la venta/compra que originó el movimiento
  notes          String?

  organization   Organization      @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  warehouse      Warehouse         @relation(fields: [warehouseId], references: [id])
  product        Product           @relation(fields: [productId], references: [id])

  createdAt      DateTime          @default(now())

  @@index([organizationId, productId])
  @@index([organizationId, warehouseId])
  @@index([organizationId, createdAt])
  @@index([productId, warehouseId])
}
```

### Tarea 3.5: Modelos de Tesorería
**Archivo**: `prisma/schema.prisma`

```prisma
enum CashRegisterStatus {
  OPEN
  CLOSED
}

model CashRegister {
  id             String              @id @default(cuid())
  organizationId String
  openedById     String              // User que abrió la caja
  closedById     String?             // User que cerró la caja

  name           String              @default("Caja 1")
  status         CashRegisterStatus  @default(OPEN)

  openingAmount  Decimal             @db.Decimal(12, 2)  // Monto inicial
  closingAmount  Decimal?            @db.Decimal(12, 2)  // Monto al cierre
  expectedAmount Decimal?            @db.Decimal(12, 2)  // Monto esperado (calculado)
  difference     Decimal?            @db.Decimal(12, 2)  // Diferencia (real - esperado)

  openedAt       DateTime            @default(now())
  closedAt       DateTime?

  organization   Organization        @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  sales          Sale[]
  paymentRecords PaymentRecord[]

  createdAt      DateTime            @default(now())
  updatedAt      DateTime            @updatedAt

  @@index([organizationId, status])
  @@index([organizationId, openedAt])
}

enum PaymentMethod {
  CASH              // Efectivo
  DEBIT_CARD        // Tarjeta de débito
  CREDIT_CARD       // Tarjeta de crédito
  TRANSFER          // Transferencia bancaria
  QOBRA             // Qobra (mock en Fase 1)
  QR                // QR
  OTHER
}

model PaymentRecord {
  id             String        @id @default(cuid())
  organizationId String
  saleId         String
  cashRegisterId String?

  method         PaymentMethod
  amount         Decimal       @db.Decimal(12, 2)

  reference      String?                   // Nro de operación, últimos 4 dígitos tarjeta, etc.

  organization   Organization  @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  sale           Sale          @relation(fields: [saleId], references: [id])
  cashRegister   CashRegister? @relation(fields: [cashRegisterId], references: [id])

  createdAt      DateTime      @default(now())

  @@index([organizationId, saleId])
  @@index([cashRegisterId])
}
```

**Commit**: `feat(schema): add Contact, Invoice, Sale, Stock and Treasury models`

---

## Etapa 4: Helper withTenant, seed y tests

### Tarea 4.1: Helper withTenant
**Archivo nuevo**: `src/lib/tenant.ts`

Crear helper que simplifica queries multi-tenant:

```typescript
// Funciones a implementar:

// withTenant(tenantId) — retorna objeto { where: { organizationId: tenantId, deletedAt: null } }
// para usar como spread en queries Prisma

// validateTenantAccess(userId, tenantId) — verifica que el user tenga membership en esa org
// Lanza error 403 si no tiene acceso

// getTenantRole(userId, tenantId) — retorna el MemberRole del usuario en esa org

// requireTenantRole(userId, tenantId, minimumRole) — valida que tenga al menos ese rol
// Jerarquía: OWNER > ADMIN > SELLER > VIEWER
```

### Tarea 4.2: Tests para withTenant
**Archivo nuevo**: `src/lib/__tests__/tenant.test.ts`

Tests unitarios:
- `withTenant` retorna filtro correcto con organizationId y deletedAt: null
- `validateTenantAccess` lanza error si no hay membership
- `validateTenantAccess` pasa si hay membership
- `getTenantRole` retorna el rol correcto
- `requireTenantRole` valida jerarquía de roles

### Tarea 4.3: Seed de datos demo
**Archivo**: `prisma/seed.ts`

Crear (o actualizar si existe) seed con:
- 1 Plan por cada tier (Micro, Starter, Pro, Max) con los límites correctos
- 1 Organization demo ("Ferretería Don Pedro") con plan Starter
- 1 Membership OWNER para el primer usuario
- 1 Warehouse "Principal" (default)
- 3-5 categorías de ejemplo (Herramientas, Pinturas, Electricidad, Plomería, Tornillería)
- 10 productos de ejemplo con precios realistas en ARS
- 3 contactos demo (2 clientes, 1 proveedor)

### Tarea 4.4: Ejecutar migración y seed
**Comandos**:
```bash
npx prisma migrate dev --name init-qontabiliza-models
npx prisma db seed
```

Verificar que:
- Migración corre sin errores
- Seed inserta datos correctamente
- `npx prisma studio` muestra las tablas (verificación visual)

**Commit**: `feat(multi-tenancy): add withTenant helper, seed data, and run migration`

---

## Checklist de cierre de sesión

- [ ] Todos los modelos de dominio creados en Prisma
- [ ] Migración ejecutada sin errores
- [ ] Seed funcional con datos de demo
- [ ] Helper `withTenant` implementado con tests
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
- [ ] `npm run build` pasa sin errores
