import type { Metadata } from 'next'
import { prisma } from '@qautiva/db'
import { TldPricingForm } from './TldPricingForm'

export const metadata: Metadata = { title: 'Precios TLD | Qautiva Admin' }
export const dynamic = 'force-dynamic'

// ── Data ─────────────────────────────────────────────────────────────────────

async function getTldPricings() {
  return prisma.tldPricing.findMany({
    orderBy: { tld: 'asc' },
    select: {
      id: true,
      tld: true,
      registrationPriceUsd: true,
      renewalPriceUsd: true,
      marginType: true,
      marginValue: true,
      isActive: true,
      lastSyncedAt: true,
    },
  })
}

// ── Page ─────────────────────────────────────────────────────────────────────

export default async function PricingPage() {
  const rawPricings = await getTldPricings()

  // Serialize Decimal fields before passing to client component
  const pricings = rawPricings.map((p) => ({
    ...p,
    registrationPriceUsd: p.registrationPriceUsd.toString(),
    renewalPriceUsd: p.renewalPriceUsd?.toString() ?? null,
    marginValue: p.marginValue.toString(),
  }))

  return (
    <div className="flex flex-col p-6 gap-6">
      {/* Header */}
      <div>
        <h1 className="text-white text-xl font-bold">Precios TLD</h1>
        <p className="text-[#64748B] text-sm mt-0.5">
          {pricings.length} TLD{pricings.length !== 1 ? 's' : ''} configurados
        </p>
      </div>

      {/* Table */}
      {pricings.length === 0 ? (
        <p className="text-[#64748B] text-sm">Sin TLDs configurados todavía.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[#1E293B]">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[#64748B] border-b border-[#1E293B] bg-[#0F172A]">
                <th className="px-4 py-3 font-medium">TLD</th>
                <th className="px-4 py-3 font-medium">Registro USD</th>
                <th className="px-4 py-3 font-medium">Renovación USD</th>
                <th className="px-4 py-3 font-medium">Tipo margen</th>
                <th className="px-4 py-3 font-medium">Margen</th>
                <th className="px-4 py-3 font-medium">Activo</th>
                <th className="px-4 py-3 font-medium">Último sync</th>
              </tr>
            </thead>
            <tbody>
              {pricings.map((p) => (
                <tr
                  key={p.id}
                  className="border-b border-[#1E293B] last:border-0 hover:bg-[#0F172A] transition-colors"
                >
                  <td className="px-4 py-3 text-[#A78BFA] font-mono font-medium">.{p.tld}</td>
                  <td className="px-4 py-3 text-[#F8FAFC]">
                    ${Number(p.registrationPriceUsd).toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-3 text-[#F8FAFC]">
                    ${Number(p.renewalPriceUsd).toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-3 text-[#94A3B8]">
                    {p.marginType === 'PERCENTAGE' ? 'Porcentaje' : 'Fijo ARS'}
                  </td>
                  <td className="px-4 py-3 text-[#94A3B8]">
                    {p.marginType === 'PERCENTAGE'
                      ? `${Number(p.marginValue).toLocaleString('es-AR')}%`
                      : `$${Number(p.marginValue).toLocaleString('es-AR')}`}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                        p.isActive
                          ? 'bg-[#10B981]/15 text-[#10B981]'
                          : 'bg-[#64748B]/15 text-[#94A3B8]'
                      }`}
                    >
                      {p.isActive ? 'Activo' : 'Inactivo'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-[#64748B] text-xs">
                    {p.lastSyncedAt ? p.lastSyncedAt.toLocaleDateString('es-AR') : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Edit form */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-5">
        <h2 className="text-[#F8FAFC] text-sm font-semibold mb-4">Editar margen de TLD</h2>
        <TldPricingForm tlds={pricings} />
      </section>
    </div>
  )
}
