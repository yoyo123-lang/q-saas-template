import { prisma } from '@qautiva/db'

/**
 * Obtiene el teamId y teamRole del primer equipo del usuario autenticado.
 * Retorna null si el usuario no tiene membresías (ej: usuarios legacy sin team).
 */
export async function getTeamForUser(
  authUserId: string,
): Promise<{ teamId: string; teamRole: string } | null> {
  const membership = await prisma.teamMember.findFirst({
    where: { user: { authUserId } },
    select: { teamId: true, role: true },
    orderBy: { createdAt: 'asc' },
  })

  if (!membership) return null

  return { teamId: membership.teamId, teamRole: membership.role }
}
