'use server'

import { requireAdminSession, createSupabaseServerClient } from '@/lib/supabase-server'
import { revalidatePath } from 'next/cache'

/**
 * Fuerza el reprocesamiento de una sesión de entrevista stuck o con error.
 * Llama al endpoint admin del portal con el JWT de Supabase del admin actual.
 */
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export async function retryInterviewSession(
  sessionId: string,
  orgId: string,
): Promise<{ ok: boolean; message: string }> {
  // Validar UUID antes de interpolar en la URL para prevenir path traversal / SSRF
  if (!UUID_RE.test(sessionId)) {
    return { ok: false, message: 'ID de sesión inválido' }
  }

  await requireAdminSession()

  // Obtener el access token de la sesión actual para autenticarse en el portal
  const supabase = await createSupabaseServerClient()
  const { data: { session } } = await supabase.auth.getSession()
  const token = session?.access_token

  if (!token) {
    return { ok: false, message: 'No se pudo obtener el token de sesión' }
  }

  const portalUrl = process.env.PORTAL_URL
  if (!portalUrl) {
    return { ok: false, message: 'PORTAL_URL no configurada — ver .env.example' }
  }

  try {
    const res = await fetch(`${portalUrl}/api/admin/sessions/${sessionId}/process`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      // 55s timeout — la generación del brief puede tomar hasta 50s
      signal: AbortSignal.timeout(55_000),
    })

    if (res.ok) {
      revalidatePath(`/clientes/${orgId}`)
      return { ok: true, message: 'Sesión procesada exitosamente' }
    }

    const body = await res.json().catch(() => null)
    const errorMsg = body?.error ?? `HTTP ${res.status}`
    return { ok: false, message: `Error del portal: ${errorMsg}` }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    return { ok: false, message: `Error de conexión: ${msg}` }
  }
}

/**
 * Retrocede una sesión en PROCESSING o ERROR a IN_PROGRESS,
 * para que el usuario pueda volver a hacer la entrevista.
 * Las respuestas se conservan — el usuario retoma donde quedó.
 */
export async function resetSessionToInterview(
  sessionId: string,
  orgId: string,
): Promise<{ ok: boolean; message: string }> {
  if (!UUID_RE.test(sessionId)) {
    return { ok: false, message: 'ID de sesión inválido' }
  }

  await requireAdminSession()

  const supabase = await createSupabaseServerClient()
  const { data: { session } } = await supabase.auth.getSession()
  const token = session?.access_token

  if (!token) {
    return { ok: false, message: 'No se pudo obtener el token de sesión' }
  }

  const portalUrl = process.env.PORTAL_URL
  if (!portalUrl) {
    return { ok: false, message: 'PORTAL_URL no configurada — ver .env.example' }
  }

  try {
    const res = await fetch(`${portalUrl}/api/admin/sessions/${sessionId}/reset-to-interview`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      signal: AbortSignal.timeout(15_000),
    })

    if (res.ok) {
      revalidatePath(`/clientes/${orgId}`)
      revalidatePath('/sesiones')
      return { ok: true, message: 'Sesión devuelta a entrevista' }
    }

    const body = await res.json().catch(() => null)
    const errorMsg = body?.error ?? `HTTP ${res.status}`
    return { ok: false, message: `Error del portal: ${errorMsg}` }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    return { ok: false, message: `Error de conexión: ${msg}` }
  }
}
