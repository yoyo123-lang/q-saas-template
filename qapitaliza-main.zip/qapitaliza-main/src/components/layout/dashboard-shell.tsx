'use client'

import { useState } from 'react'
import { Menu } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

interface DashboardShellProps {
  sidebar: React.ReactNode
  children: React.ReactNode
}

/**
 * Client wrapper for dashboard/admin layouts.
 * Sidebar is always visible on xl+, hidden on smaller screens with a drawer toggle.
 */
export function DashboardShell({ sidebar, children }: DashboardShellProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex h-screen bg-navy-950">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 xl:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Sidebar — always rendered, toggled via translate on mobile */}
      <div
        className={cn(
          'fixed left-0 top-0 h-screen z-40 transition-transform duration-200',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full xl:translate-x-0'
        )}
      >
        {sidebar}
      </div>

      {/* Main content */}
      <main className="flex-1 xl:ml-[280px] overflow-y-auto">
        {/* Mobile top bar */}
        <div className="xl:hidden flex items-center gap-3 px-4 py-3 border-b border-slate-800 bg-navy-950 sticky top-0 z-20">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 text-slate-400 hover:text-slate-50 transition-colors"
            aria-label="Abrir menú"
          >
            <Menu className="size-5" />
          </button>
          <span className="text-sm font-medium text-slate-300">Qapitaliza</span>
        </div>

        <div className="p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  )
}
