'use client'

import { useFormContext } from 'react-hook-form'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select } from '@/components/ui/select'
import { TagInput } from '@/components/ui/tag-input'
import type { CreateListingInput } from '@/lib/schemas/listing'

const typeOptions = [
  { value: 'WEBSITE', label: 'Sitio Web' },
  { value: 'DOMAIN', label: 'Dominio' },
  { value: 'SAAS', label: 'SaaS / MVP' },
  { value: 'ECOMMERCE', label: 'E-commerce' },
  { value: 'PROJECT', label: 'Proyecto' },
  { value: 'OTHER', label: 'Otro' },
]

const currencyOptions = [
  { value: 'USD', label: 'USD' },
  { value: 'ARS', label: 'ARS' },
]

const techSuggestions = [
  'React', 'Next.js', 'WordPress', 'Shopify', 'Node.js', 'Python',
  'Laravel', 'Vue', 'Tailwind CSS', 'TypeScript', 'PostgreSQL', 'Supabase',
]

export function StepBasic() {
  const { register, watch, setValue, formState: { errors } } = useFormContext<CreateListingInput>()

  const description = watch('description') ?? ''
  const techStack = watch('techStack') ?? []
  const tags = watch('tags') ?? []

  return (
    <div className="space-y-5">
      <Input
        label="Título del activo"
        placeholder="Ej: SaaS de gestión de proyectos con 200 usuarios activos"
        error={errors.title?.message}
        {...register('title')}
      />

      <Select
        label="Tipo de activo"
        options={typeOptions}
        placeholder="Seleccioná un tipo"
        value={watch('type') ?? ''}
        onChange={(v) => setValue('type', v as CreateListingInput['type'], { shouldValidate: true })}
        error={errors.type?.message}
      />

      <Input
        label="URL del activo"
        prefix="https://"
        placeholder="tu-sitio.com"
        error={errors.url?.message}
        {...register('url')}
      />

      <Textarea
        label="Descripción"
        rows={6}
        maxLength={2000}
        placeholder="Describí el activo: qué hace, para quién, por qué lo vendés..."
        error={errors.description?.message}
        {...register('description')}
        value={description}
        onChange={(e) => {
          setValue('description', e.target.value)
        }}
      />

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Precio"
          prefix="$"
          type="number"
          min={1}
          placeholder="18000"
          error={errors.askingPrice?.message}
          {...register('askingPrice', { valueAsNumber: true })}
        />
        <Select
          label="Moneda"
          options={currencyOptions}
          value={(watch('currency') as string | undefined) ?? 'USD'}
          onChange={(v) => setValue('currency', v as 'USD' | 'ARS')}
        />
      </div>

      <TagInput
        label="Tech Stack"
        value={techStack}
        onChange={(v) => setValue('techStack', v, { shouldValidate: true })}
        maxTags={10}
        maxLength={30}
        suggestions={techSuggestions}
        placeholder="Ej: React, Next.js..."
        error={errors.techStack?.message}
        helper="Presioná Enter o coma para agregar. Máx 10 tecnologías."
      />

      <TagInput
        label="Tags"
        value={tags}
        onChange={(v) => setValue('tags', v, { shouldValidate: true })}
        maxTags={8}
        maxLength={30}
        placeholder="Ej: rentable, automatizado..."
        error={errors.tags?.message}
        helper="Etiquetas para ayudar a los compradores a encontrar tu activo. Máx 8."
      />
    </div>
  )
}
