export default function AdminReportesPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
      <h1 className="text-2xl font-bold text-slate-50 mb-2">Reportes</h1>
      <p className="text-slate-400">Esta sección está disponible en la Fase 2.</p>
    </div>
  )
}
