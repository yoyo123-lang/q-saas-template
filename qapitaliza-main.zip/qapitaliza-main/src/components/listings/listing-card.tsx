import Link from 'next/link'
import Image from 'next/image'
import { Heart } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { TechPill } from '@/components/listings/tech-pill'
import { LogoQ } from '@/components/shared/logo-q'

const typeLabels: Record<string, string> = {
  WEBSITE: 'Sitio Web',
  DOMAIN: 'Dominio',
  SAAS: 'SaaS',
  ECOMMERCE: 'E-commerce',
  PROJECT: 'Proyecto',
  OTHER: 'Otro',
}

function formatMetricValue(value: number): string {
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`
  if (value >= 1000) return `${(value / 1000).toFixed(1)}k`
  return value.toString()
}

interface ListingCardMetrics {
  mrr?: number
  monthlyVisits?: number
  users?: number
  orders?: number
  da?: number
  age?: string
}

interface ListingCardProps {
  id: string
  slug: string
  title: string
  type: string
  priceUsd: number
  screenshot?: string
  metrics?: ListingCardMetrics
  techStack?: string[]
  badges?: ('verified' | 'featured' | 'premium')[]
  isFavorited?: boolean
  onFavoriteToggle?: (id: string) => void
}

function MetricRow({ metrics }: { metrics: ListingCardMetrics }) {
  const items: { label: string; value: string }[] = []

  if (metrics.mrr != null) items.push({ label: 'MRR', value: `$${formatMetricValue(metrics.mrr)}` })
  if (metrics.monthlyVisits != null)
    items.push({ label: 'visitas/mes', value: formatMetricValue(metrics.monthlyVisits) })
  if (metrics.users != null)
    items.push({ label: 'usuarios', value: formatMetricValue(metrics.users) })
  if (metrics.orders != null)
    items.push({ label: 'orders/mes', value: metrics.orders.toString() })
  if (metrics.da != null) items.push({ label: 'DA', value: metrics.da.toString() })
  if (metrics.age) items.push({ label: 'online', value: metrics.age })

  const displayed = items.slice(0, 2)
  if (displayed.length === 0) return null

  return (
    <div className="flex items-center gap-4 text-sm text-slate-400">
      {displayed.map((m) => (
        <span key={m.label}>
          {m.value} {m.label}
        </span>
      ))}
    </div>
  )
}

export function ListingCard({
  id,
  slug,
  title,
  type,
  priceUsd,
  screenshot,
  metrics = {},
  techStack = [],
  badges = [],
  isFavorited = false,
  onFavoriteToggle,
}: ListingCardProps) {
  return (
    <div className="bg-navy-900 border border-slate-800 rounded-xl overflow-hidden transition-all duration-200 hover:border-amber-500/30 hover:shadow-lg hover:shadow-amber-500/5 flex flex-col">
      {/* Screenshot */}
      <Link href={`/explorar/${slug}`} className="block relative h-40 bg-slate-900 flex-shrink-0">
        {screenshot ? (
          <Image
            src={screenshot}
            alt={title}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
            <LogoQ size="md" />
          </div>
        )}
      </Link>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1 gap-3">
        {/* Badges row */}
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="info">{typeLabels[type] ?? type}</Badge>
          {badges.includes('verified') && (
            <Badge variant="success" dot>Verificado</Badge>
          )}
          {badges.includes('featured') && (
            <Badge variant="amber">Destacado</Badge>
          )}
          {badges.includes('premium') && (
            <Badge variant="amber">Premium</Badge>
          )}
        </div>

        {/* Title */}
        <Link href={`/explorar/${slug}`}>
          <h3 className="text-base font-semibold text-slate-50 leading-snug line-clamp-2 hover:text-amber-400 transition-colors">
            {title}
          </h3>
        </Link>

        {/* Price */}
        <p className="text-xl font-bold text-amber-500">
          {Number.isFinite(priceUsd) ? `$${priceUsd.toLocaleString('en-US')} USD` : 'Precio a consultar'}
        </p>

        <div className="h-px bg-slate-800" />

        {/* Metrics */}
        <MetricRow metrics={metrics} />

        {/* Tech stack */}
        {techStack.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {techStack.slice(0, 3).map((tech) => (
              <TechPill key={tech} tech={tech} />
            ))}
            {techStack.length > 3 && (
              <span className="font-mono text-xs bg-slate-800 text-slate-400 px-3 py-1 rounded-full">
                +{techStack.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 mt-auto pt-1">
          {onFavoriteToggle ? (
            <button
              onClick={() => onFavoriteToggle(id)}
              aria-label={isFavorited ? 'Quitar de favoritos' : 'Guardar en favoritos'}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-amber-500 text-amber-500 text-sm font-medium hover:bg-amber-500/10 transition-colors flex-shrink-0"
            >
              <Heart className={`size-4 ${isFavorited ? 'fill-amber-500' : ''}`} />
            </button>
          ) : (
            <Link
              href="/login"
              aria-label="Guardar en favoritos"
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-amber-500 text-amber-500 text-sm font-medium hover:bg-amber-500/10 transition-colors flex-shrink-0"
            >
              <Heart className="size-4" />
            </Link>
          )}
          <Link
            href={`/explorar/${slug}`}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 text-navy-950 text-sm font-medium hover:bg-amber-400 transition-colors text-center"
          >
            Ver activo →
          </Link>
        </div>
      </div>
    </div>
  )
}
