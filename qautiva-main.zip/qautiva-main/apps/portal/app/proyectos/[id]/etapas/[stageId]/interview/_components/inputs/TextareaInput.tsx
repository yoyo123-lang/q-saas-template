'use client'

import type { QuestionBlock } from '@/app/_lib/interview/types'

export function TextareaInput({
  value,
  onChange,
  placeholder,
  disabled,
  validation,
}: {
  value: string
  onChange: (v: unknown) => void
  placeholder: string
  disabled: boolean
  validation?: QuestionBlock['validation']
}) {
  return (
    <div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder || 'Escribí tu respuesta...'}
        disabled={disabled}
        maxLength={validation?.maxLength}
        rows={4}
        className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-4 py-3 text-white placeholder-[#334155] text-base outline-none transition-colors resize-none disabled:opacity-50 disabled:cursor-not-allowed"
      />
      {validation?.maxLength && (
        <p className="text-right text-xs text-[#475569] mt-1">
          {value.length}/{validation.maxLength}
        </p>
      )}
    </div>
  )
}
