'use client'

import { useState } from 'react'

const PROVIDER_LABELS: Record<string, string> = {
  ANTHROPIC: 'Anthropic',
  OPENAI: 'OpenAI',
  GOOGLE_GEMINI: 'Google Gemini',
}

export type ApiKeyData = {
  id: string
  provider: string
  keyHint: string
  label: string | null
  isValid: boolean | null
  lastUsedAt: Date | string | null
  lastError: string | null
  createdAt: Date | string
}

type Props = {
  apiKey: ApiKeyData
  onRevoke: (id: string) => Promise<void>
}

export function ApiKeyCard({ apiKey, onRevoke }: Props) {
  const [isRevoking, setIsRevoking] = useState(false)

  async function handleRevoke() {
    if (!confirm(`¿Querés revocar la key de ${PROVIDER_LABELS[apiKey.provider] ?? apiKey.provider}? Esta acción no se puede deshacer.`)) return
    setIsRevoking(true)
    await onRevoke(apiKey.id)
    setIsRevoking(false)
  }

  const lastUsed = apiKey.lastUsedAt
    ? new Date(apiKey.lastUsedAt).toLocaleDateString('es-AR', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    : null

  return (
    <div className="flex items-center justify-between py-3 border-b border-[#1E293B] last:border-0 gap-3">
      <div className="flex flex-col gap-0.5 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-white text-sm font-medium">
            {PROVIDER_LABELS[apiKey.provider] ?? apiKey.provider}
          </span>
          {apiKey.isValid === true && (
            <span className="bg-[#10B981]/10 border border-[#10B981]/30 text-[#34D399] text-xs px-2 py-0.5 rounded-full">
              Válida
            </span>
          )}
          {apiKey.isValid === false && (
            <span className="bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-xs px-2 py-0.5 rounded-full">
              Inválida
            </span>
          )}
          {apiKey.isValid === null && (
            <span className="bg-[#F59E0B]/10 border border-[#F59E0B]/30 text-[#FCD34D] text-xs px-2 py-0.5 rounded-full">
              Sin verificar
            </span>
          )}
        </div>
        <div className="flex items-center gap-3 text-xs text-[#64748B]">
          <span className="font-mono">{apiKey.keyHint}</span>
          {apiKey.label && <span>· {apiKey.label}</span>}
          {lastUsed && <span>· Usada el {lastUsed}</span>}
        </div>
        {apiKey.lastError && (
          <p className="text-xs text-[#EF4444] mt-0.5 truncate">{apiKey.lastError}</p>
        )}
      </div>

      <button
        onClick={handleRevoke}
        disabled={isRevoking}
        className="shrink-0 text-xs text-[#EF4444] hover:text-red-300 disabled:opacity-50 transition-colors"
      >
        {isRevoking ? 'Revocando…' : 'Revocar'}
      </button>
    </div>
  )
}
