import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'

export default async function HomePage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const meta = user.app_metadata ?? {}

  // Usuarios legacy (asignados manualmente con org_id) → flujo original
  if (meta.org_id) redirect('/progreso')

  // Usuarios self-service → hub de proyectos
  if (meta.onboarding_complete) redirect('/proyectos')

  // Sin onboarding completo → wizard de cuenta
  redirect('/onboarding')
}
