import { cn } from '@/lib/utils/cn'

type AvatarRole = 'SELLER' | 'BUYER' | 'ADMIN'

interface AvatarProps {
  initials: string
  role?: AvatarRole
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

const roleColors: Record<AvatarRole, string> = {
  SELLER: 'bg-amber-500/20 text-amber-500',
  BUYER:  'bg-blue-500/20 text-blue-500',
  ADMIN:  'bg-purple-500/20 text-purple-400',
}

const sizeClasses = {
  sm: 'size-7 text-xs',
  md: 'size-9 text-sm',
  lg: 'size-12 text-base',
}

export function Avatar({ initials, role = 'BUYER', size = 'md', className }: AvatarProps) {
  return (
    <div
      className={cn(
        'rounded-full flex items-center justify-center font-semibold flex-shrink-0',
        roleColors[role],
        sizeClasses[size],
        className
      )}
      aria-label={`Avatar de ${initials}`}
    >
      {initials.slice(0, 2).toUpperCase()}
    </div>
  )
}
