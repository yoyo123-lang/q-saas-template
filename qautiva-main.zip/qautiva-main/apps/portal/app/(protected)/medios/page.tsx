import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { Download } from 'lucide-react'

export const metadata: Metadata = { title: 'Medios — Qautiva' }


function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function getFileIcon(mimetype?: string): string {
  if (!mimetype) return '📄'
  if (mimetype.startsWith('image/')) return '🖼️'
  if (mimetype === 'application/pdf') return '📑'
  if (mimetype.startsWith('video/')) return '🎬'
  return '📄'
}

export default async function MediosPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  const orgId = user?.app_metadata?.org_id as string | undefined

  if (!orgId) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-4">Medios</h1>
        <p className="text-[#94A3B8]">No hay un proyecto asignado a tu cuenta.</p>
      </div>
    )
  }

  // Listar archivos del bucket de assets de la org
  const { data: files, error } = await supabase.storage
    .from('org-assets')
    .list(`${orgId}/`, { limit: 100, sortBy: { column: 'name', order: 'asc' } })

  if (error) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-4">Medios</h1>
        <div className="bg-[#0F172A] border border-[#EF4444]/30 rounded-xl p-6">
          <p className="text-[#EF4444] text-sm">No se pudieron cargar los archivos. Intentá de nuevo más tarde.</p>
        </div>
      </div>
    )
  }

  const assets = (files ?? []).filter((f) => f.name !== '.emptyFolderPlaceholder')

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Medios</h1>
        <p className="text-[#64748B] text-sm mt-1">Assets de tu marca y materiales entregados</p>
      </div>

      {assets.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {assets.map((file) => {
            const { data: urlData } = supabase.storage
              .from('org-assets')
              .getPublicUrl(`${orgId}/${file.name}`)

            const size = (file.metadata as { size?: number } | null)?.size
            const mimetype = (file.metadata as { mimetype?: string } | null)?.mimetype

            return (
              <div
                key={file.id}
                className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 flex items-start gap-3"
              >
                <span className="text-2xl flex-shrink-0" aria-hidden="true">
                  {getFileIcon(mimetype)}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{file.name}</p>
                  {size !== undefined && (
                    <p className="text-[#64748B] text-xs mt-0.5">{formatBytes(size)}</p>
                  )}
                </div>
                <a
                  href={urlData.publicUrl}
                  download={file.name}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 text-[#64748B] hover:text-[#A78BFA] transition-colors duration-200"
                  aria-label={`Descargar ${file.name}`}
                >
                  <Download size={16} aria-hidden="true" />
                </a>
              </div>
            )
          })}
        </div>
      ) : (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">
            Tus assets de marca aparecen acá cuando estén listos.
          </p>
        </div>
      )}
    </div>
  )
}
