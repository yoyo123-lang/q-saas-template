'use client'

import { useCallback, useEffect, useState } from 'react'
import { useRouter, useSearchParams, usePathname } from 'next/navigation'

interface KanbanFiltersProps {
  industries: string[]
}

export function KanbanFilters({ industries }: KanbanFiltersProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  // Estado local para el input de búsqueda (se actualiza sin round-trip al servidor)
  const [searchValue, setSearchValue] = useState(searchParams.get('q') ?? '')

  // Debounce: sólo actualiza la URL 400ms después de que el usuario deja de tipear
  useEffect(() => {
    const timer = setTimeout(() => {
      const params = new URLSearchParams(searchParams.toString())
      if (searchValue) {
        params.set('q', searchValue)
      } else {
        params.delete('q')
      }
      router.push(`${pathname}?${params.toString()}`)
    }, 400)
    return () => clearTimeout(timer)
  }, [searchValue, router, pathname, searchParams])

  const updateParam = useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(searchParams.toString())
      if (value) {
        params.set(key, value)
      } else {
        params.delete(key)
      }
      router.push(`${pathname}?${params.toString()}`)
    },
    [router, pathname, searchParams],
  )

  const planValue     = searchParams.get('plan') ?? ''
  const industryValue = searchParams.get('industry') ?? ''
  const statusValue   = searchParams.get('status') ?? ''

  // Clases base + highlight cuando el filtro está activo
  const selectBase   = 'px-3 py-2 rounded-lg bg-[#0F172A] text-sm cursor-pointer transition-colors'
  const selectIdle   = 'border border-[#1E293B] text-[#94A3B8]'
  const selectActive = 'border border-[#3B82F6] text-white'

  return (
    <div className="flex items-center gap-3 flex-wrap">
      <select
        value={planValue}
        onChange={(e) => updateParam('plan', e.target.value)}
        className={`${selectBase} ${planValue ? selectActive : selectIdle}`}
        aria-label="Filtrar por plan"
      >
        <option value="">Plan</option>
        <option value="BASE">Base</option>
        <option value="COMPLETO">Completo</option>
        <option value="PREMIUM">Premium</option>
      </select>

      <select
        value={industryValue}
        onChange={(e) => updateParam('industry', e.target.value)}
        className={`${selectBase} ${industryValue ? selectActive : selectIdle}`}
        aria-label="Filtrar por rubro"
      >
        <option value="">Rubro</option>
        {industries.map((ind) => (
          <option key={ind} value={ind}>{ind}</option>
        ))}
      </select>

      <select
        value={statusValue}
        onChange={(e) => updateParam('status', e.target.value)}
        className={`${selectBase} ${statusValue ? selectActive : selectIdle}`}
        aria-label="Filtrar por estado"
      >
        <option value="">Estado</option>
        <option value="En proceso">En proceso</option>
        <option value="Espera cliente">Espera cliente</option>
        <option value="Espera revisión">Espera revisión</option>
      </select>

      <input
        type="search"
        value={searchValue}
        onChange={(e) => setSearchValue(e.target.value)}
        placeholder="Buscar cliente..."
        className={`px-3 py-2 rounded-lg bg-[#0F172A] placeholder-[#64748B] text-sm w-48 transition-colors ${searchValue ? 'border border-[#3B82F6] text-white' : 'border border-[#1E293B] text-[#94A3B8]'}`}
        aria-label="Buscar cliente"
      />
    </div>
  )
}
