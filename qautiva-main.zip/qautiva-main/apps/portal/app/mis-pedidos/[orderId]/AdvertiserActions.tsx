'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { OrderStatus } from '@qautiva/db/types'

type Props = {
  orderId: string
  currentStatus: OrderStatus
}

const inputClass =
  'w-full bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-[#334155] placeholder-[#475569] resize-none'

export function AdvertiserActions({ orderId, currentStatus }: Props) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Correcciones
  const [revisionNote, setRevisionNote] = useState('')
  const [showRevisionForm, setShowRevisionForm] = useState(false)

  // Disputa
  const [disputeReason, setDisputeReason] = useState('')
  const [showDisputeForm, setShowDisputeForm] = useState(false)

  if (currentStatus !== OrderStatus.DELIVERED) return null

  async function patch(status: OrderStatus, extra?: Record<string, string>) {
    setError(null)
    setLoading(true)
    try {
      const res = await fetch(`/api/marketplace/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, ...extra }),
      })
      const data = (await res.json()) as { error?: string }
      if (!res.ok) {
        setError(data.error ?? 'Ocurrió un error.')
        return
      }
      router.refresh()
    } catch {
      setError('No se pudo conectar con el servidor.')
    } finally {
      setLoading(false)
    }
  }

  function handleApprove() {
    if (!window.confirm('¿Estás seguro de aprobar la entrega? Esta acción libera el pago al editor y no se puede deshacer.')) return
    patch(OrderStatus.COMPLETED)
  }

  return (
    <section aria-label="Acciones del pedido" className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4">
      <h2 className="text-white font-semibold">Revisá la entrega</h2>
      <p className="text-[#94A3B8] text-sm">
        El editor entregó el pedido. Revisá el contenido y elegí una opción.
      </p>

      {/* Form de correcciones */}
      {showRevisionForm && (
        <div className="flex flex-col gap-3">
          <label htmlFor="revisionNote" className="text-white font-semibold text-sm">
            ¿Qué debe corregir el editor? <span className="text-red-400">*</span>
          </label>
          <textarea
            id="revisionNote"
            rows={3}
            maxLength={2000}
            placeholder="Describí los cambios que necesitás…"
            value={revisionNote}
            onChange={(e) => setRevisionNote(e.target.value)}
            className={inputClass}
          />
          <div className="flex gap-2 flex-wrap">
            <button
              type="button"
              disabled={loading || !revisionNote.trim()}
              onClick={() => patch(OrderStatus.REVISION, { cancellationReason: revisionNote.trim() })}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-orange-900/40 text-orange-400 hover:bg-orange-900/60 disabled:opacity-50 transition-colors"
            >
              Enviar correcciones
            </button>
            <button
              type="button"
              onClick={() => { setShowRevisionForm(false); setRevisionNote('') }}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] transition-colors"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Form de disputa */}
      {showDisputeForm && (
        <div className="flex flex-col gap-3">
          <label htmlFor="disputeReason" className="text-white font-semibold text-sm">
            Motivo de la disputa <span className="text-red-400">*</span>
          </label>
          <p className="text-[#64748B] text-xs">
            Nuestro equipo revisará tu caso. Describí el problema con el mayor detalle posible.
          </p>
          <textarea
            id="disputeReason"
            rows={4}
            maxLength={2000}
            placeholder="Ej: El contenido publicado no sigue el brief. No se incluyeron las palabras clave solicitadas y el enlace apunta a una URL diferente…"
            value={disputeReason}
            onChange={(e) => setDisputeReason(e.target.value)}
            className={inputClass}
          />
          <div className="flex gap-2 flex-wrap">
            <button
              type="button"
              disabled={loading || !disputeReason.trim()}
              onClick={() => patch(OrderStatus.DISPUTED, { cancellationReason: disputeReason.trim() })}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-[#3B1414] text-red-400 hover:bg-[#4A1A1A] disabled:opacity-50 transition-colors"
            >
              Abrir disputa
            </button>
            <button
              type="button"
              onClick={() => { setShowDisputeForm(false); setDisputeReason('') }}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] transition-colors"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Botones principales — solo cuando no hay formulario abierto */}
      {!showRevisionForm && !showDisputeForm && (
        <div className="flex gap-2 flex-wrap">
          <button
            type="button"
            disabled={loading}
            onClick={handleApprove}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-[#0F2E2A] text-[#34D399] hover:bg-[#0F3A34] disabled:opacity-50 transition-colors"
          >
            ✓ Aprobar entrega
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={() => setShowRevisionForm(true)}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-[#3B2A0F] text-orange-400 hover:bg-[#4A3312] disabled:opacity-50 transition-colors"
          >
            Pedir correcciones
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={() => setShowDisputeForm(true)}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-[#3B1414] text-red-400 hover:bg-[#4A1A1A] disabled:opacity-50 transition-colors"
          >
            Abrir disputa
          </button>
        </div>
      )}

      {error && (
        <p role="alert" className="text-red-400 text-xs">{error}</p>
      )}
    </section>
  )
}
