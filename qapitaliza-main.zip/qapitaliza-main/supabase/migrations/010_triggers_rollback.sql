-- ============================================================
-- ROLLBACK 010 — Triggers
-- ============================================================

-- Triggers de updated_at
DROP TRIGGER IF EXISTS trg_profiles_updated_at   ON public.profiles;
DROP TRIGGER IF EXISTS trg_listings_updated_at   ON public.listings;
DROP TRIGGER IF EXISTS trg_inquiries_updated_at  ON public.inquiries;

-- Trigger de mensaje nuevo
DROP TRIGGER IF EXISTS trg_inquiry_message_inserted ON public.inquiry_messages;
DROP FUNCTION IF EXISTS public.update_inquiry_on_new_message();

-- Trigger de auto-crear perfil
DROP TRIGGER IF EXISTS trg_on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Trigger de published_at
DROP TRIGGER IF EXISTS trg_listings_published_at ON public.listings;
DROP FUNCTION IF EXISTS public.set_published_at();

-- Funciones
DROP FUNCTION IF EXISTS public.increment_listing_views(UUID);
DROP FUNCTION IF EXISTS public.set_updated_at();
