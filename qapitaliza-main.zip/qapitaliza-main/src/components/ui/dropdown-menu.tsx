'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { MoreHorizontal } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

export interface DropdownMenuItem {
  label: string
  icon?: React.ReactNode
  onClick?: () => void
  href?: string
  danger?: boolean
}

interface DropdownMenuProps {
  items: DropdownMenuItem[]
  align?: 'left' | 'right'
}

export function DropdownMenu({ items, align = 'right' }: DropdownMenuProps) {
  const [open, setOpen] = useState(false)
  const [focusedIndex, setFocusedIndex] = useState(-1)
  const menuRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)

  const focusItem = useCallback((index: number) => {
    const el = menuRef.current?.querySelectorAll<HTMLElement>('[role="menuitem"]')[index]
    el?.focus()
    setFocusedIndex(index)
  }, [])

  useEffect(() => {
    if (!open) return
    const onClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false)
        setFocusedIndex(-1)
      }
    }
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false)
        setFocusedIndex(-1)
        triggerRef.current?.focus()
        return
      }
      const menuItems = menuRef.current?.querySelectorAll<HTMLElement>('[role="menuitem"]')
      if (!menuItems) return
      const count = menuItems.length
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        focusItem((focusedIndex + 1) % count)
      } else if (e.key === 'ArrowUp') {
        e.preventDefault()
        focusItem((focusedIndex - 1 + count) % count)
      } else if (e.key === 'Home') {
        e.preventDefault()
        focusItem(0)
      } else if (e.key === 'End') {
        e.preventDefault()
        focusItem(count - 1)
      }
    }
    document.addEventListener('mousedown', onClickOutside)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('mousedown', onClickOutside)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open, focusedIndex, focusItem])

  return (
    <div ref={menuRef} className="relative inline-block">
      <button
        ref={triggerRef}
        onClick={() => { setOpen((v) => !v); setFocusedIndex(-1) }}
        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-50 hover:bg-slate-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
        aria-label="Opciones"
        aria-expanded={open}
        aria-haspopup="menu"
      >
        <MoreHorizontal className="size-4" />
      </button>

      {open && (
        <div
          role="menu"
          className={cn(
            'absolute z-50 top-full mt-1 w-44 bg-navy-900 border border-slate-800 rounded-xl shadow-xl overflow-hidden',
            align === 'right' ? 'right-0' : 'left-0'
          )}
        >
          {items.map((item, idx) =>
            item.href ? (
              <a
                key={idx}
                href={item.href}
                role="menuitem"
                className={cn(
                  'flex items-center gap-2.5 px-3 py-2.5 text-sm transition-colors',
                  item.danger
                    ? 'text-red-400 hover:bg-red-500/10'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-slate-50'
                )}
                onClick={() => setOpen(false)}
              >
                {item.icon && <span className="size-4 flex items-center">{item.icon}</span>}
                {item.label}
              </a>
            ) : (
              <button
                key={idx}
                role="menuitem"
                className={cn(
                  'w-full flex items-center gap-2.5 px-3 py-2.5 text-sm transition-colors text-left',
                  item.danger
                    ? 'text-red-400 hover:bg-red-500/10'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-slate-50'
                )}
                onClick={() => {
                  setOpen(false)
                  item.onClick?.()
                }}
              >
                {item.icon && <span className="size-4 flex items-center">{item.icon}</span>}
                {item.label}
              </button>
            )
          )}
        </div>
      )}
    </div>
  )
}
