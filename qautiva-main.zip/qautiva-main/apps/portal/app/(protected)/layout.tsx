import { cookies } from 'next/headers'
import { unstable_cache } from 'next/cache'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { ClientSidebar } from '@/components/ClientSidebar'
import { TopBar } from '@/components/TopBar'
import { SidebarProvider } from '@/components/SidebarContext'
import { MobileSidebarWrapper } from '@/components/MobileSidebarWrapper'

/** Cachea la info de org por orgId durante 60 segundos para evitar un DB call por cada page navigation */
const getOrgInfo = unstable_cache(
  async (orgId: string) => {
    return prisma.organization.findUnique({
      where: { id: orgId },
      select: { name: true, status: true },
    })
  },
  ['org-info'],
  { revalidate: 60 },
)

/** Cachea si el usuario tiene medios en el marketplace (para visibilidad de "Mis Ventas") */
const getUserHasMedios = unstable_cache(
  async (authUserId: string) => {
    const profile = await prisma.userProfile.findUnique({
      where: { authUserId },
      select: { _count: { select: { media: { where: { deletedAt: null } } } } },
    })
    return (profile?._count.media ?? 0) > 0
  },
  ['user-has-medios'],
  { revalidate: 60 },
)

export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  let orgName = ''
  let orgStatus = ''
  let hasMedia = false

  if (user?.app_metadata?.org_id) {
    const org = await getOrgInfo(user.app_metadata.org_id as string)
    orgName = org?.name ?? ''
    orgStatus = org?.status ?? ''

    // Métricas visibles a partir de LAUNCHED
    // Medios visibles si hay assets en la org (comprobamos via Storage en la página /medios)
    // Para el sidebar usamos solo el status
    hasMedia = orgStatus === 'LAUNCHED' || orgStatus === 'MEDIA'
  }

  const showMetrics = orgStatus === 'LAUNCHED'
  const showMedia = hasMedia
  const showCampaigns = orgStatus === 'CAMPAIGNS' || orgStatus === 'LAUNCHED'
  const hasMedios = user ? await getUserHasMedios(user.id) : false

  return (
    <SidebarProvider>
      <div className="flex flex-col min-h-screen bg-[#0B0F1A]">
        <TopBar hasMedios={hasMedios} />
        <MobileSidebarWrapper
          sidebar={
            <ClientSidebar
              orgName={orgName}
              showMetrics={showMetrics}
              showMedia={showMedia}
              showCampaigns={showCampaigns}
            />
          }
        >
          {children}
        </MobileSidebarWrapper>
      </div>
    </SidebarProvider>
  )
}
