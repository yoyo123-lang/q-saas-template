import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = fileURLToPath(new URL('.', import.meta.url))

/** @type {import('next').NextConfig} */
const config = {
  outputFileTracingRoot: path.join(__dirname, '../../'),
  experimental: {
    outputFileTracingIncludes: {
      '/api/**': ['../../packages/db/generated/client/**'],
    },
    // Next.js 14: las external packages van dentro de experimental
    // Handlebars (CommonJS puro), jsdom e isomorphic-dompurify no se pueden bundlear con webpack
    serverComponentsExternalPackages: [
      'handlebars',
      'isomorphic-dompurify',
      'jsdom',
      'google-ads-api',
      'google-ads-node',
      '@grpc/grpc-js',
      '@grpc/proto-loader',
    ],
  },
  transpilePackages: ['@qautiva/db'],
  // webpack externals como fallback: serverComponentsExternalPackages no aplica
  // a imports que vienen desde workspace packages transpilados (transpilePackages).
  // jsdom/isomorphic-dompurify bundleados rompen la ruta a default-stylesheet.css.
  webpack(config, { isServer }) {
    if (isServer) {
      config.externals.push('jsdom', 'isomorphic-dompurify', 'canvas', 'sharp')
    }
    return config
  },
  // Fallbacks para build en entornos sin .env (CI, build local sin vars).
  // En producción (Vercel) las vars reales sobreescriben estos valores.
  env: {
    NEXT_PUBLIC_SUPABASE_URL:
      process.env.NEXT_PUBLIC_SUPABASE_URL ?? 'https://placeholder.supabase.co',
    NEXT_PUBLIC_SUPABASE_ANON_KEY:
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? 'placeholder-anon-key',
  },
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      // Supabase Storage (imágenes de deliverables, logos de marca)
      {
        protocol: 'https',
        hostname: '*.supabase.co',
        pathname: '/storage/v1/object/**',
      },
      // Supabase Storage via proyecto custom (por si acaso)
      {
        protocol: 'https',
        hostname: '*.supabase.in',
        pathname: '/storage/v1/object/**',
      },
      // Google Storage / Gemini imagen generada (URLs temporales de Gemini Image)
      {
        protocol: 'https',
        hostname: 'storage.googleapis.com',
      },
      {
        protocol: 'https',
        hostname: '*.googleapis.com',
      },
    ],
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
    ]
  },
}

export default config
