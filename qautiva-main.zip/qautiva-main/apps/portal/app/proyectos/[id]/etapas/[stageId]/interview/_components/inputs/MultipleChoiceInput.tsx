'use client'

import type { QuestionBlock } from '@/app/_lib/interview/types'

export function MultipleChoiceInput({
  options,
  value,
  onChange,
  disabled,
}: {
  options: QuestionBlock['options'] & {}
  value: string
  onChange: (v: unknown) => void
  disabled: boolean
}) {
  if (options.length === 0) {
    return (
      <p className="text-[#64748B] text-sm">No hay opciones configuradas para esta pregunta.</p>
    )
  }

  return (
    <div className="flex flex-col gap-2" role="radiogroup">
      {options.map((opt) => {
        const selected = value === opt.value
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={selected}
            disabled={disabled}
            onClick={() => onChange(opt.value)}
            className={`w-full text-left px-4 py-3 rounded-lg border transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed ${
              selected
                ? 'bg-[#8B5CF6]/10 border-[#8B5CF6] text-white'
                : 'bg-[#0B0F1A] border-[#1E293B] text-[#94A3B8] hover:border-[#334155] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`w-4 h-4 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
                  selected ? 'border-[#8B5CF6]' : 'border-[#334155]'
                }`}
                aria-hidden="true"
              >
                {selected && <div className="w-2 h-2 rounded-full bg-[#8B5CF6]" />}
              </div>
              <span className="text-sm font-medium">{opt.label}</span>
            </div>
          </button>
        )
      })}
    </div>
  )
}
