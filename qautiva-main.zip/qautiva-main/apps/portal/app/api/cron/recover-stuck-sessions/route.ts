import { NextResponse, type NextRequest } from 'next/server'
import { prisma, Prisma } from '@qautiva/db'
import { processSession, type SessionToProcess } from '@/app/_lib/interview/session-processor'

// Pro plan: hasta 300s. Cada sesión tarda ~20-50s en Anthropic, procesamos 3 en serie.
export const maxDuration = 300

// Sesiones PROCESSING sin actividad por más de este tiempo se consideran bloqueadas
const STUCK_THRESHOLD_MS = 5 * 60 * 1000 // 5 minutos

/**
 * GET /api/cron/recover-stuck-sessions
 *
 * Recupera sesiones bloqueadas en estado PROCESSING por más de 5 minutos.
 * Invocado por Vercel Cron cada 5 minutos.
 *
 * Autenticación: CRON_SECRET en el header Authorization.
 */
export async function GET(request: NextRequest) {
  const cronSecret = process.env.CRON_SECRET
  const authHeader = request.headers.get('authorization')
  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const stuckBefore = new Date(Date.now() - STUCK_THRESHOLD_MS)

  const stuckSessions = await prisma.interviewSession.findMany({
    where: {
      status: 'PROCESSING',
      OR: [
        // /process fue llamado pero no completó (processingStartedAt seteado por el lock atómico)
        { processingStartedAt: { lt: stuckBefore } },
        // /process nunca fue llamado (cliente crasheó antes de llamarlo)
        { processingStartedAt: null, updatedAt: { lt: stuckBefore } },
      ],
    },
    select: {
      id: true,
      flowDefinition: true,
      answers: true,
      retryCount: true,
      maxRetries: true,
      stageId: true,
      projectId: true,
      teamId: true,
      selectedWebTemplateId: true,
      stage: { select: { stageKey: true } },
      project: { select: { brandKit: true } },
    },
    // Máximo 2: cada sesión tarda ~20-90s en Anthropic (timeout 90s).
    // Con maxDuration=300s, 2 sesiones = máx 180s + overhead, margen seguro.
    take: 2,
  })

  if (stuckSessions.length === 0) {
    return NextResponse.json({ ok: true, recovered: 0 })
  }

  // Procesar en serie para respetar el rate limit de Anthropic y el timeout de 60s.
  // El cron corre cada 5 min — si hay > 3 sesiones stuck, las restantes se procesan
  // en la siguiente ejecución.
  const results: boolean[] = []
  for (const session of stuckSessions) {
    results.push(await recoverSession({ ...session, stageKey: session.stage?.stageKey ?? '' }))
  }

  const recovered = results.filter(Boolean).length
  const failed = results.length - recovered

  console.info('[cron/recover-stuck-sessions]', { total: stuckSessions.length, recovered, failed })

  return NextResponse.json({ ok: true, recovered, failed })
}

type StuckSession = SessionToProcess & {
  retryCount: number
  maxRetries: number
}

async function recoverSession(session: StuckSession): Promise<boolean> {
  // WEBSITE sessions without a template are not stuck — they're waiting for user input.
  // Don't process them; the user will trigger /process after selecting a template.
  if (session.stageKey === 'WEBSITE' && !session.selectedWebTemplateId) {
    console.info('[cron/recover-stuck-sessions] skipping WEBSITE session pending template selection', { sessionId: session.id })
    return true
  }

  if (session.retryCount >= session.maxRetries) {
    await prisma.interviewSession.update({
      where: { id: session.id },
      data: { status: 'ERROR', lastError: 'Máximo de reintentos alcanzado' },
    })
    return false
  }

  // Atomic lock: mismo patrón que /process para evitar duplicar llamadas a Anthropic
  // si el cliente también llama /process mientras el cron intenta recuperar la sesión.
  const PROCESSING_LOCK_MS = 2 * 60 * 1000
  const claimed = await prisma.interviewSession.updateMany({
    where: {
      id: session.id,
      status: 'PROCESSING',
      OR: [
        { processingStartedAt: null },
        { processingStartedAt: { lt: new Date(Date.now() - PROCESSING_LOCK_MS) } },
      ],
    },
    data: { processingStartedAt: new Date() },
  })
  if (claimed.count === 0) {
    console.info('[cron/recover-stuck-sessions] lock not acquired, skipping', { sessionId: session.id })
    return true // otro actor ya tomó el lock — no es un fallo
  }

  return processSession(session, 'cron/recover-stuck-sessions')
}
