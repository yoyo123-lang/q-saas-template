import { notFound } from 'next/navigation'
import { getAdminListing } from '@/lib/data/admin'
import { AdminListingReview } from './review-client'

interface PageProps {
  params: Promise<{ id: string }>
}

export default async function AdminListingDetailPage({ params }: PageProps) {
  const { id } = await params
  const listing = await getAdminListing(id)
  if (!listing) notFound()
  return <AdminListingReview listing={listing} />
}
