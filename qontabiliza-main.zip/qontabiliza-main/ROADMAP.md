# Roadmap: Qontabiliza

## Visión

ERP SaaS para PyMEs argentinas que venden productos. Facturación electrónica ARCA, stock, ventas, compras, tesorería y contabilidad — integrado nativamente con el ecosistema Q Company (Qobra, Qontacta, Qautiva, Qapitaliza).

**Fase actual**: Fase 1 — MVP Vendible.

## Decisiones técnicas clave

| Decisión | Elección | Razón |
|----------|----------|-------|
| Multi-tenancy | DB compartida + `tenantId` por tabla | Simple, Prisma ya configurado, suficiente para miles de tenants |
| Facturación ARCA | Afip SDK (Node.js) | Open source, 100k+ descargas, sin costo por comprobante |
| Integración Qobra | Mock en Fase 1 | Qobra no está listo; interfaz preparada para integración real |
| Primer caso de uso | Comercio genérico PyME | No IEA (educación tiene flujos diferentes) |
| Plataforma | Web-only | Mobile/tablet en fases posteriores |
| Auth | NextAuth v5 (ya en template) + capa de tenant | Extender el auth existente, no reemplazarlo |

## Módulos — Fase 1 (MVP Vendible)

| # | Módulo | Descripción | Capa | Depende de | Sesiones est. | Prioridad |
|---|--------|-------------|------|------------|---------------|-----------|
| M1 | Multi-tenancy | Organizaciones, membresías, contexto de tenant, tenant-scoping en queries | Full | — | 2 | Crítico |
| M2 | Productos y catálogo | Productos con variantes, categorías, códigos de barras, listas de precios | Full | M1 | 2 | Crítico |
| M3 | Clientes y proveedores | CRUD con datos fiscales (CUIT, condición IVA, domicilio fiscal) | Full | M1 | 1 | Crítico |
| M4 | Facturación ARCA | Facturas A/B/C, notas de crédito/débito, integración Afip SDK, PDF | Full | M1, M3 | 2 | Crítico |
| M5 | Ventas y POS | Pantalla de venta rápida, búsqueda de productos, múltiples medios de pago | Full | M2, M3, M4, M6 | 2 | Crítico |
| M6 | Stock básico | Un depósito, movimientos entrada/salida, alertas de stock bajo | Full | M1, M2 | 1 | Crítico |
| M7 | Tesorería básica | Caja diaria, medios de pago, mock Qobra | Full | M1 | 1 | Importante |
| M8 | Reportes esenciales | Ventas del día/mes, libro IVA, cuentas a cobrar, dashboard | Full | M4, M5 | 1 | Importante |
| M9 | Suscripciones y onboarding | Planes (Micro/Starter/Pro/Max), límites de uso, wizard de alta | Full | M1 | 1 | Importante |
| M10 | QA y polish | Tests E2E, revisión de errores, performance, UX final | Full | Todos | 1 | Importante |

## Módulos — Fase 2 (Paridad con La Pyme) — *solo referencia*

| # | Módulo | Descripción | Prioridad |
|---|--------|-------------|-----------|
| M11 | Compras | Órdenes de compra, recepción de mercadería, importación desde ARCA | Crítico |
| M12 | Multi-depósito | Transferencias entre depósitos, stock por ubicación | Importante |
| M13 | Tesorería avanzada | Bancos, cheques, liquidaciones de tarjeta, apertura/cierre de caja | Crítico |
| M14 | Cuentas corrientes | Saldos clientes/proveedores, cobranzas parciales, resúmenes | Importante |
| M15 | Integración Mercado Libre | Sync stock, precios, facturación automática | Importante |
| M16 | Integración Tiendanube | Sync stock, precios, facturación automática | Nice-to-have |
| M17 | Qontacta CRM | Historial de comunicaciones por cliente | Nice-to-have |
| M18 | Qobra real | Reemplazar mock con integración real de cobros | Crítico |

## Módulos — Fase 3 (Superioridad) — *solo referencia*

| # | Módulo | Descripción |
|---|--------|-------------|
| M19 | Contabilidad con IA | Asientos automáticos, plan de cuentas sugerido, ajuste por inflación |
| M20 | Reportes inteligentes | Predicción de ventas, alertas de stock con IA, rentabilidad por producto |
| M21 | WhatsApp Commerce | Catálogo y facturación directa por WhatsApp |
| M22 | Presencia web (Qautiva) | Tienda online generada desde catálogo |
| M23 | Multimoneda | USD, EUR, BRL con cotización automática |
| M24 | API pública + webhooks | Para integraciones de terceros, compatible con n8n y Make |

---

## Plan de sesiones — Fase 1

### ✅ Sesión 1: Schema base y multi-tenancy (backend) — COMPLETADA 2026-03-25
- **Módulos**: M1 (parte 1 — modelos y backend)
- **Objetivo**: Modelos Organization, Membership, y todos los modelos de dominio de Fase 1 en Prisma. Helper `withTenant()` para queries scoped. Migración ejecutada.
- **Pre-requisitos**: ninguno
- **Incluye migraciones**: sí
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Diseñar schema Prisma completo (Organization, Membership, Product, Category, ProductVariant, PriceList, Contact, Invoice, InvoiceItem, Sale, SaleItem, StockMovement, Warehouse, CashRegister, PaymentRecord, Subscription, Plan)
  - Etapa 2: Helper `withTenant(tenantId)` que agrega filtro automático a queries Prisma
  - Etapa 3: Migración y seed con datos de ejemplo (un tenant demo, productos, un cliente)
  - Etapa 4: Tests unitarios para `withTenant` y validaciones de modelos

### Sesión 2: Multi-tenancy (frontend) y onboarding
- **Módulos**: M1 (parte 2 — frontend), M9 (parcial)
- **Objetivo**: Flujo de creación de organización, selector de tenant, contexto de tenant en toda la app. Wizard de onboarding básico.
- **Pre-requisitos**: Sesión 1 completada
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: API routes para Organization CRUD y Membership
  - Etapa 2: TenantProvider (context React) que resuelve tenant activo y lo pasa a toda la app
  - Etapa 3: Selector de organización en sidebar + página de crear organización
  - Etapa 4: Wizard de onboarding (datos fiscales del negocio, primer producto, primer cliente)

### Sesión 3: Productos y catálogo (backend + frontend)
- **Módulos**: M2 (parte 1)
- **Objetivo**: CRUD completo de categorías y productos con variantes. Lista de productos con filtros y búsqueda.
- **Pre-requisitos**: Sesión 2 completada
- **Incluye migraciones**: no (modelos ya creados en S1)
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Validaciones Zod para Product, Category, ProductVariant
  - Etapa 2: API routes CRUD para categorías y productos (con variantes anidadas)
  - Etapa 3: Página de listado de productos con DataTable, filtros por categoría y estado, búsqueda
  - Etapa 4: Formulario de crear/editar producto con variantes dinámicas

### Sesión 4: Productos avanzado + Clientes y proveedores
- **Módulos**: M2 (parte 2 — listas de precios, códigos de barras), M3
- **Objetivo**: Listas de precios funcionales. CRUD completo de clientes/proveedores con datos fiscales.
- **Pre-requisitos**: Sesión 3 completada
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Listas de precios — API + UI para crear listas y asignar precios por producto
  - Etapa 2: Códigos de barras — campo en producto/variante, búsqueda por código
  - Etapa 3: Validaciones Zod y API routes para Contact (cliente/proveedor) con validación de CUIT
  - Etapa 4: Páginas de listado y formulario de clientes/proveedores (condición IVA, domicilio fiscal)

### Sesión 5: Facturación ARCA (backend)
- **Módulos**: M4 (parte 1 — integración Afip SDK)
- **Objetivo**: Servicio de facturación funcional que genera comprobantes reales (o en modo testing de ARCA).
- **Pre-requisitos**: Sesión 4 completada
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Instalar y configurar Afip SDK. Servicio `AfipService` con métodos para crear factura A/B/C y notas de crédito/débito
  - Etapa 2: Gestión de certificados digitales por tenant (almacenamiento seguro, renovación)
  - Etapa 3: API routes para crear comprobante, consultar último número, y obtener comprobante por ID
  - Etapa 4: Tests con modo testing de ARCA (Afip SDK soporta homologación)

### Sesión 6: Facturación ARCA (frontend) + PDF
- **Módulos**: M4 (parte 2 — UI y PDF)
- **Objetivo**: Crear facturas desde la UI, ver listado, generar PDF descargable.
- **Pre-requisitos**: Sesión 5 completada
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Formulario de nueva factura (seleccionar cliente, agregar ítems, calcular IVA automático)
  - Etapa 2: Listado de facturas con filtros (fecha, tipo, cliente, estado)
  - Etapa 3: Generación de PDF con formato fiscal argentino (usando @react-pdf/renderer o similar)
  - Etapa 4: Detalle de factura + emisión de nota de crédito/débito asociada

### Sesión 7: Stock básico
- **Módulos**: M6
- **Objetivo**: Control de stock con un depósito, movimientos de entrada/salida, vista de stock actual con alertas.
- **Pre-requisitos**: Sesión 3 completada (productos)
- **Incluye migraciones**: no
- **Estimación**: ~70 min Opus
- **Detalle**:
  - Etapa 1: Validaciones Zod y API routes para Warehouse y StockMovement
  - Etapa 2: Servicio de stock: calcular stock actual, registrar movimiento, validar stock suficiente
  - Etapa 3: Página de stock actual (por producto, con indicador de stock bajo)
  - Etapa 4: Página de movimientos de stock (historial) + formulario de ajuste manual

### Sesión 8: Ventas y POS (backend)
- **Módulos**: M5 (parte 1), M7
- **Objetivo**: Modelo de venta completo con descuento de stock automático, emisión de factura, y registro en caja.
- **Pre-requisitos**: Sesiones 5, 6, 7 completadas
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Servicio de ventas: crear venta → descontar stock → emitir factura → registrar pago (transacción atómica)
  - Etapa 2: API routes para Sale CRUD, medios de pago
  - Etapa 3: Tesorería básica: CashRegister con apertura/cierre, PaymentRecord por venta
  - Etapa 4: Mock Qobra como medio de pago (interfaz `PaymentProvider` con implementación mock)

### Sesión 9: Ventas y POS (frontend)
- **Módulos**: M5 (parte 2)
- **Objetivo**: Pantalla de punto de venta funcional — buscar producto, armar carrito, cobrar, emitir ticket/factura.
- **Pre-requisitos**: Sesión 8 completada
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Pantalla POS — layout a dos columnas (búsqueda/catálogo + carrito)
  - Etapa 2: Búsqueda de productos por nombre, código de barras, categoría. Agregar al carrito con cantidad
  - Etapa 3: Panel de cobro: selección de medio de pago, cálculo de vuelto, confirmación
  - Etapa 4: Post-venta: mostrar ticket, opción de imprimir/descargar PDF, enviar por email

### Sesión 10: Reportes y dashboard
- **Módulos**: M8, M9 (completar)
- **Objetivo**: Dashboard con métricas clave, reportes de ventas, libro IVA, cuentas a cobrar. Planes de suscripción con límites.
- **Pre-requisitos**: Sesión 9 completada
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Dashboard — widgets de ventas del día, ventas del mes, stock bajo, facturas pendientes de cobro
  - Etapa 2: Reporte de ventas (diario/mensual/por producto) con gráficos
  - Etapa 3: Libro IVA ventas (requerido por ARCA) + cuentas a cobrar
  - Etapa 4: Sistema de planes — modelo Plan con límites (usuarios, comprobantes), enforcement en API, página de billing

### Sesión 11: QA, polish y deploy
- **Módulos**: M10
- **Objetivo**: Tests E2E de flujos críticos, revisión de seguridad, optimización de performance, preparar para producción.
- **Pre-requisitos**: Todas las sesiones anteriores
- **Incluye migraciones**: no
- **Estimación**: ~90 min Opus
- **Detalle**:
  - Etapa 1: Tests E2E — flujo completo: crear org → crear producto → crear cliente → emitir factura → registrar venta
  - Etapa 2: Revisión de seguridad: tenant isolation (un tenant no puede ver datos de otro), validación de inputs, rate limiting
  - Etapa 3: Performance: índices de DB, lazy loading, optimistic updates en POS
  - Etapa 4: Landing page pública + preparar deploy (variables de entorno, seeds de producción)

---

## Orden de construcción

```
S1: Schema + Multi-tenancy BE ──→ S2: Multi-tenancy FE + Onboarding
                                        │
                                        ├──→ S3: Productos BE+FE ──→ S4: Precios + Clientes
                                        │                                    │
                                        │                              S5: ARCA BE ──→ S6: ARCA FE
                                        │                                    │
                                        ├──→ S7: Stock ─────────────────────┐│
                                        │                                    ││
                                        │                              S8: Ventas BE (necesita S5+S6+S7)
                                        │                                    │
                                        │                              S9: POS FE
                                        │                                    │
                                        └──→ S10: Reportes + Dashboard + Suscripciones
                                                         │
                                                   S11: QA + Deploy
```

**Camino crítico**: S1 → S2 → S3 → S4 → S5 → S6 → S8 → S9 → S10 → S11

**Paralelizable**: S7 (Stock) puede desarrollarse en paralelo con S4-S6 si se usa otro agente/worktree.

## Fuera de alcance — Fase 1

- Integración Mercado Libre / Tiendanube
- Multi-depósito
- Compras y órdenes de compra
- Contabilidad y asientos
- Cuentas corrientes avanzadas
- WhatsApp Commerce
- Presencia web (Qautiva)
- Multimoneda
- API pública / webhooks
- App mobile / tablet
- Migración desde otros sistemas (La Pyme, Colppy, etc.)
- Programa de referidos / partners

## Resumen

| Métrica | Valor |
|---------|-------|
| Módulos Fase 1 | 10 |
| Sesiones estimadas | 11 |
| Modelo recomendado | Opus |
| Tiempo total estimado | ~16-17 horas efectivas |
| Módulos Fase 2 (referencia) | 8 |
| Módulos Fase 3 (referencia) | 6 |
