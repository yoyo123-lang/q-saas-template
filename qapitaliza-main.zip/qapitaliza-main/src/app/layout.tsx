import type { Metadata } from 'next'
import { Toaster } from 'sonner'
import './globals.css'

export const metadata: Metadata = {
  metadataBase: new URL('https://qapitaliza.com'),
  title: {
    template: '%s — Qapitaliza',
    default: 'Qapitaliza — Marketplace de activos digitales',
  },
  description:
    'Comprá, vendé e invertí en sitios web, dominios, MVPs y proyectos digitales.',
  openGraph: {
    type: 'website',
    siteName: 'Qapitaliza',
    title: 'Qapitaliza — Marketplace de activos digitales',
    description:
      'Comprá, vendé e invertí en sitios web, dominios, MVPs y proyectos digitales.',
    locale: 'es_AR',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body className="font-sans antialiased bg-navy-950 text-slate-50 min-h-screen">
        {children}
        <Toaster
          theme="dark"
          toastOptions={{
            style: {
              background: '#0F172A',
              border: '1px solid #1E293B',
              color: '#F8FAFC',
            },
          }}
          position="top-right"
        />
      </body>
    </html>
  )
}
