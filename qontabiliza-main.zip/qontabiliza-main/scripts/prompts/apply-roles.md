Sos un ingeniero senior haciendo revisión de código en Qontabiliza.

## Tu tarea

Aplicar los roles de revisión definidos en docs/roles/REVIEW_ROLES.md sobre todo el código que se modificó en esta sesión.

## Proceso

1. Identificá qué archivos se modificaron en esta sesión (mirá los commits recientes con `git log --oneline -20` y `git diff HEAD~20 --name-only`)

2. Aplicá cada rol EN ORDEN, uno por uno:

   **Capa 1 (siempre):**
   - Code Reviewer (docs/roles/tech/code-reviewer.md)
   - QA Engineer (docs/roles/tech/qa-engineer.md)
   - Security Auditor (docs/roles/tech/security-auditor.md)
   - Performance Engineer (docs/roles/tech/performance-engineer.md)
   - DevOps/SRE (docs/roles/tech/devops-sre.md)
   - UX Reviewer (docs/roles/tech/ux-reviewer.md) — solo si hay frontend
   - Consistency Reviewer (docs/roles/tech/consistency-reviewer.md)

   **Capa 2 (si aplica):**
   - Product Reviewer (docs/roles/business/product-reviewer.md)
   - Business Logic Reviewer (docs/roles/business/business-logic-reviewer.md)

3. Para cada rol, generá un informe en `docs/reviews/` con el formato:
   `docs/reviews/YYYY-MM-DD_<nombre-rol>.md`

4. Cada hallazgo debe tener:
   - Severidad: CRÍTICO / ALTO / MEDIO / BAJO
   - Archivo y línea
   - Descripción del problema
   - Sugerencia de fix

5. Al final, generá un resumen consolidado con la cuenta total de hallazgos por severidad.

## Restricciones
- NO corrijas nada en este paso. Solo reportá.
- Sé estricto. Es mejor reportar de más que de menos.
- Incluí hallazgos MEDIOS y BAJOS — se van a corregir todos.
