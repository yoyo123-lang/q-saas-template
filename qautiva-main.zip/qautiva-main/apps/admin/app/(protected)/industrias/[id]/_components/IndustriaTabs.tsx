'use client'

import Link from 'next/link'
import { usePathname, useSearchParams } from 'next/navigation'

type TabId = 'preguntas' | 'keywords' | 'paletas' | 'campanas'

interface IndustriaTabsProps {
  activeTab: string
  industryId: string
}

const TABS: { id: TabId; label: string }[] = [
  { id: 'preguntas', label: 'Preguntas por etapa' },
  { id: 'keywords', label: 'Keywords' },
  { id: 'paletas', label: 'Paletas de color' },
  { id: 'campanas', label: 'Campañas base' },
]

export function IndustriaTabs({ activeTab, industryId }: IndustriaTabsProps) {
  const pathname = usePathname()
  const searchParams = useSearchParams()

  function buildHref(tabId: TabId) {
    const params = new URLSearchParams(searchParams.toString())
    params.set('tab', tabId)
    return `${pathname}?${params.toString()}`
  }

  return (
    <div className="flex gap-1 border-b border-[#1E293B] pb-0">
      {TABS.map((tab) => {
        const isActive = activeTab === tab.id
        return (
          <Link
            key={tab.id}
            href={buildHref(tab.id)}
            className={`
              flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors -mb-px
              ${isActive
                ? 'text-white border border-[#1E293B] border-b-[#0F172A] bg-[#0F172A]'
                : 'text-[#64748B] hover:text-[#94A3B8]'
              }
            `}
          >
            {tab.label}
          </Link>
        )
      })}
    </div>
  )
}
