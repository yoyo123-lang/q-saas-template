import { describe, it, expect } from 'vitest'
import { mergeFlowDefinition, isAnswerEmpty, hashFlowDefinition, getAgentNumberForStage } from '../../app/_lib/interview/merge-flow'
import type { QuestionBlock } from '../../app/_lib/interview/types'

// ── Helpers ───────────────────────────────────────────────────────────────────

function q(id: string, extra: Partial<QuestionBlock> = {}): QuestionBlock {
  return { id, question: `Pregunta ${id}`, inputType: 'text', ...extra }
}

// ── mergeFlowDefinition ───────────────────────────────────────────────────────

describe('mergeFlowDefinition', () => {
  it('retorna array vacío cuando interviewPrompt es null e industryQuestions es null', () => {
    expect(mergeFlowDefinition(1, null, null)).toEqual([])
  })

  it('retorna las preguntas base cuando no hay preguntas de industria para esta etapa', () => {
    const base = JSON.stringify([q('q1'), q('q2')])
    const result = mergeFlowDefinition(1, base, null)
    expect(result).toHaveLength(2)
    expect(result.map((r) => r.id)).toEqual(['q1', 'q2'])
  })

  it('agrega preguntas de industria al final cuando no hay conflicto de id', () => {
    const base = JSON.stringify([q('q1')])
    const industry = { '1': [q('q2'), q('q3')] }
    const result = mergeFlowDefinition(1, base, industry)
    expect(result.map((r) => r.id)).toEqual(['q1', 'q2', 'q3'])
  })

  it('las preguntas de industria reemplazan a las base cuando comparten id', () => {
    const base = JSON.stringify([q('q1', { question: 'Original' })])
    const industry = { '1': [q('q1', { question: 'Reemplazada' })] }
    const result = mergeFlowDefinition(1, base, industry)
    expect(result).toHaveLength(1)
    expect(result[0]!.question).toBe('Reemplazada')
  })

  it('usa solo las preguntas de industria para la etapa correcta', () => {
    const base = JSON.stringify([q('q1')])
    const industry = {
      '1': [q('i1')],
      '2': [q('i2')],
    }
    const result = mergeFlowDefinition(2, base, industry)
    expect(result.map((r) => r.id)).toContain('i2')
    expect(result.map((r) => r.id)).not.toContain('i1')
  })

  it('filtra items inválidos del interviewPrompt (sin id)', () => {
    const base = JSON.stringify([
      { id: 'q1', question: 'válida', inputType: 'text' },
      { question: 'sin id', inputType: 'text' },
      { id: '', question: 'id vacío', inputType: 'text' },
    ])
    const result = mergeFlowDefinition(1, base, null)
    expect(result).toHaveLength(1)
    expect(result[0]!.id).toBe('q1')
  })

  it('filtra items inválidos de las preguntas de industria', () => {
    const base = JSON.stringify([])
    const industry = {
      '1': [
        { id: 'i1', question: 'válida', inputType: 'text' } as QuestionBlock,
        { question: 'sin id', inputType: 'text' } as unknown as QuestionBlock,
      ],
    }
    const result = mergeFlowDefinition(1, base, industry)
    expect(result).toHaveLength(1)
    expect(result[0]!.id).toBe('i1')
  })

  it('retorna array vacío cuando interviewPrompt es JSON inválido', () => {
    const result = mergeFlowDefinition(1, 'no es json', null)
    expect(result).toEqual([])
  })

  it('retorna array vacío cuando interviewPrompt es JSON válido pero no es array', () => {
    const result = mergeFlowDefinition(1, '{"id":"q1"}', null)
    expect(result).toEqual([])
  })

  it('retorna solo preguntas de industria cuando no hay base', () => {
    const industry = { '1': [q('i1'), q('i2')] }
    const result = mergeFlowDefinition(1, null, industry)
    expect(result.map((r) => r.id)).toEqual(['i1', 'i2'])
  })

  it('preserva el orden: base primero, luego nuevas de industria', () => {
    const base = JSON.stringify([q('b1'), q('b2'), q('shared')])
    const industry = { '3': [q('shared', { question: 'Override' }), q('i1')] }
    const result = mergeFlowDefinition(3, base, industry)
    // shared se actualiza in-place en el Map → mantiene posición de inserción original
    const ids = result.map((r) => r.id)
    expect(ids).toContain('b1')
    expect(ids).toContain('b2')
    expect(ids).toContain('shared')
    expect(ids).toContain('i1')
    // shared debe aparecer en su posición original (índice 2, antes de i1)
    expect(ids.indexOf('shared')).toBeLessThan(ids.indexOf('i1'))
  })
})

// ── isAnswerEmpty ─────────────────────────────────────────────────────────────

describe('isAnswerEmpty', () => {
  it('null → vacío', () => expect(isAnswerEmpty(null)).toBe(true))
  it('undefined → vacío', () => expect(isAnswerEmpty(undefined)).toBe(true))
  it('string vacío → vacío', () => expect(isAnswerEmpty('')).toBe(true))
  it('string solo espacios → vacío', () => expect(isAnswerEmpty('   ')).toBe(true))
  it('array vacío → vacío', () => expect(isAnswerEmpty([])).toBe(true))

  it('string con contenido → NO vacío', () => expect(isAnswerEmpty('hola')).toBe(false))
  it('array con elementos → NO vacío', () => expect(isAnswerEmpty(['a'])).toBe(false))
  it('número 0 → NO vacío', () => expect(isAnswerEmpty(0)).toBe(false))
  it('false → NO vacío', () => expect(isAnswerEmpty(false)).toBe(false))
  it('objeto con keys → NO vacío', () => expect(isAnswerEmpty({ min: 0, max: 100 })).toBe(false))
})

// ── hashFlowDefinition ────────────────────────────────────────────────────────

describe('hashFlowDefinition', () => {
  it('retorna un string hex de 64 caracteres (SHA-256)', () => {
    const hash = hashFlowDefinition([q('q1')])
    expect(hash).toMatch(/^[0-9a-f]{64}$/)
  })

  it('el mismo input produce el mismo hash (determinístico)', () => {
    const flow = [q('q1'), q('q2')]
    expect(hashFlowDefinition(flow)).toBe(hashFlowDefinition(flow))
  })

  it('distinto input produce distinto hash', () => {
    const h1 = hashFlowDefinition([q('q1')])
    const h2 = hashFlowDefinition([q('q2')])
    expect(h1).not.toBe(h2)
  })

  it('array vacío produce hash válido', () => {
    const hash = hashFlowDefinition([])
    expect(hash).toMatch(/^[0-9a-f]{64}$/)
  })
})

// ── getAgentNumberForStage ────────────────────────────────────────────────────

describe('getAgentNumberForStage', () => {
  it.each([
    ['DISCOVERY', 1, 1],
    ['RESEARCH', 2, 2],
    ['BRAND', 3, 3],
    ['WEBSITE', 4, 4],
    ['CAMPAIGNS', 5, 5],
    ['MEDIA', 6, 6],
  ])('stageKey=%s → agentNumber=%i', (key, stageNumber, expected) => {
    expect(getAgentNumberForStage(key, stageNumber)).toBe(expected)
  })

  it('fallback al stageNumber cuando el stageKey no está mapeado', () => {
    expect(getAgentNumberForStage('UNKNOWN', 4)).toBe(4)
  })

  it('string vacío usa fallback', () => {
    expect(getAgentNumberForStage('', 2)).toBe(2)
  })
})
