/**
 * GET /api/ads/meta/callback?code=xxx&state=xxx
 *
 * Callback de Meta OAuth. Intercambia el code por tokens y guarda la cuenta.
 */
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { exchangeMetaCode } from '@qautiva/ads/meta'
import { encryptToken } from '@qautiva/ads/shared'

const STATE_COOKIE = 'ads_meta_oauth_state'
const META_GRAPH_URL = 'https://graph.facebook.com/v22.0'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get('code')
  const state = searchParams.get('state')
  const error = searchParams.get('error')
  const errorReason = searchParams.get('error_reason')

  // El usuario canceló el flujo en Meta
  if (error) {
    console.warn('[ads/meta/callback] User denied access:', { error, errorReason })
    return redirectWithError('Cancelaste la conexión con Meta Ads. Podés intentarlo de nuevo.')
  }

  if (!code || !state) {
    return redirectWithError('Respuesta inválida de Meta. Intentá de nuevo.')
  }

  // 1. Verificar CSRF
  const cookieStore = cookies()
  const storedState = cookieStore.get(STATE_COOKIE)?.value

  if (!storedState || storedState !== state) {
    console.error('[ads/meta/callback] State mismatch — possible CSRF')
    return redirectWithError('Sesión inválida. Iniciá el proceso de conexión de nuevo.')
  }

  const projectId = state.split('|')[0]
  if (!projectId) {
    return redirectWithError('Estado de sesión inválido.')
  }

  // 2. Verificar autenticación
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return redirectWithError('Tu sesión expiró. Iniciá sesión e intentá de nuevo.')
  }

  // 3. Verificar ownership del proyecto
  const profile = await prisma.userProfile.findFirst({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile) {
    console.error('[ads/meta/callback] Profile not found', { userId: user.id })
    return redirectWithError('Perfil no encontrado.')
  }

  const teamIds = profile.teamMemberships.map(m => m.teamId)
  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, teamId: true },
  })

  if (!project) {
    console.error('[ads/meta/callback] Project not found or unauthorized', { userId: user.id, projectId })
    return redirectWithError('Proyecto no encontrado.')
  }

  // 4. Intercambiar code por tokens (short → long lived)
  let tokens
  try {
    tokens = await exchangeMetaCode(code)
  } catch (err) {
    console.error('[ads/meta/callback] Token exchange failed', { userId: user.id, projectId })
    return redirectWithError('No pudimos conectar con Meta Ads. Intentá de nuevo.')
  }

  // 5. Obtener cuentas de ads disponibles para el usuario
  let adAccounts: Array<{ id: string; name: string; currency: string; timezone_name: string }> = []
  try {
    const res = await fetch(
      `${META_GRAPH_URL}/me/adaccounts?fields=id,name,currency,timezone_name&limit=10`,
      {
        headers: { Authorization: `Bearer ${tokens.accessToken}` },
        signal: AbortSignal.timeout(10_000),
      },
    )
    if (res.ok) {
      const data = await res.json() as { data?: typeof adAccounts }
      adAccounts = data.data ?? []
    }
  } catch {
    console.warn('[ads/meta/callback] Could not fetch ad accounts — using defaults', { userId: user.id, projectId })
  }

  // Tomar la primera cuenta disponible (o crear entrada genérica)
  const firstAccount = adAccounts[0]
  const externalId = firstAccount?.id ?? 'act_unknown'
  const accountName = firstAccount?.name ?? 'Meta Ads'
  const currency = firstAccount?.currency ?? 'ARS'
  const timezone = firstAccount?.timezone_name ?? 'America/Argentina/Buenos_Aires'

  // 6. Encriptar token y guardar en DB
  // Meta no tiene refresh token — el accessToken es long-lived (~60 días)
  try {
    await prisma.adAccount.upsert({
      where: {
        projectId_platform_externalId: {
          projectId: project.id,
          platform: 'META',
          externalId,
        },
      },
      create: {
        projectId: project.id,
        teamId: project.teamId,
        platform: 'META',
        externalId,
        name: accountName,
        accessToken: encryptToken(tokens.accessToken),
        refreshToken: encryptToken('meta_no_refresh_token'), // Meta no usa refresh tokens
        tokenExpiresAt: tokens.expiresAt,
        status: 'ACTIVE',
        metadata: { currency, timezone, scope: tokens.scope },
      },
      update: {
        accessToken: encryptToken(tokens.accessToken),
        tokenExpiresAt: tokens.expiresAt,
        status: 'ACTIVE',
        revokedAt: null,
        metadata: { currency, timezone, scope: tokens.scope },
      },
    })
  } catch (err) {
    console.error('[ads/meta/callback] Failed to save AdAccount', { userId: user.id, projectId })
    return redirectWithError('No pudimos guardar la conexión. Contactá a soporte.')
  }

  // 7. Limpiar cookie y redirigir
  const successUrl = `/proyectos/${project.id}/publicidad?connected=meta`
  const response = NextResponse.redirect(new URL(successUrl, request.url))
  response.cookies.delete(STATE_COOKIE)

  return response
}

function redirectWithError(message: string): NextResponse {
  // La cookie se limpia siempre para evitar replay de state tokens
  const url = new URL('/proyectos', process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3001')
  url.searchParams.set('ads_error', message)
  const response = NextResponse.redirect(url)
  response.cookies.delete(STATE_COOKIE)
  return response
}
