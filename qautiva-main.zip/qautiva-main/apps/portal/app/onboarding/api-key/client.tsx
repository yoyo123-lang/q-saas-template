'use client'

import { useState, Suspense } from 'react'
import { useRouter } from 'next/navigation'
import LoadingSpinner from '../_components/LoadingSpinner'

type AiProvider = 'ANTHROPIC' | 'OPENAI' | 'GOOGLE_GEMINI'
type KeyMode = 'trial' | 'hosted' | 'byok'

const PROVIDERS: { id: AiProvider; label: string; placeholder: string }[] = [
  { id: 'ANTHROPIC', label: 'Anthropic (Claude)', placeholder: 'sk-ant-...' },
  { id: 'OPENAI', label: 'OpenAI (GPT)', placeholder: 'sk-...' },
  { id: 'GOOGLE_GEMINI', label: 'Google Gemini', placeholder: 'AIza...' },
]

function ApiKeyForm({
  isTrialActive,
  trialTokenAmount,
}: {
  isTrialActive: boolean
  trialTokenAmount: number
}) {
  const router = useRouter()
  const [mode, setMode] = useState<KeyMode>(isTrialActive ? 'trial' : 'hosted')
  const [showByok, setShowByok] = useState(false)
  const [provider, setProvider] = useState<AiProvider>('ANTHROPIC')
  const [apiKey, setApiKey] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const effectiveMode = isTrialActive && !showByok ? 'trial' : mode

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (effectiveMode === 'byok' && !apiKey.trim()) {
      setErrorMessage('Ingresá tu clave de API.')
      return
    }

    setIsSubmitting(true)
    setErrorMessage('')

    try {
      const body: Record<string, unknown> = {
        step: 2,
        mode: effectiveMode,
      }

      if (effectiveMode === 'byok') {
        body.provider = provider
        body.apiKey = apiKey.trim()
      }

      const res = await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (!res.ok) {
        const data = await res.json().catch((err: unknown) => { console.error('[ApiKeyForm] Failed to parse error response', err); return {} })
        setErrorMessage(data.error ?? 'Error al guardar. Intentá de nuevo.')
        setIsSubmitting(false)
        return
      }

      router.push('/proyectos')
    } catch {
      setErrorMessage('Error de red. Verificá tu conexión e intentá de nuevo.')
      setIsSubmitting(false)
    }
  }

  return (
    <div className="w-full max-w-md">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Potenciá tu negocio con IA</h1>
        <p className="text-[#94A3B8] text-sm">
          {isTrialActive
            ? 'Empezá gratis — sin tarjeta ni configuración.'
            : 'Elegí cómo querés usar la IA.'}
        </p>
      </div>

      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
        {errorMessage && (
          <div className="mb-4 p-3 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {isTrialActive && !showByok ? (
            <TrialSection
              trialTokenAmount={trialTokenAmount}
              isSubmitting={isSubmitting}
              onShowByok={() => { setShowByok(true); setMode('byok') }}
            />
          ) : (
            <FullSection
              isTrialActive={isTrialActive}
              mode={mode}
              provider={provider}
              apiKey={apiKey}
              isSubmitting={isSubmitting}
              onModeChange={setMode}
              onProviderChange={setProvider}
              onApiKeyChange={(val) => setApiKey(val)}
            />
          )}
        </form>
      </div>
    </div>
  )
}

function TrialSection({
  trialTokenAmount,
  isSubmitting,
  onShowByok,
}: {
  trialTokenAmount: number
  isSubmitting: boolean
  onShowByok: () => void
}) {
  return (
    <div className="space-y-4">
      <div className="p-4 rounded-lg bg-[#8B5CF6]/10 border border-[#8B5CF6]/30 text-center">
        <div className="text-2xl mb-2">🚀</div>
        <p className="text-white text-sm font-medium mb-1">
          {trialTokenAmount.toLocaleString('es-AR')} generaciones gratuitas
        </p>
        <p className="text-[#94A3B8] text-xs">
          Sin tarjeta ni configuración. Probá Qautiva sin costo.
        </p>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-[#8B5CF6] text-white font-medium hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? (
          <>
            <LoadingSpinner />
            Configurando...
          </>
        ) : '⚡ Empezá gratis'}
      </button>

      <button
        type="button"
        onClick={onShowByok}
        className="w-full text-center text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors py-1"
      >
        Ya tengo mi propia clave de IA → (costo menor)
      </button>
    </div>
  )
}

function FullSection({
  isTrialActive,
  mode,
  provider,
  apiKey,
  isSubmitting,
  onModeChange,
  onProviderChange,
  onApiKeyChange,
}: {
  isTrialActive: boolean
  mode: KeyMode
  provider: AiProvider
  apiKey: string
  isSubmitting: boolean
  onModeChange: (m: KeyMode) => void
  onProviderChange: (p: AiProvider) => void
  onApiKeyChange: (val: string) => void
}) {
  const MODE_OPTIONS = [
    { id: 'hosted' as KeyMode, label: 'Usar la IA de Qautiva', desc: 'Sin configuración. Cargás saldo y listo.' },
    { id: 'byok' as KeyMode, label: 'Traer mi propia clave de IA', desc: 'Más barato si ya tenés cuenta en Anthropic, OpenAI o Google.' },
  ]

  return (
    <div className="space-y-4">
      {!isTrialActive && (
        <div className="space-y-2">
          {MODE_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => onModeChange(opt.id)}
              disabled={isSubmitting}
              className={[
                'w-full flex items-start gap-3 p-3 rounded-lg border text-left transition-all',
                mode === opt.id ? 'border-[#8B5CF6] bg-[#8B5CF6]/10' : 'border-[#1E293B] hover:border-[#8B5CF6]/40',
              ].join(' ')}
            >
              <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 mt-0.5 ${mode === opt.id ? 'border-[#8B5CF6] bg-[#8B5CF6]' : 'border-[#64748B]'}`} />
              <div>
                <p className="text-white text-sm font-medium">{opt.label}</p>
                <p className="text-[#64748B] text-xs mt-0.5">{opt.desc}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {mode === 'byok' && (
        <ByokFields
          provider={provider}
          apiKey={apiKey}
          isSubmitting={isSubmitting}
          onProviderChange={onProviderChange}
          onApiKeyChange={onApiKeyChange}
        />
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? (
          <>
            <LoadingSpinner />
            Configurando...
          </>
        ) : 'Continuar →'}
      </button>

      {/* Para modo hosted: opción de continuar sin cargar saldo */}
      {mode === 'hosted' && (
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full text-center text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors py-1"
        >
          Continuar sin saldo por ahora
        </button>
      )}
    </div>
  )
}

function ByokFields({
  provider,
  apiKey,
  isSubmitting,
  onProviderChange,
  onApiKeyChange,
}: {
  provider: AiProvider
  apiKey: string
  isSubmitting: boolean
  onProviderChange: (p: AiProvider) => void
  onApiKeyChange: (val: string) => void
}) {
  return (
    <div className="space-y-3 p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B]">
      <div>
        <label htmlFor="byok-provider" className="block text-xs text-[#94A3B8] mb-1.5">Proveedor</label>
        <select
          id="byok-provider"
          value={provider}
          onChange={(e) => onProviderChange(e.target.value as AiProvider)}
          disabled={isSubmitting}
          className="w-full px-3 py-2 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white text-sm focus:outline-none focus:border-[#A78BFA] transition-colors"
        >
          {PROVIDERS.map((p) => (
            <option key={p.id} value={p.id}>{p.label}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="byok-api-key" className="block text-xs text-[#94A3B8] mb-1.5">Clave de API</label>
        <input
          id="byok-api-key"
          type="password"
          value={apiKey}
          onChange={(e) => onApiKeyChange(e.target.value)}
          placeholder={PROVIDERS.find((p) => p.id === provider)?.placeholder ?? ''}
          disabled={isSubmitting}
          className="w-full px-3 py-2 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm font-mono focus:outline-none focus:border-[#A78BFA] transition-colors"
          maxLength={500}
        />
      </div>
    </div>
  )
}

export default function ApiKeyClient(props: { isTrialActive: boolean; trialTokenAmount: number }) {
  return (
    <Suspense fallback={<div className="text-[#64748B] text-sm">Cargando...</div>}>
      <ApiKeyForm {...props} />
    </Suspense>
  )
}
