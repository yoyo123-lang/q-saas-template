'use client'

import { useCallback, useEffect, useReducer, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import type { QuestionBlock } from '@/app/_lib/interview/types'
import type { WelcomeData } from './_types'
import { StageWelcomeScreen } from './_components/StageWelcomeScreen'
import { QuestionCard } from './_components/QuestionCard'
import { NavigationButtons } from './_components/NavigationButtons'
import { ProcessingScreen } from './_components/ProcessingScreen'
import { FeedbackForm } from './_components/FeedbackForm'
import { BriefView } from './_components/BriefView'
import { WebsitePreviewView } from './_components/WebsitePreviewView'

/** Breadcrumb reutilizable para volver a la página de progreso */
function BackToProgress({ projectId }: { projectId: string }) {
  return (
    <Link
      href={`/proyectos/${projectId}/progreso`}
      className="inline-flex items-center gap-1 text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors duration-200 mb-4"
    >
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M15 18l-6-6 6-6" />
      </svg>
      Mi progreso
    </Link>
  )
}

/**
 * Subset del InterviewSession que devuelve la API.
 * flowDefinition se carga una vez desde POST /sessions y no cambia.
 */
type SessionData = {
  id: string
  status: string
  currentStep: number
  totalSteps: number
  answersVersion: number
  answers: Record<string, unknown> | null
  flowDefinition: QuestionBlock[] | null
  retryCount?: number
  maxRetries?: number
}

type UIState = 'loading' | 'ready' | 'saving' | 'error'

// ── InterviewClient reducer ───────────────────────────────────────────────────

type InterviewState = {
  session: SessionData | null
  uiState: UIState
  errorMsg: string
}

type InterviewAction =
  | { type: 'INIT_SUCCESS'; payload: SessionData }
  | { type: 'INIT_ERROR'; payload: string }
  | { type: 'SET_SAVING' }
  | { type: 'SET_READY' }
  | { type: 'SET_ERROR'; payload: string }
  | { type: 'SET_SESSION'; payload: SessionData }
  | { type: 'ADVANCE_SUCCESS'; payload: SessionData }
  | { type: 'CLEAR_ERROR' }
  | { type: 'UPDATE_SESSION_PARTIAL'; payload: Partial<SessionData> }

function interviewReducer(state: InterviewState, action: InterviewAction): InterviewState {
  switch (action.type) {
    case 'INIT_SUCCESS':
      return { session: action.payload, uiState: 'ready', errorMsg: '' }
    case 'INIT_ERROR':
      return { ...state, uiState: 'error', errorMsg: action.payload }
    case 'SET_SAVING':
      return { ...state, uiState: 'saving', errorMsg: '' }
    case 'SET_READY':
      return { ...state, uiState: 'ready' }
    case 'SET_ERROR':
      return { ...state, uiState: 'error', errorMsg: action.payload }
    case 'SET_SESSION':
      return { ...state, session: action.payload }
    case 'ADVANCE_SUCCESS':
      return { ...state, session: action.payload, uiState: 'ready' }
    case 'CLEAR_ERROR':
      return { ...state, errorMsg: '' }
    case 'UPDATE_SESSION_PARTIAL':
      return {
        ...state,
        session: state.session ? { ...state.session, ...action.payload } : null,
      }
    default:
      return state
  }
}

const initialInterviewState: InterviewState = {
  session: null,
  uiState: 'loading',
  errorMsg: '',
}

// ─────────────────────────────────────────────────────────────────────────────

type Props = {
  projectId: string
  stageId: string
  stageNumber: number
  stageKey: string
  stageName: string
  welcomeData?: WelcomeData
}

export function InterviewClient({ projectId, stageId, stageNumber, stageKey, stageName, welcomeData }: Props) {
  const router = useRouter()
  const [state, dispatch] = useReducer(interviewReducer, initialInterviewState)
  const { session, uiState, errorMsg } = state

  // Draft answer para la pregunta actual — resetea al cambiar de paso.
  // Se mantiene separado del reducer porque determina si saveCurrentAnswer se recrea.
  const [draftAnswer, setDraftAnswer] = useState<unknown>(undefined)
  const [retrying, setRetrying] = useState(false)
  const initRef = useRef(false)

  // Crear o retomar sesión al montar el componente
  useEffect(() => {
    if (initRef.current) return
    initRef.current = true

    async function initSession() {
      try {
        const res = await fetch('/api/interview/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stageId, projectId }),
        })
        if (!res.ok) {
          const err = await res.json().catch(() => null)
          dispatch({ type: 'INIT_ERROR', payload: err?.error ?? 'Error al cargar la entrevista' })
          return
        }
        const data = await res.json()
        const s: SessionData = data.session
        // Pre-cargar draft con la respuesta guardada de la pregunta actual
        const flow = s.flowDefinition ?? []
        const q = flow[s.currentStep]
        setDraftAnswer(q ? (s.answers?.[q.id] ?? undefined) : undefined)
        dispatch({ type: 'INIT_SUCCESS', payload: s })
      } catch {
        dispatch({
          type: 'INIT_ERROR',
          payload: 'No se pudo conectar. Revisá tu conexión e intentá de nuevo.',
        })
      }
    }

    initSession()
  }, [projectId, stageId])

  /**
   * Guarda la respuesta del draft actual si difiere de la guardada.
   * Retorna la sesión actualizada, o null si hubo error (y ya despachó la acción).
   * Captura draftAnswer desde la closure — se recrea cuando draftAnswer cambia.
   */
  const saveCurrentAnswer = useCallback(async (sess: SessionData): Promise<SessionData | null> => {
    const flow = sess.flowDefinition ?? []
    const currentQuestion = flow[sess.currentStep]
    if (!currentQuestion) return sess

    const savedAnswer = sess.answers?.[currentQuestion.id]
    // Nada que guardar si el draft es undefined o igual al guardado
    if (draftAnswer === undefined || draftAnswer === savedAnswer) return sess

    const res = await fetch(`/api/interview/sessions/${sess.id}/answer`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        questionId: currentQuestion.id,
        answer: draftAnswer,
        answersVersion: sess.answersVersion,
      }),
    })

    if (!res.ok) {
      const err = await res.json().catch(() => null)
      if (err?.code === 'VERSION_CONFLICT') {
        dispatch({ type: 'SET_ERROR', payload: 'Tus respuestas se actualizaron en otra pestaña. Recargando...' })
        setTimeout(() => window.location.reload(), 2000)
      } else {
        dispatch({ type: 'SET_ERROR', payload: err?.error ?? 'Error al guardar la respuesta' })
      }
      return null
    }

    const { session: updated } = await res.json()
    return {
      ...sess,
      answers: updated.answers,
      answersVersion: updated.answersVersion,
      status: updated.status,
    }
  }, [draftAnswer])

  /**
   * Avanza/retrocede/inicia/envía la sesión.
   * Siempre guarda el draft actual antes de navegar.
   * useCallback evita que NavigationButtons reciba una nueva referencia de función
   * en cada render causado por cambios de uiState o errorMsg no relacionados.
   */
  const advance = useCallback(async (action: 'start' | 'next' | 'back' | 'submit') => {
    if (!session) return
    dispatch({ type: 'SET_SAVING' })

    // Guardar draft antes de avanzar (excepto "start" que no tiene draft)
    let currentSession = session
    if (action !== 'start') {
      const saved = await saveCurrentAnswer(currentSession)
      if (!saved) return // saveCurrentAnswer ya despachó SET_ERROR
      currentSession = saved
      dispatch({ type: 'SET_SESSION', payload: currentSession })
    }

    const res = await fetch(`/api/interview/sessions/${currentSession.id}/advance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    })

    if (!res.ok) {
      const err = await res.json().catch(() => null)
      if (err?.code === 'MISSING_REQUIRED_ANSWERS') {
        dispatch({ type: 'SET_ERROR', payload: 'Respondé todas las preguntas obligatorias antes de enviar.' })
        dispatch({ type: 'SET_READY' })
        return
      }
      if (err?.code === 'CONCURRENT_MODIFICATION') {
        dispatch({ type: 'SET_ERROR', payload: 'La sesión fue modificada en otra pestaña. Recargando...' })
        setTimeout(() => window.location.reload(), 2000)
        return
      }
      dispatch({ type: 'SET_ERROR', payload: err?.error ?? 'Error al avanzar' })
      return
    }

    const { session: advanced } = await res.json()
    const newSession: SessionData = { ...currentSession, ...advanced }

    // Si el submit puso la sesión en PROCESSING, disparar la generación en background.
    // Para WEBSITE: siempre hacer router.refresh() para que el server component
    // verifique si falta seleccionar template (TemplateRecommendationClient).
    // ProcessingScreen llama /process al montar, después de que el server validó
    // que el template existe. Esto evita que /process corra sin template.
    // Para otros stages: disparar /process inmediatamente como optimización.
    if (action === 'submit' && newSession.status === 'PROCESSING') {
      if (stageKey === 'WEBSITE') {
        dispatch({ type: 'ADVANCE_SUCCESS', payload: newSession })
        router.refresh()
        return
      }

      fetch(`/api/interview/sessions/${currentSession.id}/process`, { method: 'POST' })
        .then((r) => {
          if (!r.ok) console.error('[process] call failed', { sessionId: currentSession.id, status: r.status })
          else console.log('[process] call ok', { sessionId: currentSession.id, status: r.status })
        })
        .catch((err) => console.error('[process] network error', { sessionId: currentSession.id, err }))
    }

    // Resetear draft con la respuesta guardada de la nueva pregunta
    const flow = newSession.flowDefinition ?? []
    const newQuestion = flow[newSession.currentStep]
    const newSavedAnswer = newQuestion ? (newSession.answers?.[newQuestion.id] ?? undefined) : undefined

    setDraftAnswer(newSavedAnswer)
    dispatch({ type: 'ADVANCE_SUCCESS', payload: newSession })
  }, [session, saveCurrentAnswer, stageKey, router])

  // ── Render ────────────────────────────────────────────────────────────────

  if (uiState === 'loading') {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <div className="flex items-center gap-3 text-[#94A3B8]">
          <svg
            className="animate-spin"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            aria-hidden="true"
          >
            <path d="M21 12a9 9 0 1 1-6.219-8.56" />
          </svg>
          <span>Cargando entrevista...</span>
        </div>
      </div>
    )
  }

  if (uiState === 'error' && !session) {
    return (
      <div className="p-8 max-w-2xl">
        <BackToProgress projectId={projectId} />
        <ErrorBanner message={errorMsg} onRetry={() => window.location.reload()} />
      </div>
    )
  }

  if (!session) return null

  const flow = session.flowDefinition ?? []
  const currentQuestion = flow[session.currentStep] ?? null

  // Procesando — polling automático hasta que la IA termina
  if (session.status === 'PROCESSING') {
    return (
      <div className="p-8 max-w-2xl">
        <BackToProgress projectId={projectId} />
        <ProcessingScreen
          sessionId={session.id}
          onComplete={(updated) =>
            dispatch({ type: 'UPDATE_SESSION_PARTIAL', payload: updated })
          }
        />
      </div>
    )
  }

  // Completado exitosamente
  if (session.status === 'COMPLETED') {
    return (
      <div className="p-8 max-w-2xl">
        <BackToProgress projectId={projectId} />
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-[#10B981]/10 border border-[#10B981]/30 flex items-center justify-center flex-shrink-0">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#10B981"
                strokeWidth="2"
                aria-hidden="true"
              >
                <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">¡Entrevista completada!</h2>
              <p className="text-[#94A3B8] text-sm">Tus respuestas fueron enviadas exitosamente.</p>
            </div>
          </div>
          {stageKey === 'DISCOVERY' ? (
            <p className="text-[#64748B] text-sm leading-relaxed mb-5">
              Tu Brief Estratégico está listo. Úsalo como referencia para todas las etapas siguientes.
            </p>
          ) : stageKey === 'WEBSITE' ? (
            <p className="text-[#64748B] text-sm leading-relaxed mb-5">
              La IA generó el contenido de tu sitio web. Revisá el preview y aprobalo cuando esté listo.
            </p>
          ) : (
            <p className="text-[#64748B] text-sm leading-relaxed mb-5">
              Tu equipo de Qautiva está preparando el resultado de esta etapa.
              Te avisamos por email cuando esté listo para revisar.
            </p>
          )}
          <Link
            href={`/proyectos/${projectId}/progreso`}
            className="inline-block px-4 py-2 rounded-lg bg-[#1E293B] text-white text-sm font-medium hover:bg-[#334155] transition-colors duration-200"
          >
            Volver a mi progreso
          </Link>
        </div>
        {stageKey === 'DISCOVERY' && <BriefView sessionId={session.id} />}
        {stageKey === 'WEBSITE' && <WebsitePreviewView sessionId={session.id} projectId={projectId} />}
        <FeedbackForm sessionId={session.id} />
      </div>
    )
  }

  // Estado de error terminal
  if (session.status === 'ERROR') {
    const retriesExhausted = session.retryCount != null && session.maxRetries != null && session.retryCount >= session.maxRetries

    return (
      <div className="p-8 max-w-2xl">
        <BackToProgress projectId={projectId} />
        <div className="bg-[#EF4444]/5 border border-[#EF4444]/20 rounded-xl p-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-[#EF4444]/10 border border-[#EF4444]/30 flex items-center justify-center flex-shrink-0">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#EF4444"
                strokeWidth="2"
                aria-hidden="true"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 8v4m0 4h.01" strokeLinecap="round" />
              </svg>
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">Algo salió mal</h2>
              <p className="text-[#94A3B8] text-sm">
                {retriesExhausted
                  ? 'Se agotaron los reintentos automáticos.'
                  : 'Hubo un error durante el procesamiento.'}
              </p>
            </div>
          </div>
          <p className="text-[#64748B] text-sm leading-relaxed mb-5">
            Tus respuestas están guardadas y no se perdieron. Nuestro equipo revisará lo sucedido.
          </p>
          <div className="flex items-center gap-3">
            {!retriesExhausted && (
              <button
                onClick={async () => {
                  setRetrying(true)
                  try {
                    const res = await fetch(`/api/interview/sessions/${session.id}/process`, { method: 'POST' })
                    if (res.ok) {
                      dispatch({ type: 'UPDATE_SESSION_PARTIAL', payload: { status: 'PROCESSING' } })
                    }
                  } finally {
                    setRetrying(false)
                  }
                }}
                disabled={retrying}
                className="px-4 py-2 text-sm font-medium text-white bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors"
              >
                {retrying ? 'Reintentando...' : 'Reintentar'}
              </button>
            )}
            <a
              href="mailto:hola@qautiva.ar"
              className="px-4 py-2 text-sm bg-[#1E293B] hover:bg-[#334155] text-[#94A3B8] hover:text-white rounded-lg transition-colors"
            >
              Contactar soporte
            </a>
          </div>
        </div>
      </div>
    )
  }

  // Pantalla de bienvenida
  if (session.status === 'NOT_STARTED') {
    return (
      <div className="p-8 max-w-2xl">
        <BackToProgress projectId={projectId} />
        <StageWelcomeScreen
          stageNumber={stageNumber}
          stageName={stageName}
          welcomeData={welcomeData}
          totalSteps={session.totalSteps}
          onStart={() => advance('start')}
          isLoading={uiState === 'saving'}
        />
      </div>
    )
  }

  // Entrevista conversacional (DISCOVERY = El Estratega genera preguntas dinámicamente)
  // Usamos stageKey en lugar de stageNumber para ser robustos ante proyectos con numeración distinta
  if (stageKey === 'DISCOVERY') {
    return (
      <div className="p-8 max-w-2xl">
        <BackToProgress projectId={projectId} />
        {errorMsg && uiState === 'ready' && (
          <ErrorBanner message={errorMsg} onDismiss={() => dispatch({ type: 'CLEAR_ERROR' })} className="mb-6" />
        )}
        <ConversationalInterview
          sessionId={session.id}
          onComplete={() =>
            dispatch({ type: 'UPDATE_SESSION_PARTIAL', payload: { status: 'PROCESSING' } })
          }
          onError={(msg) => {
            dispatch({ type: 'SET_ERROR', payload: msg })
            dispatch({ type: 'SET_READY' })
          }}
        />
      </div>
    )
  }

  // Flujo de preguntas estático (IN_PROGRESS / PAUSED)
  if (!currentQuestion) {
    return (
      <div className="p-8 text-[#94A3B8]">
        No hay preguntas configuradas para esta etapa.
      </div>
    )
  }

  const isLastStep = session.currentStep >= session.totalSteps - 1

  return (
    <div className="p-8 max-w-2xl">
      <BackToProgress projectId={projectId} />

      {/* Banner de error dismissible */}
      {errorMsg && uiState === 'ready' && (
        <ErrorBanner message={errorMsg} onDismiss={() => dispatch({ type: 'CLEAR_ERROR' })} className="mb-6" />
      )}

      {/* Barra de progreso — usa flow.length como fuente de verdad para evitar
          discrepancias si session.totalSteps difiere del flow cargado */}
      {flow.length > 1 && (
        <div className="mb-6">
          <div className="flex justify-between text-xs text-[#64748B] mb-2">
            <span>
              Pregunta {session.currentStep + 1} de {flow.length}
            </span>
            <span>{Math.round(((session.currentStep + 1) / flow.length) * 100)}%</span>
          </div>
          <div className="h-1.5 bg-[#1E293B] rounded-full overflow-hidden">
            <div
              className="h-full bg-[#8B5CF6] rounded-full transition-all duration-300"
              style={{ width: `${((session.currentStep + 1) / flow.length) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Pregunta actual */}
      <QuestionCard
        question={currentQuestion}
        value={draftAnswer}
        onChange={setDraftAnswer}
        isSaving={uiState === 'saving'}
      />

      {/* Botones de navegación */}
      <NavigationButtons
        currentStep={session.currentStep}
        isLastStep={isLastStep}
        isLoading={uiState === 'saving'}
        onBack={session.currentStep > 0 ? () => advance('back') : undefined}
        onNext={!isLastStep ? () => advance('next') : undefined}
        onSubmit={isLastStep ? () => advance('submit') : undefined}
      />
    </div>
  )
}

// ── Entrevista Conversacional ─────────────────────────────────────────────────

type ConvState = 'thinking' | 'answering'

// ── ConversationalInterview reducer ──────────────────────────────────────────

type ConvInterviewState = {
  convState: ConvState
  currentQuestion: QuestionBlock | null
  answeredCount: number
}

type ConvAction =
  | { type: 'SET_THINKING' }
  | { type: 'SET_QUESTION'; payload: QuestionBlock; fromAnswer: boolean }
  | { type: 'COMPLETE' }

function convInterviewReducer(state: ConvInterviewState, action: ConvAction): ConvInterviewState {
  switch (action.type) {
    case 'SET_THINKING':
      return { ...state, convState: 'thinking' }
    case 'SET_QUESTION':
      return {
        convState: 'answering',
        currentQuestion: action.payload,
        answeredCount: action.fromAnswer ? state.answeredCount + 1 : state.answeredCount,
      }
    case 'COMPLETE':
      return { ...state, convState: 'thinking' }
    default:
      return state
  }
}

const initialConvState: ConvInterviewState = {
  convState: 'thinking',
  currentQuestion: null,
  answeredCount: 0,
}

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Gestiona el flujo conversacional con la IA para El Estratega (etapa 1).
 * - Llama a POST /next-question para obtener cada pregunta de Claude
 * - Muestra un indicador "Pensando..." mientras Claude responde
 * - No tiene barra de progreso ni botón de retroceso (flujo conversacional)
 */
function ConversationalInterview({
  sessionId,
  onComplete,
  onError,
}: {
  sessionId: string
  onComplete: () => void
  onError: (msg: string) => void
}) {
  const [convState, dispatch] = useReducer(convInterviewReducer, initialConvState)
  const { convState: state, currentQuestion, answeredCount } = convState

  // Draft answer separado porque no interactúa con otros estados del reducer
  const [draftAnswer, setDraftAnswer] = useState<unknown>(undefined)
  const initRef = useRef(false)

  /** Llama a /next-question. Si hay respuesta pendiente, la envía primero. */
  const fetchNext = useCallback(
    async (questionId?: string, answer?: unknown) => {
      dispatch({ type: 'SET_THINKING' })

      const body: Record<string, unknown> =
        questionId !== undefined && answer !== undefined
          ? { questionId, answer }
          : {}

      try {
        const res = await fetch(`/api/interview/sessions/${sessionId}/next-question`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        })

        if (!res.ok) {
          const err = await res.json().catch(() => null)
          if (err?.code === 'VERSION_CONFLICT') {
            onError('Tus respuestas se actualizaron en otra pestaña. Recargando...')
            setTimeout(() => window.location.reload(), 2000)
            return
          }
          onError(err?.error ?? 'Error al obtener la siguiente pregunta')
          return
        }

        const data = await res.json()

        if (data.complete) {
          // Disparar generación del brief en background — no esperamos el resultado.
          // La ProcessingScreen hace polling hasta que la sesión cambia a COMPLETED.
          // Los errores se loguean en consola para facilitar el debug.
          fetch(`/api/interview/sessions/${sessionId}/process`, { method: 'POST' })
            .then((r) => {
              if (!r.ok) console.error('[process] call failed', { sessionId, status: r.status })
              else console.log('[process] call ok', { sessionId, status: r.status })
            })
            .catch((err) => console.error('[process] network error', { sessionId, err }))
          dispatch({ type: 'COMPLETE' })
          onComplete()
          return
        }

        if (data.question) {
          setDraftAnswer(undefined)
          dispatch({ type: 'SET_QUESTION', payload: data.question as QuestionBlock, fromAnswer: !!questionId })
        }
      } catch {
        onError('No se pudo conectar. Revisá tu conexión e intentá de nuevo.')
      }
    },
    [sessionId, onComplete, onError],
  )

  // Obtener la primera pregunta al montar
  useEffect(() => {
    if (initRef.current) return
    initRef.current = true
    fetchNext()
  }, [fetchNext])

  const handleSubmitAnswer = useCallback(() => {
    if (!currentQuestion || draftAnswer === undefined || draftAnswer === '') return
    fetchNext(currentQuestion.id, draftAnswer)
  }, [currentQuestion, draftAnswer, fetchNext])

  const isThinking = state === 'thinking'

  if (isThinking) {
    return (
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8">
        <div className="flex items-center gap-4">
          <div className="flex gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
          <p className="text-[#64748B] text-sm">
            {answeredCount === 0 ? 'Preparando la entrevista...' : 'Analizando tu respuesta...'}
          </p>
        </div>
        {answeredCount === 0 && (
          <p className="text-[#475569] text-xs mt-4">
            Generalmente son entre 8 y 12 preguntas, adaptadas a tu negocio.
          </p>
        )}
      </div>
    )
  }

  if (!currentQuestion) return null

  const answerIsEmpty =
    draftAnswer === undefined ||
    draftAnswer === '' ||
    (Array.isArray(draftAnswer) && draftAnswer.length === 0)

  return (
    <div>
      {/* Contador de preguntas (sin total — es conversacional) */}
      {answeredCount > 0 && (
        <p className="text-[#475569] text-xs mb-4">Pregunta {answeredCount + 1}</p>
      )}

      <QuestionCard
        question={currentQuestion}
        value={draftAnswer}
        onChange={setDraftAnswer}
        isSaving={false}
      />

      <div className="flex justify-end mt-4">
        <button
          type="button"
          disabled={answerIsEmpty || isThinking}
          onClick={handleSubmitAnswer}
          className="px-6 py-2.5 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Siguiente
        </button>
      </div>
    </div>
  )
}

// ── Componente auxiliar ErrorBanner ──────────────────────────────────────────

function ErrorBanner({
  message,
  onRetry,
  onDismiss,
  className = '',
}: {
  message: string
  onRetry?: () => void
  onDismiss?: () => void
  className?: string
}) {
  return (
    <div
      className={`bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-xl p-4 ${className}`}
    >
      <div className="flex items-start gap-3">
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#EF4444"
          strokeWidth="2"
          className="mt-0.5 flex-shrink-0"
          aria-hidden="true"
        >
          <circle cx="12" cy="12" r="10" />
          <path d="M12 8v4m0 4h.01" strokeLinecap="round" />
        </svg>
        <p className="text-[#EF4444] text-sm flex-1">{message}</p>
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="text-[#EF4444]/60 hover:text-[#EF4444] transition-colors"
            aria-label="Cerrar"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
            </svg>
          </button>
        )}
      </div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-3 px-4 py-1.5 text-sm bg-[#1E293B] text-white rounded-lg hover:bg-[#334155] transition-colors"
        >
          Reintentar
        </button>
      )}
    </div>
  )
}
