'use client'

import { useFormContext } from 'react-hook-form'
import { ImageUploader } from '@/components/ui/image-uploader'
import type { CreateListingInput } from '@/lib/schemas/listing'

export function StepImages() {
  const { watch, setValue, formState: { errors } } = useFormContext<CreateListingInput>()
  const screenshotUrls = watch('screenshotUrls') ?? []

  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-400">
        Subí capturas de pantalla de tu activo. Las imágenes se subirán al enviar el listado.
        Un listado con buenas imágenes recibe hasta 3x más consultas.
      </p>
      <ImageUploader
        value={screenshotUrls}
        onChange={(urls) => setValue('screenshotUrls', urls, { shouldValidate: true })}
        maxImages={5}
        maxSizeMb={2}
        error={errors.screenshotUrls?.message}
      />
    </div>
  )
}
