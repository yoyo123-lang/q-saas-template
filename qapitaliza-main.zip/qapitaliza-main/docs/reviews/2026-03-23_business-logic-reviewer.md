# Revisión: Business Logic Reviewer
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de Business Logic Reviewer (Capa 2)

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 1 alto, 2 medios, 1 bajo
- Contrato base: `docs/BUSINESS_MODEL.md`

## Hallazgos

### [ALTO → CORREGIDO] viewCount se incrementaba en cada render, no por visita única
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Regla: BUSINESS_MODEL.md §Reglas de dominio: "El viewCount se incrementa por visita única (no por refresh). Implementación mínima: por IP o por sesión."
- Problema: El counter se incrementaba en cada request SSR, incluyendo refreshes y bots.
- Fix aplicado: Cookie `viewed_{id}` con `httpOnly: true`, `maxAge: 3600` — el mismo usuario no suma más de una vista por hora por listing.

### [MEDIO] Regla "SELLER no puede consultar su propio activo" no implementada en UI pública
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Regla: BUSINESS_MODEL.md §Reglas por rol: "CUANDO un SELLER intenta consultar su propio activo ENTONCES se muestra error 'No podés consultar tu propio activo'."
- Problema: La página pública no tiene acceso a la sesión del usuario, por lo que no puede evaluar esta regla. El botón "Consultar al vendedor" se muestra igual para todos.
- Aceptable en MVP: Esta regla se implementará en Sesión 05 (Server Actions de consultas), cuando se tenga la sesión disponible en SSR.

### [MEDIO] Botón "Favorito" no verifica si el usuario es el propio seller
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Regla implícita: Los favoritos son del buyer. El seller no debería guardarse su propio activo como favorito.
- Problema: No hay verificación de rol — cualquier usuario puede favoritar cualquier activo incluyendo los propios.
- Aceptable en MVP: Se implementará cuando la funcionalidad de favoritos esté completa con auth.

### [BAJO] Slug de listing generado en seed sin validar unicidad programáticamente
- Dónde: `prisma/seed.ts`
- Regla: BUSINESS_MODEL.md §Reglas de dominio: "El slug se genera automáticamente desde el título y debe ser único. Si hay colisión, se agrega sufijo numérico."
- Problema: El seed tiene slugs hardcodeados únicos, pero el código de creación de listings (Sesión 04) deberá implementar la lógica de slugify + deduplicación.
- Observación: No es un bug en el código actual de páginas públicas, sino un recordatorio para Sesión 04.

## Reglas del BUSINESS_MODEL.md verificadas en esta sesión

| Regla | Estado |
|-------|--------|
| Solo listings PUBLISHED aparecen en catálogo y detalle | ✅ Implementado (`where: { status: 'PUBLISHED' }`) |
| Catálogo paginado (20 por página, máx 100) | ✅ Implementado |
| viewCount por visita única | ✅ Corregido con cookie |
| Favoritos privados — sin contador público | ✅ No se muestra contador |
| Búsqueda full-text en título y descripción | ✅ Implementado con `contains + insensitive` |
| Screenshots: solo visualización, no upload (MVP) | ✅ Solo lectura en páginas públicas |
| Listados relacionados del mismo tipo | ✅ `getRelatedListings` filtra por `type` |

## Lo que está bien
- El DAL filtra consistentemente `status: 'PUBLISHED'` en todas las queries del catálogo público.
- El filtro de `verified` mapea correctamente a `verificationStatus: 'VERIFIED'`.
- La paginación respeta el límite máximo de 100 items.
- Las páginas públicas son read-only — no modifican estado sin autenticación.

## Recomendaciones generales
- Implementar verificación de rol en "Consultar al vendedor" y "Guardar favorito" en Sesión 05.
- Documentar el proceso de slugify + deduplicación antes de implementar el formulario de creación de listing.
