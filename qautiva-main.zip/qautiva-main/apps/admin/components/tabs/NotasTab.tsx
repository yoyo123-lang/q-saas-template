import type { OrgWithDetails, OrgNote } from '@/lib/types'
import { AgregarNotaForm } from '@/components/forms/AgregarNotaForm'

// ── Helpers ────────────────────────────────────────────────────────────────────

function formatDate(date: Date): string {
  return new Date(date).toLocaleString('es-AR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

// ── Sub-componentes ────────────────────────────────────────────────────────────

function NoteCard({ note }: { note: OrgNote }) {
  return (
    <div className="p-4 rounded-xl bg-[#0F172A] border border-[#1E293B]">
      <p className="text-white text-sm leading-relaxed whitespace-pre-wrap">{note.content}</p>
      <p className="text-[#475569] text-xs mt-2">{formatDate(note.createdAt)}</p>
    </div>
  )
}

// ── Tab principal ──────────────────────────────────────────────────────────────

interface NotasTabProps {
  notes: OrgWithDetails['notes']
  orgId: string
}

export function NotasTab({ notes, orgId }: NotasTabProps) {
  return (
    <div className="flex flex-col gap-4 flex-1 min-h-0">
      {/* Formulario nuevo */}
      <AgregarNotaForm orgId={orgId} />

      {/* Lista de notas */}
      <div className="flex flex-col gap-2 overflow-y-auto flex-1 pb-4">
        {notes.length === 0 ? (
          <p className="text-[#64748B] text-sm">Sin notas aún.</p>
        ) : (
          notes.map((note) => (
            <NoteCard key={note.id} note={note} />
          ))
        )}
      </div>
    </div>
  )
}
