import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { buildSlug } from '@/app/_lib/project-slug'
import { CORE_STAGES, SERVICE_STAGES, VALID_SERVICES, type ServiceType } from '@/app/_lib/service-stages'
import { createOrganizationLegacy } from '@/app/_lib/organization-legacy'
import { INDUSTRIES } from '@/app/onboarding/_constants/industries'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

/**
 * POST /api/projects
 * Wizard de creación de proyecto (2 pasos). Requiere onboarding_complete=true.
 * Paso 1: crea el Project con datos del negocio. Retorna { projectId }.
 * Paso 2: guarda servicios, crea Stages y Organization legacy. Retorna { projectId }.
 */
export async function POST(request: Request) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const meta = user.app_metadata ?? {}
  if (!meta.onboarding_complete) {
    return NextResponse.json({ error: 'Completá el onboarding primero' }, { status: 403 })
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const step = typeof body.step === 'number' ? body.step : Number(body.step)

  if (step === 1) return handleStep1(body, user.id)
  if (step === 2) return handleStep2(body, user.id)

  return NextResponse.json({ error: 'Step inválido' }, { status: 400 })
}

/**
 * Paso 1: valida datos del negocio y crea el Project con status SETUP.
 */
async function handleStep1(body: Record<string, unknown>, authUserId: string) {
  const name = (body.name as string | undefined)?.trim()
  const industry = (body.industry as string | undefined)?.trim()

  if (!name || !industry) {
    return NextResponse.json({ error: 'Nombre e industria son obligatorios' }, { status: 400 })
  }
  if (name.length > 100) {
    return NextResponse.json({ error: 'El nombre no puede superar los 100 caracteres' }, { status: 400 })
  }
  if (!(INDUSTRIES as readonly string[]).includes(industry)) {
    return NextResponse.json({ error: 'Industria inválida' }, { status: 400 })
  }

  const description = (body.description as string | undefined)?.trim()
  if (description && description.length > 500) {
    return NextResponse.json({ error: 'La descripción no puede superar los 500 caracteres' }, { status: 400 })
  }

  const city = (body.city as string | undefined)?.trim()
  if (city && city.length > 100) {
    return NextResponse.json({ error: 'La ciudad no puede superar los 100 caracteres' }, { status: 400 })
  }

  let profile
  try {
    profile = await prisma.userProfile.findUnique({
      where: { authUserId },
      select: {
        teamMemberships: {
          select: { team: { select: { id: true } } },
          orderBy: { createdAt: 'asc' },
          take: 1,
        },
      },
    })
  } catch (err) {
    console.error('[projects] step1: error al buscar perfil', err)
    return NextResponse.json({ error: 'Error de base de datos. Intentá de nuevo.' }, { status: 500 })
  }

  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'No se encontró el team del usuario' }, { status: 404 })
  }

  const team = profile.teamMemberships[0]!.team

  // Guard de permisos: solo ADMIN y OWNER pueden crear proyectos
  const perm = await checkTeamPermission(authUserId, team.id, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden crear proyectos.' },
      { status: 403 },
    )
  }

  const slug = buildSlug(name)

  try {
    const project = await prisma.project.create({
      data: {
        teamId: team.id,
        name,
        slug,
        industry,
        description: description || null,
        city: city || null,
        status: 'SETUP',
        selectedServices: [],
      },
    })

    return NextResponse.json({ projectId: project.id })
  } catch (err) {
    console.error('[projects] step1: error al crear proyecto', err)
    return NextResponse.json({ error: 'Error al crear el proyecto. Intentá de nuevo.' }, { status: 500 })
  }
}

const VALID_ACTIVATIONS = ['ACTIVE', 'SKIP', 'PROVIDED_BY_CLIENT'] as const
type StageActivationValue = typeof VALID_ACTIVATIONS[number]

/**
 * Paso 2: guarda servicios seleccionados, crea Stages y Organization legacy.
 * Verifica ownership del projectId para prevenir IDOR.
 */
async function handleStep2(body: Record<string, unknown>, authUserId: string) {
  const projectId = body.projectId as string | undefined
  const services = body.services as string[] | undefined

  if (!projectId || !services || services.length === 0) {
    return NextResponse.json({ error: 'projectId y servicios son obligatorios' }, { status: 400 })
  }

  const stageActivation = (body.stageActivation as Record<string, string> | undefined) ?? {}
  for (const [key, val] of Object.entries(stageActivation)) {
    if (!VALID_ACTIVATIONS.includes(val as StageActivationValue)) {
      return NextResponse.json({ error: `Activation inválida para ${key}: ${val}` }, { status: 400 })
    }
  }

  const includeIntake = body.includeIntake === true

  // Validar formato UUID para evitar errores 500 innecesarios
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(projectId)) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  const filteredServices = services.filter((s): s is ServiceType =>
    VALID_SERVICES.includes(s as ServiceType),
  )
  if (filteredServices.length === 0) {
    return NextResponse.json({ error: 'Seleccioná al menos un servicio válido' }, { status: 400 })
  }

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId },
    select: { id: true, teamMemberships: { select: { teamId: true } } },
  })
  if (!profile) {
    return NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  // Verificar ownership + idempotencia: el proyecto debe estar en SETUP.
  // Si ya está en GENERATING/ACTIVE, los stages ya fueron creados — no volver a crear.
  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null, status: 'SETUP' },
  })
  if (!project) {
    // Puede ser que no exista, no pertenezca al team, o ya fue procesado (status != SETUP)
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // Guard de permisos: solo ADMIN y OWNER pueden configurar servicios del proyecto
  const perm2 = await checkTeamPermission(authUserId, project.teamId, ['ADMIN', 'OWNER'])
  if (!perm2.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden configurar proyectos.' },
      { status: 403 },
    )
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.project.update({
        where: { id: projectId },
        data: { selectedServices: filteredServices },
      })

      // Stage 0 (opcional): intake interview, si se solicita explícitamente
      const intakeStageData = includeIntake
        ? [{
            projectId,
            teamId: project.teamId,
            number: 0,
            name: 'Intake',
            stageKey: 'INTAKE',
            activation: 'ACTIVE' as StageActivationValue,
            status: 'PENDING' as const,
            completedAt: null,
          }]
        : []

      // Stages 1 y 2: siempre se crean (Tu negocio + Mercado).
      const coreStageData = CORE_STAGES.map((s) => {
        const activation = (stageActivation[s.stageKey] ?? 'ACTIVE') as StageActivationValue
        return {
          projectId,
          teamId: project.teamId,
          number: s.number,
          name: s.name,
          stageKey: s.stageKey,
          activation,
          status: activation !== 'ACTIVE' ? 'COMPLETED' as const : 'PENDING' as const,
          completedAt: activation !== 'ACTIVE' ? new Date() : null,
        }
      })

      // Stages 3+: servicios seleccionados, ordenados por sortOrder.
      const serviceStageData = filteredServices
        .map((s) => SERVICE_STAGES[s])
        .filter((s): s is { sortOrder: number; name: string; stageKey: string } => s !== undefined)
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((stage, i) => {
          const activation = (stageActivation[stage.stageKey] ?? 'ACTIVE') as StageActivationValue
          return {
            projectId,
            teamId: project.teamId,
            number: CORE_STAGES.length + i + 1,   // 3, 4, 5, 6...
            name: stage.name,
            stageKey: stage.stageKey,
            activation,
            status: activation !== 'ACTIVE' ? 'COMPLETED' as const : 'PENDING' as const,
            completedAt: activation !== 'ACTIVE' ? new Date() : null,
          }
        })

      await tx.stage.createMany({
        data: [...intakeStageData, ...coreStageData, ...serviceStageData],
      })

      await tx.project.update({
        where: { id: projectId },
        data: { status: 'GENERATING' },
      })

      // Crear Organization legacy y vincular stages (compatibilidad con admin)
      const org = await createOrganizationLegacy(tx, project)

      // Actualizar organizationId en el perfil del usuario
      await tx.userProfile.update({
        where: { id: profile.id },
        data: { organizationId: org.id },
      })
    })

    revalidatePath('/proyectos')
    return NextResponse.json({ projectId })
  } catch (err) {
    console.error('[projects] step2: error en transacción', err)
    return NextResponse.json({ error: 'Error al crear el proyecto. Intentá de nuevo.' }, { status: 500 })
  }
}
