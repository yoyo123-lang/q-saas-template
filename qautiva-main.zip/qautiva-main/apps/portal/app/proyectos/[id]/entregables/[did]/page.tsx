import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ChevronLeft } from 'lucide-react'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { BrandApproval } from '@/components/BrandApproval'
import { WebPreview } from '@/components/WebPreview'
import { BriefDeliverable } from '@/components/BriefDeliverable'
import { MarketStudyDeliverable } from '@/components/MarketStudyDeliverable'
import { AdVisualsGallery } from '@/components/AdVisualsGallery'
import type { StrategicBrief, MarketStudy, AdVisuals } from '@/app/_lib/interview/types'
import { DeliverableAnalytics } from './_components/DeliverableAnalytics'

export function generateMetadata(): Metadata {
  // Sin consulta a DB — evitar IDOR (acceso a título sin auth/ownership check).
  // El título real se renderiza en el componente server-side con auth completo.
  return { title: 'Entregable — Qautiva' }
}

// Tipos de contenido de entregables (los mismos que en (protected)/entregables/[id]/page.tsx)
type BrandOptionContent = {
  id: string
  label: string
  logoUrl?: string
  colors: { hex: string; name: string }[]
  headingFont: string
  bodyFont: string
  brandPersonality: string[]
}

type BrandOptionsContent = {
  options: BrandOptionContent[]
  disclaimer?: string
}

type WebsiteContent = {
  previewUrl?: string
  html?: string
}

function isWebsiteContent(content: unknown): content is WebsiteContent {
  return (
    typeof content === 'object' &&
    content !== null &&
    ('previewUrl' in content || 'html' in content)
  )
}

function isAdVisualsContent(content: unknown): content is AdVisuals {
  return (
    typeof content === 'object' &&
    content !== null &&
    'visuals' in content &&
    Array.isArray((content as AdVisuals).visuals)
  )
}

function isBrandOptionsContent(content: unknown): content is BrandOptionsContent {
  return (
    typeof content === 'object' &&
    content !== null &&
    'options' in content &&
    Array.isArray((content as BrandOptionsContent).options)
  )
}


function GenericDeliverable({
  title,
  status,
}: {
  title: string
  content: unknown
  status: string
}) {
  const isApproved = status === 'CLIENT_APPROVED'

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold text-white mb-2">{title}</h1>
      {isApproved && (
        <span className="inline-block bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 text-xs font-medium px-2.5 py-1 rounded-full mb-6">
          Aprobado
        </span>
      )}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
        <div className="w-12 h-12 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 flex items-center justify-center mx-auto mb-4">
          <span className="text-[#A78BFA] text-xl font-bold">Q</span>
        </div>
        <p className="text-white font-medium mb-2">Entregable en preparación</p>
        <p className="text-[#94A3B8] text-sm">
          Nuestro equipo está trabajando en este entregable. Te avisamos por email cuando esté listo para revisar.
        </p>
      </div>
    </div>
  )
}

export default async function ProjectEntregableDetailPage({
  params,
}: {
  params: { id: string; did: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) notFound()

  // Verificar ownership vía team membership
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    include: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) notFound()

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const deliverable = await prisma.deliverable.findFirst({
    where: {
      id: params.did,
      projectId: params.id,
      teamId: { in: teamIds },
    },
    select: {
      id: true,
      title: true,
      type: true,
      status: true,
      content: true,
      feedback: true,
    },
  })

  if (!deliverable) notFound()

  const canApprove = deliverable.status === 'SENT_TO_CLIENT'

  return (
    <div className="flex flex-col min-h-full">
      {/* Breadcrumb */}
      <div className="px-8 pt-6 pb-2">
        <Link
          href={`/proyectos/${params.id}/progreso`}
          className="inline-flex items-center gap-1.5 text-[#64748B] text-sm hover:text-[#94A3B8] transition-colors duration-200"
        >
          <ChevronLeft size={14} aria-hidden="true" />
          Mi progreso
        </Link>
      </div>

      {/* Feedback previo si lo hay */}
      {deliverable.feedback && (
        <div className="mx-8 mb-2 bg-[#F59E0B]/10 border border-[#F59E0B]/30 rounded-lg px-4 py-3">
          <p className="text-[#F59E0B] text-xs font-medium mb-1">Tu feedback anterior:</p>
          <p className="text-[#94A3B8] text-sm">{deliverable.feedback}</p>
        </div>
      )}

      {/* Contenido principal según tipo */}
      {deliverable.type === 'BRIEF' ? (
        <BriefDeliverable
          deliverableId={deliverable.id}
          projectId={params.id}
          title={deliverable.title}
          brief={deliverable.content as StrategicBrief}
          canApprove={canApprove}
        />
      ) : deliverable.type === 'MARKET_STUDY' ? (
        <MarketStudyDeliverable
          deliverableId={deliverable.id}
          projectId={params.id}
          title={deliverable.title}
          study={deliverable.content as MarketStudy}
          canApprove={canApprove}
        />
      ) : deliverable.type === 'BRAND_OPTIONS' && isBrandOptionsContent(deliverable.content) ? (
        <BrandApproval
          deliverableId={deliverable.id}
          projectId={params.id}
          title={deliverable.title}
          options={deliverable.content.options}
          disclaimer={deliverable.content.disclaimer}
          canApprove={canApprove}
        />
      ) : deliverable.type === 'WEBSITE_PREVIEW' && isWebsiteContent(deliverable.content) ? (
        <>
          <WebPreview
            deliverableId={deliverable.id}
            projectId={params.id}
            title={deliverable.title}
            previewUrl={deliverable.content.previewUrl}
            canApprove={canApprove}
          />
          <div className="px-8 pb-6">
            <DeliverableAnalytics deliverableId={deliverable.id} />
          </div>
        </>
      ) : deliverable.type === 'AD_VISUALS' && isAdVisualsContent(deliverable.content) ? (
        <div className="px-8 py-6 max-w-4xl">
          <h1 className="text-2xl font-bold text-white mb-2">{deliverable.title}</h1>
          <p className="text-[#94A3B8] text-sm mb-6">
            {deliverable.content.visuals.length} pieza{deliverable.content.visuals.length !== 1 ? 's' : ''} generada{deliverable.content.visuals.length !== 1 ? 's' : ''} para Meta Ads
          </p>
          <AdVisualsGallery visuals={deliverable.content.visuals} />
          {deliverable.content.disclaimer && (
            <p className="text-[#475569] text-xs italic mt-4">{deliverable.content.disclaimer}</p>
          )}
        </div>
      ) : (
        <GenericDeliverable
          title={deliverable.title}
          content={deliverable.content}
          status={deliverable.status}
        />
      )}
    </div>
  )
}
