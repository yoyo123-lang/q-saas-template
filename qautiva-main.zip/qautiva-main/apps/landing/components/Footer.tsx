import Image from 'next/image'
import { Instagram, Linkedin, Twitter } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-navy-950 border-t border-navy-800 py-12">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Izquierda: logo */}
          <Image
            src="/logo.png"
            alt="Qautiva Marketing"
            width={480}
            height={160}
            className="h-32 w-auto"
          />

          {/* Centro: links */}
          <nav className="flex items-center gap-6">
            <a
              href="/terminos"
              className="text-slate-500 hover:text-white text-sm transition-colors duration-200"
            >
              Términos
            </a>
            <a
              href="/privacidad"
              className="text-slate-500 hover:text-white text-sm transition-colors duration-200"
            >
              Privacidad
            </a>
            <a
              href="#precios"
              className="text-slate-500 hover:text-white text-sm transition-colors duration-200"
            >
              Contacto
            </a>
          </nav>

          {/* Derecha */}
          <p className="text-slate-500 text-sm">
            © {new Date().getFullYear()} qautiva · Parte de Q Company
          </p>
        </div>

        {/* Íconos sociales */}
        <div className="flex justify-center gap-5 mt-8 pt-8 border-t border-navy-800">
          <a
            href="https://instagram.com/qautiva"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram de qautiva"
            className="text-slate-600 hover:text-white transition-colors duration-200"
          >
            <Instagram size={18} />
          </a>
          <a
            href="https://linkedin.com/company/qautiva"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn de qautiva"
            className="text-slate-600 hover:text-white transition-colors duration-200"
          >
            <Linkedin size={18} />
          </a>
          <a
            href="https://twitter.com/qautiva"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Twitter de qautiva"
            className="text-slate-600 hover:text-white transition-colors duration-200"
          >
            <Twitter size={18} />
          </a>
        </div>
      </div>
    </footer>
  )
}
