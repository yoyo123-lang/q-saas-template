'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import {
  LayoutDashboard, Package, Heart, MessageSquare, User, LogOut, Plus,
  Users, BarChart3,
} from 'lucide-react'
import { cn } from '@/lib/utils/cn'
import { LogoQ } from '@/components/shared/logo-q'
import { createClient } from '@/lib/supabase/client'
import { useInterval } from '@/lib/hooks/use-interval'
import { getPendingCountAction } from '@/lib/actions/admin'

interface SidebarUser {
  name: string
  email: string
  role: string
  avatarInitials: string
}

interface SidebarProps {
  variant?: 'dashboard' | 'admin'
  unreadInquiries?: number
  pendingCount?: number
  user?: SidebarUser
}

const dashboardNav = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/mis-activos', label: 'Mis activos', icon: Package },
  { href: '/consultas', label: 'Consultas', icon: MessageSquare, badgeKey: 'inquiries' as const },
  { href: '/favoritos', label: 'Favoritos', icon: Heart },
  { href: '/perfil', label: 'Perfil', icon: User },
]

const adminNav = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard, exact: true },
  { href: '/admin/listados', label: 'Listados', icon: Package, badgeKey: 'pending' as const },
  { href: '/admin/usuarios', label: 'Usuarios', icon: Users },
  { href: '/admin/reportes', label: 'Reportes', icon: BarChart3 },
]

const roleColors: Record<string, string> = {
  SELLER: 'bg-blue-500',
  BUYER: 'bg-emerald-500',
  ADMIN: 'bg-amber-500',
}

const roleLabels: Record<string, string> = {
  SELLER: 'Vendedor',
  BUYER: 'Comprador',
  ADMIN: 'Admin',
}

export function Sidebar({
  variant = 'dashboard',
  unreadInquiries = 0,
  pendingCount: initialPendingCount = 0,
  user,
}: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [pendingCount, setPendingCount] = useState(initialPendingCount)

  // Poll pending count every 5 minutes when in admin variant
  useInterval(
    () => {
      if (variant !== 'admin') return
      getPendingCountAction()
        .then((count) => setPendingCount(count))
        .catch(() => {})
    },
    5 * 60 * 1000
  )

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  const isAdmin = variant === 'admin'
  const navItems = isAdmin ? adminNav : dashboardNav

  return (
    <aside className="fixed left-0 top-0 h-screen w-[280px] bg-navy-950 border-r border-slate-800 flex flex-col z-40">
      {/* Logo */}
      <div className="p-6 border-b border-slate-800">
        <Link href={isAdmin ? '/admin' : '/dashboard'}>
          <LogoQ size="md" showText adminBadge={isAdmin} />
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto" aria-label="Navegación principal">
        {navItems.map(({ href, label, icon: Icon, badgeKey, ...rest }) => {
          const exact = (rest as { exact?: boolean }).exact
          const isActive = exact
            ? pathname === href
            : pathname === href || pathname.startsWith(href + '/')

          const showInquiriesBadge = badgeKey === 'inquiries' && unreadInquiries > 0
          const showPendingBadge = badgeKey === 'pending' && pendingCount > 0

          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'relative flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'nav-active bg-amber-500/[0.08] text-amber-500 before:absolute before:left-0 before:inset-y-0 before:w-[3px] before:bg-amber-500 before:rounded-r-sm'
                  : 'text-slate-400 hover:text-slate-50 hover:bg-slate-800'
              )}
            >
              <Icon size={18} />
              <span className="flex-1">{label}</span>
              {showInquiriesBadge && (
                <span className="size-5 text-xs font-semibold bg-amber-500 text-navy-950 rounded-full flex items-center justify-center">
                  {unreadInquiries > 9 ? '9+' : unreadInquiries}
                </span>
              )}
              {showPendingBadge && (
                <span className="size-5 text-xs font-semibold bg-red-500 text-white rounded-full flex items-center justify-center animate-pulse">
                  {pendingCount > 99 ? '99+' : pendingCount}
                </span>
              )}
            </Link>
          )
        })}

        {/* Dashboard: separator + Nuevo listado */}
        {!isAdmin && (
          <div className="pt-3 pb-1">
            <div className="h-px bg-slate-800 mb-3" />
            <Link
              href="/mis-activos/nuevo"
              className="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-lg text-sm font-medium border border-amber-500 text-amber-500 hover:bg-amber-500/10 transition-colors"
            >
              <Plus size={16} />
              Nuevo listado
            </Link>
          </div>
        )}
      </nav>

      {/* Footer with user info + logout */}
      <div className="p-4 border-t border-slate-800">
        {user && (
          <div className="flex items-center gap-3 px-2 py-2 mb-2">
            <div
              className={cn(
                'size-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0',
                roleColors[user.role] ?? 'bg-slate-700'
              )}
            >
              {user.avatarInitials}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-200 truncate">{user.name}</p>
              <p className="text-xs text-slate-500">{roleLabels[user.role] ?? user.role}</p>
            </div>
          </div>
        )}
        <button
          onClick={handleSignOut}
          className="flex items-center gap-3 px-4 py-2.5 w-full rounded-lg text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut size={18} />
          Cerrar sesión
        </button>
      </div>
    </aside>
  )
}
