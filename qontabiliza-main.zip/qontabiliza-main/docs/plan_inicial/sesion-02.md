# Sesión 02: Multi-tenancy (frontend) y onboarding

## Objetivo
API routes para Organization y Membership. TenantProvider en React. Selector de organización en sidebar. Wizard de onboarding para nuevos usuarios. Al terminar, un usuario puede crear una organización, invitar miembros, y la app entera funciona scoped al tenant activo.

## Pre-requisitos
- Sesión 01 completada (schema, migración, withTenant)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/lib/tenant.ts` (helper de S01)
3. Leer `src/app/api/v1/projects/` como patrón de referencia para API routes
4. Leer `src/hooks/use-projects.ts` como patrón de referencia para hooks
5. Leer `src/components/layout/nav-config.ts` para entender la navegación actual

---

## Etapa 1: API routes para Organization

### Tarea 1.1: Validaciones Zod para Organization
**Archivo nuevo**: `src/lib/validations/organization.ts`

Schemas:
- `createOrganizationSchema` — name (requerido), legalName, cuit, ivaCondition, address, phone, email
- `updateOrganizationSchema` — todos opcionales excepto name
- Validar CUIT con formato XX-XXXXXXXX-X (regex)
- Validar ivaCondition contra enum de Prisma

### Tarea 1.2: API routes CRUD Organization
**Archivos nuevos**:
- `src/app/api/v1/organizations/route.ts` — GET (list mis orgs), POST (crear org)
- `src/app/api/v1/organizations/[id]/route.ts` — GET, PUT, DELETE

Patrón a seguir: copiar estructura de `src/app/api/v1/projects/` pero:
- GET list: traer solo organizaciones donde el usuario tiene membership
- POST create: crear organización + membership OWNER automática + warehouse "Principal" por defecto
- PUT/DELETE: solo si el usuario es OWNER o ADMIN de esa org

### Tarea 1.3: API routes Membership
**Archivos nuevos**:
- `src/app/api/v1/organizations/[id]/members/route.ts` — GET (list members), POST (invitar)
- `src/app/api/v1/organizations/[id]/members/[memberId]/route.ts` — PUT (cambiar rol), DELETE (remover)

Reglas:
- Solo OWNER y ADMIN pueden invitar/remover miembros
- No se puede remover al último OWNER
- Para MVP: invitación directa (sin email). El user debe existir previamente en AllowedEmail + User

**Commit**: `feat(api): add Organization and Membership CRUD endpoints`

---

## Etapa 2: TenantProvider y contexto

### Tarea 2.1: Hook y provider de tenant
**Archivo nuevo**: `src/hooks/use-tenant.ts`

```typescript
// Hook que:
// 1. Lee el tenantId de localStorage (persistencia entre sesiones)
// 2. Si no hay tenantId guardado, busca la primera organización del user
// 3. Expone: { currentTenant, setCurrentTenant, isLoading, memberships }
// 4. Valida que el user tenga membership activa en el tenant seleccionado
```

**Archivo nuevo**: `src/components/providers/tenant-provider.tsx`

```typescript
// TenantContext con:
// - currentTenant: Organization | null
// - currentMembership: Membership | null (incluye role)
// - switchTenant: (orgId: string) => void
// - isLoading: boolean
// Wrappea toda la app en /dashboard
```

### Tarea 2.2: Integrar TenantProvider en layout
**Archivo a modificar**: `src/app/dashboard/layout.tsx`

Envolver el layout del dashboard con `<TenantProvider>`. Si el user no tiene ninguna organización, redirigir a `/onboarding`.

### Tarea 2.3: Hook para API calls con tenant
**Archivo a modificar**: `src/hooks/api.ts`

Modificar el fetch wrapper para que incluya header `x-tenant-id` en todas las requests. Las API routes leerán este header para saber qué tenant está activo.

**Archivo nuevo**: `src/lib/get-tenant-from-request.ts`

Helper server-side que extrae el tenantId del header `x-tenant-id`, valida que el user autenticado tenga membership en esa org, y retorna el tenantId validado. Si no es válido, retorna error 403.

**Commit**: `feat(tenant): add TenantProvider, tenant context and API tenant header`

---

## Etapa 3: UI de selector y creación de org

### Tarea 3.1: Selector de organización en sidebar
**Archivo nuevo**: `src/components/layout/org-switcher.tsx`

Componente dropdown en el sidebar (arriba de la navegación) que muestra:
- Logo + nombre de la org actual
- Lista de orgs del usuario (si tiene más de una)
- Botón "Crear nueva organización"
- Indicador del rol del usuario en cada org

**Archivo a modificar**: `src/components/layout/sidebar.tsx` — agregar OrgSwitcher arriba de la navegación

### Tarea 3.2: Página de crear organización
**Archivo nuevo**: `src/app/dashboard/organizations/new/page.tsx`

Formulario con campos:
- Nombre comercial (requerido)
- Razón social
- CUIT (con máscara XX-XXXXXXXX-X)
- Condición IVA (dropdown)
- Domicilio fiscal
- Teléfono, email

Al crear: redirige al dashboard con la nueva org como tenant activo.

### Tarea 3.3: Página de settings de organización
**Archivo nuevo**: `src/app/dashboard/settings/organization/page.tsx`

Mismos campos que la creación, pero para editar. Incluye sección de "Miembros" con:
- Lista de miembros con rol
- Botón para invitar nuevo miembro (solo OWNER/ADMIN)
- Botón para cambiar rol
- Botón para remover (no al último OWNER)

**Commit**: `feat(ui): add org switcher, create org page and org settings`

---

## Etapa 4: Onboarding wizard

### Tarea 4.1: Página de onboarding
**Archivo nuevo**: `src/app/onboarding/page.tsx`

Wizard de 3 pasos:
1. **Tu negocio** — Nombre, CUIT, condición IVA (los datos de Organization)
2. **Tu primer producto** — Nombre, precio, categoría (crea 1 producto de ejemplo)
3. **Tu primer cliente** — Nombre, CUIT (o "Consumidor Final" por defecto) (crea 1 contacto)

Al terminar: crea Organization + Membership OWNER + Warehouse + Product + Contact, y redirige a `/dashboard`.

### Tarea 4.2: Layout de onboarding
**Archivo nuevo**: `src/app/onboarding/layout.tsx`

Layout limpio sin sidebar (el usuario aún no tiene org). Logo de Qontabiliza, stepper visual de progreso, botones Anterior/Siguiente.

### Tarea 4.3: Actualizar navegación
**Archivo a modificar**: `src/components/layout/nav-config.ts`

Actualizar con las secciones de Qontabiliza:
```typescript
// Navegación Fase 1:
// - Dashboard (icon: LayoutDashboard)
// - Productos (icon: Package)
// - Clientes (icon: Users)
// - Facturación (icon: FileText)
// - Ventas (icon: ShoppingCart)
// - Stock (icon: Warehouse)
// - Caja (icon: Banknote)
// - Reportes (icon: BarChart3)
// - Configuración (icon: Settings)
```

Las páginas aún no existen — van a mostrar "Próximamente" o estar vacías. Se construyen en sesiones siguientes.

**Commit**: `feat(onboarding): add onboarding wizard and update navigation`

---

## Checklist de cierre de sesión

- [ ] API routes de Organization y Membership funcionando
- [ ] TenantProvider wrappea todo el dashboard
- [ ] Header `x-tenant-id` se envía en todas las API calls
- [ ] Selector de organización en sidebar funcional
- [ ] Wizard de onboarding crea org + datos iniciales
- [ ] Navegación actualizada con secciones de Qontabiliza
- [ ] Tests de API routes
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
