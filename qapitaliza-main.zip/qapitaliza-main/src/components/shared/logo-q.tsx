import { cn } from '@/lib/utils/cn'

interface LogoQProps {
  size?: 'sm' | 'md' | 'lg'
  showText?: boolean
  adminBadge?: boolean
  className?: string
}

const sizeClasses = {
  sm: { box: 'size-8 text-sm', text: 'text-sm' },
  md: { box: 'size-10 text-base', text: 'text-base' },
  lg: { box: 'size-16 text-xl', text: 'text-lg' },
}

export function LogoQ({ size = 'md', showText = false, adminBadge = false, className }: LogoQProps) {
  const classes = sizeClasses[size]

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div
        className={cn(
          'bg-amber-500 rounded-lg flex items-center justify-center font-bold text-navy-950 flex-shrink-0',
          classes.box
        )}
        aria-label="Qapitaliza logo"
      >
        Q
      </div>

      {showText && (
        <span className={cn('font-semibold text-slate-50', classes.text)}>
          qapitaliza
        </span>
      )}

      {adminBadge && (
        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/15 text-amber-500">
          Admin
        </span>
      )}
    </div>
  )
}
