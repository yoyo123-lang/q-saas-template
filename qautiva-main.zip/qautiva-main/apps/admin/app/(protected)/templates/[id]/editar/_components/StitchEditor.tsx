'use client'

import { useState, useEffect } from 'react'

interface Template {
  id: string
  name: string
  stitchProjectId: string | null
  stitchScreenId: string | null
  htmlBase: string | null
  source: string
}

interface Props {
  template: Template
}

interface EditResult {
  processedHtml: string
  detectedSections: Record<string, boolean>
}

type ScreenStatus = 'unknown' | 'ok' | 'missing'

export function StitchEditor({ template }: Props) {
  const [prompt, setPrompt] = useState('')
  const [isApplying, setIsApplying] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [currentHtml, setCurrentHtml] = useState<string | null>(template.htmlBase)
  const [screenStatus, setScreenStatus] = useState<ScreenStatus>('unknown')

  const isStitchTemplate =
    template.source === 'STITCH' && !!template.stitchProjectId && !!template.stitchScreenId

  useEffect(() => {
    if (!isStitchTemplate) return
    setScreenStatus('ok')
    // El screen se verifica implícitamente al intentar editar.
    // Si el SDK retorna 404, el error se muestra en handleApply.
  }, [isStitchTemplate])

  if (!isStitchTemplate) {
    return (
      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 text-[#94A3B8] text-sm">
        Este template no fue creado con Stitch. Usá TabCodigo para editar el HTML manualmente.
      </div>
    )
  }

  async function handleApply() {
    if (!prompt.trim()) {
      setError('El prompt es requerido')
      return
    }

    setError(null)
    setIsApplying(true)

    try {
      const res = await fetch('/api/stitch/edit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ templateId: template.id, prompt: prompt.trim() }),
      })

      if (res.status === 404) {
        setScreenStatus('missing')
        setError('El screen de Stitch asociado a este template ya no está disponible. Podés re-generarlo o editarlo manualmente en TabCodigo.')
        return
      }

      if (!res.ok) {
        const data = (await res.json()) as { error: string; reason?: string }
        setError(data.reason ? `${data.error} (${data.reason})` : data.error)
        return
      }

      const data = (await res.json()) as EditResult
      setCurrentHtml(data.processedHtml)
      setPrompt('')
    } catch {
      setError('Error al conectar con el servidor')
    } finally {
      setIsApplying(false)
    }
  }

  if (screenStatus === 'missing') {
    return (
      <div className="border border-yellow-400/20 bg-yellow-400/10 rounded-lg p-6 text-yellow-400 text-sm">
        El screen de Stitch asociado a este template ya no está disponible. Podés re-generarlo o
        editarlo manualmente en TabCodigo.
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Formulario de edición */}
      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-[#94A3B8]">
            Prompt de edición <span className="text-red-400">*</span>
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={isApplying}
            rows={3}
            placeholder="Ej: Cambiá la paleta a colores cálidos y agregá más espacio en el hero."
            className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors resize-none disabled:opacity-50"
          />
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}

        <div>
          <button
            onClick={handleApply}
            disabled={isApplying}
            className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isApplying ? 'Aplicando cambios...' : 'Aplicar cambios'}
          </button>
        </div>
      </div>

      {/* Preview */}
      {currentHtml && (
        <div className="border border-[#1E293B] rounded-lg overflow-hidden">
          <div className="px-4 py-2 bg-[#0F172A] border-b border-[#1E293B]">
            <span className="text-xs text-[#64748B]">Preview actual</span>
          </div>
          <iframe
            srcDoc={currentHtml}
            sandbox="allow-scripts"
            className="w-full h-[600px] bg-white"
            title="Preview del template"
          />
        </div>
      )}
    </div>
  )
}
