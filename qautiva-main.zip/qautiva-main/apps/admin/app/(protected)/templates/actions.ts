'use server'

import { revalidatePath } from 'next/cache'
import { Prisma } from '@qautiva/db'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { logAudit } from '@/lib/audit'
import { DEFAULT_SECTIONS } from './_constants'

export type ActionState = { ok: true } | { ok: false; error: string }
export type CreateActionState = { ok: true; id: string } | { ok: false; error: string }

// Límite de tamaño para HTML y CSS (1MB)
const MAX_HTML_CSS_SIZE = 1_000_000

/**
 * Elimina vectores XSS del HTML almacenado en templates.
 * Cubre los vectores más comunes: script/style/iframe/svg, event handlers, protocolos peligrosos.
 * IMPORTANTE: No reemplaza a un sanitizador completo (ej: DOMPurify) en el lado de renderizado.
 * El renderizado final debe escapar el HTML o usar un sandbox (iframe sandboxed).
 */
function sanitizeTemplateHtml(html: string): string {
  return html
    // Remover tags peligrosos con su contenido
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<iframe[\s\S]*?<\/iframe>/gi, '')
    .replace(/<object[\s\S]*?<\/object>/gi, '')
    .replace(/<svg[\s\S]*?<\/svg>/gi, '')
    .replace(/<form[\s\S]*?<\/form>/gi, '')
    // Remover tags void peligrosos
    .replace(/<embed[^>]*\/?>/gi, '')
    .replace(/<link[^>]*\/?>/gi, '')
    // Remover event handlers (quoted, unquoted, con variaciones de espaciado)
    .replace(/\s+on\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]*)/gi, '')
    // Remover protocolos peligrosos
    .replace(/\b(javascript|vbscript|data)\s*:/gi, '')
}

/**
 * Valida que la URL del catálogo sea segura para hacer fetch.
 * Previene SSRF: bloquea IPs de metadata cloud y protocolos no HTTP(S).
 */
function validateCatalogUrl(rawUrl: string): boolean {
  let parsed: URL
  try {
    parsed = new URL(rawUrl)
  } catch {
    return false
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false
  const hostname = parsed.hostname
  // Bloquear IPs de metadata de cloud providers (AWS, GCP, Azure)
  if (hostname === '169.254.169.254' || hostname === '100.100.100.200' || hostname === 'metadata.google.internal') {
    return false
  }
  return true
}

/**
 * Valida que una URL de thumbnail sea segura (http/https solamente).
 * Previene XSS via javascript: o data: URLs.
 */
function validateThumbnailUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'https:' || parsed.protocol === 'http:'
  } catch {
    return false
  }
}

export async function createWebTemplate(
  _prev: CreateActionState | null,
  formData: FormData,
): Promise<CreateActionState> {
  const { userId } = await requireAdminSession()

  const name = formData.get('name')?.toString().trim() ?? ''
  if (!name) return { ok: false, error: 'El nombre es obligatorio.' }
  if (name.length > 200) return { ok: false, error: 'El nombre no puede superar 200 caracteres.' }

  try {
    const template = await prisma.webTemplate.create({
      data: {
        name,
        compatibleIndustries: [],
        sections: DEFAULT_SECTIONS,
      },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: template.id,
      newState: { name },
    })

    revalidatePath('/templates')
    return { ok: true, id: template.id }
  } catch (err: unknown) {
    // P2002 = unique constraint violation
    if ((err as { code?: string })?.code === 'P2002') {
      return { ok: false, error: 'Ya existe un template con ese nombre.' }
    }
    console.error('[createWebTemplate]', err)
    return { ok: false, error: 'Error al crear el template. Intentá de nuevo.' }
  }
}

export async function updateTemplateInfo(
  _prev: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  const { userId } = await requireAdminSession()

  const id = formData.get('id')?.toString().trim() ?? ''
  const name = formData.get('name')?.toString().trim() ?? ''
  const description = formData.get('description')?.toString().trim() ?? ''
  const thumbnail = formData.get('thumbnail')?.toString().trim() ?? ''
  const statusRaw = formData.get('status')?.toString() ?? ''
  const industriesRaw = formData.get('compatibleIndustries')?.toString() ?? '[]'

  if (!id) return { ok: false, error: 'ID inválido.' }
  if (!name) return { ok: false, error: 'El nombre es obligatorio.' }
  if (name.length > 200) return { ok: false, error: 'El nombre no puede superar 200 caracteres.' }
  if (description.length > 500) return { ok: false, error: 'La descripción no puede superar 500 caracteres.' }

  // Validar URL de thumbnail si se proveyó
  if (thumbnail) {
    try {
      const url = new URL(thumbnail)
      if (url.protocol !== 'https:' && url.protocol !== 'http:') {
        return { ok: false, error: 'El thumbnail debe ser una URL válida.' }
      }
    } catch {
      return { ok: false, error: 'El thumbnail debe ser una URL válida.' }
    }
  }

  const status =
    statusRaw === 'ACTIVE' || statusRaw === 'DRAFT' ? statusRaw : undefined
  if (!status) return { ok: false, error: 'Estado inválido.' }

  let compatibleIndustries: string[]
  try {
    compatibleIndustries = JSON.parse(industriesRaw)
    if (!Array.isArray(compatibleIndustries)) throw new Error()
  } catch {
    return { ok: false, error: 'Lista de industrias inválida.' }
  }

  try {
    const previous = await prisma.webTemplate.findUnique({
      where: { id },
      select: { name: true, description: true, thumbnail: true, status: true, compatibleIndustries: true },
    })

    await prisma.webTemplate.update({
      where: { id },
      data: {
        name,
        description: description || null,
        thumbnail: thumbnail || null,
        compatibleIndustries,
        status,
      },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: id,
      previousState: previous,
      newState: { name, description, thumbnail, status, compatibleIndustries },
    })

    revalidatePath('/templates')
    revalidatePath(`/templates/${id}`)
    return { ok: true }
  } catch (err: unknown) {
    if ((err as { code?: string })?.code === 'P2002') {
      return { ok: false, error: 'Ya existe otro template con ese nombre.' }
    }
    console.error('[updateTemplateInfo]', err)
    return { ok: false, error: 'Error al guardar. Intentá de nuevo.' }
  }
}

export async function updateTemplateSections(
  _prev: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  const { userId } = await requireAdminSession()

  const id = formData.get('id')?.toString().trim() ?? ''
  const sectionsRaw = formData.get('sections')?.toString() ?? '{}'

  if (!id) return { ok: false, error: 'ID inválido.' }

  let sections: Record<string, boolean>
  try {
    sections = JSON.parse(sectionsRaw)
    if (typeof sections !== 'object' || Array.isArray(sections)) throw new Error()
  } catch {
    return { ok: false, error: 'Secciones inválidas.' }
  }

  // Hero siempre obligatorio
  sections.hero = true

  try {
    const previous = await prisma.webTemplate.findUnique({
      where: { id },
      select: { sections: true },
    })

    await prisma.webTemplate.update({
      where: { id },
      data: { sections },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: id,
      previousState: { sections: previous?.sections },
      newState: { sections },
    })

    revalidatePath(`/templates/${id}`)
    return { ok: true }
  } catch (err) {
    console.error('[updateTemplateSections]', err)
    return { ok: false, error: 'Error al guardar. Intentá de nuevo.' }
  }
}

export async function updateTemplateCode(
  _prev: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  const { userId } = await requireAdminSession()

  const id = formData.get('id')?.toString().trim() ?? ''
  const htmlBase = formData.get('htmlBase')?.toString() ?? ''
  const css = formData.get('css')?.toString() ?? ''
  const variablesRaw = formData.get('variables')?.toString() ?? ''

  if (!id) return { ok: false, error: 'ID inválido.' }
  if (htmlBase.length > MAX_HTML_CSS_SIZE) return { ok: false, error: 'El HTML supera el tamaño máximo permitido (1MB).' }
  if (css.length > MAX_HTML_CSS_SIZE) return { ok: false, error: 'El CSS supera el tamaño máximo permitido (1MB).' }

  let variables: Record<string, string> | null
  try {
    variables = variablesRaw.trim() ? JSON.parse(variablesRaw) : null
    if (variables !== null && (typeof variables !== 'object' || Array.isArray(variables))) {
      throw new Error()
    }
  } catch {
    return { ok: false, error: 'Variables JSON inválido.' }
  }

  // Sanitizar HTML y CSS para prevenir XSS almacenado
  const sanitizedHtml = htmlBase.trim() ? sanitizeTemplateHtml(htmlBase) : null
  const sanitizedCss = css.trim() || null

  try {
    await prisma.webTemplate.update({
      where: { id },
      data: {
        htmlBase: sanitizedHtml,
        css: sanitizedCss,
        variables: variables ?? Prisma.JsonNull,
      },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: id,
      newState: { htmlBase: sanitizedHtml ? '[presente]' : null, css: sanitizedCss ? '[presente]' : null },
    })

    revalidatePath(`/templates/${id}`)
    return { ok: true }
  } catch (err) {
    console.error('[updateTemplateCode]', err)
    return { ok: false, error: 'Error al guardar. Intentá de nuevo.' }
  }
}

export async function deleteWebTemplate(
  _prev: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  const { userId } = await requireAdminSession()

  const id = formData.get('id')?.toString().trim() ?? ''
  if (!id) return { ok: false, error: 'ID inválido.' }

  try {
    const template = await prisma.webTemplate.findUnique({
      where: { id },
      select: { name: true, usageCount: true },
    })

    if (!template) return { ok: false, error: 'Template no encontrado.' }
    if (template.usageCount > 0) {
      return {
        ok: false,
        error: `Tiene ${template.usageCount} uso(s) activo(s). No se puede eliminar.`,
      }
    }

    await prisma.webTemplate.delete({ where: { id } })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: id,
      previousState: { name: template.name },
      reason: 'Eliminado por admin',
    })

    revalidatePath('/templates')
    return { ok: true }
  } catch (err) {
    console.error('[deleteWebTemplate]', err)
    return { ok: false, error: 'Error al eliminar. Intentá de nuevo.' }
  }
}

/**
 * Importa un template desde el catálogo externo (qautiva-templates).
 * Fetches el HTML/CSS del slug dado, crea un WebTemplate en la DB en estado DRAFT.
 */
export async function importWebTemplate(
  _prev: CreateActionState | null,
  formData: FormData,
): Promise<CreateActionState> {
  const { userId } = await requireAdminSession()

  const slug = formData.get('slug')?.toString().trim() ?? ''
  if (!slug) return { ok: false, error: 'Slug inválido.' }
  // Validar slug: solo letras, números y guiones
  if (!/^[a-z0-9-]+$/.test(slug)) return { ok: false, error: 'Slug con caracteres inválidos.' }

  const rawCatalogUrl = process.env.TEMPLATES_CATALOG_URL
  if (!rawCatalogUrl) {
    console.error('[importWebTemplate] TEMPLATES_CATALOG_URL no configurada')
    return { ok: false, error: 'Servicio de catálogo no configurado.' }
  }
  // Normalizar: agregar https:// si falta el protocolo
  const catalogUrl = /^https?:\/\//i.test(rawCatalogUrl) ? rawCatalogUrl : `https://${rawCatalogUrl}`
  // Prevenir SSRF: validar que la URL apunte a un host seguro
  if (!validateCatalogUrl(catalogUrl)) {
    console.error('[importWebTemplate] TEMPLATES_CATALOG_URL inválida o apunta a host no permitido', { catalogUrl })
    return { ok: false, error: 'Configuración de catálogo inválida.' }
  }

  let catalogData: {
    name: string
    description?: string
    thumbnail?: string
    htmlBase?: string
    css?: string
    variables?: Record<string, string>
    sections?: Record<string, boolean>
    compatibleIndustries?: string[]
  }

  try {
    const response = await fetch(`${catalogUrl}/api/templates/${encodeURIComponent(slug)}`, {
      signal: AbortSignal.timeout(5_000),
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
    })

    if (!response.ok) {
      if (response.status === 404) return { ok: false, error: 'Template no encontrado en el catálogo.' }
      return { ok: false, error: `Error del catálogo: ${response.status}` }
    }

    catalogData = await response.json() as typeof catalogData

    // Validar estructura básica de la respuesta antes de usarla
    if (
      typeof catalogData !== 'object' ||
      catalogData === null ||
      Array.isArray(catalogData) ||
      typeof catalogData.name !== 'string'
    ) {
      console.error('[importWebTemplate] respuesta del catálogo inválida', { slug, catalogUrl })
      return { ok: false, error: 'El catálogo devolvió datos con formato inesperado.' }
    }
  } catch (err: unknown) {
    if (err instanceof Error && err.name === 'TimeoutError') {
      return { ok: false, error: 'El catálogo no respondió. Intentá de nuevo.' }
    }
    console.error('[importWebTemplate] fetch error', { slug, catalogUrl }, err)
    return { ok: false, error: 'No se pudo conectar al catálogo de templates.' }
  }

  // Validar datos mínimos requeridos
  const name = catalogData.name?.toString().trim()
  if (!name) return { ok: false, error: 'El template del catálogo no tiene nombre.' }
  if (name.length > 200) return { ok: false, error: 'El nombre del template supera 200 caracteres.' }

  const htmlBase = catalogData.htmlBase?.toString() ?? null
  const css = catalogData.css?.toString() ?? null

  // Sanitizar HTML antes de guardar
  const sanitizedHtml = htmlBase ? sanitizeTemplateHtml(htmlBase) : null

  // Validar tamaño
  if (sanitizedHtml && sanitizedHtml.length > MAX_HTML_CSS_SIZE) {
    return { ok: false, error: 'El HTML del template supera el tamaño máximo (1MB).' }
  }
  if (css && css.length > MAX_HTML_CSS_SIZE) {
    return { ok: false, error: 'El CSS del template supera el tamaño máximo (1MB).' }
  }

  try {
    // Validar thumbnail antes de persistir (previene XSS via javascript:/data: URLs)
    const rawThumbnail = catalogData.thumbnail?.toString() ?? null
    const thumbnail = rawThumbnail && validateThumbnailUrl(rawThumbnail) ? rawThumbnail : null

    const template = await prisma.webTemplate.create({
      data: {
        name,
        description: catalogData.description?.toString().slice(0, 500) ?? null,
        thumbnail,
        htmlBase: sanitizedHtml,
        css: css || null,
        variables: (catalogData.variables as Prisma.InputJsonValue) ?? Prisma.JsonNull,
        sections: (catalogData.sections as Prisma.InputJsonValue) ?? DEFAULT_SECTIONS,
        compatibleIndustries: Array.isArray(catalogData.compatibleIndustries)
          ? catalogData.compatibleIndustries.filter((i) => typeof i === 'string')
          : [],
        status: 'DRAFT',
      },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_IMPORT',
      targetEntity: 'WebTemplate',
      targetId: template.id,
      newState: { name, importedFromSlug: slug },
    })

    revalidatePath('/templates')
    return { ok: true, id: template.id }
  } catch (err: unknown) {
    if ((err as { code?: string })?.code === 'P2002') {
      return { ok: false, error: 'Este template ya fue importado. Podés verlo en la lista de templates.' }
    }
    console.error('[importWebTemplate]', { slug }, err)
    return { ok: false, error: 'Error al importar el template. Intentá de nuevo.' }
  }
}

/**
 * Activa un template para que sea visible en el portal de clientes.
 * Cambia el estado de DRAFT a ACTIVE.
 */
export async function publishWebTemplate(
  _prev: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  const { userId } = await requireAdminSession()

  const id = formData.get('id')?.toString().trim() ?? ''
  if (!id) return { ok: false, error: 'ID inválido.' }

  try {
    await prisma.webTemplate.update({
      where: { id },
      data: { status: 'ACTIVE' },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: id,
      newState: { status: 'ACTIVE' },
    })

    revalidatePath('/templates')
    return { ok: true }
  } catch (err) {
    console.error('[publishWebTemplate]', err)
    return { ok: false, error: 'Error al publicar. Intentá de nuevo.' }
  }
}

export async function duplicateWebTemplate(
  _prev: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  const { userId } = await requireAdminSession()

  const id = formData.get('id')?.toString().trim() ?? ''
  if (!id) return { ok: false, error: 'ID inválido.' }

  try {
    const original = await prisma.webTemplate.findUnique({ where: { id } })
    if (!original) return { ok: false, error: 'Template no encontrado.' }

    // Buscar nombre disponible con una sola query en lugar de N+1
    const copyPrefix = `${original.name} (copia`
    const existingCopies = await prisma.webTemplate.findMany({
      where: { name: { startsWith: copyPrefix } },
      select: { name: true },
    })
    const existingNames = new Set(existingCopies.map((t) => t.name))
    // Genera "X (copia)", "X (copia 2)", "X (copia 3)", etc.
    let finalName = `${original.name} (copia)`
    let counter = 2
    while (existingNames.has(finalName)) {
      finalName = `${original.name} (copia ${counter++})`
    }

    const copy = await prisma.webTemplate.create({
      data: {
        name: finalName,
        description: original.description,
        compatibleIndustries: original.compatibleIndustries as Prisma.InputJsonValue,
        thumbnail: original.thumbnail,
        sections: (original.sections ?? DEFAULT_SECTIONS) as Prisma.InputJsonValue,
        htmlBase: original.htmlBase,
        css: original.css,
        variables: original.variables ?? Prisma.JsonNull,
        status: 'DRAFT',
      },
    })

    logAudit({
      userId,
      action: 'TEMPLATE_UPDATE',
      targetEntity: 'WebTemplate',
      targetId: copy.id,
      newState: { name: finalName, copiedFrom: id },
    })

    revalidatePath('/templates')
    return { ok: true }
  } catch (err: unknown) {
    if ((err as { code?: string })?.code === 'P2002') {
      return { ok: false, error: 'Ya existe un template con ese nombre.' }
    }
    console.error('[duplicateWebTemplate]', err)
    return { ok: false, error: 'Error al duplicar. Intentá de nuevo.' }
  }
}
