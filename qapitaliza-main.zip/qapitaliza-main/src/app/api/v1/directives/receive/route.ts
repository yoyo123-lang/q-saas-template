import { NextResponse } from 'next/server'
import { createHmac, timingSafeEqual } from 'crypto'
import { updateDirectiveStatus } from '@/lib/board-client'

function validateBoardSignature(
  rawBody: string,
  signatureHeader: string,
  secret: string
): boolean {
  const expected = createHmac('sha256', secret).update(rawBody).digest('hex')
  const received = signatureHeader.replace('sha256=', '')

  const a = Buffer.from(expected, 'hex')
  const b = Buffer.from(received, 'hex')

  if (a.length !== b.length) return false
  return timingSafeEqual(a, b)
}

export async function POST(request: Request) {
  const rawBody = await request.text()
  const signature = request.headers.get('x-board-signature') ?? ''
  const secret = process.env.BOARD_WEBHOOK_SECRET

  if (!secret) {
    console.error('[Board] BOARD_WEBHOOK_SECRET no configurado')
    return NextResponse.json({ error: 'Server misconfigured' }, { status: 500 })
  }

  if (!validateBoardSignature(rawBody, signature, secret)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = JSON.parse(rawBody) as {
    directive_id: string
    type: string
    title: string
    description: string
    execution?: { type: string; repo?: string; labels?: string[] }
  }

  const { directive_id, type, title } = body
  console.log(`[Board] Directiva recibida: ${type} — ${title}`)

  // Responder rápido (< 5 seg) y procesar en background
  processDirectiveInBackground(body).catch(console.error)

  return NextResponse.json({ acknowledged: true, directive_id })
}

async function processDirectiveInBackground(directive: {
  directive_id: string
  type: string
  title: string
  description: string
  execution?: { type: string; repo?: string; labels?: string[] }
}) {
  try {
    await updateDirectiveStatus(directive.directive_id, 'in_progress')

    switch (directive.type) {
      case 'PROMOTION':
        // Activar promoción con las condiciones del payload
        break
      case 'FEATURE_REQUEST':
        // Si execution.type === 'github_issue', el Board ya creó el issue
        break
      case 'TECHNICAL_DIRECTIVE':
        // Crear ADR o tarea técnica
        break
      case 'POLICY_CHANGE':
        // Actualizar configuración según la política
        break
      case 'CAMPAIGN':
        // Activar campaña con assets y timing del payload
        break
      case 'CONFIG_CHANGE':
        // Cambiar parámetro de runtime
        break
      default:
        console.log(`[Board] Tipo de directiva no manejado: ${directive.type}`)
    }

    await updateDirectiveStatus(directive.directive_id, 'completed', 'Procesado correctamente')
  } catch (error) {
    await updateDirectiveStatus(
      directive.directive_id,
      'failed',
      error instanceof Error ? error.message : 'Error desconocido'
    )
  }
}
