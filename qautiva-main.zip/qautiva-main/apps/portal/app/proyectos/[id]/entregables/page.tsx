import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { DeliverableCard } from '@/components/DeliverableCard'

export const metadata: Metadata = { title: 'Mis archivos — Qautiva' }

import type { DeliverableStatus } from '@qautiva/db'

// Statuses that are visible to the client (exclude internal draft/review states)
const CLIENT_VISIBLE_STATUSES: DeliverableStatus[] = [
  'SENT_TO_CLIENT',
  'CLIENT_APPROVED',
  'REVISION_REQUESTED',
  'READY',
  'GENERATING',
  'FAILED',
]

/**
 * /proyectos/[id]/entregables — lista todos los entregables del proyecto.
 */
export default async function MisArchivosPage({
  params,
}: {
  params: { id: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) notFound()

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    include: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) notFound()

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const project = await prisma.project.findFirst({
    where: { id: params.id, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true },
  })

  if (!project) notFound()

  const deliverables = await prisma.deliverable.findMany({
    where: {
      projectId: project.id,
      status: { in: CLIENT_VISIBLE_STATUSES },
    },
    orderBy: { updatedAt: 'desc' },
    select: {
      id: true,
      title: true,
      type: true,
      status: true,
      updatedAt: true,
    },
  })

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold text-white mb-6">Mis archivos</h1>

      {deliverables.length > 0 ? (
        <div className="flex flex-col gap-3">
          {deliverables.map((d) => (
            <DeliverableCard
              key={d.id}
              id={d.id}
              title={d.title}
              type={d.type}
              status={d.status}
              updatedAt={d.updatedAt}
              href={`/proyectos/${project.id}/entregables/${d.id}`}
            />
          ))}
        </div>
      ) : (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">
            Tus archivos aparecen acá cuando estén listos.
          </p>
        </div>
      )}
    </div>
  )
}
