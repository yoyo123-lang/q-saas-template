# Prompts para Gemini — Dashboard Vendedor

> Cada prompt es autocontenido. Copiá y pegá uno a la vez en Gemini.

---

## PROMPT 1: Dashboard general (`/dashboard`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A | Fondo cards/sidebar: #0F172A | Fondo hover: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24
- Texto: #F8FAFC (primario), #94A3B8 (secundario), #64748B (apagado)
- Bordes: #1E293B | Success: #10B981 | Warning: #F59E0B | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans (400, 500, 600, 700). Mono: JetBrains Mono.
Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" oscuro. Idioma: español argentino.

PÁGINA: Dashboard general del vendedor — vista principal después de loguearse

ESTRUCTURA:

Layout con sidebar fija izquierda (280px) + contenido principal:

SIDEBAR (280px, fondo #0B0F1A, borde derecho #1E293B, altura 100vh):
- Logo arriba: cuadrado amber 32x32 con "Q" + "qapitaliza" en 16px #F8FAFC
- Espacio 32px
- Sección de navegación (items verticales):
  - "Dashboard" — ACTIVO (tiene barra izquierda 3px amber, texto #F59E0B, fondo rgba(245,158,11,0.08)) — ícono LayoutDashboard
  - "Mis activos" — inactivo (#94A3B8, hover fondo #1E293B) — ícono Package
  - "Consultas" — con badge "3" amber — ícono MessageCircle
  - "Favoritos" — ícono Heart
  - "Perfil" — ícono User
- Divider #1E293B
- Sección inferior:
  - "Nuevo listado" — botón outline amber con ícono Plus
- Abajo del todo:
  - Avatar circular + "Martín Rodríguez" en 14px #F8FAFC + "vendedor" en 12px #64748B
  - Botón logout ícono

CONTENIDO PRINCIPAL (margen izquierdo 280px, fondo #0B0F1A, padding 32px):

a) HEADER
   - "Dashboard" (28px semibold #F8FAFC)
   - "Bienvenido, Martín" (#94A3B8)

b) STAT CARDS — grilla 4 columnas
   Cada card: fondo #0F172A, borde #1E293B, rounded 12px, padding 20px
   - "Activos publicados": "8" (32px bold #F8FAFC), label en #64748B, ícono Package amber
   - "Vistas totales": "2,847" con "+12% este mes" en verde, ícono Eye amber
   - "Consultas activas": "3" con dot amber pulsante, ícono MessageCircle amber
   - "Revenue total listado": "$94,500 USD" en amber, ícono DollarSign

c) GRÁFICO (card fondo #0F172A, borde #1E293B, rounded 12px)
   - Heading: "Vistas de tus activos" + dropdown "Últimos 30 días"
   - Gráfico de línea simple: línea amber con fill amber al 10%, eje X con fechas, eje Y con valores
   - Fondo del gráfico #0B0F1A, grid lines muy sutiles en #1E293B

d) ACTIVIDAD RECIENTE (card)
   - Heading: "Actividad reciente"
   - Lista de 5 items con timestamp:
     - "Laura García consultó sobre CryptoAlerts.io" — hace 2 horas — dot azul
     - "Tu activo DevTools.pro fue destacado" — hace 5 horas — dot amber
     - "Nueva vista en TuMascota.shop" — hace 1 día — dot gris
     - "RecetasVegan.ar fue aprobado y publicado" — hace 2 días — dot verde
     - "Respondiste la consulta de Pedro M." — hace 3 días — dot gris

e) MIS ACTIVOS (preview — card con tabla)
   - Heading: "Mis activos" + link "Ver todos →" amber
   - Tabla con 4 filas:
     | Activo | Tipo | Precio | Estado | Vistas |
     | CryptoAlerts.io | SaaS | $18,000 | Publicado (verde) | 847 |
     | DevTools.pro | Tool | $32,000 | Destacado (amber) | 1,203 |
     | RecetasVegan.ar | Web | $4,500 | Publicado (verde) | 412 |
     | NuevoProyecto | MVP | $5,000 | Borrador (gris) | 0 |
   - Estado como badge pill con color correspondiente
```

---

## PROMPT 2: Mis activos / listados (`/mis-activos`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards/sidebar: #0F172A | Hover: #1E293B
- Acento: #F59E0B | Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Warning: #F59E0B | Error: #EF4444

Tipografía: DM Sans. Mono: JetBrains Mono. Cards: rounded 12px. Buttons: rounded 8px.
Logo: cuadrado amber con "Q". Idioma: español argentino.

PÁGINA: Mis activos — lista de todos los activos del vendedor

ESTRUCTURA: Sidebar (280px, misma que dashboard con "Mis activos" activo) + contenido principal

CONTENIDO:

a) HEADER
   - "Mis activos" (28px semibold #F8FAFC)
   - Botón "Nuevo listado" (amber, ícono Plus)

b) FILTROS INLINE
   - Tabs horizontales: "Todos (12)" | "Publicados (8)" | "Borradores (2)" | "En revisión (1)" | "Vendidos (1)"
   - Tab activo con borde inferior amber y texto amber
   - Barra de búsqueda a la derecha: "Buscar mis activos..."

c) TABLA DE ACTIVOS (fondo #0F172A, borde #1E293B, rounded 12px)
   Headers de tabla: #64748B uppercase 12px tracking-wider
   Filas con hover #1E293B, borde bottom #1E293B sutil

   | Activo | Tipo | Precio | Estado | Vistas | Consultas | Acciones |
   |--------|------|--------|--------|--------|-----------|----------|
   | [screenshot mini] CryptoAlerts.io | SaaS | $18,000 | ● Publicado (verde) | 847 | 3 | ⋯ |
   | [screenshot mini] DevTools.pro | Tool | $32,000 | ★ Destacado (amber) | 1,203 | 5 | ⋯ |
   | [screenshot mini] TuMascota.shop | E-com | $7,200 | ● Publicado (verde) | 534 | 2 | ⋯ |
   | [screenshot mini] RecetasVegan.ar | Web | $4,500 | ● Publicado (verde) | 412 | 1 | ⋯ |
   | [screenshot mini] FitnessPlan.app | MVP | $2,800 | ● Publicado (verde) | 189 | 0 | ⋯ |
   | [screenshot mini] Viajeros.com.ar | Dom | $15,000 | ● Publicado (verde) | 302 | 2 | ⋯ |
   | [screenshot mini] MiContador.ar | SaaS | $9,500 | ● Publicado (verde) | 156 | 1 | ⋯ |
   | [screenshot mini] NotiTech.com | Web | $6,200 | ● Publicado (verde) | 204 | 0 | ⋯ |
   | [screenshot mini] BlogViajes.ar | Web | - | ◌ Borrador (gris) | 0 | 0 | ⋯ |
   | [screenshot mini] AppDelivery | MVP | $12,000 | ◎ En revisión (azul) | 0 | 0 | ⋯ |
   | [screenshot mini] Streaming.lat | Dom | $22,000 | ✓ Vendido (amber) | 890 | 8 | ⋯ |
   | [screenshot mini] NuevoProyecto | MVP | $5,000 | ◌ Borrador (gris) | 0 | 0 | ⋯ |

   El menú ⋯ (three dots) abre: Editar | Ver página | Pausar | Eliminar

d) PAGINACIÓN abajo
```

---

## PROMPT 3: Crear listado (`/mis-activos/nuevo`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards: #0F172A | Inputs: #1E293B
- Acento: #F59E0B | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Error: #EF4444

Tipografía: DM Sans. Mono: JetBrains Mono. Cards: rounded 12px. Inputs/Buttons: rounded 8px.
Logo: cuadrado amber con "Q". Idioma: español argentino.

PÁGINA: Crear nuevo listado — formulario multi-step

ESTRUCTURA: Sidebar (280px) + contenido principal

CONTENIDO:

a) HEADER
   - Breadcrumb: "Mis activos > Nuevo listado" en #64748B
   - "Nuevo listado" (28px semibold #F8FAFC)

b) PROGRESS STEPPER (horizontal)
   - 4 pasos conectados con línea:
   - Paso 1: "Información básica" — ACTIVO (circle amber con número 1, texto amber)
   - Paso 2: "Métricas" — pendiente (circle #1E293B con número 2, texto #64748B)
   - Paso 3: "Imágenes" — pendiente
   - Paso 4: "Revisión" — pendiente
   - Línea entre pasos: amber hasta el paso activo, #1E293B después

c) FORMULARIO — Paso 1: Información básica (card fondo #0F172A, borde #1E293B, rounded 12px, padding 32px)

   - Sección "Datos del activo" (heading 16px semibold):

   - "Título del activo" (label 14px medium #94A3B8):
     Input fondo #1E293B, borde #1E293B, focus borde amber, placeholder "Ej: MiSitio.com"
     Helper: "Usá el nombre del dominio o proyecto" en 12px #64748B

   - "Tipo de activo" (label):
     Select/dropdown fondo #1E293B: opciones Sitio Web | Dominio | SaaS/MVP | E-commerce | Proyecto
     Actualmente seleccionado: "SaaS/MVP"

   - "URL del activo" (label):
     Input con prefijo "https://" en #64748B, placeholder "cryptoalerts.io"

   - "Descripción" (label):
     Textarea grande (6 rows), fondo #1E293B, placeholder "Describí tu activo en detalle: qué hace, qué incluye la venta, por qué lo vendés..."
     Counter abajo: "0 / 2000 caracteres" en #64748B

   - Row 2 columnas:
     - "Precio" (label): Input numérico con prefijo "$", placeholder "18000"
     - "Moneda" (label): Select — USD | ARS. Seleccionado: "USD"

   - "Tech Stack" (label):
     Input con tags/chips: escribís y se agregan como pills. Placeholder "Ej: React, Node.js, PostgreSQL"
     Pills ejemplo ya agregadas: [Next.js ×] [TypeScript ×] [PostgreSQL ×]

   - "Tags" (label):
     Input similar al anterior. Placeholder "Ej: fintech, cripto, automatización"

d) FOOTER DEL FORM
   - Botón "Cancelar" (ghost, #94A3B8) a la izquierda
   - Botón "Guardar borrador" (outline amber) + Botón "Siguiente →" (amber sólido) a la derecha
```

---

## PROMPT 4: Editar listado (`/mis-activos/[id]/editar`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards: #0F172A | Inputs: #1E293B
- Acento: #F59E0B | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Warning: #F59E0B | Error: #EF4444

Tipografía: DM Sans. Mono: JetBrains Mono. Cards: rounded 12px. Inputs/Buttons: rounded 8px.
Logo: cuadrado amber con "Q". Idioma: español argentino.

PÁGINA: Editar listado existente — "CryptoAlerts.io" — con tabs

ESTRUCTURA: Sidebar (280px) + contenido principal

CONTENIDO:

a) HEADER
   - Breadcrumb: "Mis activos > CryptoAlerts.io > Editar"
   - "Editar: CryptoAlerts.io" (28px semibold #F8FAFC)
   - Badge "Publicado" (verde) al lado del título
   - Botón "Ver página pública →" (link amber)

b) TABS HORIZONTALES
   - "Información" (activo, borde inferior amber) | "Métricas" | "Imágenes" | "Configuración"

c) TAB ACTIVO — Información (card fondo #0F172A, rounded 12px, padding 32px)

   Mismo formulario que crear pero pre-populado con datos:
   - Título: "CryptoAlerts.io"
   - Tipo: "SaaS/MVP" seleccionado
   - URL: "https://cryptoalerts.io"
   - Descripción: texto completo pre-llenado
   - Precio: 18000 | Moneda: USD
   - Tech Stack: [Next.js ×] [TypeScript ×] [PostgreSQL ×] [Redis ×] [Stripe ×]
   - Tags: [cripto ×] [alertas ×] [SaaS ×] [fintech ×]

d) SIDEBAR DERECHA (300px, card #0F172A)
   - "Estado del listado"
   - Status actual: "● Publicado" (verde) con fecha "Desde 17 mar 2026"
   - Acciones:
     - Botón "Pausar publicación" (outline amber)
     - Botón "Marcar como vendido" (outline verde)
     - Divider
     - Botón "Eliminar listado" (outline rojo, texto rojo)
   - Stats rápidas:
     - Vistas: 847
     - Consultas: 3
     - Favoritos: 12

e) FOOTER DEL FORM
   - "Última edición: hace 2 días" en #64748B izquierda
   - Botón "Descartar cambios" (ghost) + Botón "Guardar cambios" (amber sólido) derecha
```
