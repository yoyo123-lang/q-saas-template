import { NextRequest, NextResponse } from 'next/server'
import { waitUntil } from '@vercel/functions'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { generateTemplate, processStitchHtml, validateHandlebarsCompilation } from '@qautiva/stitch'
import { TEMPLATE_STYLES } from '@qautiva/shared'

export const maxDuration = 300

const LOCK_TIMEOUT_MS = 5 * 60 * 1000 // 5 minutos — mismo que generate/route.ts

function isValidUUID(id: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
}

/**
 * Selecciona la cuenta Stitch con menor uso hoy (round-robin).
 * Incrementa usedToday inmediatamente al seleccionar para que la próxima
 * invocación tome otra cuenta — no espera a que el job complete.
 */
async function selectBestAccount(): Promise<{ id: string; apiKey: string } | null> {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  await prisma.stitchAccount.updateMany({
    where: { active: true, lastResetAt: { lt: today } },
    data: { usedToday: 0, lastResetAt: new Date() },
  })

  const accounts = await prisma.stitchAccount.findMany({
    where: { active: true },
    select: { id: true, apiKey: true, usedToday: true, dailyLimit: true },
    orderBy: { usedToday: 'asc' },
  })

  const account = accounts.find((a) => a.usedToday < a.dailyLimit) ?? null
  if (!account) return null

  // Reservar el crédito inmediatamente → round-robin real entre cuentas
  await prisma.stitchAccount.update({
    where: { id: account.id },
    data: { usedToday: { increment: 1 } },
  })

  return { id: account.id, apiKey: account.apiKey }
}

/**
 * Corre la generación en background.
 * Si Stitch devuelve 429 → marca la cuenta sin créditos y pone el job de vuelta a QUEUED.
 * Si hay error genérico → pone el job a ERROR.
 * Si éxito → pone el job a DONE con queueStatus=DONE y status=DRAFT.
 */
async function runQueueGeneration(
  templateId: string,
  params: { industry: string; sections: string[]; prompt: string; stylePrompt: string; styleLabel: string },
  accountId: string,
): Promise<void> {
  const { industry, sections, prompt, stylePrompt, styleLabel } = params
  const fullPrompt = `${prompt}\n\nEstilo visual: ${stylePrompt}`
  const startMs = Date.now()
  console.info(`[stitch:queue:run] start templateId=${templateId} accountId=${accountId}`)

  try {
    const accountRecord = await prisma.stitchAccount.findUnique({
      where: { id: accountId },
      select: { apiKey: true },
    })
    if (!accountRecord?.apiKey) {
      throw new Error(`[stitch:queue:run] No se encontró apiKey para cuenta ${accountId}`)
    }

    // Pasar apiKey directamente → generateTemplate crea un cliente Stitch fresco.
    // NO mutar process.env: el SDK usa un singleton que ignora cambios posteriores al primer uso.
    const result = await generateTemplate({ industry, sections, prompt: fullPrompt, apiKey: accountRecord.apiKey })
    const { html, css, thumbnailUrl, stitchProjectId, stitchScreenId } = result

    const processResult = processStitchHtml(html, sections)
    if (!processResult.success) {
      await prisma.webTemplate.update({
        where: { id: templateId },
        data: { queueStatus: 'ERROR', generatingAt: null, queueError: `processStitchHtml:${processResult.reason}` },
      })
      console.error(`[stitch:queue:run] processStitchHtml failed (${templateId}): ${processResult.reason}`)
      console.error(`[stitch:queue:run] HTML snippet (${templateId}): ${html.slice(0, 500)}`)
      return
    }

    const validationResult = validateHandlebarsCompilation(processResult.processedHtml)
    if (!validationResult.valid) {
      await prisma.webTemplate.update({
        where: { id: templateId },
        data: { queueStatus: 'ERROR', generatingAt: null, queueError: `handlebars:${validationResult.error?.slice(0, 500) ?? 'unknown'}` },
      })
      console.error(`[stitch:queue:run] Handlebars validation failed (${templateId}): ${validationResult.error}`)
      return
    }

    // usedToday ya se incrementó en selectBestAccount (reserva anticipada)
    // Nombre descriptivo: "Calzado — Limpio y profesional" en vez de "__queue__uuid"
    const displayName = `${industry} — ${styleLabel}`
    await prisma.webTemplate.update({
      where: { id: templateId },
      data: {
        name: displayName,
        source: 'STITCH',
        stitchProjectId,
        stitchScreenId,
        htmlBase: processResult.processedHtml,
        css,
        thumbnail: thumbnailUrl,
        generationPrompt: fullPrompt,
        variables: processResult.extractedVariables,
        sections: processResult.detectedSections,
        generatingAt: null,
        queueStatus: 'DONE',
        status: 'DRAFT',
        stitchAccountId: accountId,
      },
    })
    console.info(`[stitch:queue:run] done templateId=${templateId} accountId=${accountId} duration=${Date.now() - startMs}ms`)
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err)

    // Si Stitch devuelve 429, marcar la cuenta como sin créditos y volver el job a QUEUED
    if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit') || errMsg.toLowerCase().includes('quota')) {
      await Promise.all([
        prisma.stitchAccount.update({
          where: { id: accountId },
          // Marcar como agotada hasta el próximo reset
          data: { usedToday: { increment: 9999 } },
        }),
        prisma.webTemplate.update({
          where: { id: templateId },
          data: { queueStatus: 'QUEUED', generatingAt: null, stitchAccountId: null, queueError: '429:rate_limit' },
        }),
      ]).catch(() => {})
      console.error(`[stitch:queue:run] 429 de Stitch para cuenta ${accountId} — job ${templateId} vuelve a QUEUED`)
      return
    }

    await prisma.webTemplate
      .update({
        where: { id: templateId },
        data: { queueStatus: 'ERROR', generatingAt: null, queueError: errMsg.slice(0, 500) },
      })
      .catch(() => {})
    // Log en líneas separadas para que Vercel no trunque
    console.error(`[run] FATAL templateId=${templateId}`)
    console.error(`[run] FATAL accountId=${accountId}`)
    console.error(`[run] FATAL errName=${err instanceof Error ? err.name : 'unknown'}`)
    console.error(`[run] FATAL errMsg=${errMsg.slice(0, 200)}`)
    if (errMsg.length > 200) console.error(`[run] FATAL errMsg2=${errMsg.slice(200, 400)}`)
    if (err instanceof Error && err.stack) {
      const stackLines = err.stack.split('\n').slice(1, 4)
      stackLines.forEach((l, i) => console.error(`[run] FATAL stack${i}=${l.trim()}`))
    }
    if (err instanceof Error && err.cause) {
      console.error(`[run] FATAL cause=${JSON.stringify(err.cause).slice(0, 200)}`)
    }
  }
}

/**
 * POST /api/stitch/queue/:id/run
 *
 * Ejecuta un job QUEUED usando la cuenta Stitch con más créditos disponibles.
 * Responde 202 inmediatamente y corre la generación en background (waitUntil).
 * El cliente hace polling a GET /api/stitch/queue para ver el estado.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: { id: string } },
): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const { id } = params

  if (!isValidUUID(id)) {
    return NextResponse.json({ error: 'id inválido' }, { status: 400 })
  }

  const job = await prisma.webTemplate.findUnique({
    where: { id },
    select: {
      id: true,
      queueStatus: true,
      generatingAt: true,
      compatibleIndustries: true,
      sections: true,
      generationPrompt: true,
      styleId: true,
    },
  })

  if (!job) {
    return NextResponse.json({ error: 'Job no encontrado' }, { status: 404 })
  }

  if (job.queueStatus !== 'QUEUED' && job.queueStatus !== 'ERROR') {
    return NextResponse.json(
      { error: 'El job no está disponible para ejecutar. Solo se pueden ejecutar jobs en estado QUEUED o ERROR.' },
      { status: 409 },
    )
  }

  // Verificar lock (por si hay una carrera)
  if (job.generatingAt !== null) {
    const lockAge = Date.now() - job.generatingAt.getTime()
    if (lockAge < LOCK_TIMEOUT_MS) {
      return NextResponse.json({ error: 'Generación ya en progreso' }, { status: 409 })
    }
  }

  // Seleccionar cuenta con créditos
  const account = await selectBestAccount()
  if (!account) {
    return NextResponse.json(
      { error: 'Sin créditos disponibles. Todas las cuentas Stitch alcanzaron su límite diario.' },
      { status: 429 },
    )
  }

  // Obtener info del estilo
  const styleId = job.styleId ?? 'clean-professional'
  const style = TEMPLATE_STYLES.find((s) => s.id === styleId) ?? TEMPLATE_STYLES[0]

  // Extraer industria del template
  const industries = job.compatibleIndustries as string[]
  const industry = industries[0] ?? ''

  // Extraer secciones del template
  const sectionsObj = (job.sections ?? {}) as Record<string, boolean>
  const sections = Object.entries(sectionsObj)
    .filter(([, v]) => v)
    .map(([k]) => k)

  // Prompt base (si ya tiene uno guardado, reutilizarlo)
  const prompt = job.generationPrompt ?? `Template para ${industry}.`

  // Marcar como GENERATING con lock (limpiar queueError de intentos anteriores)
  await prisma.webTemplate.update({
    where: { id },
    data: { queueStatus: 'GENERATING', generatingAt: new Date(), queueError: null },
  })

  waitUntil(
    runQueueGeneration(id, { industry, sections, prompt, stylePrompt: style.prompt, styleLabel: style.label }, account.id),
  )

  return NextResponse.json({ jobId: id, status: 'generating' }, { status: 202 })
}
