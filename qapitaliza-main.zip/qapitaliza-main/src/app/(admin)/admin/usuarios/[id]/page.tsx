import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, ExternalLink } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { getUserDetail } from '@/lib/data/admin'

const ROLE_LABELS: Record<string, string> = {
  SELLER: 'Vendedor',
  BUYER: 'Comprador',
  ADMIN: 'Admin',
}

const ROLE_VARIANTS: Record<string, 'info' | 'muted' | 'amber'> = {
  SELLER: 'info',
  BUYER: 'muted',
  ADMIN: 'amber',
}

const STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Borrador',
  PENDING_REVIEW: 'En revisión',
  PUBLISHED: 'Publicado',
  PAUSED: 'Pausado',
  SOLD: 'Vendido',
  REJECTED: 'Rechazado',
}

const STATUS_VARIANTS: Record<string, 'success' | 'amber' | 'info' | 'muted' | 'danger'> = {
  PUBLISHED: 'success',
  PENDING_REVIEW: 'amber',
  SOLD: 'info',
  DRAFT: 'muted',
  PAUSED: 'muted',
  REJECTED: 'danger',
}

const ACTION_LABELS: Record<string, string> = {
  LISTING_CREATED: 'Listado creado',
  LISTING_SUBMITTED: 'Listado enviado a revisión',
  LISTING_PUBLISHED: 'Listado publicado',
  LISTING_REJECTED: 'Listado rechazado',
  LISTING_APPROVED: 'Listado aprobado',
  LISTING_VIEWED: 'Listado visualizado',
  LISTING_FEATURED: 'Listado destacado',
  INQUIRY_SENT: 'Consulta enviada',
  INQUIRY_REPLIED: 'Consulta respondida',
  INQUIRY_CONVERTED: 'Consulta convertida',
  FAVORITE_ADDED: 'Favorito agregado',
  SIGNUP_COMPLETED: 'Registro completado',
  USER_SUSPENDED: 'Usuario suspendido',
  USER_ROLE_CHANGED: 'Rol cambiado',
}

interface PageProps {
  params: Promise<{ id: string }>
}

export default async function AdminUserDetailPage({ params }: PageProps) {
  const { id } = await params
  const user = await getUserDetail(id)
  if (!user) notFound()

  const name = user.fullName ?? user.email ?? 'Usuario'
  const initials = name.split(' ').slice(0, 2).map((n: string) => n[0]?.toUpperCase() ?? '').join('')
  const isSuspended = !!user.suspendedAt

  const ROLE_AVATAR_COLORS: Record<string, string> = {
    SELLER: 'bg-amber-500 text-navy-950',
    BUYER: 'bg-blue-500 text-white',
    ADMIN: 'bg-purple-500 text-white',
  }

  return (
    <div className="space-y-6">
      {/* Back */}
      <Link
        href="/admin/usuarios"
        className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-50 transition-colors"
      >
        <ArrowLeft className="size-4" />
        Volver a usuarios
      </Link>

      {/* User card */}
      <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div
            className={`size-16 rounded-full flex items-center justify-center text-xl font-bold flex-shrink-0 ${ROLE_AVATAR_COLORS[user.role] ?? 'bg-slate-700 text-slate-200'}`}
          >
            {initials || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-bold text-slate-50">{name}</h1>
              <Badge variant={ROLE_VARIANTS[user.role] ?? 'muted'}>
                {ROLE_LABELS[user.role] ?? user.role}
              </Badge>
              {isSuspended && <Badge variant="danger">Suspendido</Badge>}
            </div>
            <p className="text-slate-400 text-sm mt-1">{user.email}</p>
            <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
              <span>Registrado: {new Date(user.createdAt).toLocaleDateString('es-AR')}</span>
              {user.website && (
                <a
                  href={user.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-amber-500 hover:underline"
                >
                  {user.website}
                  <ExternalLink className="size-3" />
                </a>
              )}
            </div>
            {user.bio && <p className="text-slate-400 text-sm mt-2">{user.bio}</p>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Listings */}
        <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
          <h2 className="font-semibold text-slate-50 mb-4">
            Listados ({user.listings.length})
          </h2>
          {user.listings.length === 0 ? (
            <p className="text-sm text-slate-500">Sin listados.</p>
          ) : (
            <div className="space-y-3">
              {user.listings.map((listing) => (
                <Link
                  key={listing.id}
                  href={`/admin/listados/${listing.id}`}
                  className="flex items-center justify-between gap-3 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-200 truncate">{listing.title}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(listing.createdAt).toLocaleDateString('es-AR')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Badge variant={STATUS_VARIANTS[listing.status] ?? 'muted'}>
                      {STATUS_LABELS[listing.status] ?? listing.status}
                    </Badge>
                    <span className="text-xs font-medium text-amber-500">
                      {listing.currency} {Number(listing.askingPrice).toLocaleString()}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Audit log */}
        <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
          <h2 className="font-semibold text-slate-50 mb-4">Historial de actividad</h2>
          {user.auditLogs.length === 0 ? (
            <p className="text-sm text-slate-500">Sin actividad registrada.</p>
          ) : (
            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
              {user.auditLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-3">
                  <div className="size-1.5 rounded-full bg-slate-600 mt-1.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-slate-300">
                      {ACTION_LABELS[log.action] ?? log.action}
                    </p>
                    <p className="text-xs text-slate-500">
                      {new Date(log.createdAt).toLocaleString('es-AR')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
