// Tests for inquiry and favorite business rules.
// Server Actions require server env (cookies, auth), so we test the
// business logic in isolation — same pattern as listings.test.ts.

import { describe, it, expect } from 'vitest'
import { sendMessageSchema } from '@/lib/schemas/inquiry'

// ─── sendMessageSchema ───────────────────────────────────────────────────────

describe('sendMessageSchema', () => {
  it('acepta mensaje válido', () => {
    expect(sendMessageSchema.safeParse({ content: 'Hola, me interesa tu activo.' }).success).toBe(true)
  })

  it('rechaza mensaje vacío', () => {
    const result = sendMessageSchema.safeParse({ content: '' })
    expect(result.success).toBe(false)
  })

  it('rechaza mensaje de solo espacios', () => {
    // Zod min(1) counts length after trim? No — zod min counts raw length.
    // The action trims before calling schema. Testing raw behavior:
    const result = sendMessageSchema.safeParse({ content: ' ' })
    expect(result.success).toBe(true) // 1 space passes min(1); trimming is the action's job
  })

  it('rechaza mensaje mayor a 5000 caracteres', () => {
    const result = sendMessageSchema.safeParse({ content: 'a'.repeat(5001) })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].path).toContain('content')
    }
  })

  it('acepta mensaje de exactamente 5000 caracteres', () => {
    expect(sendMessageSchema.safeParse({ content: 'a'.repeat(5000) }).success).toBe(true)
  })
})

// ─── createInquiry: validaciones de negocio (unit simulation) ────────────────

describe('createInquiry — validaciones de negocio', () => {
  interface Listing {
    id: string
    sellerId: string
    status: string
  }

  interface Inquiry {
    listingId: string
    buyerId: string
  }

  function validateCreateInquiry(
    currentUserId: string,
    listing: Listing,
    existingInquiries: Inquiry[]
  ): { ok: boolean; error?: string } {
    if (listing.sellerId === currentUserId) {
      return { ok: false, error: 'No podés consultar sobre tu propio activo.' }
    }
    if (listing.status !== 'PUBLISHED') {
      return { ok: false, error: 'Solo podés consultar activos publicados.' }
    }
    const duplicate = existingInquiries.find(
      (i) => i.listingId === listing.id && i.buyerId === currentUserId
    )
    if (duplicate) {
      return { ok: false, error: 'Ya tenés una consulta abierta para este activo.' }
    }
    return { ok: true }
  }

  const listing: Listing = { id: 'listing-1', sellerId: 'seller-1', status: 'PUBLISHED' }

  it('permite consultar a un comprador en un activo publicado', () => {
    expect(validateCreateInquiry('buyer-1', listing, []).ok).toBe(true)
  })

  it('bloquea consultar el propio activo', () => {
    const result = validateCreateInquiry('seller-1', listing, [])
    expect(result.ok).toBe(false)
    expect(result.error).toContain('propio activo')
  })

  it('bloquea consultar un activo no publicado (DRAFT)', () => {
    const draft = { ...listing, status: 'DRAFT' }
    const result = validateCreateInquiry('buyer-1', draft, [])
    expect(result.ok).toBe(false)
    expect(result.error).toContain('publicados')
  })

  it('bloquea consultar un activo PAUSED', () => {
    const paused = { ...listing, status: 'PAUSED' }
    expect(validateCreateInquiry('buyer-1', paused, []).ok).toBe(false)
  })

  it('retorna la consulta existente (no duplica)', () => {
    const existing: Inquiry[] = [{ listingId: 'listing-1', buyerId: 'buyer-1' }]
    // In the real action we return the existing id; here we just check the duplicate detection
    const result = validateCreateInquiry('buyer-1', listing, existing)
    expect(result.ok).toBe(false)
  })
})

// ─── sendMessage: validaciones de participante ───────────────────────────────

describe('sendMessage — IDOR protection', () => {
  interface InquiryParticipants {
    buyerId: string
    sellerId: string
    status: string
  }

  function validateSendMessage(
    currentUserId: string,
    inquiry: InquiryParticipants
  ): { ok: boolean; error?: string } {
    const isBuyer = inquiry.buyerId === currentUserId
    const isSeller = inquiry.sellerId === currentUserId
    if (!isBuyer && !isSeller) {
      return { ok: false, error: 'No tenés permiso para participar en esta consulta.' }
    }
    if (inquiry.status === 'CLOSED') {
      return { ok: false, error: 'Esta consulta está cerrada.' }
    }
    return { ok: true }
  }

  const inquiry: InquiryParticipants = {
    buyerId: 'buyer-1',
    sellerId: 'seller-1',
    status: 'OPEN',
  }

  it('permite al comprador enviar mensaje', () => {
    expect(validateSendMessage('buyer-1', inquiry).ok).toBe(true)
  })

  it('permite al vendedor enviar mensaje', () => {
    expect(validateSendMessage('seller-1', inquiry).ok).toBe(true)
  })

  it('bloquea a un tercero (IDOR)', () => {
    const result = validateSendMessage('attacker-999', inquiry)
    expect(result.ok).toBe(false)
    expect(result.error).toContain('permiso')
  })

  it('bloquea enviar mensaje en consulta cerrada', () => {
    const closed = { ...inquiry, status: 'CLOSED' }
    const result = validateSendMessage('buyer-1', closed)
    expect(result.ok).toBe(false)
    expect(result.error).toContain('cerrada')
  })
})

// ─── closeInquiry: solo el comprador puede cerrar ────────────────────────────

describe('closeInquiry — validaciones de rol', () => {
  function validateCloseInquiry(
    currentUserId: string,
    inquiry: { buyerId: string; status: string }
  ): { ok: boolean; error?: string } {
    if (inquiry.buyerId !== currentUserId) {
      return { ok: false, error: 'Solo el comprador puede cerrar la consulta.' }
    }
    if (inquiry.status === 'CLOSED') {
      return { ok: false, error: 'La consulta ya está cerrada.' }
    }
    return { ok: true }
  }

  it('permite al comprador cerrar la consulta', () => {
    expect(validateCloseInquiry('buyer-1', { buyerId: 'buyer-1', status: 'OPEN' }).ok).toBe(true)
  })

  it('bloquea al vendedor cerrar la consulta', () => {
    const result = validateCloseInquiry('seller-1', { buyerId: 'buyer-1', status: 'OPEN' })
    expect(result.ok).toBe(false)
    expect(result.error).toContain('comprador')
  })

  it('bloquea cerrar una consulta ya cerrada', () => {
    const result = validateCloseInquiry('buyer-1', { buyerId: 'buyer-1', status: 'CLOSED' })
    expect(result.ok).toBe(false)
    expect(result.error).toContain('ya está cerrada')
  })
})

// ─── Rate limiting ────────────────────────────────────────────────────────────

describe('rate limiting de consultas', () => {
  const DAILY_LIMIT = 10

  function canCreateInquiry(dailyCount: number): boolean {
    return dailyCount < DAILY_LIMIT
  }

  it('permite hasta 10 consultas por día', () => {
    for (let i = 0; i < DAILY_LIMIT; i++) {
      expect(canCreateInquiry(i)).toBe(true)
    }
  })

  it('rechaza la 11va consulta del día', () => {
    expect(canCreateInquiry(10)).toBe(false)
    expect(canCreateInquiry(11)).toBe(false)
  })
})

// ─── toggleFavorite: lógica de toggle ────────────────────────────────────────

describe('toggleFavorite — lógica de toggle', () => {
  function toggleFavoriteLogic(
    existing: boolean
  ): { action: 'insert' | 'delete'; isFavorited: boolean } {
    if (existing) {
      return { action: 'delete', isFavorited: false }
    }
    return { action: 'insert', isFavorited: true }
  }

  it('crea favorito cuando no existe', () => {
    const result = toggleFavoriteLogic(false)
    expect(result.action).toBe('insert')
    expect(result.isFavorited).toBe(true)
  })

  it('borra favorito cuando ya existe', () => {
    const result = toggleFavoriteLogic(true)
    expect(result.action).toBe('delete')
    expect(result.isFavorited).toBe(false)
  })
})
