# Sesión 11: QA, polish y deploy

## Objetivo
Tests E2E de flujos críticos, revisión de seguridad (tenant isolation), optimización de performance, landing page pública, y preparación para deploy en producción. Al terminar, Qontabiliza está listo para recibir usuarios reales.

## Pre-requisitos
- Todas las sesiones anteriores completadas
- Instalar Playwright si no está: `npm install -D @playwright/test && npx playwright install`

## Al iniciar
1. Leer `ROADMAP.md` — verificar que todos los módulos de Fase 1 están marcados como completados
2. Leer `SESSION_LOG.md` — revisión de issues pendientes de sesiones anteriores
3. Leer `KNOWN_ISSUES.md` — verificar si hay issues abiertos
4. Correr `npm run build` — verificar que compila limpio
5. Correr todos los tests existentes — verificar que pasan

---

## Etapa 1: Tests E2E

### Tarea 1.1: Setup Playwright
**Archivo nuevo**: `playwright.config.ts` (si no existe)

Configurar:
- baseURL: http://localhost:3000
- testDir: `e2e/`
- Browsers: chromium (solo uno para MVP)
- Auth state: reutilizar sesión logueada

**Archivo nuevo**: `e2e/auth.setup.ts`

Setup de autenticación:
- Login con Google OAuth (o bypass en modo test)
- Guardar state en archivo para reutilizar en tests

### Tarea 1.2: E2E — Flujo de onboarding
**Archivo nuevo**: `e2e/onboarding.spec.ts`

Test:
1. Nuevo usuario llega → redirige a /onboarding
2. Completar paso 1: datos del negocio
3. Completar paso 2: primer producto
4. Completar paso 3: primer cliente
5. Redirige a /dashboard con org creada
6. Dashboard muestra datos correctos

### Tarea 1.3: E2E — Flujo completo de venta
**Archivo nuevo**: `e2e/sale-flow.spec.ts`

Test:
1. Crear un producto con precio y stock
2. Crear un cliente con datos fiscales
3. Ir al POS
4. Abrir caja con monto inicial
5. Buscar producto → agregar al carrito
6. Seleccionar cliente
7. Cobrar en efectivo
8. Verificar que se emitió factura (en modo test de ARCA)
9. Verificar que se descontó stock
10. Verificar ticket post-venta
11. Cerrar caja → verificar arqueo

### Tarea 1.4: E2E — Tenant isolation
**Archivo nuevo**: `e2e/tenant-isolation.spec.ts`

Test con 2 usuarios en organizaciones diferentes:
1. User A crea producto en Org A
2. User B en Org B NO ve el producto de Org A
3. User B intenta acceder a API de Org A por ID directo → 403
4. Verificar en: productos, contactos, facturas, stock

**Commit**: `test(e2e): add E2E tests for onboarding, sale flow and tenant isolation`

---

## Etapa 2: Seguridad y robustez

### Tarea 2.1: Auditoría de tenant isolation
**Checklist manual** (ejecutar y documentar resultados):

Para CADA endpoint de API:
- [ ] Usa `getTenantFromRequest()` al inicio
- [ ] Todas las queries incluyen filtro `organizationId`
- [ ] No hay forma de acceder a datos de otro tenant vía query params o body
- [ ] DELETE y UPDATE verifican que el recurso pertenece al tenant

Endpoints a auditar:
- /api/v1/organizations/*
- /api/v1/categories/*
- /api/v1/products/*
- /api/v1/price-lists/*
- /api/v1/contacts/*
- /api/v1/invoices/*
- /api/v1/sales/*
- /api/v1/stock/*
- /api/v1/cash-registers/*
- /api/v1/reports/*
- /api/v1/dashboard

### Tarea 2.2: Validación de inputs
Revisar que TODOS los endpoints:
- Validan el body con Zod antes de usar los datos
- No concatenan strings en queries SQL (si hay raw queries)
- Sanitizan outputs (no devuelven datos sensibles como certificados ARCA)
- Rate limiting en endpoints críticos (facturación ARCA — evitar flood)

### Tarea 2.3: Manejo de errores
**Archivo a revisar/modificar**: `src/lib/api-response.ts`

Verificar que:
- Errores de Prisma (unique constraint, not found) se mapean a HTTP codes correctos
- Errores de ARCA se loguean pero no exponen detalles internos al cliente
- Errores de validación retornan los campos específicos que fallaron
- No hay stack traces en respuestas de producción

### Tarea 2.4: Rate limiting básico
**Archivo nuevo**: `src/lib/rate-limit.ts`

Rate limiter simple en memoria (para MVP — en producción se debería usar Redis):
- Por IP + endpoint
- Facturación ARCA: máx 10 requests/minuto (ARCA se queja si se envían muchos)
- APIs generales: máx 100 requests/minuto
- Helper `rateLimit(req, { limit, window })` que retorna 429 si se excede

**Commit**: `fix(security): audit tenant isolation, add input validation and rate limiting`

---

## Etapa 3: Performance y UX

### Tarea 3.1: Índices de base de datos
Revisar que todas las queries frecuentes tienen índices apropiados.

Queries críticas a verificar:
- Dashboard: ventas del mes por tenant (index en organizationId + completedAt)
- POS: búsqueda de productos por barcode (index en organizationId + barcode)
- Stock: SUM de movimientos por producto (index en organizationId + productId)
- Facturas: listado por fecha (index en organizationId + issuedAt)
- Reportes: agregaciones por período

Agregar índices faltantes en una migración.

### Tarea 3.2: Optimización del POS
**Archivos a revisar/modificar** en `src/components/pos/`:

- Productos: pre-cargar catálogo al abrir POS (no fetch por cada búsqueda)
- Búsqueda: hacer búsqueda local primero, API solo como fallback
- Carrito: evitar re-renders innecesarios (React.memo en items, useMemo en cálculos)
- Cobro: optimistic update — mostrar "Venta completada" inmediatamente, procesar ARCA en background

### Tarea 3.3: Loading states y error handling en UI
Revisar que TODAS las páginas tienen:
- Loading state (skeleton o spinner) mientras cargan datos
- Error state con mensaje y botón de reintentar
- Empty state con call to action (ej: "No hay productos. Creá tu primer producto.")

Páginas a verificar:
- Dashboard
- Productos
- Categorías
- Contactos
- Facturas
- Stock
- POS
- Caja
- Reportes
- Settings

### Tarea 3.4: Responsive check
Verificar que las páginas principales funcionan en:
- Desktop (1920px, 1440px, 1280px)
- Tablet (1024px, 768px) — especialmente el POS
- No se requiere mobile en Fase 1, pero no debe estar completamente roto

**Commit**: `perf: optimize DB indexes, POS performance and loading states`

---

## Etapa 4: Landing page y deploy

### Tarea 4.1: Landing page pública
**Archivo nuevo**: `src/app/(public)/page.tsx`

Landing page de Qontabiliza:

Secciones:
1. **Hero**: "Gestioná tu negocio completo en un solo lugar" + CTA "Empezar gratis"
2. **Funcionalidades**: 6 cards (Facturación ARCA, POS, Stock, Clientes, Reportes, Cobros con Qobra)
3. **Precios**: tabla de planes (Micro, Starter, Pro, Max)
4. **CTA final**: "Probalo 30 días gratis" + botón de registro

Diseño: limpio, profesional, colores del brand de Qontabiliza.
Ruta: `/` (la raíz del sitio). El dashboard está en `/dashboard`.

### Tarea 4.2: Preparar environment de producción
**Archivo a crear/actualizar**: `.env.example`

Variables necesarias para producción:
```
DATABASE_URL=
NEXTAUTH_URL=
NEXTAUTH_SECRET=
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
# ARCA se configura por tenant en la UI, no necesita env vars globales
```

**Archivo nuevo**: `scripts/setup-production.sh`

Script que:
1. Verifica variables de entorno
2. Corre migraciones de Prisma
3. Ejecuta seed de planes (si no existen)
4. Verifica build exitoso

### Tarea 4.3: Build final y verificación
**Comandos**:
```bash
npm run build        # Verificar que compila sin warnings
npm run test         # Todos los tests unitarios pasan
npx playwright test  # Todos los tests E2E pasan
```

Documentar cualquier warning o issue en `KNOWN_ISSUES.md`.

### Tarea 4.4: Actualizar documentación
**Archivos a actualizar**:
- `BLUEPRINT.md` — completar con los datos reales de Qontabiliza
- `docs/ARCHITECTURE.md` — actualizar con los módulos implementados
- `ROADMAP.md` — marcar Fase 1 como completada, actualizar estimaciones

**Commit**: `feat: add landing page, production setup and update documentation`

---

## Checklist de cierre de sesión

- [ ] Tests E2E pasando: onboarding, venta completa, tenant isolation
- [ ] Auditoría de seguridad: tenant isolation en todas las APIs
- [ ] Rate limiting en endpoints críticos
- [ ] Índices de DB optimizados
- [ ] POS optimizado (pre-carga, búsqueda local)
- [ ] Loading/error/empty states en todas las páginas
- [ ] Landing page pública con precios
- [ ] .env.example completo
- [ ] Build de producción exitoso
- [ ] Todos los tests (unitarios + E2E) pasando
- [ ] BLUEPRINT.md completado
- [ ] ARCHITECTURE.md actualizado
- [ ] ROADMAP.md — Fase 1 marcada como completada
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado

---

## 🎉 Fase 1 completada

Con esta sesión, Qontabiliza tiene:
- Multi-tenancy con aislamiento por organización
- Catálogo de productos con variantes, categorías y listas de precios
- Clientes y proveedores con datos fiscales argentinos
- Facturación electrónica ARCA (A/B/C + NC/ND) con PDF
- Punto de venta completo con búsqueda, carrito y cobro
- Stock con movimientos y alertas
- Caja diaria con apertura/cierre
- Dashboard con métricas y gráficos
- Reportes: ventas, libro IVA, cuentas a cobrar
- Planes de suscripción con enforcement de límites
- Landing page pública
- Tests E2E de flujos críticos

**Siguiente paso**: Fase 2 — Compras, multi-depósito, tesorería avanzada, integraciones ML/TN.
