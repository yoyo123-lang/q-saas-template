# Revisión Completa — Sesión 05: Interacción Comprador-Vendedor
**Fecha:** 2026-03-23
**Tipo:** Completa (Capa 1 + Capa 2)
**Alcance:** Cambios de Sesión 05 (sistema de favoritos + consultas comprador-vendedor)

---

## DASHBOARD

```
═══════════════════════════════════════════════════════════════
  REVISIÓN: Completa — 2026-03-23
  ALCANCE: Sesión 05 — Interacción Comprador-Vendedor
═══════════════════════════════════════════════════════════════

  DASHBOARD
  ─────────────────────────────────────────────────────────────
  Rol                    │ Estado │ C │ A │ M
  ───────────────────────│────────│───│───│───
  Code Reviewer          │  ✅    │ 0 │ 0 │ 2
  QA Engineer            │  ⚠️    │ 0 │ 1 │ 2
  Security Auditor       │  ✅    │ 0 │ 0 │ 1
  Performance Engineer   │  ⚠️    │ 0 │ 1 │ 1
  DevOps / SRE           │  ✅    │ 0 │ 0 │ 1
  UX Reviewer            │  ⚠️    │ 0 │ 1 │ 3
  Product Reviewer       │  ✅    │ 0 │ 0 │ 1
  Business Logic         │  ❌    │ 1 │ 0 │ 1
  Data/Analytics         │  ✅    │ 0 │ 0 │ 2
  ───────────────────────│────────│───│───│───
  TOTAL (pre-fix)        │  ❌    │ 1 │ 3 │ 14

  C=Críticos  A=Altos  M=Medios
═══════════════════════════════════════════════════════════════
```

---

## HALLAZGOS Y CORRECCIONES APLICADAS

### CRÍTICOS (1) — ✅ Corregidos

| # | Rol | Archivo | Problema | Estado |
|---|-----|---------|----------|--------|
| C1 | Business Logic | `src/lib/actions/inquiries.ts` | `closeInquiry` solo permitía al buyer cerrar; BUSINESS_MODEL.md Regla 12 permite buyer, seller, o admin | ✅ Corregido |

### ALTOS (3) — ✅ Corregidos

| # | Rol | Archivo | Problema | Estado |
|---|-----|---------|----------|--------|
| A1 | QA | `src/lib/data/inquiries.ts` | `getInquiryMessages` no verificaba participación (IDOR) | ✅ Corregido — requiere `verifiedUserId` |
| A2 | Performance | `prisma/schema.prisma` | Sin índices en `inquiries.buyerId`, `inquiries.updatedAt`, `favorites.userId` | ✅ Corregido — migration 011 + schema |
| A3 | UX | `src/components/listings/listing-actions.tsx` | Doble ícono en botón favorito (SVG + unicode `♡`/`♥`) | ✅ Corregido — eliminado unicode |

### MEDIOS (14) — ✅ Todos corregidos

| # | Rol | Archivo | Problema | Estado |
|---|-----|---------|----------|--------|
| M1 | Code | `lib/actions/inquiries.ts` + `favorites.ts` | `getAuthenticatedUser` duplicado | ✅ Extraído a `auth-helpers.ts` |
| M2 | Code | `inquiry-card.tsx` + `chat-view.tsx` | `statusVariant`/`statusLabel`/`getInitials` duplicados | ✅ Extraído a `inquiry-shared.ts` |
| M3 | QA | `src/app/(dashboard)/consultas/page.tsx` | Sin paginación UI (solo datos) | ✅ Paginación con `<Link>` inline |
| M4 | QA | `src/components/listings/inquiry-card.tsx` | `<Link>` anidado dentro de `<Link>` (HTML inválido) | ✅ Outer reemplazado por `<div>` |
| M5 | Security | `src/lib/notifications/email.ts` | URL hardcodeada | ✅ Usa `NEXT_PUBLIC_APP_URL` env var |
| M6 | Security | `src/lib/actions/inquiries.ts` | Sin rate limit en `sendMessage` | ✅ Límite 20/min por usuario |
| M7 | Performance | `src/lib/data/favorites.ts` | Sin límite en query de favoritos | ✅ `MAX_FAVORITES = 200` |
| M8 | Performance | `src/lib/data/inquiries.ts` | Sin límite en mensajes por consulta | ✅ `MAX_MESSAGES_PER_INQUIRY = 200` |
| M9 | DevOps | `src/lib/actions/inquiries.ts` | Rate limiter in-memory no funciona en multi-instancia | ⚠️ Documentado — OK para MVP, requiere Redis en producción |
| M10 | UX | `src/app/(dashboard)/favoritos/favorites-grid.tsx` | Solo 2 columnas en lg, inconsistente con catálogo | ✅ Añadido `lg:grid-cols-3` |
| M11 | UX | `src/app/(dashboard)/consultas/[id]/chat-view.tsx` | Sin `aria-label` en textarea de mensaje | ✅ Añadido `aria-label` + `role="log"` + `aria-live` |
| M12 | UX | `src/app/(dashboard)/consultas/[id]/chat-view.tsx` | Botón cerrar solo para buyer | ✅ Habilitado para buyer y seller |
| M13 | Business | `src/lib/data/favorites.ts` | Favoritos incluían listings SOLD/REJECTED | ✅ Filtrado a solo PUBLISHED + PAUSED |
| M14 | Data | `prisma/schema.prisma` | Sin `@@index` en modelos clave | ✅ Mismo que A2 |

---

## LO BUENO

- **Code Reviewer**: Separación clara Server/Client Components; ActionResult<T> pattern consistente; Zod para validación server-side; optimistic updates con revert en error.
- **QA Engineer**: Tests cubren reglas de negocio críticas (IDOR, rate limit, roles); Vitest sin dependencias de servidor.
- **Security Auditor**: IDOR check en getInquiry antes de cualquier mutación; auth check en todas las actions; sin SQL injection (Prisma); sin datos sensibles expuestos.
- **Performance Engineer**: Queries paralelas con `Promise.all`; select fields específicos en lugar de `include *`.
- **UX Reviewer**: Optimistic updates con revert; scroll automático al último mensaje; Enter=enviar, Shift+Enter=nueva línea; indicador de estado en header.
- **Business Logic**: Throttle de emails (1h) para evitar spam; upsert idempotente en createInquiry; `INQUIRY_CLOSED` en audit log.

---

## ARCHIVOS MODIFICADOS EN ESTA SESIÓN

### Nuevos archivos
- `src/lib/schemas/inquiry.ts`
- `src/lib/data/favorites.ts`
- `src/lib/data/inquiries.ts`
- `src/lib/notifications/email.ts`
- `src/lib/actions/favorites.ts`
- `src/lib/actions/inquiries.ts`
- `src/lib/supabase/auth-helpers.ts`
- `src/components/listings/inquiry-shared.ts`
- `src/components/listings/inquiry-card.tsx`
- `src/components/listings/listing-actions.tsx`
- `src/app/(dashboard)/favoritos/page.tsx`
- `src/app/(dashboard)/favoritos/favorites-grid.tsx`
- `src/app/(dashboard)/consultas/page.tsx`
- `src/app/(dashboard)/consultas/[id]/page.tsx`
- `src/app/(dashboard)/consultas/[id]/chat-view.tsx`
- `src/lib/actions/__tests__/inquiries.test.ts`
- `supabase/migrations/011_inquiry_closed_and_indexes.sql`
- `supabase/migrations/011_inquiry_closed_and_indexes_rollback.sql`

### Archivos modificados
- `prisma/schema.prisma`
- `src/app/(public)/explorar/[slug]/page.tsx`
- `src/app/(public)/explorar/page.tsx`
- `src/components/listings/results-grid.tsx`

---

## NOTAS DE DEUDA TÉCNICA

1. **Rate limiter in-memory** (`src/lib/actions/inquiries.ts`): funciona correctamente en single-instance (desarrollo, Vercel sin edge). En producción multi-instancia se necesita Redis/Upstash. Documentado en `docs/KNOWN_ISSUES.md`.
2. **Paginación de mensajes** (`getInquiry`): actualmente limitado a 200 mensajes hardcodeados. Para conversaciones largas se necesitará cursor-based pagination.
3. **Email throttle en memoria** (`src/lib/notifications/email.ts`): el Map `lastEmailSent` se resetea con cada deploy. Para producción debería persistirse en base de datos.
