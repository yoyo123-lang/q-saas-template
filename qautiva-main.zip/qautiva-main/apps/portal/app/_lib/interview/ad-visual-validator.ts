/**
 * Validador de piezas gráficas para Meta Ads.
 *
 * Implementa el patrón de auto-validación del Agentic Marketing Campaign Generator:
 * genera → valida → regenera si falla → valida final.
 *
 * DISEÑO: usa Anthropic/OpenAI (no Gemini) para validar piezas generadas por Gemini,
 * evitando el bias de que el mismo modelo evalúe su propio output.
 * El proveedor se lee de TrialConfig.qautivaProvider (mismo que otros generators).
 *
 * 5 dimensiones de evaluación (0-100 cada una):
 * 1. Relevancia con la campaña
 * 2. Calidad técnica de la imagen
 * 3. Coherencia de marca (colores, estilo)
 * 4. Composición visual
 * 5. Legibilidad del texto / CTA
 *
 * Manejo de fallos en la validación:
 * - Si la llamada de validación falla (error de API, timeout): acepta piezas sin score
 * - Si el score promedio < threshold (default 60): marca para regeneración
 * - Máximo 2 piezas se regeneran (las de peor score); el resto se acepta
 *
 * Ver ADR-0024.
 */

import Anthropic from '@anthropic-ai/sdk'
import OpenAI from 'openai'
import { getAiConfig, type AiProviderType } from './ai-config'
import type { BillingContext } from './ai-tool-call'
import { registerAiUsage } from '../billing/register-ai-usage'
import type { AdVisual, AdVisuals } from './types'

// ── Constantes ────────────────────────────────────────────────────────────────

/** Score mínimo promedio para que una pieza sea aceptada. */
const VALIDATION_THRESHOLD = 60

/** Máximo de piezas que se regeneran tras validación (las de peor score). */
const MAX_REGENERATIONS = 2

/** Timeout para la llamada de validación (ms). */
const VALIDATION_TIMEOUT_MS = 30_000

/** Tamaño de lote para validación (máx 3 imágenes por llamada). */
const VALIDATION_BATCH_SIZE = 3

/** Budget total para toda la validación (descarga + API). Si se supera, acepta sin score. */
const VALIDATION_TOTAL_BUDGET_MS = 90_000

// ── Tipos públicos ────────────────────────────────────────────────────────────

export type ValidationScore = {
  visualId: string  // format + angle como identificador
  scores: {
    relevancia: number
    calidadTecnica: number
    coherenciaMarca: number
    composicion: number
    legibilidadTexto: number
  }
  scorePromedio: number
  observaciones: string
  aprobada: boolean
}

export type ValidationResult = {
  scores: ValidationScore[]
  /** IDs de piezas que deben regenerarse (máx MAX_REGENERATIONS) */
  toRegenerate: string[]
  /** Si la validación en sí falló (error de API) — en ese caso aceptar todo */
  validationFailed: boolean
}

// ── Clientes de IA ────────────────────────────────────────────────────────────

let _anthropicClient: Anthropic | null = null
function getAnthropicValidator(): Anthropic {
  if (!_anthropicClient) {
    _anthropicClient = new Anthropic({ timeout: VALIDATION_TIMEOUT_MS, maxRetries: 0 })
  }
  return _anthropicClient
}

let _openaiClient: OpenAI | null = null
function getOpenAIValidator(): OpenAI {
  if (!_openaiClient) {
    const apiKey = process.env['OPENAI_API_KEY']
    if (!apiKey) throw new Error('[ad-visual-validator] OPENAI_API_KEY no está configurada')
    _openaiClient = new OpenAI({ apiKey, timeout: VALIDATION_TIMEOUT_MS })
  }
  return _openaiClient
}

// ── Construcción del prompt de validación ─────────────────────────────────────

function buildValidationSystemPrompt(): string {
  return `Sos un experto en publicidad digital especializado en Meta Ads (Facebook/Instagram).
Tu trabajo es evaluar piezas gráficas publicitarias en 5 dimensiones.

Para cada pieza, devolvé un JSON con este formato exacto:
{
  "scores": [
    {
      "visualId": "<id>",
      "relevancia": <0-100>,
      "calidadTecnica": <0-100>,
      "coherenciaMarca": <0-100>,
      "composicion": <0-100>,
      "legibilidadTexto": <0-100>,
      "observaciones": "<1-2 oraciones concretas>"
    }
  ]
}

Criterios:
- relevancia: ¿la imagen comunica el mensaje de la campaña?
- calidadTecnica: ¿la imagen es nítida, sin artefactos, bien iluminada?
- coherenciaMarca: ¿los colores y estilo son coherentes con la marca descrita?
- composicion: ¿la composición es equilibrada y profesional para un ad?
- legibilidadTexto: ¿el texto en la imagen es legible y está bien posicionado? (100 si no hay texto)

Sé objetivo y estricto. Un ad mediocre no merece más de 65 en ninguna dimensión.`
}

function buildValidationUserMessage(
  batch: Array<{ visual: AdVisual; imageBase64: string }>,
  brandContext: { dominantColors: string[]; style: string },
): string {
  const lines: string[] = [
    `Contexto de marca:`,
    `- Colores: ${brandContext.dominantColors.join(', ')}`,
    `- Estilo: ${brandContext.style}`,
    '',
    `Evaluá las ${batch.length} piezas adjuntas.`,
    '',
    'IDs de las piezas (en orden):',
    ...batch.map((b, i) => `  ${i + 1}. visualId: "${b.visual.format}-${b.visual.angle}" | formato: ${b.visual.format} | ángulo: ${b.visual.angle}`),
  ]
  return lines.join('\n')
}

// ── Validación con Anthropic ──────────────────────────────────────────────────

async function validateWithAnthropic(
  batch: Array<{ visual: AdVisual; imageBase64: string }>,
  brandContext: { dominantColors: string[]; style: string },
  billingContext?: BillingContext,
): Promise<ValidationScore[]> {
  const client = getAnthropicValidator()

  const imageContent: Anthropic.ImageBlockParam[] = batch.map((b) => ({
    type: 'image',
    source: {
      type: 'base64',
      media_type: 'image/png',
      data: b.imageBase64,
    },
  }))

  const response = await client.messages.create({
    model: 'claude-haiku-4-5-20251001',
    max_tokens: 1024,
    system: buildValidationSystemPrompt(),
    messages: [
      {
        role: 'user',
        content: [
          ...imageContent,
          { type: 'text', text: buildValidationUserMessage(batch, brandContext) },
        ],
      },
    ],
  })

  if (billingContext) {
    void registerAiUsage({
      teamId: billingContext.teamId,
      projectId: billingContext.projectId,
      provider: 'ANTHROPIC',
      model: 'claude-haiku-4-5-20251001',
      operation: 'visual_validation',
      source: billingContext.source,
      tokensIn: response.usage.input_tokens,
      tokensOut: response.usage.output_tokens,
    })
  }

  const text = response.content.find((b) => b.type === 'text')?.text ?? ''
  return parseValidationResponse(text, batch)
}

// ── Validación con OpenAI ─────────────────────────────────────────────────────

async function validateWithOpenAI(
  batch: Array<{ visual: AdVisual; imageBase64: string }>,
  brandContext: { dominantColors: string[]; style: string },
  billingContext?: BillingContext,
): Promise<ValidationScore[]> {
  const client = getOpenAIValidator()

  const imageContent: OpenAI.Chat.ChatCompletionContentPartImage[] = batch.map((b) => ({
    type: 'image_url',
    image_url: { url: `data:image/png;base64,${b.imageBase64}` },
  }))

  const response = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    max_tokens: 1024,
    messages: [
      { role: 'system', content: buildValidationSystemPrompt() },
      {
        role: 'user',
        content: [
          ...imageContent,
          { type: 'text', text: buildValidationUserMessage(batch, brandContext) },
        ],
      },
    ],
    response_format: { type: 'json_object' },
  })

  if (billingContext) {
    void registerAiUsage({
      teamId: billingContext.teamId,
      projectId: billingContext.projectId,
      provider: 'OPENAI',
      model: 'gpt-4o-mini',
      operation: 'visual_validation',
      source: billingContext.source,
      tokensIn: response.usage?.prompt_tokens ?? 0,
      tokensOut: response.usage?.completion_tokens ?? 0,
    })
  }

  const text = response.choices[0]?.message?.content ?? ''
  return parseValidationResponse(text, batch)
}

// ── Parsing de la respuesta ───────────────────────────────────────────────────

function parseValidationResponse(
  raw: string,
  batch: Array<{ visual: AdVisual }>,
): ValidationScore[] {
  let parsed: unknown
  try {
    // Extraer JSON del texto (puede venir con markdown ```json ... ```)
    const jsonMatch = raw.match(/\{[\s\S]*\}/)
    if (!jsonMatch) throw new Error('No se encontró JSON en la respuesta')
    parsed = JSON.parse(jsonMatch[0])
  } catch {
    throw new Error(`[ad-visual-validator] Respuesta de validación no es JSON válido: ${raw.slice(0, 200)}`)
  }

  const obj = parsed as Record<string, unknown>
  if (!Array.isArray(obj['scores'])) {
    throw new Error('[ad-visual-validator] Respuesta no tiene array "scores"')
  }

  return batch.map((b, i) => {
    const raw = (obj['scores'] as unknown[])[i] as Record<string, unknown> | undefined
    const visualId = `${b.visual.format}-${b.visual.angle}`

    if (!raw) {
      // Si no hay score para esta pieza, aceptarla con score neutro
      return buildNeutralScore(visualId)
    }

    // Usar ?? 0 (no ||) para no enmascarar scores reales de 0
    const relevancia = clamp(raw['relevancia'] != null ? Number(raw['relevancia']) : 0)
    const calidadTecnica = clamp(raw['calidadTecnica'] != null ? Number(raw['calidadTecnica']) : 0)
    const coherenciaMarca = clamp(raw['coherenciaMarca'] != null ? Number(raw['coherenciaMarca']) : 0)
    const composicion = clamp(raw['composicion'] != null ? Number(raw['composicion']) : 0)
    const legibilidadTexto = clamp(raw['legibilidadTexto'] != null ? Number(raw['legibilidadTexto']) : 0)
    const scorePromedio = Math.round(
      (relevancia + calidadTecnica + coherenciaMarca + composicion + legibilidadTexto) / 5,
    )

    return {
      visualId,
      scores: { relevancia, calidadTecnica, coherenciaMarca, composicion, legibilidadTexto },
      scorePromedio,
      observaciones: String(raw['observaciones'] ?? '').slice(0, 300),
      aprobada: scorePromedio >= VALIDATION_THRESHOLD,
    }
  })
}

function clamp(n: number): number {
  return Math.max(0, Math.min(100, Math.round(n)))
}

function buildNeutralScore(visualId: string): ValidationScore {
  return {
    visualId,
    scores: { relevancia: 70, calidadTecnica: 70, coherenciaMarca: 70, composicion: 70, legibilidadTexto: 70 },
    scorePromedio: 70,
    observaciones: 'Score neutral asignado (sin respuesta del validador para esta pieza).',
    aprobada: true,
  }
}

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Valida las piezas generadas y determina cuáles deben regenerarse.
 *
 * Si la validación falla (error de API, timeout, parse error):
 * devuelve validationFailed=true y acepta todas las piezas sin score.
 * No bloquea el pipeline ante fallos de validación.
 *
 * @param adVisuals - Piezas generadas por generateAdVisuals
 * @param billingContext - Contexto de billing (opcional)
 * @returns ValidationResult con scores y lista de piezas a regenerar
 */
export async function validateAdVisuals(
  adVisuals: AdVisuals,
  billingContext?: BillingContext,
): Promise<ValidationResult> {
  const { visuals } = adVisuals

  if (visuals.length === 0) {
    return { scores: [], toRegenerate: [], validationFailed: false }
  }

  console.log(`[ad-visual-validator] starting validation of ${visuals.length} visuals`)

  // Budget total para toda la validación — si se supera, acepta sin score
  const timeoutResult: ValidationResult = { scores: [], toRegenerate: [], validationFailed: true }
  const budgetTimeout = new Promise<ValidationResult>((resolve) =>
    setTimeout(() => {
      console.warn(`[ad-visual-validator] budget total (${VALIDATION_TOTAL_BUDGET_MS}ms) superado — aceptando sin score`)
      resolve(timeoutResult)
    }, VALIDATION_TOTAL_BUDGET_MS),
  )

  return Promise.race([_validateAdVisualsCore(adVisuals, billingContext), budgetTimeout])
}

async function _validateAdVisualsCore(
  adVisuals: AdVisuals,
  billingContext?: BillingContext,
): Promise<ValidationResult> {
  const { visuals, brandContext } = adVisuals

  let provider: AiProviderType
  try {
    const config = await getAiConfig()
    provider = config.provider
  } catch {
    provider = 'OPENAI'
  }

  // Descargar imágenes en paralelo para validación (desde signed URLs)
  const downloadResults = await Promise.allSettled(
    visuals.map(async (visual) => {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5_000)
      try {
        const response = await fetch(visual.imageUrl, { signal: controller.signal })
        clearTimeout(timeoutId)
        if (!response.ok) {
          console.warn(`[ad-visual-validator] imagen no descargable (${response.status}): ${visual.format}/${visual.angle} — asignando score neutral`)
          return null
        }
        const arrayBuffer = await response.arrayBuffer()
        const imageBase64 = Buffer.from(arrayBuffer).toString('base64')
        return { visual, imageBase64 }
      } catch (err) {
        clearTimeout(timeoutId)
        const msg = err instanceof Error ? err.message : String(err)
        console.warn(`[ad-visual-validator] error descargando imagen ${visual.format}/${visual.angle}: ${msg} — asignando score neutral`)
        return null
      }
    }),
  )

  const visualsWithImages: Array<{ visual: AdVisual; imageBase64: string }> = []
  for (const result of downloadResults) {
    if (result.status === 'fulfilled' && result.value) {
      visualsWithImages.push(result.value)
    }
  }

  if (visualsWithImages.length === 0) {
    console.warn('[ad-visual-validator] no se pudieron descargar imágenes — aceptando sin validación')
    return { scores: [], toRegenerate: [], validationFailed: true }
  }

  // Validar en lotes de VALIDATION_BATCH_SIZE
  const allScores: ValidationScore[] = []

  for (let i = 0; i < visualsWithImages.length; i += VALIDATION_BATCH_SIZE) {
    const batch = visualsWithImages.slice(i, i + VALIDATION_BATCH_SIZE)

    try {
      let batchScores: ValidationScore[]

      if (provider === 'ANTHROPIC') {
        batchScores = await validateWithAnthropic(batch, brandContext, billingContext)
      } else {
        batchScores = await validateWithOpenAI(batch, brandContext, billingContext)
      }

      allScores.push(...batchScores)

      console.log(`[ad-visual-validator] batch validated`, {
        batch: i / VALIDATION_BATCH_SIZE + 1,
        scores: batchScores.map((s) => ({ visualId: s.visualId, score: s.scorePromedio, aprobada: s.aprobada })),
      })
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      console.error(`[ad-visual-validator] validation batch failed: ${msg} — aceptando lote sin score`)

      // Degradación: asignar scores neutrales para las piezas del lote fallido
      for (const b of batch) {
        allScores.push(buildNeutralScore(`${b.visual.format}-${b.visual.angle}`))
      }
    }
  }

  // Agregar scores neutrales para las piezas que no se pudieron descargar
  const downloadedIds = new Set(visualsWithImages.map((v) => `${v.visual.format}-${v.visual.angle}`))
  for (const visual of visuals) {
    const id = `${visual.format}-${visual.angle}`
    if (!downloadedIds.has(id)) {
      allScores.push(buildNeutralScore(id))
    }
  }

  // Determinar cuáles regenerar (máx MAX_REGENERATIONS, las de peor score)
  const failed = allScores
    .filter((s) => !s.aprobada)
    .sort((a, b) => a.scorePromedio - b.scorePromedio)
    .slice(0, MAX_REGENERATIONS)

  const toRegenerate = failed.map((s) => s.visualId)

  if (toRegenerate.length > 0) {
    console.warn(`[ad-visual-validator] ${toRegenerate.length} piezas para regenerar: ${toRegenerate.join(', ')}`)
  } else {
    console.log(`[ad-visual-validator] todas las piezas aprobaron la validación`)
  }

  return {
    scores: allScores,
    toRegenerate,
    validationFailed: false,
  }
}

/**
 * Aplica los scores de validación al array de AdVisual.
 * Actualiza el campo validationScore en cada pieza.
 */
export function applyValidationScores(
  visuals: AdVisual[],
  validationResult: ValidationResult,
): AdVisual[] {
  if (validationResult.validationFailed) return visuals

  const scoreMap = new Map(validationResult.scores.map((s) => [s.visualId, s.scorePromedio]))

  return visuals.map((v) => {
    const id = `${v.format}-${v.angle}`
    const score = scoreMap.get(id)
    return score !== undefined ? { ...v, validationScore: score } : v
  })
}
