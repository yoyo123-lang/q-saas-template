import { test, expect } from '@playwright/test'

/**
 * E2E: Catálogo público
 * Tests the public catalog browsing experience.
 * Requires seed data to be present in the database.
 */

test.describe('Catálogo', () => {
  test('Landing carga correctamente', async ({ page }) => {
    await page.goto('/')
    await expect(page).toHaveTitle(/Qapitaliza/i)
    await expect(page.getByRole('link', { name: /explorar/i }).first()).toBeVisible()
  })

  test('Click en "Explorar" navega al catálogo', async ({ page }) => {
    await page.goto('/')
    await page.getByRole('link', { name: /explorar/i }).first().click()
    await expect(page).toHaveURL(/\/explorar/)
  })

  test('Catálogo muestra activos o empty state', async ({ page }) => {
    await page.goto('/explorar')

    // Wait for any meaningful content state (avoids SSR/hydration race conditions).
    // The locator resolves when ANY of these becomes visible.
    await expect(
      page.locator('a[href^="/explorar/"]')
        .or(page.getByText(/sin resultados/i))
        .or(page.getByText(/no pudimos cargar/i))
        .first()
    ).toBeVisible({ timeout: 15000 })
  })

  test('Barra de búsqueda filtra resultados', async ({ page }) => {
    await page.goto('/explorar')

    // Fill the search box (in navbar hero or results header)
    const searchInput = page.locator('input[placeholder*="Buscar"], input[name="q"]').first()
    if (await searchInput.isVisible()) {
      await searchInput.fill('SaaS')
      await searchInput.press('Enter')
      await expect(page).toHaveURL(/q=SaaS/)
    }
  })

  test('Filtro de categoría actualiza la URL', async ({ page }) => {
    await page.goto('/explorar')

    // Click a category checkbox if visible
    const categoryFilter = page.locator('input[type="checkbox"]').first()
    if (await categoryFilter.isVisible()) {
      await categoryFilter.check()
      await expect(page).toHaveURL(/category=/)
    }
  })

  test('Click en activo navega a la página de detalle', async ({ page }) => {
    await page.goto('/explorar')

    // Check if there are any listing cards without waiting (avoid TimeoutError)
    const cardCount = await page.locator('a[href^="/explorar/"]').count()
    if (cardCount === 0) return // no listings — skip

    const firstCard = page.locator('a[href^="/explorar/"]').first()
    const cardHref = await firstCard.getAttribute('href')

    if (cardHref) {
      await firstCard.click()
      await expect(page).toHaveURL(new RegExp(cardHref.replace('/', '\\/')))
      // Detail page should have a heading
      await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
    }
  })

  test('Página de detalle tiene precio y botón consultar', async ({ page }) => {
    await page.goto('/explorar')

    // Check if there are any listing cards without waiting (avoid TimeoutError)
    const cardCount = await page.locator('a[href^="/explorar/"]').count()
    if (cardCount === 0) return // no listings — skip

    const firstCard = page.locator('a[href^="/explorar/"]').first()
    const href = await firstCard.getAttribute('href')

    if (href) {
      await page.goto(href)
      // Should show price in USD
      await expect(page.getByText(/USD/)).toBeVisible()
    }
  })

  test('Páginas de términos y privacidad no retornan 404', async ({ page }) => {
    const response1 = await page.goto('/terminos')
    const response2 = await page.goto('/privacidad')
    expect(response1?.status()).toBe(200)
    expect(response2?.status()).toBe(200)
  })

  test('Página 404 muestra mensaje personalizado', async ({ page }) => {
    await page.goto('/ruta-que-no-existe')
    // Use first() to avoid strict-mode violation (page has both a <p>404</p> and an <h1>)
    await expect(page.getByText(/404|no encontrada/i).first()).toBeVisible()
    await expect(page.getByRole('link', { name: /inicio/i })).toBeVisible()
  })
})
