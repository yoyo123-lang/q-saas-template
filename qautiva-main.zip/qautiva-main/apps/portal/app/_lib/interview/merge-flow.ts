import { createHash } from 'crypto'
import type { QuestionBlock } from './types'

/** Mapeo fijo stageKey → AgentConfig.agentNumber (1-6) */
const STAGE_KEY_TO_AGENT_NUMBER: Record<string, number> = {
  DISCOVERY: 1,
  RESEARCH: 2,
  BRAND: 3,
  WEBSITE: 4,
  CAMPAIGNS: 5,
  MEDIA: 6,
}

/**
 * AL2: Valida que un item parseado del interviewPrompt tenga la estructura mínima
 * requerida para ser un QuestionBlock. Previene que JSON válido pero mal formado
 * (configurado por un admin) corrompa el flowDefinition de futuras sesiones.
 */
function isValidQuestionBlock(item: unknown): item is QuestionBlock {
  if (!item || typeof item !== 'object') return false
  const q = item as Record<string, unknown>
  return typeof q.id === 'string' && q.id.length > 0 && typeof q.inputType === 'string'
}

/**
 * Merge de preguntas base (AgentConfig.interviewPrompt) con preguntas
 * específicas por industria (IndustryTemplate.questions[stageNumber]).
 *
 * Reglas de merge:
 * - Las preguntas base van primero
 * - Las preguntas de industria con el mismo id REEMPLAZAN a las base
 * - Las preguntas de industria sin id conflicto se AGREGAN al final
 *
 * @param stageNumber - Número de etapa (1-6)
 * @param interviewPrompt - JSON string del AgentConfig, debe parsear como QuestionBlock[]
 * @param industryQuestions - Mapa { "1": QuestionBlock[], "2": ... } del IndustryTemplate
 * @returns Array mergeado de QuestionBlock listo para guardar en flowDefinition
 */
export function mergeFlowDefinition(
  stageNumber: number,
  interviewPrompt: string | null,
  industryQuestions: Record<string, QuestionBlock[]> | null,
): QuestionBlock[] {
  // Parsear preguntas base
  let baseQuestions: QuestionBlock[] = []
  if (interviewPrompt) {
    try {
      const parsed: unknown = JSON.parse(interviewPrompt)
      if (Array.isArray(parsed)) {
        // AL2: Filtrar solo items con estructura válida de QuestionBlock
        baseQuestions = parsed.filter(isValidQuestionBlock)
      }
    } catch {
      // interviewPrompt aún no configurado como JSON — se deja vacío hasta A14
      baseQuestions = []
    }
  }

  // Preguntas específicas de la industria para esta etapa
  const rawIndustryQuestions = industryQuestions?.[String(stageNumber)] ?? []
  // AL2: Filtrar solo items válidos de las preguntas de industria también
  const industryStageQuestions = Array.isArray(rawIndustryQuestions)
    ? rawIndustryQuestions.filter(isValidQuestionBlock)
    : []

  // Merge: las de industria sobreescriben las base cuando comparten id
  const merged = new Map<string, QuestionBlock>(baseQuestions.map((q) => [q.id, q]))
  for (const q of industryStageQuestions) {
    merged.set(q.id, q)
  }

  return Array.from(merged.values())
}

/**
 * Determina si un valor de respuesta está vacío (no cuenta como "respondido").
 * Usado tanto al guardar (PATCH /answer) como al validar el submit.
 *
 * Reglas:
 * - string vacío o solo espacios → vacío
 * - array vacío → vacío
 * - null/undefined → vacío
 * - 0, false, objetos con keys → NO vacíos (son valores válidos)
 */
export function isAnswerEmpty(value: unknown): boolean {
  if (value === null || value === undefined) return true
  if (typeof value === 'string') return value.trim().length === 0
  if (Array.isArray(value)) return value.length === 0
  return false
}

/**
 * Computa SHA-256 del flowDefinition para verificar integridad.
 * Se guarda en InterviewSession.flowDefinitionHash al crear la sesión.
 */
export function hashFlowDefinition(flowDefinition: QuestionBlock[]): string {
  return createHash('sha256').update(JSON.stringify(flowDefinition)).digest('hex')
}

/**
 * Devuelve el agentNumber de AgentConfig correspondiente a un stageKey.
 * Fallback al stageNumber si el stageKey no está mapeado (ej: stageKey = "").
 */
export function getAgentNumberForStage(stageKey: string, stageNumber: number): number {
  return STAGE_KEY_TO_AGENT_NUMBER[stageKey] ?? stageNumber
}
