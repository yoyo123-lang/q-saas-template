import { cookies } from 'next/headers'
import { unstable_cache } from 'next/cache'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { TopBar } from '@/components/TopBar'

const getUserHasMedios = unstable_cache(
  async (authUserId: string) => {
    const profile = await prisma.userProfile.findUnique({
      where: { authUserId },
      select: { _count: { select: { media: { where: { deletedAt: null } } } } },
    })
    return (profile?._count.media ?? 0) > 0
  },
  ['user-has-medios'],
  { revalidate: 60 },
)

export default async function MarketplaceLayout({ children }: { children: React.ReactNode }) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  const hasMedios = user ? await getUserHasMedios(user.id) : false

  return (
    <div className="min-h-screen bg-[#0B0F1A] flex flex-col">
      <TopBar hasMedios={hasMedios} />
      <main className="flex-1">
        {children}
      </main>
    </div>
  )
}
