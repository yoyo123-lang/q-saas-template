export function Domains() {
  const tlds = [
    { ext: '.com', price: 'desde $12.000 ARS/año' },
    { ext: '.net', price: 'desde $14.000 ARS/año' },
    { ext: '.org', price: 'desde $11.000 ARS/año' },
    { ext: '.com.ar', price: 'desde $3.000 ARS/año' },
  ]

  return (
    <section id="dominios" className="bg-navy-900 py-20 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Registrá tu dominio
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Buscá y registrá tu dominio en minutos. Más de 500 extensiones disponibles.
          </p>
        </div>

        {/* Buscador visual */}
        <div className="flex gap-2 mb-12 max-w-xl mx-auto">
          <a
            href="https://app.qautiva.ar/dominios/buscar"
            className="flex-1 bg-navy-950 border border-navy-800 rounded-lg px-4 py-3 text-slate-500 text-sm cursor-text"
            aria-label="Buscar dominio"
          >
            ejemplo, minegocio, marca...
          </a>
          <a
            href="https://app.qautiva.ar/dominios/buscar"
            className="px-5 py-3 rounded-lg bg-accent text-white font-semibold text-sm hover:opacity-90 transition-opacity"
          >
            Buscar
          </a>
        </div>

        {/* TLD cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {tlds.map(({ ext, price }) => (
            <div
              key={ext}
              className="bg-navy-950 rounded-card p-6 border border-navy-800 hover:border-accent/40 transition-colors duration-300 text-center"
            >
              <p className="text-accent font-bold text-2xl mb-2">{ext}</p>
              <p className="text-slate-400 text-sm">{price}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <a
            href="https://app.qautiva.ar/dominios/buscar"
            className="inline-block px-8 py-4 rounded-lg bg-accent text-white font-semibold text-lg hover:opacity-90 transition-opacity"
          >
            Empezar
          </a>
        </div>
      </div>
    </section>
  )
}
