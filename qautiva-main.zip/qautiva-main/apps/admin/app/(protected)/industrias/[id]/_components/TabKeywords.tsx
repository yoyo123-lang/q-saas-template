'use client'

import { useState } from 'react'
import { updateKeywords } from '../../actions'
import type { ActionState } from '../../actions'

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar keywords'}
    </button>
  )
}

interface TabKeywordsProps {
  industryId: string
  keywords: string[]
}

export function TabKeywords({ industryId, keywords: initialKeywords }: TabKeywordsProps) {
  const [keywords, setKeywords] = useState<string[]>(initialKeywords)
  const [inputValue, setInputValue] = useState('')
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  function addKeyword() {
    const trimmed = inputValue.trim()
    if (!trimmed || keywords.includes(trimmed)) {
      setInputValue('')
      return
    }
    setKeywords((prev) => [...prev, trimmed])
    setInputValue('')
  }

  function removeKeyword(index: number) {
    setKeywords((prev) => prev.filter((_, i) => i !== index))
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      e.preventDefault()
      addKeyword()
    }
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', industryId)
    formData.set('keywords', JSON.stringify(keywords))
    try {
      const result = await updateKeywords(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-4">
      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-4 flex flex-col gap-4">
        {/* Input para agregar */}
        <div className="flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Nueva keyword..."
            maxLength={100}
            className="flex-1 px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
          />
          <button
            type="button"
            onClick={addKeyword}
            className="px-3 py-2 bg-[#1E293B] text-[#94A3B8] text-sm rounded-lg hover:text-white hover:bg-[#334155] transition-colors"
          >
            Agregar
          </button>
        </div>

        {/* Chips */}
        {keywords.length === 0 ? (
          <p className="text-[#64748B] text-sm text-center py-4">
            Sin keywords todavía. Agregá la primera arriba.
          </p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {keywords.map((kw, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#1E293B] text-[#94A3B8] text-sm rounded-full"
              >
                {kw}
                <button
                  type="button"
                  onClick={() => removeKeyword(idx)}
                  className="text-[#64748B] hover:text-red-400 transition-colors leading-none"
                  aria-label={`Eliminar keyword ${kw}`}
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center gap-3">
        <SaveButton pending={isPending} />
        {state && (
          state.ok
            ? <p className="text-sm text-green-400">Guardado correctamente.</p>
            : <p className="text-sm text-red-400">{state.error}</p>
        )}
      </div>
    </form>
  )
}
