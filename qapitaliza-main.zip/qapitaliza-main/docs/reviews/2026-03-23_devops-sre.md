# Revisión: DevOps / SRE
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de DevOps / SRE

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 1 alto, 2 medios, 1 bajo

## Hallazgos

### [ALTO → CORREGIDO] Faltaba `robots.txt`
- Dónde: ausente
- Problema: Sin robots.txt, los crawlers accedían a `/api/`, `/dashboard/` y `/admin/` — rutas que no deben indexarse.
- Fix aplicado: `src/app/robots.ts` con reglas explícitas de disallow y referencia al sitemap.

### [ALTO → CORREGIDO] Errores de DB tragados silenciosamente
- Dónde: `src/app/page.tsx:29`, `src/app/sitemap.ts:32`
- Problema: Los `catch {}` vacíos impedían diagnosticar fallas de DB en producción.
- Fix aplicado: `console.error('[contexto] mensaje descriptivo', e)`.

### [MEDIO] No hay logging estructurado — solo `console.error`
- Problema: Los errores se loguean con `console.error` pero sin formato estructurado (sin request_id, sin contexto de usuario). En producción con alto volumen, es difícil correlacionar logs.
- Recomendación: Integrar un logger estructurado (Pino, Winston) en Sesión 05+.

### [MEDIO] Variables de entorno no documentadas completamente
- Dónde: `.env.example`
- Problema: `.env.example` podría no listar todas las variables necesarias para el nuevo código de Sesión 02. Verificar que `DATABASE_URL`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` están documentadas.
- Recomendación: Revisar y actualizar `.env.example` antes del primer deploy.

### [BAJO] El endpoint `/api/health` no se referencia en ningún proceso de monitoreo
- Dónde: `src/app/api/health/route.ts`
- Problema: El health check existe pero si nadie lo llama periódicamente, no tiene utilidad práctica.
- Recomendación: Configurar uptime monitor (Better Uptime, UptimeRobot) apuntando al endpoint.

## Lo que está bien
- Health check en `/api/health` verifica conexión a DB ✓
- Build en un solo comando (`npm run build`) con `prisma generate` incluido ✓
- Sitemap dinámico con `revalidate: 3600` para no fetchear la DB en cada request ✓
- `robots.ts` ahora protege rutas sensibles ✓
- Manejo graceful cuando DB no está disponible en build (listados retornan array vacío) ✓
- Vercel detectado como plataforma de hosting — deploy sin downtime por defecto ✓

## Recomendaciones generales
- Documentar proceso de rollback en README (Vercel permite redeployar versiones anteriores).
- Configurar monitor de uptime antes del primer deploy público.
- Agregar `DATABASE_URL` al checklist de variables en `.env.example`.
