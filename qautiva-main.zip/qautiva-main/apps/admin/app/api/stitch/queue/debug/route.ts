import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

const LOCK_TIMEOUT_MS = 5 * 60 * 1000

export async function GET(req: NextRequest): Promise<NextResponse> {
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env['CRON_SECRET']
  const hasCronAuth = cronSecret && authHeader === `Bearer ${cronSecret}`

  if (!hasCronAuth) {
    try {
      await requireAdminSession()
    } catch {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }
  }

  const stuckBefore = new Date(Date.now() - LOCK_TIMEOUT_MS)

  const [queueCounts, accounts, queueConfig, zombies, recentErrors] = await Promise.all([
    prisma.webTemplate.groupBy({
      by: ['queueStatus'],
      where: { queueStatus: { not: null } },
      _count: { _all: true },
    }),
    prisma.stitchAccount.findMany({
      select: { id: true, label: true, usedToday: true, dailyLimit: true, active: true, lastResetAt: true },
      orderBy: { usedToday: 'asc' },
    }),
    prisma.stitchQueueConfig.findUnique({ where: { id: 1 } }),
    prisma.webTemplate.findMany({
      where: { queueStatus: 'GENERATING', generatingAt: { lt: stuckBefore } },
      select: { id: true, generatingAt: true, compatibleIndustries: true },
    }),
    prisma.webTemplate.findMany({
      where: { queueStatus: 'ERROR' },
      select: { id: true, compatibleIndustries: true, queueError: true, updatedAt: true },
      orderBy: { updatedAt: 'desc' },
      take: 5,
    }),
  ])

  const counts = Object.fromEntries(queueCounts.map((r) => [r.queueStatus ?? 'null', r._count._all]))

  return NextResponse.json({
    paused: queueConfig?.paused ?? false,
    queueCounts: counts,
    accounts: accounts.map((a) => ({
      ...a,
      exhausted: a.usedToday >= a.dailyLimit,
      lastResetAt: a.lastResetAt.toISOString(),
    })),
    zombieJobs: zombies.map((z) => ({
      id: z.id,
      generatingAt: z.generatingAt?.toISOString(),
      stuckForMs: z.generatingAt ? Date.now() - z.generatingAt.getTime() : null,
      industries: z.compatibleIndustries,
    })),
    recentErrors: recentErrors.map((e) => ({
      id: e.id,
      industries: e.compatibleIndustries,
      queueError: e.queueError,
      updatedAt: e.updatedAt.toISOString(),
    })),
    generatedAt: new Date().toISOString(),
  })
}
