import { test, expect } from '@playwright/test'

/**
 * E2E: Flujo de consulta comprador → vendedor
 * Requires: authenticated BUYER session + at least one published listing.
 * Set E2E_BUYER_EMAIL, E2E_BUYER_PASSWORD env vars.
 */

test.describe('Flujo de consulta', () => {
  test.beforeEach(async ({ page }) => {
    if (!process.env.E2E_BUYER_EMAIL || !process.env.E2E_BUYER_PASSWORD) {
      test.skip()
      return
    }

    await page.goto('/login')
    await page.fill('input[type="email"]', process.env.E2E_BUYER_EMAIL)
    await page.fill('input[type="password"]', process.env.E2E_BUYER_PASSWORD)
    await page.click('button[type="submit"]')
    await expect(page).toHaveURL(/\/dashboard/, { timeout: 10000 })
  })

  test('Página de consultas carga para usuario autenticado', async ({ page }) => {
    await page.goto('/consultas')
    // Should show tabs or empty state, not 404 or login redirect
    await expect(page).not.toHaveURL(/\/login/)
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  })

  test('Favoritos carga para usuario autenticado', async ({ page }) => {
    await page.goto('/favoritos')
    await expect(page).not.toHaveURL(/\/login/)
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  })

  test('Detalle de activo tiene botón "Consultar al vendedor"', async ({ page }) => {
    // Get first published listing
    await page.goto('/explorar')
    const firstCard = page.locator('a[href^="/explorar/"]').first()
    const href = await firstCard.getAttribute('href')

    if (href) {
      await page.goto(href)
      const consultarBtn = page.getByRole('button', { name: /consultar/i })
      await expect(consultarBtn).toBeVisible()
    }
  })

  test('Click en "Consultar" crea consulta y redirige a chat', async ({ page }) => {
    await page.goto('/explorar')
    const firstCard = page.locator('a[href^="/explorar/"]').first()
    const href = await firstCard.getAttribute('href')

    if (!href) return

    await page.goto(href)
    const consultarBtn = page.getByRole('button', { name: /consultar/i })

    if (await consultarBtn.isVisible()) {
      await consultarBtn.click()
      // Should redirect to consultas or show modal
      await page.waitForURL(/\/consultas/, { timeout: 10000 }).catch(() => {
        // Might show a modal instead — check for it
      })
    }
  })
})
