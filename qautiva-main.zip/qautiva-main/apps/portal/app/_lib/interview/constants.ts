import type { InterviewStatus } from '@qautiva/db'

/**
 * Estados de entrevista en los que el usuario puede actuar
 * (iniciar, continuar, o retomar). Usado en UI para mostrar
 * CTAs y links de navegación a la entrevista.
 */
export const INTERVIEW_ACTIONABLE_STATUSES: InterviewStatus[] = [
  'NOT_STARTED',
  'IN_PROGRESS',
  'PAUSED',
]
