# Plan: Actualizar docs/roles/ — separación tech/business

## Contexto

El template actualizado (`templete-blanco-main.zip`) reorganiza `docs/roles/` en dos subdirectorios:
- `docs/roles/tech/` — roles horizontales (siempre aplican)
- `docs/roles/business/` — roles verticales (aplican si hay BUSINESS_MODEL.md)

También introduce `docs/BUSINESS_TECHNICAL_MAP.md`, un archivo nuevo que vincula reglas de negocio con decisiones técnicas, y agrega un bloque "Contexto de negocio" a los 6 roles tech.

## Cambios a realizar

### Tarea 1: Crear estructura de directorios
- Crear `docs/roles/tech/`
- Crear `docs/roles/business/`

### Tarea 2: Mover archivos de roles a subdirectorios
**A `docs/roles/tech/`** (8 archivos):
- `code-reviewer.md`
- `qa-engineer.md`
- `security-auditor.md`
- `performance-engineer.md`
- `devops-sre.md`
- `ux-reviewer.md`
- `security-audit-post-sprint.md`
- `security-scan-quick.md`

**A `docs/roles/business/`** (3 archivos):
- `product-reviewer.md`
- `business-logic-reviewer.md`
- `data-analytics-reviewer.md`

**Se queda en `docs/roles/`** (no se mueve):
- `REVIEW_ROLES.md`

### Tarea 3: Actualizar contenido de los archivos de roles
**6 roles tech** — agregar bloque "Contexto de negocio" (referencia a `BUSINESS_TECHNICAL_MAP.md`):
- `code-reviewer.md` → sección Código
- `qa-engineer.md` → sección QA
- `security-auditor.md` → sección Seguridad
- `performance-engineer.md` → sección Performance
- `devops-sre.md` → sección Infraestructura
- `ux-reviewer.md` → sección UX

**Todos los 11 roles** — actualizar rutas en prompts de activación:
- `docs/roles/X.md` → `docs/roles/tech/X.md` o `docs/roles/business/X.md`

### Tarea 4: Crear `docs/BUSINESS_TECHNICAL_MAP.md`
- Copiar el archivo del template (es un template con placeholders, se llenará con `/project:descubrimiento`)

### Tarea 5: Actualizar `docs/roles/REVIEW_ROLES.md`
- Actualizar todas las rutas en la tabla de roles
- Agregar bloque "Regla de precedencia" (negocio manda sobre técnica)
- Actualizar prompt de ejemplo con ruta `docs/roles/tech/`

### Tarea 6: Actualizar referencias en otros archivos del proyecto
Archivos que referencian `docs/roles/` y necesitan actualización de rutas:

| Archivo | Tipo de cambio |
|---------|---------------|
| `.claude/commands/cambio.md` | Rutas genéricas → incluir `tech/` o `business/` |
| `.claude/commands/cambio-grande.md` | Ídem |
| `.claude/commands/revision.md` | Ídem |
| `.claude/commands/deploy.md` | Ruta de `security-scan-quick.md` → `tech/` |
| `docs/REGLAS_PREVENTIVAS.md` | 7 rutas específicas de roles |
| `docs/MULTI-AGENT.md` | 3 rutas en tabla |
| `docs/MANUAL_DE_USO.md` | Referencia genérica `docs/roles/*.md` |
| `README.md` | 10 rutas de roles en la sección de documentación |

**NO se tocan** (tienen contenido específico de Qautiva, no del template):
- `docs/OPERATIONS.md` — tiene runbooks reales del proyecto
- `docs/ARCHITECTURE.md` — tiene arquitectura real, no placeholders
- `docs/KNOWN_ISSUES.md` — tiene issues documentados

**NO se tocan** (archivos históricos/de sesión, las rutas viejas quedan como registro):
- `SESSION_LOG.md`
- `PLAN.md`
- `IMPLEMENTATION_PLAN.md`
- `plan-campanas-ui.md`
- `docs/plan-domain-registration.md`
- `docs/reviews/*` (informes históricos)
- `docs/marketplace/ETAPAS.md`

### Tarea 7: Commit y push
- Commit atómico con mensaje descriptivo
- Push a `claude/review-docs-roles-ThQYj`

## Riesgos

1. **Rutas rotas**: Si algún archivo que no detectamos referencia `docs/roles/X.md` directamente, se romperá. Mitigación: ya hicimos grep exhaustivo.
2. **Commands/skills que usan rutas dinámicas**: Los commands de `.claude/commands/` usan `docs/roles/[ROL].md` como patrón genérico — hay que decidir si cambiar a `docs/roles/tech/[ROL].md` o documentar que el agente debe detectar el subdirectorio.

## Orden de ejecución

1 → 2 → 3 → 4 → 5 → 6 → 7 (secuencial, cada paso depende del anterior)
