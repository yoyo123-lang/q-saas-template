'use server'

import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getPrisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'
import { trackEvent } from '@/lib/analytics/events'
import {
  createListingSchema,
  updateListingSchema,
  type CreateListingData,
  type UpdateListingData,
} from '@/lib/schemas/listing'

const ACTIVE_LISTING_LIMIT = 50

export interface ActionResult<T = undefined> {
  success: boolean
  error?: string
  data?: T
}

// ─── Helpers ─────────────────────────────────────────────────

async function getAuthenticatedUser() {
  const supabase = await createClient()
  const { data: { user }, error } = await supabase.auth.getUser()
  if (error || !user) return null
  return user
}

async function verifyOwnership(listingId: string, userId: string): Promise<boolean> {
  const listing = await getPrisma().listing.findFirst({
    where: { id: listingId },
    select: { sellerId: true },
  })
  return listing?.sellerId === userId
}

function slugify(title: string): string {
  return title
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 80)
}

async function uniqueSlug(base: string): Promise<string> {
  const prisma = getPrisma()
  let slug = base
  let i = 0
  while (await prisma.listing.findFirst({ where: { slug }, select: { id: true } })) {
    i++
    slug = `${base}-${i}`
  }
  return slug
}

// ─── Actions ─────────────────────────────────────────────────

export async function createListing(
  data: CreateListingData
): Promise<ActionResult<{ id: string; slug: string }>> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    const parsed = createListingSchema.safeParse(data)
    if (!parsed.success) {
      return { success: false, error: 'Datos inválidos. Revisá el formulario.' }
    }

    const prisma = getPrisma()

    // Verificar límite de listados activos
    const activeCount = await prisma.listing.count({
      where: {
        sellerId: user.id,
        status: { in: ['PUBLISHED', 'PENDING_REVIEW', 'DRAFT'] },
      },
    })
    if (activeCount >= ACTIVE_LISTING_LIMIT) {
      return {
        success: false,
        error: `Alcanzaste el límite de ${ACTIVE_LISTING_LIMIT} listados activos.`,
      }
    }

    const {
      title, type, description, techStack, tags, screenshotUrls,
      askingPrice, currency, url,
      monthlyTraffic, domainAge, monthlyRevenue,
    } = parsed.data
    let slug = await uniqueSlug(slugify(parsed.data.title))

    const listingData = {
      title,
      type,
      description,
      sellerId: user.id,
      slug,
      askingPrice,
      currency: currency ?? 'USD',
      url: url || null,
      techStack: techStack ?? [],
      tags: tags ?? [],
      screenshotUrls: screenshotUrls ?? [],
      status: 'DRAFT' as const,
      monthlyTraffic: monthlyTraffic?.value ?? null,
      domainAge: domainAge?.value ? Math.round(domainAge.value) : null,
      monthlyRevenue: monthlyRevenue?.value ?? null,
    }

    let listing
    try {
      listing = await prisma.listing.create({ data: listingData })
    } catch (createErr) {
      // Retry once with a random suffix if there's a unique constraint collision
      if (createErr instanceof Prisma.PrismaClientKnownRequestError && createErr.code === 'P2002') {
        slug = `${slug}-${Date.now().toString(36)}`
        listing = await prisma.listing.create({ data: { ...listingData, slug } })
      } else {
        throw createErr
      }
    }

    await trackEvent('LISTING_CREATED', 'listing', listing.id, user.id)

    return { success: true, data: { id: listing.id, slug: listing.slug } }
  } catch (e) {
    console.error('[createListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al crear el listado. Intentá de nuevo.' }
  }
}

export async function updateListing(
  id: string,
  data: UpdateListingData
): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    if (!(await verifyOwnership(id, user.id))) {
      return { success: false, error: 'No tenés permiso para editar este listado.' }
    }

    const parsed = updateListingSchema.safeParse(data)
    if (!parsed.success) {
      return { success: false, error: 'Datos inválidos. Revisá el formulario.' }
    }

    const {
      url, title, type, description, techStack, tags, screenshotUrls,
      askingPrice, currency, monthlyTraffic, domainAge, monthlyRevenue,
    } = parsed.data

    await getPrisma().listing.update({
      where: { id },
      data: {
        ...(title !== undefined && { title }),
        ...(type !== undefined && { type }),
        ...(description !== undefined && { description }),
        ...(url !== undefined && { url: url || null }),
        ...(techStack !== undefined && { techStack }),
        ...(tags !== undefined && { tags }),
        ...(screenshotUrls !== undefined && { screenshotUrls }),
        ...(askingPrice !== undefined && { askingPrice }),
        ...(currency !== undefined && { currency }),
        ...(monthlyTraffic !== undefined && { monthlyTraffic: monthlyTraffic?.value ?? null }),
        ...(domainAge !== undefined && { domainAge: domainAge?.value ? Math.round(domainAge.value) : null }),
        ...(monthlyRevenue !== undefined && { monthlyRevenue: monthlyRevenue?.value ?? null }),
        updatedAt: new Date(),
      },
    })

    return { success: true }
  } catch (e) {
    console.error('[updateListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al guardar los cambios.' }
  }
}

export async function deleteListing(id: string): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    if (!(await verifyOwnership(id, user.id))) {
      return { success: false, error: 'No tenés permiso para eliminar este listado.' }
    }

    await getPrisma().listing.delete({ where: { id } })

    return { success: true }
  } catch (e) {
    console.error('[deleteListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al eliminar el listado.' }
  }
}

export async function publishListing(id: string): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    if (!(await verifyOwnership(id, user.id))) {
      return { success: false, error: 'No tenés permiso para publicar este listado.' }
    }

    const listing = await getPrisma().listing.findUnique({
      where: { id },
      select: { title: true, description: true, askingPrice: true, screenshotUrls: true },
    })

    if (!listing) return { success: false, error: 'Listado no encontrado.' }

    if (!listing.title || !listing.description || !listing.askingPrice) {
      return { success: false, error: 'El listado debe tener título, descripción y precio para enviarse a revisión.' }
    }

    if (!listing.screenshotUrls || listing.screenshotUrls.length === 0) {
      return { success: false, error: 'El listado debe tener al menos una imagen para enviarse a revisión.' }
    }

    await getPrisma().listing.update({
      where: { id },
      data: { status: 'PENDING_REVIEW', updatedAt: new Date() },
    })

    await trackEvent('LISTING_SUBMITTED', 'listing', id, user.id)

    return { success: true }
  } catch (e) {
    console.error('[publishListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al enviar el listado a revisión.' }
  }
}

export async function pauseListing(id: string): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    if (!(await verifyOwnership(id, user.id))) {
      return { success: false, error: 'No tenés permiso para pausar este listado.' }
    }

    const listing = await getPrisma().listing.findUnique({ where: { id }, select: { status: true } })
    if (!listing) return { success: false, error: 'Listado no encontrado.' }
    if (!['PUBLISHED', 'PENDING_REVIEW'].includes(listing.status)) {
      return { success: false, error: 'Solo se pueden pausar listados publicados o en revisión.' }
    }

    await getPrisma().listing.update({
      where: { id },
      data: { status: 'PAUSED', updatedAt: new Date() },
    })

    return { success: true }
  } catch (e) {
    console.error('[pauseListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al pausar el listado.' }
  }
}

export async function resumeListing(id: string): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    if (!(await verifyOwnership(id, user.id))) {
      return { success: false, error: 'No tenés permiso para reanudar este listado.' }
    }

    const listing = await getPrisma().listing.findUnique({ where: { id }, select: { status: true } })
    if (!listing) return { success: false, error: 'Listado no encontrado.' }
    if (listing.status !== 'PAUSED') {
      return { success: false, error: 'Solo se pueden reanudar listados pausados.' }
    }

    await getPrisma().listing.update({
      where: { id },
      data: { status: 'PUBLISHED', updatedAt: new Date() },
    })

    return { success: true }
  } catch (e) {
    console.error('[resumeListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al reanudar el listado.' }
  }
}

export async function markAsSold(id: string): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    if (!(await verifyOwnership(id, user.id))) {
      return { success: false, error: 'No tenés permiso para marcar este listado como vendido.' }
    }

    const listing = await getPrisma().listing.findUnique({ where: { id }, select: { status: true } })
    if (!listing) return { success: false, error: 'Listado no encontrado.' }
    if (listing.status === 'SOLD') {
      return { success: false, error: 'El listado ya está marcado como vendido.' }
    }

    await getPrisma().listing.update({
      where: { id },
      data: { status: 'SOLD', updatedAt: new Date() },
    })

    return { success: true }
  } catch (e) {
    console.error('[markAsSold]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al marcar el listado como vendido.' }
  }
}

// Usada para guardar borrador y redirigir
export async function saveDraftAndRedirect(data: CreateListingData) {
  const result = await createListing(data)
  if (result.success && result.data) {
    redirect('/mis-activos')
  }
  return result
}

// Usada para enviar a revisión desde el wizard
export async function submitListingForReview(data: CreateListingData) {
  const createResult = await createListing(data)
  if (!createResult.success || !createResult.data) return createResult

  const publishResult = await publishListing(createResult.data.id)
  if (!publishResult.success) return publishResult

  redirect('/mis-activos')
}
