# Product Review
**Fecha:** 2026-03-25
**Archivos revisados:**
- `prisma/schema.prisma`
- `prisma/seed.ts`

> Nota: Esta sesión es de infraestructura de datos (schema, seed, tenant helper). No hay UI que revisar.
> El foco está en si el modelo de datos soporta correctamente las necesidades del producto.

---

## Hallazgos

### ALTO

#### PROD-01 — Los límites de plan no se pueden hacer cumplir sin lógica adicional
**Archivo:** `prisma/schema.prisma:158-171` + `prisma/seed.ts:43-82`
**Descripción:** El schema define `Plan.maxUsers` y `Plan.maxMonthlyComprobantes`, pero no hay ningún mecanismo en la capa de datos que haga cumplir estos límites. Un tenant en plan MICRO (50 comprobantes/mes) puede crear ilimitadas facturas. Los límites son datos que no hacen nada por sí solos.
**Impacto en producto:** La propuesta de valor de los planes (diferenciación por límites) no se traduce en comportamiento real del sistema. Un usuario free puede usar ilimitado.
**Fix sugerido:** Implementar verificación de límites en los endpoints de creación de facturas/comprobantes. El schema ya tiene la info necesaria; falta la lógica de enforcement.

#### PROD-02 — Argentina AFIP: número de comprobante sin mecanismo de autoincremento
**Archivo:** `prisma/schema.prisma:373-374`
**Descripción:** `Invoice.number Int` y `Invoice.series String` existen en el schema con unique constraint `(organizationId, invoiceType, series, number)`. Pero no hay ninguna lógica de generación automática del próximo número. AFIP requiere numeración correlativa sin saltos. Un developer que use `create` sin manejar correctamente la secuencia generará facturas con números incorrectos o violará el constraint.
**Fix sugerido:** Documentar claramente que el número debe generarse con `SELECT MAX(number) + 1 FOR UPDATE` dentro de una transacción. Idealmente implementar una función o Server Action dedicada `createInvoice()` que encapsule esto.

---

### MEDIO

#### PROD-03 — Plan MICRO con precio 0 sin fecha de expiración ni límite de tiempo de trial
**Archivo:** `prisma/seed.ts:45-51`
**Descripción:** MICRO tiene `priceMonthly: "0.00"` sin ninguna restricción temporal. El modelo `Subscription` tiene `trialEndsAt` pero no hay mecanismo que fuerce a un MICRO a convertirse en pagante después del trial. Un comercio podría usar MICRO indefinidamente sin convertir.
**Fix sugerido:** Definir en el producto si MICRO es un plan gratuito permanente o un trial. Si es trial, implementar la expiración. Si es freemium permanente, documentarlo explícitamente.

#### PROD-04 — Relación Sale → Invoice opcional: ventas sin fiscal document posibles
**Archivo:** `prisma/schema.prisma:433`
**Descripción:** `Sale.invoiceId String?` es nullable. En Argentina, cada venta debería tener un comprobante fiscal asociado (mínimo ticket X). Permitir ventas sin `invoiceId` podría llevar a incumplimiento fiscal por diseño.
**Fix sugerido:** Decidir si en el dominio es válido tener una venta sin factura (ej: ventas en efectivo con ticket manual). Si no es válido, hacer `invoiceId` not-nullable o agregar validación de negocio.

#### PROD-05 — Precios en ARS hardcodeados sin campo de moneda
**Archivo:** `prisma/schema.prisma:164` + `prisma/seed.ts:49-80`
**Descripción:** `Plan.priceMonthly Decimal` sin campo de currency. En un SaaS argentino con inflación alta, los precios deben poder actualizarse sin modificar el schema. El campo `currency` no existe.
**Fix sugerido:** Agregar `currency String @default("ARS")` al modelo Plan para explicitarlo y permitir futura multi-currency.

---

### BAJO

#### PROD-06 — `Subscription.status = TRIAL` no requiere `trialEndsAt`
**Archivo:** `prisma/schema.prisma:185`
**Descripción:** Un tenant puede tener `status = TRIAL` con `trialEndsAt = null`, lo que crea un trial que nunca expira por omisión. No hay validación DB que requiera `trialEndsAt` cuando `status = TRIAL`.
**Fix sugerido:** Agregar una constraint de aplicación: si `status == TRIAL`, entonces `trialEndsAt` debe ser not-null. Documentarlo en el schema con un comentario.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 0        |
| ALTO      | 2        |
| MEDIO     | 3        |
| BAJO      | 1        |
| **Total** | **6**    |
