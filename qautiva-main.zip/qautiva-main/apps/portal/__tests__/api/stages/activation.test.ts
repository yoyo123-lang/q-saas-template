/**
 * Tests de integración: PATCH /api/stages/[stageId]/activation
 *
 * Verifica autenticación, permisos por rol, validación de body,
 * existencia del stage, y que la actualización se realiza correctamente.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// ── Mocks ──────────────────────────────────────────────────────────────────────

const { mockGetUser, mockStageFindUnique, mockStageUpdate, mockUserProfileFindUnique } =
  vi.hoisted(() => ({
    mockGetUser: vi.fn(),
    mockStageFindUnique: vi.fn(),
    mockStageUpdate: vi.fn(),
    mockUserProfileFindUnique: vi.fn(),
  }))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    stage: {
      findUnique: mockStageFindUnique,
      update: mockStageUpdate,
    },
    userProfile: {
      findUnique: mockUserProfileFindUnique,
    },
  },
}))

// ── Imports ────────────────────────────────────────────────────────────────────

import { PATCH } from '@/app/api/stages/[stageId]/activation/route'

// ── Constantes ─────────────────────────────────────────────────────────────────

const STAGE_ID = 'stage-00000000-0000-4000-a000-000000000001'
const USER_ID = 'user-auth-id'
const TEAM_ID = 'team-1'

const mockUser = { id: USER_ID }

const mockStage = {
  id: STAGE_ID,
  teamId: TEAM_ID,
  activation: 'ACTIVE',
  status: 'PENDING',
}

const routeParams = { params: { stageId: STAGE_ID } }

function makeRequest(body: object) {
  return new NextRequest(
    `http://localhost:3001/api/stages/${STAGE_ID}/activation`,
    {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
  )
}

// ── Tests ──────────────────────────────────────────────────────────────────────

describe('PATCH /api/stages/[stageId]/activation', () => {
  beforeEach(() => {
    mockGetUser.mockReset()
    mockStageFindUnique.mockReset()
    mockStageUpdate.mockReset()
    mockUserProfileFindUnique.mockReset()
  })

  it('401 si no está autenticado', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: new Error('no session') })

    const res = await PATCH(makeRequest({ activation: 'SKIP' }), routeParams)

    expect(res.status).toBe(401)
    const body = await res.json()
    expect(body.error).toMatch(/autenticado/i)
  })

  it('403 si el usuario es MEMBER (sin permisos)', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue(mockStage)
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'MEMBER' }],
    })

    const res = await PATCH(makeRequest({ activation: 'SKIP' }), routeParams)

    expect(res.status).toBe(403)
    const body = await res.json()
    expect(body.error).toMatch(/permiso/i)
  })

  it('200 si es ADMIN con activation válida', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue(mockStage)
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'ADMIN' }],
    })
    mockStageUpdate.mockResolvedValue({
      id: STAGE_ID,
      activation: 'SKIP',
      status: 'COMPLETED',
    })

    const res = await PATCH(makeRequest({ activation: 'SKIP' }), routeParams)

    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.activation).toBe('SKIP')
    expect(body.status).toBe('COMPLETED')
  })

  it('200 si es OWNER con activation válida', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue(mockStage)
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'OWNER' }],
    })
    mockStageUpdate.mockResolvedValue({
      id: STAGE_ID,
      activation: 'PROVIDED_BY_CLIENT',
      status: 'COMPLETED',
    })

    const res = await PATCH(makeRequest({ activation: 'PROVIDED_BY_CLIENT' }), routeParams)

    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.activation).toBe('PROVIDED_BY_CLIENT')
  })

  it('400 si el body tiene activation inválida', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })

    const res = await PATCH(makeRequest({ activation: 'INVALID_VALUE' }), routeParams)

    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/activation/i)
  })

  it('400 si el body no tiene campo activation', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })

    const res = await PATCH(makeRequest({}), routeParams)

    expect(res.status).toBe(400)
  })

  it('404 si el stageId no existe', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue(null)

    const res = await PATCH(makeRequest({ activation: 'SKIP' }), routeParams)

    expect(res.status).toBe(404)
    const body = await res.json()
    expect(body.error).toMatch(/no encontrada/i)
  })

  it('404 si el stage existe pero no tiene teamId (no pertenece a ningún team)', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue({ ...mockStage, teamId: null })

    const res = await PATCH(makeRequest({ activation: 'SKIP' }), routeParams)

    expect(res.status).toBe(404)
  })

  it('actualiza el stage con el activation correcto (SKIP → status COMPLETED)', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue(mockStage)
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'ADMIN' }],
    })
    mockStageUpdate.mockResolvedValue({
      id: STAGE_ID,
      activation: 'SKIP',
      status: 'COMPLETED',
    })

    await PATCH(makeRequest({ activation: 'SKIP' }), routeParams)

    expect(mockStageUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: STAGE_ID },
        data: expect.objectContaining({
          activation: 'SKIP',
          status: 'COMPLETED',
        }),
      }),
    )
  })

  it('volver a ACTIVE desde SKIP/PROVIDED_BY_CLIENT → status PENDING', async () => {
    const stageCompletedBySkip = {
      ...mockStage,
      activation: 'SKIP',
      status: 'COMPLETED',
    }
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockStageFindUnique.mockResolvedValue(stageCompletedBySkip)
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'ADMIN' }],
    })
    mockStageUpdate.mockResolvedValue({
      id: STAGE_ID,
      activation: 'ACTIVE',
      status: 'PENDING',
    })

    const res = await PATCH(makeRequest({ activation: 'ACTIVE' }), routeParams)

    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.status).toBe('PENDING')
    expect(mockStageUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          activation: 'ACTIVE',
          status: 'PENDING',
        }),
      }),
    )
  })
})
