'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'

type SidebarContextValue = {
  open: boolean
  toggle: () => void
  close: () => void
}

const SidebarContext = createContext<SidebarContextValue>({
  open: false,
  toggle: () => {},
  close: () => {},
})

/**
 * Proveedor del estado global del sidebar mobile.
 * Debe envolver el layout que contenga tanto el TopBar como el MobileSidebarWrapper.
 * En desktop el estado no tiene efecto visual (la sidebar es siempre visible por CSS).
 */
export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)

  const toggle = useCallback(() => setOpen((v) => !v), [])
  const close = useCallback(() => setOpen(false), [])

  const value = useMemo(() => ({ open, toggle, close }), [open, toggle, close])

  return (
    <SidebarContext.Provider value={value}>
      {children}
    </SidebarContext.Provider>
  )
}

/**
 * Hook para acceder al estado del sidebar desde cualquier Client Component
 * dentro de un SidebarProvider. Si se usa fuera del Provider retorna los
 * valores default (open: false, noops).
 */
export const useSidebar = () => useContext(SidebarContext)
