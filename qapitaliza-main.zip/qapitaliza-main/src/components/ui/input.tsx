import { cn } from '@/lib/utils/cn'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  helper?: string
  error?: string
  prefix?: string
  suffix?: React.ReactNode
  counter?: { current: number; max: number }
}

export function Input({
  label,
  helper,
  error,
  prefix,
  suffix,
  counter,
  id,
  className,
  ...props
}: InputProps) {
  const inputId = id ?? label?.toLowerCase().replace(/\s+/g, '-')
  const errorId = inputId ? `${inputId}-error` : undefined
  const helperId = inputId ? `${inputId}-helper` : undefined

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label
          htmlFor={inputId}
          className="text-sm font-medium text-slate-400 block"
        >
          {label}
        </label>
      )}

      <div className="relative flex items-center">
        {prefix && (
          <span className="absolute left-3 text-sm text-slate-500 pointer-events-none select-none">
            {prefix}
          </span>
        )}
        <input
          id={inputId}
          aria-invalid={!!error}
          aria-describedby={error ? errorId : helper ? helperId : undefined}
          className={cn(
            'w-full bg-slate-800 border border-slate-800 rounded-lg px-3 py-2.5',
            'text-sm text-slate-50 placeholder:text-slate-500',
            'focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent',
            'transition-all duration-150',
            error && 'border-red-500 focus:ring-red-500',
            props.disabled && 'opacity-50 cursor-not-allowed bg-slate-900',
            prefix && 'pl-10',
            suffix && 'pr-10',
            className
          )}
          {...props}
        />
        {suffix && (
          <span className="absolute right-3 text-slate-400 flex items-center">
            {suffix}
          </span>
        )}
      </div>

      {counter && (
        <span className="text-xs text-slate-500 text-right">
          {counter.current} / {counter.max} caracteres
        </span>
      )}
      {error ? (
        <span id={errorId} className="text-xs text-red-400">
          {error}
        </span>
      ) : helper ? (
        <span id={helperId} className="text-xs text-slate-500">
          {helper}
        </span>
      ) : null}
    </div>
  )
}
