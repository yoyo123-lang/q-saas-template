import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { MediumStatus } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { MediumRow, type MediumRowData } from './components/MediumRow'
import { formatARS } from '@/lib/format'

export const metadata: Metadata = { title: 'Mis Medios — Qautiva' }

export default async function MisMediosPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login?next=/mis-medios')

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true },
  })
  if (!profile) redirect('/login')

  // Inicio del mes actual para calcular ingresos del mes
  const startOfMonth = new Date()
  startOfMonth.setDate(1)
  startOfMonth.setHours(0, 0, 0, 0)

  const media = await prisma.medium.findMany({
    where: { userId: profile.id, deletedAt: null },
    select: {
      id: true,
      name: true,
      platform: true,
      status: true,
      verified: true,
      followersCount: true,
      monthlyVisits: true,
      completedOrders: true,
      avgRating: true,
      _count: { select: { products: { where: { active: true } } } },
      orders: {
        where: { status: 'COMPLETED', completedAt: { gte: startOfMonth } },
        select: { editorPayout: true },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  // Armar los datos para MediumRow
  type RawOrder = { editorPayout: { toNumber: () => number } }
  type RawMedium = (typeof media)[number]
  const rows: MediumRowData[] = media.map((m: RawMedium) => ({
    id: m.id,
    name: m.name,
    platform: m.platform,
    status: m.status,
    verified: m.verified,
    followersCount: m.followersCount,
    monthlyVisits: m.monthlyVisits,
    completedOrders: m.completedOrders,
    avgRating: m.avgRating,
    activeProducts: m._count.products,
    monthlyEarnings: (m.orders as RawOrder[]).reduce((acc: number, o: RawOrder) => acc + o.editorPayout.toNumber(), 0),
  }))

  // Resumen global
  const totalActive = rows.filter((r) => r.status === MediumStatus.ACTIVE).length
  const totalEarningsMonth = rows.reduce((acc, r) => acc + r.monthlyEarnings, 0)
  const totalCompletedMonth = media.reduce((acc: number, m: RawMedium) => acc + m.orders.length, 0)

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Encabezado */}
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-white">Mis Medios</h1>
          <p className="text-[#94A3B8] text-sm mt-1">Gestioná tus medios y productos</p>
        </div>
        <Link
          href="/mis-medios/nuevo"
          className="bg-[#1E3A5F] hover:bg-[#1E4D8C] text-[#60A5FA] text-sm font-medium px-4 py-2 rounded-lg transition-colors whitespace-nowrap"
        >
          + Agregar medio
        </Link>
      </div>

      {/* Resumen del mes */}
      {rows.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 text-center">
            <p className="text-white text-2xl font-bold">{totalActive}</p>
            <p className="text-[#64748B] text-xs mt-1">Medios activos</p>
          </div>
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 text-center">
            <p className="text-white text-2xl font-bold">{totalCompletedMonth}</p>
            <p className="text-[#64748B] text-xs mt-1">Entregas este mes</p>
          </div>
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 text-center">
            <p className="text-white text-2xl font-bold">{formatARS(totalEarningsMonth)}</p>
            <p className="text-[#64748B] text-xs mt-1">Ingresos este mes</p>
          </div>
        </div>
      )}

      {/* Lista de medios */}
      {rows.length === 0 ? (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-10 text-center">
          <p className="text-white font-semibold mb-2">Aún no tenés medios</p>
          <p className="text-[#94A3B8] text-sm mb-4">
            Agregá tu primer medio para empezar a recibir pedidos de anunciantes.
          </p>
          <Link
            href="/mis-medios/nuevo"
            className="inline-block bg-[#1E3A5F] hover:bg-[#1E4D8C] text-[#60A5FA] text-sm font-medium px-5 py-2 rounded-lg transition-colors"
          >
            Agregar mi primer medio
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {rows.map((medium) => (
            <MediumRow key={medium.id} medium={medium} />
          ))}
        </div>
      )}
    </div>
  )
}
