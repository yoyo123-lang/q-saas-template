'use client'

import { useRef, useState, useTransition } from 'react'
import { createAdminNote } from '@/lib/actions'

interface AgregarNotaFormProps {
  orgId: string
}

export function AgregarNotaForm({ orgId }: AgregarNotaFormProps) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)

  function handleSubmit(formData: FormData) {
    setError(null)
    setSuccess(false)
    startTransition(async () => {
      try {
        await createAdminNote(formData)
        formRef.current?.reset()
        setSuccess(true)
        setTimeout(() => setSuccess(false), 3000)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error al guardar la nota')
      }
    })
  }

  return (
    <form ref={formRef} action={handleSubmit} className="flex flex-col gap-2">
      <input type="hidden" name="orgId" value={orgId} />

      <label className="text-[#94A3B8] text-xs font-medium">Agregar nota interna</label>
      <textarea
        name="content"
        rows={3}
        placeholder="Nota interna (no visible para el cliente)..."
        maxLength={5000}
        className="w-full px-3 py-2 rounded-lg bg-[#0F172A] border border-[#1E293B] text-white text-sm placeholder-[#475569] resize-none focus:outline-none focus:border-[#3B82F6] transition-colors"
        required
        disabled={isPending}
      />

      {error && (
        <p className="text-[#F87171] text-xs">{error}</p>
      )}
      {success && (
        <p className="text-[#34D399] text-xs">Nota guardada.</p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="self-end px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm font-medium hover:bg-[#334155] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {isPending ? 'Guardando...' : 'Guardar nota'}
      </button>
    </form>
  )
}
