import { cookies } from 'next/headers'
import { unstable_cache } from 'next/cache'
import { notFound } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { ProjectSidebar } from '@/components/ProjectSidebar'
import { TopBar } from '@/components/TopBar'
import { SidebarProvider } from '@/components/SidebarContext'
import { MobileSidebarWrapper } from '@/components/MobileSidebarWrapper'
import { INTERVIEW_ACTIONABLE_STATUSES } from '@/app/_lib/interview/constants'

/** Cachea si el usuario tiene medios en el marketplace (para visibilidad de "Mis Ventas") */
const getUserHasMedios = unstable_cache(
  async (authUserId: string) => {
    const profile = await prisma.userProfile.findUnique({
      where: { authUserId },
      select: { _count: { select: { media: { where: { deletedAt: null } } } } },
    })
    return (profile?._count.media ?? 0) > 0
  },
  ['user-has-medios'],
  { revalidate: 60 },
)

/**
 * Cachea el stageId al que apuntar para el link de entrevista en sidebar.
 * Prioriza una sesión activa (IN_PROGRESS/PAUSED). Si no existe ninguna sesión,
 * devuelve la primera etapa no completada (la entrevista se creará on-demand).
 */
const getInterviewStageId = unstable_cache(
  async (projectId: string) => {
    // Primero: buscar sesión activa existente
    const activeSession = await prisma.interviewSession.findFirst({
      where: {
        projectId,
        status: { in: INTERVIEW_ACTIONABLE_STATUSES },
      },
      orderBy: { createdAt: 'asc' },
      select: { stageId: true },
    })
    if (activeSession) return activeSession.stageId

    // Sin sesión: buscar primera etapa no completada (para "Comenzar entrevista")
    const activeStage = await prisma.stage.findFirst({
      where: { projectId, status: { not: 'COMPLETED' } },
      orderBy: { number: 'asc' },
      select: { id: true },
    })
    return activeStage?.id ?? null
  },
  ['project-interview-stage'],
  { revalidate: 60 },
)

/** Cachea si el proyecto tiene una etapa CAMPAIGNS (para mostrar el link de Creativos). */
const getHasCampaignsStage = unstable_cache(
  async (projectId: string) => {
    const stage = await prisma.stage.findFirst({
      where: { projectId, stageKey: 'CAMPAIGNS' },
      select: { id: true },
    })
    return !!stage
  },
  ['project-has-campaigns-stage'],
  { revalidate: 60 },
)

/** Cachea la verificación de ownership del proyecto por userId+projectId durante 60s */
const getProjectForUser = unstable_cache(
  async (userId: string, projectId: string) => {
    const profile = await prisma.userProfile.findUnique({
      where: { authUserId: userId },
      include: {
        teamMemberships: { select: { teamId: true } },
      },
    })

    if (!profile || profile.teamMemberships.length === 0) return null

    const teamIds = profile.teamMemberships.map((m) => m.teamId)

    return prisma.project.findFirst({
      where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
      select: { id: true, name: true },
    })
  },
  ['project-layout'],
  { revalidate: 60 },
)

export default async function ProjectLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { id: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) notFound()

  let project: { id: string; name: string } | null | undefined
  try {
    project = await getProjectForUser(user.id, params.id)
  } catch (err) {
    console.error('[project-layout] Error loading project', {
      projectId: params.id,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    notFound()
  }

  if (!project) notFound()

  const [hasMedios, interviewStageId, hasCampaigns] = await Promise.all([
    getUserHasMedios(user.id),
    getInterviewStageId(project.id).catch((err) => {
      console.error('[project-layout] Error loading active interview', {
        projectId: project.id,
        error: err instanceof Error ? err.message : String(err),
      })
      return null
    }),
    getHasCampaignsStage(project.id).catch(() => false),
  ])

  const interviewHref = interviewStageId
    ? `/proyectos/${project.id}/etapas/${interviewStageId}/interview`
    : null

  const creativosHref = hasCampaigns ? `/proyectos/${project.id}/creativos` : null

  return (
    <SidebarProvider>
      <div className="flex flex-col min-h-screen bg-[#0B0F1A]">
        <TopBar hasMedios={hasMedios} />
        <MobileSidebarWrapper
          sidebar={
            <ProjectSidebar
              projectId={project.id}
              projectName={project.name}
              interviewHref={interviewHref}
              adsHref={`/proyectos/${project.id}/publicidad`}
              creativosHref={creativosHref}
            />
          }
        >
          {children}
        </MobileSidebarWrapper>
      </div>
    </SidebarProvider>
  )
}
