import { NextResponse, type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'
import { createOpenSrsClientFromEnv, OpenSrsProvider } from '@qautiva/domains'

// Permite procesar múltiples dominios con llamadas a OpenSRS (~15s c/u)
export const maxDuration = 60

const MAX_RETRIES = 5

/**
 * GET /api/cron/domains/process
 *
 * Procesa dominios en estado PENDING registrándolos en OpenSRS.
 * Invocado por Vercel Cron cada 1 minuto.
 *
 * Autenticación: CRON_SECRET en el header Authorization.
 */
export async function GET(request: NextRequest) {
  const reqId = crypto.randomUUID()

  const authHeader = request.headers.get('authorization')
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const regPassword = process.env.OPENSRS_DEFAULT_REG_PASSWORD
  if (!regPassword) {
    console.error('[cron/domains/process] Falta OPENSRS_DEFAULT_REG_PASSWORD', { reqId })
    return NextResponse.json({ error: 'Configuración incompleta' }, { status: 500 })
  }

  const pendingDomains = await prisma.domain.findMany({
    where: {
      status: 'PENDING',
      retryCount: { lt: MAX_RETRIES },
      deletedAt: null,
    },
    select: {
      id: true,
      teamId: true,
      domainName: true,
      tld: true,
      period: true,
      registrantInfo: true,
      retryCount: true,
    },
    orderBy: { createdAt: 'asc' },
    take: 5,
  })

  if (pendingDomains.length === 0) {
    return NextResponse.json({ ok: true, processed: 0, succeeded: 0, failed: 0 })
  }

  let client: ReturnType<typeof createOpenSrsClientFromEnv>
  try {
    client = createOpenSrsClientFromEnv()
  } catch (err) {
    console.error('[cron/domains/process] Failed to initialize OpenSRS client', {
      reqId,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al inicializar el cliente OpenSRS' }, { status: 500 })
  }
  const provider = new OpenSrsProvider(client)

  const results = await Promise.allSettled(
    pendingDomains.map((domain) => processDomain(provider, domain, regPassword, reqId)),
  )

  const succeeded = results.filter((r) => r.status === 'fulfilled' && r.value).length
  const failed = results.length - succeeded

  console.info('[cron/domains/process]', {
    reqId,
    total: pendingDomains.length,
    succeeded,
    failed,
  })

  return NextResponse.json({ ok: true, processed: pendingDomains.length, succeeded, failed })
}

type PendingDomain = {
  id: string
  teamId: string
  domainName: string
  tld: string
  period: number
  registrantInfo: unknown
  retryCount: number
}

async function processDomain(
  provider: OpenSrsProvider,
  domain: PendingDomain,
  regPassword: string,
  reqId: string,
): Promise<boolean> {
  // Marcar como REGISTERING para evitar procesamiento concurrente
  await prisma.domain.update({
    where: { id: domain.id, status: 'PENDING' },
    data: { status: 'REGISTERING' },
  })

  const info = (domain.registrantInfo ?? {}) as Record<string, unknown>
  const startedAt = Date.now()

  const result = await provider.register({
    domain: domain.domainName,
    period: domain.period,
    contact: {
      firstName: String(info.firstName ?? ''),
      lastName: String(info.lastName ?? ''),
      orgName: String(info.orgName ?? ''),
      address1: String(info.address1 ?? ''),
      city: String(info.city ?? ''),
      state: String(info.state ?? ''),
      postalCode: String(info.postalCode ?? ''),
      country: String(info.country ?? ''),
      phone: String(info.phone ?? ''),
      email: String(info.email ?? ''),
    },
    registrantIp: '0.0.0.0',
    regUsername: domain.domainName.replace(/\./g, '_'),
    regPassword,
  })

  const durationMs = Date.now() - startedAt

  if (result.success) {
    const { orderId } = result.data
    const expiresAt = computeExpiresAt(domain.period)

    await prisma.domain.update({
      where: { id: domain.id },
      data: {
        status: 'ACTIVE',
        opensrsOrderId: orderId,
        registeredAt: new Date(),
        expiresAt,
        lastError: null,
      },
    })

    await prisma.domainTransaction.create({
      data: {
        domainId: domain.id,
        teamId: domain.teamId,
        operation: 'REGISTER',
        status: 'SUCCESS',
        responseCode: 200,
        durationMs,
      },
    })

    console.info('[cron/domains/process] registered', { reqId, domainName: domain.domainName, orderId })
    return true
  }

  // Fallo: incrementar retryCount, marcar FAILED si se agotaron reintentos
  const newRetryCount = domain.retryCount + 1
  const newStatus = newRetryCount >= MAX_RETRIES ? 'FAILED' : 'PENDING'
  const errorMsg = result.error.message

  await prisma.domain.update({
    where: { id: domain.id },
    data: {
      status: newStatus,
      retryCount: newRetryCount,
      lastError: errorMsg.slice(0, 500),
    },
  })

  await prisma.domainTransaction.create({
    data: {
      domainId: domain.id,
      teamId: domain.teamId,
      operation: 'REGISTER',
      status: 'FAILED',
      errorMessage: errorMsg.slice(0, 500),
      durationMs,
    },
  })

  console.error('[cron/domains/process] registration failed', {
    reqId,
    domainName: domain.domainName,
    retryCount: newRetryCount,
    status: newStatus,
    error: errorMsg,
  })

  return false
}

function computeExpiresAt(periodYears: number): Date {
  const d = new Date()
  d.setFullYear(d.getFullYear() + periodYears)
  return d
}
