-- ============================================================
-- 011 — INQUIRY_CLOSED audit action + índices de performance
-- Rollback: 011_inquiry_closed_and_indexes_rollback.sql
-- ============================================================

-- Agregar INQUIRY_CLOSED al enum audit_action
-- Nota: ALTER TYPE ... ADD VALUE no es transaccional en Postgres; debe
-- correr fuera de un bloque BEGIN/COMMIT si se usa con migraciones.
ALTER TYPE audit_action ADD VALUE IF NOT EXISTS 'INQUIRY_CLOSED';

-- Índice en Inquiry.buyer_id para queries getInquiries (buyer side)
CREATE INDEX IF NOT EXISTS idx_inquiries_buyer_id
  ON public.inquiries (buyer_id);

-- Índice en Inquiry.updated_at para ORDER BY en el listado de consultas
CREATE INDEX IF NOT EXISTS idx_inquiries_updated_at
  ON public.inquiries (updated_at DESC);

-- Índice en Favorite.user_id para getFavoriteIds y getFavorites
CREATE INDEX IF NOT EXISTS idx_favorites_user_id
  ON public.favorites (user_id);
