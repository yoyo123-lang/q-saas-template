# Sesión 3: Productos y catálogo (backend + frontend)

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 3
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

CRUD completo de categorías y productos con variantes. Lista de productos con filtros y búsqueda.

## Pre-requisitos

Sesión 2 completada (multi-tenancy frontend, TenantProvider).

## Etapas

### Etapa 1: Validaciones Zod
- Schemas Zod para Product, Category, ProductVariant
- Validación de campos obligatorios, tipos, rangos

### Etapa 2: API routes CRUD
- Categorías: crear, listar, actualizar, eliminar (soft delete)
- Productos: crear con variantes anidadas, listar, actualizar, eliminar
- Todas las queries scoped por tenant con withTenant()

### Etapa 3: Listado de productos
- DataTable con columnas: nombre, categoría, precio, stock, estado
- Filtros por categoría y estado (activo/inactivo)
- Búsqueda por nombre y SKU
- Paginación server-side

### Etapa 4: Formulario de crear/editar producto
- Campos: nombre, descripción, categoría, SKU, precio base
- Sección de variantes dinámicas (agregar/quitar variantes con sus atributos)
- Validación client-side con Zod
- Preview antes de guardar

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
