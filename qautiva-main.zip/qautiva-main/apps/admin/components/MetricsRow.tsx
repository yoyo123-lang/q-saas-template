export interface MetricData {
  label: string
  value: string
  highlight?: 'warning' | 'default'
}

function MetricCard({ metric }: { metric: MetricData }) {
  const isWarning = metric.highlight === 'warning'

  return (
    <div
      className={`
        flex flex-col gap-0.5 px-4 py-3 rounded-lg border flex-1
        ${isWarning
          ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30'
          : 'bg-[#0F172A] border-[#1E293B]'
        }
      `}
    >
      <span className="text-[#94A3B8] text-xs">{metric.label}</span>
      <span
        className={`text-xl font-bold font-mono ${isWarning ? 'text-[#FBBF24]' : 'text-white'}`}
      >
        {metric.value}
      </span>
    </div>
  )
}

export function MetricsRow({ metrics }: { metrics: MetricData[] }) {
  return (
    <div className="flex flex-wrap gap-3">
      {metrics.map((metric) => (
        <MetricCard key={metric.label} metric={metric} />
      ))}
    </div>
  )
}
