import { prisma } from '@qautiva/db'
import type { AiProvider, UsageSource } from '@qautiva/db'

export interface RecordTokenUsageParams {
  teamId: string | null
  projectId: string
  provider: AiProvider
  model: string
  operation: string
  source: UsageSource
  tokensIn: number
  tokensOut: number
}

/**
 * Registra el consumo de tokens de una operación de IA en la tabla `TokenUsage`.
 *
 * Consulta `AiModelPricing` para calcular `costUsd`, y `FeeConfig` (vía `BillingAccount`)
 * para calcular `feeUsd` y `totalUsd`. Inserta el registro de forma atómica.
 *
 * @throws Error si no se encuentra pricing para el provider+model (CRITICAL).
 * @returns El `id` y `totalUsd` del `TokenUsage` creado, o `null` si `teamId` es nulo.
 */
export async function recordTokenUsage(params: RecordTokenUsageParams): Promise<{ id: string; totalUsd: number } | null> {
  const { teamId, projectId, provider, model, operation, source, tokensIn, tokensOut } = params

  if (!teamId) {
    console.warn('[billing] recordTokenUsage: teamId es null — no se registra consumo', { projectId, operation })
    return null
  }

  if (tokensIn < 0 || tokensOut < 0) {
    const msg = `CRITICAL: recordTokenUsage recibió tokens negativos — valor inválido. tokensIn=${tokensIn} tokensOut=${tokensOut}`
    console.error(msg, { teamId, projectId, operation })
    throw new Error(msg)
  }

  // ── 1. Pricing del modelo + BillingAccount (en paralelo) ────────────────────
  const [pricing, billingAccount] = await Promise.all([
    prisma.aiModelPricing.findUnique({
      where: { provider_model: { provider, model } },
      select: { inputPer1M: true, outputPer1M: true },
    }),
    prisma.billingAccount.findUnique({
      where: { teamId },
      select: { plan: true, preferredKeySource: true },
    }),
  ])

  if (!pricing) {
    const msg = `CRITICAL: No existe AiModelPricing para provider=${provider} model=${model}. Registro de consumo fallido.`
    console.error(msg, { teamId, projectId, operation })
    throw new Error(msg)
  }

  const inputPer1M = pricing.inputPer1M.toNumber()
  const outputPer1M = pricing.outputPer1M.toNumber()
  const costUsd = (tokensIn * inputPer1M + tokensOut * outputPer1M) / 1_000_000

  // ── 2. Fee del plan (depende de billingAccount) ──────────────────────────────
  let feePercentage = 0

  if (billingAccount) {
    const feeConfig = await prisma.feeConfig.findFirst({
      where: {
        plan: billingAccount.plan,
        keySource: billingAccount.preferredKeySource,
        isActive: true,
      },
      select: { feePercentage: true },
    })

    if (feeConfig) {
      feePercentage = feeConfig.feePercentage.toNumber()
    } else if (billingAccount.preferredKeySource !== 'BYOK') {
      // BYOK: el usuario paga su propia key, fee=0 es válido sin FeeConfig
      // Non-BYOK sin FeeConfig: error de configuración del admin
      const { plan, preferredKeySource: keySource } = billingAccount
      throw new Error(
        `CRITICAL: FeeConfig no encontrado para plan=${plan} keySource=${keySource}. Billing no configurado.`,
      )
    }
  }

  const feeUsd = costUsd * feePercentage / 100
  const totalUsd = costUsd + feeUsd

  // ── 3. Insertar TokenUsage ───────────────────────────────────────────────────
  const record = await prisma.tokenUsage.create({
    data: {
      teamId,
      projectId,
      provider,
      model,
      operation,
      source,
      tokensIn,
      tokensOut,
      costUsd,
      feePercentage,
      feeUsd,
      totalUsd,
    },
    select: { id: true },
  })

  return { id: record.id, totalUsd }
}
