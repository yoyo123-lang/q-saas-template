export const revalidate = 900

import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { HeroSearch } from '@/components/shared/hero-search'
import { CategoryPill } from '@/components/shared/category-pill'
import { HowItWorks } from '@/components/shared/how-it-works'
import { ListingCard } from '@/components/listings/listing-card'
import { getPrisma } from '@/lib/prisma'

const STATIC_CATEGORIES = [
  { icon: '🌐', label: 'Sitios Web', slug: 'website' },
  { icon: '🔗', label: 'Dominios', slug: 'domain' },
  { icon: '💻', label: 'SaaS / MVPs', slug: 'saas' },
  { icon: '🛒', label: 'E-commerce', slug: 'ecommerce' },
  { icon: '📁', label: 'Proyectos', slug: 'project' },
]

async function getFeaturedListings() {
  try {
    return await getPrisma().listing.findMany({
      where: {
        status: 'PUBLISHED',
        featuredUntil: { gt: new Date() },
      },
      include: { seller: true, metrics: true },
      take: 6,
      orderBy: { publishedAt: 'desc' },
    })
  } catch (e) {
    console.error('[LandingPage] Failed to fetch featured listings:', e)
    return []
  }
}

export default async function LandingPage() {
  const featuredListings = await getFeaturedListings()

  return (
    <>
      <Navbar />
      <main className="pt-16">
        {/* ─── Hero ──────────────────────────────────── */}
        <section className="relative mesh-gradient-amber min-h-[70vh] flex flex-col items-center justify-center px-6 py-24 text-center overflow-hidden">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-50 max-w-3xl mx-auto leading-tight">
            Comprá, vendé e invertí en{' '}
            <span className="text-amber-500">activos digitales</span>
          </h1>
          <p className="mt-4 text-lg text-slate-400 max-w-xl mx-auto">
            El marketplace más confiable para comprar y vender sitios web, dominios, SaaS y
            proyectos digitales en Latinoamérica.
          </p>

          <HeroSearch />

          <p className="mt-6 text-sm text-slate-500">
            El marketplace de activos digitales para Latinoamérica
          </p>
        </section>

        {/* ─── Categorías ────────────────────────────── */}
        <section className="max-w-7xl mx-auto px-6 py-16">
          <h2 className="text-2xl font-semibold text-slate-50 mb-8 text-center">
            Explorá por categoría
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {STATIC_CATEGORIES.map((cat) => (
              <CategoryPill
                key={cat.slug}
                icon={cat.icon}
                label={cat.label}
                slug={cat.slug}
              />
            ))}
          </div>
        </section>

        {/* ─── Activos destacados ─────────────────────── */}
        <section className="max-w-7xl mx-auto px-6 py-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-semibold text-slate-50">Activos destacados</h2>
            <Link
              href="/explorar"
              className="text-sm text-amber-500 hover:text-amber-400 transition-colors"
            >
              Ver todos →
            </Link>
          </div>

          {featuredListings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredListings.map((listing) => {
                const badges: ('verified' | 'featured' | 'premium')[] = ['featured']
                if (listing.verificationStatus === 'VERIFIED') badges.push('verified')

                const mrr = listing.monthlyRevenue
                  ? parseFloat(listing.monthlyRevenue.toString())
                  : undefined

                return (
                  <ListingCard
                    key={listing.id}
                    id={listing.id}
                    slug={listing.slug}
                    title={listing.title}
                    type={listing.type}
                    priceUsd={parseFloat(listing.askingPrice.toString())}
                    screenshot={listing.screenshotUrls[0]}
                    metrics={{
                      mrr,
                      monthlyVisits: listing.monthlyTraffic ?? undefined,
                    }}
                    techStack={listing.techStack}
                    badges={badges}
                  />
                )
              })}
            </div>
          ) : (
            <div className="bg-navy-900 border border-slate-800 rounded-xl p-12 text-center">
              <p className="text-slate-500">
                Todavía no hay activos destacados.{' '}
                <Link href="/explorar" className="text-amber-500 hover:underline">
                  Explorá el catálogo →
                </Link>
              </p>
            </div>
          )}
        </section>

        {/* ─── Cómo funciona ──────────────────────────── */}
        <section className="bg-navy-900/50 border-y border-slate-800 py-16">
          <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-2xl font-semibold text-slate-50 mb-3 text-center">
              Cómo funciona
            </h2>
            <p className="text-slate-400 text-center mb-12 max-w-lg mx-auto">
              Publicar y vender tu activo digital nunca fue tan simple.
            </p>
            <HowItWorks />
          </div>
        </section>

        {/* ─── CTA Final ──────────────────────────────── */}
        <section className="max-w-7xl mx-auto px-6 py-16">
          <div className="bg-gradient-to-r from-amber-500/5 to-transparent border border-amber-500/20 rounded-2xl p-10 text-center">
            <h2 className="text-2xl font-semibold text-slate-50 mb-3">
              ¿Tenés un activo digital para vender?
            </h2>
            <p className="text-slate-400 mb-8 max-w-md mx-auto">
              Publicá gratis en minutos y llegá a cientos de compradores calificados.
            </p>
            <Link
              href="/registro?rol=seller"
              className="inline-flex items-center justify-center px-8 py-3 rounded-lg bg-amber-500 text-navy-950 font-semibold text-base hover:bg-amber-400 transition-colors"
            >
              Publicá gratis
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
