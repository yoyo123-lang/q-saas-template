import Link from 'next/link'
import { MediumPlatform, MediumStatus } from '@qautiva/db'
import { PLATFORM_LABEL, PLATFORM_COLOR } from '../../marketplace/lib/constants'
import { formatARS, formatNumber } from '@/lib/format'

const STATUS_LABEL: Record<MediumStatus, string> = {
  PENDING_REVIEW: 'En revisión',
  ACTIVE: 'Activo',
  PAUSED: 'Pausado',
  REJECTED: 'Rechazado',
  SUSPENDED: 'Suspendido',
}

const STATUS_COLOR: Record<MediumStatus, string> = {
  PENDING_REVIEW: 'bg-[#2D2A0F] text-yellow-400',
  ACTIVE: 'bg-[#0F2E2A] text-[#34D399]',
  PAUSED: 'bg-[#1E293B] text-[#94A3B8]',
  REJECTED: 'bg-[#3B1414] text-red-400',
  SUSPENDED: 'bg-[#3B1414] text-red-400',
}

export type MediumRowData = {
  id: string
  name: string
  platform: MediumPlatform
  status: MediumStatus
  verified: boolean
  followersCount: number | null
  monthlyVisits: number | null
  completedOrders: number
  avgRating: number | null
  monthlyEarnings: number
  activeProducts: number
}

export function MediumRow({ medium }: { medium: MediumRowData }) {
  const platformLabel = PLATFORM_LABEL[medium.platform]
  const platformColor = PLATFORM_COLOR[medium.platform]
  const statusLabel = STATUS_LABEL[medium.status]
  const statusColor = STATUS_COLOR[medium.status]
  const isWebsite = medium.platform === MediumPlatform.WEBSITE
  const mainMetric = isWebsite ? medium.monthlyVisits : medium.followersCount

  return (
    <article className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        {/* Info principal */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${platformColor}`}>
              {platformLabel}
            </span>
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${statusColor}`}>
              {statusLabel}
            </span>
            {medium.verified && (
              <span className="text-xs bg-[#0F2E2A] text-[#34D399] px-2 py-0.5 rounded-full">
                ✓ Verificado
              </span>
            )}
          </div>
          <h3 className="text-white font-semibold">{medium.name}</h3>
          <p className="text-[#64748B] text-xs mt-1">
            {medium.activeProducts} {medium.activeProducts === 1 ? 'producto activo' : 'productos activos'}
          </p>
        </div>

        {/* Métricas */}
        <div className="flex gap-4 sm:gap-6 flex-wrap shrink-0">
          {mainMetric !== null && (
            <div className="text-center">
              <p className="text-white font-semibold text-sm">{formatNumber(mainMetric)}</p>
              <p className="text-[#64748B] text-xs">{isWebsite ? 'visitas/mes' : 'seguidores'}</p>
            </div>
          )}
          <div className="text-center">
            <p className="text-white font-semibold text-sm">{medium.completedOrders}</p>
            <p className="text-[#64748B] text-xs">entregas</p>
          </div>
          {medium.avgRating !== null && (
            <div className="text-center">
              <p className="text-white font-semibold text-sm">
                ★ {medium.avgRating.toFixed(1)}
              </p>
              <p className="text-[#64748B] text-xs">rating</p>
            </div>
          )}
          <div className="text-center">
            <p className="text-white font-semibold text-sm">{formatARS(medium.monthlyEarnings)}</p>
            <p className="text-[#64748B] text-xs">este mes</p>
          </div>
        </div>

        {/* Acciones */}
        <div className="flex gap-2 shrink-0">
          <Link
            href={`/marketplace/${medium.id}`}
            aria-label={`Ver ${medium.name} en el marketplace`}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] transition-colors"
          >
            Ver
          </Link>
          <Link
            href={`/mis-medios/${medium.id}/editar`}
            aria-label={`Editar ${medium.name}`}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[#1E3A5F] text-[#60A5FA] hover:bg-[#1E4D8C] transition-colors"
          >
            Editar
          </Link>
        </div>
      </div>

      {/* Mensaje de estado para rechazados */}
      {medium.status === MediumStatus.REJECTED && (
        <p className="text-red-400 text-xs mt-3 bg-[#3B1414] rounded-lg px-3 py-2">
          Este medio fue rechazado. Editalo y volvé a enviarlo a revisión.
        </p>
      )}
      {medium.status === MediumStatus.PENDING_REVIEW && (
        <p className="text-yellow-400 text-xs mt-3 bg-[#2D2A0F] rounded-lg px-3 py-2">
          En revisión por nuestro equipo. Normalmente tarda menos de 24 horas.
        </p>
      )}
    </article>
  )
}
