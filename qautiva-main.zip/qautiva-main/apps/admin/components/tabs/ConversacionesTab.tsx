import type { MessageSender, MessageChannel } from '@qautiva/db'
import type { OrgWithDetails, OrgMessage } from '@/lib/types'
import { IntervenirForm } from '@/components/forms/IntervenirForm'

// ── Constante de UI ────────────────────────────────────────────────────────────

/** Límite de mensajes visibles para evitar DOM excesivo. Los más recientes. */
const MAX_VISIBLE_MESSAGES = 100

// ── Badges ─────────────────────────────────────────────────────────────────────

const SENDER_STYLE: Record<MessageSender, { label: string; align: 'left' | 'right'; bubble: string; nameClass: string }> = {
  CLIENT: { label: 'Cliente', align: 'left',  bubble: 'bg-[#1E293B] text-white',                                    nameClass: 'text-[#94A3B8]' },
  AI:     { label: 'IA',      align: 'left',  bubble: 'bg-[#0F172A] border border-[#1E293B] text-[#94A3B8]',       nameClass: 'text-[#60A5FA]' },
  ADMIN:  { label: 'Admin',   align: 'right', bubble: 'bg-[#3B82F6] text-white',                                    nameClass: 'text-[#60A5FA]' },
}

const CHANNEL_BADGE: Record<MessageChannel, string> = {
  WEB:      'bg-[#1E293B] text-[#64748B]',
  WHATSAPP: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30',
  TELEGRAM: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30',
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function formatTime(date: Date): string {
  return new Date(date).toLocaleString('es-AR', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
}

// ── Sub-componentes ────────────────────────────────────────────────────────────

function MessageBubble({ message }: { message: OrgMessage }) {
  const style = SENDER_STYLE[message.sender]
  const isRight = style.align === 'right'

  return (
    <div className={`flex flex-col gap-1 ${isRight ? 'items-end' : 'items-start'}`}>
      <div className={`flex items-center gap-2 text-[11px] ${isRight ? 'flex-row-reverse' : ''}`}>
        <span className={style.nameClass}>{style.label}</span>
        <span className={`px-1.5 py-0.5 rounded text-[10px] ${CHANNEL_BADGE[message.channel]}`}>
          {message.channel.toLowerCase()}
        </span>
        {message.stageNumber && (
          <span className="text-[#475569]">Etapa {message.stageNumber}</span>
        )}
        <span className="text-[#475569]">{formatTime(message.createdAt)}</span>
      </div>
      <div
        className={`
          max-w-[75%] px-3 py-2 rounded-xl text-sm leading-relaxed whitespace-pre-wrap
          ${style.bubble}
        `}
      >
        {message.content}
      </div>
    </div>
  )
}

// ── Tab principal ──────────────────────────────────────────────────────────────

interface ConversacionesTabProps {
  messages: OrgWithDetails['messages']
  orgId: string
}

export function ConversacionesTab({ messages, orgId }: ConversacionesTabProps) {
  const total = messages.length
  const visible = messages.slice(-MAX_VISIBLE_MESSAGES)

  return (
    <div className="flex flex-col gap-4 flex-1 min-h-0">
      {/* Aviso si hay mensajes omitidos */}
      {total > MAX_VISIBLE_MESSAGES && (
        <p className="text-[#475569] text-xs text-center">
          Mostrando los últimos {MAX_VISIBLE_MESSAGES} mensajes de {total}.
        </p>
      )}

      {/* Timeline */}
      <div className="flex flex-col gap-3 overflow-y-auto flex-1 pb-2">
        {visible.length === 0 ? (
          <p className="text-[#64748B] text-sm">Sin mensajes aún.</p>
        ) : (
          visible.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))
        )}
      </div>

      {/* Formulario de intervención */}
      <IntervenirForm orgId={orgId} />
    </div>
  )
}
