import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getFavorites } from '@/lib/data/favorites'
import { FavoritesGrid } from './favorites-grid'

export const metadata = {
  title: 'Mis favoritos',
}

export default async function FavoritosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const favorites = await getFavorites(user.id)

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-50">Mis favoritos</h1>
        <p className="text-slate-400 mt-1 text-sm">
          Activos que guardaste para revisar más tarde.
        </p>
      </div>

      <FavoritesGrid initialFavorites={favorites} />
    </div>
  )
}
