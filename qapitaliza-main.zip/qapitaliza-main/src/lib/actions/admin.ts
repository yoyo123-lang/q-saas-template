'use server'

import { createClient } from '@/lib/supabase/server'
import { getPrisma } from '@/lib/prisma'
import { z } from 'zod'
import { trackEvent } from '@/lib/analytics/events'
import type { ActionResult } from '@/lib/actions/listings'
import { getPendingListingsCount } from '@/lib/data/admin'

// ─── Schemas ─────────────────────────────────────────────────

const rejectListingSchema = z.object({
  reason: z
    .string()
    .trim()
    .min(20, 'El motivo debe tener al menos 20 caracteres.')
    .max(500, 'El motivo no puede superar 500 caracteres.'),
})

const suspendUserSchema = z.object({
  reason: z.string().min(1, 'El motivo de suspensión es requerido.'),
})

const changeRoleSchema = z.object({
  role: z.enum(['BUYER', 'SELLER', 'ADMIN']),
})

// ─── Auth helper ─────────────────────────────────────────────

async function getAdminUser() {
  const supabase = await createClient()
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) return null

  const profile = await getPrisma().profile.findUnique({
    where: { id: user.id },
    select: { role: true },
  })

  if (profile?.role !== 'ADMIN') return null
  return user
}

// ─── Listing actions ─────────────────────────────────────────

/**
 * Approves a listing and publishes it.
 * Only admins can call this action.
 */
export async function approveListing(id: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    const listing = await getPrisma().listing.findUnique({
      where: { id },
      select: { status: true, sellerId: true },
    })
    if (!listing) return { success: false, error: 'Listado no encontrado.' }
    if (listing.status !== 'PENDING_REVIEW') {
      return { success: false, error: `El listado no está en revisión (estado actual: ${listing.status}).` }
    }

    await getPrisma().listing.update({
      where: { id },
      data: {
        status: 'PUBLISHED',
        publishedAt: new Date(),
        updatedAt: new Date(),
      },
    })

    await trackEvent('LISTING_APPROVED', 'listing', id, admin.id, {
      old_status: listing.status,
      new_status: 'PUBLISHED',
    })
    await trackEvent('LISTING_PUBLISHED', 'listing', id, admin.id, {
      seller_id: listing.sellerId,
    })

    return { success: true }
  } catch (e) {
    console.error('[approveListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al aprobar el listado.' }
  }
}

/**
 * Rejects a listing with a required reason (min 20 chars).
 * Only admins can call this action.
 */
export async function rejectListing(id: string, reason: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    const parsed = rejectListingSchema.safeParse({ reason })
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? 'Motivo inválido.' }
    }

    const listing = await getPrisma().listing.findUnique({
      where: { id },
      select: { status: true },
    })
    if (!listing) return { success: false, error: 'Listado no encontrado.' }

    await getPrisma().listing.update({
      where: { id },
      data: {
        status: 'REJECTED',
        rejectionReason: parsed.data.reason,
        updatedAt: new Date(),
      },
    })

    await trackEvent('LISTING_REJECTED', 'listing', id, admin.id, {
      reason: parsed.data.reason,
      old_status: listing.status,
      new_status: 'REJECTED',
    })

    return { success: true }
  } catch (e) {
    console.error('[rejectListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al rechazar el listado.' }
  }
}

/**
 * Marks a listing as featured.
 * Featured status expires in 30 days.
 */
export async function featureListing(id: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    const featuredUntil = new Date()
    featuredUntil.setDate(featuredUntil.getDate() + 30)

    await getPrisma().listing.update({
      where: { id },
      data: { featuredUntil, updatedAt: new Date() },
    })

    await trackEvent('LISTING_FEATURED', 'listing', id, admin.id)

    return { success: true }
  } catch (e) {
    console.error('[featureListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al destacar el listado.' }
  }
}

/**
 * Removes the featured status from a listing.
 */
export async function unfeatureListing(id: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    await getPrisma().listing.update({
      where: { id },
      data: { featuredUntil: null, updatedAt: new Date() },
    })

    await trackEvent('LISTING_UNFEATURED', 'listing', id, admin.id)

    return { success: true }
  } catch (e) {
    console.error('[unfeatureListing]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al quitar el destacado.' }
  }
}

/**
 * Marks a listing as sold by an admin.
 */
export async function markListingAsSold(id: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    const listing = await getPrisma().listing.findUnique({
      where: { id },
      select: { status: true },
    })
    if (!listing) return { success: false, error: 'Listado no encontrado.' }
    if (listing.status === 'SOLD') {
      return { success: false, error: 'El listado ya está marcado como vendido.' }
    }

    await getPrisma().listing.update({
      where: { id },
      data: { status: 'SOLD', updatedAt: new Date() },
    })

    await trackEvent('LISTING_SOLD', 'listing', id, admin.id, {
      old_status: listing.status,
    })

    return { success: true }
  } catch (e) {
    console.error('[markListingAsSold]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al marcar el listado como vendido.' }
  }
}

// ─── User actions ─────────────────────────────────────────────

/**
 * Suspends a user account. Stores the reason in audit log.
 */
export async function suspendUser(userId: string, reason: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    const parsed = suspendUserSchema.safeParse({ reason })
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? 'Motivo inválido.' }
    }

    if (admin.id === userId) {
      return { success: false, error: 'No podés suspender tu propia cuenta.' }
    }

    const profile = await getPrisma().profile.findUnique({
      where: { id: userId },
      select: { role: true },
    })
    if (!profile) return { success: false, error: 'Usuario no encontrado.' }

    await getPrisma().profile.update({
      where: { id: userId },
      data: { suspendedAt: new Date(), updatedAt: new Date() },
    })

    await trackEvent('USER_SUSPENDED', 'profile', userId, admin.id, {
      reason: parsed.data.reason,
      target_role: profile.role,
    })

    return { success: true }
  } catch (e) {
    console.error('[suspendUser]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al suspender el usuario.' }
  }
}

/**
 * Changes the role of a user.
 */
export async function changeUserRole(
  userId: string,
  role: 'BUYER' | 'SELLER' | 'ADMIN'
): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    const parsed = changeRoleSchema.safeParse({ role })
    if (!parsed.success) {
      return { success: false, error: 'Rol inválido.' }
    }

    const profile = await getPrisma().profile.findUnique({
      where: { id: userId },
      select: { role: true },
    })
    if (!profile) return { success: false, error: 'Usuario no encontrado.' }

    await getPrisma().profile.update({
      where: { id: userId },
      data: { role: parsed.data.role, updatedAt: new Date() },
    })

    await trackEvent('USER_ROLE_CHANGED', 'profile', userId, admin.id, {
      old_role: profile.role,
      new_role: parsed.data.role,
    })

    return { success: true }
  } catch (e) {
    console.error('[changeUserRole]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al cambiar el rol del usuario.' }
  }
}

/**
 * Soft-deletes a user. Data is retained for 90 days.
 */
export async function deleteUser(userId: string): Promise<ActionResult> {
  try {
    const admin = await getAdminUser()
    if (!admin) return { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }

    if (admin.id === userId) {
      return { success: false, error: 'No podés eliminar tu propia cuenta.' }
    }

    const profile = await getPrisma().profile.findUnique({
      where: { id: userId },
      select: { role: true, deletedAt: true },
    })
    if (!profile) return { success: false, error: 'Usuario no encontrado.' }
    if (profile.deletedAt) return { success: false, error: 'El usuario ya fue eliminado.' }

    // Pause all active listings before soft-deleting the user
    await getPrisma().listing.updateMany({
      where: {
        sellerId: userId,
        status: { in: ['PUBLISHED', 'PENDING_REVIEW'] },
      },
      data: { status: 'PAUSED', updatedAt: new Date() },
    })

    // Soft delete — data retained for 90 days
    await getPrisma().profile.update({
      where: { id: userId },
      data: { deletedAt: new Date(), updatedAt: new Date() },
    })

    await trackEvent('USER_DELETED', 'profile', userId, admin.id, {
      target_role: profile.role,
    })

    return { success: true }
  } catch (e) {
    console.error('[deleteUser]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al eliminar el usuario.' }
  }
}

// ─── Read actions (called from client components for polling) ─

/**
 * Returns the count of PENDING_REVIEW listings.
 * Used by the admin sidebar for badge polling.
 */
export async function getPendingCountAction(): Promise<number> {
  try {
    const admin = await getAdminUser()
    if (!admin) return 0
    return getPendingListingsCount()
  } catch {
    return 0
  }
}
