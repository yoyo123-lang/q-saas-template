'use client'

import type { BudgetAnswer } from './types'

export function BudgetRangeInput({
  value,
  onChange,
  disabled,
  placeholder,
}: {
  value: BudgetAnswer | null
  onChange: (v: unknown) => void
  disabled: boolean
  placeholder?: string
}) {
  const min = value?.min ?? null
  const max = value?.max ?? null

  function update(field: 'min' | 'max', raw: string) {
    const n = raw === '' ? null : Number(raw.replace(/\D/g, ''))
    const next: BudgetAnswer = { min, max, [field]: n }
    if (next.min !== null && next.max !== null && next.min > next.max) return
    onChange(next)
  }

  return (
    <div>
      <div className="flex items-center gap-3">
        <div className="flex-1">
          <label className="text-[#64748B] text-xs mb-1 block">Mínimo</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#475569] text-sm" aria-hidden="true">$</span>
            <input
              type="number"
              min={0}
              value={min ?? ''}
              onChange={(e) => update('min', e.target.value)}
              disabled={disabled}
              placeholder={placeholder ?? '0'}
              className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg pl-7 pr-3 py-3 text-white placeholder-[#334155] text-base outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>
        </div>

        <span className="text-[#475569] text-sm mt-5 flex-shrink-0">—</span>

        <div className="flex-1">
          <label className="text-[#64748B] text-xs mb-1 block">Máximo</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#475569] text-sm" aria-hidden="true">$</span>
            <input
              type="number"
              min={0}
              value={max ?? ''}
              onChange={(e) => update('max', e.target.value)}
              disabled={disabled}
              placeholder="Sin límite"
              className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg pl-7 pr-3 py-3 text-white placeholder-[#334155] text-base outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>
        </div>
      </div>

      {min !== null && max !== null && max < min && (
        <p className="text-[#EF4444] text-xs mt-2">El máximo debe ser mayor al mínimo.</p>
      )}
    </div>
  )
}
