'use client'

/**
 * Tab "Entrevista" en la ficha de cliente.
 * Muestra, por etapa, el estado de la InterviewSession y
 * los Deliverables con visor expandible de `content`.
 */

import { useState } from 'react'
import type { InterviewStatus } from '@qautiva/db'
import type { OrgWithDetails, OrgInterviewSession } from '@/lib/types'
import { DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL } from '@/lib/badges'
import { RetrySessionButton } from '@/app/(protected)/sesiones/_components/RetrySessionButton'

// ── Badges de InterviewStatus ──────────────────────────────────────────────────

const SESSION_STATUS_BADGE: Record<InterviewStatus, { label: string; className: string }> = {
  NOT_STARTED:  { label: 'No iniciada',   className: 'bg-[#1E293B] text-[#64748B]' },
  IN_PROGRESS:  { label: 'En progreso',   className: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30' },
  IMPORTING:    { label: 'Importando',    className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  PROCESSING:   { label: 'Procesando',    className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  REGENERATING: { label: 'Regenerando',   className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  REVIEW:       { label: 'En revisión',   className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  COMPLETED:    { label: 'Completada',    className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  PAUSED:       { label: 'Pausada',       className: 'bg-[#64748B]/15 text-[#94A3B8] border border-[#64748B]/30' },
  STALE:        { label: 'Desactualizada',className: 'bg-[#64748B]/15 text-[#94A3B8] border border-[#64748B]/30' },
  ERROR:        { label: 'Error',         className: 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30' },
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function fmtDate(d: Date | null): string {
  if (!d) return '—'
  return new Date(d).toLocaleString('es-AR', {
    day: '2-digit', month: '2-digit', year: '2-digit',
    hour: '2-digit', minute: '2-digit',
  })
}

const JSON_MAX_BYTES = 50_000

/** Renderiza el JSON truncado a 50KB para no bloquear el navegador con datos grandes. */
function JsonContent({ data }: { data: unknown }) {
  const full = JSON.stringify(data as Record<string, unknown>, null, 2)
  const truncated = full.length > JSON_MAX_BYTES
  const text = truncated ? full.slice(0, JSON_MAX_BYTES) + '\n\n… [truncado — ' + (full.length / 1024).toFixed(0) + 'KB total]' : full
  return (
    <pre className="mt-1.5 p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-xs font-mono overflow-x-auto max-h-72 overflow-y-auto leading-relaxed whitespace-pre-wrap break-words">
      {text}
    </pre>
  )
}

function JsonViewer({ label, data }: { label: string; data: unknown }) {
  const [open, setOpen] = useState(false)
  const isEmpty = data === null || data === undefined ||
    (typeof data === 'object' && Object.keys(data as object).length === 0)

  if (isEmpty) return null

  return (
    <div className="mt-2">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 text-xs text-[#8B5CF6] hover:text-[#A78BFA] transition-colors"
      >
        <span className="font-mono">{open ? '▾' : '▸'}</span>
        {label}
      </button>
      {open && (
        <JsonContent data={data} />
      )}
    </div>
  )
}

// ── Sección de sesión ──────────────────────────────────────────────────────────

function SessionSection({ session, orgId }: { session: OrgInterviewSession; orgId: string }) {
  const badge = SESSION_STATUS_BADGE[session.status]
  const progress = session.totalSteps > 0
    ? Math.round((session.currentStep / session.totalSteps) * 100)
    : 0

  const isActionable = session.status === 'PROCESSING' || session.status === 'ERROR'

  return (
    <div className="p-4 rounded-lg bg-[#0B0F1A] border border-[#1E293B] space-y-3">
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-semibold text-[#64748B] uppercase tracking-wide">Sesión de entrevista</p>
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
          {badge.label}
        </span>
      </div>

      {/* Banner PROCESSING stuck */}
      {session.status === 'PROCESSING' && (
        <div className="p-2.5 rounded-lg bg-[#F59E0B]/10 border border-[#F59E0B]/20">
          <p className="text-xs text-[#FBBF24]">
            Sesión en procesamiento
            {session.processingStartedAt && (() => {
              const minAgo = Math.floor((Date.now() - new Date(session.processingStartedAt).getTime()) / 60_000)
              return minAgo > 5 ? ` — demorado hace ${minAgo} min` : ''
            })()}
          </p>
        </div>
      )}

      {/* Progreso */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs text-[#64748B]">
          <span>Progreso</span>
          <span>{session.currentStep} / {session.totalSteps} preguntas</span>
        </div>
        <div className="h-1.5 bg-[#1E293B] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#8B5CF6] rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Timestamps */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-[#475569]">Iniciada: </span>
          <span className="text-[#94A3B8]">{fmtDate(session.startedAt)}</span>
        </div>
        <div>
          <span className="text-[#475569]">Completada: </span>
          <span className="text-[#94A3B8]">{fmtDate(session.completedAt)}</span>
        </div>
      </div>

      {/* Error — lastError truncado a 500 chars para no exponer info de infraestructura */}
      {session.status === 'ERROR' && session.lastError && (
        <div className="p-2.5 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/20">
          <p className="text-xs text-[#F87171] break-words">
            {session.lastError.length > 500
              ? session.lastError.slice(0, 500) + '…'
              : session.lastError}
          </p>
          {session.retryCount > 0 && (
            <p className="text-[10px] text-[#EF4444]/60 mt-0.5">Reintentos: {session.retryCount}</p>
          )}
        </div>
      )}

      {/* JSON viewers */}
      <JsonViewer label="Ver respuestas" data={session.answers} />
      <JsonViewer label="Ver historial de follow-ups" data={session.followUpHistory} />
      {Boolean(session.errorDetails) && (
        <JsonViewer label="Ver detalles del error" data={session.errorDetails} />
      )}

      {/* Retry button — solo para PROCESSING y ERROR */}
      {isActionable && (
        <div className="mt-3">
          <RetrySessionButton sessionId={session.id} orgId={orgId} />
        </div>
      )}
    </div>
  )
}

// ── Sección de entregables ─────────────────────────────────────────────────────

function DeliverablesSection({ deliverables }: { deliverables: OrgWithDetails['stages'][number]['deliverables'] }) {
  if (deliverables.length === 0) return null

  return (
    <div className="space-y-2">
      <p className="text-xs font-semibold text-[#64748B] uppercase tracking-wide">
        Entregables ({deliverables.length})
      </p>
      {deliverables.map((d) => {
        const badge = DELIVERABLE_STATUS_BADGE[d.status]
        return (
          <div key={d.id} className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B]">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-sm text-white leading-snug">{d.title}</p>
                <p className="text-xs text-[#475569] mt-0.5">
                  {DELIVERABLE_TYPE_LABEL[d.type]} · v{d.version}
                </p>
              </div>
              <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
                {badge.label}
              </span>
            </div>
            {d.feedback && (
              <p className="text-xs text-[#F87171] italic mt-1.5">&ldquo;{d.feedback}&rdquo;</p>
            )}
            <JsonViewer label="Ver contenido del entregable" data={d.content} />
          </div>
        )
      })}
    </div>
  )
}

// ── Componente principal ───────────────────────────────────────────────────────

interface EntrevistaTabProps {
  stages: OrgWithDetails['stages']
  orgId: string
}

export function EntrevistaTab({ stages, orgId }: EntrevistaTabProps) {
  const stagesWithData = stages.filter(
    (s) => s.interviewSession !== null || s.deliverables.length > 0,
  )

  if (stagesWithData.length === 0) {
    return (
      <p className="text-[#64748B] text-sm">
        Este cliente no tiene sesiones de entrevista ni entregables registrados aún.
      </p>
    )
  }

  return (
    <div className="flex flex-col gap-6 overflow-y-auto flex-1 pb-4">
      {stagesWithData.map((stage) => (
        <div key={stage.id} className="space-y-3">
          {/* Encabezado de etapa */}
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-[#1E293B] flex items-center justify-center text-[10px] font-bold text-[#64748B]">
              {stage.number}
            </span>
            <h3 className="text-sm font-semibold text-white">{stage.name}</h3>
          </div>

          {stage.interviewSession && (
            <SessionSection session={stage.interviewSession} orgId={orgId} />
          )}

          <DeliverablesSection deliverables={stage.deliverables} />
        </div>
      ))}
    </div>
  )
}
