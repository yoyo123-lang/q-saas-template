'use client'

import { useState } from 'react'

/**
 * Formulario de feedback guiado post-entrevista.
 * "Guiado" = múltiples preguntas estructuradas, no un solo textarea.
 *
 * El envío a la API se conecta en B4 (flujo de aprobación).
 * Mientras tanto, los datos se persisten en localStorage (clave: feedback:<sessionId>)
 * para no perderlos si el usuario cierra la pestaña antes de que B4 esté listo.
 */

type FeedbackData = {
  rating: number | null           // 1–5 estrellas
  useful: string[]                // qué partes fueron útiles (multi-select)
  wouldChange: string | null      // qué cambiarían
  comments: string                // texto libre opcional
}

type FeedbackStep = 'rating' | 'useful' | 'wouldChange' | 'comments' | 'done'

const USEFUL_OPTIONS = [
  { value: 'questions', label: 'Las preguntas fueron claras' },
  { value: 'guidance', label: 'Me ayudó a organizar mis ideas' },
  { value: 'speed', label: 'Fue rápido y directo' },
  { value: 'help', label: 'Los textos de ayuda fueron útiles' },
]

const WOULD_CHANGE_OPTIONS = [
  { value: 'nothing', label: 'Nada, estuvo perfecto' },
  { value: 'fewer_questions', label: 'Menos preguntas' },
  { value: 'clearer_questions', label: 'Preguntas más claras' },
  { value: 'more_examples', label: 'Más ejemplos o contexto' },
  { value: 'other', label: 'Algo más (lo detallo abajo)' },
]

type Props = {
  /**
   * ID de la sesión: se usa como clave de localStorage y eventualmente para
   * enviar a la API cuando B4 esté implementado.
   */
  sessionId?: string
}

export function FeedbackForm({ sessionId }: Props) {
  const [step, setStep] = useState<FeedbackStep>('rating')
  const [data, setData] = useState<FeedbackData>({
    rating: null,
    useful: [],
    wouldChange: null,
    comments: '',
  })
  const [skipped, setSkipped] = useState(false)

  function handleSkip() {
    setSkipped(true)
  }

  if (skipped) return null

  if (step === 'done') {
    return <ThankYouState />
  }

  return (
    <div className="mt-6 bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
      <div className="flex items-center justify-between mb-1">
        <p className="text-[#8B5CF6] text-xs font-medium uppercase tracking-wide">
          Feedback opcional
        </p>
        <button
          onClick={handleSkip}
          className="text-[#475569] text-xs hover:text-[#64748B] transition-colors"
        >
          Omitir
        </button>
      </div>
      <p className="text-[#64748B] text-xs mb-5">
        Tu opinión nos ayuda a mejorar la experiencia.
      </p>

      {step === 'rating' && (
        <RatingStep
          value={data.rating}
          onChange={(r) => setData((d) => ({ ...d, rating: r }))}
          onNext={() => setStep('useful')}
        />
      )}

      {step === 'useful' && (
        <UsefulStep
          value={data.useful}
          onChange={(u) => setData((d) => ({ ...d, useful: u }))}
          onBack={() => setStep('rating')}
          onNext={() => setStep('wouldChange')}
        />
      )}

      {step === 'wouldChange' && (
        <WouldChangeStep
          value={data.wouldChange}
          onChange={(w) => setData((d) => ({ ...d, wouldChange: w }))}
          onBack={() => setStep('useful')}
          onNext={() => setStep('comments')}
        />
      )}

      {step === 'comments' && (
        <CommentsStep
          value={data.comments}
          onChange={(c) => setData((d) => ({ ...d, comments: c }))}
          onBack={() => setStep('wouldChange')}
          onSubmit={async () => {
            const feedbackPayload = { ...data, submittedAt: new Date().toISOString() }

            // Persistir en localStorage como backup inmediato
            try {
              const key = sessionId ? `feedback:${sessionId}` : `feedback:${Date.now()}`
              localStorage.setItem(key, JSON.stringify(feedbackPayload))
            } catch {
              // localStorage puede fallar en modo incógnito — no es crítico
            }

            // Enviar a la API (best-effort: no bloquear al usuario si falla)
            if (sessionId) {
              fetch(`/api/interview/sessions/${sessionId}/feedback`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(feedbackPayload),
              }).catch((err) => {
                console.error('[FeedbackForm] envío de feedback falló (dato guardado en localStorage):', err)
              })
            }

            setStep('done')
          }}
        />
      )}

      {/* Indicador de progreso del form */}
      <FeedbackProgress current={step} />
    </div>
  )
}

// ── Paso 1: Rating ───────────────────────────────────────────────────────────

function RatingStep({
  value,
  onChange,
  onNext,
}: {
  value: number | null
  onChange: (r: number) => void
  onNext: () => void
}) {
  return (
    <div>
      <p className="text-white text-sm font-medium mb-4">
        ¿Cómo fue tu experiencia con la entrevista?
      </p>
      <div className="flex gap-2 mb-6" role="radiogroup" aria-label="Calificación">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            role="radio"
            aria-checked={value === star}
            aria-label={`${star} ${star === 1 ? 'estrella' : 'estrellas'}`}
            onClick={() => onChange(star)}
            className="p-1 transition-transform hover:scale-110"
          >
            <svg
              width="28"
              height="28"
              viewBox="0 0 24 24"
              fill={value !== null && star <= value ? '#F59E0B' : 'none'}
              stroke={value !== null && star <= value ? '#F59E0B' : '#334155'}
              strokeWidth="1.5"
              aria-hidden="true"
            >
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
          </button>
        ))}
      </div>
      <button
        onClick={onNext}
        disabled={value === null}
        className="px-4 py-2 text-sm font-medium text-white bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors"
      >
        Continuar →
      </button>
    </div>
  )
}

// ── Paso 2: ¿Qué fue útil? ───────────────────────────────────────────────────

function UsefulStep({
  value,
  onChange,
  onBack,
  onNext,
}: {
  value: string[]
  onChange: (v: string[]) => void
  onBack: () => void
  onNext: () => void
}) {
  function toggle(opt: string) {
    onChange(
      value.includes(opt) ? value.filter((v) => v !== opt) : [...value, opt],
    )
  }

  return (
    <div>
      <p className="text-white text-sm font-medium mb-4">
        ¿Qué partes te resultaron más útiles? (podés elegir varias)
      </p>
      <div className="flex flex-col gap-2 mb-6">
        {USEFUL_OPTIONS.map((opt) => {
          const selected = value.includes(opt.value)
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => toggle(opt.value)}
              className={`text-left px-3 py-2.5 rounded-lg border text-sm transition-all ${
                selected
                  ? 'bg-[#8B5CF6]/10 border-[#8B5CF6]/60 text-white'
                  : 'bg-[#0B0F1A] border-[#1E293B] text-[#94A3B8] hover:border-[#334155]'
              }`}
            >
              <span className="mr-2 text-[#8B5CF6]">{selected ? '✓' : '○'}</span>
              {opt.label}
            </button>
          )
        })}
      </div>
      <div className="flex gap-2">
        <button
          onClick={onBack}
          className="px-4 py-2 text-sm text-[#64748B] hover:text-[#94A3B8] transition-colors"
        >
          ← Atrás
        </button>
        {/* Cuando no hay selección el botón dice "Omitir" para no bloquear pero sí informar */}
        <button
          onClick={onNext}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            value.length > 0
              ? 'text-white bg-[#8B5CF6] hover:bg-[#7C3AED]'
              : 'text-[#64748B] hover:text-[#94A3B8]'
          }`}
        >
          {value.length > 0 ? 'Continuar →' : 'Omitir'}
        </button>
      </div>
    </div>
  )
}

// ── Paso 3: ¿Qué cambiarías? ─────────────────────────────────────────────────

function WouldChangeStep({
  value,
  onChange,
  onBack,
  onNext,
}: {
  value: string | null
  onChange: (v: string) => void
  onBack: () => void
  onNext: () => void
}) {
  return (
    <div>
      <p className="text-white text-sm font-medium mb-4">¿Qué mejorarías?</p>
      <div className="flex flex-col gap-2 mb-6" role="radiogroup">
        {WOULD_CHANGE_OPTIONS.map((opt) => {
          const selected = value === opt.value
          return (
            <button
              key={opt.value}
              type="button"
              role="radio"
              aria-checked={selected}
              onClick={() => onChange(opt.value)}
              className={`text-left px-3 py-2.5 rounded-lg border text-sm transition-all ${
                selected
                  ? 'bg-[#8B5CF6]/10 border-[#8B5CF6]/60 text-white'
                  : 'bg-[#0B0F1A] border-[#1E293B] text-[#94A3B8] hover:border-[#334155]'
              }`}
            >
              {opt.label}
            </button>
          )
        })}
      </div>
      <div className="flex gap-2">
        <button
          onClick={onBack}
          className="px-4 py-2 text-sm text-[#64748B] hover:text-[#94A3B8] transition-colors"
        >
          ← Atrás
        </button>
        <button
          onClick={onNext}
          disabled={value === null}
          className="px-4 py-2 text-sm font-medium text-white bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors"
        >
          Continuar →
        </button>
      </div>
    </div>
  )
}

// ── Paso 4: Comentarios ──────────────────────────────────────────────────────

function CommentsStep({
  value,
  onChange,
  onBack,
  onSubmit,
}: {
  value: string
  onChange: (v: string) => void
  onBack: () => void
  onSubmit: () => void
}) {
  return (
    <div>
      <p className="text-white text-sm font-medium mb-1">
        ¿Algo más que quieras contarnos?
      </p>
      <p className="text-[#64748B] text-xs mb-4">Opcional</p>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Escribí lo que quieras..."
        rows={3}
        maxLength={500}
        className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-4 py-3 text-white placeholder-[#334155] text-sm outline-none transition-colors resize-none mb-1"
      />
      {value.length > 0 && (
        <p className="text-right text-xs text-[#475569] mb-4">{value.length}/500</p>
      )}
      <div className="flex gap-2 mt-2">
        <button
          onClick={onBack}
          className="px-4 py-2 text-sm text-[#64748B] hover:text-[#94A3B8] transition-colors"
        >
          ← Atrás
        </button>
        <button
          onClick={onSubmit}
          className="px-4 py-2 text-sm font-medium text-white bg-[#10B981] hover:bg-[#059669] rounded-lg transition-colors"
        >
          Enviar feedback
        </button>
      </div>
    </div>
  )
}

// ── Estado final: gracias ────────────────────────────────────────────────────

function ThankYouState() {
  return (
    <div className="mt-6 bg-[#0F172A] border border-[#10B981]/20 rounded-xl p-5 flex items-center gap-4">
      <div className="w-8 h-8 rounded-full bg-[#10B981]/10 border border-[#10B981]/30 flex items-center justify-center flex-shrink-0">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="2.5" aria-hidden="true">
          <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <div>
        <p className="text-white text-sm font-medium">¡Gracias por tu feedback!</p>
        <p className="text-[#64748B] text-xs">Nos ayuda a mejorar la experiencia para todos.</p>
      </div>
    </div>
  )
}

// ── Indicador de progreso del form ───────────────────────────────────────────

const STEP_ORDER: FeedbackStep[] = ['rating', 'useful', 'wouldChange', 'comments']

function FeedbackProgress({ current }: { current: FeedbackStep }) {
  if (current === 'done') return null
  const currentIndex = STEP_ORDER.indexOf(current)

  return (
    <div className="flex gap-1.5 mt-5" aria-hidden="true">
      {STEP_ORDER.map((s, i) => (
        <div
          key={s}
          className={`h-1 rounded-full flex-1 transition-all duration-300 ${
            i < currentIndex
              ? 'bg-[#8B5CF6]/60'
              : i === currentIndex
                ? 'bg-[#8B5CF6]'
                : 'bg-[#1E293B]'
          }`}
        />
      ))}
    </div>
  )
}
