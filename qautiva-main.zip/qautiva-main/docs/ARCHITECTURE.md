# Arquitectura del Proyecto

> Fuente de verdad de arquitectura.
> Última actualización: 2026-03-22 (Board Integration — heartbeat + directivas)

---

## 1) Visión del proyecto

- **Proyecto en una oración:** Qautiva es la plataforma de marketing de Q Company que lanza negocios digitales llave en mano usando agentes de IA.
- **Problema que resuelve / para quién:** Emprendedores y negocios que necesitan presencia digital completa (marca, web, campañas, medios) pero no tienen tiempo, dinero ni conocimiento para contratarlo por cuenta propia.
- **Objetivos de negocio:**
  - Convertir visitantes anónimos en clientes pagos (landing)
  - Retener clientes con visibilidad del proceso y aprobación de entregables (portal)
  - Escalar operaciones sin crecer el equipo humano (admin + automatización IA)
- **Alcance:**
  - ✅ Landing pública (captación) con reCAPTCHA v3
  - ✅ Portal del cliente (seguimiento, aprobaciones, chat multicanal)
  - ✅ Backoffice admin (supervisión, configuración de agentes, bot Telegram)
  - ✅ Auth con Google OAuth via Supabase Auth
  - ✅ Bot de Telegram para interacción del cliente en el proceso
  - ✅ Entrevista conversacional IA (El Estratega, etapa 1) + generación de Brief Estratégico
  - ✅ Estudio de mercado (El Analista, etapa 2) + entrevista MARKET_STUDY
  - ✅ Brand Generator (El Director Creativo, etapa 3): conceptos de marca via OpenAI + logos via Gemini
  - ✅ Meta Ads Creative Generator: 6 piezas visuales (feed 1:1, feed 4:5, story 9:16) vía Gemini Flash Image, con wizard de generación independiente en el portal (`/proyectos/[id]/creativos`)
  - ✅ Integración con Q Company Board: heartbeat cada 5 min + endpoint receptor de directivas HMAC-SHA256
  - ❌ Integración real con Google Ads / Meta Ads (publicación de ads via API externa)
- **Estado actual:** Desarrollo inicial — MVP
- **Roadmap:** Ver `qautiva-specs-claude-code.md` sección 7

---

## 2) Arquitectura del sistema

### 2.1 Diagrama general

```text
                    ┌──────────────────────────────────────────────────┐
                    │              Monorepo qautiva/                    │
                    │                                                   │
 [Visitante] ────▶  │  apps/landing  (qautiva.ar)                     │
                    │    Next.js 14 SSG                                │
                    │    reCAPTCHA v3 en formularios                   │
                    │                                                   │
 [Cliente Web] ──▶  │  apps/portal   (app.qautiva.ar)                 │
                    │    Next.js 14 App Router                         │
                    │    Supabase Auth (Google OAuth + email)          │──▶ [Supabase]
                    │    reCAPTCHA v3 en login sin OAuth               │     PostgreSQL
                    │                                                   │     Auth + RLS
 [Cliente TG] ───▶  │  services/telegram-bot                          │     Realtime
                    │    grammY + Anthropic SDK                        │     Storage
                    │    Long-polling, proceso persistente             │
                    │                                                   │──▶ [Prisma ORM]
 [Admin] ────────▶  │  apps/admin    (admin.qautiva.ar)               │
                    │    Next.js 14 App Router                         │
                    │    Rol admin verificado en servidor + RLS        │
                    │                                                   │
                    │  packages/ui    (design system)                   │
                    │  packages/db    (Prisma schema + RLS policies)   │
                    └──────────────────────────────────────────────────┘
                                          │
                               ┌──────────┴──────────┐
                          [Vercel]              [Railway]
                       landing + portal    admin + telegram-bot

                    ┌──────────────────────────────────────────────────┐
                    │          Flujo de mensajes multicanal             │
                    │                                                   │
                    │  [Web ChatPanel] ──┐                              │
                    │                    ├──▶ Message (DB) ──▶ Realtime │
                    │  [Telegram Bot] ──┘     channel: WEB|TELEGRAM    │
                    │                                                   │
                    │  La IA responde por ambos canales simultáneamente │
                    │  El admin puede intervenir desde el backoffice    │
                    └──────────────────────────────────────────────────┘
```

### 2.2 Estilo arquitectónico

- **Tipo:** Monorepo con aplicaciones independientes (monolito modular por app)
- **Justificación:** Las 3 apps + bot comparten design system y schema de base de datos pero tienen dominios, audiencias y ciclos de deploy distintos. El monorepo permite reutilización sin acoplar los deployments.

### 2.3 Módulos / servicios

| Módulo | Responsabilidad | Datos que maneja |
|---|---|---|
| `apps/landing` | Captación de clientes, SEO, conversión, reCAPTCHA | Ninguno (SSG + formulario protegido) |
| `apps/portal` | Dashboard del cliente, aprobaciones, métricas, chat web, **marketplace** | Organizations, Stages, Deliverables, Messages, Metrics, Medium, Product, Order |
| `apps/admin` | Kanban, cola de revisión, config de agentes, gestión bot TG, **moderación de medios** | Todo el schema + AgentConfig + IndustryTemplate + TelegramUser/Config + marketplace_* |
| `services/telegram-bot` | Interacción del cliente via Telegram, LLM contextual | Messages, TelegramUser, TelegramConfig |
| `packages/ui` | Design system compartido | Ninguno |
| `packages/db` | Schema Prisma, RLS policies, cliente compartido, seeds | Todas las entidades |

### 2.4 Comunicación interna

| Origen | Destino | Mecanismo |
|---|---|---|
| `apps/portal` | Supabase | Supabase client (`@supabase/ssr`) + Prisma via API Routes |
| `apps/admin` | Supabase | Supabase client + Prisma via API Routes |
| `apps/landing` | Supabase | Solo formulario de contacto via API Route (protegido con reCAPTCHA) |
| `services/telegram-bot` | Supabase | Prisma client directo (proceso persistente, no serverless) |
| Portal ↔ Admin ↔ TG Bot | — | Supabase Realtime sobre tabla `Message` — todos los canales ven los nuevos mensajes en tiempo real |

### 2.4.1 Patrón de job asíncrono (Meta Ads Creatives)

Las operaciones de generación de imágenes que tardan >5s usan el patrón **POST→jobId→polling**:

```
POST /api/projects/[id]/generate-creatives
  → valida auth, rol, inflight, rate limit, billing
  → crea job en Map (job-store.ts) + fire-and-forget
  → devuelve { jobId }

GET /api/projects/[id]/generate-creatives/[jobId]  (polling cada 3-10s con backoff)
  → lee job de Map en memoria
  → si no está en memoria: fallback a DB (AD_VISUALS READY en últimos 10 min)
  → devuelve { status, result? }
```

**Limitación conocida**: El job store en memoria (`Map`) no persiste entre deploys ni instancias serverless. El fallback a DB mitiga esto para generaciones recientes. Para alta concurrencia, migrar a Redis KV (post-MVP). Ver ADR-0024.

### 2.5 Dependencias externas

| Servicio | Uso | Riesgo | Fallback |
|---|---|---|---|
| Supabase | PostgreSQL + Auth + Realtime + Storage | Crítico | Error con opción de reintentar |
| Vercel | Deploy landing + portal | Alto | Railway como fallback |
| Railway | Deploy admin + telegram-bot | Medio | Vercel (admin) / local (bot) |
| Google OAuth | Login de clientes | Alto | Login email/password de Supabase como alternativa |
| Google reCAPTCHA v3 | Protección de formularios | Medio | En dev se saltea; en prod fail-closed |
| Telegram API | Bot de interacción con clientes | Medio | Chat web del portal como alternativa |
| Anthropic API | LLM para respuestas del bot (TG) + entrevista conversacional + Brief Estratégico (portal) | Medio | Respuestas template para bot; entrevista bloqueada si Anthropic no disponible |
| Satoshi font | Tipografía | Bajo | `system-ui` en tokens |
| Catálogo de Templates (`templates.qautiva.ar`) | Fuente de templates importables desde el admin (`/templates/importar`). Variable: `TEMPLATES_CATALOG_URL`. Endpoints: `GET /api/templates`, `GET /api/templates/[slug]`. Verificar: `curl $TEMPLATES_CATALOG_URL/api/templates` debe devolver array JSON. | Medio | La página `/templates/importar` muestra error de conexión. La funcionalidad core del admin (crear/editar templates) no se ve afectada. |
| Google Stitch (Labs) | Generación de templates web por rubro con IA (backoffice admin) + personalización de templates en onboarding del cliente (portal). Package: `packages/stitch`. Variable: `STITCH_API_KEY`. Decisión: ADR-0022. | Alto (experimental) | Templates `source: MANUAL` sin cambios. Templates `source: STITCH` usan `htmlBase` con Handlebars almacenado en DB — el portal personaliza via Handlebars si Stitch falla (badge `usedStitchFallback: true` en Deliverable). |
| Gemini Flash Image (Nano Banana) | Generación de piezas gráficas para Meta Ads (feed 1:1, feed 4:5, story 9:16) desde el portal y desde el pipeline de sesión. Modelo configurable vía `TrialConfig.geminiImageModel`. Variable: `GOOGLE_GENERATIVE_AI_API_KEY`. Decisión: ADR-0024. | Alto | `generateAdVisuals()` usa `Promise.allSettled` — degradación parcial si algunas piezas fallan. Fallback a placeholder en `AdVisualsGallery`. |
| Q Company Board API | Heartbeat cada 5 min + recepción de directivas. Variables: `BOARD_URL`, `BOARD_API_KEY`, `BOARD_BU_ID`, `BOARD_WEBHOOK_SECRET`. Decisión: ADR-0025. | Bajo | Si el Board no está disponible, el cron falla silenciosamente (no afecta al usuario). Si `BOARD_URL` no está seteada, el cron devuelve 500. |

### 2.6 ADRs activos

- `docs/decisions/ADR-0001-sistema-documentacion-modular.md`
- `docs/decisions/ADR-0002-decisiones-arquitectonicas-v1.md`
- `docs/decisions/ADR-0003-selectedoptionid-en-feedback.md` — Opción elegida de marca en campo feedback
- `docs/decisions/ADR-0004-saas-self-service-byok.md` — Modelo de onboarding self-service con BYOK
- `docs/decisions/ADR-0005-server-actions-auth-pattern.md` — Auth en Server Actions con requireAdminSession
- `docs/decisions/ADR-0006-url-based-tabs-admin.md` — Tabs basados en URL para ficha de cliente
- `docs/decisions/ADR-0007-turborepo-y-optimizacion-builds-vercel.md` — Turborepo, ignoreCommand, desactivación de preview deployments
- `docs/decisions/ADR-0008-marketplace-data-model.md` — Prefijo tablas marketplace, rol editor implícito, senderId sin relación Prisma, partial index WEBSITE
- `docs/decisions/ADR-0009-separacion-onboarding-cuenta-proyecto.md` — Onboarding 2 pasos (cuenta + API key), wizard /proyectos/nuevo separado
- `docs/decisions/ADR-0010-user-settings-architecture.md` — Configuración de usuario: tabs URL-based, BYOK management, cambio de contraseña seguro
- `docs/decisions/ADR-0011-mobile-sidebar-responsive.md` — Sidebar responsive mobile: Context API + drawer vs alternativas
- `docs/decisions/ADR-0012-entrevista-conversacional-ia-estratega.md` — Entrevista conversacional IA: reconstrucción de historial vs almacenarlo en DB; tool_use para output estructurado
- `docs/decisions/ADR-0013-eliminacion-segura-proyectos.md` — Soft-delete vs hard-delete; botón hover con progressive disclosure; modal de confirmación vs window.confirm()
- `docs/decisions/ADR-0022-stitch-template-factory.md` — Integración híbrida de Google Stitch como fábrica de templates: Stitch genera `htmlBase`, Handlebars es el fallback, DB es la fuente de verdad
- `docs/decisions/ADR-0024-meta-ads-creative-generation.md` — Generación de piezas gráficas para Meta Ads con Gemini Flash Image: patrón async job (POST→jobId, GET polling), job store en memoria con fallback a DB, rate limit 10/proyecto/día, validación cruzada con Anthropic Haiku
- `docs/decisions/ADR-0025-board-heartbeat-integration.md` — Integración con Q Company Board: heartbeat cada 5 min via Vercel Cron + endpoint receptor de directivas con HMAC-SHA256

---

## 3) Stack tecnológico

| Componente | Tecnología | Versión | Motivo |
|---|---|---|---|
| Lenguaje | TypeScript | 5.x | Tipos, mantenibilidad, soporte Next.js |
| Framework | Next.js | 14+ (App Router) | SSR/SSG, API routes, rutas dinámicas |
| Estilos | Tailwind CSS | 3.x | Utilidades, dark mode nativo, consistencia |
| Gráficos | Recharts | 2.x | Dashboards de métricas, composable |
| Iconos | Lucide React | latest | Tree-shakeable, consistente con renders |
| Base de datos | PostgreSQL (Supabase) | 15.x | Relacional, RLS para multi-tenancy |
| ORM | Prisma | 5.x | Tipos generados, migraciones |
| Auth | Supabase Auth + `@supabase/ssr` | — | Google OAuth, JWT, RLS integrado |
| reCAPTCHA | Google reCAPTCHA v3 | — | Sin dependencias extra (fetch + next/script) |
| Telegram Bot | grammY | 1.x | TypeScript-first, 41K descargas/semana, activo |
| LLM SDK | @anthropic-ai/sdk | latest | Respuestas contextuales del bot |
| Testing | Vitest | 2.x | Rápido, soporte TS nativo, compatible con monorepo |
| Build orchestration | Turborepo | 2.x | Cache local/remoto, orquestación de builds en monorepo |
| Package manager | pnpm | 10.x | Workspaces, performance en monorepo |
| Deploy landing/portal | Vercel | — | SSR/SSG público, edge network |
| Deploy admin + bot | Railway | — | Procesos persistentes, mayor control |
| Fuente | Satoshi | — | Geométrica moderna |
| Fuente mono | JetBrains Mono | — | Datos, código |

### 3.1 Tecnologías prohibidas

- Light mode — dark mode es el único modo, no implementar toggle
- `any` en TypeScript — usar tipos estrictos siempre
- `SELECT *` en queries — pedir solo columnas necesarias
- `console.log` de debug en código commiteado
- `@supabase/auth-helpers-nextjs` — deprecado, usar `@supabase/ssr`
- `eval()`, `exec()`, `Function()` — nunca con datos del usuario
- NextAuth / next-auth — usamos Supabase Auth, no mezclar

---

## 4) Estructura de carpetas

```text
qautiva/
├── CLAUDE.md                          # Reglas para Claude Code
├── qautiva-specs-claude-code.md       # Especificaciones del producto
├── IMPLEMENTATION_PLAN.md             # Plan de implementación por etapas
├── SESSION_LOG.md                     # Log de sesiones de trabajo
├── docs/                              # Documentación del proyecto
│   ├── ARCHITECTURE.md                # Este archivo
│   ├── CONVENTIONS.md
│   ├── REGLAS_PREVENTIVAS.md
│   ├── TESTING.md
│   ├── SECURITY.md
│   ├── GIT-WORKFLOW.md
│   ├── DEBUGGING.md
│   ├── DEPLOYMENT.md
│   ├── decisions/                     # ADRs
│   └── ...
├── packages/
│   ├── ui/                            # Design system compartido
│   │   ├── components/
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── ProgressBar.tsx        # StageProgress
│   │   │   └── Sidebar.tsx
│   │   ├── tokens.ts                  # Colores, tipografía, spacing, radios
│   │   ├── tailwind.config.ts         # Config Tailwind base compartida
│   │   ├── index.ts                   # Re-exports
│   │   └── package.json
│   └── db/
│       ├── prisma/
│       │   ├── schema.prisma          # Schema completo incluyendo User + Telegram
│       │   ├── seed.ts                # Datos de ejemplo argentinos
│       │   └── rls.sql                # Políticas RLS para multi-tenancy
│       ├── client.ts                  # Prisma client singleton
│       ├── supabase.ts                # Supabase client helpers (server + browser)
│       └── package.json
├── apps/
│   ├── landing/                       # qautiva.ar
│   │   ├── app/
│   │   │   ├── layout.tsx             # Metadata SEO + fuentes
│   │   │   ├── page.tsx               # Todas las secciones en una página
│   │   │   ├── api/contact/route.ts   # Endpoint de contacto (reCAPTCHA + email)
│   │   │   └── globals.css
│   │   ├── components/
│   │   │   ├── Navbar.tsx
│   │   │   ├── Hero.tsx
│   │   │   ├── HowItWorks.tsx
│   │   │   ├── Deliverables.tsx
│   │   │   ├── WhyDifferent.tsx
│   │   │   ├── Pricing.tsx
│   │   │   ├── Ecosystem.tsx
│   │   │   ├── FinalCta.tsx
│   │   │   └── Footer.tsx
│   │   ├── next.config.ts
│   │   ├── tailwind.config.ts
│   │   └── package.json
│   ├── portal/                        # app.qautiva.ar
│   │   ├── app/
│   │   │   ├── layout.tsx             # Layout raíz
│   │   │   ├── page.tsx               # Redirect a /progreso
│   │   │   ├── login/page.tsx         # Login con OAuth + email (reCAPTCHA). force-dynamic
│   │   │   ├── auth/callback/route.ts # OAuth callback handler
│   │   │   ├── onboarding/            # Wizard self-service (4 pasos, público — no requiere auth previa)
│   │   │   │   ├── layout.tsx         # Progress bar de 4 pasos; lee x-pathname del middleware
│   │   │   │   ├── page.tsx           # Paso 1: Sign up (Google OAuth o email). reCAPTCHA v3
│   │   │   │   ├── negocio/page.tsx   # Paso 2: Datos del negocio (nombre, industria, ciudad)
│   │   │   │   ├── servicios/page.tsx # Paso 3: Selección de servicios (BRAND/WEBSITE/CAMPAIGNS/MEDIA)
│   │   │   │   ├── api-key/
│   │   │   │   │   ├── page.tsx       # Server Component: lee TrialConfig de DB
│   │   │   │   │   └── client.tsx     # Paso 4 (client): trial | hosted | BYOK con validación live
│   │   │   │   ├── completo/page.tsx  # Pantalla de éxito (fallback). Redirige a /proyectos/{pid}/progreso si pid en URL
│   │   │   │   └── _constants/
│   │   │   │       └── industries.ts  # Lista canónica de industrias (importada en client + server)
│   │   │   ├── proyectos/             # Dashboard self-service (Project/Team model)
│   │   │   │   ├── page.tsx           # Lista de proyectos. Grid de cards con DeleteProjectButton. Server Component
│   │   │   │   ├── _components/
│   │   │   │   │   └── DeleteProjectButton.tsx # 'use client'. Botón papelera + modal confirmación. Llama DELETE /api/projects/[id]. Ver ADR-0013
│   │   │   │   └── [id]/
│   │   │   │       ├── layout.tsx     # Server Component: envuelto en SidebarProvider + MobileSidebarWrapper. Verifica team membership vía unstable_cache (TTL 60s), pasa project a ProjectSidebar
│   │   │   │       ├── progreso/page.tsx # Stages + deliverables por projectId; AutoRefresh cada 30s si GENERATING
│   │   │   │       ├── etapas/[stageId]/interview/
│   │   │   │       │   ├── page.tsx      # Server Component: renderiza TemplateSelectionClient (WEBSITE sin template) o InterviewClient (resto)
│   │   │   │       │   ├── client.tsx    # InterviewClient: flujo de preguntas con flowDefinition, optimistic locking
│   │   │   │       │   └── _components/
│   │   │   │       │       ├── TemplateSelectionClient.tsx # Pantalla E2: selección de WebTemplate antes de iniciar entrevista WEBSITE
│   │   │   │       │       ├── QuestionCard.tsx            # Renderiza QuestionBlock según inputType
│   │   │   │       │       ├── NavigationButtons.tsx       # Botones atrás/siguiente/submit
│   │   │   │       │       ├── StageWelcomeScreen.tsx      # Pantalla de bienvenida al iniciar etapa
│   │   │   │       │       ├── ProcessingScreen.tsx        # Pantalla de espera PROCESSING con polling
│   │   │   │       │       ├── BriefView.tsx               # Vista del Brief Estratégico completado
│   │   │   │       │       └── FeedbackForm.tsx            # Formulario de feedback/revisión
│   │   │   │       └── entregables/
│   │   │   │           ├── page.tsx   # Índice: redirige al pending o al progreso
│   │   │   │           └── [did]/page.tsx # Detalle: BrandApproval | WebPreview | GenericDeliverable; generateMetadata con título
│   │   │   ├── (protected)/           # Grupo de rutas autenticadas (usuarios legados con org_id)
│   │   │   │   ├── layout.tsx         # Server Component: envuelto en SidebarProvider + MobileSidebarWrapper. Lee org de DB, pasa a ClientSidebar
│   │   │   │   ├── progreso/page.tsx  # Stages + deliverables con mapeo de status visual
│   │   │   │   ├── entregables/
│   │   │   │   │   ├── page.tsx       # Lista con tabs URL-based (filtro via searchParams)
│   │   │   │   │   └── [id]/page.tsx  # Detalle: BrandApproval | WebPreview | GenericDeliverable
│   │   │   │   ├── metricas/page.tsx  # Dashboard 30 días: cards + LineChart + campañas
│   │   │   │   ├── medios/page.tsx    # Assets de Supabase Storage (org-assets/{orgId}/)
│   │   │   │   └── configuracion/         # Configuración de usuario (tabs URL-based)
│   │   │   │       ├── page.tsx           # Server Component hub: detecta legacy/self-service, paralleliza Prisma queries, pasa props
│   │   │   │       └── _components/
│   │   │   │           ├── TabNav.tsx         # URL-based tab nav (cuenta/ia/plan). Filtra tabs para usuarios legacy
│   │   │   │           ├── AccountTab.tsx     # Edición de nombre (maxLength 150) + avatar URL + email (read-only) + sección org (legacy)
│   │   │   │           ├── ChangePasswordForm.tsx # Cambio de contraseña. Bloqueado para proveedores no-email (OAuth)
│   │   │   │           ├── AiTab.tsx          # Selector BYOK/Hosted + lista de API keys + formulario agregar key
│   │   │   │           ├── ApiKeyCard.tsx     # Card de API key: provider, hint, validez, lastUsed, botón revocar
│   │   │   │           ├── AddApiKeyForm.tsx  # Agregar API key: provider select + input + validación live ("Validando...")
│   │   │   │           ├── PlanTab.tsx        # Estado del plan: trial token bar, período pagado, balance
│   │   │   │           └── InfoRow.tsx        # Componente compartido label/valor para AccountTab y PlanTab
│   │   │   └── api/
│   │   │       ├── onboarding/route.ts                # POST steps 2/3/4: crea Project, Stages, ApiKey, BillingAccount
│   │   │       ├── projects/route.ts                  # POST wizard de creación (2 pasos). Requiere onboarding_complete
│   │   │       ├── projects/[id]/route.ts             # DELETE: soft-delete (deletedAt). Auth + UUID check + ownership check (teamIds). Ver ADR-0013
│   │   │       ├── deliverables/[id]/action/route.ts  # POST approve/reject. Ver convención feedback abajo
│   │   │       ├── messages/route.ts                  # POST crear mensaje (sender: CLIENT, channel: WEB)
│   │   │       └── settings/
│   │   │           ├── profile/route.ts               # PATCH: actualiza displayName y/o avatarUrl. Valida URL con protocolo http/https
│   │   │           ├── password/route.ts              # POST: cambia contraseña. Bloquea OAuth (provider !== 'email'). Verifica contraseña actual con signInWithPassword
│   │   │           ├── api-keys/route.ts              # GET: lista API keys del equipo (sin encryptedKey). POST: valida + encripta + crea ApiKey
│   │   │           ├── api-keys/[id]/route.ts         # DELETE: ownership check + guard contra borrar última key en modo BYOK
│   │   │           └── ai-mode/route.ts               # PATCH: cambia preferredKeySource. Bloquea switch a BYOK sin keys válidas
│   │   │       ├── templates/route.ts                 # GET: templates activos (max 100, orden usageCount). ?industry= filtra recommendedId via IndustryTemplate. Cache s-maxage=300
│   │   │       └── interview/
│   │   │           ├── sessions/route.ts              # POST: crea o retoma InterviewSession. Mergea AgentConfig + IndustryTemplate → flowDefinition. Para WEBSITE: inyecta preguntas tpl_* si hay selectedWebTemplateId (E3, idempotente)
│   │   │           └── sessions/[id]/
│   │   │               ├── route.ts                   # GET: retorna sesión con flowDefinition + answers (para rehydratación de cliente)
│   │   │               ├── advance/route.ts           # POST: navegación start/next/back/pause/submit. AL1: WHERE con condición de estado para proteger concurrencia (P2025 → 409). Submit valida preguntas requeridas
│   │   │               ├── answer/route.ts            # PATCH: guarda respuesta con merge parcial. Locking optimista en 2 niveles: soft check (version+key) + hard check atómico (WHERE answersVersion, P2025). Valida questionId en flowDefinition. Cap historial 100 entradas. Límite payload 50 KB
│   │   │               ├── template/route.ts          # PATCH: guarda selectedWebTemplateId. Transacción interactiva: decrementa usageCount del anterior + incrementa el nuevo, evita race conditions
│   │   │               ├── next-question/route.ts     # POST: guarda respuesta + llama Claude → próxima pregunta o { complete: true }. Límite 15 preguntas
│   │   │               ├── route.ts                   # GET: polling de estado (status, currentStep, etc.). Cache-Control: no-store
│   │   │               ├── process/route.ts           # POST: genera StrategicBrief. Optimistic lock 2 min. Fire-and-forget idempotente
│   │   │               ├── feedback/route.ts          # POST: guarda feedback post-entrevista en InterviewSession.feedback (JSON)
│   │   │               └── brief/route.ts             # GET: retorna Deliverable BRIEF si status === COMPLETED
│   │   │   ├── admin/
│   │   │   │   └── sessions/[id]/process/route.ts    # POST: reprocesamiento admin. Auth: Bearer JWT Supabase con role=ADMIN. Acepta PROCESSING/ERROR, resetea retryCount=0
│   │   │   └── cron/
│   │   │       └── recover-stuck-sessions/route.ts   # GET (Vercel Cron cada 5min): recupera sesiones PROCESSING > 5min. CRON_SECRET en header. Serial loop de 3 sesiones
│   │   ├── app/_lib/                  # Helpers de servidor (no importar en Client Components)
│   │   │   ├── get-team-for-user.ts   # getTeamForUser(authUserId): resuelve { teamId, teamRole } del primer team del usuario
│   │   │   ├── interview/             # Módulo de entrevista conversacional IA
│   │   │   │   ├── types.ts           # QuestionBlock, StrategicBrief, AiInterviewerResult, ColorSwatch, BrandConceptOption, BrandOption, BrandOptions
│   │   │   │   ├── ai-interviewer.ts  # getNextQuestion() + buildMessages() — tools ask_question/interview_complete
│   │   │   │   ├── brief-generator.ts # generateStrategicBrief() — tool generate_brief con schema completo. max_tokens: 2048
│   │   │   │   ├── brand-generator.ts # generateBrandOptions() — OpenAI (conceptos) + Gemini (logos PNG). Ver ADR-0017
│   │   │   │   ├── openai-client.ts   # Singleton OpenAI SDK. Valida OPENAI_API_KEY en init. timeout: 90s
│   │   │   │   ├── gemini-client.ts   # Singleton GoogleGenerativeAI SDK. Valida GOOGLE_GEMINI_API_KEY en init
│   │   │   │   ├── session-processor.ts # processSession() — lógica compartida de procesamiento: /process, /admin/process, cron
│   │   │   │   ├── get-user-team-ids.ts # getUserTeamIds(authUserId): helper de ownership compartido entre rutas
│   │   │   │   ├── merge-flow.ts      # mergeFlowDefinition(), hashFlowDefinition(), getAgentNumberForStage(), isAnswerEmpty()
│   │   │   │   ├── template-personalization.ts # buildTemplatePersonalizationQuestions(sections) + hasTemplatePersonalizationQuestions(flow) — preguntas tpl_* para etapa WEBSITE
│   │   │   │   ├── constants.ts       # Constantes del módulo
│   │   │   │   └── __tests__/         # Tests unitarios del módulo (Vitest)
│   │   │   │       └── brand-generator.test.ts # 21 tests: happy path, degradación 1/3, threshold 2/3, magic bytes, hex regex, JSON-serializable
│   │   │   ├── project-slug.ts        # buildSlug(): genera slug único para proyectos
│   │   │   ├── service-stages.ts      # SERVICE_STAGES, VALID_SERVICES, ServiceType
│   │   │   ├── validate-api-key.ts    # validateApiKey(provider, key): validación live con timeout 10s via Promise.race
│   │   │   └── organization-legacy.ts # createOrganizationLegacy(): bridge temporal para admin panel
│   │   ├── lib/
│   │   │   ├── supabase-server.ts     # Re-export de createServerClient desde @qautiva/db
│   │   │   ├── supabase-browser.ts    # createSupabaseBrowserClient (sin server-only, para ChatPanel)
│   │   │   ├── recaptcha.ts           # verifyRecaptcha helper
│   │   │   └── encryption.ts         # AES-256-GCM para API keys BYOK (encrypt/decrypt/keyHint)
│   │   ├── components/
│   │   │   ├── SidebarContext.tsx     # Context + SidebarProvider + useSidebar hook. Estado open/toggle/close para sidebar mobile. Ver ADR-0011
│   │   │   ├── MobileSidebarWrapper.tsx # Drawer mobile con overlay, cierre automático por navegación/resize/Escape, focus management. Desktop: no-op
│   │   │   ├── TopBar.tsx             # Header global: hamburger (mobile, usa useSidebar), logo responsive (h-8 md:h-12), nav marketplace, dropdown perfil
│   │   │   ├── ProjectSidebar.tsx     # Sidebar para /proyectos/[id]/* (self-service). Nav + logout + link Mis proyectos + chat
│   │   │   ├── AutoRefresh.tsx        # Client component: llama router.refresh() en intervalo. Usado en pantalla GENERATING
│   │   │   ├── ClientSidebar.tsx
│   │   │   ├── ActionCard.tsx
│   │   │   ├── DeliverableCard.tsx    # Tarjeta en lista de entregables, badge de estado
│   │   │   ├── BrandApproval.tsx      # Selección de opción de marca + approve/reject
│   │   │   ├── WebPreview.tsx         # Preview de web con toggle desktop/tablet/mobile
│   │   │   ├── MetricsCards.tsx       # 4 KPI cards con trend del mes anterior
│   │   │   ├── MetricsChart.tsx       # LineChart (Recharts) visitas + consultas. use client
│   │   │   ├── CampaignCard.tsx       # Card de campaña Google/Meta con spend real
│   │   │   └── ChatPanel.tsx          # Chat panel con Supabase Realtime. use client. maxLength 2000. Deduplicación por ID real
│   │   ├── middleware.ts              # Auth + redirect a onboarding si no completó wizard. Setea x-pathname. /api/health excluido
│   │   └── package.json

Convenciones del portal:

- **Server Components por defecto.** Solo se usa `'use client'` cuando hay interactividad
  (BrandApproval, WebPreview, MetricsChart, CampaignCard* [sin estado], ChatPanel)
- **Auth en cada page:** `createServerClient(cookies())` → `supabase.auth.getUser()` → verifica ownership
- **Doble check de ownership en Route Handlers:** JWT + query Prisma con teamId/userId — dos capas además de RLS
- **Soft-delete obligatorio:** Toda query de `Project` incluye `deletedAt: null` para evitar acceso a proyectos eliminados. La eliminación se hace via `DELETE /api/projects/[id]` (soft-delete, `deletedAt: new Date()`). Ver ADR-0013.
- **`_components/` colocados con la feature:** Componentes client específicos de una ruta van en `_components/` dentro del directorio de esa ruta (ej: `proyectos/_components/DeleteProjectButton.tsx`)
- **`getTeamForUser()` en route handlers de settings:** Helper compartido en `app/_lib/get-team-for-user.ts` que resuelve `{ teamId, teamRole }` a partir de `authUserId`. Evita duplicar la query de membresía en los 3 endpoints de settings (api-keys, ai-mode, etc.)
- **Configuración de usuario (`/configuracion`):** Ruta unificada que sirve tanto a usuarios legacy (`org_id`) como self-service (`onboarding_complete`). Legacy ve solo tab "Mi cuenta". Self-service ve tabs "Mi cuenta", "IA", y "Plan". La detección ocurre en el Server Component con `Boolean(user.app_metadata?.org_id)`.
- **`unstable_cache` en layouts:** `getProjectForUser()` en `proyectos/[id]/layout.tsx` cacheado con TTL 60s (key: `userId + projectId`) para evitar 2 queries Prisma por cada navegación entre sub-páginas
- **Middleware setea x-pathname:** Para que Server Components lean el path actual sin searchParams
- **Sidebar mobile responsive:** `SidebarContext` + `MobileSidebarWrapper` envuelven cada layout con sidebar. En mobile (<md): drawer deslizable con overlay. En desktop (≥md): sidebar siempre visible, sin diferencia de comportamiento respecto a versión anterior. Ver ADR-0011.
- **Entrevista conversacional IA (etapa 1):** El historial de mensajes de Anthropic se reconstruye en cada llamada desde `flowDefinition` + `answers` (sin almacenar `MessageParam[]` en DB). `buildMessages()` en `ai-interviewer.ts` es la única fuente de verdad de esta reconstrucción. Las respuestas del usuario se envuelven en `<respuesta_usuario>...</respuesta_usuario>` para prevenir prompt injection. Ver ADR-0012.
- **`getUserTeamIds()` en rutas de entrevista:** Helper compartido en `app/_lib/interview/get-user-team-ids.ts` que resuelve los teamIds del usuario autenticado. Equivalente a `getTeamForUser()` pero retorna `string[] | null` (todos los teams, no solo el primero).
- **Brief Estratégico generado via tool_use:** `generateStrategicBrief()` usa `tool_choice: { type: 'tool', name: 'generate_brief' }` con schema completo para obtener JSON validado. El Brief se persiste como `Deliverable(type: BRIEF, status: SENT_TO_CLIENT)` — plataforma self-service: el cliente lo aprueba directamente, sin gate de revisión admin obligatorio.
- **Flujo WEBSITE (E1→E2→E3):**
  - **E1** — `page.tsx` detecta `stageKey === 'WEBSITE' && !selectedWebTemplateId` y renderiza `TemplateSelectionClient`.
  - **E2** — `TemplateSelectionClient` llama `POST /api/interview/sessions` (crea sesión), `GET /api/templates?industry=...` (carga catálogo), y `PATCH /api/interview/sessions/[id]/template` (guarda selección). Tras guardar, `router.refresh()` recarga la página.
  - **E3** — Al volver a llamar `POST /api/interview/sessions` con el template ya seleccionado, el route handler detecta que la sesión no tiene preguntas `tpl_*` y las inyecta llamando `buildTemplatePersonalizationQuestions(template.sections)`. Idempotente: se detecta por presencia de ids que comienzan con `tpl_` en el flowDefinition. Solo aplica para sesiones `NOT_STARTED | IN_PROGRESS | PAUSED`.
  - **Prefijo `tpl_`**: todas las preguntas de personalización del template llevan ids `tpl_sections`, `tpl_tone`, `tpl_cta`, `tpl_slogan`, `tpl_hours`, `tpl_extra`. La IA (E4) leerá `answers.tpl_*` + `selectedWebTemplateId` → `WebTemplate.htmlBase/variables` para generar el sitio.
  - Ver ADR-0016.
- **Fire-and-forget `/process`:** El cliente llama a `/process` sin esperar respuesta después de que `/next-question` retorna `{ complete: true }`. La `ProcessingScreen` hace polling hasta que la sesión cambia a COMPLETED.
- **Cron de recovery:** Sesiones bloqueadas en PROCESSING > 5min son reintentadas por `GET /api/cron/recover-stuck-sessions`. Requiere `CRON_SECRET` en variables de entorno de Vercel. Procesa en serie (loop de 3 sesiones) para respetar `maxDuration: 60` y rate limits de Anthropic.
- **Admin reprocessing:** `POST /api/admin/sessions/[id]/process` acepta sesiones en PROCESSING o ERROR; resetea retryCount=0. Auth: Supabase JWT con `role=ADMIN` verificado server-side via `createServiceClient().auth.getUser(token)`. Ver ADR-0014.
- **`processSession()` como única fuente de verdad:** Toda la lógica de generación de brief + transición COMPLETED/ERROR vive en `app/_lib/interview/session-processor.ts`. Los tres callers (/process, /admin/process, cron) usan este helper — sin duplicación.
- **`website-generator.ts` — copy y HTML para etapa WEBSITE:** `generateWebsiteCopy()` llama al LLM con schema strict (OpenAI strict mode + Anthropic tool_use) y devuelve `WebsiteCopy`. `applyWebsiteCopy()` aplica el copy al `htmlBase` usando **Handlebars** (`{{variable}}` → valor; placeholders sin valor → `''`). ⚠️ **Node.js only** — Handlebars (CommonJS) no es compatible con Vercel Edge Runtime. `SECTION_KEYS` define las secciones soportadas; al agregar un template con sección nueva, actualizar esa constante en `website-generator.ts`.
- **Optimistic lock en `/process`:** Si `processingStartedAt` tiene < 2 minutos, retorna 202 sin llamar a Anthropic. Evita doble costo de tokens en reloads rápidos o tabs múltiples.
- **Feedback post-entrevista:** `POST /api/interview/sessions/[id]/feedback` guarda `FeedbackData` en `InterviewSession.feedback (Json?)`. `FeedbackForm` llama a la API con fire-and-forget + localStorage como backup.
- **Cache-Control en polling:** `GET /api/interview/sessions/[id]` incluye `Cache-Control: no-store` para prevenir que CDN o Next.js cachee respuestas durante el polling de ProcessingScreen.
- **Convención `feedback` en Deliverable:**
  - `REVISION_REQUESTED`: feedback es texto libre del cliente
  - `CLIENT_APPROVED` (BRAND_OPTIONS): feedback = `"selected:{optionId}"` — ver ADR-0003
  - `CLIENT_APPROVED` (otros): feedback = null
- **Brand Generator (etapa BRAND / Director Creativo):** Arquitectura multi-provider — OpenAI `gpt-4o` con `response_format: json_schema` genera 3 conceptos de marca (colores, tipografía, personalidad, prompt de logo); Gemini `gemini-2.0-flash-exp-image-generation` genera el logo PNG de cada concepto en paralelo (`Promise.allSettled`). Degradación graceful: 1 logo fallido → `logoUrl` omitido en esa opción; 2+ logos fallidos → throw. Logos persistidos en Supabase Storage bucket `brand-logos` vía `createServiceClient()`. Ver ADR-0017.
  - **`BrandConceptOption`** (interno): incluye `logoPrompt`. **`BrandOption`** (deliverable): incluye `logoUrl?`, sin `logoPrompt`.
  - **Magic bytes validation**: PNG (`89 50 4E 47`) y JPEG (`FF D8 FF`) antes de subir a Storage. Buffer > 2 MB rechazado.
  - **`_bucketEnsured` flag** module-level: evita `listBuckets()` en cada generación dentro del mismo proceso. Reset vía `_resetBucketCacheForTesting()` para tests.
  - **`responseModalities: ['IMAGE']`** no está tipado en `@google/generative-ai@0.24.1` → cast `as unknown as GenerationConfig`. Runtime funciona; fix tipado pending upgrade SDK.
│   └── admin/                         # admin.qautiva.ar
│       ├── app/
│       │   ├── layout.tsx             # Layout con sidebar admin (protegido + rol)
│       │   ├── page.tsx               # Kanban con filtros server-side (plan, industry, status, texto)
│       │   ├── clientes/
│       │   │   ├── page.tsx           # Tabla completa de clientes (activos + pausados). Búsqueda por nombre, cache 30s, take:500
│       │   │   └── [id]/
│       │   │       ├── page.tsx       # Ficha de cliente: query única, 4 tabs URL-based, hasAdminReview, tabCounts
│       │   │       ├── loading.tsx    # Skeleton con animate-pulse
│       │   │       └── error.tsx      # Error boundary con digest
│       │   ├── sesiones/
│       │   │   ├── page.tsx           # Lista global PROCESSING/ERROR: client, stage, lastError, tiempo stuck, retry inline. force-dynamic
│       │   │   └── _components/
│       │   │       └── RetrySessionButton.tsx  # useTransition + confirmación antes de disparar retryInterviewSession()
│       │   ├── revision/page.tsx      # Dual-mode: cola (sin params) o detalle (?stage=X&org=Y). take:100. force-dynamic
│       │   ├── agentes/
│       │   │   ├── page.tsx           # Grid 3×2 de AgentCard: merge DB + defaults de lib/agent-defaults.ts. force-dynamic
│       │   │   └── [id]/page.tsx      # Detalle: form prompt+automationLevel, BarChart rendimiento, tabla últimos 10 entregables
│       │   ├── templates/page.tsx
│       │   ├── medios/page.tsx
│       │   ├── telegram/page.tsx      # Admin del bot TG (config, ABM usuarios)
│       │   ├── configuracion/page.tsx
│       │   └── api/health/route.ts    # Health check
│       ├── components/
│       │   ├── AdminSidebar.tsx
│       │   ├── KanbanBoard.tsx
│       │   ├── KanbanColumn.tsx
│       │   ├── ClientCard.tsx         # Wrapped en Link a /clientes/[id], badge de plan/status
│       │   ├── ClientHeader.tsx        # Avatar, nombre, badges, createdAt, suscripción ARS, botón revisión condicional
│       │   ├── ClientTabs.tsx          # URL-based tabs (Progreso|Entregables|Conversaciones|Notas) con contadores
│       │   ├── RevisionQueue.tsx       # Lista de cards con timeAgo, link a detalle. Empty state "Todo al día"
│       │   ├── RevisionPanel.tsx       # Detalle: breadcrumb, deliverables, ApproveStageForm+RejectStageForm
│       │   ├── AgentCard.tsx              # Tarjeta de agente: toggle read-only, stats, link a detalle
│       │   ├── AgentPerformanceChart.tsx  # Recharts BarChart aprobados vs rechazados por mes. use client
│       │   ├── AutomationToggle.tsx       # Toggle 3 estados: Manual|Semi-auto|Auto. Fallback para valores inválidos
│       │   ├── MetricsRow.tsx
│       │   ├── tabs/                   # Contenido de cada tab de la ficha de cliente
│       │   │   ├── ProgresoTab.tsx
│       │   │   ├── EntregablesTab.tsx
│       │   │   ├── ConversacionesTab.tsx
│       │   │   └── NotasTab.tsx
│       │   └── forms/                  # Formularios client con useTransition
│       │       ├── IntervenirForm.tsx   # confirm() antes de enviar, éxito, maxLength=2000
│       │       ├── AgregarNotaForm.tsx  # éxito, maxLength=5000
│       │       ├── ApproveStageForm.tsx # window.confirm(), éxito 800ms, manejo de error en UI
│       │       ├── RejectStageForm.tsx  # Expandible, formRef.reset() al cancelar, éxito, maxLength=1000
│       │       └── UpdateAgentForm.tsx  # Textarea controlada (contador 0/10000), toggle, éxito/error, cleanup timer
│       ├── actions/
│       │   └── interview.ts       # retryInterviewSession(sessionId, orgId): Server Action → POST /api/admin/sessions/{id}/process con Bearer JWT
│       ├── lib/
│       │   ├── actions.ts              # Server Actions: createAdminNote, sendAdminMessage, approveStage, rejectStage, updateAgentConfig
│       │   ├── agent-defaults.ts       # Única fuente de verdad para los 6 agentes IA (defaults de nombre/prompt/stats)
│       │   ├── badges.ts               # STAGE_STATUS_BADGE, DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL, PLAN_BADGE
│       │   ├── org-utils.ts            # Helpers compartidos de org: relativeTime(), deriveClientStatus()
│       │   ├── types.ts                # OrgWithDetails + tipos derivados (OrgStage, OrgDeliverable, OrgMessage, OrgNote)
│       │   ├── supabase-server.ts      # createSupabaseServerClient + requireAdminSession
│       │   └── supabase-browser.ts
│       ├── middleware.ts              # Protección de rutas (verifica sesión + rol ADMIN en app_metadata)
│       └── package.json

Convenciones del admin:

- **Server Components por defecto.** `'use client'` solo en forms y tabs interactivos
- **`requireAdminSession()` como primer paso** en todo Server Action — verifica sesión + rol ADMIN
- **Ownership check obligatorio:** todo Server Action que recibe un ID debe verificar que el recurso pertenece a la org indicada antes de operar (previene IDOR)
- **`prisma.$transaction`** para operaciones que deben ser atómicas (ej: rejectStage + createAdminNote)
- **URL-based routing:** tabs via `searchParams.tab`, modo detalle via `searchParams.stage` — permite deep links y back del browser
- **`take` en todas las queries de listado:** límite explícito para prevenir cargas masivas de DB
- **Admin→Portal HTTP pattern:** Server Actions del admin llaman al portal via `fetch` server-to-server con el `access_token` de Supabase del admin como Bearer. El portal verifica el JWT con `createServiceClient().auth.getUser(token)` + chequeo de `role === 'ADMIN'`. Ver ADR-0014.
- **`PORTAL_URL` obligatoria:** La variable de entorno `PORTAL_URL` no tiene fallback — falla explícitamente si no está configurada, para prevenir que staging llame a producción accidentalmente.
- **Badges centralizados:** importar siempre de `lib/badges.ts`, no redefinir localmente
- **Helpers de org compartidos:** `relativeTime()` y `deriveClientStatus()` viven en `lib/org-utils.ts` — no duplicar en páginas individuales
- **`revalidatePath`** después de cada mutación para invalidar caché de Next.js
├── services/
│   └── telegram-bot/                  # Bot de Telegram
│       ├── src/
│       │   ├── index.ts               # Entry point, long-polling
│       │   ├── bot.ts                 # Config de grammY, handlers
│       │   ├── llm-service.ts         # Interfaz con Anthropic SDK
│       │   ├── message-bridge.ts      # Sincroniza mensajes TG ↔ DB
│       │   ├── rate-limiter.ts        # Ventana deslizante in-memory
│       │   └── commands/              # Handlers por comando
│       │       ├── start.ts
│       │       ├── status.ts
│       │       └── help.ts
│       ├── package.json
│       └── tsconfig.json
└── package.json                       # Workspace root (pnpm)
```

---

## 5) Variables de entorno

Definidas en `.env.example` en la raíz y en cada app/servicio.

```bash
# ─── Supabase (packages/db + apps/portal + apps/admin) ───
DATABASE_URL=postgresql://...              # Prisma — connection string directo
DIRECT_URL=postgresql://...                # Prisma — bypasa PgBouncer para migraciones
NEXT_PUBLIC_SUPABASE_URL=                  # URL del proyecto Supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=             # Clave pública (safe for browser)
SUPABASE_SERVICE_ROLE_KEY=                 # Solo server-side. NUNCA en el cliente

# ─── Google OAuth (configurado en Supabase dashboard, no en código) ───
# Las credenciales de Google OAuth se configuran en:
# Supabase Dashboard → Authentication → Providers → Google
# No se necesitan env vars en el código para OAuth

# ─── reCAPTCHA v3 (apps/landing + apps/portal) ───
RECAPTCHA_SECRET_KEY=                      # Solo server-side. En dev: si falta, se saltea
# Site key: hardcodeada en el componente (es pública)

# ─── Telegram Bot (services/telegram-bot) ───
TELEGRAM_BOT_TOKEN=                        # Si falta, el bot no inicia (el server arranca igual)
ANTHROPIC_API_KEY=                         # Para respuestas LLM del bot

# ─── Landing ───
NEXT_PUBLIC_WHATSAPP_NUMBER=               # Link de WhatsApp en FinalCta

# ─── General ───
NODE_ENV=production                        # En producción. Nunca dejar development
```

---

## 6) Autenticación y autorización

### 6.1 Auth — Supabase Auth

**Decisión:** Supabase Auth en lugar de NextAuth. Ver ADR-0002.

**Flujo de login del cliente:**
1. Cliente llega a `app.qautiva.ar/login`
2. Opción A: Click "Continuar con Google" → Supabase OAuth → callback → redirect a `/progreso`
3. Opción B: Email + password → reCAPTCHA v3 → Supabase signInWithPassword → redirect a `/progreso`

**Flujo de registro (self-service):**
1. Cliente llega desde la landing (CTA "Lanzá tu negocio") → `/onboarding`
2. Paso 1: Sign up con Google OAuth o email/password (reCAPTCHA v3)
3. Paso 2: Completa datos del negocio → crea `Project` + asigna a `Team`
4. Paso 3: Selecciona servicios (BRAND/WEBSITE/CAMPAIGNS/MEDIA) → crea `Stage`s
5. Paso 4: Elige modo IA:
   - **Trial**: tokens gratuitos con TTL configurable desde admin (`TrialConfig`)
   - **Hosted**: plan PREPAID usando keys de Qautiva
   - **BYOK**: ingresa su API key (Anthropic/OpenAI/Gemini), se encripta AES-256-GCM, se valida con timeout 10s
6. `Project.status` → `GENERATING`, `user.app_metadata.onboarding_complete = true`
7. TODO Etapa 3: redirect a `/proyectos/{id}/progreso`

**Usuarios legacy (agencia):** tienen `app_metadata.org_id` en lugar de `onboarding_complete`. El middleware los distingue y les da acceso completo sin pasar por el wizard.

**Middleware (portal):** Verifica sesión válida. Redirige a `/login` si no autenticado, a `/onboarding` si autenticado pero sin `onboarding_complete` ni `org_id`. Setea header `x-pathname` para Server Components.
**Middleware (admin):** Verifica sesión + que `user.app_metadata.role === 'admin'`. Si no → 403.

**Paquete:** `@supabase/ssr` — crea clientes para server components, route handlers, y middleware.

### 6.2 Autorización — Row Level Security (RLS)

**Decisión:** RLS en PostgreSQL como capa principal de autorización multi-tenant.

**Principio:** Un cliente solo puede ver datos de SU organización. Incluso si hay un bug en el código de la app, la DB impide el acceso cruzado.

**Implementación:**
- Cada tabla con datos de cliente tiene `organization_id`
- RLS policy: `organization_id = (auth.jwt() ->> 'org_id')::uuid`
- El `org_id` se inyecta en el JWT via Supabase Auth hook al hacer login
- Las tablas de admin (`AgentConfig`, `IndustryTemplate`) tienen policy: `auth.jwt() ->> 'role' = 'admin'`

**Índices obligatorios:** Toda columna referenciada en una policy RLS debe tener índice. Sin índice, RLS hace sequential scan en cada query.

**Server Actions (admin):** Todo Server Action en `apps/admin/lib/actions.ts` llama `requireAdminSession()` como primer paso. Esta función crea un cliente Supabase server-side via `@supabase/ssr` con las cookies del request, verifica sesión activa, y valida que `user.app_metadata.role === 'ADMIN'`. Si falla, lanza error. El middleware ya protege las páginas, pero los Server Actions son endpoints independientes que requieren su propia verificación.

### 6.3 reCAPTCHA v3

- **Landing:** Protege formulario de contacto/CTA
- **Portal login:** Protege login con email/password (no aplica cuando es OAuth)
- **Comportamiento por ambiente:**
  - Dev: si `RECAPTCHA_SECRET_KEY` no está, se saltea (log de warning)
  - Prod: si `RECAPTCHA_SECRET_KEY` no está, bloquea todo (fail-closed)
- **Sin dependencias extra:** Usa `next/script` para cargar el script de Google, `fetch` nativo para verificar en servidor

---

## 7) Bot de Telegram

### 7.1 Stack

- **Framework:** grammY (TypeScript-first, 41K descargas/semana)
- **LLM:** @anthropic-ai/sdk — modelo escalonado (Haiku para consultas simples, Sonnet para complejas)
- **Runtime:** Proceso persistente con long-polling, desplegado en Railway junto al admin
- **DB:** Comparte Prisma client con el resto del monorepo

### 7.2 Integración con ChatPanel

Los mensajes de Telegram y del chat web se almacenan en la misma tabla `Message` con el campo `channel` diferenciando el origen. Supabase Realtime propaga inserts a todos los suscriptores:

- **Cliente escribe en Telegram** → bot guarda `Message(channel: TELEGRAM)` → Realtime notifica al portal web y al admin
- **Cliente escribe en ChatPanel** → portal guarda `Message(channel: WEB)` → Realtime notifica al admin y al bot (que puede responder por TG)
- **Admin interviene** → admin guarda `Message(sender: ADMIN)` → llega a ambos canales

### 7.3 Modelos de datos adicionales

```
TelegramUser   — whitelist de usuarios autorizados, vinculados a Organization
TelegramConfig — singleton (bot_enabled, llm_model, rate_limit, system_prompt)
```

### 7.4 Optimización de costos LLM

| Estrategia | Ahorro estimado |
|---|---|
| Cache de consultas de estado ("¿en qué etapa estoy?") → respuesta desde DB sin LLM | 40-60% de calls |
| Modelo escalonado: Haiku para FAQ, Sonnet solo para conversaciones complejas | 70% reducción de costo por call |
| Respuestas template para estados conocidos (entregable listo, esperando aprobación) | 20-30% de calls |
| Rate limiting por plan: Base 50 msg/mes, Completo 200, Premium ilimitado | Control de gasto por cliente |
| Límite global configurable en `TelegramConfig.rate_limit_per_hour` | Protección contra picos |

---

## 8) Sistema de diseño — tokens

Fuente de verdad visual en `packages/ui/tokens.ts`. Resumen:

| Token | Valor | Uso |
|---|---|---|
| `bg.primary` | `#0B0F1A` | Fondo principal |
| `bg.secondary` | `#0F172A` | Tarjetas, paneles |
| `bg.tertiary` | `#1E293B` | Inputs, hovers |
| `accent.DEFAULT` | `#8B5CF6` | Botones primarios, activos |
| `accent.light` | `#A78BFA` | Hover, bordes activos |
| `text.primary` | `#F8FAFC` | Títulos, texto principal |
| `text.secondary` | `#94A3B8` | Descripciones |
| `text.muted` | `#64748B` | Metadatos, placeholders |
| `status.success` | `#10B981` | Completado, aprobado |
| `status.warning` | `#F59E0B` | Pendiente, atención |
| `status.error` | `#EF4444` | Error, rechazo |

**Tipografía:** Satoshi (display + body) · JetBrains Mono (datos)
**Dark mode:** Único modo. No hay toggle de tema.

---

## 9) Escalabilidad y costos

### 9.1 Costo mensual estimado

| Recurso | MVP (0-50 clientes) | Growth (50-500) | Scale (500-5000) |
|---------|---------------------|-----------------|------------------|
| Supabase Pro (DB + Auth + Realtime + Storage) | $25/mo | $25 + usage | $25 + usage |
| Vercel Pro (landing + portal) | $20/mo | $20/mo | $20 + functions |
| Railway (admin + TG bot) | ~$5/mo | ~$10/mo | ~$20-40/mo |
| Anthropic API (LLM del bot) | ~$5-20/mo | ~$50-200/mo | $200-2000/mo |
| **Total** | **~$55-70/mo** | **~$105-255/mo** | **~$265-2085/mo** |

> **Nota:** Supabase free tier pausa proyectos tras 7 días de inactividad. Para producción se necesita Pro ($25/mo) desde el día 1.

### 9.2 Decisiones de optimización de costos

| Decisión | Impacto |
|---|---|
| Landing SSG puro (no SSR) | CDN de Vercel, casi gratis |
| Dark mode only | 0 CSS/lógica de tema extra |
| Monorepo pnpm + Turborepo | Un solo node_modules, builds cacheados local y remotamente |
| Supabase all-in-one (DB + Auth + Realtime + Storage) | 1 factura, no 4 servicios |
| Telegram bot en mismo deploy que admin | $0 extra de infra |
| ISR en portal donde sea posible | Reduce serverless function calls |
| Preview deployments desactivados | Solo deploy en push a main; elimina ~70% de build minutes |
| `ignoreCommand` por app en Vercel | Skipea builds cuando no hay cambios relevantes para esa app |
| Cache de consultas LLM frecuentes | 40-60% menos calls a Anthropic |
| Modelo LLM escalonado (Haiku / Sonnet) | 70% reducción de costo por call |

### 9.3 Trampas de escalabilidad a evitar

| Trampa | Umbral | Mitigación |
|--------|--------|------------|
| Supabase Realtime connections | 200 concurrent (Pro) | Conectar solo cuando hay acción pendiente; desconectar en idle |
| Prisma connection pooling | 60 connections (Supabase) | Usar PgBouncer de Supabase (incluido); `DIRECT_URL` para migraciones |
| Telegram long-polling | ~1000 usuarios concurrentes | Migrar a webhooks + queue cuando se alcance |
| Tabla `Metric` crece 1 row/día/org | 150K rows/mes a 5000 orgs | Job de agregación mensual; detalle solo últimos 90 días |
| Vercel serverless sin límite de gasto | Sin hard spending limit | Configurar alertas de billing; máximo duration en functions |
| Storage de entregables | 1GB free, después $0.021/GB | Comprimir imágenes antes de subir; lazy loading con `next/image` |

---

## 10) Restricciones conocidas

- **Sin light mode:** La app es dark-only por diseño de marca
- **Datos en ARS:** Todos los montos en pesos argentinos, formato `$45.000`
- **Idioma:** Español argentino con voseo en toda la UI
- **Renders de referencia:** Los 12 renders de Gemini son la fuente de verdad visual. El texto generado por Gemini en sidebars es ruido — la navegación correcta está en el spec
- **Sin generación de IA en este repo:** El motor que genera los entregables es un sistema externo; este repo solo muestra y gestiona los entregables ya generados
- **Supabase free tier no sirve para producción:** Se pausa tras 7 días de inactividad
- **Vercel no tiene hard spending limit:** Configurar alertas de billing es obligatorio
- **Preview deployments desactivados:** No hay validación visual pre-merge en Vercel. Usar CI (GitHub Actions) para validar builds en PRs
- **`ignoreCommand` requiere mantenimiento manual:** Al agregar un nuevo paquete compartido, actualizar los paths en cada `vercel.json`. Ver ADR-0007

---

---

## 11) Marketplace de medios

> Estado: **Etapa 1 en desarrollo** — Schema base completo, CRUD en construcción.
> Ver spec completa en `docs/marketplace/PLAN.md` y plan de etapas en `docs/marketplace/ETAPAS.md`.

### 11.1 Concepto

Marketplace tipo Getlinko orientado a Argentina. Los usuarios compran y venden espacios
en medios digitales (blogs, diarios, redes sociales). Sin roles separados: el mismo usuario
puede comprar (anunciante) y vender (editor). Ver ADR-0008 para decisiones de diseño.

### 11.2 Nuevas rutas del portal

| Ruta | Descripción |
|------|-------------|
| `/marketplace` | Catálogo de medios con filtros (Server Component + URL-based filters) |
| `/marketplace/[mediumId]` | Detalle del medio: métricas, productos, reseñas |
| `/marketplace/[mediumId]/comprar/[productId]` | Formulario de pedido |
| `/mis-medios` | Panel del editor: medios registrados |
| `/mis-medios/nuevo` | Wizard de alta de medio (4 pasos, Client Component) |
| `/mis-pedidos` | Panel del anunciante: pedidos realizados |
| `/mis-pedidos/[orderId]` | Detalle de pedido + mensajes |
| `/mis-ventas` | Panel del editor: ventas recibidas |
| `/mis-ventas/[orderId]` | Detalle de venta + formulario de entrega + mensajes |

### 11.3 Nuevas rutas del admin

| Ruta | Descripción |
|------|-------------|
| `/medios` | Cola de medios pendientes de aprobación |
| `/medios/[id]` | Detalle del medio: aprobar/rechazar |
| `/ordenes` | Listado de órdenes (monitor de disputas) |
| `/ordenes/[id]` | Detalle de orden |

### 11.4 Nuevas tablas (prefijo `marketplace_`)

| Tabla | Descripción |
|-------|-------------|
| `marketplace_categories` | Categorías temáticas con self-relation (subcategorías) |
| `marketplace_media` | Medios registrados por editores. Soft delete. |
| `marketplace_medium_categories` | Join table Medium ↔ Category |
| `marketplace_products` | Productos ofrecidos por cada medio |
| `marketplace_orders` | Pedidos de anunciantes a editores |
| `marketplace_order_messages` | Chat interno de cada orden |

**Convenciones específicas del marketplace:**
- Todas las tablas usan prefijo `marketplace_` para aislar el dominio
- `editor` = usuario con al menos un `Medium` (no hay UserRole especial) — ver ADR-0008
- `Order.price` es snapshot del precio al momento de la compra (no FK al `Product.price` actual)
- `Order.commission` = 10% fijo (configurable en el futuro). `Order.editorPayout` = price - commission
- `OrderMessage.senderId` es String con FK en SQL pero sin relación Prisma formal — ver ADR-0008
- Partial unique index `(userId, url) WHERE platform = 'WEBSITE'` — vive en migración SQL, no en schema Prisma

### 11.5 ADRs del marketplace

- `docs/decisions/ADR-0008-marketplace-data-model.md` — Prefijo de tablas, rol de editor, senderId, partial index WEBSITE

*Última actualización: 2026-03-15 — Eliminación segura de proyectos: endpoint DELETE /api/projects/[id] (soft-delete), componente DeleteProjectButton, ADR-0013.*

---

## 12) Billing Core — Registro de consumo de IA

> Implementado en Fase billing-1 (2026-03-18). Corrige hallazgos críticos 1.1–1.4.

### 12.1 Modelos de datos

| Modelo | Descripción |
|--------|-------------|
| `BillingAccount` | Cuenta de facturación por Team. Tiene `plan`, `preferredKeySource`, `balanceUsd`, `trialTokensUsed`, `trialTokensTotal`, `trialExpiresAt` |
| `AiModelPricing` | Precio por provider+model: `inputPer1M` y `outputPer1M` (USD por 1M tokens). Único por `[provider, model]` |
| `FeeConfig` | Fee de Qautiva por `plan` + `keySource`. `feePercentage` aplicado sobre `costUsd`. Único por `[plan, keySource]` |
| `TokenUsage` | Registro de cada llamada LLM. Tiene `teamId`, `projectId`, `provider`, `model`, `operation`, `source`, `tokensIn`, `tokensOut`, `costUsd`, `feeUsd`, `totalUsd` |

### 12.2 Flujo de registro de consumo

```
AI call (executeToolCall / llamada directa)
    ↓
registerAiUsage({ teamId, projectId, provider, model, operation, source, tokensIn, tokensOut })
    ↓
recordTokenUsage()             updateBillingConsumption()
  - AiModelPricing → costUsd    - TRIAL → trialTokensUsed++
  - FeeConfig → feeUsd          - QAUTIVA_HOSTED → balanceUsd--
  - Inserta TokenUsage          - BYOK → no-op
```

**Fire-and-forget:** `registerAiUsage` captura todos los errores y los loguea con `CRITICAL:` pero NO propaga la excepción. El consumo de IA ya ocurrió — el registro de billing no debe cancelar la respuesta al usuario.

### 12.3 Cálculo de costos

```
costUsd = (tokensIn * inputPer1M + tokensOut * outputPer1M) / 1_000_000
feeUsd  = costUsd * feePercentage / 100
totalUsd = costUsd + feeUsd
```

### 12.4 Fuente de uso (UsageSource)

Derivada de `BillingAccount` al inicio de cada sesión por `resolveUsageSource()` en `session-processor.ts`:
- `plan === FREE_TRIAL` → `TRIAL`
- `preferredKeySource === BYOK` → `BYOK`
- else → `QAUTIVA_HOSTED`

### 12.5 Archivos del módulo

| Archivo | Responsabilidad |
|---------|-----------------|
| `apps/portal/app/_lib/billing/record-token-usage.ts` | Calcula costUsd/feeUsd/totalUsd e inserta TokenUsage |
| `apps/portal/app/_lib/billing/update-billing.ts` | Actualiza BillingAccount según source |
| `apps/portal/app/_lib/billing/register-ai-usage.ts` | Orquestador fire-and-forget |

### 12.6 Integración con generators

Todos los generators aceptan `billingContext?: BillingContext` (opcional para backward compat).
`executeToolCall()` acepta `billingContext?` y dispara `registerAiUsage()` automáticamente.
Las llamadas directas a OpenAI (brand-generator, market-study-generator) también registran usage.

**Gemini imagen:** no se registra (la API de generación de imágenes no expone token usage). Ver `KNOWN_ISSUES.md`.

*Última actualización: 2026-03-18 — Billing core implementado (Fase billing-1).*

---

## 13) Billing Guards — Validación pre-ejecución

> Implementado en Fase billing-2 (2026-03-18). Corrige hallazgos críticos 1.6, 2.1, 6.1.

### Objetivo

Ninguna operación de IA se ejecuta sin verificar saldo/trial activo. `balanceUsd` no puede ser negativo (constraint DB).

### Función `checkBillingEligibility(teamId)`

**Archivo:** `apps/portal/app/_lib/billing/check-eligibility.ts`

Lógica por plan:

| Plan | Condición de elegibilidad |
|------|--------------------------|
| BYOK (cualquier plan) | Siempre eligible — el usuario paga su propia API key |
| `FREE_TRIAL` | `trialExpiresAt > now()` (si está configurado) AND `trialTokensUsed < trialTokensTotal` |
| `PREPAID` | `balanceUsd > 0` |
| `MONTHLY` / `YEARLY` | `balanceUsd >= 0` (suscripción activa) |
| Sin `BillingAccount` | Lanza error CRITICAL — no puede verificar elegibilidad |

**Retorna:** `{ eligible: boolean, reason?: string, billingPlan: BillingPlan, source: UsageSource }`

El campo `source` es el `UsageSource` a pasar a `registerAiUsage()` para el registro post-ejecución.

### Puntos de guard

El guard se inserta ANTES del lock atómico para no reclamar recursos si el billing falla:

**`POST /api/interview/sessions/[id]/advance` (acción `submit`):**
- Verificado después de validar respuestas requeridas y ANTES de transicionar a `PROCESSING`
- Si no es eligible → `402 Payment Required` con `{ error: reason }`
- Si falla la consulta DB → `503 Service Unavailable` (fail-safe: bloquea por seguridad)

**`POST /api/interview/sessions/[id]/process`:**
- Verificado después de ownership check y ANTES del lock atómico (`updateMany`)
- Si no es eligible → `402 Payment Required` con `{ error: reason }`
- Si falla la consulta DB → `503 Service Unavailable`

### Constraint DB

**Migración:** `packages/db/prisma/migrations/016_billing_balance_check.sql`

```sql
ALTER TABLE "BillingAccount"
  ADD CONSTRAINT "BillingAccount_balanceUsd_check" CHECK ("balanceUsd" >= 0);
```

Incluye verificación previa que impide aplicar el constraint si existen registros con saldo negativo.

### Módulos

| Archivo | Responsabilidad |
|---------|----------------|
| `apps/portal/app/_lib/billing/check-eligibility.ts` | Lógica de elegibilidad por plan |
| `apps/portal/app/api/interview/sessions/[id]/process/route.ts` | Guard en endpoint de procesamiento |
| `apps/portal/app/api/interview/sessions/[id]/advance/route.ts` | Guard en submit de entrevista |
| `packages/db/prisma/migrations/016_billing_balance_check.sql` | CHECK constraint balanceUsd >= 0 |

*Última actualización: 2026-03-18 — Billing guards implementados (Fase billing-2).*

---

## 14) Telegram Bot Billing — Fase billing-3

> Implementado en Fase billing-3 (2026-03-18). Integra billing en el servicio de Telegram.

### Objetivo

El bot registra el consumo de tokens de cada interacción con el LLM. Antes de llamar al LLM, verifica que el team tenga saldo/trial activo.

### Flujo en `message-bridge.ts`

```
handleMessage(ctx)
  ├── Resolver TelegramUser (organizationId + projectId + project.teamId)
  ├── Si teamId existe:
  │   ├── checkBotBillingEligibility(teamId)
  │   │   ├── eligible=false → reply(reason) y return (fail-closed)
  │   │   └── falla DB      → reply(error) y return (fail-closed)
  │   └── billingContext = { teamId, projectId, source }
  ├── Si teamId=null (legacy): billingContext=null (degradación graceful)
  └── generateResponse(msg, orgId, history, billingContext)
        └── _registerUsage(billingContext, model, tokens)  ← fire-and-forget
```

### `checkBotBillingEligibility(teamId)`

**Archivo:** `services/telegram-bot/src/billing.ts`

Misma lógica que `checkBillingEligibility()` del portal, adaptada al cliente Prisma propio del bot:

| Plan | Condición |
|------|-----------|
| BYOK | Siempre eligible |
| FREE_TRIAL | No expirado AND tokens disponibles |
| PREPAID | `balanceUsd > 0` |
| MONTHLY / YEARLY | `balanceUsd >= 0` |
| Sin `BillingAccount` | Lanza error CRITICAL |

### `registerBotTokenUsage(params)`

**Archivo:** `services/telegram-bot/src/billing.ts`

- Provider siempre `ANTHROPIC`, operation siempre `telegram_chat`
- Acumula tokens de ambas llamadas al LLM (con y sin tool_use)
- Fire-and-forget: nunca propaga errores (el consumo ya ocurrió)
- Calcula `costUsd` con pricing de `AiModelPricing`, aplica `FeeConfig`, descuenta `BillingAccount`

### Resolución de `teamId`

`TelegramUser` tiene `projectId` nullable (Fase A). El `teamId` se obtiene via join:

```prisma
prisma.telegramUser.findUnique({
  select: { organizationId, projectId, project: { select: { teamId } } }
})
```

Si `projectId` es null (usuario legacy), el billing check se omite y `billingContext=null` se pasa al LLM (tokens no se registran, con warning en log).

### Módulos

| Archivo | Responsabilidad |
|---------|----------------|
| `services/telegram-bot/src/billing.ts` | `checkBotBillingEligibility` + `registerBotTokenUsage` |
| `services/telegram-bot/src/llm.ts` | Acepta `billingContext`, llama `_registerUsage` fire-and-forget |
| `services/telegram-bot/src/message-bridge.ts` | Guard de billing + resolución de teamId |

*Última actualización: 2026-03-18 — Telegram Bot billing implementado (Fase billing-3).*

---

## 15. Política de Permisos por Rol (Fase billing-4)

*Implementado: 2026-03-18*

### Roles disponibles

| Rol | Descripción |
|-----|-------------|
| `OWNER` | Dueño del team. Máximos permisos, incluyendo eliminación de proyectos. |
| `ADMIN` | Administrador. Puede crear proyectos, ejecutar generaciones, gestionar API keys. |
| `MEMBER` | Solo lectura. No puede ejecutar operaciones de escritura. |

### Helper central

**Archivo:** `apps/portal/app/_lib/auth/check-team-permission.ts`

```typescript
checkTeamPermission(authUserId, teamId, requiredRoles[]) → { authorized, role }
```

- Consulta `userProfile.teamMemberships` filtrado por `teamId` en la DB (no en memoria)
- Si el usuario no tiene perfil o no pertenece al team → `{ authorized: false, role: null }`
- Fail-closed: cualquier rol no incluido en `requiredRoles` → `{ authorized: false }`

### Matriz de permisos por endpoint

| Endpoint | Método | Roles requeridos | Patrón |
|----------|--------|-----------------|--------|
| `/api/interview/sessions` | POST | ADMIN, OWNER | `checkTeamPermission` via `project.teamId` |
| `/api/interview/sessions/[id]/process` | POST | ADMIN, OWNER | `checkTeamPermission` via `session.teamId` |
| `/api/interview/sessions/[id]/advance` | POST (submit) | ADMIN, OWNER | `checkTeamPermission` via `session.teamId` |
| `/api/interview/sessions/[id]/answer` | POST | ADMIN, OWNER | `checkTeamPermission` via `session.teamId` |
| `/api/projects` | POST (step 1) | ADMIN, OWNER | `checkTeamPermission` via user's first team |
| `/api/projects` | POST (step 2) | ADMIN, OWNER | `checkTeamPermission` via `project.teamId` |
| `/api/projects/[id]` | DELETE | **OWNER only** | `checkTeamPermission` via `project.teamId` |
| `/api/settings/api-keys` | POST | ADMIN, OWNER | `getTeamForUser` → `team.teamRole` |
| `/api/settings/api-keys/[id]` | DELETE | ADMIN, OWNER | `getTeamForUser` → `team.teamRole` |
| `/api/settings/ai-mode` | PATCH | ADMIN, OWNER | `getTeamForUser` → `team.teamRole` |
| `/api/domains/register` | POST | ADMIN, OWNER | `getTeamContext` → `teamRole` |

### Decisión de implementación

Para endpoints que ya usan `getTeamForUser()` (settings, domains), el rol se obtiene del resultado existente sin una query adicional. Para endpoints de interview/projects, se usa `checkTeamPermission()` porque el `teamId` se obtiene del recurso (proyecto/sesión), no del perfil.

### Respuestas HTTP

| Situación | Status | Mensaje |
|-----------|--------|---------|
| Rol insuficiente | 403 | "Permisos insuficientes. Solo ADMIN y OWNER pueden [acción]." |
| No miembro del team | 403 | "Permisos insuficientes..." |
| Sin perfil | 403 | "Permisos insuficientes..." |

*Última actualización: 2026-03-18 — Roles y permisos implementados (Fase billing-4).*

---

## 16) Stages Flexibles — Fase billing-5

> Implementado en Fase billing-5 (2026-03-18). Ver ADR-0020.

### Enum `StageActivation`

| Valor | Comportamiento |
|-------|----------------|
| `ACTIVE` | El stage se procesa normalmente (valor por defecto) |
| `SKIP` | No aplica para este proyecto. Al inicio de `processSession()`, hace early return y marca el stage `COMPLETED` automáticamente sin generar nada |
| `PROVIDED_BY_CLIENT` | El cliente ya tiene este material. Mismo early return que `SKIP` — se marca `COMPLETED` sin generar entregables |

### Cómo se setea la activation

- **Al crear el proyecto** (`POST /api/projects`, paso 2): el body puede incluir `stageActivation: Record<StageKey, StageActivation>`. Si se omite un stage, queda con el valor `ACTIVE`.
- **Manualmente** via `PATCH /api/stages/[stageId]/activation`: permite cambiar la activation de un stage existente. Requiere rol `ADMIN` o `OWNER`.

### Enforcement en `session-processor.ts`

Al inicio de `processSession()`, antes de cualquier llamada LLM:

```
if (stage.activation === SKIP || stage.activation === PROVIDED_BY_CLIENT) {
  → mark stage COMPLETED
  → early return (sin generar, sin consumir tokens)
}
```

### Entrevista de intake (`stageKey = 'INTAKE'`)

Stage especial con `number = 0` que ejecuta antes que el resto. Al completarse:

1. Las respuestas del usuario se analizan para determinar qué stages aplican.
2. Se actualizan las `activation` del resto de stages según esas respuestas (ej: el cliente ya tiene logo → stage BRAND pasa a `PROVIDED_BY_CLIENT`).
3. Los stages con `activation != ACTIVE` quedan marcados `COMPLETED` automáticamente en la siguiente ejecución del processor.

Ver ADR-0020 para el diseño completo del flujo de intake.

---

## 17) Revenue de Dominios — Fase billing-6

> Implementado en Fase billing-6 (2026-03-18).

### Campo `Domain.revenueUsd`

Margen materializado de la venta de un dominio, calculado y persistido en el momento del registro.

**Fórmula:**

```
revenueUsd = paidAmountArs / exchangeRate - costUsd
```

Donde:
- `paidAmountArs`: monto cobrado al cliente en pesos argentinos
- `exchangeRate`: tipo de cambio ARS/USD vigente al momento del registro
- `costUsd`: costo del dominio al proveedor (OpenSRS u otro) en USD

**Cálculo:** ocurre en `POST /api/domains/register`, al momento de insertar el registro. No se recalcula posteriormente.

**Valores negativos:** son válidos y auditables. Ocurren cuando el margen configurado no cubrió el costo real (ej: tipo de cambio desfavorable o fee mal configurado). No se deben ocultar ni corregir automáticamente.

**Datos históricos:** dominios registrados antes de la implementación de este campo fueron populados con el cálculo retroactivo via migración 018.

---

## 18) Integridad de Datos — Fase billing-7

> Implementado en Fase billing-7 (2026-03-18).

### Constraints de unicidad parcial

#### `Deliverable_one_active_per_stage`

```sql
-- Migration 019
CREATE UNIQUE INDEX "Deliverable_one_active_per_stage"
  ON "Deliverable"("stageId")
  WHERE "isActive" = true;
```

Garantiza que hay **como máximo un `Deliverable` activo por `Stage`**. Previene la situación donde múltiples deliverables activos para el mismo stage generan inconsistencias en la vista del cliente.

#### `TeamMember_one_owner_per_team`

```sql
-- Migration 020
CREATE UNIQUE INDEX "TeamMember_one_owner_per_team"
  ON "TeamMember"("teamId")
  WHERE "role" = 'OWNER';
```

Garantiza **exactamente un `OWNER` por `Team`**. Hace que la DB rechace cualquier operación que intente asignar un segundo OWNER al mismo team, sin depender de validación en código.

### Mecanismo admin en RLS

El mecanismo actual usa dos enfoques inconsistentes para verificar el rol admin (Supabase JWT claim `role` vs. columna en tabla de usuarios). El plan de migración para unificar esto está documentado en ADR-0021.

*Última actualización: 2026-03-19 — Integración Google Stitch (package `packages/stitch`, ADR-0022, migración 021, UI admin, personalización async en portal).*

---

## 19. Cola de Diseños Stitch

> Implementado: 2026-03-20 — branch `claude/stitch-design-queue-IXxiT`, ADR-0023

Sistema de cola para generación asíncrona de templates HTML con Google Stitch. Permite registrar pedidos sin consumir créditos inmediatamente, ejecutarlos de a uno respetando límites diarios, y rotar entre múltiples cuentas Stitch.

### Modelo de datos

**`TemplateQueueStatus`** (enum)
- `QUEUED` → registrado, sin ejecutar
- `GENERATING` → Stitch corriendo en background
- `DONE` → HTML listo, template queda como `DRAFT` para aprobación admin
- `ERROR` → falló, puede reintentar manualmente desde UI

**`StitchAccount`** (tabla)
- Representa una cuenta Google Stitch con pool de créditos independiente
- Campos clave: `apiKey`, `usedToday`, `dailyLimit`, `active`
- Las API keys se almacenan en texto plano (DB detrás de RLS de Supabase)

**`WebTemplate`** (extensión)
- Nuevos campos nullable: `queueStatus`, `queuedAt`, `styleId`, `stitchAccountId`, `stitchJobId`
- `null` en `queueStatus` = template manual, no participa en la cola

### Endpoints nuevos (`apps/admin`)

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/stitch/accounts` | Lista cuentas con reset inline de cuota si `lastResetAt < hoy` |
| POST | `/api/stitch/accounts` | Crea nueva cuenta Stitch |
| GET | `/api/stitch/queue` | Lista jobs con filtro por status |
| POST | `/api/stitch/queue` | Encola un template (status → `QUEUED`) |
| POST | `/api/stitch/queue/factory` | Encola N templates por industrias × estilos (bulk) |
| POST | `/api/stitch/queue/[id]/run` | Ejecuta un job manualmente (ignora cuota) |
| POST | `/api/cron/reset-stitch-quota` | Reset nocturno de `usedToday` en todas las cuentas |

### UI admin

**Página `/templates/cola`**
- Panel de cuentas: uso diario, límites, activar/desactivar
- Lista de jobs con status en tiempo real y botón de reintento
- Factory: formulario para encolar múltiples templates por industria × estilo

### Decisiones técnicas

Ver ADR-0023 para las 4 decisiones principales:
1. Sin Redis/BullMQ — cola sobre DB con cron existente
2. `queueStatus` nullable (compatibilidad hacia atrás)
3. Multi-cuenta en tabla DB (no env vars)
4. Reset de cuotas inline + cron de respaldo

*Última actualización: 2026-03-20 — Cola de diseños Stitch (ADR-0023, migración 022, UI `/templates/cola`, endpoints `/api/stitch/queue` y `/api/stitch/accounts`).*
