# Componentes Base — Qapitaliza

> Catálogo de primitivos reutilizables. Cada componente vive en `src/components/ui/`.
> No duplicar lógica visual — si el patrón existe acá, usarlo.

---

## 1. Button

**Archivo:** `src/components/ui/Button.tsx`

### Variantes

| Variant | Apariencia | Casos de uso |
|---|---|---|
| `solid` | Fondo `#F59E0B`, texto `#0B0F1A`, hover `#FBBF24` | CTA principal: "Iniciar sesión", "Guardar cambios", "Publicá tu activo" |
| `outline` | Borde `#F59E0B`, texto `#F59E0B`, fondo transparente, hover fondo amber/10 | Acciones secundarias: "Guardar borrador", "Pausar publicación" |
| `outline-danger` | Borde `#EF4444`, texto `#EF4444` | Acciones destructivas: "Eliminar listado", "Rechazar" |
| `outline-success` | Borde `#10B981`, texto `#10B981` | Aprobar listados |
| `ghost` | Sin borde ni fondo, texto `#94A3B8`, hover texto `#F8FAFC` | "Cancelar", "Descartar cambios" |
| `link` | Solo texto amber con underline en hover | "Ver todos →", "Ver perfil →" |

### Tamaños

| Size | Padding | Font size | Uso |
|---|---|---|---|
| `sm` | `px-3 py-1.5` | `text-sm` | Acciones en tablas, botones de modals inline |
| `md` | `px-4 py-2` | `text-sm` | Default |
| `lg` | `px-6 py-3` | `text-base` | CTAs principales, formularios |
| `full` | `w-full px-4 py-3` | `text-base` | Botones en columnas de formulario (auth, cards de acción) |

### Props

```ts
interface ButtonProps {
  variant?: 'solid' | 'outline' | 'outline-danger' | 'outline-success' | 'ghost' | 'link'
  size?: 'sm' | 'md' | 'lg' | 'full'
  loading?: boolean       // muestra spinner, deshabilita el botón
  disabled?: boolean
  icon?: React.ReactNode  // ícono Lucide a la izquierda del texto
  iconRight?: React.ReactNode
  children: React.ReactNode
  onClick?: () => void
  type?: 'button' | 'submit' | 'reset'
}
```

### Reglas

- `rounded-lg` siempre (8px)
- `transition-colors duration-150` en todos
- Estado `loading`: mostrar `<Loader2 className="animate-spin size-4" />` y deshabilitar pointer events
- Estado `disabled`: opacidad 50%, cursor not-allowed

---

## 2. Card

**Archivo:** `src/components/ui/Card.tsx`

```ts
interface CardProps {
  children: React.ReactNode
  className?: string
  hover?: boolean      // activa el efecto hover con borde amber
  padding?: 'sm' | 'md' | 'lg'  // p-4 | p-5 | p-8
  border?: 'default' | 'amber'  // borde #1E293B | borde amber al 20%
}
```

**Estilos base:**
```
bg-navy-900 border border-slate-800 rounded-xl
```

**Con hover:**
```
transition-all duration-200 hover:border-amber-500/30 hover:shadow-lg hover:shadow-amber-500/5
```

**Con border amber** (usado en card de seguridad/transacción):
```
border-amber-500/20
```

---

## 3. Badge / Pill

**Archivo:** `src/components/ui/Badge.tsx`

```ts
interface BadgeProps {
  variant: 'success' | 'amber' | 'info' | 'muted' | 'danger'
  children: React.ReactNode
  dot?: boolean   // muestra dot de color antes del texto
  icon?: React.ReactNode
}
```

| Variant | Background | Texto | Uso |
|---|---|---|---|
| `success` | `bg-emerald-500/15` | `text-emerald-500` | "Publicado", "Verificado", "Activo" |
| `amber` | `bg-amber-500/15` | `text-amber-500` | "Destacado", "Premium", "Pendiente", "En revisión" |
| `info` | `bg-blue-500/15` | `text-blue-500` | "SaaS", "Respondida", rol "Vendedor" |
| `muted` | `bg-slate-800` | `text-slate-400` | "Borrador", "Cerrada" |
| `danger` | `bg-red-500/15` | `text-red-500` | "Rechazado", "Suspendido" |

**Estilos base:** `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium`

---

## 4. Input

**Archivo:** `src/components/ui/Input.tsx`

```ts
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  helper?: string         // texto ayuda debajo del input
  error?: string          // reemplaza helper, muestra en rojo
  prefix?: string         // texto fijo antes del input ("https://", "$")
  suffix?: React.ReactNode // elemento derecho (ícono, botón)
  counter?: { current: number; max: number }  // "0 / 2000 caracteres"
}
```

**Estilos base del input:**
```
bg-slate-800 border border-slate-800 rounded-lg px-3 py-2.5 text-sm text-slate-50
placeholder:text-slate-500
focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent
transition-all duration-150
```

**Estado error:**
```
border-red-500 focus:ring-red-500
```

**Label:** `text-sm font-medium text-slate-400 mb-1.5 block`

**Helper:** `text-xs text-slate-500 mt-1`

**Error text:** `text-xs text-red-400 mt-1`

---

## 5. Textarea

**Archivo:** `src/components/ui/Textarea.tsx`

Igual que Input pero `<textarea>`. Props adicionales:
```ts
rows?: number      // default: 4
maxLength?: number // habilita counter automático
```

**Counter:** `text-xs text-slate-500 text-right mt-1` — muestra `{current} / {max} caracteres`

---

## 6. Select

**Archivo:** `src/components/ui/Select.tsx`

```ts
interface SelectProps {
  label?: string
  options: { value: string; label: string }[]
  value?: string
  onChange?: (value: string) => void
  placeholder?: string
  error?: string
}
```

Mismos estilos base que Input. Flecha personalizada con `ChevronDown` de Lucide.

---

## 7. ListingCard

**Archivo:** `src/components/listing/ListingCard.tsx`

El componente central del catálogo. Se usa en: landing, /explorar, /favoritos, activos relacionados.

```ts
interface ListingCardProps {
  id: string
  title: string
  type: 'WEBSITE' | 'DOMAIN' | 'SAAS' | 'ECOMMERCE' | 'PROJECT'
  priceUsd: number
  screenshot?: string       // URL imagen o placeholder
  metrics: {
    mrr?: number            // mostrado como "$X MRR"
    monthlyVisits?: number  // "Xk visitas/mes"
    users?: number          // "X usuarios"
    orders?: number         // "X orders/mes"
    da?: number             // "DA X"
    age?: string            // "X meses online"
  }
  techStack?: string[]      // pills en font mono
  badges?: ('verified' | 'featured' | 'premium')[]
  isFavorited?: boolean
  onFavoriteToggle?: (id: string) => void
}
```

**Estructura interna de la card:**
```
┌──────────────────────────────┐
│ [screenshot 100% x 160px]    │  bg-slate-800, object-cover, rounded-t-xl
├──────────────────────────────┤
│ [badge tipo] [badge verified]│  row de badges
│ Título del Activo            │  text-lg font-semibold text-slate-50
│ $18,000 USD                  │  text-2xl font-bold text-amber-500
│ ─────────────────────────    │
│ 📈 $2,100 MRR  👥 1.2k usr  │  text-sm text-slate-400, 2 métricas max
│ [Next.js] [Stripe]           │  font-mono text-xs, bg-slate-800
│ [♡ Guardar] [Consultar →]   │  botones full-width outline/solid
└──────────────────────────────┘
```

**Hover:** `hover:border-amber-500/30 hover:shadow-lg hover:shadow-amber-500/5`

**Sin screenshot:** mostrar placeholder con gradiente `bg-gradient-to-br from-slate-800 to-slate-900` + logo Q centrado.

---

## 8. StatCard

**Archivo:** `src/components/ui/StatCard.tsx`

Usado en dashboards (vendedor, comprador, admin).

```ts
interface StatCardProps {
  label: string
  value: string | number
  icon: React.ReactNode
  trend?: { value: string; positive: boolean }  // "+12% este mes"
  pulse?: boolean   // dot pulsante amber (consultas activas)
  highlight?: boolean  // valor en amber (revenue total)
}
```

**Estructura:**
```
┌──────────────────────────┐
│ [ícono amber]  label     │  icon size-5, label text-sm text-slate-500
│ Valor grande             │  text-3xl font-bold text-slate-50
│ [▲ trend]                │  text-sm text-emerald-500 / text-red-400
└──────────────────────────┘
```

---

## 9. Sidebar

**Archivo:** `src/components/layout/Sidebar.tsx`

```ts
interface SidebarProps {
  variant: 'dashboard' | 'admin'
  activeItem: string
  user: { name: string; email: string; role: string; avatarInitials: string }
}
```

**Ancho:** `w-[280px] fixed left-0 top-0 h-screen`
**Fondo:** `bg-navy-950 border-r border-slate-800`

**Nav item inactivo:** `flex items-center gap-3 px-4 py-2.5 text-slate-400 rounded-lg hover:bg-slate-800 transition-colors`

**Nav item activo:**
```
relative flex items-center gap-3 px-4 py-2.5 text-amber-500
bg-amber-500/[0.08] rounded-lg
before:absolute before:left-0 before:inset-y-0 before:w-[3px]
before:bg-amber-500 before:rounded-r-sm
```

---

## 10. Navbar pública

**Archivo:** `src/components/layout/Navbar.tsx`

**Estructura:** `fixed top-0 left-0 right-0 z-50`
```
bg-navy-950/95 backdrop-blur-sm border-b border-slate-800 h-16
```

Interna: `max-w-7xl mx-auto px-6 flex items-center justify-between`

- Izquierda: Logo (`LogoQ` component)
- Centro: links `text-slate-400 hover:text-slate-50 text-sm transition-colors`
- Derecha: `<Button variant="outline" size="sm">Iniciar sesión</Button>` + `<Button variant="solid" size="sm">Registrate</Button>`

---

## 11. LogoQ

**Archivo:** `src/components/ui/LogoQ.tsx`

```ts
interface LogoQProps {
  size?: 'sm' | 'md' | 'lg'  // 32x32 | 40x40 | 64x64
  showText?: boolean           // muestra "qapitaliza" al lado
  adminBadge?: boolean         // muestra pill "Admin" amber
}
```

Cuadrado `bg-amber-500 rounded-lg` con letra `Q` en `text-navy-950 font-bold`.
Texto: `text-slate-50 font-semibold` al lado.

---

## 12. Modal

**Archivo:** `src/components/ui/Modal.tsx`

```ts
interface ModalProps {
  open: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'  // 400px | 600px | 800px
}
```

Overlay: `fixed inset-0 bg-black/60 backdrop-blur-sm z-50`
Panel: `bg-navy-900 border border-slate-800 rounded-xl shadow-2xl`

---

## 13. Estados obligatorios

Cada pantalla crítica DEBE implementar estos 4 estados:

| Estado | Componente sugerido | Cuándo |
|---|---|---|
| **Loading** | `<SkeletonCard />` / `<Loader2 animate-spin />` | Fetch de datos en curso |
| **Empty** | `<EmptyState icon title description cta />` | Lista sin resultados, sin favoritos |
| **Error** | `<ErrorState message retry />` | Fetch fallido, error de red |
| **Success** | Toast / inline con ícono `Check` verde | Submit de formulario exitoso |

**EmptyState example:** "No tenés activos publicados todavía" + botón "Publicar mi primer activo"
