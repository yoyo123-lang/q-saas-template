'use client'

import { useRef } from 'react'

const PRESET_COLORS = [
  '#FFFFFF', '#F8FAFC', '#F1F5F9', '#CBD5E1',
  '#1E293B', '#0F172A', '#020617', '#000000',
  '#EF4444', '#F97316', '#EAB308', '#22C55E',
  '#3B82F6', '#8B5CF6', '#EC4899', '#06B6D4',
]

export function ColorPickerInput({
  value,
  onChange,
  disabled,
}: {
  value: string
  onChange: (v: unknown) => void
  disabled: boolean
}) {
  const customRef = useRef<HTMLInputElement>(null)
  const isPreset = PRESET_COLORS.includes(value.toUpperCase()) || PRESET_COLORS.includes(value)

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-3" role="radiogroup" aria-label="Color de marca">
        {PRESET_COLORS.map((color) => {
          const selected = value.toLowerCase() === color.toLowerCase()
          return (
            <button
              key={color}
              type="button"
              role="radio"
              aria-checked={selected}
              aria-label={color}
              disabled={disabled}
              onClick={() => onChange(color)}
              style={{ backgroundColor: color }}
              className={`w-8 h-8 rounded-lg border-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                selected ? 'border-[#8B5CF6] scale-110 shadow-lg shadow-[#8B5CF6]/20' : 'border-[#1E293B] hover:border-[#334155]'
              }`}
            />
          )
        })}

        <button
          type="button"
          disabled={disabled}
          onClick={() => customRef.current?.click()}
          title="Color personalizado"
          aria-label="Elegir color personalizado"
          className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
            !isPreset && value ? 'border-[#8B5CF6] scale-110' : 'border-[#334155] hover:border-[#475569]'
          }`}
          style={!isPreset && value ? { backgroundColor: value } : { backgroundColor: '#0F172A' }}
        >
          {(isPreset || !value) && (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2" aria-hidden="true">
              <path d="M12 5v14M5 12h14" strokeLinecap="round" />
            </svg>
          )}
        </button>
      </div>

      <input
        ref={customRef}
        type="color"
        value={value || '#000000'}
        className="sr-only"
        aria-label="Selector de color personalizado"
        onChange={(e) => onChange(e.target.value)}
      />

      {value && (
        <div className="flex items-center gap-2">
          <div
            className="w-5 h-5 rounded border border-[#1E293B] flex-shrink-0"
            style={{ backgroundColor: value }}
            aria-hidden="true"
          />
          <span className="text-[#94A3B8] text-xs font-mono uppercase">{value}</span>
        </div>
      )}
    </div>
  )
}
