'use client'

import { useState } from 'react'

interface QuestionBlock {
  id: string
  question: string
  helpText?: string
  inputType: string
  skippable?: boolean
}

interface IndustryForMerge {
  id: string
  name: string
  questions: unknown
}

interface FlujoMergeadoSectionProps {
  agentNumber: number
  interviewPrompt: string | null
  industries: IndustryForMerge[]
}

function parseIndustryQuestions(
  questions: unknown,
  stageNumber: number,
): QuestionBlock[] {
  if (!questions || typeof questions !== 'object') return []

  const questionsMap = questions as Record<string, unknown>
  const stageQuestions = questionsMap[String(stageNumber)]

  if (!Array.isArray(stageQuestions)) return []

  return stageQuestions.filter(
    (q): q is QuestionBlock =>
      typeof q === 'object' &&
      q !== null &&
      typeof (q as Record<string, unknown>).id === 'string' &&
      typeof (q as Record<string, unknown>).question === 'string',
  )
}

function QuestionList({ questions }: { questions: QuestionBlock[] }) {
  if (questions.length === 0) {
    return (
      <p className="text-[#64748B] text-sm italic">Sin preguntas configuradas para este stage.</p>
    )
  }

  return (
    <ol className="flex flex-col gap-3">
      {questions.map((q, idx) => (
        <li key={q.id} className="flex gap-3">
          <span className="text-[#64748B] text-xs font-mono mt-0.5 min-w-[20px]">
            {idx + 1}.
          </span>
          <div className="flex flex-col gap-0.5">
            <p className="text-[#F8FAFC] text-sm">{q.question}</p>
            {q.helpText && (
              <p className="text-[#64748B] text-xs">{q.helpText}</p>
            )}
            <span className="text-[#475569] text-xs font-mono">{q.inputType}</span>
          </div>
        </li>
      ))}
    </ol>
  )
}

/**
 * Muestra el flujo mergeado entre el interview prompt del agente
 * y las preguntas específicas de una industria seleccionada.
 * Recibe la lista de industrias como prop desde el server component padre.
 */
export function FlujoMergeadoSection({
  agentNumber,
  interviewPrompt,
  industries,
}: FlujoMergeadoSectionProps) {
  const [selectedIndustryId, setSelectedIndustryId] = useState<string>('')

  const selectedIndustry = industries.find((i) => i.id === selectedIndustryId) ?? null

  const industryQuestions = selectedIndustry
    ? parseIndustryQuestions(selectedIndustry.questions, agentNumber)
    : []

  return (
    <div className="flex flex-col gap-5">
      {/* Selector de industria */}
      <div className="flex flex-col gap-2">
        <label htmlFor="industry-select" className="text-[#94A3B8] text-sm font-medium">
          Industria
        </label>
        {industries.length === 0 ? (
          <p className="text-[#64748B] text-sm">
            No hay industrias configuradas. Crear una en /industrias.
          </p>
        ) : (
          <select
            id="industry-select"
            value={selectedIndustryId}
            onChange={(e) => setSelectedIndustryId(e.target.value)}
            className="w-full max-w-xs bg-[#1E293B] text-[#F8FAFC] text-sm rounded-lg border border-[#334155] focus:border-[#8B5CF6] focus:outline-none px-4 py-2"
          >
            <option value="">Seleccionar industria…</option>
            {industries.map((industry) => (
              <option key={industry.id} value={industry.id}>
                {industry.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Vista mergeada */}
      {selectedIndustryId && (
        <div className="flex flex-col gap-4">
          {/* Card: preguntas base del agente */}
          <div className="flex flex-col gap-3 p-4 bg-[#0B0F1A] rounded-xl border border-[#1E293B]">
            <h3 className="text-[#94A3B8] text-xs font-semibold uppercase tracking-wider">
              Preguntas base del agente
            </h3>
            {interviewPrompt ? (
              <pre className="text-[#F8FAFC] text-sm font-mono whitespace-pre-wrap leading-relaxed">
                {interviewPrompt}
              </pre>
            ) : (
              <p className="text-[#64748B] text-sm italic">No configurado</p>
            )}
          </div>

          {/* Card: preguntas específicas de la industria */}
          <div className="flex flex-col gap-3 p-4 bg-[#0B0F1A] rounded-xl border border-[#1E293B]">
            <h3 className="text-[#94A3B8] text-xs font-semibold uppercase tracking-wider">
              Preguntas específicas — {selectedIndustry?.name}
            </h3>
            <QuestionList questions={industryQuestions} />
          </div>

          {/* Nota informativa */}
          <p className="text-[#64748B] text-xs bg-[#0F172A] rounded-lg border border-[#1E293B] px-4 py-3">
            En la entrevista real, ambos conjuntos se combinan para el cliente. Las preguntas del
            agente definen la estructura base; las de la industria añaden contexto específico del
            rubro.
          </p>
        </div>
      )}
    </div>
  )
}
