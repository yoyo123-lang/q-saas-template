import type { Metadata } from 'next'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import { ImportButton } from './_import-button'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Importar template | Qautiva Admin' }

interface CatalogTemplate {
  slug: string
  name: string
  description?: string
  thumbnail?: string
  compatibleIndustries?: string[]
}

/** Normaliza la URL del catálogo: agrega https:// si no tiene protocolo. */
function normalizeCatalogUrl(raw: string): string {
  return /^https?:\/\//i.test(raw) ? raw : `https://${raw}`
}

async function fetchCatalogTemplates(): Promise<CatalogTemplate[] | null> {
  const rawCatalogUrl = process.env.TEMPLATES_CATALOG_URL
  if (!rawCatalogUrl) {
    console.error('[importar/page] TEMPLATES_CATALOG_URL no configurada')
    return null
  }

  const catalogUrl = normalizeCatalogUrl(rawCatalogUrl)

  try {
    const response = await fetch(`${catalogUrl}/api/templates`, {
      signal: AbortSignal.timeout(5_000),
      next: { revalidate: 300 },  // cachear catálogo 5 min, DB local siempre fresh
    })

    if (!response.ok) {
      console.error('[importar/page] catálogo respondió HTTP', response.status, 'url:', catalogUrl)
      return null
    }

    const data = await response.json() as unknown
    // Aceptar tanto array directo como { templates: [...] }
    const list = Array.isArray(data)
      ? data
      : (data !== null && typeof data === 'object' && 'templates' in (data as object) && Array.isArray((data as Record<string, unknown>).templates))
        ? (data as Record<string, unknown>).templates as unknown[]
        : null
    if (!list) {
      console.error('[importar/page] catálogo respondió formato inesperado', JSON.stringify(data).slice(0, 200))
      return null
    }
    return list as CatalogTemplate[]
  } catch (err) {
    console.error('[importar/page] error al fetch catálogo', err)
    return null
  }
}

export default async function ImportarTemplatePage() {
  const [templates, localTemplates] = await Promise.all([
    fetchCatalogTemplates(),
    prisma.webTemplate.findMany({ select: { name: true } }),
  ])

  // Set de nombres ya importados para comparación rápida
  const importedNames = new Set(localTemplates.map((t) => t.name))

  return (
    <div className="p-8 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link
            href="/templates"
            className="inline-flex items-center gap-1 text-sm text-[#64748B] hover:text-[#94A3B8] mb-2 transition-colors"
          >
            ← Templates web
          </Link>
          <h1 className="text-2xl font-bold text-white">Importar desde catálogo</h1>
          <p className="text-[#64748B] text-sm mt-1">
            Elegí un template del catálogo y se importa como borrador listo para editar.
          </p>
        </div>
      </div>

      {/* Error de configuración */}
      {templates === null && (
        <div className="border border-red-900/50 bg-red-950/20 rounded-lg p-6 text-center">
          <p className="text-red-400 text-sm font-medium">No se pudo conectar al catálogo de templates.</p>
          <p className="text-[#64748B] text-xs mt-1">
            Verificá que <code className="text-[#94A3B8]">TEMPLATES_CATALOG_URL</code> esté configurada y el servicio esté activo.
          </p>
        </div>
      )}

      {/* Lista vacía */}
      {templates !== null && templates.length === 0 && (
        <div className="border border-[#1E293B] rounded-lg p-12 text-center">
          <p className="text-[#64748B] text-sm">El catálogo no tiene templates disponibles todavía.</p>
        </div>
      )}

      {/* Grid de templates */}
      {templates !== null && templates.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map((template) => {
            const industries = Array.isArray(template.compatibleIndustries)
              ? template.compatibleIndustries
              : []
            const isImported = importedNames.has(template.name)
            return (
              <div
                key={template.slug}
                className="border border-[#1E293B] rounded-lg bg-[#0F172A] overflow-hidden flex flex-col"
              >
                {/* Thumbnail */}
                {template.thumbnail ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={template.thumbnail}
                    alt={template.name}
                    loading="lazy"
                    className="w-full h-40 object-cover"
                  />
                ) : (
                  <div className="w-full h-40 bg-[#0B0F1A] flex items-center justify-center">
                    <span className="text-[#475569] text-xs">Sin preview</span>
                  </div>
                )}

                {/* Contenido */}
                <div className="p-4 flex flex-col gap-3 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h2 className="text-white font-medium text-sm">{template.name}</h2>
                      {template.description && (
                        <p className="text-[#64748B] text-xs mt-0.5 line-clamp-2">{template.description}</p>
                      )}
                    </div>
                    {isImported && (
                      <span className="shrink-0 px-2 py-0.5 bg-green-400/10 text-green-400 text-xs rounded-full font-medium">
                        Importado
                      </span>
                    )}
                  </div>

                  {industries.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {industries.slice(0, 3).map((ind) => (
                        <span
                          key={ind}
                          className="px-2 py-0.5 bg-[#1E293B] text-[#94A3B8] text-xs rounded-full"
                        >
                          {ind}
                        </span>
                      ))}
                      {industries.length > 3 && (
                        <span className="text-[#64748B] text-xs self-center">+{industries.length - 3}</span>
                      )}
                    </div>
                  )}

                  <div className="mt-auto">
                    {isImported ? (
                      <Link
                        href="/templates"
                        className="block w-full px-3 py-1.5 bg-[#1E293B] text-[#94A3B8] text-xs font-medium rounded-lg text-center hover:text-white transition-colors"
                      >
                        Ver en mis templates
                      </Link>
                    ) : (
                      <ImportButton slug={template.slug} />
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
