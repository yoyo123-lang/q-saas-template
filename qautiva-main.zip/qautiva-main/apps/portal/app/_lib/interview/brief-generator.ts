import { executeToolCall, type BillingContext, type ToolDefinition } from './ai-tool-call'
import type { QuestionBlock, StrategicBrief } from './types'

// ── Tool definition ───────────────────────────────────────────────────────────

/**
 * Tool que fuerza al modelo a devolver el StrategicBrief como JSON estructurado.
 * Compatible con Anthropic tool_use y OpenAI function calling.
 */
const GENERATE_BRIEF_TOOL: ToolDefinition = {
  name: 'generate_brief',
  description:
    'Genera el Brief Estratégico completo a partir de toda la información recopilada en la entrevista.',
  input_schema: {
    type: 'object' as const,
    additionalProperties: false,
    properties: {
      negocio: {
        type: 'object',
        additionalProperties: false,
        properties: {
          descripcion: { type: 'string' },
          estado: { type: 'string', enum: ['operando', 'lanzamiento', 'pivoteando'] },
          antiguedad: { type: ['string', 'null'] },
          recursosDisponibles: { type: 'string' },
          restricciones: { type: 'array', items: { type: 'string' } },
        },
        required: ['descripcion', 'estado', 'antiguedad', 'recursosDisponibles', 'restricciones'],
      },
      mercado: {
        type: 'object',
        additionalProperties: false,
        properties: {
          zonaGeografica: { type: 'string' },
          alcance: { type: 'string' },
          competidores: {
            type: 'array',
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                nombre: { type: 'string' },
                fortaleza: { type: 'string' },
                debilidad: { type: 'string' },
              },
              required: ['nombre', 'fortaleza', 'debilidad'],
            },
          },
          espaciosVacios: { type: 'array', items: { type: 'string' } },
          tendencias: { type: 'array', items: { type: 'string' } },
        },
        required: ['zonaGeografica', 'alcance', 'competidores', 'espaciosVacios', 'tendencias'],
      },
      audiencia: {
        type: 'object',
        additionalProperties: false,
        properties: {
          perfilCliente: { type: 'string' },
          comoCompra: { type: 'string' },
          dolorPrincipal: { type: 'string' },
          canalAdquisicion: { type: 'string' },
        },
        required: ['perfilCliente', 'comoCompra', 'dolorPrincipal', 'canalAdquisicion'],
      },
      posicionamiento: {
        type: 'object',
        additionalProperties: false,
        properties: {
          estrategia: {
            type: 'string',
            enum: ['bajo_costo', 'diferenciacion', 'enfoque'],
          },
          nichoEspecifico: { type: 'string' },
          ventajaCompetitiva: { type: 'string' },
          riesgos: { type: 'array', items: { type: 'string' } },
          justificacion: { type: 'string' },
        },
        required: [
          'estrategia',
          'nichoEspecifico',
          'ventajaCompetitiva',
          'riesgos',
          'justificacion',
        ],
      },
      direccionComunicacional: {
        type: 'object',
        additionalProperties: false,
        properties: {
          mensajeCentral: { type: 'string' },
          tonoSugerido: { type: 'string' },
          territoriosTematicos: { type: 'array', items: { type: 'string' } },
          queNoDecir: { type: 'array', items: { type: 'string' } },
          rangoPrecios: { type: 'string' },
        },
        required: [
          'mensajeCentral',
          'tonoSugerido',
          'territoriosTematicos',
          'queNoDecir',
          'rangoPrecios',
        ],
      },
      decisionesPendientes: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            tema: { type: 'string' },
            opciones: {
              type: 'array',
              items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  opcion: { type: 'string' },
                  pro: { type: 'string' },
                  contra: { type: 'string' },
                },
                required: ['opcion', 'pro', 'contra'],
              },
            },
          },
          required: ['tema', 'opciones'],
        },
      },
    },
    required: [
      'negocio',
      'mercado',
      'audiencia',
      'posicionamiento',
      'direccionComunicacional',
      'decisionesPendientes',
    ],
  },
}

// ── Prompt de síntesis ────────────────────────────────────────────────────────

const SYNTHESIS_SYSTEM_PROMPT = `Sos El Estratega de Qautiva. Acabás de completar una entrevista de descubrimiento con un cliente.

Tu tarea es sintetizar toda la información recopilada en un Brief Estratégico estructurado y accionable.

Instrucciones:
1. Basate en la información que el cliente proporcionó — no inventes datos
2. Para campos donde la información no es completa, inferí conservadoramente desde lo que sí tenés
3. Para el posicionamiento, elegí UNA estrategia de las tres (bajo_costo, diferenciacion, enfoque) con evidencia concreta de las respuestas. No elijas "diferenciacion" por default — analizá realmente cuál le sirve más a este negocio
4. La ventaja competitiva debe ser algo que la competencia no pueda copiar fácilmente en el corto plazo
5. Las decisionesPendientes son puntos donde el cliente debe decidir — presentá exactamente 2-3 opciones con pros/contras, no hagas la decisión por él
6. El mensajeCentral debe ser una frase corta (máx 10 palabras) que un cliente podría recordar

Acción: Llamá a generate_brief con el Brief Estratégico completo.`

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Genera el StrategicBrief a partir de las respuestas de la entrevista.
 * Usa el provider/modelo configurado en TrialConfig (admin panel).
 *
 * @param flowDefinition - Preguntas de la entrevista (para contexto)
 * @param answers - Respuestas del usuario { questionId: value }
 * @returns StrategicBrief estructurado
 * @throws Error si el modelo falla o no devuelve el output esperado
 */
export async function generateStrategicBrief(
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
  billingContext?: BillingContext,
): Promise<StrategicBrief> {
  const interviewContent = buildInterviewSummary(flowDefinition, answers)

  const result = await executeToolCall({
    system: SYNTHESIS_SYSTEM_PROMPT,
    userMessage: `Acá está la transcripción completa de la entrevista:\n\n${interviewContent}\n\nGenerá el Brief Estratégico.`,
    tool: GENERATE_BRIEF_TOOL,
    maxTokens: 16384,
    logPrefix: 'brief-generator',
    billingContext: billingContext ? { ...billingContext, operation: 'brief_generation' } : undefined,
  })

  return validateStrategicBrief(result.input)
}

// ── Validación runtime ────────────────────────────────────────────────────────

/**
 * Valida que el output del modelo tenga la estructura esperada de StrategicBrief.
 * Lanza Error descriptivo si falta algún campo estructural.
 * Patrón idéntico a validateMarketStudy en market-study-generator.ts.
 */
function validateStrategicBrief(raw: unknown): StrategicBrief {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error('[brief-generator] Output no es un objeto')
  }
  const obj = raw as Record<string, unknown>

  // ── negocio ──
  if (typeof obj['negocio'] !== 'object' || obj['negocio'] === null) {
    throw new Error('[brief-generator] Falta negocio')
  }
  const negocio = obj['negocio'] as Record<string, unknown>
  if (typeof negocio['descripcion'] !== 'string') {
    throw new Error('[brief-generator] negocio.descripcion debe ser string')
  }
  if (!Array.isArray(negocio['restricciones'])) {
    throw new Error('[brief-generator] negocio.restricciones debe ser array')
  }

  // ── mercado ──
  if (typeof obj['mercado'] !== 'object' || obj['mercado'] === null) {
    throw new Error('[brief-generator] Falta mercado')
  }
  const mercado = obj['mercado'] as Record<string, unknown>
  if (!Array.isArray(mercado['competidores'])) {
    throw new Error('[brief-generator] mercado.competidores debe ser array')
  }
  for (const c of mercado['competidores'] as unknown[]) {
    if (typeof c !== 'object' || c === null) {
      throw new Error('[brief-generator] mercado.competidores[*] debe ser objeto')
    }
    const comp = c as Record<string, unknown>
    if (typeof comp['nombre'] !== 'string') {
      throw new Error('[brief-generator] mercado.competidores[*].nombre debe ser string')
    }
  }
  if (!Array.isArray(mercado['espaciosVacios'])) {
    throw new Error('[brief-generator] mercado.espaciosVacios debe ser array')
  }
  if (!Array.isArray(mercado['tendencias'])) {
    throw new Error('[brief-generator] mercado.tendencias debe ser array')
  }

  // ── audiencia ──
  if (typeof obj['audiencia'] !== 'object' || obj['audiencia'] === null) {
    throw new Error('[brief-generator] Falta audiencia')
  }
  const audiencia = obj['audiencia'] as Record<string, unknown>
  if (typeof audiencia['perfilCliente'] !== 'string') {
    throw new Error('[brief-generator] audiencia.perfilCliente debe ser string')
  }

  // ── posicionamiento ──
  if (typeof obj['posicionamiento'] !== 'object' || obj['posicionamiento'] === null) {
    throw new Error('[brief-generator] Falta posicionamiento')
  }
  const pos = obj['posicionamiento'] as Record<string, unknown>
  if (typeof pos['estrategia'] !== 'string') {
    throw new Error('[brief-generator] posicionamiento.estrategia debe ser string')
  }
  if (!Array.isArray(pos['riesgos'])) {
    throw new Error('[brief-generator] posicionamiento.riesgos debe ser array')
  }

  // ── direccionComunicacional ──
  if (typeof obj['direccionComunicacional'] !== 'object' || obj['direccionComunicacional'] === null) {
    throw new Error('[brief-generator] Falta direccionComunicacional')
  }
  const dir = obj['direccionComunicacional'] as Record<string, unknown>
  if (typeof dir['mensajeCentral'] !== 'string') {
    throw new Error('[brief-generator] direccionComunicacional.mensajeCentral debe ser string')
  }
  if (!Array.isArray(dir['territoriosTematicos'])) {
    throw new Error('[brief-generator] direccionComunicacional.territoriosTematicos debe ser array')
  }
  if (!Array.isArray(dir['queNoDecir'])) {
    throw new Error('[brief-generator] direccionComunicacional.queNoDecir debe ser array')
  }

  // ── decisionesPendientes ──
  if (!Array.isArray(obj['decisionesPendientes'])) {
    throw new Error('[brief-generator] decisionesPendientes debe ser array')
  }
  for (const d of obj['decisionesPendientes'] as unknown[]) {
    if (typeof d !== 'object' || d === null) {
      throw new Error('[brief-generator] decisionesPendientes[*] debe ser objeto')
    }
    const dec = d as Record<string, unknown>
    if (typeof dec['tema'] !== 'string') {
      throw new Error('[brief-generator] decisionesPendientes[*].tema debe ser string')
    }
    if (!Array.isArray(dec['opciones'])) {
      throw new Error('[brief-generator] decisionesPendientes[*].opciones debe ser array')
    }
  }

  return raw as StrategicBrief
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Convierte flowDefinition + answers en texto legible para el prompt de síntesis.
 * Compartida entre brief-generator y market-study-generator.
 */
export function buildInterviewSummary(
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
): string {
  if (flowDefinition.length === 0) {
    return '(Sin preguntas registradas)'
  }

  return flowDefinition
    .map((q, i) => {
      const answer = answers[q.id]
      const answerText =
        answer === undefined
          ? '(sin respuesta)'
          : typeof answer === 'string'
            ? answer
            : JSON.stringify(answer)
      return `Pregunta ${i + 1}: ${q.question}\nRespuesta: ${answerText}`
    })
    .join('\n\n')
}
