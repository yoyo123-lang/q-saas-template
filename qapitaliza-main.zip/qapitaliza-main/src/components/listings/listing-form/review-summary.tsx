'use client'

import { Badge } from '@/components/ui/badge'
import { typeLabels } from '@/lib/constants/listing-labels'
import type { CreateListingInput } from '@/lib/schemas/listing'

interface ReviewSummaryProps {
  data: Partial<CreateListingInput>
}

export function ReviewSummary({ data }: ReviewSummaryProps) {
  return (
    <div className="space-y-4">
      <div className="bg-navy-950 border border-slate-800 rounded-xl p-5 space-y-2">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Información básica</h3>
        <p className="text-base font-semibold text-slate-50">{data.title || '—'}</p>
        <div className="flex gap-2 flex-wrap">
          {data.type && <Badge variant="info">{typeLabels[data.type]}</Badge>}
          <span className="text-sm text-amber-500 font-semibold">
            ${data.askingPrice?.toLocaleString()} {data.currency ?? 'USD'}
          </span>
        </div>
        {data.url && (
          <p className="text-xs text-slate-500">URL: {data.url}</p>
        )}
        {data.description && (
          <p className="text-sm text-slate-400 line-clamp-3">{data.description}</p>
        )}
        {(data.techStack ?? []).length > 0 && (
          <div className="flex flex-wrap gap-1 pt-1">
            {(data.techStack ?? []).map((t) => (
              <span key={t} className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">{t}</span>
            ))}
          </div>
        )}
      </div>

      {(data.screenshotUrls ?? []).length > 0 && (
        <div className="bg-navy-950 border border-slate-800 rounded-xl p-5 space-y-2">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Imágenes</h3>
          <div className="flex gap-2 flex-wrap">
            {(data.screenshotUrls ?? []).map((url, i) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img key={i} src={url} alt="" className="size-16 rounded-lg object-cover" />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
