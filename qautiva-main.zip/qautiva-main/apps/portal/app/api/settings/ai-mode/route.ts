import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { getTeamForUser } from '@/app/_lib/get-team-for-user'

const VALID_SOURCES = ['BYOK', 'QAUTIVA_HOSTED'] as const
type KeySource = (typeof VALID_SOURCES)[number]

/**
 * PATCH /api/settings/ai-mode
 * Cambia la fuente de API keys preferida del equipo (BYOK / QAUTIVA_HOSTED).
 * Si cambia a BYOK, verifica que el equipo tenga al menos una key válida.
 */
export async function PATCH(request: Request) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const team = await getTeamForUser(user.id)
  if (!team) {
    return NextResponse.json({ error: 'No se encontró el equipo' }, { status: 404 })
  }

  // Guard de permisos: solo ADMIN y OWNER pueden cambiar el modo de IA
  if (!['ADMIN', 'OWNER'].includes(team.teamRole)) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden cambiar la configuración de IA.' },
      { status: 403 },
    )
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const preferredKeySource = body.preferredKeySource as string | undefined

  if (!preferredKeySource || !(VALID_SOURCES as readonly string[]).includes(preferredKeySource)) {
    return NextResponse.json(
      { error: 'preferredKeySource inválido. Valores válidos: BYOK, QAUTIVA_HOSTED' },
      { status: 400 },
    )
  }

  // Si cambia a BYOK, verificar que tenga keys válidas
  if (preferredKeySource === 'BYOK') {
    const validKeyCount = await prisma.apiKey.count({
      where: { teamId: team.teamId, isValid: true },
    })
    if (validKeyCount === 0) {
      return NextResponse.json(
        { error: 'Necesitás agregar al menos una API key válida antes de cambiar a modo BYOK' },
        { status: 400 },
      )
    }
  }

  const billing = await prisma.billingAccount.findUnique({
    where: { teamId: team.teamId },
    select: { id: true, plan: true },
  })

  if (!billing) {
    return NextResponse.json({ error: 'No se encontró la cuenta de facturación' }, { status: 404 })
  }

  // Bloquear el cambio a BYOK en planes FREE_TRIAL
  if (preferredKeySource === 'BYOK' && billing.plan === 'FREE_TRIAL') {
    return NextResponse.json(
      { error: 'Los planes de prueba no pueden usar claves API propias. Actualizá tu plan para acceder a esta funcionalidad.' },
      { status: 403 },
    )
  }

  await prisma.billingAccount.update({
    where: { teamId: team.teamId },
    data: { preferredKeySource: preferredKeySource as KeySource },
  })

  revalidatePath('/configuracion')

  return NextResponse.json({ ok: true, preferredKeySource })
}
