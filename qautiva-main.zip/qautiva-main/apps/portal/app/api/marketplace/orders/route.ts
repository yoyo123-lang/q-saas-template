import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { OrderStatus, Prisma } from '@qautiva/db'
import {
  getProfileOrUnauthorized,
  serializeOrder,
  filterOrderByRole,
  isValidHttpUrl,
  ORDER_RESPONSE_SELECT,
  ORDER_RESPONSE_SELECT_ADVERTISER,
  ORDER_RESPONSE_SELECT_EDITOR,
} from '@/lib/api/marketplace-helpers'

// ── GET /api/marketplace/orders ───────────────────────────────────────────────
// Lista órdenes del usuario autenticado como anunciante y/o editor.
// ?role=advertiser  → solo órdenes donde el usuario es el anunciante
// ?role=editor      → solo órdenes donde el usuario es editor del medio
// Sin role          → ambos roles (OR)
// ?status=PENDING   → filtrar por estado

export async function GET(request: NextRequest): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  const sp = request.nextUrl.searchParams
  const role = sp.get('role')
  const statusParam = sp.get('status')

  const pageRaw = parseInt(sp.get('page') ?? '1', 10)
  const takeRaw = parseInt(sp.get('take') ?? '20', 10)
  if (isNaN(pageRaw) || isNaN(takeRaw)) {
    return NextResponse.json({ error: 'page y take deben ser números enteros' }, { status: 400 })
  }
  const page = Math.max(1, pageRaw)
  const take = Math.min(50, Math.max(1, takeRaw))

  if (role && !['advertiser', 'editor'].includes(role)) {
    return NextResponse.json({ error: 'role debe ser "advertiser" o "editor"' }, { status: 400 })
  }
  if (statusParam && !Object.values(OrderStatus).includes(statusParam as OrderStatus)) {
    return NextResponse.json({ error: 'Estado inválido' }, { status: 400 })
  }

  const statusFilter = statusParam ? { status: statusParam as OrderStatus } : {}

  let roleFilter: Prisma.OrderWhereInput
  if (role === 'advertiser') {
    roleFilter = { advertiserId: profile.id }
  } else if (role === 'editor') {
    roleFilter = { medium: { userId: profile.id } }
  } else {
    roleFilter = { OR: [{ advertiserId: profile.id }, { medium: { userId: profile.id } }] }
  }

  const where: Prisma.OrderWhereInput = { ...roleFilter, ...statusFilter }

  // Campos financieros diferenciados por rol:
  // - advertiser: sin commission ni editorPayout (no exponemos el margen de la plataforma)
  // - editor: con editorPayout (lo que va a cobrar), sin commission
  // - ambos (no role): traemos el select completo y filtramos por orden según advertiserId
  const selectByRole =
    role === 'advertiser'
      ? ORDER_RESPONSE_SELECT_ADVERTISER
      : role === 'editor'
        ? ORDER_RESPONSE_SELECT_EDITOR
        : ORDER_RESPONSE_SELECT

  try {
    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        select: selectByRole,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * take,
        take,
      }),
      prisma.order.count({ where }),
    ])

    console.info('[GET /api/marketplace/orders]', { reqId, userId: profile.id, role, total })

    const serialized = orders.map((o: typeof orders[number]) => {
      const s = serializeOrder(o as Parameters<typeof serializeOrder>[0])
      // Para el caso "ambos roles": si el usuario es solo anunciante en esta orden
      // (no es el editor del medio), eliminamos los campos internos de la plataforma.
      if (!role && (o as unknown as { advertiserId: string }).advertiserId === profile.id) {
        return filterOrderByRole(s, 'advertiser')
      }
      return s
    })

    return NextResponse.json({
      orders: serialized,
      pagination: { page, take, total, pages: Math.ceil(total / take) },
    })
  } catch (err) {
    console.error('[GET /api/marketplace/orders] Prisma query failed', {
      reqId,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al obtener las órdenes' }, { status: 500 })
  }
}

// ── POST /api/marketplace/orders ──────────────────────────────────────────────
// El anunciante autenticado crea una orden sobre un producto activo.
// El precio se toma del producto en DB (snapshot) — nunca del body.
// Calcula commission (10%) y editorPayout automáticamente.
// expiresAt = now + 3 días (el editor tiene ese tiempo para aceptar).

type CreateOrderBody = {
  productId: string
  brief: string
  targetUrl?: string
  anchorText?: string
}

const COMMISSION_RATE = new Prisma.Decimal('0.10')
const ORDER_EXPIRY_DAYS = 3

export async function POST(request: NextRequest): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: CreateOrderBody
  try {
    body = (await request.json()) as CreateOrderBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { productId, brief, targetUrl, anchorText } = body

  if (!productId || typeof productId !== 'string') {
    return NextResponse.json({ error: 'El campo productId es requerido' }, { status: 400 })
  }
  if (!brief || typeof brief !== 'string' || brief.trim().length < 10) {
    return NextResponse.json({ error: 'El brief debe tener al menos 10 caracteres' }, { status: 400 })
  }
  if (brief.trim().length > 5000) {
    return NextResponse.json({ error: 'El brief no puede superar los 5000 caracteres' }, { status: 400 })
  }
  if (targetUrl !== undefined && targetUrl.trim() && !isValidHttpUrl(targetUrl.trim())) {
    return NextResponse.json({ error: 'targetUrl debe ser una URL válida (http/https)' }, { status: 400 })
  }
  if (anchorText && anchorText.length > 200) {
    return NextResponse.json({ error: 'El anchorText no puede superar los 200 caracteres' }, { status: 400 })
  }

  // Buscar el producto con su medio para validar disponibilidad
  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: {
      id: true,
      mediumId: true,
      price: true,
      deliveryDays: true,
      active: true,
      medium: {
        select: { id: true, userId: true, deletedAt: true, status: true },
      },
    },
  })

  if (!product || product.medium.deletedAt !== null) {
    return NextResponse.json({ error: 'Producto no encontrado' }, { status: 404 })
  }
  if (!product.active) {
    return NextResponse.json({ error: 'El producto no está disponible' }, { status: 409 })
  }
  if (product.medium.status !== 'ACTIVE') {
    return NextResponse.json({ error: 'El medio no está activo' }, { status: 409 })
  }
  // Precio nunca puede ser 0 o negativo (protección ante datos corruptos)
  if (!product.price.greaterThan(0)) {
    return NextResponse.json({ error: 'El producto no tiene un precio válido' }, { status: 409 })
  }
  // El editor no puede comprarse a sí mismo
  if (product.medium.userId === profile.id) {
    return NextResponse.json({ error: 'No podés comprar tu propio producto' }, { status: 409 })
  }

  // Cálculos financieros — Decimal para precisión exacta
  const price = product.price
  const commission = price.mul(COMMISSION_RATE).toDecimalPlaces(2)
  const editorPayout = price.sub(commission)

  const now = new Date()
  const expiresAt = new Date(now)
  expiresAt.setDate(expiresAt.getDate() + ORDER_EXPIRY_DAYS)

  try {
    // Protección contra doble submit dentro de una transacción serializable:
    // el findFirst y el create son atómicos — dos requests concurrentes no pueden
    // pasar ambas el check y crear dos órdenes PENDING para el mismo producto.
    const order = await prisma.$transaction(
      async (tx: Prisma.TransactionClient) => {
        const existing = await tx.order.findFirst({
          where: { advertiserId: profile.id, productId: product.id, status: OrderStatus.PENDING },
          select: { id: true },
        })
        if (existing) {
          throw Object.assign(
            new Error('Ya tenés una orden pendiente para este producto'),
            { code: 'DUPLICATE_PENDING', orderId: existing.id },
          )
        }

        return tx.order.create({
          data: {
            advertiserId: profile.id,
            mediumId: product.mediumId,
            productId: product.id,
            brief: brief.trim(),
            targetUrl: targetUrl?.trim() || null,
            anchorText: anchorText?.trim() || null,
            price,
            commission,
            editorPayout,
            expiresAt,
          },
          select: ORDER_RESPONSE_SELECT,
        })
      },
      { isolationLevel: 'Serializable' },
    )

    console.info('[POST /api/marketplace/orders]', {
      reqId,
      orderId: order.id,
      advertiserId: profile.id,
      mediumId: product.mediumId,
      price: price.toNumber(),
    })

    return NextResponse.json({ order: serializeOrder(order) }, { status: 201 })
  } catch (err) {
    if (err instanceof Error && (err as Error & { code?: string }).code === 'DUPLICATE_PENDING') {
      return NextResponse.json(
        { error: err.message, orderId: (err as Error & { orderId?: string }).orderId },
        { status: 409 },
      )
    }
    console.error('[POST /api/marketplace/orders] Prisma create failed', {
      reqId,
      advertiserId: profile.id,
      productId,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al crear la orden' }, { status: 500 })
  }
}
