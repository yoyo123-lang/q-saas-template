# Informe de Revisión — ROL 3: Security Auditor
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol 3 - Security Auditor

---

## Resumen ejecutivo

Las páginas públicas no exponen endpoints de escritura directos. Los datos se obtienen solo via SSR con queries parametrizadas. Se detectaron un hallazgo medio de infraestructura y uno bajo de UX/seguridad.

---

## Hallazgos

### [MEDIO] No hay rate limiting propio en las páginas públicas

**Contexto:** El BUSINESS_MODEL.md especifica 60 req/min en el catálogo. Las páginas públicas actuales no tienen middleware de rate limiting propio.

**Estado:** No implementado en esta sesión — requiere middleware de Next.js o solución de infraestructura (Vercel Edge, Cloudflare). Reportado como hallazgo para Etapa 7 (pre-deploy).

**Mitigación actual:** Las páginas son todas de lectura. Un ataque de rate abuse incrementaría viewCounts pero no modificaría datos sensibles. La cookie de deduplicación en `/explorar/[slug]` reduce el impacto en el contador de vistas.

---

### [BAJO → CORREGIDO] Botón de favorito no redirige a /login sin sesión

**Archivo:** `src/components/listings/listing-card.tsx`

**Problema original:** El botón de favorito llamaba `onFavoriteToggle?.(id)` — si no había handler, el click no hacía nada visible ni útil para el usuario.

**Fix aplicado:** El componente usa renderizado condicional: si `onFavoriteToggle` está definido, renderiza un `<button>` funcional; si no, renderiza un `<Link href="/login">` que redirige al login.

---

## Puntos positivos

- Queries parametrizadas via Prisma ORM en todas las consultas — sin SQL injection posible.
- `incrementListingViews` es server-only, no expuesto a clientes.
- `robots.ts` correctamente bloquea `/api/`, `/dashboard/`, `/admin/`.
- No se exponen IDs internos en URLs — se usa `slug`.
- Stack traces nunca llegan al cliente — errores capturados en SSR.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| Sin rate limiting en catálogo | MEDIO | Pendiente Etapa 7 |
| Favorito sin redirect a /login | BAJO | Corregido |
