import { prisma } from "./db";

/**
 * Modelos que tienen organizationId como campo de multi-tenancy.
 * User, Account, Session, VerificationToken, AllowedEmail y Plan NO tienen organizationId.
 * Organization no se incluye porque es la raíz del tenant (no tiene organizationId propio).
 * Para acceder a la org propia: prisma.organization.findUnique({ where: { id: organizationId } })
 */
export const TENANT_SCOPED_MODELS = new Set([
  "membership",
  "subscription",
  "category",
  "product",
  "productVariant",
  "priceList",
  "priceListItem",
  "contact",
  "invoice",
  "invoiceItem",
  "sale",
  "saleItem",
  "warehouse",
  "stockMovement",
  "cashRegister",
  "paymentRecord",
]);

/**
 * Retorna un objeto where con organizationId inyectado.
 * El organizationId del tenant siempre sobreescribe cualquier valor previo,
 * para evitar que un caller inyecte un tenant distinto.
 *
 * @param organizationId - ID de la organización (tenant)
 * @param where - Condiciones adicionales del query (opcional)
 */
export function applyTenantFilter<T extends Record<string, unknown>>(
  organizationId: string,
  where?: T
): T & { organizationId: string } {
  return { ...(where ?? {}), organizationId } as T & { organizationId: string };
}

/** Cache de clientes extendidos por organizationId (evita crear un Proxy por cada request). */
const tenantClientCache = new Map<string, ReturnType<typeof buildTenantClient>>();

function buildTenantClient(organizationId: string) {
  return prisma.$extends({
    query: {
      $allModels: {
        // --- Operaciones de lectura ---

        async findMany({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async findFirst({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async findFirstOrThrow({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        /**
         * findUnique: inyectamos organizationId en el where para evitar IDOR.
         * Prisma evalúa el campo extra como filtro adicional post-lookup:
         * si el registro existe pero pertenece a otro tenant, retorna null.
         */
        async findUnique({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async findUniqueOrThrow({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async count({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async aggregate({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },

        // --- Operaciones de escritura ---

        /** create: inyecta organizationId en data para evitar registros sin tenant. */
        async create({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.data = { ...(args.data as Record<string, unknown>), organizationId };
          }
          return query(args);
        },
        async createMany({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            if (Array.isArray(args.data)) {
              args.data = args.data.map((item) => ({
                ...(item as Record<string, unknown>),
                organizationId,
              }));
            } else {
              args.data = { ...(args.data as Record<string, unknown>), organizationId };
            }
          }
          return query(args);
        },
        /** update: inyecta organizationId en where para prevenir cross-tenant writes. */
        async update({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async updateMany({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        /** delete: inyecta organizationId en where para prevenir cross-tenant deletes. */
        async delete({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async deleteMany({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
          }
          return query(args);
        },
        async upsert({ model, args, query }) {
          if (TENANT_SCOPED_MODELS.has(model)) {
            args.where = applyTenantFilter(organizationId, args.where as Record<string, unknown>);
            args.create = { ...(args.create as Record<string, unknown>), organizationId };
          }
          return query(args);
        },
      },
    },
  });
}

/**
 * Retorna un Prisma Client extendido que inyecta automáticamente
 * `organizationId` en todos los queries y mutaciones de modelos tenant-scoped.
 *
 * Cubre: findMany, findFirst, findUnique (+OrThrow), count, aggregate,
 *        create, createMany, update, updateMany, delete, deleteMany, upsert.
 *
 * Uso:
 *   const db = withTenant(session.organizationId)
 *   const products = await db.product.findMany({ where: { isActive: true } })
 *   // Ejecuta: WHERE organizationId = '...' AND isActive = true
 *
 * @param organizationId - ID de la organización activa en la request
 * @throws {Error} si organizationId es falsy
 */
export function withTenant(organizationId: string) {
  if (!organizationId) {
    throw new Error("withTenant: organizationId es requerido y no puede estar vacío");
  }

  const cached = tenantClientCache.get(organizationId);
  if (cached) return cached;

  const client = buildTenantClient(organizationId);
  tenantClientCache.set(organizationId, client);
  return client;
}
