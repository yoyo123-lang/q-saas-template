export const statusBadgeVariant: Record<string, 'success' | 'amber' | 'muted' | 'danger' | 'info'> = {
  PUBLISHED: 'success',
  PENDING_REVIEW: 'amber',
  FEATURED: 'amber',
  DRAFT: 'muted',
  REJECTED: 'danger',
  SOLD: 'info',
  PAUSED: 'muted',
}

export const statusLabels: Record<string, string> = {
  PUBLISHED: 'Publicado',
  PENDING_REVIEW: 'En revisión',
  DRAFT: 'Borrador',
  REJECTED: 'Rechazado',
  SOLD: 'Vendido',
  PAUSED: 'Pausado',
}

export const typeLabels: Record<string, string> = {
  WEBSITE: 'Sitio Web',
  DOMAIN: 'Dominio',
  SAAS: 'SaaS',
  ECOMMERCE: 'E-commerce',
  PROJECT: 'Proyecto',
  OTHER: 'Otro',
}
