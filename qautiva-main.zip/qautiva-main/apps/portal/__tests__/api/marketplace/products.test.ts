import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// ── Mocks ──────────────────────────────────────────────────────────────────────

// server-only no tiene runtime en tests
vi.mock('server-only', () => ({}))

const mockGetProfileOrUnauthorized = vi.fn()
const mockSerializeDecimalPrice = vi.fn()

const mockMediumFindUnique = vi.fn()
const mockProductFindUnique = vi.fn()
const mockProductFindMany = vi.fn()
const mockProductCount = vi.fn()
const mockProductCreate = vi.fn()
const mockProductUpdate = vi.fn()
const mockOrderCount = vi.fn()

vi.mock('@/lib/api/marketplace-helpers', () => ({
  getProfileOrUnauthorized: mockGetProfileOrUnauthorized,
  serializeDecimalPrice: mockSerializeDecimalPrice,
}))

vi.mock('@qautiva/db', () => {
  function MockDecimal(v: string | number) {
    const n = typeof v === 'string' ? parseFloat(v) : Number(v)
    return { toNumber: () => n, toString: () => String(n) }
  }

  return {
    prisma: {
      medium: { findUnique: mockMediumFindUnique },
      product: {
        findUnique: mockProductFindUnique,
        findMany: mockProductFindMany,
        count: mockProductCount,
        create: mockProductCreate,
        update: mockProductUpdate,
      },
      order: { count: mockOrderCount },
    },
    Prisma: {
      Decimal: MockDecimal,
      JsonNull: null,
    },
    MediumStatus: {
      ACTIVE: 'ACTIVE',
      PENDING_REVIEW: 'PENDING_REVIEW',
      PAUSED: 'PAUSED',
      REJECTED: 'REJECTED',
      SUSPENDED: 'SUSPENDED',
    },
    ProductType: {
      ARTICLE: 'ARTICLE',
      BANNER: 'BANNER',
      SOCIAL_POST: 'SOCIAL_POST',
      NEWSLETTER: 'NEWSLETTER',
      SPONSORED_CONTENT: 'SPONSORED_CONTENT',
    },
  }
})

// Next.js cookies / supabase-server (usados por GET ownership check)
vi.mock('next/headers', () => ({ cookies: vi.fn(() => ({})) }))
vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn(() => ({
    auth: { getUser: vi.fn().mockResolvedValue({ data: { user: null } }) },
  })),
}))

// ── Helpers ────────────────────────────────────────────────────────────────────

const PROFILE_ID = 'editor-profile-id'
const MEDIUM_ID = 'medium-uuid-1'
const PRODUCT_ID = 'product-uuid-1'

function makeRequest(method: string, body?: unknown): NextRequest {
  return new NextRequest('http://localhost:3000/api/marketplace/products', {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  })
}

function makeGetRequest(params?: Record<string, string>): NextRequest {
  const url = new URL('http://localhost:3000/api/marketplace/products')
  if (params) Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))
  return new NextRequest(url)
}

function mockAuthOk() {
  mockGetProfileOrUnauthorized.mockResolvedValueOnce({
    profile: { id: PROFILE_ID },
    unauthorized: false,
  })
}

function mockAuthFail() {
  mockGetProfileOrUnauthorized.mockResolvedValueOnce({
    profile: null,
    unauthorized: true,
    response: new Response(JSON.stringify({ error: 'No autorizado' }), { status: 401 }),
  })
}

function makeMedium(overrides?: Record<string, unknown>) {
  return {
    id: MEDIUM_ID,
    userId: PROFILE_ID,
    deletedAt: null,
    status: 'ACTIVE',
    ...overrides,
  }
}

function makeProduct(overrides?: Record<string, unknown>) {
  return {
    id: PRODUCT_ID,
    mediumId: MEDIUM_ID,
    type: 'ARTICLE',
    name: 'Artículo patrocinado',
    description: null,
    price: { toNumber: () => 100 },
    deliveryDays: 5,
    includesWriting: false,
    active: true,
    conditions: null,
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    ...overrides,
  }
}

function resetAllMocks() {
  vi.resetModules()
  mockGetProfileOrUnauthorized.mockReset()
  mockMediumFindUnique.mockReset()
  mockProductFindUnique.mockReset()
  mockProductFindMany.mockReset()
  mockProductCount.mockReset()
  mockProductCreate.mockReset()
  mockProductUpdate.mockReset()
  mockOrderCount.mockReset()
  mockSerializeDecimalPrice.mockImplementation((p: Record<string, unknown>) => ({ ...p, price: 100 }))
}

// ── GET /api/marketplace/products ─────────────────────────────────────────────

describe('GET /api/marketplace/products', () => {
  beforeEach(resetAllMocks)

  it('retorna 400 cuando falta mediumId', async () => {
    const { GET } = await import('../../../app/api/marketplace/products/route')
    const res = await GET(makeGetRequest())
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/mediumId/)
  })

  it('retorna 404 cuando el medio no existe', async () => {
    mockMediumFindUnique.mockResolvedValueOnce(null)
    const { GET } = await import('../../../app/api/marketplace/products/route')
    const res = await GET(makeGetRequest({ mediumId: MEDIUM_ID }))
    expect(res.status).toBe(404)
  })

  it('retorna 404 cuando el medio tiene deletedAt', async () => {
    mockMediumFindUnique.mockResolvedValueOnce({ id: MEDIUM_ID, userId: PROFILE_ID, deletedAt: new Date() })
    const { GET } = await import('../../../app/api/marketplace/products/route')
    const res = await GET(makeGetRequest({ mediumId: MEDIUM_ID }))
    expect(res.status).toBe(404)
  })

  it('retorna productos activos para visitantes anónimos', async () => {
    mockMediumFindUnique.mockResolvedValueOnce(makeMedium())
    mockProductFindMany.mockResolvedValueOnce([makeProduct()])
    mockProductCount.mockResolvedValueOnce(1)

    const { GET } = await import('../../../app/api/marketplace/products/route')
    const res = await GET(makeGetRequest({ mediumId: MEDIUM_ID }))
    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.products).toBeDefined()
    expect(body.pagination.total).toBe(1)
  })
})

// ── POST /api/marketplace/products ────────────────────────────────────────────

describe('POST /api/marketplace/products', () => {
  beforeEach(resetAllMocks)

  const validBody = {
    mediumId: MEDIUM_ID,
    type: 'ARTICLE',
    name: 'Artículo patrocinado',
    price: 100,
    deliveryDays: 5,
  }

  it('retorna 401 cuando no está autenticado', async () => {
    mockAuthFail()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', validBody))
    expect(res.status).toBe(401)
  })

  it('retorna 400 cuando falta mediumId', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, mediumId: undefined }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/mediumId/)
  })

  it('retorna 400 cuando el tipo es inválido', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, type: 'INVALID_TYPE' }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/[Tt]ipo/)
  })

  it('retorna 400 cuando el nombre tiene menos de 3 caracteres', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, name: 'ab' }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/nombre/)
  })

  it('retorna 400 cuando el precio es 0', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, price: 0 }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/precio/)
  })

  it('retorna 400 cuando el precio es negativo', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, price: -10 }))
    expect(res.status).toBe(400)
  })

  it('retorna 400 cuando el precio tiene más de 2 decimales', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, price: 10.999 }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/decimal/)
  })

  it('retorna 400 cuando deliveryDays no es entero positivo', async () => {
    mockAuthOk()
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', { ...validBody, deliveryDays: 0 }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/deliveryDays/)
  })

  it('retorna 404 cuando el medio no existe', async () => {
    mockAuthOk()
    mockMediumFindUnique.mockResolvedValueOnce(null)
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', validBody))
    expect(res.status).toBe(404)
  })

  it('retorna 403 cuando el editor no es dueño del medio', async () => {
    mockAuthOk()
    mockMediumFindUnique.mockResolvedValueOnce(makeMedium({ userId: 'otro-profile-id' }))
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', validBody))
    expect(res.status).toBe(403)
  })

  it('retorna 403 cuando el medio está REJECTED', async () => {
    mockAuthOk()
    mockMediumFindUnique.mockResolvedValueOnce(makeMedium({ status: 'REJECTED' }))
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', validBody))
    expect(res.status).toBe(403)
  })

  it('retorna 403 cuando el medio está SUSPENDED', async () => {
    mockAuthOk()
    mockMediumFindUnique.mockResolvedValueOnce(makeMedium({ status: 'SUSPENDED' }))
    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', validBody))
    expect(res.status).toBe(403)
  })

  it('crea el producto y retorna 201 en happy path', async () => {
    mockAuthOk()
    mockMediumFindUnique.mockResolvedValueOnce(makeMedium())
    const created = makeProduct()
    mockProductCreate.mockResolvedValueOnce(created)

    const { POST } = await import('../../../app/api/marketplace/products/route')
    const res = await POST(makeRequest('POST', validBody))
    expect(res.status).toBe(201)
    const body = await res.json()
    expect(body.product).toBeDefined()
    expect(mockProductCreate).toHaveBeenCalledOnce()
  })
})

// ── PATCH /api/marketplace/products ───────────────────────────────────────────

describe('PATCH /api/marketplace/products', () => {
  beforeEach(resetAllMocks)

  it('retorna 401 cuando no está autenticado', async () => {
    mockAuthFail()
    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { id: PRODUCT_ID, price: 150 }))
    expect(res.status).toBe(401)
  })

  it('retorna 400 cuando falta el id', async () => {
    mockAuthOk()
    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { price: 150 }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toMatch(/id/)
  })

  it('retorna 400 cuando nombre actualizado es muy corto', async () => {
    mockAuthOk()
    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { id: PRODUCT_ID, name: 'AB' }))
    expect(res.status).toBe(400)
  })

  it('retorna 400 cuando el precio actualizado tiene más de 2 decimales', async () => {
    mockAuthOk()
    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { id: PRODUCT_ID, price: 9.999 }))
    expect(res.status).toBe(400)
  })

  it('retorna 404 cuando el producto no existe', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(null)
    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { id: PRODUCT_ID, price: 150 }))
    expect(res.status).toBe(404)
  })

  it('retorna 403 cuando el editor no es dueño del medio del producto', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      medium: { userId: 'otro-profile-id', deletedAt: null },
    })
    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { id: PRODUCT_ID, price: 150 }))
    expect(res.status).toBe(403)
  })

  it('actualiza el producto y retorna 200 en happy path', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      medium: { userId: PROFILE_ID, deletedAt: null },
    })
    const updated = makeProduct({ price: { toNumber: () => 150 } })
    mockProductUpdate.mockResolvedValueOnce(updated)

    const { PATCH } = await import('../../../app/api/marketplace/products/route')
    const res = await PATCH(makeRequest('PATCH', { id: PRODUCT_ID, price: 150 }))
    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.product).toBeDefined()
    expect(mockProductUpdate).toHaveBeenCalledOnce()
  })
})

// ── DELETE /api/marketplace/products ──────────────────────────────────────────

describe('DELETE /api/marketplace/products', () => {
  beforeEach(resetAllMocks)

  it('retorna 401 cuando no está autenticado', async () => {
    mockAuthFail()
    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', { id: PRODUCT_ID }))
    expect(res.status).toBe(401)
  })

  it('retorna 400 cuando falta el id', async () => {
    mockAuthOk()
    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', {}))
    expect(res.status).toBe(400)
  })

  it('retorna 404 cuando el producto no existe', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce(null)
    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', { id: PRODUCT_ID }))
    expect(res.status).toBe(404)
  })

  it('retorna 403 cuando el editor no es dueño', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      active: true,
      medium: { userId: 'otro-profile-id', deletedAt: null },
    })
    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', { id: PRODUCT_ID }))
    expect(res.status).toBe(403)
  })

  it('retorna 409 cuando el producto ya está inactivo', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      active: false,
      medium: { userId: PROFILE_ID, deletedAt: null },
    })
    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', { id: PRODUCT_ID }))
    expect(res.status).toBe(409)
    const body = await res.json()
    expect(body.error).toMatch(/inactivo/)
  })

  it('retorna 409 cuando hay órdenes activas', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      active: true,
      medium: { userId: PROFILE_ID, deletedAt: null },
    })
    mockOrderCount.mockResolvedValueOnce(2)
    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', { id: PRODUCT_ID }))
    expect(res.status).toBe(409)
    const body = await res.json()
    expect(body.error).toMatch(/[óÓo]rdenes/)
  })

  it('desactiva el producto y retorna 200 en happy path', async () => {
    mockAuthOk()
    mockProductFindUnique.mockResolvedValueOnce({
      active: true,
      medium: { userId: PROFILE_ID, deletedAt: null },
    })
    mockOrderCount.mockResolvedValueOnce(0)
    mockProductUpdate.mockResolvedValueOnce({ id: PRODUCT_ID })

    const { DELETE } = await import('../../../app/api/marketplace/products/route')
    const res = await DELETE(makeRequest('DELETE', { id: PRODUCT_ID }))
    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.ok).toBe(true)
    expect(mockProductUpdate).toHaveBeenCalledWith({
      where: { id: PRODUCT_ID },
      data: { active: false },
    })
  })
})
