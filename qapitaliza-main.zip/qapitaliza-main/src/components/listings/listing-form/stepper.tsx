import { Check } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

interface Step {
  id: number
  label: string
}

interface StepperProps {
  steps: Step[]
  currentStep: number
}

export function Stepper({ steps, currentStep }: StepperProps) {
  return (
    <div className="flex items-center gap-0">
      {steps.map((step, idx) => {
        const isCompleted = step.id < currentStep
        const isActive = step.id === currentStep
        const isLast = idx === steps.length - 1

        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            {/* Step circle + label */}
            <div className="flex flex-col items-center gap-1.5">
              <div
                className={cn(
                  'size-8 rounded-full flex items-center justify-center text-sm font-semibold transition-colors',
                  isCompleted
                    ? 'bg-emerald-500 text-white'
                    : isActive
                      ? 'bg-amber-500 text-navy-950'
                      : 'bg-slate-800 text-slate-400'
                )}
              >
                {isCompleted ? <Check className="size-4" /> : step.id}
              </div>
              <span
                className={cn(
                  'text-xs font-medium whitespace-nowrap',
                  isActive ? 'text-amber-500' : isCompleted ? 'text-emerald-500' : 'text-slate-500'
                )}
              >
                {step.label}
              </span>
            </div>

            {/* Connector line */}
            {!isLast && (
              <div
                className={cn(
                  'h-px flex-1 mx-3 mb-4 transition-colors',
                  step.id < currentStep ? 'bg-amber-500' : 'bg-slate-800'
                )}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}
