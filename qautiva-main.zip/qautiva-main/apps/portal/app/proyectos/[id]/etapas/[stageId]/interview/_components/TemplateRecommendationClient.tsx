'use client'

/**
 * Pantalla de recomendación de templates para la etapa WEBSITE v2.
 * Se muestra DESPUÉS de completar la entrevista, cuando el cliente
 * aún no eligió un diseño.
 *
 * Flujo:
 * 1. Carga 2 templates recomendados (GET /api/templates/recommend)
 * 2. El usuario elige uno de los 2 recomendados (o ve el catálogo completo)
 * 3. Se guarda la selección (PATCH /api/interview/sessions/[id]/template)
 * 4. Se recarga la página: el servidor dispara la generación
 *
 * @see ADR-0018 — Paso 2: Recomendación de templates
 */

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'

const SECTION_LABELS: Record<string, string> = {
  hero: 'Hero / Inicio',
  services: 'Servicios / Menú',
  about: 'Sobre nosotros',
  contact: 'Contacto / WhatsApp',
  gallery: 'Galería',
  testimonials: 'Testimonios',
  map: 'Ubicación / Mapa',
  pricing: 'Precios',
  booking: 'Reserva de turnos',
  payments: 'Pagos online',
  careers: 'Portal de empleo',
  blog: 'Blog',
}

type RecommendedTemplate = {
  id: string
  name: string
  description: string | null
  thumbnail: string | null
  score: number
  reason: string
}

type Props = {
  sessionId: string
  projectId: string
  stageId: string
}

export default function TemplateRecommendationClient({
  sessionId,
  projectId,
  stageId,
}: Props) {
  const router = useRouter()
  const [templates, setTemplates] = useState<RecommendedTemplate[]>([])
  const [allTemplates, setAllTemplates] = useState<RecommendedTemplate[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [showAll, setShowAll] = useState(false)
  const fetchedRef = useRef(false)
  const savingLockRef = useRef(false)

  useEffect(() => {
    if (fetchedRef.current) return
    fetchedRef.current = true

    async function load() {
      try {
        const res = await fetch(
          `/api/templates/recommend?sessionId=${sessionId}`,
        )
        if (!res.ok) {
          setError('No pudimos cargar las recomendaciones. Intentá recargar la página.')
          return
        }
        const data = await res.json()
        setTemplates(data.templates ?? [])
      } catch {
        setError('Error de conexión. Verificá tu internet y recargá la página.')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [sessionId])

  async function loadAllTemplates() {
    setShowAll(true)
    try {
      const res = await fetch('/api/templates')
      if (!res.ok) return
      const data = await res.json()
      setAllTemplates(data.templates ?? [])
    } catch {
      // Silently fail — the recommended ones are still visible
    }
  }

  async function handleSelect(templateId: string) {
    if (savingLockRef.current) return
    savingLockRef.current = true
    setSaving(true)
    setError(null)

    try {
      const res = await fetch(
        `/api/interview/sessions/${sessionId}/template`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ templateId }),
        },
      )

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        setError(data.error ?? 'Error al guardar el diseño. Intentá de nuevo.')
        savingLockRef.current = false
        setSaving(false)
        return
      }

      router.refresh()
    } catch {
      setError('Error de conexión. Intentá de nuevo.')
      savingLockRef.current = false
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <p className="text-sm text-[#64748B] mb-2">Paso 2 de 3</p>
          <div className="h-8 w-64 bg-[#1E293B] rounded animate-pulse mb-4" />
          <div className="h-4 w-96 bg-[#1E293B] rounded animate-pulse" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {[1, 2].map((i) => (
            <div
              key={i}
              className="border border-[#1E293B] rounded-xl overflow-hidden animate-pulse"
            >
              <div className="h-48 bg-[#1E293B]" />
              <div className="p-4 space-y-3">
                <div className="h-5 w-32 bg-[#1E293B] rounded" />
                <div className="h-4 w-full bg-[#1E293B] rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <p className="text-sm text-[#64748B] mb-2">Paso 2 de 3</p>
        <h1 className="text-2xl font-bold text-white mb-2">
          Elegí el diseño de tu sitio
        </h1>
        <p className="text-[#94A3B8]">
          Seleccionamos estos diseños basándonos en tu rubro y lo que nos contaste. Elegí el que más te guste.
        </p>
      </div>

      {/* Error banner */}
      {error && (
        <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">
          {error}
        </div>
      )}

      {/* Recommended templates */}
      {templates.length === 0 && !showAll ? (
        <div className="border border-[#1E293B] rounded-xl p-12 text-center">
          <p className="text-[#94A3B8] mb-4">
            No encontramos diseños recomendados para tu negocio.
          </p>
          <button
            onClick={loadAllTemplates}
            className="text-[#8B5CF6] hover:text-[#7C3AED] text-sm font-medium"
          >
            Ver todos los diseños disponibles
          </button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
            {templates.map((template) => (
              <button
                key={template.id}
                onClick={() => setSelectedId(template.id)}
                disabled={saving}
                className={`text-left border rounded-xl overflow-hidden transition-all ${
                  selectedId === template.id
                    ? 'border-[#8B5CF6] ring-2 ring-[#8B5CF6]/30'
                    : 'border-[#1E293B] hover:border-[#334155]'
                } ${saving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
              >
                {/* Thumbnail */}
                <div className="relative h-48 bg-[#1E293B] overflow-hidden">
                  {template.thumbnail ? (
                    <img
                      src={template.thumbnail}
                      alt={template.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full text-[#64748B]">
                      Vista previa no disponible
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-white mb-1">
                    {template.name}
                  </h3>
                  {template.description && (
                    <p className="text-sm text-[#94A3B8] mb-2 line-clamp-2">
                      {template.description}
                    </p>
                  )}
                  <p className="text-xs text-[#8B5CF6]">{template.reason}</p>
                </div>
              </button>
            ))}
          </div>

          {/* CTA Button */}
          {selectedId && (
            <div className="flex justify-center mb-6">
              <button
                onClick={() => handleSelect(selectedId)}
                disabled={saving}
                className="bg-[#8B5CF6] hover:bg-[#7C3AED] text-white px-8 py-3 rounded-lg font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {saving ? (
                  <>
                    <svg
                      className="animate-spin h-5 w-5"
                      viewBox="0 0 24 24"
                      fill="none"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                      />
                    </svg>
                    Guardando...
                  </>
                ) : (
                  'Elegir este diseño'
                )}
              </button>
            </div>
          )}
        </>
      )}

      {/* Show all templates - fallback link */}
      {!showAll && templates.length > 0 && (
        <div className="text-center">
          <button
            onClick={loadAllTemplates}
            className="text-xs text-[#64748B] hover:text-[#94A3B8] transition-colors"
          >
            Ver todos los diseños
          </button>
        </div>
      )}

      {/* Full catalog (shown when "ver todos" is clicked) */}
      {showAll && allTemplates.length > 0 && (
        <div className="mt-8 pt-8 border-t border-[#1E293B]">
          <h2 className="text-lg font-semibold text-white mb-4">
            Todos los diseños
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {allTemplates
              .filter((t) => !templates.some((rec) => rec.id === t.id))
              .map((template) => (
                <button
                  key={template.id}
                  onClick={() => {
                    setSelectedId(template.id)
                    window.scrollTo({ top: 0, behavior: 'smooth' })
                  }}
                  disabled={saving}
                  className={`text-left border rounded-xl overflow-hidden transition-all ${
                    selectedId === template.id
                      ? 'border-[#8B5CF6] ring-2 ring-[#8B5CF6]/30'
                      : 'border-[#1E293B] hover:border-[#334155]'
                  } ${saving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <div className="relative h-36 bg-[#1E293B] overflow-hidden">
                    {template.thumbnail ? (
                      <img
                        src={template.thumbnail}
                        alt={template.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-[#64748B] text-sm">
                        Sin preview
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-white">
                      {template.name}
                    </h3>
                  </div>
                </button>
              ))}
          </div>
        </div>
      )}
    </div>
  )
}
