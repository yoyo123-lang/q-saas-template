import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { encrypt, keyHint } from '@/lib/encryption'
import { validateApiKey } from '@/app/_lib/validate-api-key'
import { getTeamForUser } from '@/app/_lib/get-team-for-user'

const VALID_PROVIDERS = ['ANTHROPIC', 'OPENAI', 'GOOGLE_GEMINI'] as const
type Provider = (typeof VALID_PROVIDERS)[number]

/**
 * GET /api/settings/api-keys
 * Lista las API keys del equipo del usuario. Nunca retorna encryptedKey.
 */
export async function GET() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const team = await getTeamForUser(user.id)
  if (!team) {
    return NextResponse.json({ error: 'No se encontró el equipo' }, { status: 404 })
  }

  const keys = await prisma.apiKey.findMany({
    where: { teamId: team.teamId },
    select: {
      id: true,
      provider: true,
      keyHint: true,
      label: true,
      isValid: true,
      lastUsedAt: true,
      lastError: true,
      createdAt: true,
    },
    orderBy: { createdAt: 'asc' },
  })

  return NextResponse.json({ keys })
}

/**
 * POST /api/settings/api-keys
 * Agrega una nueva API key al equipo. Valida contra el proveedor antes de guardar.
 */
export async function POST(request: Request) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const team = await getTeamForUser(user.id)
  if (!team) {
    return NextResponse.json({ error: 'No se encontró el equipo' }, { status: 404 })
  }

  // Guard de permisos: solo ADMIN y OWNER pueden gestionar API keys
  if (!['ADMIN', 'OWNER'].includes(team.teamRole)) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden gestionar API keys.' },
      { status: 403 },
    )
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const rawKey = typeof body.key === 'string' ? body.key.trim() : ''
  const provider = body.provider as string | undefined
  const label = typeof body.label === 'string' ? body.label.trim() : undefined

  if (!rawKey) {
    return NextResponse.json({ error: 'El campo key es obligatorio' }, { status: 400 })
  }

  if (!provider || !(VALID_PROVIDERS as readonly string[]).includes(provider)) {
    return NextResponse.json({ error: 'Provider inválido. Valores válidos: ANTHROPIC, OPENAI, GOOGLE_GEMINI' }, { status: 400 })
  }

  // Validar key contra el proveedor (timeout 10s)
  let isValid: boolean | null = null
  try {
    const result = await Promise.race([
      validateApiKey(provider as Provider, rawKey),
      new Promise<'timeout'>((resolve) => setTimeout(() => resolve('timeout'), 10000)),
    ])
    isValid = result === 'timeout' ? null : result
  } catch {
    isValid = null
  }

  if (isValid === false) {
    return NextResponse.json({ error: 'La API key es inválida. Verificá que sea correcta y tenga los permisos necesarios.' }, { status: 400 })
  }

  const encryptedKey = encrypt(rawKey)
  const hint = keyHint(rawKey, 4)

  const created = await prisma.apiKey.create({
    data: {
      teamId: team.teamId,
      provider: provider as Provider,
      encryptedKey,
      keyHint: hint,
      label: label || null,
      isValid,
    },
    select: {
      id: true,
      provider: true,
      keyHint: true,
      label: true,
      isValid: true,
      lastUsedAt: true,
      lastError: true,
      createdAt: true,
    },
  })

  revalidatePath('/configuracion')

  return NextResponse.json({ ok: true, key: created }, { status: 201 })
}
