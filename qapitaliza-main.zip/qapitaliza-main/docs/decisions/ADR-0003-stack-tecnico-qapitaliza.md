# ADR-0003: Stack técnico de Qapitaliza

> **Fecha**: 2026-03-22
> **Estado**: Aceptada

## Contexto

Qapitaliza es un marketplace de activos digitales + plataforma de crowdfunding del ecosistema Q Company. Necesitamos definir el stack técnico para el MVP, priorizando consistencia con el ecosistema existente, velocidad de desarrollo, y capacidad de escalar.

Se analizaron los tres proyectos existentes del ecosistema:
- **Q-Company (central)**: Next.js 14, App Router, TypeScript, Prisma, PostgreSQL, JWT custom, Vercel
- **Qautiva**: Next.js 14, App Router, TypeScript, Prisma, PostgreSQL (Supabase), Supabase Auth, Vercel, monorepo pnpm+Turborepo
- **Qontrata**: Express + React/Vite, Prisma, PostgreSQL, JWT custom, Railway

## Opciones consideradas

### Opción A: Next.js App Router + Supabase (patrón Qautiva)
- **Pros**: Consistente con el proyecto más moderno del ecosistema. Supabase Auth resuelve auth out-of-the-box (OAuth, magic links, row-level security). SSR/RSC para SEO del marketplace. Server Actions para mutations. Deploy en Vercel con zero-config.
- **Contras**: Dependencia de Supabase como proveedor. Supabase Auth tiene opiniones fuertes sobre el modelo de usuarios.

### Opción B: Express + React/Vite (patrón Qontrata)
- **Pros**: Separación clara frontend/backend. Más flexibilidad en la API.
- **Contras**: Más código boilerplate. Pierde SSR/RSC (malo para SEO de un marketplace). No es el patrón dominante del ecosistema.

### Opción C: Next.js App Router + JWT custom (patrón Q-Company)
- **Pros**: Control total de auth. Sin dependencia de Supabase.
- **Contras**: Más trabajo manual para implementar auth, OAuth, password recovery. Q-Company usa auth simple (username/password) que no escala para un marketplace con usuarios públicos.

## Decisión

Elegimos **Opción A: Next.js App Router + Supabase** porque:

1. **SEO es crítico** para un marketplace — los listados deben ser indexables. Next.js RSC lo resuelve nativamente.
2. **Auth complejo** — un marketplace necesita registro público, OAuth, recovery, verificación de email. Supabase Auth lo resuelve sin implementación manual.
3. **Consistencia** — es el patrón más moderno del ecosistema (Qautiva) y el que Q-Company está evolucionando hacia.
4. **Velocidad de desarrollo** — menos boilerplate que Express separado.
5. **PostgreSQL + Prisma** — idéntico a todos los proyectos del ecosistema.

### Stack definido

| Componente | Tecnología | Versión |
|---|---|---|
| Framework | Next.js (App Router) | 15.x |
| Lenguaje | TypeScript | 5.x (strict) |
| Base de datos | PostgreSQL | 16 |
| ORM | Prisma | 5.x |
| Auth | Supabase Auth | latest |
| CSS | Tailwind CSS | 4.x |
| Validación | Zod | 3.x |
| Iconos | lucide-react | latest |
| Testing | Vitest + Testing Library | latest |
| Deploy | Vercel | - |
| Tipografía | DM Sans (Google Fonts) | - |
| Color acento | Amber #F59E0B | - |

### Estructura: proyecto único (no monorepo)

A diferencia de Qautiva (monorepo), Qapitaliza arranca como proyecto Next.js único. La complejidad de monorepo no se justifica hasta que haya múltiples apps (admin separado, API pública, etc.). Se puede migrar a monorepo más adelante si es necesario.

## Consecuencias

### Lo que ganamos
- SSR para SEO del marketplace
- Auth completo sin implementación manual
- Consistencia con el ecosistema Q
- Deploy simple en Vercel
- Row-level security de Supabase para multi-tenant futuro

### Lo que perdemos o se complica
- Dependencia de Supabase como servicio
- Supabase Auth tiene su propio modelo de usuarios (tabla `auth.users` en schema separado)
- Si se necesita migrar de Supabase, hay trabajo de extracción

### Lo que hay que tener en cuenta a futuro
- Si el marketplace crece mucho, evaluar CDN/edge para assets
- Si se necesita API pública para integraciones con Qobra/Qontacta, considerar migrar a monorepo
- El crowdfunding regulado puede requerir compliance adicional que afecte la arquitectura
