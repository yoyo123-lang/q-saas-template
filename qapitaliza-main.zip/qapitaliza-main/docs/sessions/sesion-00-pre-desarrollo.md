# Sesión 00 — Pre-desarrollo

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales (sitios web, dominios, MVPs) para el mercado hispanohablante.

Es la primera sesión. No hay código todavía. El objetivo es dejar listos los documentos de producto y el archivo de variables de entorno antes de arrancar el desarrollo.

Documentación existente:
- `PLAN.md` — plan completo de implementación
- `docs/BUSINESS_MODEL.md` — modelo de negocio (puede estar incompleto)
- `docs/decisions/ADR-0003-stack-tecnico-qapitaliza.md` — decisión de stack

## Tarea de esta sesión

**Objetivo:** Dejar cerrada la documentación de producto y el `.env.example` antes de escribir una línea de código.

### 1. Revisar y completar `docs/BUSINESS_MODEL.md`

Leer el archivo existente. Si está incompleto, completar las secciones que falten con la información disponible en `PLAN.md`. Las secciones críticas son:

- Roles y permisos (BUYER, SELLER, ADMIN)
- Límites operativos: máx 50 listados activos por vendedor, máx 10 consultas nuevas por día por usuario
- Política de baja de contenido: soft-delete con retención 90 días
- Eventos de funnel a trackear: `signup_completed`, `listing_created`, `listing_submitted`, `listing_published`, `listing_viewed`, `inquiry_sent`, `inquiry_replied`, `inquiry_converted`, `favorite_added`
- Reglas de moderación: motivo de rechazo obligatorio, mínimo 20 caracteres

### 2. Crear `.env.example`

Crear el archivo `.env.example` en la raíz con todas las variables documentadas pero sin valores reales. Incluir:

```
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Database (Prisma)
DATABASE_URL=
DIRECT_URL=

# Google OAuth (configurado en Supabase)
# No necesita variables adicionales si se usa Supabase Auth

# Rate limiting (Upstash Redis)
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=

# Email (Resend)
RESEND_API_KEY=
RESEND_FROM_EMAIL=

# App
NEXT_PUBLIC_APP_URL=
```

Agregar un comentario explicativo arriba de cada variable indicando dónde obtenerla (ej: "Supabase Dashboard → Settings → API").

### 3. Verificar que las migraciones SQL están listas

Revisar que existan los archivos en `supabase/migrations/` del 001 al 010. Si falta alguno, reportarlo.

## Reglas

- Seguir todas las instrucciones de `CLAUDE.md`
- No crear código de aplicación en esta sesión — solo documentación y configuración
- Si algo requiere decisión de negocio, preguntar en lugar de asumir

## Checkpoint

La sesión está completa cuando:
- [ ] `docs/BUSINESS_MODEL.md` tiene las secciones críticas completas
- [ ] `.env.example` existe en la raíz con todas las variables documentadas
- [ ] Los 10 archivos SQL de migraciones existen en `supabase/migrations/`
