# Plan: Billing, Guards, Permisos e Integridad de Datos

> Corrige todos los hallazgos de la revisión de negocio (`business-logic-reviewer`) del 2026-03-18.
> Última actualización: 2026-03-18
> Branch: `claude/review-docs-roles-ThQYj`

---

## Resumen del problema

El billing es 100% inoperable: ningún consumo de IA se registra, ningún trial se descuenta, ningún balance se cobra. Todo el modelo de monetización está diseñado en el schema pero sin implementar en código. Además hay gaps en permisos por rol, stages flexibles, revenue de dominios, e invariantes de datos sin enforcement en DB.

## Hallazgos a corregir

| # | Severidad | Descripción | Fase |
|---|-----------|-------------|------|
| 1.1 | CRÍTICO | No existe registro de TokenUsage en ninguna operación de IA | 1 |
| 1.2 | CRÍTICO | `trialTokensUsed` nunca se incrementa | 1 |
| 1.3 | CRÍTICO | `FeeConfig` existe en schema pero nunca se consulta | 1 |
| 1.4 | CRÍTICO | `balanceUsd` nunca se descuenta | 1 |
| 1.5 | CRÍTICO | Telegram bot consume Anthropic sin registro ni trazabilidad | 3 |
| 1.6 | CRÍTICO | No se valida saldo ANTES de ejecutar operaciones de IA | 2 |
| 2.1 | CRÍTICO | No existe guard que bloquee agentes cuando trial vence | 2 |
| 6.1 | CRÍTICO | No se valida que `balanceUsd` >= 0 en DB | 2 |
| 3.1 | IMPORTANTE | TeamRole MEMBER no validado a nivel de aplicación | 4 |
| 4.1 | IMPORTANTE | Stage no tiene campo `skip` ni `provided_by_client` | 5 |
| 4.2 | IMPORTANTE | No existe entrevista de intake inicial | 5 |
| 5.1 | IMPORTANTE | Margen de dominios no se registra como revenue | 6 |
| 6.2 | MENOR | Invariante "un Deliverable activo por Stage" sin constraint DB | 7 |
| 6.3 | MENOR | No se valida un solo OWNER por Team en DB | 7 |
| 3.2 | MENOR | Inconsistencia mecanismo admin entre tablas (documentar plan) | 7 |

## Estado general

| Fase | Nombre | Estado |
|------|--------|--------|
| 1 | Billing Core — Registro de consumo y cálculo de costos | ✅ Completado (2026-03-18) |
| 2 | Billing Guards — Validación pre-ejecución | ✅ Completado (2026-03-18) |
| 3 | Telegram Bot — Billing y trazabilidad | ✅ Completado (2026-03-18) |
| 4 | Roles y Permisos — Enforcement de TeamRole | ✅ Completado (2026-03-18) |
| 5 | Stages Flexibles — Skip y Provided By Client | ✅ Completado (2026-03-18) |
| 6 | Revenue de Dominios | ✅ Completado (2026-03-18) |
| 7 | Integridad de Datos — Constraints en DB | ✅ Completado (2026-03-18) |
| 8 | Revisión Final — Todos los roles | ⬜ Pendiente |

## Convenciones de ejecución

- Cada tarea atómica se commitea individualmente
- TDD obligatorio para toda lógica de negocio nueva
- Después de cada tarea que toque lógica de negocio, seguridad o modelo de datos → `micro-revisor` obligatorio
- Al finalizar cada fase → sub-agente `revisor` + roles técnicos según mapa
- Al finalizar TODO el plan → revisión completa capa 1 + capa 2

## Uso de agentes

| Paso | Agente | Modelo | Cuándo |
|------|--------|--------|--------|
| Investigar antes de cada fase | `explorador` | Sonnet | Antes de escribir código |
| Implementar cada tarea | `implementador` | Sonnet | Una tarea a la vez |
| Verificar post-tarea atómica | `micro-revisor` | Haiku | Después de cada tarea de negocio/seguridad/datos |
| Revisar al cerrar cada fase | `revisor` | Opus | Al completar todas las tareas de la fase |
| Roles técnicos post-fase | Agente principal adopta rol | Opus | Según mapa de roles |
| Revisión final de negocio | Agente principal adopta rol | Opus | Al final de todas las fases |

## Mapa de roles por fase

| Fase | Roles técnicos post-fase | Roles de negocio post-fase |
|------|--------------------------|----------------------------|
| 1 | Code Reviewer, QA, Security Auditor | — |
| 2 | Code Reviewer, QA, Security Auditor | — |
| 3 | Code Reviewer, QA, Security Auditor | — |
| 4 | Code Reviewer, QA, Security Auditor | — |
| 5 | Code Reviewer, QA | — |
| 6 | Code Reviewer, QA | — |
| 7 | Code Reviewer, QA | — |
| **8 (Final)** | **Todos capa 1 (1→7)** | **Business Logic + Data Analytics** |

---

## Fase 1: Billing Core — Registro de consumo y cálculo de costos

> Hallazgos: 1.1 (CRÍTICO), 1.2 (CRÍTICO), 1.3 (CRÍTICO), 1.4 (CRÍTICO)
>
> **Objetivo:** que toda operación de IA registre `TokenUsage` con costo calculado, y que `trialTokensUsed` / `balanceUsd` se actualicen atómicamente.
>
> **Contexto clave:**
> - `executeToolCall()` en `ai-tool-call.ts` centraliza llamadas a Anthropic/OpenAI y ya expone `response.usage`
> - `brand-generator.ts` llama a Gemini directo (no pasa por `executeToolCall`)
> - `AiModelPricing` tiene precios por provider+model (`inputPer1M`, `outputPer1M`)
> - `FeeConfig` tiene fee por `plan` + `keySource` (BYOK vs HOSTED)
> - `BillingAccount` tiene `trialTokensUsed`, `trialTokensTotal`, `balanceUsd`
> - RLS exige `service_role` para escribir en `TokenUsage` y `BillingAccount`

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 1.1 | Crear función `recordTokenUsage()` en `apps/portal/app/_lib/billing/record-token-usage.ts`. Recibe `{ teamId, projectId, provider, model, operation, source, tokensIn, tokensOut }`. Consulta `AiModelPricing` para calcular `costUsd` (`tokensIn * inputPer1M / 1_000_000 + tokensOut * outputPer1M / 1_000_000`). Consulta `FeeConfig` (por `plan` + `keySource` del `BillingAccount`) para calcular `feeUsd` y `totalUsd`. Inserta en `TokenUsage`. | `apps/portal/app/_lib/billing/record-token-usage.ts` (nuevo) | Tests unitarios pasan | ✅ |
| 1.2 | Escribir tests para `recordTokenUsage()`: caso normal (costUsd calculado correctamente), caso sin pricing en DB (error ruidoso con `console.error CRITICAL:`), caso sin FeeConfig (fee=0 con warning), caso BYOK vs HOSTED (source correcto) | `apps/portal/app/_lib/billing/__tests__/record-token-usage.test.ts` (nuevo) | `npm test -- record-token-usage` pasa | ✅ |
| 1.3 | Crear función `updateBillingConsumption()` en `apps/portal/app/_lib/billing/update-billing.ts`. Según `source`: si `TRIAL` → incrementa `trialTokensUsed` por `tokensIn + tokensOut`; si `QAUTIVA_HOSTED` → decrementa `balanceUsd` por `totalUsd` (usando Prisma `decrement`). Si `BYOK` → no-op (el usuario paga su propia API key). Operación atómica. | `apps/portal/app/_lib/billing/update-billing.ts` (nuevo) | Tests unitarios pasan | ✅ |
| 1.4 | Escribir tests para `updateBillingConsumption()`: caso trial (incrementa `trialTokensUsed`), caso prepaid hosted (decrementa `balanceUsd`), caso BYOK (no modifica nada), edge case saldo insuficiente (error ruidoso, NO silencioso) | `apps/portal/app/_lib/billing/__tests__/update-billing.test.ts` (nuevo) | `npm test -- update-billing` pasa | ✅ |
| 1.5 | Crear función orquestadora `registerAiUsage()` en `apps/portal/app/_lib/billing/register-ai-usage.ts`. Llama `recordTokenUsage()` + `updateBillingConsumption()` en secuencia. Encapsula el try/catch para que un error de billing NO cancele la respuesta al usuario (el consumo ya ocurrió). Loguea `CRITICAL:` si falla. | `apps/portal/app/_lib/billing/register-ai-usage.ts` (nuevo) | Tests unitarios pasan | ✅ |
| 1.6 | Escribir tests para `registerAiUsage()`: happy path completo, error en recordTokenUsage (no propaga, loguea), error en updateBilling (no propaga, loguea) | `apps/portal/app/_lib/billing/__tests__/register-ai-usage.test.ts` (nuevo) | `npm test -- register-ai-usage` pasa | ✅ |
| 1.7 | Integrar `registerAiUsage()` en `executeToolCall()` (`ai-tool-call.ts`). Después de recibir response exitosa de Anthropic/OpenAI, llamar a `registerAiUsage()` con los tokens del `response.usage`. Agregar parámetros `teamId`, `projectId`, `source` a la firma de `executeToolCall()`. | `apps/portal/app/_lib/interview/ai-tool-call.ts` | Build compila + tests existentes pasan | ✅ |
| 1.8 | Actualizar todos los callers de `executeToolCall()` para pasar los nuevos parámetros. Los callers están en `session-processor.ts` y los procesadores individuales. Trazar de dónde viene `teamId` y `projectId` en cada caller (ya disponibles en el contexto de la sesión). | `apps/portal/app/_lib/interview/session-processor.ts`, procesadores individuales | Build compila + tests existentes pasan | ✅ |
| 1.9 | Integrar `registerAiUsage()` en `brand-generator.ts` para las llamadas directas a Gemini que no pasan por `executeToolCall()`. | `apps/portal/app/_lib/interview/brand-generator.ts` | Build compila | ✅ |
| 1.10 | Auditar y integrar `registerAiUsage()` en cualquier otro generador que haga llamadas directas sin pasar por `executeToolCall()`. Verificar: `market-study-generator.ts`, `website-generator.ts`, `campaign-strategy-generator.ts`, `ad-creative-generator.ts`. | Generadores que apliquen | Build compila | ✅ |
| 1.11 | Test de integración: simular una generación completa y verificar que `TokenUsage` se creó con `costUsd > 0`, `feeUsd >= 0`, `totalUsd > 0`, y que `trialTokensUsed` se incrementó correctamente. | `apps/portal/app/_lib/billing/__tests__/billing-integration.test.ts` (nuevo) | Test pasa | ✅ |
| 1.12 | Documentar el módulo de billing: docstrings en las funciones públicas + actualizar `docs/ARCHITECTURE.md` sección de billing con el flujo de registro de consumo. | `docs/ARCHITECTURE.md`, funciones nuevas | — | ✅ |

**Checkpoint de fase:** Toda operación de IA registra `TokenUsage` con `costUsd`, `feeUsd`, `totalUsd` calculados. `trialTokensUsed` se incrementa para trials. `balanceUsd` se decrementa para QAUTIVA_HOSTED.

**Post-fase:**
1. `micro-revisor` por cada tarea (obligatorio: toca billing)
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer (`docs/roles/tech/code-reviewer.md`) → QA (`docs/roles/tech/qa-engineer.md`) → Security Auditor (`docs/roles/tech/security-auditor.md`)
4. Corregir todos los hallazgos encontrados (CRÍTICOS, ALTOS, MEDIOS, BAJOS)
5. Re-ejecutar roles que tuvieron hallazgos hasta que estén limpios

---

## Fase 2: Billing Guards — Validación pre-ejecución

> Hallazgos: 1.6 (CRÍTICO), 2.1 (CRÍTICO), 6.1 (CRÍTICO)
>
> **Objetivo:** ninguna operación de IA se ejecuta sin verificar saldo/trial. `balanceUsd` no puede ser negativo.
>
> **Contexto clave:**
> - `POST /api/interview/sessions/[id]/process` ya verifica ownership y estado, pero no billing
> - `POST /api/interview/sessions/[id]/advance` transiciona a PROCESSING sin verificar billing
> - `BillingAccount` tiene: `plan`, `trialTokensUsed`, `trialTokensTotal`, `trialExpiresAt`, `balanceUsd`
> - BYOK: el usuario paga su propia key → siempre eligible (no consume saldo de Qautiva)

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 2.1 | Crear función `checkBillingEligibility(teamId)` en `apps/portal/app/_lib/billing/check-eligibility.ts`. Lee `BillingAccount` del team. Lógica: si `plan = FREE_TRIAL` → verificar `trialExpiresAt > now()` AND `trialTokensUsed < trialTokensTotal`. Si `PREPAID` → verificar `balanceUsd > 0`. Si `MONTHLY/YEARLY` → verificar suscripción activa (por ahora: `balanceUsd >= 0`). Si `preferredKeySource = BYOK` → siempre eligible. Retorna `{ eligible: boolean, reason?: string, billingPlan: BillingPlan }`. | `apps/portal/app/_lib/billing/check-eligibility.ts` (nuevo) | Tests pasan | ⬜ |
| 2.2 | Tests para `checkBillingEligibility()`: trial activo con tokens → eligible, trial expirado → no eligible con reason, trial tokens agotados → no eligible, prepaid con saldo → eligible, prepaid sin saldo → no eligible, BYOK → siempre eligible, sin BillingAccount → error ruidoso | `apps/portal/app/_lib/billing/__tests__/check-eligibility.test.ts` (nuevo) | `npm test -- check-eligibility` pasa | ⬜ |
| 2.3 | Integrar `checkBillingEligibility()` en `POST /api/interview/sessions/[id]/process`. Insertar el check antes del lock atómico (`updateMany`). Si no es eligible, retornar `Response 402` con `{ error: reason }`. | `apps/portal/app/api/interview/sessions/[id]/process/route.ts` | Build compila + tests existentes pasan | ⬜ |
| 2.4 | Integrar `checkBillingEligibility()` en `POST /api/interview/sessions/[id]/advance`. Insertar el check antes de la transición a `PROCESSING`. Retornar 402 si no es eligible. | `apps/portal/app/api/interview/sessions/[id]/advance/route.ts` | Build compila | ⬜ |
| 2.5 | Crear migración SQL: `ALTER TABLE "BillingAccount" ADD CONSTRAINT "BillingAccount_balanceUsd_check" CHECK ("balanceUsd" >= 0)`. Incluir script de verificación previo que confirma que ningún registro existente viola el constraint. | `packages/db/prisma/migrations/` (nueva migración) | `npx prisma migrate dev` exitoso | ⬜ |
| 2.6 | Tests de integración: request a `/process` con trial expirado → 402, con saldo $0 → 402, con trial activo y tokens → 200/202, con BYOK → 200/202 independientemente del saldo | `apps/portal/app/api/interview/sessions/__tests__/billing-guard.test.ts` (nuevo) | Tests pasan | ⬜ |
| 2.7 | Documentar el guard de billing, el código 402, y la lógica de elegibilidad en `docs/ARCHITECTURE.md`. | `docs/ARCHITECTURE.md` | — | ⬜ |

**Checkpoint de fase:** Ningún endpoint de generación se ejecuta sin verificar billing. DB rechaza `balanceUsd < 0`.

**Post-fase:**
1. `micro-revisor` por cada tarea (obligatorio: toca seguridad y billing)
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer → QA → Security Auditor
4. Corregir todos los hallazgos
5. Re-ejecutar roles hasta limpio

---

## Fase 3: Telegram Bot — Billing y trazabilidad

> Hallazgo: 1.5 (CRÍTICO)
>
> **Objetivo:** el bot de Telegram asocia cada conversación a un team y registra consumo de tokens.
>
> **Contexto clave:**
> - El bot es un servicio separado en `services/telegram-bot/`
> - Actualmente usa `organizationId` (sistema legacy) en vez de `teamId`
> - Hace hasta 2 llamadas a Anthropic por mensaje (`interpretResponse` + `formatResponse`)
> - No tiene acceso directo al módulo `_lib/billing/` del portal

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 3.1 | (explorador) Investigar el código del bot: flujo de mensajes, cómo se identifica al usuario, cómo llama a Anthropic, qué DB usa, si comparte el cliente Prisma con el portal o tiene su propia conexión. | Solo lectura | Reporte del explorador | ⬜ |
| 3.2 | Reemplazar `organizationId` por `teamId` en el bot. Migrar el campo/variable donde se almacena la asociación usuario-organización para usar el modelo de Teams. | `services/telegram-bot/src/` (archivos que usen organizationId) | Build compila | ⬜ |
| 3.3 | Crear mecanismo para resolver `teamId` a partir del usuario de Telegram. Opciones a evaluar en la exploración (3.1): campo `telegramChatId` en `TeamMember`, tabla de mapping dedicada, o comando `/vincular` del bot. Elegir el approach más simple. | `services/telegram-bot/src/`, posiblemente schema | Build compila | ⬜ |
| 3.4 | Extraer la lógica de billing (`recordTokenUsage`, `updateBillingConsumption`, `checkBillingEligibility`) a `packages/billing/` (shared package) para que tanto el portal como el bot puedan usarla. O si el bot ya comparte el cliente Prisma, importar directamente del portal. Evaluar en 3.1. | `packages/billing/` o `apps/portal/app/_lib/billing/` | Build compila en ambos servicios | ⬜ |
| 3.5 | Integrar `registerAiUsage()` en las llamadas LLM del bot (`interpretResponse` + `formatResponse`). Cada llamada registra su consumo con el `teamId` resuelto. | `services/telegram-bot/src/llm.ts` | Build compila | ⬜ |
| 3.6 | Integrar `checkBillingEligibility()` antes de cada llamada LLM en el bot. Si no es eligible, responder al usuario con mensaje descriptivo (ej: "Tu trial expiró. Contactá a soporte para activar un plan."). | `services/telegram-bot/src/llm.ts` o handler principal | Build compila | ⬜ |
| 3.7 | Tests: usuario con team y trial activo → respuesta OK, usuario sin team vinculado → error descriptivo, usuario con trial vencido → mensaje de bloqueo, ambas llamadas (interpret + format) registran tokens | `services/telegram-bot/src/__tests__/` | Tests pasan | ⬜ |
| 3.8 | Documentar la integración de billing del bot y el mecanismo de vinculación de usuario-team en `docs/ARCHITECTURE.md`. | `docs/ARCHITECTURE.md` | — | ⬜ |

**Checkpoint de fase:** El bot registra consumo en `TokenUsage` asociado a un `teamId`. Verifica eligibilidad antes de llamar al LLM. Ya no usa `organizationId`.

**Post-fase:**
1. `micro-revisor` por cada tarea
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer → QA → Security Auditor
4. Corregir todos los hallazgos
5. Re-ejecutar roles hasta limpio

---

## Fase 4: Roles y Permisos — Enforcement de TeamRole

> Hallazgo: 3.1 (IMPORTANTE)
>
> **Objetivo:** MEMBER solo tiene lectura. Operaciones de escritura requieren ADMIN o OWNER.
>
> **Contexto clave:**
> - RLS ya restringe algunas operaciones por rol, pero los endpoints del portal solo verifican pertenencia al team (`teamId: { in: teamIds }`), sin distinguir el rol
> - `TeamRole`: `OWNER | ADMIN | MEMBER`
> - Regla de negocio: MEMBER = solo lectura, ADMIN = lectura + escritura, OWNER = todo + gestión del team

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 4.1 | Crear función `checkTeamPermission(userId, teamId, requiredRoles: TeamRole[])` en `apps/portal/app/_lib/auth/check-team-permission.ts`. Consulta `TeamMember` y verifica que el rol esté en `requiredRoles`. Retorna `{ authorized: boolean, role: TeamRole \| null }`. | `apps/portal/app/_lib/auth/check-team-permission.ts` (nuevo) | Tests pasan | ✅ |
| 4.2 | Tests para `checkTeamPermission()`: OWNER pasa para `['OWNER']`, ADMIN pasa para `['ADMIN', 'OWNER']`, MEMBER falla para `['ADMIN', 'OWNER']`, usuario no miembro del team falla, usuario inexistente falla | `apps/portal/app/_lib/auth/__tests__/check-team-permission.test.ts` (nuevo) | Tests pasan | ✅ |
| 4.3 | Integrar guard en endpoints de escritura de interview: `process/route.ts`, `advance/route.ts`, `answer/route.ts`, `next-question/route.ts`. Requiere `['ADMIN', 'OWNER']` para operaciones de escritura. MEMBER → 403 con `{ error: "Insufficient permissions" }`. | `apps/portal/app/api/interview/sessions/[id]/` (4 archivos) | Build compila + tests pasan | ✅ |
| 4.4 | Integrar guard en endpoints de escritura de proyectos: `POST /api/projects`, `PATCH /api/projects/[id]`. MEMBER → 403. | `apps/portal/app/api/projects/` | Build compila | ✅ |
| 4.5 | (explorador) Auditar TODOS los endpoints POST/PATCH/DELETE del portal para identificar cuáles faltan el guard de permisos. Generar lista completa. | Solo lectura | Lista de endpoints | ✅ |
| 4.6 | Integrar guard en todos los endpoints de escritura identificados en 4.5 que no lo tengan. | Endpoints identificados | Build compila | ✅ |
| 4.7 | Tests de integración: MEMBER intenta POST a `/api/interview/sessions/[id]/process` → 403, ADMIN → 202, OWNER → 202. MEMBER intenta POST a `/api/projects` → 403. | Tests de integración | Tests pasan | ✅ |
| 4.8 | Documentar la política de permisos por rol (OWNER/ADMIN/MEMBER) y qué endpoints requieren qué rol en `docs/ARCHITECTURE.md`. | `docs/ARCHITECTURE.md` | — | ✅ |

**Checkpoint de fase:** MEMBER no puede ejecutar operaciones de escritura en ningún endpoint. Solo ADMIN y OWNER pueden disparar generaciones, crear proyectos, y modificar datos.

**Post-fase:**
1. `micro-revisor` por cada tarea (obligatorio: toca seguridad)
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer → QA → Security Auditor
4. Corregir todos los hallazgos
5. Re-ejecutar roles hasta limpio

---

## Fase 5: Stages Flexibles — Skip y Provided By Client

> Hallazgos: 4.1 (IMPORTANTE), 4.2 (IMPORTANTE)
>
> **Objetivo:** las etapas pueden marcarse como `SKIP` o `PROVIDED_BY_CLIENT`. Una entrevista de intake evalúa qué tiene el cliente y activa solo las etapas relevantes.
>
> **Contexto clave:**
> - `StageStatus` actual: `PENDING | IN_PROGRESS | ADMIN_REVIEW | CLIENT_REVIEW | REVISION | COMPLETED | FAILED`
> - `stageKey`: `DISCOVERY | RESEARCH | BRAND | WEBSITE | CAMPAIGNS | MEDIA`
> - El wizard actual crea stages según servicios seleccionados (checkboxes)
> - `session-processor.ts` despacha por `stageKey` y genera deliverables

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 5.1 | Agregar enum `StageActivation` con valores `ACTIVE`, `SKIP`, `PROVIDED_BY_CLIENT` al schema Prisma. Agregar campo `activation StageActivation @default(ACTIVE)` al modelo `Stage`. | `packages/db/prisma/schema.prisma` | `npx prisma validate` | ✅ |
| 5.2 | Crear migración. Datos existentes: todos los stages → `ACTIVE` (default, no requiere data migration explícita). | `packages/db/prisma/migrations/` (nueva) | `npx prisma migrate dev` exitoso | ✅ |
| 5.3 | Actualizar `POST /api/projects` para aceptar `activation` opcional por etapa en el body. Default: `ACTIVE`. Si `activation = SKIP` o `PROVIDED_BY_CLIENT`, crear el stage con `status = COMPLETED`. | `apps/portal/app/api/projects/route.ts` | Build compila + tests pasan | ✅ |
| 5.4 | Actualizar `session-processor.ts`: al inicio de `processSession()`, verificar `stage.activation`. Si es `SKIP` → marcar `COMPLETED` sin generar deliverable, retornar `true`. Si es `PROVIDED_BY_CLIENT` → marcar `COMPLETED`, retornar `true`. Solo procesar si es `ACTIVE`. | `apps/portal/app/_lib/interview/session-processor.ts` | Build compila + tests pasan | ✅ |
| 5.5 | Crear ADR para el diseño de la entrevista de intake: ¿se implementa como `InterviewSession` con `stageKey = 'INTAKE'`? ¿O como un paso previo al wizard de proyecto? Documentar pros/cons y decisión. | `docs/decisions/ADR-intake-interview.md` (nuevo) | — | ✅ |
| 5.6 | Implementar sesión de intake según el ADR. Crear el procesador correspondiente en `session-processor.ts` que, al completar, evalúa las respuestas del cliente y setea `activation` en los stages del proyecto. | `apps/portal/app/_lib/interview/session-processor.ts`, procesador nuevo | Build compila + tests | ✅ |
| 5.7 | Agregar UI en la vista de proyecto para mostrar el estado de activación de cada etapa. OWNER/ADMIN pueden cambiar `activation` manualmente (dropdown o toggle). MEMBER solo ve. | `apps/portal/app/(protected)/proyectos/` | Build compila | ✅ |
| 5.8 | Tests: crear proyecto con stage `SKIP` → no genera deliverable y stage queda `COMPLETED`; `PROVIDED_BY_CLIENT` → ídem; `ACTIVE` → comportamiento normal; cambio de activation post-creación → se respeta en processing. | Tests unitarios + integración | Tests pasan | ✅ |
| 5.9 | Documentar stages flexibles, el enum `StageActivation`, y el flujo de intake en `docs/ARCHITECTURE.md`. | `docs/ARCHITECTURE.md` | — | ✅ |

**Checkpoint de fase:** Las etapas soportan `ACTIVE`, `SKIP`, `PROVIDED_BY_CLIENT`. La intake interview determina la activación. El processing respeta la activación.

**Post-fase:**
1. `micro-revisor` por cada tarea
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer → QA
4. Corregir todos los hallazgos
5. Re-ejecutar roles hasta limpio

---

## Fase 6: Revenue de Dominios

> Hallazgo: 5.1 (IMPORTANTE)
>
> **Objetivo:** materializar el margen de venta de dominios como `revenueUsd` explícito.
>
> **Contexto clave:**
> - `Domain` ya tiene `costUsd` (costo mayorista OpenSRS) y `paidAmountArs` (precio al cliente)
> - `exchangeRate` está disponible en el registro
> - El margen es: `paidAmountArs / exchangeRate - costUsd`
> - No existe campo que materialice este cálculo

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 6.1 | Agregar campo `revenueUsd Decimal(10,4)?` al modelo `Domain` en el schema Prisma. | `packages/db/prisma/schema.prisma` | `npx prisma validate` | ✅ |
| 6.2 | Crear migración. Script de data migration que calcule `revenueUsd` para dominios existentes que tengan `costUsd`, `paidAmountArs`, y `exchangeRate` no null: `revenueUsd = paidAmountArs / exchangeRate - costUsd`. | `packages/db/prisma/migrations/` (nueva) | `npx prisma migrate dev` | ✅ |
| 6.3 | Actualizar `POST /api/domains/register` para calcular y guardar `revenueUsd` al momento del registro. Fórmula: `revenueUsd = paidAmountArs / exchangeRate - costUsd`. Si algún valor falta, `revenueUsd = null`. | `apps/portal/app/api/domains/register/route.ts` | Build compila | ✅ |
| 6.4 | Tests: registrar dominio con margen → `revenueUsd` correcto, dominio sin `paidAmountArs` → `revenueUsd = null`, dominio gratuito → `revenueUsd = 0` | Tests | Tests pasan | ✅ |
| 6.5 | Documentar la fórmula de revenue de dominios en `docs/ARCHITECTURE.md`. | `docs/ARCHITECTURE.md` | — | ✅ |

**Checkpoint de fase:** Cada dominio registrado tiene `revenueUsd` calculado y persistido. Los dominios históricos también.

**Post-fase:**
1. `micro-revisor` por cada tarea
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer → QA
4. Corregir todos los hallazgos

---

## Fase 7: Integridad de Datos — Constraints y Invariantes en DB

> Hallazgos: 6.2 (MENOR), 6.3 (MENOR), 3.2 (MENOR — solo documentar)
>
> **Objetivo:** las invariantes de negocio se enforzan a nivel de base de datos, no solo en código. La inconsistencia del mecanismo admin se documenta como plan de migración.

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 7.1 | Script de verificación: consultar DB para confirmar que no hay stages con más de un deliverable activo, y que no hay teams con más de un OWNER. Si hay violaciones, listarlas para corregir antes de crear los constraints. | Script temporal | Ejecuta sin encontrar violaciones (o las lista) | ✅ |
| 7.2 | Si 7.1 encontró violaciones, corregirlas (desactivar deliverables duplicados, reasignar OWNERs extra a ADMIN). | Según violaciones | Violaciones corregidas | ✅ |
| 7.3 | Crear migración: `CREATE UNIQUE INDEX "Deliverable_one_active_per_stage" ON "Deliverable" ("stageId") WHERE "isActive" = true`. Solo un deliverable activo por stage. | `packages/db/prisma/migrations/` (nueva) | `npx prisma migrate dev` exitoso | ✅ |
| 7.4 | Crear migración: `CREATE UNIQUE INDEX "TeamMember_one_owner_per_team" ON "TeamMember" ("teamId") WHERE "role" = 'OWNER'`. Solo un OWNER por team. | `packages/db/prisma/migrations/` (nueva) | `npx prisma migrate dev` exitoso | ✅ |
| 7.5 | Crear ADR documentando el plan de migración para la inconsistencia del mecanismo admin (hallazgo 3.2): migrar tablas legadas de `auth.jwt() ->> 'role'` a `auth.jwt() -> 'app_metadata' ->> 'role'`. Incluir: tablas afectadas, orden de migración, riesgo, y rollback. NO implementar, solo documentar. | `docs/decisions/ADR-admin-role-migration.md` (nuevo) | — | ✅ |
| 7.6 | Actualizar `docs/ARCHITECTURE.md` con los nuevos constraints de DB y referencia al ADR de migración admin. | `docs/ARCHITECTURE.md` | — | ✅ |

**Checkpoint de fase:** Constraints `one_active_per_stage` y `one_owner_per_team` activos en DB. ADR de migración admin documentado.

**Post-fase:**
1. `micro-revisor` por cada tarea
2. `revisor` al cerrar la fase
3. Roles: Code Reviewer → QA
4. Corregir todos los hallazgos

---

## Fase 8: Revisión Final — Todos los roles (Capa 1 + Capa 2)

> **Objetivo:** pasar TODOS los roles técnicos y de negocio para validar que el billing funciona end-to-end y el modelo de negocio está correctamente implementado.
>
> **Prerequisito:** `docs/BUSINESS_MODEL.md` debe existir para los roles de capa 2. Si no existe, generar con `/project:descubrimiento` antes de esta fase.

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 8.1 | Build completo: `npm run build` (o `pnpm build`) en todos los packages y apps. | Todo el proyecto | Build exitoso sin errores | ⬜ |
| 8.2 | Correr suite completa de tests: `npm test` (o `pnpm test`). | Todo el proyecto | Todos los tests pasan | ⬜ |
| 8.3 | Lint completo: `npm run lint` (o equivalente). | Todo el proyecto | Sin errores de lint | ⬜ |
| 8.4 | **Code Reviewer** (Tech Lead) — Adoptar rol de `docs/roles/tech/code-reviewer.md`. Revisar todo el código nuevo de fases 1-7. Generar informe en `docs/reviews/YYYY-MM-DD_code-review-billing.md`. | Todo el código nuevo | Informe generado | ⬜ |
| 8.5 | **QA Engineer** — Adoptar rol de `docs/roles/tech/qa-engineer.md`. Buscar bugs, edge cases, flujos rotos en billing, guards, permisos, stages. Generar informe. | Todo el código nuevo | Informe generado | ⬜ |
| 8.6 | **Security Auditor** — Adoptar rol de `docs/roles/tech/security-auditor.md`. Revisar auth, guards de billing, validación de inputs, headers. Generar informe. | Todo el código nuevo | Informe generado | ⬜ |
| 8.7 | **Performance Engineer** — Adoptar rol de `docs/roles/tech/performance-engineer.md`. Revisar queries de billing (N+1?), caching de `AiModelPricing`/`FeeConfig`, overhead del registro de tokens. Generar informe. | Todo el código nuevo | Informe generado | ⬜ |
| 8.8 | **DevOps / SRE** — Adoptar rol de `docs/roles/tech/devops-sre.md`. Revisar migraciones, rollback, logs de billing, health checks. Generar informe. | Todo el código nuevo + migraciones | Informe generado | ⬜ |
| 8.9 | **UX Reviewer** — Adoptar rol de `docs/roles/tech/ux-reviewer.md`. Revisar los cambios de UI: mensajes de error 402, UI de stages flexibles, dropdown de activación. Generar informe. | Cambios de UI (fase 5.7, mensajes 402) | Informe generado | ⬜ |
| 8.10 | **Product Reviewer** — Adoptar rol de `docs/roles/business/product-reviewer.md`. Revisar si el billing, los guards, y los stages resuelven el problema del usuario. Generar informe. | Todo el proyecto | Informe generado | ⬜ |
| 8.11 | Corregir TODOS los hallazgos CRÍTICOS y ALTOS de las revisiones 8.4-8.10. | Según hallazgos | Build + tests pasan post-corrección | ⬜ |
| 8.12 | Corregir todos los hallazgos MEDIOS y BAJOS de las revisiones 8.4-8.10. | Según hallazgos | Build + tests pasan post-corrección | ⬜ |
| 8.13 | Re-ejecutar roles que tuvieron hallazgos CRÍTICOS/ALTOS para verificar corrección. | Roles que apliquen | Informes limpios (✅ o ⚠️ solo BAJOS) | ⬜ |
| 8.14 | **Business Logic Reviewer** (Capa 2) — Adoptar rol de `docs/roles/business/business-logic-reviewer.md`. Verificar que TODOS los 15 hallazgos originales están corregidos. Billing funcional, trial se bloquea, balance se descuenta, permisos por rol, stages flexibles, revenue de dominios, constraints de DB. Generar informe. | Todo el billing + guards + permisos + stages | Informe generado | ⬜ |
| 8.15 | **Data & Analytics Reviewer** (Capa 2) — Adoptar rol de `docs/roles/business/data-analytics-reviewer.md`. Verificar tracking: `TokenUsage` registra todo, `BillingAccount` se actualiza, `revenueUsd` se calcula. Generar informe. | TokenUsage, BillingAccount, Domain | Informe generado | ⬜ |
| 8.16 | Corregir hallazgos de capa 2 (8.14 + 8.15). | Según hallazgos | Build + tests pasan | ⬜ |
| 8.17 | Re-ejecutar Business Logic Reviewer si tuvo hallazgos CRÍTICOS/ALTOS. | Si aplica | Informe limpio | ⬜ |
| 8.18 | Documentar hallazgos BAJOS residuales (si quedan) en `docs/KNOWN_ISSUES.md`. | `docs/KNOWN_ISSUES.md` | — | ⬜ |

**Checkpoint final:** Todos los roles aprueban (✅ o ⚠️ con solo BAJOS residuales documentados). El billing es funcional end-to-end. El modelo de negocio está correctamente implementado en código.

---

## Cosas que NO se van a tocar

- **Stripe integration**: campos `stripeCustomerId` y `stripeSubscriptionId` existen en el schema pero la integración con Stripe está fuera de scope
- **Admin panel de billing**: el admin ya puede editar `FeeConfig` desde UI, no se modifica
- **Migración de tablas legacy a `app_metadata`** (hallazgo 3.2): solo se documenta el plan en ADR
- **Agent Teams**: no se usa esta feature experimental
- **Refactors no solicitados**: no se refactoriza código existente que funciona correctamente
- **UI del admin**: no se agregan pantallas nuevas al admin panel

## Orden de ejecución sugerido por sesión

| Sesión | Fases | Justificación |
|--------|-------|---------------|
| 1 | 1 + 2 | Billing core + guards: el corazón del problema, son dependientes |
| 2 | 3 + 4 | Telegram + permisos: dependen del billing de fase 1 |
| 3 | 5 + 6 + 7 | Stages + dominios + integridad: independientes entre sí |
| 4 | 8 | Revisión final completa con todos los roles |
