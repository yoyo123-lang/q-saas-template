'use client'

/**
 * Tab "Campañas" en la ficha de cliente.
 * Muestra los deliverables CAMPAIGN_PLAN y AD_CREATIVES agrupados por etapa,
 * con vistas estructuradas legibles (no JSON crudo) y acción para enviar al cliente.
 */

import { useState, useTransition } from 'react'
import type { OrgWithDetails } from '@/lib/types'
import { DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL } from '@/lib/badges'
import { sendCampaignDeliverableToClient } from '@/lib/campaign-actions'
import { CampaignPlanViewer } from './CampaignPlanViewer'
import { AdCreativesViewer } from './AdCreativesViewer'
import { AdVisualsViewer } from './AdVisualsViewer'

const CAMPAIGN_TYPES = new Set(['CAMPAIGN_PLAN', 'AD_CREATIVES', 'AD_VISUALS'])
const SENDABLE_STATUSES = new Set(['DRAFT', 'ADMIN_APPROVED', 'READY'])

// ── Botón de envío al cliente ──────────────────────────────────────────────────

function SendToClientButton({ deliverableId, orgId }: { deliverableId: string; orgId: string }) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [sent, setSent] = useState(false)

  function handleSend() {
    setError(null)
    startTransition(async () => {
      const result = await sendCampaignDeliverableToClient(deliverableId, orgId)
      if (result.ok) {
        setSent(true)
      } else {
        setError(result.error ?? 'Error desconocido')
      }
    })
  }

  if (sent) {
    return (
      <div className="mt-3">
        <p className="text-xs text-[#10B981] font-medium">✓ Enviado al cliente</p>
      </div>
    )
  }

  return (
    <div className="mt-3">
      <button
        type="button"
        onClick={handleSend}
        disabled={isPending}
        className="px-3 py-1.5 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 text-white text-xs font-medium transition-colors"
      >
        {isPending ? 'Enviando…' : 'Enviar al cliente'}
      </button>
      {error && <p className="mt-1 text-xs text-[#F87171]">{error}</p>}
    </div>
  )
}

// ── Componente principal ───────────────────────────────────────────────────────

interface CampanasTabProps {
  stages: OrgWithDetails['stages']
  orgId: string
}

export function CampanasTab({ stages, orgId }: CampanasTabProps) {
  const stagesWithCampaigns = stages
    .map((s) => ({
      ...s,
      deliverables: s.deliverables.filter((d) => CAMPAIGN_TYPES.has(d.type)),
    }))
    .filter((s) => s.deliverables.length > 0)

  if (stagesWithCampaigns.length === 0) {
    return (
      <div className="space-y-4">
        <p className="text-[#64748B] text-sm">
          No hay entregables de campaña generados aún.
        </p>
        <p className="text-xs text-[#475569]">
          Los entregables de campaña aparecen cuando el cliente completa la etapa de Campañas.
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 overflow-y-auto flex-1 pb-4">
      {stagesWithCampaigns.map((stage) => (
        <div key={stage.id} className="space-y-3">
          {/* Encabezado de etapa */}
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-[#1E293B] flex items-center justify-center text-[10px] font-bold text-[#64748B]">
              {stage.number}
            </span>
            <h3 className="text-sm font-semibold text-white">{stage.name}</h3>
          </div>

          {stage.deliverables.map((d) => {
            const badge = DELIVERABLE_STATUS_BADGE[d.status]
            const canSend = SENDABLE_STATUSES.has(d.status)

            return (
              <div key={d.id} className="p-4 rounded-lg bg-[#0B0F1A] border border-[#1E293B] space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm text-white leading-snug">{d.title}</p>
                    <p className="text-xs text-[#475569] mt-0.5">
                      {DELIVERABLE_TYPE_LABEL[d.type]} · v{d.version}
                    </p>
                  </div>
                  <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
                    {badge.label}
                  </span>
                </div>

                {d.feedback && (
                  <p className="text-xs text-[#F87171] italic">&ldquo;{d.feedback}&rdquo;</p>
                )}

                {/* Visor estructurado según tipo */}
                {d.type === 'CAMPAIGN_PLAN' && <CampaignPlanViewer data={d.content} />}
                {d.type === 'AD_CREATIVES' && <AdCreativesViewer data={d.content} />}
                {d.type === 'AD_VISUALS' && <AdVisualsViewer data={d.content} />}

                {canSend && (
                  <SendToClientButton deliverableId={d.id} orgId={orgId} />
                )}
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}
