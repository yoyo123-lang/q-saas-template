# Sesión 08: Ventas y POS (backend) + Tesorería

## Objetivo
Motor de ventas que orquesta la transacción completa: crear venta → descontar stock → emitir factura → registrar pago en caja. Tesorería básica con apertura/cierre de caja. Mock de Qobra como medio de pago. Al terminar, el backend soporta el flujo completo de una venta.

## Pre-requisitos
- Sesión 05 y 06 completadas (facturación ARCA)
- Sesión 07 completada (stock)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/lib/services/invoice-service.ts` (S05)
3. Leer `src/lib/services/stock-service.ts` (S07)
4. Leer `prisma/schema.prisma` — modelos Sale, SaleItem, CashRegister, PaymentRecord
5. Leer `src/types/invoice.ts` para entender la integración con facturación

---

## Etapa 1: Servicio de ventas

### Tarea 1.1: SaleService
**Archivo nuevo**: `src/lib/services/sale-service.ts`

```typescript
// Servicio que orquesta el flujo completo de una venta.
// Este es el servicio más complejo porque coordina Stock + Facturación + Tesorería.
//
// Métodos:
//
// createSale(params: CreateSaleParams): Promise<SaleResult>
//   Flujo en transacción Prisma:
//   1. Validar que hay caja abierta (si se requiere registro en caja)
//   2. Crear Sale con status PENDING y los SaleItems
//   3. Para cada item con trackStock:
//      - Llamar StockService.registerMovement(type: SALE)
//      - Si falla por stock insuficiente → rollback todo
//   4. Si el cliente requiere factura:
//      - Llamar InvoiceService.createInvoice() con los items de la venta
//      - Asociar invoice.saleId = sale.id
//   5. Registrar PaymentRecords (puede ser múltiples medios de pago)
//   6. Actualizar Sale: status = COMPLETED, completedAt = now()
//   7. Si hay caja abierta: asociar la venta a la caja
//   8. Retornar { sale, invoice?, stockMovements, paymentRecords }
//
// cancelSale(saleId): Promise<void>
//   1. Verificar que la venta está COMPLETED
//   2. Revertir stock (crear movimientos RETURN)
//   3. Si tiene factura: emitir NC por el total
//   4. Marcar venta como CANCELLED
//
// getSaleSummary(organizationId, dateFrom, dateTo): Promise<SaleSummary>
//   - Total de ventas en el período
//   - Cantidad de ventas
//   - Venta promedio
//   - Desglose por medio de pago
//   - Este método se usa para reportes (S10)
//
// Tipos:
// CreateSaleParams {
//   organizationId, contactId?,
//   items: { productId, quantity, unitPrice, ivaRate, discount? }[],
//   payments: { method: PaymentMethod, amount: number, reference? }[],
//   cashRegisterId?,
//   emitInvoice: boolean  // true si el cliente pide factura
//   notes?
// }
//
// SaleResult {
//   sale: Sale & { items: SaleItem[] },
//   invoice: Invoice | null,
//   stockMovements: StockMovement[],
//   paymentRecords: PaymentRecord[]
// }
```

### Tarea 1.2: Tests unitarios de SaleService
**Archivo nuevo**: `src/lib/services/__tests__/sale-service.test.ts`

Tests (con mocks de InvoiceService, StockService, Prisma):
- Venta simple: crear sale + descontar stock + registrar pago → sale COMPLETED
- Venta con factura: crear sale + factura → sale tiene invoiceId
- Venta sin stock suficiente → error, no se crea nada
- Venta con múltiples medios de pago (ej: parte efectivo, parte tarjeta)
- Cancelar venta → revierte stock, emite NC
- `getSaleSummary` calcula totales correctamente

**Commit**: `feat(sales): add SaleService orchestrating stock + invoice + payment`

---

## Etapa 2: API routes de ventas

### Tarea 2.1: Validaciones Zod
**Archivo nuevo**: `src/lib/validations/sale.ts`

Schemas:
- `createSaleSchema`:
  - contactId (optional cuid — null para consumidor final anónimo)
  - items: array (min 1) de:
    - productId (cuid, requerido)
    - quantity (number, min 0.0001)
    - unitPrice (number, min 0)
    - ivaRate (enum de tasas válidas)
    - discount (optional number, min 0)
  - payments: array (min 1) de:
    - method (enum PaymentMethod)
    - amount (number, min 0.01)
    - reference (optional string)
  - emitInvoice (boolean, default false)
  - cashRegisterId (optional cuid)
  - notes (optional string)
  - Validación custom: sum(payments.amount) >= total calculado de items
- `saleFilterSchema`: status, contactId, dateFrom, dateTo, page, perPage
- `cancelSaleSchema`: reason (optional string)

### Tarea 2.2: API routes
**Archivos nuevos**:
- `src/app/api/v1/sales/route.ts` — GET (list), POST (crear venta completa)
- `src/app/api/v1/sales/[id]/route.ts` — GET (detalle con items, invoice, payments)
- `src/app/api/v1/sales/[id]/cancel/route.ts` — POST (cancelar venta)

Comportamiento POST crear:
1. Validar input
2. Validar tenant + rol (OWNER, ADMIN, SELLER)
3. Llamar `SaleService.createSale()`
4. Retornar SaleResult completo

Comportamiento GET list:
- Paginado, filtros por estado, contacto, fecha
- Incluir total, medio de pago principal, tiene factura?
- Ordenado por fecha descendente

### Tarea 2.3: Tests de integración
**Archivo nuevo**: `src/app/api/v1/sales/__tests__/sales.test.ts`

Tests:
- Crear venta completa (con mock de ARCA)
- Crear venta sin factura
- Crear venta con múltiples medios de pago
- Cancelar venta
- Listar con filtros
- Rol VIEWER no puede crear ventas

**Commit**: `feat(api): add Sale CRUD endpoints`

---

## Etapa 3: Tesorería — Caja diaria

### Tarea 3.1: Validaciones Zod
**Archivo nuevo**: `src/lib/validations/cash-register.ts`

Schemas:
- `openCashRegisterSchema`: name (optional, default "Caja 1"), openingAmount (number, min 0)
- `closeCashRegisterSchema`: closingAmount (number, min 0)

### Tarea 3.2: CashRegisterService
**Archivo nuevo**: `src/lib/services/cash-register-service.ts`

```typescript
// Métodos:
//
// openRegister(organizationId, userId, params): Promise<CashRegister>
//   - Verificar que no hay otra caja abierta con el mismo nombre en la org
//   - Crear CashRegister con status OPEN
//
// closeRegister(registerId, userId, closingAmount): Promise<CashRegister>
//   - Calcular expectedAmount: openingAmount + sum(paymentRecords where method=CASH)
//   - difference = closingAmount - expectedAmount
//   - Actualizar status = CLOSED, closedAt, closedById, closingAmount, expectedAmount, difference
//
// getCurrentRegister(organizationId): Promise<CashRegister | null>
//   - Retorna la caja abierta (si hay)
//
// getRegisterSummary(registerId): Promise<RegisterSummary>
//   - Total de ventas en la caja
//   - Desglose por medio de pago
//   - Cantidad de operaciones
```

### Tarea 3.3: API routes de caja
**Archivos nuevos**:
- `src/app/api/v1/cash-registers/route.ts` — GET (historial de cajas), POST (abrir caja)
- `src/app/api/v1/cash-registers/current/route.ts` — GET (caja abierta actual)
- `src/app/api/v1/cash-registers/[id]/route.ts` — GET (detalle con resumen)
- `src/app/api/v1/cash-registers/[id]/close/route.ts` — POST (cerrar caja)

**Commit**: `feat(treasury): add CashRegister service and endpoints`

---

## Etapa 4: Mock Qobra + interfaz de medios de pago

### Tarea 4.1: Interfaz PaymentProvider
**Archivo nuevo**: `src/lib/services/payment-providers/types.ts`

```typescript
// Interfaz que cualquier proveedor de pago debe implementar.
// En Fase 1 solo hay QobraMockProvider. En Fase 2 se reemplaza por QobraProvider real.
//
// interface PaymentProvider {
//   name: string
//   createPayment(amount: number, description: string, metadata?: Record<string, unknown>): Promise<PaymentResult>
//   getPaymentStatus(paymentId: string): Promise<PaymentStatus>
//   cancelPayment(paymentId: string): Promise<void>
// }
//
// PaymentResult { id, status, amount, checkoutUrl?, qrData? }
// PaymentStatus { id, status: 'pending' | 'completed' | 'failed' | 'cancelled', paidAt? }
```

### Tarea 4.2: QobraMockProvider
**Archivo nuevo**: `src/lib/services/payment-providers/qobra-mock.ts`

```typescript
// Implementación mock de PaymentProvider.
// Simula el comportamiento de Qobra para desarrollo.
//
// createPayment: retorna inmediatamente con status 'completed' y un ID random
// getPaymentStatus: siempre retorna 'completed'
// cancelPayment: no-op
//
// En producción, QobraProvider haría llamadas reales a la API de Qobra.
```

### Tarea 4.3: Registro de providers
**Archivo nuevo**: `src/lib/services/payment-providers/index.ts`

```typescript
// Factory que retorna el provider correcto según el PaymentMethod.
// getPaymentProvider(method: PaymentMethod): PaymentProvider | null
//   CASH, DEBIT_CARD, CREDIT_CARD, TRANSFER → null (se registran directamente, sin provider externo)
//   QOBRA, QR → QobraMockProvider
//   OTHER → null
```

### Tarea 4.4: Tests
**Archivo nuevo**: `src/lib/services/payment-providers/__tests__/qobra-mock.test.ts`

Tests:
- createPayment retorna resultado válido
- getPaymentStatus retorna completed
- Interfaz PaymentProvider se cumple

**Commit**: `feat(payments): add PaymentProvider interface and Qobra mock`

---

## Checklist de cierre de sesión

- [ ] SaleService orquesta venta → stock → factura → pago en transacción
- [ ] API routes de ventas (crear, listar, detalle, cancelar)
- [ ] CashRegisterService con apertura/cierre de caja
- [ ] API routes de caja (abrir, cerrar, resumen, historial)
- [ ] Interfaz PaymentProvider con mock de Qobra
- [ ] Validación: sum(pagos) >= total de la venta
- [ ] Validación: stock suficiente antes de vender
- [ ] Cancelación revierte stock y emite NC
- [ ] Tests unitarios y de integración
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
