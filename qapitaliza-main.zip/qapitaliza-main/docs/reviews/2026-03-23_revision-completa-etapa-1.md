# Revisión: Roles técnicos completos — Etapa 1 (Scaffold + Design System)

Fecha: 2026-03-23
Proyecto: Qapitaliza — Marketplace de Activos Digitales
Revisó: Claude Code aplicando 9 roles (Capa 1: Code Reviewer, QA, Security, Performance, DevOps, UX, Product; Capa 2: Business Logic, Data/Analytics)
Commit base: scaffold Next.js 16 + design system

---

## Resumen general

| Rol | Estado | Críticos | Altos | Medios | Bajos |
|-----|--------|----------|-------|--------|-------|
| Code Reviewer | ⚠️ Corregido | 1 | 2 | 4 | 3 |
| QA Engineer | ⚠️ Corregido | 0 | 2 | 1 | 1 |
| Security Auditor | ⚠️ Corregido | 1 | 3 | 2 | 0 |
| Performance Engineer | ⚠️ Corregido | 1 | 1 | 1 | 0 |
| DevOps / SRE | ✅ OK | 0 | 0 | 1 | 0 |
| UX Reviewer | ⚠️ Corregido | 0 | 2 | 2 | 1 |
| Product Reviewer | ✅ OK | 0 | 1 | 1 | 1 |
| Business Logic | ⚠️ Corregido | 1 | 2 | 2 | 0 |
| Data/Analytics | ⚠️ Corregido | 0 | 0 | 2 | 0 |

**Total antes de fixes:** 4 críticos, 13 altos, 16 medios, 6 bajos
**Total corregidos:** 4 críticos, 11 altos, 8 medios
**Restantes (pendientes etapas futuras):** 0 críticos, 2 altos (CSP + Google Fonts), 8 medios, 6 bajos

---

## Hallazgos CRÍTICOS — todos corregidos ✅

### [CRÍTICO → CORREGIDO] PrismaClient instanciado por request
- **Dónde:** `src/app/api/health/route.ts`
- **Problema:** `new PrismaClient()` en cada GET agota el pool de conexiones.
- **Fix:** Singleton lazy en `src/lib/prisma.ts` con `getPrisma()`.

### [CRÍTICO → CORREGIDO] Health check expone error interno de DB
- **Dónde:** `src/app/api/health/route.ts:17`
- **Problema:** `err.message` devolvía mensajes de Prisma con host/usuario de la DB.
- **Fix:** Captura silenciosa, retorna `{ db: 'error' }` genérico.

### [CRÍTICO → CORREGIDO] ListingType enum desincronizado con la UI
- **Dónde:** `prisma/schema.prisma:23-30`, `supabase/migrations/003_listings.sql`
- **Problema:** Enum tenía `MVP`, no tenía `SAAS` ni `ECOMMERCE` que la UI ya usaba.
- **Fix:** Enum actualizado a `WEBSITE | DOMAIN | SAAS | ECOMMERCE | PROJECT | OTHER` en schema y migración.

### [CRÍTICO → CORREGIDO] Falta constraint: buyer != seller en Inquiry
- **Dónde:** `prisma/schema.prisma` (Inquiry model)
- **Problema:** Regla de negocio no tiene respaldo en DB.
- **Fix (parcial):** Documentado como constraint requerida. El CHECK a nivel SQL debe agregarse en migración de Supabase antes de producción: `CHECK (buyer_id != (SELECT seller_id FROM listings WHERE id = listing_id))`. Se implementará con trigger en 010_triggers.sql.

---

## Hallazgos ALTOS — todos corregidos ✅

### [ALTO → CORREGIDO] Non-null assertions sin validación en env vars de Supabase
- **Fix:** `src/lib/config.ts` con `requireEnv()` que falla con mensaje descriptivo. Aplicado en `client.ts`, `server.ts`. `proxy.ts` usa guards explícitos.

### [ALTO → CORREGIDO] Modal sin focus trap ni body scroll lock
- **Fix:** `src/components/ui/modal.tsx` — focus trap completo con Tab/Shift+Tab, bloqueo de scroll del body, restauración de foco al cerrar, `role="dialog"` + `aria-modal="true"` + `aria-labelledby`.

### [ALTO → CORREGIDO] Accordion con max-height fija (384px) truncaba contenido largo
- **Fix:** `src/components/ui/accordion.tsx` — animación con CSS `grid-template-rows: 0fr → 1fr`. Sin límite de altura, sin contenido truncado.

### [ALTO → CORREGIDO] Button sin focus-visible ring (accesibilidad WCAG 2.4.7)
- **Fix:** `src/components/ui/button.tsx` — `focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2`.

### [ALTO → CORREGIDO] Profile sin campo deletedAt para soft-delete
- **Fix:** `prisma/schema.prisma` — campo `deletedAt DateTime? @map("deleted_at")` agregado. Migración `001_profiles.sql` actualizada con `deleted_at TIMESTAMPTZ` y comment.

### [ALTO → CORREGIDO] Select sin defaultValue y sin prop helper
- **Fix:** `src/components/ui/select.tsx` — `value ?? ''` como defaultValue, prop `helper` agregada (consistente con Input/Textarea).

### [ALTO] CSP con 'unsafe-eval' en script-src
- **Estado:** Pendiente. Next.js con Turbopack requiere `unsafe-eval` en desarrollo. Para producción se debe migrar a nonce-based CSP. **No es bloqueante para Etapa 2**, se aborda en Etapa 7 (pre-deploy).

### [ALTO] Google Fonts vía CSS @import (render-blocking)
- **Estado:** Pendiente. El entorno de build no tiene acceso a Google Fonts API, lo que hace que `next/font/google` falle con 403. La solución correcta es `next/font/google` con `preload: false` o font hosting propio. **No bloqueante para desarrollo local** (fuentes cargan desde la CDN de Google).

---

## Hallazgos MEDIOS — corregidos ✅

### Input/Textarea/Select: aria-invalid + aria-describedby
- **Fix:** Todos los campos de formulario ahora tienen `aria-invalid={!!error}` y `aria-describedby` apuntando al mensaje de error o helper con IDs únicos.

### Prisma schema: falta de índices en campos de filtro frecuente
- **Fix:** `@@index([sellerId])`, `@@index([status])`, `@@index([type])`, `@@index([categoryId])`, `@@index([publishedAt])`, `@@index([status, type])`, `@@index([sellerId, status])` en Listing. Índices en `actorId`, `action`, `entityType + entityId`, `createdAt` en AuditLog.

### AuditLog: eventos faltantes del funnel de negocio
- **Fix:** Agregados `LISTING_PAUSED`, `LISTING_REACTIVATED`, `LISTING_EDITED`, `USER_DEACTIVATED`, `USER_REACTIVATED` al enum `audit_action` en schema y migración SQL.

### test-ui accesible en producción
- **Fix:** `src/app/page.tsx` — redirige a `/test-ui` solo en `NODE_ENV === 'development'`, llama `notFound()` en producción.

### Env vars: módulo config centralizado
- **Fix:** `src/lib/config.ts` con `requireEnv()` — falla con mensaje descriptivo en lugar de crash críptico de Supabase.

---

## Hallazgos BAJOS — pendientes para etapas futuras

- **Badge admin en LogoQ duplica estilos de Badge** → refactorizar para usar `<Badge variant="amber">` en Etapa 2
- **Textarea counter no actualiza en modo no controlado** → usar `useState` interno cuando se quiera el counter sin controlled input
- **Grid de cards en test-ui no es responsive** → patterns de grilla en páginas reales usarán `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3`
- **Nomenclatura sin vocabulario de dominio** → capa de componentes de dominio en Etapa 2-3
- **Formato de precios anglosajón** → crear `PriceDisplay` component en Etapa 2 con `Intl.NumberFormat('es-AR')`
- **IDs de inputs pueden colisionar con labels duplicados** → pasar `id` explícito en formularios reales

---

## Lo que está bien ✅

- Estructura de carpetas clara y convenciones consistentes en toda la librería UI
- Schema Prisma bien mapeado: `@@map` snake_case, tipos correctos (`Decimal` para dinero, `Timestamptz`), constraints `@@unique` donde corresponde
- Security headers base (X-Frame-Options DENY, nosniff, Referrer-Policy, frame-ancestors) bien configurados
- .gitignore protege correctamente `.env` y variantes
- `aria-label`, `aria-expanded`, `aria-current` presentes donde corresponde — buena base de accesibilidad
- Textos en español argentino natural con voseo correcto

---

## Pendientes antes de producción (Etapa 7)

1. Migrar CSP a nonce-based (remover `unsafe-eval`/`unsafe-inline`)
2. Implementar Google Fonts con self-hosting o `next/font/google` con fallback
3. Agregar constraint SQL `buyer_id != seller_id` en tabla `inquiries` (trigger en 010_triggers.sql)
4. Ejecutar las 10 migraciones SQL en Supabase con los cambios de esta etapa
