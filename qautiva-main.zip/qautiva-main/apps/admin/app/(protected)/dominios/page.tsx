import type { Metadata } from 'next'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import type { DomainStatus } from '@qautiva/db'

export const metadata: Metadata = { title: 'Dominios | Qautiva Admin' }
export const dynamic = 'force-dynamic'

// ── Helpers ─────────────────────────────────────────────────────────────────

const STATUS_BADGE: Record<DomainStatus, { label: string; className: string }> = {
  ACTIVE:          { label: 'Activo',           className: 'bg-[#10B981]/15 text-[#10B981]' },
  PENDING_PAYMENT: { label: 'Pago pendiente',   className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  PENDING:         { label: 'Pendiente',         className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  REGISTERING:     { label: 'Registrando',       className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  RENEWAL_DUE:     { label: 'Renovación próx.',  className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  FAILED:          { label: 'Fallido',           className: 'bg-[#EF4444]/15 text-[#F87171]' },
  EXPIRED:         { label: 'Expirado',          className: 'bg-[#EF4444]/15 text-[#F87171]' },
  CANCELLED:       { label: 'Cancelado',         className: 'bg-[#64748B]/15 text-[#94A3B8]' },
}

const VALID_STATUSES = [
  'ALL', 'ACTIVE', 'PENDING_PAYMENT', 'PENDING', 'REGISTERING',
  'FAILED', 'EXPIRED', 'CANCELLED',
] as const
type StatusFilter = typeof VALID_STATUSES[number]

const PAGE_SIZE = 50

// ── Query ────────────────────────────────────────────────────────────────────

async function getDomains(statusFilter: StatusFilter, page: number) {
  const where = statusFilter !== 'ALL' ? { status: statusFilter as DomainStatus } : {}
  const [domains, total] = await Promise.all([
    prisma.domain.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      select: {
        id: true,
        domainName: true,
        tld: true,
        status: true,
        teamId: true,
        period: true,
        costUsd: true,
        expiresAt: true,
        createdAt: true,
      },
    }),
    prisma.domain.count({ where }),
  ])
  return { domains, total }
}

// ── Page ─────────────────────────────────────────────────────────────────────

interface PageProps {
  searchParams: { status?: string; page?: string }
}

export default async function DominiosPage({ searchParams }: PageProps) {
  const rawStatus = searchParams.status ?? 'ALL'
  const statusFilter: StatusFilter = (VALID_STATUSES as readonly string[]).includes(rawStatus)
    ? (rawStatus as StatusFilter)
    : 'ALL'

  const rawPage = parseInt(searchParams.page ?? '1', 10)
  const page = isNaN(rawPage) || rawPage < 1 ? 1 : rawPage

  const { domains, total } = await getDomains(statusFilter, page)
  const pages = Math.ceil(total / PAGE_SIZE)

  const tabs: { value: StatusFilter; label: string }[] = [
    { value: 'ALL',             label: 'Todos' },
    { value: 'ACTIVE',          label: 'Activos' },
    { value: 'PENDING_PAYMENT', label: 'Pago pendiente' },
    { value: 'PENDING',         label: 'Pendientes' },
    { value: 'REGISTERING',     label: 'Registrando' },
    { value: 'FAILED',          label: 'Fallidos' },
    { value: 'EXPIRED',         label: 'Expirados' },
    { value: 'CANCELLED',       label: 'Cancelados' },
  ]

  return (
    <div className="flex flex-col h-full p-6 gap-5">
      {/* Header */}
      <div>
        <h1 className="text-white text-xl font-bold">Dominios</h1>
        <p className="text-[#64748B] text-sm mt-0.5">
          {total} dominio{total !== 1 ? 's' : ''}
          {statusFilter !== 'ALL'
            ? ` · filtro: "${STATUS_BADGE[statusFilter as DomainStatus]?.label ?? statusFilter}"`
            : ''}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <Link
            key={tab.value}
            href={`/dominios?status=${tab.value}`}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              statusFilter === tab.value
                ? 'bg-[#8B5CF6] text-white'
                : 'text-[#64748B] hover:text-white hover:bg-[#1E293B]'
            }`}
          >
            {tab.label}
          </Link>
        ))}
      </div>

      {/* Tabla */}
      {domains.length === 0 ? (
        <p className="text-[#64748B] text-sm">Sin dominios en este estado.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[#1E293B]">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[#64748B] border-b border-[#1E293B] bg-[#0F172A]">
                <th className="px-4 py-3 font-medium">Dominio</th>
                <th className="px-4 py-3 font-medium">Team</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3 font-medium">Período</th>
                <th className="px-4 py-3 font-medium">Costo USD</th>
                <th className="px-4 py-3 font-medium">Expira</th>
                <th className="px-4 py-3 font-medium">Creado</th>
              </tr>
            </thead>
            <tbody>
              {domains.map((d) => {
                const badge = STATUS_BADGE[d.status] ?? { label: d.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }
                return (
                  <tr
                    key={d.id}
                    className="border-b border-[#1E293B] last:border-0 hover:bg-[#0F172A] transition-colors"
                  >
                    <td className="px-4 py-3">
                      <Link
                        href={`/dominios/${d.id}`}
                        className="text-[#A78BFA] hover:underline font-mono text-xs"
                      >
                        {d.domainName}.{d.tld}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8] font-mono text-xs">
                      {d.teamId.slice(0, 8)}…
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
                        {badge.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8]">
                      {d.period} año{d.period !== 1 ? 's' : ''}
                    </td>
                    <td className="px-4 py-3 text-white font-medium">
                      ${Number(d.costUsd).toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs">
                      {d.expiresAt ? d.expiresAt.toLocaleDateString('es-AR') : '—'}
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs">
                      {d.createdAt.toLocaleDateString('es-AR')}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Paginación */}
      {pages > 1 && (
        <div className="flex items-center gap-2 text-sm">
          {page > 1 && (
            <Link
              href={`/dominios?status=${statusFilter}&page=${page - 1}`}
              className="px-3 py-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-[#1E293B] transition-colors"
            >
              ← Anterior
            </Link>
          )}
          <span className="text-[#64748B]">
            Página {page} de {pages}
          </span>
          {page < pages && (
            <Link
              href={`/dominios?status=${statusFilter}&page=${page + 1}`}
              className="px-3 py-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-[#1E293B] transition-colors"
            >
              Siguiente →
            </Link>
          )}
        </div>
      )}
    </div>
  )
}
