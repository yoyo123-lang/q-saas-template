import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { OrderStatus } from '@qautiva/db'
import {
  getProfileOrUnauthorized,
  serializeOrder,
  filterOrderByRole,
  isValidHttpUrl,
  ORDER_RESPONSE_SELECT,
} from '@/lib/api/marketplace-helpers'

// ── Máquina de estados ────────────────────────────────────────────────────────

type Role = 'editor' | 'advertiser'

const ALLOWED_TRANSITIONS: Record<Role, Partial<Record<OrderStatus, OrderStatus[]>>> = {
  editor: {
    [OrderStatus.PENDING]: [OrderStatus.ACCEPTED, OrderStatus.CANCELLED],
    [OrderStatus.ACCEPTED]: [OrderStatus.DELIVERED],
    // Después de una revisión del anunciante, el editor puede re-entregar
    [OrderStatus.REVISION]: [OrderStatus.DELIVERED],
  },
  advertiser: {
    // El anunciante puede cancelar mientras la orden espera aceptación del editor
    [OrderStatus.PENDING]: [OrderStatus.CANCELLED],
    [OrderStatus.DELIVERED]: [OrderStatus.COMPLETED, OrderStatus.REVISION, OrderStatus.DISPUTED],
  },
}

// ── PATCH /api/marketplace/orders/[id] ────────────────────────────────────────
// Maneja transiciones de estado según el rol del usuario autenticado.
//
// Editor:
//   PENDING   → ACCEPTED   (setea acceptedAt, deliveryDeadline)
//   PENDING   → CANCELLED  (setea cancelledAt, cancellationReason opcional)
//   ACCEPTED  → DELIVERED  (setea deliveredAt, requiere deliveryUrl)
//   REVISION  → DELIVERED  (re-entrega tras corrección, requiere deliveryUrl)
//
// Anunciante:
//   DELIVERED → COMPLETED  (setea completedAt)
//   DELIVERED → REVISION   (editor debe corregir y re-entregar)
//   DELIVERED → DISPUTED   (admin interviene)

type PatchOrderBody = {
  status: string
  deliveryUrl?: string
  deliveryNotes?: string
  cancellationReason?: string
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } },
): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()
  const { id } = params

  if (!id) {
    return NextResponse.json({ error: 'El campo id es requerido' }, { status: 400 })
  }

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: PatchOrderBody
  try {
    body = (await request.json()) as PatchOrderBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { status: newStatus, deliveryUrl, deliveryNotes, cancellationReason } = body

  if (!newStatus || !Object.values(OrderStatus).includes(newStatus as OrderStatus)) {
    return NextResponse.json({ error: 'Estado inválido o requerido' }, { status: 400 })
  }
  if (deliveryUrl !== undefined && deliveryUrl.trim() && !isValidHttpUrl(deliveryUrl.trim())) {
    return NextResponse.json({ error: 'deliveryUrl debe ser una URL válida (http/https)' }, { status: 400 })
  }
  if (deliveryNotes !== undefined && deliveryNotes.length > 2000) {
    return NextResponse.json({ error: 'deliveryNotes no puede superar los 2000 caracteres' }, { status: 400 })
  }
  if (cancellationReason !== undefined && cancellationReason.length > 2000) {
    return NextResponse.json({ error: 'cancellationReason no puede superar los 2000 caracteres' }, { status: 400 })
  }

  // Buscar la orden con la info necesaria para validar la transición
  const order = await prisma.order.findUnique({
    where: { id },
    select: {
      id: true,
      status: true,
      advertiserId: true,
      expiresAt: true,
      medium: { select: { userId: true } },
      product: { select: { deliveryDays: true } },
    },
  })

  if (!order) {
    return NextResponse.json({ error: 'Orden no encontrada' }, { status: 404 })
  }

  // Determinar rol del usuario sobre esta orden
  const isAdvertiser = order.advertiserId === profile.id
  const isEditor = order.medium.userId === profile.id

  if (!isAdvertiser && !isEditor) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  // Si el usuario es ambos (edge case), el rol de editor tiene precedencia para entregas
  const role: Role = isEditor ? 'editor' : 'advertiser'

  // Validar transición permitida para este rol
  const allowed = ALLOWED_TRANSITIONS[role][order.status] ?? []
  if (!allowed.includes(newStatus as OrderStatus)) {
    return NextResponse.json({ error: 'Transición no permitida' }, { status: 409 })
  }

  // [CRÍTICO] Validar que la orden no haya expirado antes de aceptar
  if (newStatus === OrderStatus.ACCEPTED && new Date() > order.expiresAt) {
    return NextResponse.json(
      { error: 'La orden expiró y no puede ser aceptada' },
      { status: 409 },
    )
  }

  // deliveryUrl es requerido para cualquier transición a DELIVERED
  if (newStatus === OrderStatus.DELIVERED) {
    if (!deliveryUrl || !deliveryUrl.trim()) {
      return NextResponse.json({ error: 'deliveryUrl es requerido al entregar' }, { status: 400 })
    }
  }

  // Construir payload de actualización según la transición
  const now = new Date()

  type OrderUpdateData = {
    status: OrderStatus
    acceptedAt?: Date
    deliveryDeadline?: Date
    deliveredAt?: Date
    deliveryUrl?: string
    deliveryNotes?: string | null
    completedAt?: Date
    cancelledAt?: Date
    cancellationReason?: string | null
  }

  const updateData: OrderUpdateData = { status: newStatus as OrderStatus }

  switch (newStatus as OrderStatus) {
    case OrderStatus.ACCEPTED: {
      const deliveryDeadline = new Date(now)
      deliveryDeadline.setDate(deliveryDeadline.getDate() + order.product.deliveryDays)
      updateData.acceptedAt = now
      updateData.deliveryDeadline = deliveryDeadline
      break
    }
    case OrderStatus.DELIVERED: {
      updateData.deliveredAt = now
      updateData.deliveryUrl = deliveryUrl!.trim()
      updateData.deliveryNotes = deliveryNotes?.trim() || null
      break
    }
    case OrderStatus.COMPLETED: {
      updateData.completedAt = now
      break
    }
    case OrderStatus.CANCELLED: {
      updateData.cancelledAt = now
      updateData.cancellationReason = cancellationReason?.trim() || null
      break
    }
  }

  try {
    // Optimistic lock: el where incluye el status esperado.
    // Si otra request cambió el estado entre el findUnique y este update,
    // Prisma lanza P2025 (record not found) y devolvemos 409 en lugar de
    // aplicar una transición sobre un estado ya modificado.
    const updated = await prisma.order.update({
      where: { id, status: order.status },
      data: updateData,
      select: ORDER_RESPONSE_SELECT,
    })

    console.info('[PATCH /api/marketplace/orders/:id]', {
      reqId,
      orderId: id,
      from: order.status,
      to: newStatus,
      role,
      userId: profile.id,
    })

    const serialized = serializeOrder(updated)
    // El anunciante no debe ver el margen de la plataforma ni el pago al editor.
    const response = role === 'advertiser' ? filterOrderByRole(serialized, 'advertiser') : serialized
    return NextResponse.json({ order: response })
  } catch (err) {
    // P2025: el status cambió entre el read y el write (race condition)
    if (
      err instanceof Error &&
      'code' in err &&
      (err as { code: string }).code === 'P2025'
    ) {
      return NextResponse.json(
        { error: 'El estado de la orden fue modificado concurrentemente. Intentá de nuevo.' },
        { status: 409 },
      )
    }
    console.error('[PATCH /api/marketplace/orders/:id] Prisma update failed', {
      reqId,
      orderId: id,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al actualizar la orden' }, { status: 500 })
  }
}
