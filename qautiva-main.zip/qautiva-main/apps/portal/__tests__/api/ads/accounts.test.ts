import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

const PROJECT_UUID = '00000000-0000-4000-a000-000000000001'
const ACCOUNT_UUID = '00000000-0000-4000-a000-000000000002'

// vi.hoisted permite usar estas variables en los factories de vi.mock
// que se ejecutan antes que el resto del módulo de test
const { mockGetUser, prismaMocks } = vi.hoisted(() => {
  const mockGetUser = vi.fn()
  const prismaMocks = {
    userProfileFindFirst: vi.fn(),
    projectFindFirst: vi.fn(),
    adAccountFindMany: vi.fn(),
    adAccountFindFirst: vi.fn(),
    adAccountUpdate: vi.fn(),
  }
  return { mockGetUser, prismaMocks }
})

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: { findFirst: (...args: unknown[]) => prismaMocks.userProfileFindFirst(...args) },
    project: { findFirst: (...args: unknown[]) => prismaMocks.projectFindFirst(...args) },
    adAccount: {
      findMany: (...args: unknown[]) => prismaMocks.adAccountFindMany(...args),
      findFirst: (...args: unknown[]) => prismaMocks.adAccountFindFirst(...args),
      update: (...args: unknown[]) => prismaMocks.adAccountUpdate(...args),
    },
  },
}))

const mockUser = { id: 'user-auth-1' }
const mockProfile = { teamMemberships: [{ teamId: 'team-1' }] }
const mockProject = { id: PROJECT_UUID, teamId: 'team-1' }
const mockAccounts = [
  {
    id: ACCOUNT_UUID,
    platform: 'GOOGLE_ADS',
    name: 'Mi Google Ads',
    status: 'ACTIVE',
    tokenExpiresAt: null,
    metadata: null,
    revokedAt: null,
    createdAt: new Date(),
  },
]

import { GET, DELETE } from '@/app/api/ads/accounts/route'

describe('GET /api/ads/accounts', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    prismaMocks.userProfileFindFirst.mockResolvedValue(mockProfile)
    prismaMocks.projectFindFirst.mockResolvedValue(mockProject)
    prismaMocks.adAccountFindMany.mockResolvedValue(mockAccounts)
  })

  it('devuelve las cuentas del proyecto', async () => {
    const req = new NextRequest(`http://localhost/api/ads/accounts?projectId=${PROJECT_UUID}`)
    const res = await GET(req)
    expect(res.status).toBe(200)
    const data = await res.json() as { accounts: typeof mockAccounts }
    expect(data.accounts).toHaveLength(1)
    expect(data.accounts[0]!.platform).toBe('GOOGLE_ADS')
  })

  it('retorna 400 si falta projectId', async () => {
    const req = new NextRequest('http://localhost/api/ads/accounts')
    const res = await GET(req)
    expect(res.status).toBe(400)
  })

  it('retorna 401 si no está autenticado', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: new Error('no auth') })
    const req = new NextRequest(`http://localhost/api/ads/accounts?projectId=${PROJECT_UUID}`)
    const res = await GET(req)
    expect(res.status).toBe(401)
  })

  it('retorna 404 si el proyecto no pertenece al usuario (previene IDOR)', async () => {
    prismaMocks.projectFindFirst.mockResolvedValue(null)
    const req = new NextRequest(`http://localhost/api/ads/accounts?projectId=${PROJECT_UUID}`)
    const res = await GET(req)
    expect(res.status).toBe(404)
  })

  it('nunca incluye accessToken ni refreshToken en la respuesta', async () => {
    prismaMocks.adAccountFindMany.mockResolvedValue([
      { ...mockAccounts[0], accessToken: 'SHOULD_NOT_APPEAR', refreshToken: 'SHOULD_NOT_APPEAR' },
    ])
    const req = new NextRequest(`http://localhost/api/ads/accounts?projectId=${PROJECT_UUID}`)
    const res = await GET(req)
    const data = await res.json() as { accounts: Record<string, unknown>[] }
    expect(data.accounts[0]).not.toHaveProperty('accessToken')
    expect(data.accounts[0]).not.toHaveProperty('refreshToken')
  })
})

describe('DELETE /api/ads/accounts', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    prismaMocks.userProfileFindFirst.mockResolvedValue(mockProfile)
    prismaMocks.adAccountFindFirst.mockResolvedValue({ id: ACCOUNT_UUID })
    prismaMocks.adAccountUpdate.mockResolvedValue({})
  })

  it('desconecta la cuenta correctamente y marca revokedAt', async () => {
    const req = new NextRequest(`http://localhost/api/ads/accounts?accountId=${ACCOUNT_UUID}`, { method: 'DELETE' })
    const res = await DELETE(req)
    expect(res.status).toBe(200)
    const data = await res.json() as { ok: boolean }
    expect(data.ok).toBe(true)
    expect(prismaMocks.adAccountUpdate).toHaveBeenCalledWith({
      where: { id: ACCOUNT_UUID },
      data: { status: 'DISCONNECTED', revokedAt: expect.any(Date) as Date },
    })
  })

  it('retorna 400 si falta accountId', async () => {
    const req = new NextRequest('http://localhost/api/ads/accounts', { method: 'DELETE' })
    const res = await DELETE(req)
    expect(res.status).toBe(400)
  })

  it('retorna 401 si no está autenticado', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: new Error('no auth') })
    const req = new NextRequest(`http://localhost/api/ads/accounts?accountId=${ACCOUNT_UUID}`, { method: 'DELETE' })
    const res = await DELETE(req)
    expect(res.status).toBe(401)
  })

  it('retorna 404 si la cuenta no pertenece al usuario (previene IDOR)', async () => {
    prismaMocks.adAccountFindFirst.mockResolvedValue(null)
    const req = new NextRequest(`http://localhost/api/ads/accounts?accountId=${ACCOUNT_UUID}`, { method: 'DELETE' })
    const res = await DELETE(req)
    expect(res.status).toBe(404)
  })
})
