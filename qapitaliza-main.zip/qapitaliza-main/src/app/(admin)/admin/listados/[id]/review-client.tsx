'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  ArrowLeft, Star, StarOff, CheckCircle, XCircle, ShoppingBag, ExternalLink,
} from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  approveListing,
  rejectListing,
  featureListing,
  unfeatureListing,
  markListingAsSold,
} from '@/lib/actions/admin'
import type { AdminListingItem } from '@/lib/data/admin'

const STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Borrador',
  PENDING_REVIEW: 'En revisión',
  PUBLISHED: 'Publicado',
  PAUSED: 'Pausado',
  SOLD: 'Vendido',
  REJECTED: 'Rechazado',
}

const STATUS_VARIANTS: Record<string, 'success' | 'amber' | 'info' | 'muted' | 'danger'> = {
  DRAFT: 'muted',
  PENDING_REVIEW: 'amber',
  PUBLISHED: 'success',
  PAUSED: 'muted',
  SOLD: 'info',
  REJECTED: 'danger',
}

const TYPE_LABELS: Record<string, string> = {
  WEBSITE: 'Sitio web',
  DOMAIN: 'Dominio',
  SAAS: 'SaaS',
  ECOMMERCE: 'E-commerce',
  PROJECT: 'Proyecto',
  OTHER: 'Otro',
}

interface Props {
  listing: AdminListingItem
}

export function AdminListingReview({ listing }: Props) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [showRejectField, setShowRejectField] = useState(false)
  const [rejectReason, setRejectReason] = useState('')
  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  const isFeatured = listing.featuredUntil && new Date(listing.featuredUntil) > new Date()
  const isRejectDisabled = rejectReason.trim().length < 20

  async function handleApprove() {
    setErrorMsg(null)
    const result = await approveListing(listing.id)
    if (result.success) {
      toast.success('Listado publicado')
      startTransition(() => router.push('/admin/listados'))
    } else {
      setErrorMsg(result.error ?? 'Error al aprobar el listado.')
    }
  }

  async function handleReject() {
    if (isRejectDisabled) return
    setErrorMsg(null)
    const result = await rejectListing(listing.id, rejectReason.trim())
    if (result.success) {
      toast.success('Listado rechazado')
      startTransition(() => router.push('/admin/listados'))
    } else {
      setErrorMsg(result.error ?? 'Error al rechazar el listado.')
    }
  }

  async function handleFeature() {
    setErrorMsg(null)
    const result = await (isFeatured ? unfeatureListing(listing.id) : featureListing(listing.id))
    if (!result.success) {
      setErrorMsg(result.error ?? 'Error al cambiar el estado destacado.')
    }
    startTransition(() => router.refresh())
  }

  async function handleMarkSold() {
    setErrorMsg(null)
    const result = await markListingAsSold(listing.id)
    if (!result.success) {
      setErrorMsg(result.error ?? 'Error al marcar como vendido.')
    }
    startTransition(() => router.refresh())
  }

  return (
    <div className="space-y-6">
      {/* Back */}
      <Link
        href="/admin/listados"
        className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-50 transition-colors"
      >
        <ArrowLeft className="size-4" />
        Volver a listados
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Title + status */}
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <h1 className="text-xl font-bold text-slate-50">{listing.title}</h1>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant={STATUS_VARIANTS[listing.status] ?? 'muted'}>
                    {STATUS_LABELS[listing.status] ?? listing.status}
                  </Badge>
                  <Badge variant="muted">{TYPE_LABELS[listing.type] ?? listing.type}</Badge>
                  {isFeatured && <Badge variant="amber">Destacado</Badge>}
                </div>
              </div>
              <span className="text-2xl font-bold text-amber-500 whitespace-nowrap">
                {listing.currency} {Number(listing.askingPrice).toLocaleString()}
              </span>
            </div>

            {/* Screenshot */}
            {listing.screenshotUrls?.[0] && (
              <img
                src={listing.screenshotUrls[0]}
                alt={listing.title}
                className="w-full max-h-80 object-cover rounded-xl mb-4"
              />
            )}

            <h2 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-2">
              Descripción
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">{listing.description}</p>

            {listing.url && (
              <a
                href={listing.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 mt-3 text-xs text-amber-500 hover:underline"
              >
                {listing.url}
                <ExternalLink className="size-3" />
              </a>
            )}
          </div>

          {/* Metrics */}
          {(listing.monthlyRevenue || listing.monthlyTraffic || listing.domainAge) && (
            <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-4">
                Métricas declaradas
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {listing.monthlyRevenue != null && (
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-xs text-slate-400 mb-1">Ingresos / mes</p>
                    <p className="font-semibold text-slate-50">
                      ${Number(listing.monthlyRevenue).toLocaleString()}
                    </p>
                  </div>
                )}
                {listing.monthlyTraffic != null && (
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-xs text-slate-400 mb-1">Tráfico / mes</p>
                    <p className="font-semibold text-slate-50">
                      {listing.monthlyTraffic.toLocaleString()}
                    </p>
                  </div>
                )}
                {listing.domainAge != null && (
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <p className="text-xs text-slate-400 mb-1">Antigüedad</p>
                    <p className="font-semibold text-slate-50">{listing.domainAge} años</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Tech stack */}
          {listing.techStack && listing.techStack.length > 0 && (
            <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
              <h2 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-3">
                Tech stack
              </h2>
              <div className="flex flex-wrap gap-2">
                {listing.techStack.map((tech) => (
                  <span key={tech} className="px-2.5 py-1 bg-slate-800 text-slate-300 text-sm rounded-md">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Prior rejection */}
          {listing.rejectionReason && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4">
              <p className="text-sm font-medium text-amber-500 mb-1">Rechazado anteriormente</p>
              <p className="text-sm text-amber-400">{listing.rejectionReason}</p>
            </div>
          )}
        </div>

        {/* Admin sidebar */}
        <div className="space-y-4">
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-6 space-y-3 lg:sticky lg:top-6">
            <h2 className="text-sm font-semibold text-slate-50 mb-1">Acciones de moderación</h2>

            {errorMsg && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <p className="text-xs text-red-400">{errorMsg}</p>
              </div>
            )}

            <Button
              variant="solid"
              size="full"
              className="bg-emerald-500 hover:bg-emerald-400 text-white border-emerald-500 hover:border-emerald-400"
              onClick={handleApprove}
              loading={isPending}
              disabled={listing.status === 'PUBLISHED'}
            >
              <CheckCircle className="size-4" />
              Aprobar y publicar
            </Button>

            {!showRejectField ? (
              <Button
                variant="outline-danger"
                size="full"
                onClick={() => setShowRejectField(true)}
                disabled={isPending}
              >
                <XCircle className="size-4" />
                Rechazar
              </Button>
            ) : (
              <div className="space-y-2">
                <textarea
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-500 resize-none focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="Motivo del rechazo (mínimo 20 caracteres)..."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  rows={3}
                  maxLength={500}
                  autoFocus
                />
                <p className="text-xs text-slate-500 text-right">
                  {rejectReason.length} / 500
                  {isRejectDisabled && ` — mínimo 20`}
                </p>
                <Button
                  variant="outline-danger"
                  size="full"
                  onClick={handleReject}
                  disabled={isRejectDisabled || isPending}
                >
                  Confirmar rechazo
                </Button>
                <Button
                  variant="ghost"
                  size="full"
                  onClick={() => { setShowRejectField(false); setRejectReason('') }}
                >
                  Cancelar
                </Button>
              </div>
            )}

            <div className="h-px bg-slate-800" />

            <Button variant="outline" size="full" onClick={handleFeature} disabled={isPending}>
              {isFeatured ? (
                <><StarOff className="size-4" /> Quitar destacado</>
              ) : (
                <><Star className="size-4" /> Destacar</>
              )}
            </Button>

            <Button
              variant="ghost"
              size="full"
              onClick={handleMarkSold}
              disabled={isPending || listing.status === 'SOLD'}
            >
              <ShoppingBag className="size-4" />
              Marcar como vendido
            </Button>
          </div>

          {/* Seller */}
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-sm font-semibold text-slate-50 mb-4">Vendedor</h2>
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-full bg-amber-500 flex items-center justify-center text-sm font-bold text-navy-950 flex-shrink-0">
                {(listing.seller.fullName ?? listing.seller.email ?? 'U')[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-200 truncate">
                  {listing.seller.fullName ?? listing.seller.email}
                </p>
                <p className="text-xs text-slate-500 truncate">{listing.seller.email}</p>
              </div>
            </div>
            <Link
              href={`/admin/usuarios/${listing.seller.id}`}
              className="mt-3 flex items-center gap-1 text-xs text-amber-500 hover:underline"
            >
              Ver perfil del vendedor
              <ExternalLink className="size-3" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
