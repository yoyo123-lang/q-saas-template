import Handlebars from 'handlebars'
import { executeToolCall, type BillingContext, type ToolDefinition } from './ai-tool-call'
import { SERVICE_SECTION_TEMPLATES, SERVICE_SECTION_ORDER } from './service-section-templates'
import type { QuestionBlock } from './types'

// ── Handlebars sandbox + cache ────────────────────────────────────────────────

// Instancia aislada del Handlebars global: evita que helpers registrados
// en otros módulos (si los hubiera) afecten los templates de sitios web.
// ⚠️ Node.js only — no compatible con Vercel Edge Runtime.
const _hbs = Handlebars.create()

// Cache de templates compilados (módulo-level). Evita recompilar el mismo
// htmlBase en múltiples sesiones dentro del mismo proceso serverless warm.
const _templateCache = new Map<string, HandlebarsTemplateDelegate>()

// ── Tipos ─────────────────────────────────────────────────────────────────────

export interface WebsiteCopy {
  /** Frase central del negocio (max 10 palabras) */
  slogan: string
  seo: {
    /** Título SEO (max 60 chars) */
    title: string
    /** Descripción SEO (max 160 chars) */
    description: string
  }
  /** Solo las secciones activas (sections[key] === true) */
  sections: {
    [sectionKey: string]: {
      /** Título de la sección */
      heading: string
      /** Subtítulo opcional */
      subheading?: string
      /** Párrafo descriptivo (max 200 palabras) */
      body?: string
      /** Call to action de esta sección */
      cta?: string
      /** Para secciones tipo lista (servicios, precios) */
      items?: Array<{
        title: string
        description: string
      }>
    }
  }
}

// ── Tool definition ───────────────────────────────────────────────────────────

/**
 * Secciones posibles en cualquier template web. Se usan como keys explícitas
 * en el schema para compatibilidad con OpenAI strict mode (prohíbe additionalProperties).
 *
 * ⚠️ Al agregar un template nuevo con una sección que no esté en esta lista,
 * hay que agregar la key acá para que el LLM pueda generar copy para esa sección.
 * Ejemplo: si se agrega un template con sección "faq" o "team", agregar 'faq'/'team' aquí.
 */
const SECTION_KEYS = [
  'hero', 'about', 'services', 'contact', 'pricing',
  'booking', 'payments', 'careers', 'blog',
] as const

/**
 * Schema JSON de una sección de copy. Compatible con OpenAI strict mode:
 * - type: ['object', 'null'] — null indica que la sección no está activa
 * - Todos los campos en required; los opcionales usan null union
 * - additionalProperties: false
 */
const sectionSchema = {
  type: ['object', 'null'],
  properties: {
    heading:    { type: 'string' },
    subheading: { type: ['string', 'null'] },
    body:       { type: ['string', 'null'], description: 'Párrafo descriptivo, máximo 200 palabras.' },
    cta:        { type: ['string', 'null'] },
    items: {
      type: ['array', 'null'],
      items: {
        type: 'object',
        properties: {
          title:       { type: 'string' },
          description: { type: 'string' },
        },
        required: ['title', 'description'],
        additionalProperties: false,
      },
    },
  },
  required: ['heading', 'subheading', 'body', 'cta', 'items'],
  additionalProperties: false,
}

/**
 * Tool que fuerza al modelo a devolver el WebsiteCopy como JSON estructurado.
 * Compatible con Anthropic tool_use y OpenAI function calling con strict: true.
 *
 * El schema cumple los requisitos de OpenAI strict mode:
 * - additionalProperties: false en todos los objetos
 * - Todas las propiedades en required (opcionales usan null union)
 * - Sin anyOf/oneOf arbitrarios
 */
const GENERATE_WEBSITE_COPY_TOOL: ToolDefinition = {
  name: 'generate_website_copy',
  description:
    'Genera el copy completo para el sitio web de un negocio argentino a partir de la información recopilada en la entrevista.',
  input_schema: {
    type: 'object',
    properties: {
      slogan: {
        type: 'string',
        description: 'Frase central del negocio, máximo 10 palabras.',
      },
      seo: {
        type: 'object',
        properties: {
          title: {
            type: 'string',
            description: 'Título SEO, máximo 60 caracteres.',
          },
          description: {
            type: 'string',
            description: 'Descripción SEO, máximo 160 caracteres.',
          },
        },
        required: ['title', 'description'],
        additionalProperties: false,
      },
      sections: {
        type: 'object',
        description:
          'Todas las secciones posibles. Devolvé un objeto para las secciones activas y null para las inactivas.',
        properties: Object.fromEntries(SECTION_KEYS.map((k) => [k, sectionSchema])),
        required: [...SECTION_KEYS],
        additionalProperties: false,
      },
    },
    required: ['slogan', 'seo', 'sections'],
    additionalProperties: false,
  },
}

// ── Prompt del copywriter ─────────────────────────────────────────────────────

const COPYWRITER_SYSTEM_PROMPT = `Sos el copywriter de Qautiva. Tu trabajo es generar el copy completo para el sitio web de un negocio argentino, basándote en toda la información disponible: brief estratégico, estudio de mercado, marca, y la entrevista web.

El copy debe:
- Estar en español argentino natural (vos, che, etc. si corresponde al tono)
- Reflejar el tono de la marca. Si hay datos de marca (brand kit), usar ese tono. Si no hay datos de marca disponibles, usá tono profesional.
- Usar el nombre real del negocio y sus datos reales — no inventar
- El slogan: si el brand kit tiene un eslogan, usarlo. Si no, generá uno acorde al rubro y propuesta de valor.
- El CTA principal: inferirlo del objetivo del sitio (ej: "captar consultas" → "Consultá ahora"). Si hay un CTA explícito en los datos, usarlo.
- Para secciones activas: generá el copy completo con contenido real del negocio
- Para secciones inactivas: devolvé null. No inventes contenido para secciones que el usuario no activó.
- El SEO debe ser específico al negocio, no genérico
- Aprovechar la propuesta de valor, diferenciadores, y público objetivo del brief estratégico para copy más preciso

Acción: Llamá a generate_website_copy con el copy completo.`

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Genera el WebsiteCopy a partir de las respuestas de la entrevista y la
 * configuración del template seleccionado.
 * Usa el provider/modelo configurado en TrialConfig (admin panel).
 *
 * @param params.flowDefinition - Preguntas de la entrevista (para contexto)
 * @param params.answers - Respuestas del usuario { questionId: value }
 * @param params.webTemplate - Template seleccionado con sus variables y secciones
 * @param params.brandKit - Kit de marca del negocio (nombre, colores, logo, etc.)
 * @returns WebsiteCopy estructurado con todo el copy listo para aplicar
 * @throws Error si el modelo falla, no devuelve la tool, o la respuesta se trunca
 */
export async function generateWebsiteCopy(params: {
  flowDefinition: QuestionBlock[]
  answers: Record<string, unknown>
  webTemplate: {
    name: string
    htmlBase: string | null
    variables: Record<string, string> | null
    sections: Record<string, boolean>
    css: string | null
  }
  brandKit: Record<string, unknown> | null
  /** Deliverables de etapas anteriores (brief, mercado, marca) para enriquecer el prompt */
  previousDeliverables?: Array<{ type: string; content: unknown }>
  /** Secciones activas derivadas de respuestas v2 — override de webTemplate.sections para el prompt */
  activeSections?: string[]
  billingContext?: BillingContext
}): Promise<WebsiteCopy> {
  const { flowDefinition, answers, webTemplate, brandKit, previousDeliverables, activeSections, billingContext } = params

  const interviewContent = buildInterviewContent(flowDefinition, answers, webTemplate, brandKit, previousDeliverables, activeSections)

  const result = await executeToolCall({
    system: COPYWRITER_SYSTEM_PROMPT,
    userMessage: `Acá está la información del negocio recopilada en la entrevista:\n\n${interviewContent}\n\nGenerá el copy completo para el sitio web.`,
    tool: GENERATE_WEBSITE_COPY_TOOL,
    maxTokens: 4096,
    logPrefix: 'website-generator',
    billingContext: billingContext ? { ...billingContext, operation: 'website_copy' } : undefined,
  })

  return validateWebsiteCopy(result.input)
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Escapa caracteres HTML especiales para prevenir XSS al inyectar strings en HTML.
 */
function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
}

/**
 * Valida en runtime que el output del modelo tenga la estructura de WebsiteCopy.
 * Incluye coerción automática para casos comunes donde el modelo devuelve
 * formatos ligeramente incorrectos (ej: sections como array en vez de objeto).
 *
 * @internal Exportada solo para tests. No usar fuera de este módulo en producción.
 */
export function validateWebsiteCopy(raw: unknown): WebsiteCopy {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error('[website-generator] Output no es un objeto')
  }
  const obj = raw as Record<string, unknown>
  if (typeof obj['slogan'] !== 'string' || !obj['slogan']) {
    throw new Error('[website-generator] Output: slogan debe ser string no vacío')
  }
  if (typeof obj['seo'] !== 'object' || obj['seo'] === null) {
    throw new Error('[website-generator] Output: seo debe ser objeto')
  }
  const seo = obj['seo'] as Record<string, unknown>
  if (typeof seo['title'] !== 'string') {
    throw new Error('[website-generator] Output: seo.title debe ser string')
  }
  if (typeof seo['description'] !== 'string') {
    throw new Error('[website-generator] Output: seo.description debe ser string')
  }

  // Coerción: si el modelo devolvió sections como array de objetos con key/name,
  // convertir a objeto keyed. Esto pasa cuando el modelo interpreta "secciones"
  // como lista en vez de mapa.
  let sections = obj['sections']
  if (Array.isArray(sections)) {
    console.warn('[website-generator] sections es array, coercionando a objeto')
    const coerced: Record<string, unknown> = {}
    let idx = 0
    for (const item of sections) {
      if (typeof item === 'object' && item !== null) {
        const entry = item as Record<string, unknown>
        // Inferir key del nombre, id, o key del item
        const rawKey = (entry['key'] ?? entry['id'] ?? entry['name'] ?? entry['heading']) as string | undefined
        let sanitizedKey = rawKey
          ? rawKey.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
          : `section_${idx}`
        // Evitar colisión de keys: agregar sufijo numérico si ya existe
        if (sanitizedKey in coerced) {
          sanitizedKey = `${sanitizedKey}_${idx}`
        }
        coerced[sanitizedKey] = entry
      }
      idx++
    }
    if (Object.keys(coerced).length > 0) {
      sections = coerced
      obj['sections'] = coerced
    } else {
      throw new Error('[website-generator] Output: sections es array pero ningún elemento tiene key identificable')
    }
  }

  if (typeof sections !== 'object' || sections === null || Array.isArray(sections)) {
    const received = sections === null ? 'null' : Array.isArray(sections) ? 'array' : typeof sections
    throw new Error(`[website-generator] Output: sections debe ser objeto (recibido: ${received})`)
  }

  // Validar que cada sección tenga al menos heading
  const sectionsObj = sections as Record<string, unknown>
  for (const [key, value] of Object.entries(sectionsObj)) {
    if (typeof value !== 'object' || value === null) {
      console.warn(`[website-generator] sección "${key}" no es objeto, removiendo`)
      delete sectionsObj[key]
      continue
    }
    const section = value as Record<string, unknown>
    if (typeof section['heading'] !== 'string' || !section['heading']) {
      // Si no tiene heading pero tiene title, usar title como heading
      if (typeof section['title'] === 'string' && section['title']) {
        section['heading'] = section['title']
      } else {
        console.warn(`[website-generator] sección "${key}" sin heading, usando key como heading`)
        section['heading'] = key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' ')
      }
    }
    // Limpiar nulls de campos opcionales: strict mode los devuelve como null, pero el tipo
    // espera undefined. Los eliminamos para que applyWebsiteCopy y buildTemplateContext
    // puedan usar `!== undefined` de forma segura.
    for (const field of ['subheading', 'body', 'cta', 'items'] as const) {
      if (section[field] === null) delete section[field]
    }
  }

  return obj as unknown as WebsiteCopy
}

/**
 * Valida que una URL de imagen use protocolo http/https (bloquea javascript:, data:, etc.)
 */
function isSafeImageUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'http:' || parsed.protocol === 'https:'
  } catch {
    return false
  }
}

/**
 * Construye el contenido del prompt con toda la info relevante para el copywriter.
 * Incluye deliverables de etapas anteriores (brief, mercado, marca) cuando están disponibles.
 */
function buildInterviewContent(
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
  webTemplate: {
    name: string
    sections: Record<string, boolean>
  },
  brandKit: Record<string, unknown> | null,
  previousDeliverables?: Array<{ type: string; content: unknown }>,
  activeSectionsOverride?: string[],
): string {
  const parts: string[] = []

  // En v2 las secciones activas vienen derivadas de las respuestas del usuario,
  // no del template en DB (que puede estar vacío). Usar override cuando disponible.
  const activeSections = activeSectionsOverride
    ?? Object.entries(webTemplate.sections)
        .filter(([, active]) => active)
        .map(([key]) => key)

  parts.push(`Template: ${webTemplate.name}`)
  parts.push(`Secciones activas: ${activeSections.join(', ')}`)

  // Deliverables de etapas anteriores — enriquecen el contexto del copywriter.
  // Nota: el contenido es generado por nuestros propios LLMs (brief-generator,
  // market-study-generator, brand-generator). Los usuarios no editan deliverables
  // directamente, por lo que el riesgo de prompt injection es mínimo.
  // Se trunca cada deliverable a 8KB para evitar prompts excesivos.
  const MAX_DELIVERABLE_CHARS = 8000
  let hasBrandKitDeliverable = false

  if (previousDeliverables && previousDeliverables.length > 0) {
    const DELIVERABLE_LABELS: Record<string, string> = {
      BRIEF: 'Brief Estratégico (Etapa 1)',
      MARKET_STUDY: 'Estudio de Mercado (Etapa 2)',
      BRAND_OPTIONS: 'Opciones de Marca (Etapa 3)',
    }

    for (const deliverable of previousDeliverables) {
      if (deliverable.type === 'BRAND_OPTIONS') hasBrandKitDeliverable = true
      const label = DELIVERABLE_LABELS[deliverable.type] ?? deliverable.type
      parts.push(`\n--- ${label} ---`)
      let text: string
      if (typeof deliverable.content === 'string') {
        text = deliverable.content
      } else if (deliverable.content !== null && deliverable.content !== undefined) {
        text = JSON.stringify(deliverable.content, null, 2)
      } else {
        continue
      }
      if (text.length > MAX_DELIVERABLE_CHARS) {
        text = text.slice(0, MAX_DELIVERABLE_CHARS) + '\n...(truncado)'
      }
      parts.push(text)
    }
  }

  // Solo incluir brandKit si no hay un deliverable BRAND_KIT (evitar duplicación)
  if (!hasBrandKitDeliverable && brandKit && Object.keys(brandKit).length > 0) {
    parts.push('\n--- Kit de Marca ---')
    for (const [key, value] of Object.entries(brandKit)) {
      if (value !== null && value !== undefined) {
        parts.push(`${key}: ${typeof value === 'string' ? value : JSON.stringify(value)}`)
      }
    }
  }

  const tplAnswers = Object.entries(answers).filter(([key]) => key.startsWith('tpl_'))
  if (tplAnswers.length > 0) {
    parts.push('\n--- Respuestas de personalización del template ---')
    for (const [key, value] of tplAnswers) {
      const answerText =
        value === undefined
          ? '(sin respuesta)'
          : typeof value === 'string'
            ? value
            : JSON.stringify(value)
      parts.push(`${key}: ${answerText}`)
    }
  }

  parts.push('\n--- Transcripción de la entrevista ---')
  if (flowDefinition.length === 0) {
    parts.push('(Sin preguntas registradas)')
  } else {
    const interviewLines = flowDefinition.map((q, i) => {
      const answer = answers[q.id]
      const answerText =
        answer === undefined
          ? '(sin respuesta)'
          : typeof answer === 'string'
            ? answer
            : JSON.stringify(answer)
      return `Pregunta ${i + 1}: ${q.question}\nRespuesta: ${answerText}`
    })
    parts.push(interviewLines.join('\n\n'))
  }

  return parts.join('\n')
}

// ── Contexto plano para template engine ──────────────────────────────────────

/**
 * Transforma WebsiteCopy + brandKit en un objeto plano de strings compatible
 * con placeholders {{variable}} para Handlebars.
 *
 * Aplica escapeHtml a todos los valores. Excluye keys sin valor (undefined).
 * URLs de logo se validan con isSafeImageUrl antes de incluirlas.
 *
 * SEGURIDAD: applyWebsiteCopy usa noEscape:true en Handlebars para evitar
 * double-escaping. Por eso, TODOS los valores de este objeto DEBEN estar
 * HTML-escaped. No agregar valores sin pasar por escapeHtml().
 *
 * @internal Exportada para tests.
 */
export function buildTemplateContext(
  copy: WebsiteCopy,
  brandKit: Record<string, unknown> | null,
  contactAnswers?: Record<string, string>,
): Record<string, string> {
  const ctx: Record<string, string> = {
    slogan:          escapeHtml(copy.slogan),
    seo_title:       escapeHtml(copy.seo.title),
    seo_description: escapeHtml(copy.seo.description),
  }

  if (brandKit) {
    if (typeof brandKit['businessName'] === 'string') {
      ctx['business_name'] = escapeHtml(brandKit['businessName'])
    }
    if (typeof brandKit['logoUrl'] === 'string' && isSafeImageUrl(brandKit['logoUrl'])) {
      ctx['logo_url'] = escapeHtml(brandKit['logoUrl'])
    }
  }

  if (contactAnswers) {
    if (contactAnswers['whatsapp']) ctx['whatsapp'] = escapeHtml(contactAnswers['whatsapp'])
    if (contactAnswers['email']) ctx['email'] = escapeHtml(contactAnswers['email'])
    if (contactAnswers['redes']) ctx['redes'] = escapeHtml(contactAnswers['redes'])
  }

  for (const [sectionKey, section] of Object.entries(copy.sections)) {
    ctx[`${sectionKey}_heading`] = escapeHtml(section.heading)
    if (section.subheading !== undefined) {
      ctx[`${sectionKey}_subheading`] = escapeHtml(section.subheading)
    }
    if (section.body !== undefined) {
      ctx[`${sectionKey}_body`] = escapeHtml(section.body)
    }
    if (section.cta !== undefined) {
      ctx[`${sectionKey}_cta`] = escapeHtml(section.cta)
    }
  }

  return ctx
}

// ── Aplicación del copy al HTML ───────────────────────────────────────────────

/**
 * Aplica el copy generado al htmlBase del template reemplazando {{variables}}.
 * Usa Handlebars como template engine: {{variable}} → valor del contexto plano.
 * Placeholders sin valor correspondiente en el contexto quedan como string vacío.
 *
 * Para secciones de servicios Q (booking, payments, careers, blog) que el usuario
 * activó pero el template no tiene nativamente, inserta bloques HTML genéricos
 * antes del cierre del body.
 *
 * @param htmlBase - HTML base del template con placeholders {{variable}}
 * @param copy - Copy generado por el LLM
 * @param brandKit - Kit de marca del negocio
 * @param activeSections - Secciones activas derivadas de las respuestas (opcional, v2 only)
 */
export function applyWebsiteCopy(
  htmlBase: string,
  copy: WebsiteCopy,
  brandKit: Record<string, unknown> | null,
  activeSections?: string[],
  contactAnswers?: Record<string, string>,
): string {
  // Compilar el template con Handlebars. Si el HTML tiene sintaxis inválida
  // (ej: {{#if sin cerrar}) Handlebars lanzará un error — preferible a producir
  // HTML silenciosamente corrupto.
  //
  // Construir el contexto plano. buildTemplateContext ya aplica escapeHtml
  // a todos los valores, por eso usamos noEscape: true arriba para evitar
  // double-escaping.
  let html: string
  try {
    let template = _templateCache.get(htmlBase)
    if (!template) {
      template = _hbs.compile(htmlBase, { noEscape: true })
      _templateCache.set(htmlBase, template)
    }
    const ctx = buildTemplateContext(copy, brandKit, contactAnswers)
    html = template(ctx)

    // Si no hay logo, remover <img> con src="" para evitar íconos rotos.
    // Reemplazar por el nombre del negocio si está disponible.
    if (!ctx['logo_url']) {
      const businessName = ctx['business_name'] ?? ''
      const replacement = businessName
        ? `<span class="logo-text">${businessName}</span>`
        : ''
      html = html.replace(/<img\b[^>]*\bsrc=""[^>]*>/gi, replacement)
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    throw new Error(`[applyWebsiteCopy] Error compilando/renderizando template Handlebars: ${msg}`)
  }

  // Insertar bloques HTML de servicios Q para secciones activas que el template
  // no tiene nativamente. Solo aplica cuando activeSections se pasa (v2 flow).
  if (activeSections && activeSections.length > 0) {
    const missingBlocks: string[] = []

    for (const sectionKey of SERVICE_SECTION_ORDER) {
      if (!activeSections.includes(sectionKey)) continue
      // Si el template ya tiene una sección con este id (comillas dobles o simples), no duplicar
      if (html.includes(`id="${sectionKey}"`) || html.includes(`id='${sectionKey}'`)) continue
      const block = SERVICE_SECTION_TEMPLATES[sectionKey]
      if (block) missingBlocks.push(block)
    }

    if (missingBlocks.length > 0) {
      const insertion = '\n' + missingBlocks.join('\n') + '\n'
      // Insertar antes de </body> si existe, sino al final
      if (html.includes('</body>')) {
        html = html.replace('</body>', insertion + '</body>')
      } else {
        html += insertion
      }
    }
  }

  return html
}
