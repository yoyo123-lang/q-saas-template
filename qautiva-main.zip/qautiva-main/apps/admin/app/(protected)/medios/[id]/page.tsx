import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import type { MediumStatus, MediumPlatform } from '@qautiva/db'
import { ApproveMediaForm } from '@/components/forms/ApproveMediaForm'
import { RejectMediaForm } from '@/components/forms/RejectMediaForm'

// ── Helpers de presentación ────────────────────────────────────────────────────

const PLATFORM_LABEL: Record<MediumPlatform, string> = {
  WEBSITE:   'Web / Blog / Revista',
  INSTAGRAM: 'Instagram',
  FACEBOOK:  'Facebook',
  TWITTER:   'X (Twitter)',
  TIKTOK:    'TikTok',
  YOUTUBE:   'YouTube',
}

const STATUS_BADGE: Record<MediumStatus, { label: string; className: string }> = {
  PENDING_REVIEW: { label: 'Pendiente de revisión', className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  ACTIVE:         { label: 'Activo',                className: 'bg-[#10B981]/15 text-[#10B981]' },
  PAUSED:         { label: 'Pausado',               className: 'bg-[#64748B]/15 text-[#94A3B8]' },
  REJECTED:       { label: 'Rechazado',             className: 'bg-[#EF4444]/15 text-[#F87171]' },
  SUSPENDED:      { label: 'Suspendido',            className: 'bg-[#EF4444]/20 text-[#F87171]' },
}

// ── Query ──────────────────────────────────────────────────────────────────────

async function getMedium(id: string) {
  return prisma.medium.findUnique({
    where: { id, deletedAt: null },
    select: {
      id: true,
      name: true,
      handle: true,
      url: true,
      platform: true,
      description: true,
      language: true,
      country: true,
      status: true,
      verified: true,
      rejectionReason: true,
      adminNotes: true,
      followersCount: true,
      monthlyVisits: true,
      domainAuthority: true,
      linkType: true,
      publishesOnHome: true,
      maxLinks: true,
      completedOrders: true,
      cancelledOrders: true,
      avgRating: true,
      createdAt: true,
      updatedAt: true,
      user: {
        select: { id: true, displayName: true },
      },
      categories: {
        select: { category: { select: { id: true, name: true } } },
      },
      products: {
        where: { active: true },
        orderBy: { price: 'asc' },
        select: {
          id: true,
          name: true,
          type: true,
          price: true,
          deliveryDays: true,
          includesWriting: true,
        },
      },
    },
  })
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const medium = await prisma.medium.findUnique({
    where: { id: params.id, deletedAt: null },
    select: { name: true },
  })
  return { title: medium ? `${medium.name} | Medios Admin` : 'Medio | Qautiva Admin' }
}

// ── Page ───────────────────────────────────────────────────────────────────────

export default async function MedioDetailPage({ params }: { params: { id: string } }) {
  const medium = await getMedium(params.id)
  if (!medium) notFound()

  const badge = STATUS_BADGE[medium.status] ?? { label: medium.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }

  return (
    <div className="flex flex-col p-6 gap-6 max-w-3xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-[#64748B]">
        <Link href="/medios" className="hover:text-white transition-colors">
          Medios
        </Link>
        <span>/</span>
        <span className="text-white">{medium.name}</span>
      </div>

      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-white text-xl font-bold">{medium.name}</h1>
          {medium.handle && (
            <p className="text-[#64748B] text-sm">@{medium.handle}</p>
          )}
          <p className="text-[#64748B] text-sm mt-0.5">
            {PLATFORM_LABEL[medium.platform]} · Editor: {medium.user.displayName}
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium flex-shrink-0 ${badge.className}`}>
          {badge.label}
        </span>
      </div>

      {/* Info principal */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
        <h2 className="text-white text-sm font-semibold">Información</h2>
        <dl className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm">
          <div>
            <dt className="text-[#64748B]">URL</dt>
            <dd>
              <a
                href={medium.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#A78BFA] hover:underline break-all"
              >
                {medium.url}
              </a>
            </dd>
          </div>
          <div>
            <dt className="text-[#64748B]">País / Idioma</dt>
            <dd className="text-white">{medium.country} / {medium.language}</dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Verificado</dt>
            <dd className="text-white">{medium.verified ? '✓ Sí' : '✕ No'}</dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Categorías</dt>
            <dd className="text-white">
              {medium.categories.length > 0
                ? medium.categories.map((c) => c.category.name).join(', ')
                : '—'}
            </dd>
          </div>
          {medium.description && (
            <div className="col-span-2">
              <dt className="text-[#64748B]">Descripción</dt>
              <dd className="text-white mt-0.5">{medium.description}</dd>
            </div>
          )}
        </dl>
      </section>

      {/* Métricas */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
        <h2 className="text-white text-sm font-semibold">Métricas declaradas</h2>
        <dl className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <dt className="text-[#64748B]">Seguidores / Visitas</dt>
            <dd className="text-white font-medium">
              {medium.followersCount != null
                ? medium.followersCount.toLocaleString('es-AR')
                : '—'}
            </dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Visitas/mes</dt>
            <dd className="text-white font-medium">
              {medium.monthlyVisits != null
                ? medium.monthlyVisits.toLocaleString('es-AR')
                : '—'}
            </dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Domain Authority</dt>
            <dd className="text-white font-medium">
              {medium.domainAuthority != null ? medium.domainAuthority : '—'}
            </dd>
          </div>
          {medium.platform === 'WEBSITE' && (
            <>
              <div>
                <dt className="text-[#64748B]">Tipo de enlace</dt>
                <dd className="text-white">{medium.linkType ?? '—'}</dd>
              </div>
              <div>
                <dt className="text-[#64748B]">Publica en portada</dt>
                <dd className="text-white">
                  {medium.publishesOnHome == null ? '—' : medium.publishesOnHome ? 'Sí' : 'No'}
                </dd>
              </div>
              <div>
                <dt className="text-[#64748B]">Máx. enlaces</dt>
                <dd className="text-white">{medium.maxLinks ?? '—'}</dd>
              </div>
            </>
          )}
        </dl>
      </section>

      {/* Productos activos */}
      {medium.products.length > 0 && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
          <h2 className="text-white text-sm font-semibold">
            Productos ({medium.products.length})
          </h2>
          <div className="flex flex-col gap-2">
            {medium.products.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between text-sm border-b border-[#1E293B] last:border-0 pb-2 last:pb-0"
              >
                <div>
                  <span className="text-white">{p.name}</span>
                  <span className="text-[#64748B] ml-2 text-xs">{p.type}</span>
                  {p.includesWriting && (
                    <span className="ml-2 text-[#8B5CF6] text-xs">Incluye redacción</span>
                  )}
                </div>
                <div className="text-right flex-shrink-0 ml-4">
                  <span className="text-white font-medium">
                    ${Number(p.price).toLocaleString('es-AR')}
                  </span>
                  <span className="text-[#64748B] ml-2 text-xs">{p.deliveryDays}d</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Notas de moderación */}
      {(medium.rejectionReason || medium.adminNotes) && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
          <h2 className="text-white text-sm font-semibold">Moderación</h2>
          {medium.rejectionReason && (
            <div>
              <p className="text-[#64748B] text-xs mb-1">Motivo de rechazo</p>
              <p className="text-[#F87171] text-sm">{medium.rejectionReason}</p>
            </div>
          )}
          {medium.adminNotes && (
            <div>
              <p className="text-[#64748B] text-xs mb-1">Notas internas</p>
              <p className="text-[#94A3B8] text-sm">{medium.adminNotes}</p>
            </div>
          )}
        </section>
      )}

      {/* Acciones — solo si está PENDING_REVIEW */}
      {medium.status === 'PENDING_REVIEW' && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-4">
          <h2 className="text-white text-sm font-semibold">Acciones</h2>
          <div className="flex flex-wrap gap-3">
            <ApproveMediaForm mediumId={medium.id} mediumName={medium.name} />
            <RejectMediaForm mediumId={medium.id} mediumName={medium.name} />
          </div>
        </section>
      )}

      {/* Footer con timestamps */}
      <p className="text-[#475569] text-xs">
        Creado: {medium.createdAt.toLocaleString('es-AR')} ·
        Actualizado: {medium.updatedAt.toLocaleString('es-AR')}
      </p>
    </div>
  )
}
