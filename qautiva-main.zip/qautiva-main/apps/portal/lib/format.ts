const _arsFormatter = new Intl.NumberFormat('es-AR', {
  style: 'currency',
  currency: 'ARS',
  maximumFractionDigits: 0,
})

/**
 * Formatea un monto en pesos argentinos.
 * @example formatARS(45000) → "$45.000"
 */
export function formatARS(amount: number): string {
  return _arsFormatter.format(amount)
}

/**
 * Formatea un monto en pesos argentinos con sufijo "/mes".
 * @example formatARSPerMonth(45000) → "$45.000/mes"
 */
export function formatARSPerMonth(amount: number): string {
  return `${formatARS(amount)}/mes`
}

/**
 * Abrevia números grandes con sufijo K/M en formato argentino (coma decimal).
 * @example formatNumber(1500000) → "1,5M"
 * @example formatNumber(25000)   → "25K"
 */
export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace('.', ',')}M`
  if (n >= 1_000) return `${Math.round(n / 1_000)}K`
  return n.toString()
}

/**
 * Formatea una fecha en español argentino.
 * @example formatDate(new Date()) → "12 de mar. de 2026"
 */
export function formatDate(d: Date | string | null): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('es-AR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}
