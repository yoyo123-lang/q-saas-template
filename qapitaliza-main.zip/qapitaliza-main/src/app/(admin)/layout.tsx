import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getPrisma } from '@/lib/prisma'
import { Sidebar } from '@/components/layout/sidebar'
import { DashboardShell } from '@/components/layout/dashboard-shell'
import { getPendingListingsCount } from '@/lib/data/admin'

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  // Auth guard: must be ADMIN
  const profile = await getPrisma().profile.findUnique({
    where: { id: user.id },
    select: { role: true, fullName: true, email: true },
  })

  if (!profile || profile.role !== 'ADMIN') {
    redirect('/dashboard')
  }

  const name = profile.fullName ?? profile.email ?? user.email ?? 'Admin'
  const initials = name
    .split(' ')
    .slice(0, 2)
    .map((n: string) => n[0]?.toUpperCase() ?? '')
    .join('')

  const sidebarUser = {
    name,
    email: profile.email ?? user.email ?? '',
    role: 'ADMIN',
    avatarInitials: initials || 'A',
  }

  let pendingCount = 0
  try {
    pendingCount = await getPendingListingsCount()
  } catch {
    // Non-blocking — sidebar still renders
  }

  return (
    <DashboardShell
      sidebar={<Sidebar variant="admin" user={sidebarUser} pendingCount={pendingCount} />}
    >
      {children}
    </DashboardShell>
  )
}
