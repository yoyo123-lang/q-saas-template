import { prisma } from '@qautiva/db'
import type { BillingPlan, UsageSource } from '@qautiva/db'

export interface BillingEligibilityResult {
  eligible: boolean
  /** Razón del bloqueo, presente solo si eligible=false. */
  reason?: string
  /** Plan de billing actual del team. */
  billingPlan: BillingPlan
  /**
   * Fuente de consumo a usar en registerAiUsage().
   * Siempre presente; solo significativo si eligible=true.
   */
  source: UsageSource
}

/**
 * Verifica si un team puede ejecutar una operación de IA.
 *
 * Lógica por plan:
 * - BYOK: siempre eligible (el usuario paga su propia API key)
 * - FREE_TRIAL: trialExpiresAt > now() (si está configurado) AND trialTokensUsed < trialTokensTotal
 * - PREPAID: balanceUsd > 0
 * - MONTHLY / YEARLY: balanceUsd >= 0 (suscripción activa)
 *
 * @throws Error CRITICAL si no existe BillingAccount para el team.
 * @returns BillingEligibilityResult con eligible, billingPlan y source.
 */
export async function checkBillingEligibility(teamId: string): Promise<BillingEligibilityResult> {
  const account = await prisma.billingAccount.findUnique({
    where: { teamId },
    select: {
      plan: true,
      preferredKeySource: true,
      trialExpiresAt: true,
      trialTokensUsed: true,
      trialTokensTotal: true,
      balanceUsd: true,
    },
  })

  if (!account) {
    const msg = `CRITICAL: BillingAccount no encontrado para teamId=${teamId}. No se puede verificar elegibilidad.`
    console.error(msg, { teamId })
    throw new Error(msg)
  }

  const { plan, preferredKeySource, trialExpiresAt, trialTokensUsed, trialTokensTotal, balanceUsd } = account

  // ── BYOK: siempre eligible (excepto FREE_TRIAL — el trial tiene sus propios límites) ──
  if (preferredKeySource === 'BYOK' && plan !== 'FREE_TRIAL') {
    return { eligible: true, billingPlan: plan, source: 'BYOK' }
  }

  // ── FREE_TRIAL ─────────────────────────────────────────────────────────────
  if (plan === 'FREE_TRIAL') {
    if (trialExpiresAt && trialExpiresAt < new Date()) {
      return {
        eligible: false,
        reason: 'Trial expirado. Actualizá tu plan para continuar.',
        billingPlan: plan,
        source: 'TRIAL',
      }
    }

    if (trialTokensTotal === 0) {
      return {
        eligible: false,
        reason: 'Trial no configurado. Contactá a soporte para activar tu cuenta.',
        billingPlan: plan,
        source: 'TRIAL',
      }
    }

    if (trialTokensUsed >= trialTokensTotal) {
      return {
        eligible: false,
        reason: 'Tokens de trial agotados. Actualizá tu plan para continuar.',
        billingPlan: plan,
        source: 'TRIAL',
      }
    }

    return { eligible: true, billingPlan: plan, source: 'TRIAL' }
  }

  // ── PREPAID ────────────────────────────────────────────────────────────────
  if (plan === 'PREPAID') {
    const balance = balanceUsd.toNumber()
    if (balance <= 0) {
      return {
        eligible: false,
        reason: 'Saldo insuficiente. Recargá tu cuenta para continuar.',
        billingPlan: plan,
        source: 'QAUTIVA_HOSTED',
      }
    }
    return { eligible: true, billingPlan: plan, source: 'QAUTIVA_HOSTED' }
  }

  // ── MONTHLY / YEARLY: suscripción activa — verificar balanceUsd >= 0 ─────────
  // El CHECK constraint de DB (016_billing_balance_check.sql) previene saldo negativo,
  // pero este check de aplicación actúa como segunda línea de defensa.
  const subscriptionBalance = balanceUsd.toNumber()
  if (subscriptionBalance < 0) {
    return {
      eligible: false,
      reason: 'Cuenta sin saldo disponible. Contactá a soporte para regularizar tu cuenta.',
      billingPlan: plan,
      source: 'QAUTIVA_HOSTED',
    }
  }

  return { eligible: true, billingPlan: plan, source: 'QAUTIVA_HOSTED' }
}
