-- ============================================================
-- ROLLBACK 002 — Categories
-- ============================================================

DROP TABLE IF EXISTS public.categories CASCADE;
