import { NextResponse } from 'next/server'

export const runtime = 'edge'

export function GET() {
  return NextResponse.json({
    status: 'ok',
    ts: Date.now(),
    env: process.env.NODE_ENV,
    version: process.env.NEXT_PUBLIC_APP_VERSION ?? 'unknown',
  })
}
