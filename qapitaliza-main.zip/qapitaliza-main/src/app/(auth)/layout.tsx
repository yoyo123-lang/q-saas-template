import { LogoQ } from '@/components/shared/logo-q'

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      {/* Columna decorativa — oculta en mobile */}
      <div className="hidden md:flex bg-navy-950 mesh-gradient-amber flex-col items-center justify-center p-12 gap-4">
        <LogoQ size="lg" showText />
        <p className="text-slate-400 text-base mt-1">El marketplace de activos digitales</p>
        <p className="text-sm text-slate-500">Más de 340 emprendedores ya operan en Qapitaliza</p>
      </div>

      {/* Columna formulario */}
      <div className="bg-navy-900 flex items-center justify-center p-8 min-h-screen md:min-h-0">
        {children}
      </div>
    </div>
  )
}
