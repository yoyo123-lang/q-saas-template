'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createIndustry } from '../actions'
import type { CreateActionState } from '../actions'

function SubmitButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Creando...' : 'Crear industria'}
    </button>
  )
}

export default function NuevaIndustriaPage() {
  const router = useRouter()
  const [state, setState] = useState<CreateActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  useEffect(() => {
    if (state?.ok) {
      router.push(`/industrias/${state.id}`)
    }
  }, [state, router])

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await createIndustry(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <div className="p-8 max-w-lg">
      {/* Breadcrumb */}
      <Link
        href="/industrias"
        className="inline-flex items-center gap-1 text-sm text-[#64748B] hover:text-[#94A3B8] mb-6 transition-colors"
      >
        ← Industrias
      </Link>

      <h1 className="text-2xl font-bold text-white mb-6">Nueva industria</h1>

      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6">
        <form action={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="name" className="text-sm font-medium text-[#94A3B8]">
              Nombre <span className="text-red-400">*</span>
            </label>
            <input
              id="name"
              name="name"
              type="text"
              required
              maxLength={200}
              placeholder="Ej: Salud y Bienestar"
              className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
            />
          </div>

          {state && !state.ok && (
            <p className="text-sm text-red-400">{state.error}</p>
          )}

          <div className="flex items-center gap-3 pt-2">
            <SubmitButton pending={isPending} />
            <Link
              href="/industrias"
              className="px-4 py-2 text-sm text-[#64748B] hover:text-[#94A3B8] transition-colors"
            >
              Cancelar
            </Link>
          </div>
        </form>
      </div>
    </div>
  )
}
