'use client'

import { useRef, useState, useTransition } from 'react'
import { sendAdminMessage } from '@/lib/actions'

interface IntervenirFormProps {
  orgId: string
}

export function IntervenirForm({ orgId }: IntervenirFormProps) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)

  function handleSubmit(formData: FormData) {
    const content = formData.get('content') as string

    // Confirmación antes de enviar: acción irreversible visible para el cliente
    if (!confirm(`¿Enviás este mensaje como si fuera la IA?\n\n"${content}"\n\nEsta acción es visible para el cliente.`)) {
      return
    }

    setError(null)
    setSuccess(false)
    startTransition(async () => {
      try {
        await sendAdminMessage(formData)
        formRef.current?.reset()
        setSuccess(true)
        // Limpiar el éxito después de 3 segundos
        setTimeout(() => setSuccess(false), 3000)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error al enviar el mensaje')
      }
    })
  }

  return (
    <form ref={formRef} action={handleSubmit} className="flex flex-col gap-2">
      <input type="hidden" name="orgId" value={orgId} />

      <label className="text-[#94A3B8] text-xs font-medium">Intervenir como admin</label>
      <textarea
        name="content"
        rows={3}
        placeholder="Escribí un mensaje como si fuera la IA..."
        maxLength={2000}
        className="w-full px-3 py-2 rounded-lg bg-[#0F172A] border border-[#1E293B] text-white text-sm placeholder-[#475569] resize-none focus:outline-none focus:border-[#3B82F6] transition-colors"
        required
        disabled={isPending}
      />

      {error && (
        <p className="text-[#F87171] text-xs">{error}</p>
      )}
      {success && (
        <p className="text-[#34D399] text-xs">Mensaje enviado correctamente.</p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="self-end px-4 py-2 rounded-lg bg-[#3B82F6] text-white text-sm font-medium hover:bg-[#2563EB] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {isPending ? 'Enviando...' : 'Enviar mensaje'}
      </button>
    </form>
  )
}
