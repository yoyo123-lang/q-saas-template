/**
 * Utilidades compartidas para generación de imágenes con Gemini.
 * Usadas por brand-generator.ts (logos) y ad-visual-generator.ts (Meta Ads).
 *
 * Extraído de brand-generator.ts para evitar duplicación — ver ADR-0024.
 */

import { createServiceClient } from '@qautiva/db'

// ── Constantes ────────────────────────────────────────────────────────────────

/** Límite de tamaño de imagen aceptable para upload a Storage y envío a Gemini. */
export const MAX_IMAGE_BYTES = 2 * 1024 * 1024 // 2 MB

/**
 * Tamaño máximo en píxeles (lado mayor) para redimensionar imágenes antes de
 * enviarlas como inlineData a Gemini. Reduce el payload sin perder calidad visual.
 */
const MAX_RESIZE_DIMENSION = 512

// ── Cache de buckets verificados ──────────────────────────────────────────────

/**
 * Map de nombre de bucket → ya verificado que existe.
 * Evita round-trips repetidos a Supabase Storage en cada generación.
 * Key: nombre del bucket. Value: true si ya se verificó/creó.
 *
 * Uso de Map (no boolean) para soportar múltiples buckets concurrentemente
 * (brand-logos + ad-visuals) sin que un ensure tape al otro.
 */
const _bucketsEnsured = new Map<string, boolean>()

/**
 * @internal Solo para tests — resetea el cache de buckets verificados.
 */
export function _resetBucketCacheForTesting(): void {
  _bucketsEnsured.clear()
}

// ── Validación de imágenes ────────────────────────────────────────────────────

/**
 * Valida magic bytes de PNG o JPEG y tamaño de la imagen.
 * PNG: magic bytes 89 50 4E 47. JPEG: magic bytes FF D8 FF.
 *
 * @param buffer - Buffer con los bytes de la imagen
 * @param context - Identificador para logs de error (ej: "brand-logos/option-a")
 * @throws Error si el contenido no es PNG/JPEG válido o excede MAX_IMAGE_BYTES
 */
export function validateImageBytes(buffer: Buffer, context: string): void {
  if (buffer.length === 0) {
    throw new Error(`[image-utils][${context}] Imagen vacía (0 bytes)`)
  }
  if (buffer.length > MAX_IMAGE_BYTES) {
    throw new Error(
      `[image-utils][${context}] Imagen demasiado grande: ${buffer.length} bytes (máx: ${MAX_IMAGE_BYTES})`,
    )
  }
  const isPng =
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  const isJpeg = buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff
  if (!isPng && !isJpeg) {
    throw new Error(`[image-utils][${context}] Magic bytes inválidos — no es PNG ni JPEG`)
  }
}

// ── Redimensionado de imágenes ────────────────────────────────────────────────

/**
 * Redimensiona una imagen a MAX_RESIZE_DIMENSION px en el lado mayor, manteniendo
 * el aspect ratio. Si la imagen ya es más chica, la devuelve sin modificar.
 *
 * Usado para comprimir logos antes de enviarlos como inlineData base64 a Gemini,
 * reduciendo el payload de ~2MB a ~50-100KB sin perder información visual relevante.
 *
 * Implementación: usa solo Node.js built-ins (no sharp, no jimp) para no agregar
 * dependencias. Trabaja con los bytes del PNG/JPEG directamente.
 *
 * NOTA: Esta función hace downscale "inteligente" solo para logos simples.
 * No reemplaza un resize de calidad para imágenes fotográficas.
 *
 * @param buffer - Buffer PNG o JPEG original
 * @param context - Identificador para logs
 * @returns Buffer redimensionado (o el original si no hace falta)
 */
export async function resizeImageForPayload(buffer: Buffer, context: string): Promise<Buffer> {
  // Si ya es suficientemente chica, no tocar
  if (buffer.length <= MAX_IMAGE_BYTES / 4) {
    return buffer
  }

  // Intentar leer dimensiones del PNG (chunk IHDR)
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  ) {
    const width = buffer.readUInt32BE(16)
    const height = buffer.readUInt32BE(20)

    if (width <= MAX_RESIZE_DIMENSION && height <= MAX_RESIZE_DIMENSION) {
      return buffer
    }

    // Si sharp está disponible en el proyecto, usarlo; si no, devolver original con warning
    try {
      // eslint-disable-next-line
      const sharp = await (async () => { try { return require('sharp') } catch { return null } })()
      if (sharp) {
        const resized = await sharp(buffer)
          .resize(MAX_RESIZE_DIMENSION, MAX_RESIZE_DIMENSION, { fit: 'inside', withoutEnlargement: true })
          .png({ compressionLevel: 6 })
          .toBuffer()
        console.log(`[image-utils][${context}] resized ${buffer.length}B → ${resized.length}B (${width}x${height} → max ${MAX_RESIZE_DIMENSION}px)`)
        return resized
      }
    } catch {
      // sharp no disponible — continuar con original
    }

    console.warn(`[image-utils][${context}] imagen grande (${buffer.length}B, ${width}x${height}px) — sharp no disponible, enviando original`)
    return buffer
  }

  // JPEG: no podemos leer dimensiones fácilmente sin librería; devolver original
  if (buffer.length > MAX_IMAGE_BYTES) {
    console.warn(`[image-utils][${context}] JPEG grande (${buffer.length}B) — no se puede redimensionar sin sharp`)
  }
  return buffer
}

// ── Gestión de buckets ────────────────────────────────────────────────────────

/**
 * Garantiza que el bucket dado existe en Supabase Storage.
 * Usa cache por nombre de bucket para evitar llamadas repetidas a listBuckets().
 * Idempotente: si dos requests concurrentes intentan crear el bucket simultáneamente,
 * el error "already exists" se ignora.
 *
 * @param bucketName - Nombre del bucket a verificar/crear
 * @param isPublic - Si el bucket debe ser público (default: false — privado)
 * @throws Error si no se puede listar buckets o si falla la creación (salvo "already exists")
 */
export async function ensureBucket(bucketName: string, isPublic = false): Promise<void> {
  if (_bucketsEnsured.get(bucketName)) return

  const supabase = createServiceClient()
  const { data: buckets, error } = await supabase.storage.listBuckets()
  if (error) {
    throw new Error(`[image-utils][${bucketName}] Error listando buckets: ${error.message}`)
  }

  const exists = buckets?.some((b) => b.name === bucketName)
  if (!exists) {
    const { error: createError } = await supabase.storage.createBucket(bucketName, {
      public: isPublic,
      allowedMimeTypes: ['image/png', 'image/jpeg'],
    })
    if (createError && !createError.message.toLowerCase().includes('already exists')) {
      throw new Error(`[image-utils][${bucketName}] Error creando bucket: ${createError.message}`)
    }
    if (!createError) {
      console.log(`[image-utils] bucket '${bucketName}' creado (public: ${isPublic})`)
    }
  }

  _bucketsEnsured.set(bucketName, true)
}

// ── Upload a Storage ──────────────────────────────────────────────────────────

/**
 * Sube una imagen a un bucket de Supabase Storage y devuelve la URL de acceso.
 *
 * Para buckets públicos: devuelve URL pública directa.
 * Para buckets privados: devuelve signed URL con TTL de 24h.
 *
 * @param buffer - Buffer PNG o JPEG a subir
 * @param bucketName - Nombre del bucket destino
 * @param filePath - Path dentro del bucket, ej: "{projectId}/{fileName}.png"
 * @param isPublic - Si el bucket es público (afecta el tipo de URL devuelta)
 * @returns URL de acceso a la imagen
 * @throws Error si el upload o la generación de URL falla
 */
export async function uploadImageToStorage(
  buffer: Buffer,
  bucketName: string,
  filePath: string,
  isPublic = false,
): Promise<string> {
  const supabase = createServiceClient()

  console.log(`[image-utils][${bucketName}] upload started`, { filePath, sizeBytes: buffer.length })

  const contentType = buffer[0] === 0xff && buffer[1] === 0xd8 ? 'image/jpeg' : 'image/png'
  const { error } = await supabase.storage.from(bucketName).upload(filePath, buffer, {
    contentType,
    upsert: true,
  })

  if (error) {
    throw new Error(`[image-utils][${bucketName}] Upload fallido para '${filePath}': ${error.message}`)
  }

  let url: string

  if (isPublic) {
    const { data } = supabase.storage.from(bucketName).getPublicUrl(filePath)
    url = data.publicUrl
  } else {
    // Signed URL válida por 1 año — las piezas son deliverables persistentes
    const { data, error: signError } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(filePath, 60 * 60 * 24 * 365)
    if (signError || !data?.signedUrl) {
      throw new Error(
        `[image-utils][${bucketName}] Error generando signed URL para '${filePath}': ${signError?.message ?? 'sin URL'}`,
      )
    }
    url = data.signedUrl
  }

  console.log(`[image-utils][${bucketName}] upload completed`, { filePath, sizeBytes: buffer.length })
  return url
}
