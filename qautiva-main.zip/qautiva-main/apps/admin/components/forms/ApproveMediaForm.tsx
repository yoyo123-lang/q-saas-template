'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { approveMedia } from '@/lib/actions'

interface ApproveMediaFormProps {
  mediumId: string
  mediumName: string
}

export function ApproveMediaForm({ mediumId, mediumName }: ApproveMediaFormProps) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  function handleSubmit(formData: FormData) {
    if (!window.confirm(`¿Confirmás la aprobación de "${mediumName}"? Quedará visible en el catálogo.`)) {
      return
    }
    setError(null)
    startTransition(async () => {
      try {
        await approveMedia(formData)
        setSuccess(true)
        setTimeout(() => router.push('/medios'), 800)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error al aprobar el medio')
      }
    })
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-2">
      <input type="hidden" name="mediumId" value={mediumId} />
      <button
        type="submit"
        disabled={isPending || success}
        className="px-5 py-2.5 rounded-lg bg-[#10B981] text-white text-sm font-semibold hover:bg-[#059669] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {success ? '✓ Aprobado' : isPending ? 'Aprobando...' : '✓ Aprobar medio'}
      </button>
      {error && <p className="text-[#F87171] text-xs">{error}</p>}
    </form>
  )
}
