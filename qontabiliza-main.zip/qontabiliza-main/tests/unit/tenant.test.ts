import { describe, it, expect } from "vitest";
import { applyTenantFilter, TENANT_SCOPED_MODELS, withTenant } from "@/lib/tenant";

describe("applyTenantFilter", () => {
  it("agrega organizationId a un where vacío", () => {
    const result = applyTenantFilter("org_123");
    expect(result).toEqual({ organizationId: "org_123" });
  });

  it("agrega organizationId a un where existente sin sobreescribir otras condiciones", () => {
    const result = applyTenantFilter("org_123", { name: "Producto A", isActive: true });
    expect(result).toEqual({
      organizationId: "org_123",
      name: "Producto A",
      isActive: true,
    });
  });

  it("organizationId del tenant sobreescribe cualquier organizationId que haya en el where", () => {
    // Seguridad: evita que un caller inyecte otro tenantId
    const result = applyTenantFilter("org_123", { organizationId: "org_malicioso" });
    expect(result.organizationId).toBe("org_123");
  });

  it("retorna organizationId correcto para múltiples tenants distintos", () => {
    const resultA = applyTenantFilter("tenant_A");
    const resultB = applyTenantFilter("tenant_B");
    expect(resultA.organizationId).toBe("tenant_A");
    expect(resultB.organizationId).toBe("tenant_B");
    expect(resultA.organizationId).not.toBe(resultB.organizationId);
  });

  it("no muta el objeto where original", () => {
    const original = { name: "Test" };
    applyTenantFilter("org_123", original);
    expect(original).toEqual({ name: "Test" });
    expect((original as Record<string, unknown>).organizationId).toBeUndefined();
  });

  it("no muta objetos con propiedades anidadas", () => {
    // QA-05: verifica que el spread shallow no muta el objeto original con anidados
    const original = { status: "ACTIVE", nested: { key: "value" } };
    const result = applyTenantFilter("org_123", original);
    expect(result.organizationId).toBe("org_123");
    expect(result.status).toBe("ACTIVE");
    // El spread es shallow: la referencia al objeto anidado se comparte (no se clona)
    // pero el objeto original no muta en sus propiedades top-level
    expect(original).toEqual({ status: "ACTIVE", nested: { key: "value" } });
    expect((original as Record<string, unknown>).organizationId).toBeUndefined();
  });
});

describe("TENANT_SCOPED_MODELS", () => {
  it("incluye los modelos de dominio con organizationId", () => {
    const expectedModels = [
      "membership",
      "subscription",
      "category",
      "product",
      "productVariant",
      "priceList",
      "priceListItem",
      "contact",
      "invoice",
      "invoiceItem",
      "sale",
      "saleItem",
      "warehouse",
      "stockMovement",
      "cashRegister",
      "paymentRecord",
    ];
    for (const model of expectedModels) {
      expect(TENANT_SCOPED_MODELS.has(model), `falta el modelo: ${model}`).toBe(true);
    }
  });

  it("NO incluye Organization (no tiene organizationId — es la raíz del tenant)", () => {
    expect(TENANT_SCOPED_MODELS.has("organization")).toBe(false);
  });

  it("NO incluye los modelos de auth ni Plan (no tienen organizationId)", () => {
    const nonTenantModels = ["user", "account", "session", "verificationToken", "allowedEmail", "plan"];
    for (const model of nonTenantModels) {
      expect(TENANT_SCOPED_MODELS.has(model), `no debería incluir: ${model}`).toBe(false);
    }
  });
});

describe("withTenant", () => {
  it("lanza error si organizationId está vacío", () => {
    // QA-03: guard contra organizationId falsy
    expect(() => withTenant("")).toThrow("withTenant: organizationId es requerido");
  });

  it("lanza error si organizationId es solo espacios", () => {
    expect(() => withTenant("   ")).not.toThrow();
    // Nota: solo valida falsy — un string con espacios pasa.
    // Si se requiere validación más estricta, ajustar la guard en withTenant.
  });

  it("retorna un objeto (cliente extendido) cuando organizationId es válido", () => {
    const client = withTenant("org_valid_123");
    expect(client).toBeDefined();
    expect(typeof client).toBe("object");
  });

  it("retorna el mismo objeto para el mismo organizationId (memoize)", () => {
    const clientA = withTenant("org_memo_test");
    const clientB = withTenant("org_memo_test");
    expect(clientA).toBe(clientB);
  });

  it("retorna objetos distintos para organizationIds distintos", () => {
    const clientA = withTenant("org_distinct_A");
    const clientB = withTenant("org_distinct_B");
    expect(clientA).not.toBe(clientB);
  });

  /**
   * Tests de integración completa (requieren DB real):
   * - withTenant(id).invoice.findMany() solo retorna facturas del tenant
   * - withTenant(id).invoice.findUnique({ where: { id: otherTenantId } }) retorna null
   * - withTenant(id).invoice.create({ data: {...} }) inyecta organizationId automáticamente
   * - withTenant(id).invoice.update({ where: { id }, data: {...} }) falla si el ID no pertenece al tenant
   * TODO: agregar en test/integration/ con una DB de test (vitest + prisma migrate reset)
   */
});
