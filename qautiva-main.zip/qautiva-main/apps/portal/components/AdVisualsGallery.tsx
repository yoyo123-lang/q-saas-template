'use client'

/**
 * Galería reutilizable de piezas visuales para Meta Ads.
 *
 * Grid responsive: 3 columnas desktop, 2 tablet, 1 mobile.
 * Aspect ratio real por formato: 1:1, 4:5, 9:16.
 * Cada pieza tiene badge de formato/ángulo, descarga individual y lazy loading.
 *
 * Usable tanto en /creativos como en el router de entregables.
 */

import { useState } from 'react'
import Image from 'next/image'
import type { AdVisual } from '@/app/_lib/interview/types'

// ── Helpers ───────────────────────────────────────────────────────────────────

const FORMAT_LABELS: Record<string, string> = {
  feed_square: 'Feed 1:1',
  feed_portrait: 'Feed 4:5',
  story: 'Story 9:16',
}

const ANGLE_LABELS: Record<string, string> = {
  'hero shot': 'Hero shot',
  lifestyle: 'Lifestyle',
}

/** Relación aspect ratio → clase de padding-top para el contenedor. */
const ASPECT_RATIO_PADDING: Record<string, string> = {
  '1:1': 'pb-[100%]',
  '4:5': 'pb-[125%]',
  '9:16': 'pb-[177.78%]',
}

// ── Componente pieza individual ───────────────────────────────────────────────

function VisualCard({ visual }: { visual: AdVisual }) {
  const [imgError, setImgError] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)

  const paddingClass = ASPECT_RATIO_PADDING[visual.aspectRatio] ?? 'pb-[100%]'
  const formatLabel = FORMAT_LABELS[visual.format] ?? visual.format
  const angleLabel = ANGLE_LABELS[visual.angle] ?? visual.angle
  const altText = `${formatLabel} — ${angleLabel}`

  const handleDownload = async () => {
    if (isDownloading) return
    setIsDownloading(true)

    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 30_000)

    try {
      const res = await fetch(visual.imageUrl, { signal: controller.signal })
      clearTimeout(timeout)
      if (!res.ok) throw new Error('fetch failed')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `meta-ad-${visual.format}-${visual.angle.replace(' ', '-')}.png`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      clearTimeout(timeout)
      // Fallback: abrir en nueva pestaña si la descarga falla o hay timeout
      window.open(visual.imageUrl, '_blank', 'noopener,noreferrer')
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <article
      className="bg-[#0F172A] border border-[#1E293B] rounded-xl overflow-hidden group"
      aria-label={altText}
    >
      {/* Contenedor con aspect ratio real */}
      <div className={`relative w-full ${paddingClass}`}>
        {imgError ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0B0F1A] text-[#64748B] gap-2">
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              aria-hidden="true"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <path d="m8 16 2.5-3.5L13 15l2-2.5 4 4.5" />
              <circle cx="8.5" cy="8.5" r="1.5" />
            </svg>
            <span className="text-xs text-center px-2">
              Imagen no disponible
            </span>
          </div>
        ) : (
          <Image
            src={visual.imageUrl}
            alt={altText}
            fill
            loading="lazy"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-cover"
            onError={() => setImgError(true)}
          />
        )}

        {/* Badges de formato y ángulo */}
        <div className="absolute top-2 left-2 flex gap-1.5">
          <span className="px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm text-white text-xs font-medium">
            {formatLabel}
          </span>
          <span className="px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm text-[#A78BFA] text-xs">
            {angleLabel}
          </span>
        </div>
      </div>

      {/* Footer con resolución y descarga */}
      <div className="px-3 py-2.5 flex items-center justify-between">
        <span className="text-[#64748B] text-xs">{visual.resolution}</span>
        <button
          type="button"
          onClick={handleDownload}
          disabled={isDownloading}
          aria-label={isDownloading ? 'Descargando…' : `Descargar ${altText}`}
          className="
            min-h-[44px] min-w-[44px] flex items-center justify-center
            text-[#64748B] hover:text-[#A78BFA] transition-colors duration-200
            rounded-lg hover:bg-[#8B5CF6]/10
            disabled:opacity-50 disabled:cursor-wait
          "
        >
          {isDownloading ? (
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
              className="animate-spin"
            >
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
          ) : (
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
          )}
        </button>
      </div>
    </article>
  )
}

// ── Componente galería ────────────────────────────────────────────────────────

type Props = {
  visuals: AdVisual[]
}

/**
 * Galería de piezas visuales para Meta Ads.
 * Grid responsive: 3 columnas desktop, 2 tablet, 1 mobile.
 */
export function AdVisualsGallery({ visuals }: Props) {
  if (visuals.length === 0) {
    return (
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
        <p className="text-[#64748B] text-sm">No hay piezas generadas.</p>
      </div>
    )
  }

  return (
    <div
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
      role="list"
      aria-label="Piezas publicitarias generadas"
    >
      {visuals.map((visual, i) => (
        <div key={`${visual.format}-${visual.angle}-${i}`} role="listitem">
          <VisualCard visual={visual} />
        </div>
      ))}
    </div>
  )
}
