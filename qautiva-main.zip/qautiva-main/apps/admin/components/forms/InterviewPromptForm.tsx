'use client'

import { useTransition, useState, useRef, useEffect } from 'react'
import { updateInterviewPrompt } from '@/lib/actions'

interface InterviewPromptFormProps {
  agentNumber: number
  interviewPrompt: string | null
}

/**
 * Formulario para editar el interview prompt base de un agente.
 * Usa Server Action `updateInterviewPrompt` via useTransition.
 * El campo puede estar vacío — en ese caso se persiste null.
 */
export function InterviewPromptForm({
  agentNumber,
  interviewPrompt: initialPrompt,
}: InterviewPromptFormProps) {
  const [isPending, startTransition] = useTransition()
  const [prompt, setPrompt] = useState(initialPrompt ?? '')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()

    if (prompt.length > 15000) {
      setError('El interview prompt no puede superar los 15000 caracteres.')
      return
    }

    setError(null)
    setSuccess(false)

    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      try {
        await updateInterviewPrompt(formData)
        setSuccess(true)
        if (timerRef.current) clearTimeout(timerRef.current)
        timerRef.current = setTimeout(() => setSuccess(false), 5000)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error desconocido')
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <input type="hidden" name="agentNumber" value={agentNumber} />

      <div className="flex flex-col gap-2">
        <label
          htmlFor={`interviewPrompt-${agentNumber}`}
          className="text-[#94A3B8] text-sm font-medium"
        >
          Interview prompt base
        </label>
        <textarea
          id={`interviewPrompt-${agentNumber}`}
          name="interviewPrompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={12}
          maxLength={15000}
          placeholder="Preguntas base de la entrevista para este agente..."
          className="w-full resize-y bg-[#1E293B] text-[#F8FAFC] font-mono text-sm rounded-lg border border-[#334155] focus:border-[#8B5CF6] focus:outline-none p-4 leading-relaxed placeholder:text-[#64748B]"
        />
        <p className="text-[#64748B] text-xs text-right">{prompt.length} / 15000</p>
        <p className="text-[#64748B] text-xs">
          Este prompt define las preguntas BASE de la entrevista, comunes a todas las industrias.
          Las preguntas específicas de cada rubro se configuran en /industrias.
        </p>
      </div>

      {error && (
        <p className="text-[#F87171] text-sm bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-lg px-4 py-2">
          {error}
        </p>
      )}
      {success && (
        <p className="text-[#34D399] text-sm bg-[#10B981]/10 border border-[#10B981]/30 rounded-lg px-4 py-2">
          ✓ Interview prompt guardado correctamente
        </p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="self-start px-5 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isPending ? 'Guardando…' : 'Guardar interview prompt'}
      </button>
    </form>
  )
}
