/**
 * Board Client — comunicación con el Q Company Board central.
 *
 * BU → Board: métricas, eventos, heartbeat (x-api-key)
 * Board → BU:  directivas (verificadas con HMAC-SHA256)
 */

function getBoardConfig() {
  const url = process.env.BOARD_URL
  const apiKey = process.env.BOARD_API_KEY
  const buId = process.env.BOARD_BU_ID

  if (!url || !apiKey || !buId) {
    throw new Error(
      '[board-client] Variables de entorno requeridas no configuradas: ' +
        'BOARD_URL, BOARD_API_KEY, BOARD_BU_ID. ' +
        'Copiá .env.example a .env.local y completá los valores.'
    )
  }

  return { url, apiKey, buId }
}

async function boardFetch(path: string, options: RequestInit = {}) {
  const { url, apiKey, buId } = getBoardConfig()
  const fullUrl = `${url}/api/v1/bu/${buId}${path}`

  const response = await fetch(fullUrl, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      ...options.headers,
    },
  })

  if (!response.ok) {
    const body = await response.text()
    throw new Error(`[board-client] API error ${response.status} en ${path}: ${body}`)
  }

  return response.json()
}

/** Enviar heartbeat — llamar cada 5 minutos */
export async function sendHeartbeat(checks: Record<string, string>) {
  return boardFetch('/heartbeat', {
    method: 'POST',
    body: JSON.stringify({
      version: process.env.npm_package_version ?? '0.0.1',
      uptime_seconds: Math.floor(process.uptime()),
      checks,
    }),
  })
}

/** Enviar métricas — máximo 100 por request */
export async function sendMetrics(
  metrics: Array<{ key: string; value: number; period: string; metadata?: Record<string, unknown> }>
) {
  return boardFetch('/metrics', {
    method: 'POST',
    body: JSON.stringify({ metrics }),
  })
}

/** Enviar eventos — máximo 100 por request, occurred_at en UTC ISO 8601 */
export async function sendEvents(
  events: Array<{ type: string; payload: Record<string, unknown>; occurred_at: string }>
) {
  return boardFetch('/events', {
    method: 'POST',
    body: JSON.stringify({ events }),
  })
}

/** Actualizar estado de una directiva recibida */
export async function updateDirectiveStatus(
  directiveId: string,
  status: 'in_progress' | 'completed' | 'failed' | 'rejected',
  notes?: string,
  result?: Record<string, unknown>
) {
  return boardFetch(`/directives/${directiveId}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status, notes, result }),
  })
}
