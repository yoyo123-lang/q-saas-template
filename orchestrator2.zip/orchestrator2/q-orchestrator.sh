#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════
# q-orchestrator — Orquestador agnóstico de sesiones Claude Code
# ══════════════════════════════════════════════════════════════
#
# Cross-platform (Linux, macOS, WSL, Git Bash on Windows).
# No hardcoded projects — register any repo, pick your workflow.
#
# Usage:
#   ./q-orchestrator.sh                    # Interactive menu
#   ./q-orchestrator.sh --project <slug>   # Skip project selection
#   ./q-orchestrator.sh --project <slug> --mode continue  # Auto-continue
#
set -euo pipefail

# ── Resolve script location ──
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Load libraries ──
source "${SCRIPT_DIR}/lib/ui.sh"
source "${SCRIPT_DIR}/lib/projects.sh"
source "${SCRIPT_DIR}/lib/config.sh"
source "${SCRIPT_DIR}/lib/sessions.sh"
source "${SCRIPT_DIR}/lib/telemetry.sh"
source "${SCRIPT_DIR}/lib/runner.sh"
source "${SCRIPT_DIR}/lib/issues-board-api.sh"
source "${SCRIPT_DIR}/lib/issues-fetch.sh"
source "${SCRIPT_DIR}/lib/issues-queue.sh"
source "${SCRIPT_DIR}/lib/issues-report.sh"
source "${SCRIPT_DIR}/lib/issues-runner.sh"

# ── Help ──
show_help() {
  echo "q-orchestrator — Orquestador agnóstico de sesiones Claude Code"
  echo ""
  echo "Usage:"
  echo "  ./q-orchestrator.sh                          Interactive menu"
  echo "  ./q-orchestrator.sh --project <slug>         Skip project selection"
  echo "  ./q-orchestrator.sh --project <slug> --mode continue"
  echo "  ./q-orchestrator.sh --model claude-opus-4-6"
  echo ""
  echo "Modes: continue, roadmap, cambio-grande, cambio, sesion, issues"
  echo ""
  echo "Config: ~/.q-orchestrator/projects.json"
}

# ── Parse CLI args ──
ARG_PROJECT=""
ARG_MODE=""
ARG_MODEL=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) ARG_PROJECT="$2"; shift 2 ;;
    --mode)    ARG_MODE="$2"; shift 2 ;;
    --model)   ARG_MODEL="$2"; shift 2 ;;
    --help|-h) show_help; exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ── Check dependencies ──
check_deps() {
  local ok=true

  if ! command -v claude &>/dev/null; then
    ui_error "Claude CLI no encontrado. Instalá con: npm install -g @anthropic-ai/claude-code"
    ok=false
  fi

  if ! command -v git &>/dev/null; then
    ui_error "Git no encontrado."
    ok=false
  fi

  # On Windows, "python3" may be a Store alias that opens the Store instead of running.
  # Check node first (more likely on Windows), then python3 with a real execution test.
  local has_json_tool=false
  if command -v node &>/dev/null; then
    has_json_tool=true
  elif command -v python3 &>/dev/null && python3 -c "print('ok')" &>/dev/null; then
    has_json_tool=true
  elif command -v python &>/dev/null && python -c "print('ok')" &>/dev/null; then
    has_json_tool=true
  fi

  if [ "$has_json_tool" = false ]; then
    ui_error "Se necesita node o python3 para gestionar estado."
    ok=false
  fi

  if [ "$ok" = false ]; then
    echo ""
    ui_error "Hay dependencias faltantes. Resolvelas antes de continuar."
    exit 1
  fi
}

# ── Diagnostic ──
run_diagnostic() {
  ui_header
  ui_section "DIAGNÓSTICO DEL ENTORNO"
  ui_empty

  if command -v claude &>/dev/null; then
    ui_item "[OK]" "Claude CLI: $(claude --version 2>/dev/null || echo 'instalado')"
  else
    ui_item "[X]" "Claude CLI no encontrado"
  fi

  if command -v git &>/dev/null; then
    ui_item "[OK]" "$(git --version)"
  else
    ui_item "[X]" "Git no encontrado"
  fi

  if command -v node &>/dev/null; then
    ui_item "[OK]" "Node.js $(node --version)"
  else
    ui_item "[!!]" "Node.js no encontrado"
  fi

  # Test python3 with actual execution to avoid Windows Store alias
  local py_version
  if py_version=$(python3 --version 2>/dev/null) && [[ "$py_version" == *"Python"* ]]; then
    ui_item "[OK]" "$py_version"
  elif py_version=$(python --version 2>/dev/null) && [[ "$py_version" == *"Python"* ]]; then
    ui_item "[OK]" "$py_version"
  else
    ui_item "[--]" "Python no instalado (opcional si tenés Node)"
  fi

  local count
  count=$(project_count)
  ui_item "[OK]" "Proyectos registrados: ${count}"

  ui_empty
  ui_section_end

  # Show registered projects
  if [ "$count" -gt 0 ]; then
    ui_section "PROYECTOS REGISTRADOS"
    ui_empty
    while IFS='|' read -r idx slug path repo branch branch_strategy; do
      local caps
      caps=$(detect_capabilities "$path")
      ui_item "${idx}." "${slug} → ${path}"
      ui_item "  " "caps: ${caps:-ninguna}"
    done < <(list_projects)
    ui_empty
    ui_section_end
  fi

  echo ""
  read -rp "  Presioná Enter para volver..."
}

# ══════════════════════════════════════════════════════════════
# PROJECT MANAGEMENT
# ══════════════════════════════════════════════════════════════

manage_projects() {
  while true; do
    ui_header

    # Show GitHub option only if gh CLI is available
    if command -v gh &>/dev/null; then
      ui_menu "GESTIÓN DE PROYECTOS" \
        "Clonar desde GitHub" \
        "Registrar proyecto local" \
        "Ver proyectos registrados" \
        "Eliminar proyecto" \
        "Volver al menú principal"

      case "$MENU_CHOICE" in
        1) clone_from_github ;;
        2) register_project ;;
        3) show_projects ;;
        4) remove_project_menu ;;
        5) return ;;
      esac
    else
      ui_menu "GESTIÓN DE PROYECTOS" \
        "Registrar proyecto local" \
        "Ver proyectos registrados" \
        "Eliminar proyecto" \
        "Instalar GitHub CLI (instrucciones)" \
        "Volver al menú principal"

      case "$MENU_CHOICE" in
        1) register_project ;;
        2) show_projects ;;
        3) remove_project_menu ;;
        4) show_gh_install_help ;;
        5) return ;;
      esac
    fi
  done
}

# ── Clone from GitHub ──
clone_from_github() {
  echo ""

  # Check gh auth
  if ! gh auth status &>/dev/null 2>&1; then
    ui_error "No estás logueado en GitHub CLI."
    ui_info "Ejecutá: gh auth login"
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  ui_info "Buscando tus repositorios en GitHub..."
  echo ""

  # Fetch repos (owned by user, sorted by last push)
  local repos_raw
  repos_raw=$(gh repo list --limit 30 --json nameWithOwner,description,updatedAt --jq '.[] | .nameWithOwner + "|" + (.description // "sin descripción")' 2>/dev/null)

  if [ -z "$repos_raw" ]; then
    ui_error "No se pudieron obtener los repositorios."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  # Build menu
  local repo_names=()
  local repo_options=()
  local i=1

  while IFS='|' read -r name desc; do
    repo_names+=("$name")
    # Truncate description for display
    local short_desc="${desc:0:40}"
    repo_options+=("${name} — ${short_desc}")
    i=$((i + 1))
  done <<< "$repos_raw"

  if [ ${#repo_names[@]} -eq 0 ]; then
    ui_warn "No se encontraron repositorios."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  # Add search option at the end
  repo_options+=("Buscar otro repo por nombre")

  ui_menu "SELECCIONAR REPOSITORIO" "${repo_options[@]}"

  local selected_repo=""

  if [ "$MENU_CHOICE" -le "${#repo_names[@]}" ]; then
    selected_repo="${repo_names[$((MENU_CHOICE - 1))]}"
  else
    # Search by name
    echo ""
    ui_prompt "Nombre del repo (usuario/repo):"
    read -r selected_repo
    if [ -z "$selected_repo" ]; then return; fi

    # Verify it exists
    if ! gh repo view "$selected_repo" &>/dev/null 2>&1; then
      ui_error "Repo '${selected_repo}' no encontrado."
      echo ""
      read -rp "  Presioná Enter para volver..."
      return
    fi
  fi

  echo ""
  ui_info "Repo seleccionado: ${selected_repo}"

  # Ask where to clone
  local default_dir="$HOME/projects"
  ui_prompt "Carpeta destino (Enter para ${default_dir}):"
  read -r clone_dir
  [ -z "$clone_dir" ] && clone_dir="$default_dir"
  clone_dir="${clone_dir/#\~/$HOME}"

  # Create dir if needed
  mkdir -p "$clone_dir"

  # Extract repo name for the folder
  local repo_short="${selected_repo##*/}"
  local clone_path="${clone_dir}/${repo_short}"

  if [ -d "$clone_path" ]; then
    ui_warn "La carpeta ya existe: ${clone_path}"
    if ui_confirm "¿Usar la carpeta existente?"; then
      # Just register, don't clone
      :
    else
      echo ""
      read -rp "  Presioná Enter para volver..."
      return
    fi
  else
    echo ""
    ui_info "Clonando ${selected_repo}..."
    if ! gh repo clone "$selected_repo" "$clone_path" 2>&1; then
      ui_error "Error al clonar."
      echo ""
      read -rp "  Presioná Enter para volver..."
      return
    fi
    ui_ok "Clonado en: ${clone_path}"
  fi

  # Auto-register
  local slug="$repo_short"
  echo ""
  ui_prompt "Slug del proyecto (Enter para '${slug}'):"
  read -r custom_slug
  [ -n "$custom_slug" ] && slug="$custom_slug"

  # Detect default branch
  local branch
  branch=$(cd "$clone_path" && git symbolic-ref --short HEAD 2>/dev/null || echo "main")

  local result
  result=$(add_project "$slug" "$clone_path" "$selected_repo" "$branch")

  if [ "$result" = "OK" ]; then
    ui_ok "Proyecto '${slug}' registrado y listo para usar."
  elif [ "$result" = "DUPLICATE" ]; then
    ui_warn "Ya existe un proyecto con slug '${slug}'."
  fi

  echo ""
  read -rp "  Presioná Enter para continuar..."
}

# ── GitHub CLI install help ──
show_gh_install_help() {
  echo ""
  ui_section "INSTALAR GITHUB CLI"
  ui_empty
  ui_item "" "Windows: winget install GitHub.cli"
  ui_item "" "   o: choco install gh"
  ui_item "" ""
  ui_item "" "macOS:   brew install gh"
  ui_item "" "Linux:   https://github.com/cli/cli"
  ui_item "" ""
  ui_item "" "Después: gh auth login"
  ui_empty
  ui_section_end
  echo ""
  read -rp "  Presioná Enter para volver..."
}

register_project() {
  echo ""
  ui_prompt "Slug del proyecto (nombre corto, sin espacios):"
  read -r slug
  [ -z "$slug" ] && return

  ui_prompt "Ruta absoluta al proyecto:"
  read -r path
  [ -z "$path" ] && return

  # Expand ~ if present
  path="${path/#\~/$HOME}"

  ui_prompt "Repo GitHub (usuario/repo, Enter para omitir):"
  read -r repo

  ui_prompt "Branch principal (Enter para 'main'):"
  read -r branch
  [ -z "$branch" ] && branch="main"

  echo ""
  ui_prompt "Estrategia de branches:"
  echo "    [1] direct         — push directo a ${branch:-main} (proyectos sin producción)"
  echo "    [2] pr             — branch por sesión + Pull Request (proyectos en producción)"
  echo "    [3] roadmap-branch — un branch por roadmap, todas las sesiones ahí"
  read -r strategy_choice
  local branch_strategy="direct"
  [ "$strategy_choice" = "2" ] && branch_strategy="pr"
  [ "$strategy_choice" = "3" ] && branch_strategy="roadmap-branch"

  local result
  result=$(add_project "$slug" "$path" "$repo" "$branch" "$branch_strategy")

  if [ "$result" = "OK" ]; then
    ui_ok "Proyecto '${slug}' registrado."
  elif [ "$result" = "DUPLICATE" ]; then
    ui_warn "Ya existe un proyecto con slug '${slug}'."
  else
    ui_error "Error al registrar proyecto."
  fi

  echo ""
  read -rp "  Presioná Enter para continuar..."
}

show_projects() {
  ui_header
  local count
  count=$(project_count)

  if [ "$count" -eq 0 ]; then
    ui_warn "No hay proyectos registrados."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  ui_section "PROYECTOS REGISTRADOS"
  ui_empty

  while IFS='|' read -r idx slug path repo branch branch_strategy; do
    ui_item "${idx}." "${slug}"
    ui_item "  " "Path: ${path}"
    [ -n "$repo" ] && ui_item "  " "Repo: ${repo}"
    ui_item "  " "Branch: ${branch}"
    ui_item "  " "Strategy: ${branch_strategy:-direct}"

    local caps
    caps=$(detect_capabilities "$path")
    ui_item "  " "Caps: ${caps:-ninguna detectada}"

    if [ -f "${path}/ROADMAP.md" ]; then
      local pending
      pending=$(count_pending_sessions "$path" "$slug")
      local next
      next=$(next_pending_session "$path" "$slug")
      ui_item "  " "Roadmap: ${pending} sesiones pendientes (próxima: ${next})"
    fi

    ui_empty
  done < <(list_projects)

  ui_section_end
  echo ""
  read -rp "  Presioná Enter para volver..."
}

remove_project_menu() {
  local count
  count=$(project_count)

  if [ "$count" -eq 0 ]; then
    ui_warn "No hay proyectos para eliminar."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  echo ""
  show_projects

  ui_prompt "Número del proyecto a eliminar (0 para cancelar):"
  read -r num

  if [ "$num" = "0" ] || [ -z "$num" ]; then
    return
  fi

  local idx=$((num - 1))
  if [ "$idx" -lt 0 ] || [ "$idx" -ge "$count" ]; then
    ui_error "Número inválido."
    read -rp "  Presioná Enter para volver..."
    return
  fi

  local removed
  removed=$(remove_project "$idx")
  ui_ok "Proyecto '${removed}' eliminado del registro."
  echo ""
  read -rp "  Presioná Enter para continuar..."
}

# ══════════════════════════════════════════════════════════════
# PROJECT SELECTION
# ══════════════════════════════════════════════════════════════

# Selected project globals
SELECTED_SLUG=""
SELECTED_PATH=""
SELECTED_REPO=""
SELECTED_BRANCH=""
SELECTED_BRANCH_STRATEGY=""
SELECTED_IDX=""

select_project() {
  if [ -n "$ARG_PROJECT" ]; then
    # Find by slug from CLI arg
    while IFS='|' read -r idx slug path repo branch branch_strategy; do
      if [ "$slug" = "$ARG_PROJECT" ]; then
        SELECTED_IDX=$((idx - 1))
        SELECTED_SLUG="$slug"
        SELECTED_PATH="$path"
        SELECTED_REPO="$repo"
        SELECTED_BRANCH="$branch"
        SELECTED_BRANCH_STRATEGY="$branch_strategy"
        return 0
      fi
    done < <(list_projects)
    ui_error "Proyecto '${ARG_PROJECT}' no encontrado."
    return 1
  fi

  local count
  count=$(project_count)

  if [ "$count" -eq 0 ]; then
    ui_warn "No hay proyectos registrados. Registrá uno primero."
    register_project
    count=$(project_count)
    [ "$count" -eq 0 ] && return 1
  fi

  # Build options array
  local options=()
  local slugs=()
  local paths=()
  local repos=()
  local branches=()
  local branch_strategies=()

  while IFS='|' read -r idx slug path repo branch branch_strategy; do
    local strategy_tag=""
    [ "$branch_strategy" = "pr" ] && strategy_tag=" [PR]"
    [ "$branch_strategy" = "roadmap-branch" ] && strategy_tag=" [ROADMAP]"
    local label="${slug}${strategy_tag} — ${path}"
    if [ -f "${path}/ROADMAP.md" ]; then
      local pending
      pending=$(count_pending_sessions "$path" "$slug")
      label="${label} [${pending} pendientes]"
    fi
    options+=("$label")
    slugs+=("$slug")
    paths+=("$path")
    repos+=("$repo")
    branches+=("$branch")
    branch_strategies+=("$branch_strategy")
  done < <(list_projects)

  ui_menu "SELECCIONAR PROYECTO" "${options[@]}"
  local idx=$((MENU_CHOICE - 1))

  SELECTED_IDX="$idx"
  SELECTED_SLUG="${slugs[$idx]}"
  SELECTED_PATH="${paths[$idx]}"
  SELECTED_REPO="${repos[$idx]}"
  SELECTED_BRANCH="${branches[$idx]}"
  SELECTED_BRANCH_STRATEGY="${branch_strategies[$idx]}"

  return 0
}

# ══════════════════════════════════════════════════════════════
# MODEL SELECTION
# ══════════════════════════════════════════════════════════════

SELECTED_MODEL="$ORCH_MODEL"

select_model() {
  if [ -n "$ARG_MODEL" ]; then
    SELECTED_MODEL="$ARG_MODEL"
    return
  fi

  # Show current default from config
  local default_label="Sonnet"
  [[ "$ORCH_MODEL" == *opus* ]] && default_label="Opus"
  [[ "$ORCH_MODEL" == *haiku* ]] && default_label="Haiku"

  ui_menu "MODELO DE CLAUDE (default: ${default_label})" \
    "Sonnet 4.6 (rápido, ~\$3-5/sesión)" \
    "Opus 4.6 (mejor calidad, ~\$15-25/sesión)" \
    "Haiku 4.5 (económico, tareas simples)" \
    "Usar default de config (${default_label})"

  case "$MENU_CHOICE" in
    1) SELECTED_MODEL="claude-sonnet-4-6" ;;
    2) SELECTED_MODEL="claude-opus-4-6" ;;
    3) SELECTED_MODEL="claude-haiku-4-5-20251001" ;;
    4) SELECTED_MODEL="$ORCH_MODEL" ;;
  esac
}

# ══════════════════════════════════════════════════════════════
# MODE SELECTION & EXECUTION
# ══════════════════════════════════════════════════════════════

select_and_run_mode() {
  local project_path="$SELECTED_PATH"
  local slug="$SELECTED_SLUG"
  local model="$SELECTED_MODEL"

  # ── Load project-specific config overrides ──
  load_project_config "$project_path"

  # ── Override branch strategy from project registration ──
  if [ -n "$SELECTED_BRANCH_STRATEGY" ]; then
    ORCH_BRANCH_STRATEGY="$SELECTED_BRANCH_STRATEGY"
  fi

  # ── Show current strategy and offer to change ──
  local strategy_display="direct (push a ${SELECTED_BRANCH:-main})"
  [ "$ORCH_BRANCH_STRATEGY" = "pr" ] && strategy_display="pr (branch por sesión + Pull Request)"
  [ "$ORCH_BRANCH_STRATEGY" = "roadmap-branch" ] && strategy_display="roadmap-branch (un branch para todo el roadmap)"
  echo ""
  ui_info "Estrategia de branch: ${strategy_display}"

  if [ -z "$ARG_MODE" ]; then
    # Only offer to change in interactive mode
    read -rp "  ¿Cambiar? [s/N]: " change_strategy
    if [[ "$change_strategy" =~ ^[sS]$ ]]; then
      echo "    [1] direct         — push directo a ${SELECTED_BRANCH:-main}"
      echo "    [2] pr             — branch por sesión + Pull Request"
      echo "    [3] roadmap-branch — un branch para todo el roadmap"
      read -r new_strategy_choice
      if [ "$new_strategy_choice" = "1" ]; then
        ORCH_BRANCH_STRATEGY="direct"
        SELECTED_BRANCH_STRATEGY="direct"
      elif [ "$new_strategy_choice" = "2" ]; then
        ORCH_BRANCH_STRATEGY="pr"
        SELECTED_BRANCH_STRATEGY="pr"
      elif [ "$new_strategy_choice" = "3" ]; then
        ORCH_BRANCH_STRATEGY="roadmap-branch"
        SELECTED_BRANCH_STRATEGY="roadmap-branch"
      fi
      # Persist to projects.json
      if [ -n "$SELECTED_IDX" ]; then
        update_project_field "$SELECTED_IDX" "branch_strategy" "$ORCH_BRANCH_STRATEGY"
        ui_ok "Estrategia actualizada a '${ORCH_BRANCH_STRATEGY}' y guardada."
      fi
    fi
  fi

  # ── Override model from config if user didn't pick via CLI ──
  if [ -z "$ARG_MODEL" ] && [ "$model" = "claude-sonnet-4-6" ]; then
    model="$ORCH_MODEL"
  fi

  # ── Auto-pull: sync with remote before detecting capabilities ──
  if [ "$ORCH_AUTO_PULL" = "true" ] && [ -d "${project_path}/.git" ]; then
    ui_info "Sincronizando con remoto..."
    local pull_branch="${ORCH_PULL_BRANCH}"
    if [ -z "$pull_branch" ]; then
      pull_branch=$(cd "$project_path" && git symbolic-ref --short HEAD 2>/dev/null || echo "main")
    fi
    (cd "$project_path" && git pull origin "$pull_branch" --ff-only 2>/dev/null) || true
  fi

  local caps
  caps=$(detect_capabilities "$project_path")

  # Build mode options based on capabilities
  local options=()
  local modes=()

  if [[ "$caps" == *"roadmap"* ]]; then
    local pending
    pending=$(count_pending_sessions "$project_path" "$slug")
    options+=("Continuar roadmap (${pending} sesiones pendientes)")
    modes+=("continue")
  fi

  options+=("Crear roadmap nuevo")
  modes+=("roadmap")

  options+=("Cambio grande (multi-etapa con revisión)")
  modes+=("cambio-grande")

  options+=("Cambio puntual (1 etapa con revisión)")
  modes+=("cambio")

  options+=("Sesión libre (interactiva)")
  modes+=("sesion")

  # Show issues mode only if ORCH_ISSUES_REPOS is configured
  if [ -n "${ORCH_ISSUES_REPOS:-}" ]; then
    options+=("Issues mode (Board directives batch)")
    modes+=("issues")
  fi

  ui_menu "MODO DE TRABAJO — ${slug}" "${options[@]}"
  local selected_mode="${modes[$((MENU_CHOICE - 1))]}"

  # Override with CLI arg if provided
  [ -n "$ARG_MODE" ] && selected_mode="$ARG_MODE"

  case "$selected_mode" in
    continue)  run_mode_continue "$project_path" "$slug" "$model" ;;
    roadmap)   run_mode_roadmap "$project_path" "$slug" "$model" ;;
    cambio-grande) run_mode_cambio_grande "$project_path" "$slug" "$model" ;;
    cambio)    run_mode_cambio "$project_path" "$slug" "$model" ;;
    sesion)    run_mode_sesion "$project_path" "$slug" "$model" ;;
    issues)    run_issues_mode "$project_path" "$slug" "$model" ;;
  esac
}

# ── Mode: Continue roadmap ──
run_mode_continue() {
  local project_path="$1"
  local slug="$2"
  local model="$3"

  ui_header
  ui_section "ROADMAP — ${slug}"
  ui_empty

  # Show all sessions with status
  local sessions=()
  local session_nums=()
  local session_names=()
  local pending_indices=()
  local i=0

  while IFS='|' read -r num name status; do
    local marker="[ ]"
    [ "$status" = "completed" ] && marker="[X]"
    [ "$status" = "in-progress" ] && marker="[>]"
    ui_item "$marker" "S${num} ${name}"
    sessions+=("${num}|${name}|${status}")
    session_nums+=("$num")
    session_names+=("$name")
    if [ "$status" = "pending" ] || [ "$status" = "in-progress" ]; then
      pending_indices+=("$i")
    fi
    i=$((i + 1))
  done < <(parse_roadmap "$project_path" "$slug")

  ui_empty
  ui_section_end

  if [ ${#pending_indices[@]} -eq 0 ]; then
    echo ""
    ui_ok "Todas las sesiones están completadas."
    read -rp "  Presioná Enter para volver..."
    return
  fi

  echo ""
  local next_idx="${pending_indices[0]}"
  local next_num="${session_nums[$next_idx]}"
  local next_name="${session_names[$next_idx]}"

  ui_info "Próxima sesión: S${next_num} — ${next_name}"
  echo ""

  # Branch strategy info
  local strategy_label=""
  if [ "$ORCH_BRANCH_STRATEGY" = "pr" ]; then
    strategy_label=" [branch + PR por sesión]"
  elif [ "$ORCH_BRANCH_STRATEGY" = "roadmap-branch" ]; then
    strategy_label=" [branch roadmap/${slug}]"
  fi

  # If roadmap-branch strategy, ensure we're on the right branch
  if [ "$ORCH_BRANCH_STRATEGY" = "roadmap-branch" ]; then
    local roadmap_branch="roadmap/${slug}"
    local current_branch
    current_branch=$(cd "$project_path" && git symbolic-ref --short HEAD 2>/dev/null || echo "")
    if [ "$current_branch" != "$roadmap_branch" ]; then
      ui_info "Switcheando a branch ${roadmap_branch}..."
      (cd "$project_path" && git checkout "$roadmap_branch" 2>/dev/null || git checkout -b "$roadmap_branch") || true
    fi
  fi

  ui_menu "¿QUÉ HACER?${strategy_label}" \
    "Ejecutar S${next_num} y continuar con las siguientes" \
    "Ejecutar solo S${next_num}" \
    "Elegir sesión específica" \
    "Volver"

  case "$MENU_CHOICE" in
    1)
      # Auto-continue: run all pending sessions sequentially
      echo ""
      ui_info "Modo automático: ${#pending_indices[@]} sesiones pendientes."
      for pidx in "${pending_indices[@]}"; do
        local snum="${session_nums[$pidx]}"
        local sname="${session_names[$pidx]}"
        echo ""
        echo -e "  ${BOLD}══════════════════════════════════════════${RESET}"
        echo -e "  ${BOLD}  SESIÓN ${snum}: ${sname}${RESET}"
        echo -e "  ${BOLD}══════════════════════════════════════════${RESET}"
        echo ""
        run_session_cambio_grande "$project_path" "$snum" "$sname" "$model" "$slug"
      done
      echo ""
      ui_ok "Todas las sesiones pendientes completadas."
      read -rp "  Presioná Enter para continuar..."
      ;;
    2)
      run_session_cambio_grande "$project_path" "$next_num" "$next_name" "$model" "$slug"
      echo ""
      read -rp "  Presioná Enter para continuar..."
      ;;
    3)
      ui_prompt "Número de sesión:"
      read -r chosen_num
      local chosen_name=""
      for j in "${!session_nums[@]}"; do
        if [ "${session_nums[$j]}" = "$chosen_num" ]; then
          chosen_name="${session_names[$j]}"
          break
        fi
      done
      if [ -z "$chosen_name" ]; then
        ui_error "Sesión ${chosen_num} no encontrada en el roadmap."
        read -rp "  Presioná Enter para volver..."
        return
      fi
      run_session_cambio_grande "$project_path" "$chosen_num" "$chosen_name" "$model" "$slug"
      echo ""
      read -rp "  Presioná Enter para continuar..."
      ;;
    4) return ;;
  esac
}

# ── Mode: New roadmap ──
run_mode_roadmap() {
  local project_path="$1"
  local slug="$2"
  local model="$3"

  echo ""
  ui_prompt "Describí el proyecto en 1-2 oraciones:"
  read -r description

  if [ -z "$description" ]; then
    ui_error "Necesito una descripción del proyecto."
    return
  fi

  echo ""
  ui_info "Generando roadmap con Claude..."
  reset_roadmap_progress "$slug"
  run_roadmap "$project_path" "$description" "$model"
  echo ""
  read -rp "  Presioná Enter para continuar..."
}

# ── Mode: Cambio grande ──
run_mode_cambio_grande() {
  local project_path="$1"
  local slug="$2"
  local model="$3"

  echo ""
  ui_prompt "Describí el cambio grande:"
  read -r description

  if [ -z "$description" ]; then
    ui_error "Necesito una descripción del cambio."
    return
  fi

  echo ""
  ui_info "Ejecutando cambio grande con Claude..."
  local prompt="Ejecutá /project:cambio-grande para este cambio: ${description}"
  run_claude "$project_path" "$prompt" "$model" "$DEFAULT_MAX_TURNS"
  echo ""
  read -rp "  Presioná Enter para continuar..."
}

# ── Mode: Cambio puntual ──
run_mode_cambio() {
  local project_path="$1"
  local slug="$2"
  local model="$3"

  echo ""
  ui_prompt "Describí el cambio:"
  read -r description

  if [ -z "$description" ]; then
    ui_error "Necesito una descripción del cambio."
    return
  fi

  echo ""
  ui_info "Ejecutando cambio con Claude..."
  run_cambio "$project_path" "$description" "$model"
  echo ""
  read -rp "  Presioná Enter para continuar..."
}

# ── Mode: Free session ──
run_mode_sesion() {
  local project_path="$1"
  local slug="$2"
  local model="$3"

  run_sesion "$project_path" "$model"
}

# ══════════════════════════════════════════════════════════════
# MAIN MENU
# ══════════════════════════════════════════════════════════════

# ── Configuration management ──
manage_config() {
  while true; do
    ui_header
    show_config

    local global_config="${CONFIG_DIR}/config.sh"

    ui_menu "CONFIGURACIÓN" \
      "Ver configuración actual" \
      "Generar/resetear config global" \
      "Editar config global (abre editor)" \
      "Volver al menú principal"

    case "$MENU_CHOICE" in
      1)
        show_config
        echo ""
        read -rp "  Presioná Enter para volver..."
        ;;
      2)
        local config_path
        config_path=$(generate_default_config)
        ui_ok "Config generada en: ${config_path}"
        ui_info "Editala para personalizar los valores."
        echo ""
        read -rp "  Presioná Enter para volver..."
        ;;
      3)
        if [ ! -f "$global_config" ]; then
          generate_default_config > /dev/null
        fi
        # Try to open in editor
        local editor="${EDITOR:-${VISUAL:-}}"
        if [ -n "$editor" ]; then
          "$editor" "$global_config"
        elif command -v notepad &>/dev/null; then
          notepad "$(_to_native_path "$global_config")" &
          ui_info "Abierto en Notepad. Guardá y cerrá para aplicar."
        elif command -v nano &>/dev/null; then
          nano "$global_config"
        elif command -v vi &>/dev/null; then
          vi "$global_config"
        else
          ui_error "No se encontró editor. Editá manualmente: $global_config"
        fi
        # Reload config after editing
        _config_loaded=false
        load_config
        ui_ok "Configuración recargada."
        echo ""
        read -rp "  Presioná Enter para volver..."
        ;;
      4) return ;;
    esac
  done
}

# ══════════════════════════════════════════════════════════════
# SELF-IMPROVEMENT — Claude analyzes telemetry and improves
# ══════════════════════════════════════════════════════════════

run_self_improve() {
  ui_header
  ui_section "AUTO-MEJORA DEL ORQUESTADOR"
  ui_empty
  ui_item "" "Claude va a analizar la telemetría"
  ui_item "" "y proponer mejoras al orquestador."
  ui_empty
  ui_section_end

  # Check if there's telemetry data
  local telemetry_base="${CONFIG_DIR}/telemetry"
  if [ ! -d "$telemetry_base" ] || [ -z "$(find "$telemetry_base" -name '*.jsonl' 2>/dev/null | head -1)" ]; then
    echo ""
    ui_warn "No hay datos de telemetría todavía."
    ui_info "Ejecutá al menos una sesión para generar datos."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  echo ""
  ui_menu "¿QUÉ TIPO DE ANÁLISIS?" \
    "Analizar y recomendar (solo lectura)" \
    "Analizar y aplicar mejoras automáticamente" \
    "Analizar un proyecto específico" \
    "Volver"

  local analysis_mode="$MENU_CHOICE"
  [ "$analysis_mode" = "4" ] && return

  # Collect all telemetry into a single temp file
  local temp_telemetry
  temp_telemetry=$(mktemp)
  find "$telemetry_base" -name '*.jsonl' -type f | sort | while IFS= read -r f; do
    echo "--- $(basename "$(dirname "$f")")/$(basename "$f") ---"
    cat "$f"
    echo ""
  done > "$temp_telemetry"

  # Collect current config
  local temp_config
  temp_config=$(mktemp)
  {
    echo "=== CURRENT CONFIG ==="
    echo "ORCH_MODEL=$ORCH_MODEL"
    echo "ORCH_MAX_TURNS_IMPLEMENT=$ORCH_MAX_TURNS_IMPLEMENT"
    echo "ORCH_MAX_TURNS_SUPPORT=$ORCH_MAX_TURNS_SUPPORT"
    echo "ORCH_MAX_TURNS_BUILD=$ORCH_MAX_TURNS_BUILD"
    echo "ORCH_MAX_TURNS_CI_FIX=$ORCH_MAX_TURNS_CI_FIX"
    echo "ORCH_CI_MAX_RETRIES=$ORCH_CI_MAX_RETRIES"
    echo "ORCH_CI_TIMEOUT=$ORCH_CI_TIMEOUT"
    echo "ORCH_SKIP_ROLES=$ORCH_SKIP_ROLES"
    echo "ORCH_SKIP_FIX=$ORCH_SKIP_FIX"
    echo "ORCH_SKIP_DOCS=$ORCH_SKIP_DOCS"
    echo "ORCH_ON_STEP_FAIL=$ORCH_ON_STEP_FAIL"
    echo "ORCH_ON_CI_EXHAUST=$ORCH_ON_CI_EXHAUST"
    echo "ORCH_SKIP_PERMISSIONS=$ORCH_SKIP_PERMISSIONS"
  } > "$temp_config"

  local orchestrator_path="$SCRIPT_DIR"
  local telemetry_content
  telemetry_content=$(cat "$temp_telemetry")
  local config_content
  config_content=$(cat "$temp_config")

  # Build the analysis prompt
  local prompt
  read -r -d '' prompt << 'PROMPTEOF' || true
Sos un ingeniero de DevTools analizando datos de telemetría de un orquestador de sesiones de Claude Code.

## Tu tarea

Analizá los datos de telemetría y la configuración actual del orquestador. Basándote en los patrones que encontrés, generá recomendaciones concretas para mejorar el rendimiento, reducir fallos, y optimizar costos.

## Datos de telemetría (JSONL events)

```
%%TELEMETRY%%
```

## Configuración actual

```
%%CONFIG%%
```

## Archivos del orquestador

Leé los siguientes archivos para entender la implementación actual:
- scripts/orchestrator/lib/config.sh (defaults y parámetros)
- scripts/orchestrator/lib/runner.sh (ejecución de sesiones)
- scripts/orchestrator/lib/telemetry.sh (sistema de telemetría)
- scripts/orchestrator/q-orchestrator.sh (menú y flujos)

## Qué analizar

1. **Duración de pasos**: ¿Qué pasos tardan más? ¿Alguno excede consistentemente su max_turns?
2. **Tasa de éxito**: ¿Qué pasos fallan más? ¿Hay un patrón de fallos recurrentes?
3. **CI retries**: ¿Son efectivos? ¿Cuántos intentos se necesitan en promedio? ¿Deberían ser más o menos?
4. **Config tuning**: ¿Los max_turns actuales son adecuados o necesitan ajuste?
5. **Cuellos de botella**: ¿Dónde se pierde más tiempo?
6. **Prompts**: ¿Los prompts inline están siendo efectivos? ¿Se podrían mejorar?
7. **Flujo**: ¿El orden de pasos es óptimo? ¿Falta algún paso? ¿Sobra alguno?

## Output esperado

%%OUTPUT_INSTRUCTIONS%%
PROMPTEOF

  # Replace placeholders
  prompt="${prompt//%%TELEMETRY%%/$telemetry_content}"
  prompt="${prompt//%%CONFIG%%/$config_content}"

  case "$analysis_mode" in
    1)
      # Read-only analysis
      prompt="${prompt//%%OUTPUT_INSTRUCTIONS%%/Generá un reporte en markdown con:
1. **Resumen ejecutivo** (3-5 bullets)
2. **Hallazgos detallados** por categoría
3. **Recomendaciones** con valores concretos (ej: \"cambiar ORCH_MAX_TURNS_IMPLEMENT de 80 a 120\")
4. **Priorización**: qué cambiar primero para mayor impacto

NO modifiques ningún archivo. Solo analizá y reportá.
Guardá el reporte en docs/orchestrator-analysis.md (creá el archivo).}"

      echo ""
      ui_info "Ejecutando análisis (solo lectura)..."
      echo ""
      run_claude "$orchestrator_path" "$prompt" "$ORCH_MODEL" "$ORCH_MAX_TURNS_SUPPORT"
      ;;
    2)
      # Auto-apply improvements
      prompt="${prompt//%%OUTPUT_INSTRUCTIONS%%/Basándote en tu análisis:

1. **Generá un reporte** en docs/orchestrator-analysis.md con hallazgos y cambios realizados
2. **Modificá lib/config.sh** — ajustá los defaults basándote en los datos reales
3. **Modificá lib/runner.sh** — mejorá prompts, flujo, o lógica si encontrás problemas
4. **Modificá lib/telemetry.sh** — agregá métricas faltantes si las necesitás
5. **NO rompas nada** — corré bash -n en cada archivo que modifiques para verificar sintaxis

Reglas:
- Solo cambiá valores default si los datos lo justifican claramente
- Si mejorás un prompt, explicá por qué en el reporte
- Commiteá cada cambio con un mensaje descriptivo
- Si no hay suficientes datos para decidir, dejá el valor actual y anotalo como \"insuficientes datos\"}"

      echo ""
      ui_warn "Claude va a analizar la telemetría Y modificar el orquestador."
      if ui_confirm "¿Continuar?"; then
        echo ""
        ui_info "Ejecutando análisis y aplicando mejoras..."
        echo ""
        run_claude "$orchestrator_path" "$prompt" "$ORCH_MODEL" "$ORCH_MAX_TURNS_IMPLEMENT"
      fi
      ;;
    3)
      # Single project analysis
      local options=()
      local slugs=()
      while IFS='|' read -r idx slug path repo branch branch_strategy; do
        options+=("${slug}")
        slugs+=("${slug}")
      done < <(list_projects)

      if [ ${#options[@]} -eq 0 ]; then
        ui_warn "No hay proyectos registrados."
        read -rp "  Presioná Enter para volver..."
        rm -f "$temp_telemetry" "$temp_config"
        return
      fi

      ui_menu "SELECCIONAR PROYECTO" "${options[@]}"
      local selected_slug="${slugs[$((MENU_CHOICE - 1))]}"

      # Filter telemetry for this project only
      local project_telemetry_dir="${telemetry_base}/${selected_slug}"
      if [ ! -d "$project_telemetry_dir" ] || [ -z "$(ls -A "$project_telemetry_dir" 2>/dev/null)" ]; then
        ui_warn "No hay telemetría para ${selected_slug}."
        read -rp "  Presioná Enter para volver..."
        rm -f "$temp_telemetry" "$temp_config"
        return
      fi

      # Rebuild telemetry with only this project
      : > "$temp_telemetry"
      find "$project_telemetry_dir" -name '*.jsonl' -type f | sort | while IFS= read -r f; do
        echo "--- $(basename "$f") ---"
        cat "$f"
        echo ""
      done > "$temp_telemetry"

      telemetry_content=$(cat "$temp_telemetry")
      prompt="${prompt//%%TELEMETRY%%/$telemetry_content}"

      prompt="${prompt//%%OUTPUT_INSTRUCTIONS%%/Generá un reporte enfocado en el proyecto ${selected_slug}:
1. **Resumen ejecutivo**
2. **Hallazgos específicos** de este proyecto
3. **Recomendaciones de config** — podés sugerir un archivo .q-orchestrator.sh específico para este proyecto
4. **Sugerencias de prompts** — si los prompts de sesión/soporte necesitan ajustes

Guardá el reporte en docs/orchestrator-analysis-${selected_slug}.md.
NO modifiques archivos del orquestador.}"

      echo ""
      ui_info "Analizando telemetría de ${selected_slug}..."
      echo ""
      run_claude "$orchestrator_path" "$prompt" "$ORCH_MODEL" "$ORCH_MAX_TURNS_SUPPORT"
      ;;
  esac

  # Cleanup
  rm -f "$temp_telemetry" "$temp_config"

  echo ""
  ui_ok "Análisis completado."
  read -rp "  Presioná Enter para volver..."
}

main_menu() {
  while true; do
    ui_header

    # Show quick status
    local count
    count=$(project_count)
    ui_info "Proyectos registrados: ${count}"

    # Show projects with pending work
    if [ "$count" -gt 0 ]; then
      echo ""
      while IFS='|' read -r idx slug path repo branch branch_strategy; do
        if [ -f "${path}/ROADMAP.md" ]; then
          local pending
          pending=$(count_pending_sessions "$path" "$slug")
          if [ "$pending" -gt 0 ]; then
            ui_info "  ${slug}: ${pending} sesiones pendientes"
          fi
        fi
      done < <(list_projects)
    fi

    ui_menu "MENÚ PRINCIPAL" \
      "Trabajar en un proyecto" \
      "Gestionar proyectos" \
      "Configuración" \
      "Diagnóstico del entorno" \
      "Logs y telemetría" \
      "Auto-mejora (Claude analiza y mejora el orquestador)" \
      "Salir"

    case "$MENU_CHOICE" in
      1)
        if select_project; then
          select_model
          select_and_run_mode
        fi
        ;;
      2) manage_projects ;;
      3) manage_config ;;
      4) run_diagnostic ;;
      5) manage_logs ;;
      6) run_self_improve ;;
      7) echo ""; echo "  Hasta luego!"; echo ""; exit 0 ;;
    esac
  done
}

# ── Logs & telemetry management ──
manage_logs() {
  while true; do
    ui_header

    ui_menu "LOGS Y TELEMETRÍA" \
      "Ver logs recientes" \
      "Exportar diagnóstico de un proyecto" \
      "Exportar diagnóstico de todos los proyectos" \
      "Ver reportes exportados" \
      "Volver al menú principal"

    case "$MENU_CHOICE" in
      1) view_logs ;;
      2) export_single_project ;;
      3)
        export_all_diagnostics
        echo ""
        read -rp "  Presioná Enter para volver..."
        ;;
      4) view_exports ;;
      5) return ;;
    esac
  done
}

view_logs() {
  ui_header
  local log_dir="${CONFIG_DIR}/logs"

  if [ ! -d "$log_dir" ] || [ -z "$(ls -A "$log_dir" 2>/dev/null)" ]; then
    ui_warn "No hay logs todavía."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  ui_section "LOGS RECIENTES"
  ui_empty

  local log_files=()
  while IFS= read -r f; do
    log_files+=("$f")
    local basename
    basename=$(basename "$f")
    ui_item "" "$basename"
  done < <(find "$log_dir" -name "*.log" -type f | sort -r | head -15)

  ui_empty
  ui_section_end

  echo ""
  ui_prompt "Nombre del log a ver (Enter para volver):"
  read -r log_name

  if [ -z "$log_name" ]; then
    return
  fi

  local found
  found=$(find "$log_dir" -name "*${log_name}*" -type f | head -1)
  if [ -n "$found" ]; then
    less "$found"
  else
    ui_error "Log no encontrado."
    read -rp "  Presioná Enter para volver..."
  fi
}

export_single_project() {
  local count
  count=$(project_count)

  if [ "$count" -eq 0 ]; then
    ui_warn "No hay proyectos registrados."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  # Build options
  local options=()
  local slugs=()
  while IFS='|' read -r idx slug path repo branch branch_strategy; do
    options+=("${slug}")
    slugs+=("${slug}")
  done < <(list_projects)

  ui_menu "EXPORTAR DIAGNÓSTICO" "${options[@]}"
  local selected_slug="${slugs[$((MENU_CHOICE - 1))]}"

  echo ""
  ui_info "Generando reporte de diagnóstico para ${selected_slug}..."

  local report
  report=$(export_diagnostic_report "$selected_slug")

  if [ -n "$report" ] && [ -f "$report" ]; then
    ui_ok "Reporte generado: ${report}"
    echo ""
    if ui_confirm "¿Ver el reporte ahora?"; then
      less "$report"
    fi
  else
    ui_warn "No hay datos de telemetría para ${selected_slug}."
    ui_info "Los datos se recopilan cuando ejecutás sesiones."
  fi

  echo ""
  read -rp "  Presioná Enter para volver..."
}

view_exports() {
  ui_header
  local export_dir="${CONFIG_DIR}/exports"

  if [ ! -d "$export_dir" ] || [ -z "$(ls -A "$export_dir" 2>/dev/null)" ]; then
    ui_warn "No hay reportes exportados todavía."
    echo ""
    read -rp "  Presioná Enter para volver..."
    return
  fi

  ui_section "REPORTES EXPORTADOS"
  ui_empty

  local export_files=()
  while IFS= read -r f; do
    export_files+=("$f")
    local basename
    basename=$(basename "$f")
    ui_item "" "$basename"
  done < <(find "$export_dir" -name "*.md" -type f | sort -r | head -15)

  ui_empty
  ui_section_end

  echo ""
  ui_prompt "Nombre del reporte a ver (Enter para volver):"
  read -r report_name

  if [ -z "$report_name" ]; then
    return
  fi

  local found
  found=$(find "$export_dir" -name "*${report_name}*" -type f | head -1)
  if [ -n "$found" ]; then
    less "$found"
  else
    ui_error "Reporte no encontrado."
    read -rp "  Presioná Enter para volver..."
  fi
}

# ══════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════

check_deps
ensure_config
load_config

# If CLI args provide enough info, skip menu
if [ -n "$ARG_PROJECT" ] && [ -n "$ARG_MODE" ]; then
  if select_project; then
    [ -n "$ARG_MODEL" ] && SELECTED_MODEL="$ARG_MODEL"
    select_and_run_mode
  fi
  exit $?
fi

main_menu
