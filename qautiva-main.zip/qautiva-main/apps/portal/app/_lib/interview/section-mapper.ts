/**
 * Mapea respuestas de la entrevista web v2 a secciones requeridas del template.
 *
 * Función pura, sin side effects. Usada por:
 * - GET /api/templates/recommend (scoring de templates)
 * - processWebsiteSession (activación de secciones en generación)
 *
 * @see ADR-0018 — Mapeo respuestas → secciones
 */

/** Valores válidos para cada pregunta de la entrevista web v2 */
export const VALID_WEB_ANSWERS: Record<string, readonly string[]> = {
  web_objetivo: ['mostrar_servicios', 'vender_online', 'captar_consultas', 'informar'],
  web_agenda: ['si', 'no', 'me_interesa'],
  web_pagos: ['si', 'no', 'me_interesa'],
  web_empleo: ['si', 'no'],
  web_blog: ['si', 'no'],
  // web_extra: texto libre, no se valida contra whitelist
} as const;

/** Secciones que se activan siempre, independiente de las respuestas */
const ALWAYS_ACTIVE_SECTIONS = ['hero', 'about'] as const;

/**
 * Deriva las secciones requeridas del template a partir de las respuestas
 * de la entrevista web v2.
 *
 * @param answers - Objeto con las respuestas del usuario (key: questionId, value: answer)
 * @returns Array de strings con los nombres de las secciones requeridas (sin duplicados)
 */
export function getRequiredSections(answers: Record<string, string>): string[] {
  const sections = new Set<string>(ALWAYS_ACTIVE_SECTIONS);

  // Objetivo principal → secciones base
  const objetivo = answers.web_objetivo;
  if (objetivo === 'mostrar_servicios') sections.add('services');
  if (objetivo === 'captar_consultas') sections.add('contact');
  if (objetivo === 'vender_online') sections.add('pricing');

  // Servicios Q → secciones específicas (solo "si", no "me_interesa")
  if (answers.web_agenda === 'si') sections.add('booking');
  if (answers.web_pagos === 'si') sections.add('payments');
  if (answers.web_empleo === 'si') sections.add('careers');
  if (answers.web_blog === 'si') sections.add('blog');

  return Array.from(sections);
}

/**
 * Extrae los leads comerciales de las respuestas "me_interesa".
 *
 * @param answers - Objeto con las respuestas del usuario
 * @returns Array de service keys que el usuario quiere conocer más
 */
export function getCommercialLeads(answers: Record<string, string>): string[] {
  const leads: string[] = [];

  if (answers.web_agenda === 'me_interesa') leads.push('qontacta');
  if (answers.web_pagos === 'me_interesa') leads.push('qobra');

  return leads;
}

/**
 * Valida que un valor de respuesta sea válido para una pregunta dada.
 * Retorna true si el valor está en la whitelist. Para web_extra (texto libre)
 * siempre retorna true (la sanitización HTML se hace por separado).
 */
export function isValidWebAnswer(questionId: string, value: string): boolean {
  if (questionId === 'web_extra') return true;

  const validValues = VALID_WEB_ANSWERS[questionId];
  if (!validValues) return false;

  return validValues.includes(value);
}
