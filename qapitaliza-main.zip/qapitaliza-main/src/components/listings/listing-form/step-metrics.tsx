'use client'

import { useFormContext } from 'react-hook-form'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import type { CreateListingInput } from '@/lib/schemas/listing'

const sourceOptions = [
  { value: 'SELF_REPORTED', label: 'Auto-reportado' },
  { value: 'SCREENSHOT', label: 'Captura de pantalla' },
  { value: 'ANALYTICS_CONNECTED', label: 'Analytics conectado' },
]

interface MetricRowProps {
  label: string
  field: string
  helper?: string
}

function MetricRow({ label, field, helper }: MetricRowProps) {
  // Using any for dynamic nested paths that can't be statically inferred
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { register, watch, setValue } = useFormContext<any>()
  const source = (watch(`${field}.source`) as string | undefined) ?? 'SELF_REPORTED'

  return (
    <div className="p-4 bg-slate-800/50 border border-slate-800 rounded-xl space-y-3">
      <p className="text-sm font-medium text-slate-300">{label}</p>
      <div className="grid grid-cols-2 gap-3">
        <Input
          type="number"
          placeholder="0"
          helper={helper}
          {...register(`${field}.value`, { valueAsNumber: true })}
        />
        <Select
          options={sourceOptions}
          value={source}
          onChange={(v) => setValue(`${field}.source`, v)}
        />
      </div>
      <Input
        placeholder="URL de evidencia (opcional)"
        {...register(`${field}.evidenceUrl`)}
      />
    </div>
  )
}

const metricsByType: Record<string, { label: string; field: string; helper?: string }[]> = {
  WEBSITE: [
    { label: 'Visitas por mes', field: 'monthlyTraffic', helper: 'Promedio últimos 3 meses' },
    { label: 'Domain Authority', field: 'domainAuthority', helper: 'Moz DA (0-100)' },
    { label: 'Edad del dominio (meses)', field: 'domainAge' },
  ],
  DOMAIN: [
    { label: 'Domain Authority', field: 'domainAuthority', helper: 'Moz DA (0-100)' },
    { label: 'Año de registro', field: 'registrationYear' },
  ],
  SAAS: [
    { label: 'MRR (USD)', field: 'mrr', helper: 'Monthly Recurring Revenue' },
    { label: 'Usuarios activos', field: 'activeUsers' },
    { label: 'Churn rate (%)', field: 'churnRate' },
    { label: 'Edad (meses)', field: 'domainAge' },
  ],
  MVP: [
    { label: 'MRR (USD)', field: 'mrr', helper: 'Monthly Recurring Revenue' },
    { label: 'Usuarios activos', field: 'activeUsers' },
    { label: 'Churn rate (%)', field: 'churnRate' },
    { label: 'Edad (meses)', field: 'domainAge' },
  ],
  ECOMMERCE: [
    { label: 'Órdenes por mes', field: 'monthlyOrders' },
    { label: 'Revenue mensual (USD)', field: 'monthlyRevenue' },
    { label: 'Edad (meses)', field: 'domainAge' },
  ],
  PROJECT: [
    { label: 'Usuarios activos', field: 'activeUsers' },
    { label: 'Edad (meses)', field: 'domainAge' },
  ],
  OTHER: [
    { label: 'Usuarios activos', field: 'activeUsers' },
  ],
}

export function StepMetrics() {
  const { watch } = useFormContext<CreateListingInput>()
  const type = watch('type')

  const metrics = metricsByType[type] ?? []

  if (!type) {
    return (
      <div className="py-8 text-center text-slate-500 text-sm">
        Seleccioná un tipo de activo en el paso anterior para ver las métricas disponibles.
      </div>
    )
  }

  if (metrics.length === 0) {
    return (
      <div className="py-8 text-center text-slate-500 text-sm">
        No hay métricas específicas para este tipo de activo.
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-400">
        Ingresá las métricas de tu activo. Cuanto más completa sea la información, mayor confianza generás en los compradores.
      </p>
      {metrics.map(({ label, field, helper }) => (
        <MetricRow key={field} label={label} field={field} helper={helper} />
      ))}
    </div>
  )
}
