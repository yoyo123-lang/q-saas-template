# Sesión 02 — Landing y Páginas Públicas

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 01 — Next.js inicializado, migraciones ejecutadas, design system y componentes UI primitivos creados.

Esta sesión construye todas las páginas públicas (sin login): landing, catálogo, detalle de activo y "cómo funciona".

Leer antes de empezar:
- `PLAN.md` — Etapas 2 y 3
- `docs/frontend/03-paginas-publicas.md` — especificación completa de cada página
- `docs/frontend/02-componentes-base.md` — componentes ya existentes a reutilizar

## Estado actual

Ya existen en `src/components/ui/`: Button, Card, Badge, Input, Textarea, Select, Modal, Accordion, Avatar, Pagination, SkeletonCard, Divider.
Ya existen en `src/components/shared/`: LogoQ, EmptyState, ErrorState.

## Tarea de esta sesión

### BLOQUE A — Layout público y navegación

#### A1. `src/app/(public)/layout.tsx`
Layout compartido para todas las páginas públicas. Incluye `<Navbar />` arriba y `<Footer />` abajo.

#### A2. `src/components/layout/navbar.tsx`
Navbar fija con blur. Ver `docs/frontend/02-componentes-base.md` §10:
- Fondo: `bg-navy-950/95 backdrop-blur-sm border-b border-slate-800 h-16 fixed top-0 z-50`
- Izquierda: `<LogoQ showText />`
- Centro: links "Explorar" `/explorar`, "Cómo funciona" `/como-funciona`
- Derecha: `<Button variant="outline" size="sm">Iniciar sesión</Button>` → `/login` y `<Button variant="solid" size="sm">Registrate</Button>` → `/registro`
- En mobile: menú hamburguesa que colapsa los links

#### A3. `src/components/layout/footer.tsx`
Footer con 3 columnas (Producto, Empresa, Legal) + copyright. Ver `docs/frontend/03-paginas-publicas.md` §1.6.

---

### BLOQUE B — Componentes de la landing

#### B1. `src/components/shared/hero-search.tsx`
Input de búsqueda del hero. Al submit navega a `/explorar?q={query}`. Ver `docs/frontend/03-paginas-publicas.md` §1.1.

#### B2. `src/components/shared/category-pill.tsx`
Pill de categoría. Props: `icon`, `label`, `count`, `slug`. Click → `/explorar?category={slug}`.

#### B3. `src/components/shared/how-it-works.tsx`
3 columnas con número amber grande (01, 02, 03), título y descripción. Datos hardcodeados.

#### B4. `src/components/shared/timeline.tsx`
Timeline vertical con dots amber y línea conectora. Props: `steps: { icon, title, description }[]`. Usado en "cómo funciona".

#### B5. `src/components/shared/accordion-faq.tsx`
FAQ con expand/collapse. Reutilizar el `accordion.tsx` de UI. Una pregunta abierta a la vez.

---

### BLOQUE C — Landing page

`src/app/page.tsx` — Server Component con fetch SSR.

Secciones en orden (ver `docs/frontend/03-paginas-publicas.md` §1):
1. **Hero**: `mesh-gradient-amber`, título H1, subtítulo, `<HeroSearch />`, stats row hardcodeados ("127 activos listados · $2.4M en transacciones · 340+ emprendedores")
2. **Categorías**: `<CategoryPill />` × 5 en fila horizontal. Counts traídos de DB con query a `categories`.
3. **Activos destacados**: grilla 3 columnas de `<ListingCard />`. Fetch SSR de listings con `featured_until > NOW()`, limit 6.
4. **Cómo funciona**: `<HowItWorks />` con 3 pasos.
5. **CTA final**: banner con gradiente amber/5, botón "Publicá gratis" → `/registro?rol=seller`.

**`<ListingCard />`** (`src/components/listings/listing-card.tsx`):
Ver `docs/frontend/02-componentes-base.md` §7. Props completas incluyendo `isFavorited`, `onFavoriteToggle`. En landing: botón favorito deshabilitado si no hay sesión (redirige a login). Mostrar placeholder si no hay screenshot.

---

### BLOQUE D — Catálogo `/explorar`

`src/app/(public)/explorar/page.tsx` — Server Component, lee searchParams.

searchParams soportados: `q`, `category`, `priceMin`, `priceMax`, `revenueMin`, `verified`, `tech` (array), `sort`, `page`. Ver `docs/frontend/03-paginas-publicas.md` §2.

#### D1. Data access layer `src/lib/data/listings.ts`

```ts
export async function getListings(params: ListingQueryParams): Promise<{ items: Listing[], total: number }>
export async function getListing(slug: string): Promise<Listing | null>
export async function getRelatedListings(listingId: string, type: string, limit?: number): Promise<Listing[]>
```

- Paginación: 20 items por página, máximo 100
- Full-text search con `to_tsvector('spanish', ...)` para el param `q`
- Filtro por `tech_stack @> ARRAY[...]::text[]` para el param `tech`
- Solo devolver listings con `status = 'PUBLISHED'`

Tests unitarios en `src/lib/data/__tests__/listings.test.ts`: queries básicas, filtros, paginación, búsqueda de texto, edge cases (página vacía, sin resultados).

#### D2. `src/components/listings/filter-sidebar.tsx`
5 secciones de filtro. Cambio de cualquier filtro → `router.push` con nuevos searchParams (sin reload de página). Ver `docs/frontend/03-paginas-publicas.md` §2.

#### D3. `src/components/listings/results-grid.tsx`
Barra superior con "N resultados" + dropdown "Ordenar por". Grid responsivo + `<Pagination />`. `<SkeletonCard />` mientras carga.

#### D4. `src/components/listings/tech-pill.tsx`
`font-mono text-xs bg-slate-800 text-slate-50 px-3 py-1 rounded-full`

---

### BLOQUE E — Detalle del activo `/explorar/[slug]`

`src/app/(public)/explorar/[slug]/page.tsx` — SSR con `generateMetadata`.

Ver `docs/frontend/03-paginas-publicas.md` §3. Estructura:
- Layout 2 columnas: 65% contenido + 35% sidebar sticky
- **Breadcrumb**: `<Breadcrumb />` (`src/components/shared/breadcrumb.tsx`)
- **Galería**: imagen principal grande + thumbnails clickables (estado local para imagen activa)
- **Tech stack**: `<TechPill />` × n
- **Métricas**: grid 2×3 de stat mini-cards con label uppercase + valor + trend opcional. Nota "Métricas verificadas ✓" en emerald si `verification_status = 'VERIFIED'`
- **Sidebar sticky**: precio amber, botón "Consultar al vendedor" (solid full-width), botón "♡ Guardar" (outline full-width), info vendedor, card de seguridad con borde amber/20
- **Activos relacionados**: `getRelatedListings()`, grilla 3 columnas

`generateMetadata`: título, description, og:image con primer screenshot.

Incrementar `view_count` llamando al RPC `increment_listing_views(id)` via Server Action (no expuesto al cliente).

---

### BLOQUE F — Cómo funciona `/como-funciona`

`src/app/(public)/como-funciona/page.tsx` — página estática, sin fetch.

Ver `docs/frontend/03-paginas-publicas.md` §4:
- Hero centrado con mesh gradient
- `<Timeline />` para vendedores (4 pasos)
- `<Timeline />` para compradores (3 pasos)
- Card de verificación con borde amber/20 y 3 checks verdes
- `<AccordionFAQ />` con 6 preguntas hardcodeadas
- CTA final con 2 botones

---

### BLOQUE G — Sitemap y metadata global

`src/app/sitemap.ts`: rutas estáticas + todos los listings PUBLISHED. `revalidate: 3600`.

`src/app/layout.tsx`: actualizar con `metadataBase`, title template, og defaults. Ver `docs/frontend/03-paginas-publicas.md` §5.

---

## Datos de prueba

Si la DB está vacía, crear un seed temporal en `prisma/seed.ts` con 10 listings de ejemplo para poder probar el catálogo. El seed completo (~50 activos) va en la Sesión 03.

## Reglas

- Todas las páginas públicas son Server Components — no usar `"use client"` salvo en componentes interactivos específicos (FilterSidebar, galería de imágenes)
- `<ListingCard />` debe manejar correctamente el estado vacío de screenshot sin romperse
- Ningún botón puede quedar sin `href` o `onClick` — si la funcionalidad no existe aún (favoritos, consultar), redirigir a `/login`

## Checkpoint

La sesión está completa cuando:
- [ ] Landing renderiza con hero, categorías, 6 activos destacados y FAQ funcional
- [ ] `/explorar` muestra catálogo con filtros funcionales y paginación
- [ ] `/explorar/[slug]` muestra detalle completo con galería, métricas, sidebar sticky
- [ ] `/como-funciona` muestra timeline, FAQ expandible y CTAs
- [ ] Metadata y Open Graph correctos en cada página
- [ ] Tests del DAL pasan
- [ ] `npm run build` sin errores
