/**
 * Tests TDD para recordTokenUsage().
 *
 * Estrategia: mocks completos de @qautiva/db (prisma).
 * Sin llamadas reales a la DB.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockAiModelPricingFindUnique = vi.fn()
const mockBillingAccountFindUnique = vi.fn()
const mockFeeConfigFindFirst = vi.fn()
const mockTokenUsageCreate = vi.fn()

vi.mock('@qautiva/db', () => ({
  prisma: {
    aiModelPricing: { findUnique: mockAiModelPricingFindUnique },
    billingAccount: { findUnique: mockBillingAccountFindUnique },
    feeConfig: { findFirst: mockFeeConfigFindFirst },
    tokenUsage: { create: mockTokenUsageCreate },
  },
  AiProvider: {
    ANTHROPIC: 'ANTHROPIC',
    OPENAI: 'OPENAI',
    GOOGLE_GEMINI: 'GOOGLE_GEMINI',
  },
  BillingPlan: {
    FREE_TRIAL: 'FREE_TRIAL',
    PREPAID: 'PREPAID',
    MONTHLY: 'MONTHLY',
    YEARLY: 'YEARLY',
  },
  ApiKeySource: {
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
  UsageSource: {
    TRIAL: 'TRIAL',
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
}))

// ── Fixtures ──────────────────────────────────────────────────────────────────

const BASE_PARAMS = {
  teamId: 'team-abc',
  projectId: 'proj-xyz',
  provider: 'ANTHROPIC' as const,
  model: 'claude-3-5-sonnet-20241022',
  operation: 'brief_generation',
  source: 'TRIAL' as const,
  tokensIn: 1000,
  tokensOut: 500,
}

const MOCK_PRICING = {
  id: 'price-1',
  provider: 'ANTHROPIC',
  model: 'claude-3-5-sonnet-20241022',
  inputPer1M: { toNumber: () => 3.0 },   // $3 per 1M input tokens
  outputPer1M: { toNumber: () => 15.0 },  // $15 per 1M output tokens
  isActive: true,
}

const MOCK_BILLING_ACCOUNT = {
  id: 'ba-1',
  teamId: 'team-abc',
  plan: 'FREE_TRIAL',
  preferredKeySource: 'QAUTIVA_HOSTED',
  balanceUsd: { toNumber: () => 10.0 },
  trialTokensTotal: 100000,
  trialTokensUsed: 5000,
}

const MOCK_FEE_CONFIG = {
  id: 'fee-1',
  plan: 'FREE_TRIAL',
  keySource: 'QAUTIVA_HOSTED',
  feePercentage: { toNumber: () => 20.0 }, // 20%
  isActive: true,
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('recordTokenUsage', () => {
  beforeEach(() => {
    mockAiModelPricingFindUnique.mockReset()
    mockBillingAccountFindUnique.mockReset()
    mockFeeConfigFindFirst.mockReset()
    mockTokenUsageCreate.mockReset()
  })

  it('caso normal: calcula costUsd, feeUsd, totalUsd correctamente e inserta TokenUsage', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(MOCK_FEE_CONFIG)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-1' })

    const result = await recordTokenUsage(BASE_PARAMS)

    // Verifica el valor de retorno
    expect(result).not.toBeNull()
    expect(result!.id).toBe('tu-1')
    expect(typeof result!.totalUsd).toBe('number')
    expect(result!.totalUsd).toBeCloseTo(0.0126, 6)

    // costUsd = 1000 * 3.0 / 1_000_000 + 500 * 15.0 / 1_000_000 = 0.003 + 0.0075 = 0.0105
    // feeUsd = 0.0105 * 20 / 100 = 0.0021
    // totalUsd = 0.0105 + 0.0021 = 0.0126
    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    const createArgs = mockTokenUsageCreate.mock.calls[0][0].data
    expect(createArgs.teamId).toBe('team-abc')
    expect(createArgs.projectId).toBe('proj-xyz')
    expect(createArgs.provider).toBe('ANTHROPIC')
    expect(createArgs.model).toBe('claude-3-5-sonnet-20241022')
    expect(createArgs.operation).toBe('brief_generation')
    expect(createArgs.source).toBe('TRIAL')
    expect(createArgs.tokensIn).toBe(1000)
    expect(createArgs.tokensOut).toBe(500)
    expect(Number(createArgs.costUsd)).toBeCloseTo(0.0105, 6)
    expect(Number(createArgs.feeUsd)).toBeCloseTo(0.0021, 6)
    expect(Number(createArgs.totalUsd)).toBeCloseTo(0.0126, 6)
    expect(Number(createArgs.feePercentage)).toBeCloseTo(20.0, 2)
  })

  it('caso sin pricing en DB: lanza error ruidoso con "CRITICAL:"', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(null)

    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
    await expect(recordTokenUsage(BASE_PARAMS)).rejects.toThrow()
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('CRITICAL:'),
      expect.anything(),
    )
    consoleSpy.mockRestore()
  })

  it('caso sin FeeConfig: lanza error CRITICAL (billing no configurado)', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(null)

    await expect(recordTokenUsage(BASE_PARAMS)).rejects.toThrow(/FeeConfig/)
    // Si lanza antes del create, el TokenUsage no se inserta
    expect(mockTokenUsageCreate).not.toHaveBeenCalled()
  })

  it('caso BYOK: source=BYOK se persiste correctamente', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    const byokAccount = { ...MOCK_BILLING_ACCOUNT, preferredKeySource: 'BYOK' }
    const byokFeeConfig = { ...MOCK_FEE_CONFIG, keySource: 'BYOK', feePercentage: { toNumber: () => 0 } }

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(byokAccount)
    mockFeeConfigFindFirst.mockResolvedValueOnce(byokFeeConfig)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-3' })

    await recordTokenUsage({ ...BASE_PARAMS, source: 'BYOK' })

    const createArgs = mockTokenUsageCreate.mock.calls[0][0].data
    expect(createArgs.source).toBe('BYOK')
  })

  it('caso QAUTIVA_HOSTED: source=QAUTIVA_HOSTED se persiste correctamente', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(MOCK_FEE_CONFIG)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-4' })

    await recordTokenUsage({ ...BASE_PARAMS, source: 'QAUTIVA_HOSTED' })

    const createArgs = mockTokenUsageCreate.mock.calls[0][0].data
    expect(createArgs.source).toBe('QAUTIVA_HOSTED')
  })

  it('caso tokens negativos: lanza error CRITICAL', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
    await expect(recordTokenUsage({ ...BASE_PARAMS, tokensIn: -1 })).rejects.toThrow()
    expect(consoleSpy).toHaveBeenCalledWith(expect.stringContaining('CRITICAL:'), expect.anything())
    expect(mockAiModelPricingFindUnique).not.toHaveBeenCalled()
    consoleSpy.mockRestore()
  })

  it('caso teamId null: retorna null sin hacer queries a la DB', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    const result = await recordTokenUsage({ ...BASE_PARAMS, teamId: null })

    expect(result).toBeNull()
    expect(mockAiModelPricingFindUnique).not.toHaveBeenCalled()
    expect(mockBillingAccountFindUnique).not.toHaveBeenCalled()
    expect(mockTokenUsageCreate).not.toHaveBeenCalled()
  })

  it('caso billingAccount no existe: fee=0 con warning, totalUsd = costUsd', async () => {
    const { recordTokenUsage } = await import('../record-token-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    // BillingAccount no existe para el team
    mockBillingAccountFindUnique.mockResolvedValueOnce(null)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-5' })

    const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
    await recordTokenUsage(BASE_PARAMS)

    // No debe fallar — fee=0 y totalUsd = costUsd
    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    const createArgs = mockTokenUsageCreate.mock.calls[0][0].data
    expect(Number(createArgs.feeUsd)).toBe(0)
    expect(Number(createArgs.feePercentage)).toBe(0)
    expect(Number(createArgs.totalUsd)).toBeCloseTo(Number(createArgs.costUsd), 6)
    // feeConfig no se consulta si billingAccount es null
    expect(mockFeeConfigFindFirst).not.toHaveBeenCalled()
    consoleSpy.mockRestore()
  })
})
