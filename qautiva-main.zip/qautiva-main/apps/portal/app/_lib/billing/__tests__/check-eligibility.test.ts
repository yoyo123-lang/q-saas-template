/**
 * Tests TDD para checkBillingEligibility().
 *
 * Estrategia: mocks completos de @qautiva/db (prisma).
 * Sin llamadas reales a la DB.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const { mockBillingAccountFindUnique } = vi.hoisted(() => ({
  mockBillingAccountFindUnique: vi.fn(),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    billingAccount: { findUnique: mockBillingAccountFindUnique },
  },
  BillingPlan: {
    FREE_TRIAL: 'FREE_TRIAL',
    PREPAID: 'PREPAID',
    MONTHLY: 'MONTHLY',
    YEARLY: 'YEARLY',
  },
  ApiKeySource: {
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
  UsageSource: {
    TRIAL: 'TRIAL',
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
}))

// ── Import después de los mocks ────────────────────────────────────────────────

import { checkBillingEligibility } from '../check-eligibility'

// ── Helpers ───────────────────────────────────────────────────────────────────

function toDecimal(n: number) {
  return { toNumber: () => n }
}

function futureDate(days = 30): Date {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000)
}

function pastDate(days = 1): Date {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000)
}

// ── Tests ──────────────────────────────────────────────────────────────────────

describe('checkBillingEligibility', () => {
  beforeEach(() => {
    mockBillingAccountFindUnique.mockReset()
  })

  // ── BYOK ──────────────────────────────────────────────────────────────────

  it('BYOK con plan no-FREE_TRIAL es siempre eligible, aunque no tenga saldo', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'PREPAID',
      preferredKeySource: 'BYOK',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(0), // sin saldo, pero BYOK no lo necesita
    })

    const result = await checkBillingEligibility('team-byok')

    expect(result.eligible).toBe(true)
    expect(result.source).toBe('BYOK')
    expect(result.reason).toBeUndefined()
  })

  it('BYOK con plan FREE_TRIAL aplica las restricciones del trial (no bypass)', async () => {
    // Un team FREE_TRIAL con BYOK mal configurado no debe bypassear el trial
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'BYOK',
      trialExpiresAt: pastDate(),
      trialTokensUsed: 99999,
      trialTokensTotal: 1000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-byok-trial')

    // Debe ser inelegible porque el trial expiró (a pesar de tener BYOK)
    expect(result.eligible).toBe(false)
    expect(result.source).toBe('TRIAL')
  })

  // ── FREE_TRIAL ────────────────────────────────────────────────────────────

  it('FREE_TRIAL activo con tokens disponibles → eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: futureDate(10),
      trialTokensUsed: 500,
      trialTokensTotal: 10000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-trial')

    expect(result.eligible).toBe(true)
    expect(result.source).toBe('TRIAL')
    expect(result.billingPlan).toBe('FREE_TRIAL')
  })

  it('FREE_TRIAL expirado → no eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: pastDate(5),
      trialTokensUsed: 100,
      trialTokensTotal: 10000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-expired')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/trial.*expirado/i)
  })

  it('FREE_TRIAL con tokens agotados → no eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: futureDate(10),
      trialTokensUsed: 10000,
      trialTokensTotal: 10000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-exhausted')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/tokens.*agotados/i)
  })

  it('FREE_TRIAL sin trialExpiresAt (no se configuró) → eligible mientras haya tokens', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 500,
      trialTokensTotal: 10000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-no-expiry')

    expect(result.eligible).toBe(true)
    expect(result.source).toBe('TRIAL')
  })

  it('FREE_TRIAL sin trialExpiresAt y sin tokens → no eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 10000,
      trialTokensTotal: 10000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-no-expiry-exhausted')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/tokens.*agotados/i)
  })

  // ── PREPAID ───────────────────────────────────────────────────────────────

  it('PREPAID con saldo > 0 → eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'PREPAID',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(10.5),
    })

    const result = await checkBillingEligibility('team-prepaid')

    expect(result.eligible).toBe(true)
    expect(result.source).toBe('QAUTIVA_HOSTED')
    expect(result.billingPlan).toBe('PREPAID')
  })

  it('PREPAID con saldo = 0 → no eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'PREPAID',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-prepaid-empty')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/saldo.*insuficiente/i)
  })

  // ── MONTHLY / YEARLY ──────────────────────────────────────────────────────

  it('MONTHLY con balanceUsd >= 0 → eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'MONTHLY',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-monthly')

    expect(result.eligible).toBe(true)
    expect(result.source).toBe('QAUTIVA_HOSTED')
  })

  it('YEARLY con balanceUsd >= 0 → eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'YEARLY',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(5.0),
    })

    const result = await checkBillingEligibility('team-yearly')

    expect(result.eligible).toBe(true)
    expect(result.source).toBe('QAUTIVA_HOSTED')
    expect(result.billingPlan).toBe('YEARLY')
  })

  // ── MONTHLY / YEARLY con saldo negativo ──────────────────────────────────

  it('MONTHLY con balanceUsd < 0 → no eligible (segunda línea de defensa)', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'MONTHLY',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(-5),
    })

    const result = await checkBillingEligibility('team-monthly-negative')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/sin saldo/i)
  })

  // ── PREPAID con saldo negativo ────────────────────────────────────────────

  it('PREPAID con saldo < 0 → no eligible', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'PREPAID',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(-1.5),
    })

    const result = await checkBillingEligibility('team-prepaid-negative')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/saldo.*insuficiente/i)
  })

  // ── FREE_TRIAL con trialTokensTotal = 0 ─────────────────────────────────

  it('FREE_TRIAL con trialTokensTotal = 0 → no eligible con mensaje de configuración', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: futureDate(30),
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-trial-zero')

    expect(result.eligible).toBe(false)
    // Mensaje diferente a "agotados" — el trial nunca tuvo tokens
    expect(result.reason).toMatch(/no configurado/i)
    expect(result.reason).not.toMatch(/agotados/i)
  })

  // ── FREE_TRIAL: expirado gana sobre tokens agotados ───────────────────────

  it('FREE_TRIAL expirado y tokens agotados → reason de expiración (primero)', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: pastDate(2),
      trialTokensUsed: 10000,
      trialTokensTotal: 10000,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-both-exhausted')

    expect(result.eligible).toBe(false)
    // La expiración se evalúa antes que los tokens agotados
    expect(result.reason).toMatch(/trial.*expirado/i)
    expect(result.reason).not.toMatch(/agotados/i)
  })

  // ── YEARLY con saldo negativo ─────────────────────────────────────────────

  it('YEARLY con balanceUsd < 0 → no eligible (idéntico a MONTHLY)', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'YEARLY',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(-2),
    })

    const result = await checkBillingEligibility('team-yearly-negative')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/sin saldo/i)
  })

  // ── FREE_TRIAL: trialExpiresAt=null + trialTokensTotal=0 ─────────────────

  it('FREE_TRIAL con trialExpiresAt=null y trialTokensTotal=0 → no eligible (no configurado)', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
      trialExpiresAt: null,
      trialTokensUsed: 0,
      trialTokensTotal: 0,
      balanceUsd: toDecimal(0),
    })

    const result = await checkBillingEligibility('team-null-expiry-zero-tokens')

    expect(result.eligible).toBe(false)
    expect(result.reason).toMatch(/no configurado/i)
  })

  // ── Sin BillingAccount ────────────────────────────────────────────────────

  it('sin BillingAccount → lanza error CRITICAL', async () => {
    mockBillingAccountFindUnique.mockResolvedValueOnce(null)

    await expect(checkBillingEligibility('team-no-account')).rejects.toThrow(
      /CRITICAL.*BillingAccount.*no encontrado/i,
    )
  })
})
