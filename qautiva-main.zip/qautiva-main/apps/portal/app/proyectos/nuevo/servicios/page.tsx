import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import ServiciosClient from './client'

export const dynamic = 'force-dynamic'

export default async function ServiciosPage({
  searchParams,
}: {
  searchParams: { pid?: string }
}) {
  const pid = searchParams.pid

  // Redirigir al paso 1 si falta el pid
  if (!pid) redirect('/proyectos/nuevo')

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  // Verificar ownership en una sola query usando join por relación
  const project = await prisma.project.findFirst({
    where: {
      id: pid,
      deletedAt: null,
      team: { members: { some: { user: { authUserId: user.id } } } },
    },
    select: { id: true },
  })

  if (!project) redirect('/proyectos/nuevo')

  return <ServiciosClient projectId={pid} />
}
