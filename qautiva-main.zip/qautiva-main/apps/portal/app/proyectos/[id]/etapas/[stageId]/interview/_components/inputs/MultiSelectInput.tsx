'use client'

import type { QuestionBlock } from '@/app/_lib/interview/types'

export function MultiSelectInput({
  options,
  value,
  onChange,
  disabled,
}: {
  options: NonNullable<QuestionBlock['options']>
  value: string[]
  onChange: (v: unknown) => void
  disabled: boolean
}) {
  if (options.length === 0) {
    return <p className="text-[#64748B] text-sm">No hay opciones configuradas para esta pregunta.</p>
  }

  function toggle(opt: string) {
    onChange(value.includes(opt) ? value.filter((v) => v !== opt) : [...value, opt])
  }

  return (
    <div>
      <div className="flex flex-col gap-2" role="group">
        {options.map((opt) => {
          const selected = value.includes(opt.value)
          return (
            <button
              key={opt.value}
              type="button"
              aria-pressed={selected}
              disabled={disabled}
              onClick={() => toggle(opt.value)}
              className={`w-full text-left px-4 py-3 rounded-lg border transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed ${
                selected
                  ? 'bg-[#8B5CF6]/10 border-[#8B5CF6] text-white'
                  : 'bg-[#0B0F1A] border-[#1E293B] text-[#94A3B8] hover:border-[#334155] hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-4 h-4 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
                    selected ? 'bg-[#8B5CF6] border-[#8B5CF6]' : 'border-[#334155]'
                  }`}
                  aria-hidden="true"
                >
                  {selected && (
                    <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5">
                      <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className="text-sm font-medium">{opt.label}</span>
              </div>
            </button>
          )
        })}
      </div>
      {value.length > 0 && (
        <p className="text-[#64748B] text-xs mt-2">
          {value.length === 1 ? '1 opción seleccionada' : `${value.length} opciones seleccionadas`}
        </p>
      )}
    </div>
  )
}
