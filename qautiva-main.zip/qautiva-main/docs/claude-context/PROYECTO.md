# Qautiva — Contexto del Proyecto

> Documento para iniciar conversaciones con Claude sobre Qautiva.
> Pegalo al inicio de una conversación para dar contexto completo.

---

## Qué es Qautiva

Qautiva es la plataforma de marketing de Q Company. Lanza negocios digitales llave en mano usando agentes de IA: el cliente entra con una idea o negocio existente, interactúa con agentes que producen entregables (brief, estudio de mercado, marca, web, campañas, presencia en medios), y sale con todo funcionando.

**Problema que resuelve:** Emprendedores y negocios que necesitan presencia digital completa (marca, web, campañas, medios) pero no tienen tiempo, dinero ni conocimiento para contratarlo por cuenta propia.

**Idioma:** Español argentino con voseo en toda la UI.
**Moneda:** Pesos argentinos (ARS), formato `$45.000`.
**Modo visual:** Dark mode only (sin toggle de tema).

---

## Las aplicaciones

| App | Subdominio | Propósito | Usuarios |
|-----|-----------|-----------|----------|
| **Landing** | qautiva.ar | Captar clientes, comunicar propuesta de valor, SEO | Visitantes anónimos |
| **Portal del cliente** | app.qautiva.ar | Seguimiento del proceso, aprobación de entregables, métricas, chat | Clientes autenticados |
| **Backoffice admin** | admin.qautiva.ar | Kanban de clientes, cola de revisión, config de agentes IA, gestión bot TG | Administradores |
| **Bot Telegram** | — | Interacción del cliente vía Telegram, respuestas con LLM contextual | Clientes en Telegram |

---

## Modelo de negocio

### Flujo del cliente

1. **Captación** — Visitante llega a la landing (qautiva.ar)
2. **Registro** — Wizard de onboarding self-service en 4 pasos:
   - Paso 1: Sign up (Google OAuth o email)
   - Paso 2: Datos del negocio (nombre, industria, ciudad)
   - Paso 3: Selección de servicios (BRAND / WEBSITE / CAMPAIGNS / MEDIA)
   - Paso 4: Modo IA (Trial gratuito / Hosted prepaid / BYOK con su propia API key)
3. **Generación** — Agentes IA producen entregables (sistema externo, no en este repo)
4. **Revisión** — Cliente aprueba o pide revisión de cada entregable desde el portal
5. **Lanzamiento** — Todo aprobado, negocio digital funcionando

### Planes

| Plan | Servicios | Mensajes bot/mes |
|------|-----------|------------------|
| Base | BRAND + WEBSITE | 50 |
| Completo | + CAMPAIGNS | 200 |
| Premium | + MEDIA | Ilimitado |

---

## Objetivos de negocio

1. **Convertir** visitantes anónimos en clientes pagos (landing)
2. **Retener** clientes con visibilidad del proceso y aprobación de entregables (portal)
3. **Escalar** operaciones sin crecer el equipo humano (admin + automatización IA)

---

## Alcance del repositorio

- ✅ Landing pública con reCAPTCHA v3
- ✅ Portal del cliente (seguimiento, aprobaciones, chat multicanal)
- ✅ Backoffice admin (supervisión, configuración, bot Telegram)
- ✅ Auth con Google OAuth via Supabase Auth
- ✅ Bot de Telegram con LLM contextual
- ❌ Motor de IA / generación de entregables (sistema externo)
- ❌ Integración real con Google Ads / Meta Ads (datos vía API externa)

---

## Comunicación multicanal

Los mensajes del chat web y Telegram se almacenan en la misma tabla `Message` con campo `channel` (WEB | TELEGRAM). Supabase Realtime propaga inserts a todos los canales:

- **Cliente en Telegram** → bot guarda mensaje → llega al portal web y al admin
- **Cliente en chat web** → portal guarda mensaje → llega al admin y al bot
- **Admin interviene** → llega a ambos canales simultáneamente

---

## Restricciones importantes

- Dark mode only — no hay light mode ni toggle
- Español argentino con voseo — toda la UI
- Montos en ARS — formato `$45.000`
- El motor de IA que genera entregables es externo — este repo muestra y gestiona los ya generados
- Google OAuth redirect URIs no soportan wildcards — cada dominio necesita entry manual
- Supabase free tier se pausa tras 7 días — producción requiere Pro ($25/mo)
