import { describe, it, expect, vi, beforeEach } from 'vitest'
vi.mock('next/cache', () => ({ revalidatePath: vi.fn(), revalidateTag: vi.fn() }))
import { NextRequest } from 'next/server'

const mockGetUser = vi.fn()
const mockFindFirst = vi.fn()
const mockUpdate = vi.fn()
const mockStageUpdate = vi.fn()
const mockUserProfileFindUnique = vi.fn()
const mockTransaction = vi.fn()

// Mock @supabase/ssr
vi.mock('@supabase/ssr', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

// Mock next/headers
vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

// Mock @qautiva/db
vi.mock('@qautiva/db', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
  prisma: {
    deliverable: {
      findFirst: mockFindFirst,
      update: mockUpdate,
    },
    userProfile: {
      findUnique: mockUserProfileFindUnique,
    },
    stage: {
      update: mockStageUpdate,
    },
    $transaction: mockTransaction,
  },
}))

function makeRequest(body: unknown, deliverableId = 'del-123'): [NextRequest, { params: { id: string } }] {
  const req = new NextRequest(
    `http://localhost:3001/api/deliverables/${deliverableId}/action`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
  )
  return [req, { params: { id: deliverableId } }]
}

describe('POST /api/deliverables/[id]/action', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetUser.mockReset()
    mockFindFirst.mockReset()
    mockUpdate.mockReset()
    mockStageUpdate.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockTransaction.mockReset()
    // $transaction ejecuta el callback con un tx que tiene los mismos mocks
    mockTransaction.mockImplementation(async (cb: (tx: unknown) => Promise<unknown>) =>
      cb({ deliverable: { update: mockUpdate }, stage: { update: mockStageUpdate } }),
    )
  })

  it('devuelve 401 si no hay usuario autenticado', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: null } })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await POST(req, ctx)

    expect(res.status).toBe(401)
  })

  it('devuelve 403 si el usuario no tiene org ni team memberships', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: {} } },
    })
    // Self-service sin memberships → 403
    mockUserProfileFindUnique.mockResolvedValueOnce({ id: 'p-1', teamMemberships: [] })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await POST(req, ctx)

    expect(res.status).toBe(403)
  })

  it('devuelve 400 si la acción es inválida', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'invalid' })
    const res = await POST(req, ctx)

    expect(res.status).toBe(400)
  })

  it('devuelve 400 al rechazar sin feedback', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'reject', feedback: '   ' })
    const res = await POST(req, ctx)

    expect(res.status).toBe(400)
  })

  it('devuelve 404 si el entregable no pertenece a la org', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })
    mockFindFirst.mockResolvedValueOnce(null)

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await POST(req, ctx)

    expect(res.status).toBe(404)
  })

  it('devuelve 409 si el entregable no está en estado SENT_TO_CLIENT', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })
    mockFindFirst.mockResolvedValueOnce({ id: 'del-123', status: 'CLIENT_APPROVED' })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await POST(req, ctx)

    expect(res.status).toBe(409)
  })

  it('aprueba correctamente un entregable SENT_TO_CLIENT', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })
    mockFindFirst.mockResolvedValueOnce({ id: 'del-123', status: 'SENT_TO_CLIENT' })
    mockUpdate.mockResolvedValueOnce({ id: 'del-123', status: 'CLIENT_APPROVED' })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await POST(req, ctx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(data.status).toBe('CLIENT_APPROVED')
    expect(mockUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'CLIENT_APPROVED' }),
      }),
    )
  })

  it('rechaza correctamente con feedback', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })
    mockFindFirst.mockResolvedValueOnce({ id: 'del-123', status: 'SENT_TO_CLIENT' })
    mockUpdate.mockResolvedValueOnce({ id: 'del-123', status: 'REVISION_REQUESTED' })

    const { POST } = await import('../../app/api/deliverables/[id]/action/route')
    const [req, ctx] = makeRequest({ action: 'reject', feedback: 'Cambiar colores' })
    const res = await POST(req, ctx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.status).toBe('REVISION_REQUESTED')
    expect(mockUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: 'REVISION_REQUESTED',
          feedback: 'Cambiar colores',
        }),
      }),
    )
  })
})
