import type { MetadataRoute } from 'next'
import { getPrisma } from '@/lib/prisma'

export const revalidate = 3600

const BASE_URL = 'https://qapitaliza.com'

const staticRoutes: MetadataRoute.Sitemap = [
  { url: BASE_URL, lastModified: new Date(), changeFrequency: 'daily', priority: 1 },
  { url: `${BASE_URL}/explorar`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.9 },
  { url: `${BASE_URL}/como-funciona`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.7 },
  { url: `${BASE_URL}/login`, lastModified: new Date(), changeFrequency: 'yearly', priority: 0.5 },
  { url: `${BASE_URL}/registro`, lastModified: new Date(), changeFrequency: 'yearly', priority: 0.6 },
]

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  let listingRoutes: MetadataRoute.Sitemap = []

  try {
    const listings = await getPrisma().listing.findMany({
      where: { status: 'PUBLISHED' },
      select: { slug: true, updatedAt: true },
      take: 1000,
    })

    listingRoutes = listings.map((listing) => ({
      url: `${BASE_URL}/explorar/${listing.slug}`,
      lastModified: listing.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.8,
    }))
  } catch (e) {
    // DB unavailable — return only static routes
    console.error('[Sitemap] Failed to fetch listing routes:', e)
  }

  return [...staticRoutes, ...listingRoutes]
}
