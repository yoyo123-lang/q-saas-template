/**
 * Tests de ad-visual-generator.ts
 *
 * Cubre: generación exitosa, degradación parcial (falla 1 pieza en formato con backup),
 * error total (formato sin ninguna pieza), logo disponible vs. no disponible,
 * timeout de budget, regenerateAdVisual.
 *
 * Mocks: Gemini, Supabase Storage (via image-utils).
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { GenerateAdVisualsInput } from '../ad-visual-generator'

// ── Fixtures ──────────────────────────────────────────────────────────────────

const VALID_PNG_B64 = Buffer.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
]).toString('base64')

const BASE_INPUT: GenerateAdVisualsInput = {
  project: { name: 'Qautiva', industry: 'SaaS', country: 'AR' },
  previousDeliverables: [],
  projectId: 'proj-001',
  sessionId: 'sess-abc123',
  brandOptions: null,
}

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockGeminiGenerateContent = vi.fn()
const mockListBuckets = vi.fn()
const mockCreateBucket = vi.fn()
const mockUpload = vi.fn()
const mockCreateSignedUrl = vi.fn()

vi.mock('../gemini-client', () => ({
  getGeminiClient: () => ({
    getGenerativeModel: () => ({
      generateContent: mockGeminiGenerateContent,
    }),
  }),
}))

vi.mock('../ai-config', () => ({
  getGeminiImageModel: async () => 'gemini-2.5-flash-image',
}))

vi.mock('@qautiva/db', () => ({
  createServiceClient: () => ({
    storage: {
      listBuckets: mockListBuckets,
      createBucket: mockCreateBucket,
      from: () => ({
        upload: mockUpload,
        createSignedUrl: mockCreateSignedUrl,
      }),
    },
  }),
}))

// ── Helpers ───────────────────────────────────────────────────────────────────

function geminiSuccess() {
  mockGeminiGenerateContent.mockResolvedValue({
    response: {
      candidates: [
        {
          content: {
            parts: [{ inlineData: { mimeType: 'image/png', data: VALID_PNG_B64 } }],
          },
        },
      ],
    },
  })
}

function storageSuccess() {
  mockListBuckets.mockResolvedValue({ data: [{ name: 'ad-visuals' }], error: null })
  mockUpload.mockResolvedValue({ error: null })
  mockCreateSignedUrl.mockResolvedValue({
    data: { signedUrl: 'https://supabase.io/signed/ad.png?token=abc' },
    error: null,
  })
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('generateAdVisuals', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    const { _resetBucketCacheForTesting } = await import('../image-utils')
    _resetBucketCacheForTesting()
  })

  it('genera 6 piezas cuando Gemini responde correctamente', async () => {
    geminiSuccess()
    storageSuccess()
    const { generateAdVisuals } = await import('../ad-visual-generator')
    const result = await generateAdVisuals(BASE_INPUT)
    expect(result.visuals).toHaveLength(6)
    expect(result.visuals[0]?.imageUrl).toContain('https://supabase.io')
  })

  it('cada pieza tiene format, aspectRatio, resolution, angle, imageUrl, generatedAt', async () => {
    geminiSuccess()
    storageSuccess()
    const { generateAdVisuals } = await import('../ad-visual-generator')
    const result = await generateAdVisuals(BASE_INPUT)
    for (const v of result.visuals) {
      expect(v.format).toMatch(/feed_square|feed_portrait|story/)
      expect(v.aspectRatio).toMatch(/1:1|4:5|9:16/)
      expect(v.angle).toMatch(/hero shot|lifestyle/)
      expect(v.imageUrl).toBeTruthy()
      expect(v.generatedAt).toBeTruthy()
      expect(v.attempt).toBe(1)
    }
  })

  it('incluye brandContext y disclaimer', async () => {
    geminiSuccess()
    storageSuccess()
    const { generateAdVisuals } = await import('../ad-visual-generator')
    const result = await generateAdVisuals(BASE_INPUT)
    expect(result.brandContext.dominantColors.length).toBeGreaterThan(0)
    expect(result.disclaimer.length).toBeGreaterThan(10)
  })

  it('lanza error total si un formato queda sin ninguna pieza', async () => {
    // Gemini falla en todas las llamadas de feed_square (primeras 2 specs)
    // Para un error total, hacemos que todas las llamadas fallen
    mockGeminiGenerateContent.mockRejectedValue(new Error('Gemini quota exceeded'))
    storageSuccess()
    const { generateAdVisuals } = await import('../ad-visual-generator')
    await expect(generateAdVisuals(BASE_INPUT)).rejects.toThrow("sin ninguna pieza exitosa")
  })

  it('acepta degradación parcial si al menos 1 pieza por formato tiene éxito', async () => {
    // Alternamos éxito/fallo: 3 éxitos (1 por formato) + 3 fallos
    let callCount = 0
    mockGeminiGenerateContent.mockImplementation(async () => {
      callCount++
      if (callCount % 2 === 0) throw new Error('transient error')
      return {
        response: {
          candidates: [{
            content: { parts: [{ inlineData: { mimeType: 'image/png', data: VALID_PNG_B64 } }] },
          }],
        },
      }
    })
    storageSuccess()
    const { generateAdVisuals } = await import('../ad-visual-generator')
    const result = await generateAdVisuals(BASE_INPUT)
    expect(result.visuals.length).toBeGreaterThanOrEqual(3)
    expect(result.visuals.length).toBeLessThan(6)
  })
})

// ── Tests: regenerateAdVisual ─────────────────────────────────────────────────

describe('regenerateAdVisual', () => {
  beforeEach(() => vi.clearAllMocks())

  it('devuelve AdVisual con attempt=2 en éxito', async () => {
    geminiSuccess()
    storageSuccess()
    mockListBuckets.mockResolvedValue({ data: [{ name: 'ad-visuals' }], error: null })
    const { regenerateAdVisual } = await import('../ad-visual-generator')
    const result = await regenerateAdVisual('feed_square-hero shot', BASE_INPUT)
    expect(result).not.toBeNull()
    expect(result?.attempt).toBe(2)
    expect(result?.format).toBe('feed_square')
    expect(result?.angle).toBe('hero shot')
  })

  it('devuelve null si el visualId no coincide con ningún spec', async () => {
    geminiSuccess()
    storageSuccess()
    const { regenerateAdVisual } = await import('../ad-visual-generator')
    const result = await regenerateAdVisual('formato_inexistente-angle_raro', BASE_INPUT)
    expect(result).toBeNull()
  })

  it('devuelve null si Gemini falla en la regeneración', async () => {
    mockGeminiGenerateContent.mockRejectedValue(new Error('Gemini down'))
    storageSuccess()
    mockListBuckets.mockResolvedValue({ data: [{ name: 'ad-visuals' }], error: null })
    const { regenerateAdVisual } = await import('../ad-visual-generator')
    const result = await regenerateAdVisual('story-lifestyle', BASE_INPUT)
    expect(result).toBeNull()
  })
})
