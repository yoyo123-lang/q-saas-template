/**
 * Helper de auditoría para el panel admin.
 *
 * logAudit() es fire-and-forget: nunca bloquea al caller ni propaga errores.
 * Si el registro falla (p.ej. timeout de DB), se loguea en consola pero la
 * acción principal ya habrá completado. Esto es intencional: una falla de
 * auditoría no debe deshacer una configuración legítima del admin.
 */

import { prisma } from '@qautiva/db'
import type { AuditAction } from '@qautiva/db'

type LogAuditParams = {
  userId: string
  action: AuditAction
  targetEntity: string
  targetId: string
  previousState?: unknown
  newState?: unknown
  reason?: string
  metadata?: unknown
}

/**
 * Registra una acción auditada de forma asíncrona (fire-and-forget).
 * Llamar después de que la acción principal haya completado con éxito.
 */
export function logAudit(params: LogAuditParams): void {
  prisma.auditLog
    .create({
      data: {
        userId: params.userId,
        action: params.action,
        targetEntity: params.targetEntity,
        targetId: params.targetId,
        previousState: params.previousState ?? undefined,
        newState: params.newState ?? undefined,
        reason: params.reason ?? null,
        metadata: params.metadata ?? undefined,
      },
    })
    .catch((err: unknown) => {
      // Loguear con contexto suficiente para debugging, sin relanzar.
      console.error(
        `[audit] FALLO al registrar acción — action=${params.action} entity=${params.targetEntity} id=${params.targetId}:`,
        err,
      )
    })
}
