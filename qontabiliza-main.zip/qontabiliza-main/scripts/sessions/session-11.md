# Sesión 11: QA, polish y deploy

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 11
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Tests E2E de flujos críticos, revisión de seguridad, optimización de performance, preparar para producción.

## Pre-requisitos

Todas las sesiones anteriores completadas.

## Etapas

### Etapa 1: Tests E2E
- Flujo completo: crear org → crear producto → crear cliente → emitir factura → registrar venta
- Test de multi-tenancy: verificar que tenant A no ve datos de tenant B
- Test de POS: buscar producto → agregar al carrito → cobrar → verificar stock descontado
- Test de onboarding: registro → crear org → wizard completo

### Etapa 2: Revisión de seguridad
- Tenant isolation: verificar en TODAS las queries que filtran por tenantId
- Validación de inputs: revisar que todos los endpoints validan con Zod
- Rate limiting en endpoints públicos y de autenticación
- Headers de seguridad (CSP, HSTS, etc.)
- Revisar que no hay secretos hardcodeados

### Etapa 3: Performance
- Índices de DB: revisar queries lentas, agregar índices donde falten
- Lazy loading de componentes pesados (POS, reportes, gráficos)
- Optimistic updates en POS para UX rápida
- Verificar que no hay N+1 queries

### Etapa 4: Preparar para producción
- Landing page pública simple (features, precios, CTA de registro)
- Variables de entorno documentadas en .env.example
- Seeds de producción (planes, categorías default)
- Verificar que npm run build produce un bundle limpio
- Documentar proceso de deploy

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
