'use client'

import { useState, type FormEvent } from 'react'
import { getRecaptchaToken } from '@/lib/recaptcha'

type FormState = 'idle' | 'loading' | 'success' | 'error'

interface FormFields {
  name: string
  email: string
  business: string
}

function ContactForm() {
  const [state, setState] = useState<FormState>('idle')
  const [errorMessage, setErrorMessage] = useState('')
  const [fields, setFields] = useState<FormFields>({ name: '', email: '', business: '' })

  function updateField(key: keyof FormFields) {
    return (e: React.ChangeEvent<HTMLInputElement>) => {
      setFields((prev) => ({ ...prev, [key]: e.target.value }))
    }
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setState('loading')
    setErrorMessage('')

    try {
      const recaptchaToken = await getRecaptchaToken('contact')

      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...fields, recaptchaToken }),
      })

      const data = (await response.json()) as { ok?: boolean; error?: string }

      if (!response.ok) {
        setState('error')
        setErrorMessage(data.error ?? 'Hubo un problema. Intentá de nuevo.')
        return
      }

      setState('success')
    } catch {
      setState('error')
      setErrorMessage('No pudimos enviar tu mensaje. Revisá tu conexión e intentá de nuevo.')
    }
  }

  if (state === 'success') {
    return (
      <div className="text-center py-8">
        <p className="text-emerald-400 font-semibold text-lg mb-2">
          ¡Gracias! Te contactamos pronto.
        </p>
        <p className="text-slate-400 text-sm">Respondemos en menos de 24 horas.</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-md mx-auto">
      <input
        type="text"
        placeholder="Tu nombre"
        value={fields.name}
        onChange={updateField('name')}
        required
        maxLength={100}
        disabled={state === 'loading'}
        className="bg-navy-800 border border-navy-800 focus:border-accent-light text-white placeholder-slate-500 rounded-lg px-4 py-3 text-sm outline-none transition-colors duration-200 disabled:opacity-50"
      />
      <input
        type="email"
        placeholder="tu@email.com"
        value={fields.email}
        onChange={updateField('email')}
        required
        maxLength={200}
        disabled={state === 'loading'}
        className="bg-navy-800 border border-navy-800 focus:border-accent-light text-white placeholder-slate-500 rounded-lg px-4 py-3 text-sm outline-none transition-colors duration-200 disabled:opacity-50"
      />
      <input
        type="text"
        placeholder="Tu negocio o idea"
        value={fields.business}
        onChange={updateField('business')}
        required
        maxLength={500}
        disabled={state === 'loading'}
        className="bg-navy-800 border border-navy-800 focus:border-accent-light text-white placeholder-slate-500 rounded-lg px-4 py-3 text-sm outline-none transition-colors duration-200 disabled:opacity-50"
      />

      {state === 'error' && (
        <p className="text-red-400 text-sm text-center">{errorMessage}</p>
      )}

      <button
        type="submit"
        disabled={state === 'loading'}
        className="bg-accent hover:bg-accent-light text-white font-semibold py-3 rounded-lg transition-colors duration-200 disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {state === 'loading' ? 'Enviando...' : 'Hablá con nosotros'}
      </button>
    </form>
  )
}

export function Pricing() {
  return (
    <section
      id="precios"
      className="bg-navy-900 py-20 md:py-24"
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Cada negocio es diferente
          </h2>
          <p className="text-slate-400 text-lg max-w-lg mx-auto">
            Contanos tu proyecto y te armamos una propuesta a medida.
          </p>
          <p className="text-accent font-semibold mt-4 text-lg">
            Desde $500 USD — pagás cuando ves resultados
          </p>
        </div>

        <ContactForm />

        <div className="flex justify-center gap-6 mt-8">
          <span className="text-slate-500 text-sm">Sin compromiso</span>
          <span className="text-slate-600" aria-hidden="true">·</span>
          <span className="text-slate-500 text-sm">Respuesta en 24hs</span>
          <span className="text-slate-600" aria-hidden="true">·</span>
          <span className="text-slate-500 text-sm">100% online</span>
        </div>
      </div>
    </section>
  )
}
