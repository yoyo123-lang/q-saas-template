import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma, Prisma } from '@qautiva/db'
import { getNextQuestion } from '@/app/_lib/interview/ai-interviewer'
import { getAgentNumberForStage } from '@/app/_lib/interview/merge-flow'
import { getUserTeamIds } from '@/app/_lib/interview/get-user-team-ids'
import type { QuestionBlock } from '@/app/_lib/interview/types'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

type NextQuestionBody = {
  /** ID de la pregunta que el usuario acaba de responder (null en la primera llamada) */
  questionId?: string
  /** Respuesta del usuario a la pregunta anterior */
  answer?: unknown
}

/**
 * POST /api/interview/sessions/[id]/next-question
 *
 * Para entrevistas conversacionales (El Estratega, agente 1).
 * Guarda la respuesta a la pregunta actual y pide a Claude la siguiente.
 *
 * Primera llamada (sin respuesta previa):
 *   Body: {} o { questionId: undefined, answer: undefined }
 *   → Claude genera la primera pregunta
 *
 * Llamadas siguientes:
 *   Body: { questionId: "neg_descripcion", answer: "Vendemos..." }
 *   → Guarda la respuesta, Claude genera la siguiente pregunta o señala fin
 *
 * Respuestas:
 *   { ok: true, question: QuestionBlock }           — mostrar la pregunta al usuario
 *   { ok: true, complete: true }                    — entrevista terminada (sesión → PROCESSING)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  // CRÍTICO-SEC: validar UUID antes de queries
  if (
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)
  ) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  let body: NextQuestionBody
  try {
    body = (await request.json()) as NextQuestionBody
  } catch {
    body = {}
  }

  const { questionId, answer } = body

  // Verificar ownership
  const teamIds = await getUserTeamIds(user.id)
  if (!teamIds) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const session = await prisma.interviewSession.findFirst({
    where: {
      id: params.id,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: {
      id: true,
      teamId: true,
      status: true,
      currentStep: true,
      flowDefinition: true,
      answers: true,
      answersVersion: true,
      stage: {
        select: {
          number: true,
          stageKey: true,
        },
      },
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Fail-closed: verificar teamId antes de cualquier guard
  if (!session.teamId) {
    console.error('[next-question] session sin teamId — error de datos, bloqueando ejecución', {
      sessionId: params.id,
    })
    return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
  }

  // Guard de permisos: MEMBER solo tiene lectura — generar preguntas consume billing
  const perm = await checkTeamPermission(user.id, session.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden ejecutar esta operación.' },
      { status: 403 },
    )
  }

  if (!['IN_PROGRESS', 'NOT_STARTED'].includes(session.status)) {
    return NextResponse.json(
      { error: `No se puede hacer preguntas en estado ${session.status}` },
      { status: 409 },
    )
  }

  // Cargar el prompt de El Estratega
  const agentNumber = getAgentNumberForStage(
    session.stage.stageKey,
    session.stage.number,
  )
  const agentConfig = await prisma.agentConfig.findUnique({
    where: { agentNumber },
    select: { interviewPrompt: true },
  })

  if (!agentConfig?.interviewPrompt) {
    console.error('[next-question] AgentConfig no encontrado', { agentNumber, sessionId: params.id })
    return NextResponse.json(
      { error: 'Configuración del agente no disponible' },
      { status: 500 },
    )
  }

  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const currentAnswers = (session.answers ?? {}) as Record<string, unknown>

  // ── Guardar la respuesta a la pregunta anterior ──────────────────────────────

  let updatedAnswers = currentAnswers
  let updatedAnswersVersion = session.answersVersion

  if (questionId && answer !== undefined && answer !== null) {
    // Validar formato de questionId
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(questionId)) {
      return NextResponse.json({ error: 'questionId inválido' }, { status: 400 })
    }

    // Validar tipo y tamaño de la respuesta
    if (typeof answer === 'string') {
      if (answer.trim().length === 0) {
        return NextResponse.json({ error: 'La respuesta no puede estar vacía' }, { status: 400 })
      }
      if (answer.length > 5000) {
        return NextResponse.json(
          { error: 'Respuesta demasiado larga (máximo 5000 caracteres)' },
          { status: 400 },
        )
      }
    } else if (Array.isArray(answer)) {
      if (answer.length > 50) {
        return NextResponse.json({ error: 'Demasiadas opciones seleccionadas (máximo 50)' }, { status: 400 })
      }
      if (!answer.every((item) => typeof item === 'string')) {
        return NextResponse.json({ error: 'Tipo de respuesta no permitido' }, { status: 400 })
      }
    } else if (typeof answer !== 'number') {
      return NextResponse.json({ error: 'Tipo de respuesta no permitido' }, { status: 400 })
    }

    const newAnswers = { ...currentAnswers, [questionId]: answer }

    try {
      const saved = await prisma.interviewSession.update({
        where: { id: params.id, answersVersion: session.answersVersion },
        data: {
          answers: newAnswers as Prisma.InputJsonValue,
          answersVersion: { increment: 1 },
          // Auto-transición si era NOT_STARTED
          ...(session.status === 'NOT_STARTED'
            ? { status: 'IN_PROGRESS', startedAt: new Date() }
            : {}),
        },
        select: { answers: true, answersVersion: true },
      })
      updatedAnswers = saved.answers as Record<string, unknown>
      updatedAnswersVersion = saved.answersVersion
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
        return NextResponse.json(
          {
            error: 'Tus respuestas se actualizaron en otra pestaña. Por favor recargá la página.',
            code: 'VERSION_CONFLICT',
          },
          { status: 409 },
        )
      }
      console.error('[next-question] save answer failed', {
        sessionId: params.id,
        questionId,
        error: err instanceof Error ? err.message : String(err),
      })
      return NextResponse.json({ error: 'Error al guardar la respuesta' }, { status: 500 })
    }
  }

  // ── Filtrar preguntas sin respuesta (compatibilidad con sesiones antiguas) ────
  // Sesiones creadas con el formato viejo pueden tener preguntas estáticas en
  // flowDefinition que nunca fueron respondidas. Usamos solo las respondidas para
  // que buildMessages nunca emita tool_use sin tool_result (Anthropic lo rechaza).

  const effectiveFlow = flowDefinition.filter((q) => updatedAnswers[q.id] !== undefined)

  // ── Límite de preguntas — previene crecimiento ilimitado de tokens ───────────

  const MAX_QUESTIONS = 15
  if (effectiveFlow.length >= MAX_QUESTIONS) {
    try {
      await prisma.interviewSession.update({
        where: { id: params.id, status: 'IN_PROGRESS' },
        data: { status: 'PROCESSING' },
      })
    } catch {
      // Ignorar si ya estaba en PROCESSING
    }
    return NextResponse.json({ ok: true, complete: true })
  }

  // ── Resume: devolver la última pregunta no respondida (ej: usuario recargó la página) ──
  // Usamos effectiveFlow para evitar devolver preguntas estáticas del formato viejo.

  const lastQuestion = effectiveFlow.length > 0 ? effectiveFlow[effectiveFlow.length - 1] : null
  const lastQuestionAnswered = lastQuestion ? updatedAnswers[lastQuestion.id] !== undefined : true

  if (lastQuestion && !lastQuestionAnswered && !questionId) {
    // La última pregunta ya fue enviada al usuario pero no tiene respuesta aún.
    // Se la devolvemos sin llamar a Claude (evita mensajes inválidos en el historial).
    return NextResponse.json({ ok: true, question: lastQuestion })
  }

  // ── Llamar a Claude para obtener la próxima pregunta ─────────────────────────

  let aiResult
  try {
    aiResult = await getNextQuestion(
      agentConfig.interviewPrompt,
      effectiveFlow,
      updatedAnswers,
    )
  } catch (err) {
    console.error('[next-question] AI call failed', {
      sessionId: params.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json(
      { error: 'No se pudo obtener la próxima pregunta. Intentá de nuevo.' },
      { status: 502 },
    )
  }

  // ── Entrevista completa ───────────────────────────────────────────────────────

  if (aiResult.type === 'complete') {
    try {
      await prisma.interviewSession.update({
        where: { id: params.id, status: 'IN_PROGRESS' },
        data: { status: 'PROCESSING' },
      })
    } catch (err) {
      // Si ya estaba en PROCESSING (llamada duplicada), ignorar
      if (!(err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025')) {
        console.error('[next-question] transition to PROCESSING failed', {
          sessionId: params.id,
          error: err instanceof Error ? err.message : String(err),
        })
      }
    }

    return NextResponse.json({ ok: true, complete: true })
  }

  // ── Nueva pregunta generada por Claude ───────────────────────────────────────

  // Deduplicar ID si Claude reutilizó uno ya existente
  const newBlock = { ...aiResult.block }
  const existingIds = new Set(effectiveFlow.map((q) => q.id))
  if (existingIds.has(newBlock.id)) {
    let suffix = 2
    while (existingIds.has(`${newBlock.id}_${suffix}`)) suffix++
    newBlock.id = `${newBlock.id}_${suffix}`
  }

  const newFlowDefinition = [...effectiveFlow, newBlock]
  const newStep = newFlowDefinition.length - 1

  try {
    await prisma.interviewSession.update({
      where: { id: params.id, answersVersion: updatedAnswersVersion },
      data: {
        flowDefinition: newFlowDefinition as unknown as Prisma.InputJsonValue,
        currentStep: newStep,
        totalSteps: newFlowDefinition.length,
        // Auto-transición si era NOT_STARTED y no se guardó respuesta antes
        ...(session.status === 'NOT_STARTED' && !questionId
          ? { status: 'IN_PROGRESS', startedAt: new Date() }
          : {}),
      },
    })
  } catch (err) {
    // Si answersVersion cambió entre el save y este update, intentar con la versión actual
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      // Igualmente devolvemos la pregunta — el flowDefinition se actualizará en el próximo save
      console.warn('[next-question] flowDefinition update conflict, returning question anyway', {
        sessionId: params.id,
      })
    } else {
      console.error('[next-question] flowDefinition update failed', {
        sessionId: params.id,
        error: err instanceof Error ? err.message : String(err),
      })
      return NextResponse.json({ error: 'Error al guardar la pregunta' }, { status: 500 })
    }
  }

  return NextResponse.json({ ok: true, question: newBlock })
}
