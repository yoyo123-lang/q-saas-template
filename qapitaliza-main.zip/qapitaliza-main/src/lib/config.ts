/**
 * Validación temprana de variables de entorno requeridas.
 * Falla con un mensaje claro al iniciar en lugar de un crash críptico en runtime.
 *
 * Importar este módulo desde lugares que necesiten las vars (lib/supabase, lib/prisma, etc.)
 * para garantizar que el error se detecta al arrancar, no en la primera request.
 */

function requireEnv(name: string): string {
  const value = process.env[name]
  if (!value) {
    throw new Error(
      `[config] Variable de entorno requerida no está configurada: "${name}". ` +
        `Copiá .env.example a .env.local y completá los valores.`
    )
  }
  return value
}

// Solo se evalúan en runtime (no en build time), así que no rompen el build
// cuando las vars no están seteadas en el entorno de CI/CD de build.
export function getSupabaseConfig() {
  // IMPORTANTE: NEXT_PUBLIC_* vars se reemplazan en build time SOLO con acceso estático.
  // No usar requireEnv() (acceso dinámico via process.env[name]) para estas vars
  // porque Next.js no las inlinea en el bundle del cliente.
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!url) {
    throw new Error(
      '[config] Variable de entorno requerida no está configurada: "NEXT_PUBLIC_SUPABASE_URL". ' +
        'Copiá .env.example a .env.local y completá los valores.'
    )
  }
  if (!anonKey) {
    throw new Error(
      '[config] Variable de entorno requerida no está configurada: "NEXT_PUBLIC_SUPABASE_ANON_KEY". ' +
        'Copiá .env.example a .env.local y completá los valores.'
    )
  }

  return { url, anonKey }
}
