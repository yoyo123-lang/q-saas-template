# Plan: Herramientas de debug para Stitch (cola + generación individual)

## Objetivo

Agregar visibilidad al pipeline de generación de Stitch para poder diagnosticar rápidamente por qué los jobs fallan o quedan atascados, tanto en la cola como en generación individual. Hoy los errores solo viven en Vercel logs (que rotan); queremos persistirlos y exponerlos.

## Etapa 1: Modelo de datos — campo `queueError`

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 1.1 | Agregar campo `queueError String? @db.Text` a `WebTemplate` en el schema de Prisma | `packages/db/prisma/schema.prisma` | `pnpm --filter @qautiva/db exec prisma validate` | ✅ |
| 1.2 | Generar y aplicar la migración de Prisma | `packages/db/prisma/migrations/*/` | `pnpm --filter @qautiva/db exec prisma migrate dev --name add-queue-error` | ✅ |

**Checkpoint de etapa:** El schema tiene el campo `queueError` y la migración se aplica sin errores.

## Etapa 2: Persistir errores en generación por cola

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 2.1 | En el cron `process-stitch-queue`, guardar `queueError` con el motivo específico en cada path de error (`processStitchHtml.reason`, `handlebars.error`, excepción genérica), y loguear los primeros 500 chars del HTML cuando falla `processStitchHtml` | `apps/admin/app/api/cron/process-stitch-queue/route.ts` | Build compila | ✅ |
| 2.2 | En el endpoint `queue/[id]/run`, guardar `queueError` con el motivo específico en cada path de error (misma lógica que 2.1) | `apps/admin/app/api/stitch/queue/[id]/run/route.ts` | Build compila | ✅ |
| 2.3 | Limpiar `queueError` a `null` al inicio de cada generación (cuando se marca GENERATING) en ambos archivos, para que un retry exitoso borre el error anterior | `apps/admin/app/api/cron/process-stitch-queue/route.ts`, `apps/admin/app/api/stitch/queue/[id]/run/route.ts` | Build compila | ✅ |

**Checkpoint de etapa:** Cuando un job de cola falla, `queueError` queda con el motivo. Cuando se reintenta, se limpia.

## Etapa 3: Persistir errores en generación individual

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 3.1 | En `generate/route.ts`, guardar `queueError` con el motivo específico en cada path de error de `runGeneration`, y loguear HTML snippet en fallo de processStitchHtml | `apps/admin/app/api/stitch/generate/route.ts` | Build compila | ✅ |
| 3.2 | En `generate/status/route.ts`, incluir `queueError` en la respuesta cuando `status === 'error'` | `apps/admin/app/api/stitch/generate/status/route.ts` | Build compila | ✅ |
| 3.3 | En `StitchGenerator.tsx`, mostrar el error detallado del status endpoint en lugar del genérico "Error al generar el template" | `apps/admin/app/(protected)/templates/nuevo/_components/StitchGenerator.tsx` | Build compila | ✅ |

**Checkpoint de etapa:** La generación individual muestra el motivo real del error en la UI.

## Etapa 4: Logging estructurado en el cron

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 4.1 | Agregar `console.info` en cada path de skip del cron (cola pausada, job GENERATING activo, sin créditos, no hay jobs) con el motivo | `apps/admin/app/api/cron/process-stitch-queue/route.ts` | Build compila | ✅ |
| 4.2 | Al inicio del cron (después de auth), loguear resumen de estado de la cola (conteo QUEUED/GENERATING/ERROR/DONE) y estado de cuentas (label, usedToday/dailyLimit) | `apps/admin/app/api/cron/process-stitch-queue/route.ts` | Build compila | ✅ |

**Checkpoint de etapa:** Cada ejecución del cron deja trazas claras en Vercel logs de qué hizo y por qué.

## Etapa 5: Endpoint de diagnóstico de cola

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 5.1 | Crear endpoint `GET /api/stitch/queue/debug` que retorne: conteo de jobs por estado, estado de cuentas (label, usedToday, dailyLimit, active), si la cola está pausada, jobs zombies en GENERATING con lock expirado, y los últimos 5 jobs en ERROR con su `queueError` | `apps/admin/app/api/stitch/queue/debug/route.ts` | Build compila | ✅ |

**Checkpoint de etapa:** Un solo GET devuelve toda la foto del sistema para diagnosticar sin Vercel logs.

## Etapa 6: Mostrar `queueError` en la UI de cola

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 6.1 | En el GET de `/api/stitch/queue`, incluir `queueError` en el select de jobs | `apps/admin/app/api/stitch/queue/route.ts` | Build compila | ✅ |
| 6.2 | En `JobsTable.tsx`, mostrar `queueError` como tooltip o texto debajo del badge ERROR | `apps/admin/app/(protected)/templates/cola/_components/JobsTable.tsx` | Build compila | ✅ |

**Checkpoint de etapa:** En la página de cola, los items ERROR muestran por qué fallaron.

## Etapa 7: Build, verificación y push

### Tareas

| # | Tarea | Archivos | Verificación | Estado |
|---|-------|----------|-------------|--------|
| 7.1 | Correr `pnpm run build` completo y arreglar cualquier error | — | `pnpm run build` exitoso | ✅ |
| 7.2 | Push al branch `claude/debug-stitch-queue-jkfhv` | — | `git push` exitoso | ✅ |

**Checkpoint de etapa:** Todo compila y está pusheado.

## Cosas que NO se van a tocar

- No se agrega retry automático (primero necesitamos entender los errores)
- No se guarda el HTML crudo completo de Stitch en DB (muy grande, solo snippet en logs)
- No se cambia la lógica de procesamiento de Stitch (processStitchHtml, validateHandlebars)
- No se modifica el endpoint de diagnostics existente (`/api/stitch/diagnostics`)
- No se toca el flujo de Factory ni el flujo de guardado (`generate/save`)

## Riesgos

- La migración de Prisma necesita que la DB esté accesible desde el entorno local. Si no lo está, la migración se genera pero no se aplica (se aplica en deploy).
- El campo `queueError` es nullable y `@db.Text`, no debería haber problemas de compatibilidad con datos existentes.
