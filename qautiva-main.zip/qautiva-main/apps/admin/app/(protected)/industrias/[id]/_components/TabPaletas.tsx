'use client'

import { useState } from 'react'
import { updateColorPalettes } from '../../actions'
import type { ActionState } from '../../actions'

type ColorPalette = {
  name: string
  colors: string[]
}

const MAX_COLORS_PER_PALETTE = 5

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar paletas'}
    </button>
  )
}

function createEmptyPalette(): ColorPalette {
  return { name: '', colors: ['#8B5CF6'] }
}

interface PaletteEditorProps {
  palette: ColorPalette
  index: number
  onUpdate: (index: number, palette: ColorPalette) => void
  onRemove: (index: number) => void
}

function PaletteEditor({ palette, index, onUpdate, onRemove }: PaletteEditorProps) {
  function updateName(name: string) {
    onUpdate(index, { ...palette, name })
  }

  function updateColor(colorIndex: number, color: string) {
    const next = [...palette.colors]
    next[colorIndex] = color
    onUpdate(index, { ...palette, colors: next })
  }

  function addColor() {
    if (palette.colors.length >= MAX_COLORS_PER_PALETTE) return
    onUpdate(index, { ...palette, colors: [...palette.colors, '#ffffff'] })
  }

  function removeColor(colorIndex: number) {
    onUpdate(index, { ...palette, colors: palette.colors.filter((_, i) => i !== colorIndex) })
  }

  return (
    <div className="border border-[#1E293B] rounded-lg p-4 bg-[#0B0F1A] flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <input
          type="text"
          value={palette.name}
          onChange={(e) => updateName(e.target.value)}
          placeholder="Nombre de la paleta..."
          maxLength={100}
          className="flex-1 px-3 py-2 bg-[#0F172A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
        />
        <button
          type="button"
          onClick={() => onRemove(index)}
          className="text-red-400 hover:text-red-300 text-sm px-2 transition-colors"
          aria-label="Eliminar paleta"
        >
          × Eliminar
        </button>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {palette.colors.map((color, colorIdx) => (
          <div key={colorIdx} className="flex flex-col items-center gap-1">
            <input
              type="color"
              value={color}
              onChange={(e) => updateColor(colorIdx, e.target.value)}
              className="w-10 h-10 rounded cursor-pointer border border-[#1E293B] bg-transparent"
              aria-label={`Color ${colorIdx + 1}`}
            />
            <button
              type="button"
              onClick={() => removeColor(colorIdx)}
              className="text-[#64748B] hover:text-red-400 text-xs transition-colors"
              aria-label={`Eliminar color ${colorIdx + 1}`}
            >
              ×
            </button>
          </div>
        ))}

        {palette.colors.length < MAX_COLORS_PER_PALETTE && (
          <button
            type="button"
            onClick={addColor}
            className="w-10 h-10 rounded border border-dashed border-[#334155] text-[#64748B] hover:text-white hover:border-[#475569] transition-colors flex items-center justify-center text-lg"
            aria-label="Agregar color"
          >
            +
          </button>
        )}
      </div>
    </div>
  )
}

interface TabPaletasProps {
  industryId: string
  colorPalettes: ColorPalette[]
}

export function TabPaletas({ industryId, colorPalettes: initialPalettes }: TabPaletasProps) {
  const [palettes, setPalettes] = useState<ColorPalette[]>(initialPalettes)
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  function updatePalette(index: number, updated: ColorPalette) {
    setPalettes((prev) => prev.map((p, i) => (i === index ? updated : p)))
  }

  function removePalette(index: number) {
    setPalettes((prev) => prev.filter((_, i) => i !== index))
  }

  function addPalette() {
    setPalettes((prev) => [...prev, createEmptyPalette()])
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', industryId)
    formData.set('colorPalettes', JSON.stringify(palettes))
    try {
      const result = await updateColorPalettes(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-4">
      {palettes.length === 0 && (
        <div className="border border-[#1E293B] rounded-lg p-8 text-center">
          <p className="text-[#64748B] text-sm">Sin paletas todavía. Agregá la primera.</p>
        </div>
      )}

      {palettes.map((palette, idx) => (
        <PaletteEditor
          key={idx}
          palette={palette}
          index={idx}
          onUpdate={updatePalette}
          onRemove={removePalette}
        />
      ))}

      <button
        type="button"
        onClick={addPalette}
        className="self-start text-sm text-[#8B5CF6] hover:text-[#A78BFA] transition-colors"
      >
        + Agregar paleta
      </button>

      <div className="flex items-center gap-3 pt-2 border-t border-[#1E293B]">
        <SaveButton pending={isPending} />
        {state && (
          state.ok
            ? <p className="text-sm text-green-400">Guardado correctamente.</p>
            : <p className="text-sm text-red-400">{state.error}</p>
        )}
      </div>
    </form>
  )
}
