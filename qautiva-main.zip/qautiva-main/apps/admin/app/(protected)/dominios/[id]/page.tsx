import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import type { DomainStatus } from '@qautiva/db'

export const metadata: Metadata = { title: 'Detalle de dominio | Qautiva Admin' }
export const dynamic = 'force-dynamic'

// ── Helpers ──────────────────────────────────────────────────────────────────

const STATUS_BADGE: Record<DomainStatus, { label: string; className: string }> = {
  ACTIVE:          { label: 'Activo',         className: 'bg-[#10B981]/15 text-[#10B981]' },
  PENDING_PAYMENT: { label: 'Pago pendiente', className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  PENDING:         { label: 'Pendiente',       className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  REGISTERING:     { label: 'Registrando',     className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  RENEWAL_DUE:     { label: 'Renovación próx.', className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  FAILED:          { label: 'Fallido',         className: 'bg-[#EF4444]/15 text-[#F87171]' },
  EXPIRED:         { label: 'Expirado',        className: 'bg-[#EF4444]/15 text-[#F87171]' },
  CANCELLED:       { label: 'Cancelado',       className: 'bg-[#64748B]/15 text-[#94A3B8]' },
}

const TX_STATUS_BADGE: Record<string, { label: string; className: string }> = {
  SUCCESS: { label: 'Exitosa',  className: 'bg-[#10B981]/15 text-[#10B981]' },
  FAILED:  { label: 'Fallida',  className: 'bg-[#EF4444]/15 text-[#F87171]' },
  PENDING: { label: 'Pendiente', className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
}

// ── Data ─────────────────────────────────────────────────────────────────────

async function getDomain(id: string) {
  return prisma.domain.findUnique({
    where: { id },
    select: {
      id: true,
      domainName: true,
      tld: true,
      status: true,
      teamId: true,
      period: true,
      costUsd: true,
      paidAmountArs: true,
      exchangeRate: true,
      registeredAt: true,
      expiresAt: true,
      autoRenew: true,
      whoisPrivacy: true,
      opensrsOrderId: true,
      opensrsDomainId: true,
      retryCount: true,
      lastError: true,
      registrantInfo: true,
      transactions: {
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          operation: true,
          status: true,
          responseCode: true,
          responseText: true,
          durationMs: true,
          errorMessage: true,
          createdAt: true,
        },
      },
    },
  })
}

// ── Field row ─────────────────────────────────────────────────────────────────

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[#64748B] text-xs">{label}</span>
      <span className="text-[#F8FAFC] text-sm">{value ?? '—'}</span>
    </div>
  )
}

// ── Page ─────────────────────────────────────────────────────────────────────

interface PageProps {
  params: { id: string }
}

export default async function DomainDetailPage({ params }: PageProps) {
  const domain = await getDomain(params.id)
  if (!domain) notFound()

  const badge = STATUS_BADGE[domain.status] ?? { label: domain.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }

  const registrant = domain.registrantInfo as Record<string, string> | null

  return (
    <div className="flex flex-col p-6 gap-6 max-w-5xl">
      {/* Back link */}
      <Link
        href="/dominios"
        className="text-[#64748B] hover:text-white text-sm transition-colors w-fit"
      >
        ← Volver a dominios
      </Link>

      {/* Header */}
      <div className="flex items-center gap-3">
        <h1 className="text-white text-xl font-bold font-mono">
          {domain.domainName}.{domain.tld}
        </h1>
        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
          {badge.label}
        </span>
      </div>

      {/* General info */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-5">
        <h2 className="text-[#F8FAFC] text-sm font-semibold mb-4">Información general</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <Field label="Team ID" value={<span className="font-mono text-xs">{domain.teamId}</span>} />
          <Field label="Período" value={`${domain.period} año${domain.period !== 1 ? 's' : ''}`} />
          <Field label="Costo USD" value={`$${Number(domain.costUsd).toLocaleString('es-AR', { minimumFractionDigits: 2 })}`} />
          <Field label="Pagado ARS" value={domain.paidAmountArs ? `$${Number(domain.paidAmountArs).toLocaleString('es-AR')}` : null} />
          <Field label="Tipo de cambio" value={domain.exchangeRate ? Number(domain.exchangeRate).toLocaleString('es-AR') : null} />
          <Field label="Auto-renovación" value={domain.autoRenew ? 'Sí' : 'No'} />
          <Field label="Privacidad Whois" value={domain.whoisPrivacy ? 'Sí' : 'No'} />
          <Field label="OpenSRS Order ID" value={domain.opensrsOrderId ?? null} />
          <Field label="OpenSRS Domain ID" value={domain.opensrsDomainId ?? null} />
          <Field label="Registrado el" value={domain.registeredAt ? domain.registeredAt.toLocaleDateString('es-AR') : null} />
          <Field label="Expira el" value={domain.expiresAt ? domain.expiresAt.toLocaleDateString('es-AR') : null} />
          <Field label="Intentos" value={domain.retryCount} />
        </div>
        {domain.lastError && (
          <div className="mt-4 p-3 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/20">
            <p className="text-xs text-[#64748B] mb-1">Último error</p>
            <p className="text-[#F87171] text-sm font-mono">{domain.lastError}</p>
          </div>
        )}
      </section>

      {/* Registrant info */}
      {registrant && Object.keys(registrant).length > 0 && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-5">
          <h2 className="text-[#F8FAFC] text-sm font-semibold mb-4">Datos del registrante</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {registrant.firstName   && <Field label="Nombre"      value={registrant.firstName} />}
            {registrant.lastName    && <Field label="Apellido"    value={registrant.lastName} />}
            {registrant.email       && <Field label="Email"       value={registrant.email} />}
            {registrant.orgName     && <Field label="Organización" value={registrant.orgName} />}
            {registrant.address1    && <Field label="Dirección"   value={registrant.address1} />}
            {registrant.city        && <Field label="Ciudad"      value={registrant.city} />}
            {registrant.state       && <Field label="Provincia"   value={registrant.state} />}
            {registrant.postalCode  && <Field label="CP"          value={registrant.postalCode} />}
            {registrant.country     && <Field label="País"        value={registrant.country} />}
            {registrant.phone       && <Field label="Teléfono"    value={registrant.phone} />}
          </div>
        </section>
      )}

      {/* Transactions */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-5">
        <h2 className="text-[#F8FAFC] text-sm font-semibold mb-4">
          Transacciones ({domain.transactions.length})
        </h2>
        {domain.transactions.length === 0 ? (
          <p className="text-[#64748B] text-sm">Sin transacciones registradas.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[#64748B] border-b border-[#1E293B]">
                  <th className="pb-2 pr-4 font-medium">Operación</th>
                  <th className="pb-2 pr-4 font-medium">Estado</th>
                  <th className="pb-2 pr-4 font-medium">Código</th>
                  <th className="pb-2 pr-4 font-medium">Respuesta</th>
                  <th className="pb-2 pr-4 font-medium">Duración</th>
                  <th className="pb-2 pr-4 font-medium">Error</th>
                  <th className="pb-2 font-medium">Fecha</th>
                </tr>
              </thead>
              <tbody>
                {domain.transactions.map((tx) => {
                  const txBadge = TX_STATUS_BADGE[tx.status] ?? { label: tx.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }
                  return (
                    <tr key={tx.id} className="border-b border-[#1E293B] last:border-0">
                      <td className="py-2.5 pr-4 text-[#94A3B8] font-mono text-xs">{tx.operation}</td>
                      <td className="py-2.5 pr-4">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${txBadge.className}`}>
                          {txBadge.label}
                        </span>
                      </td>
                      <td className="py-2.5 pr-4 text-[#64748B] text-xs">{tx.responseCode ?? '—'}</td>
                      <td className="py-2.5 pr-4 text-[#94A3B8] text-xs max-w-[200px] truncate">
                        {tx.responseText ?? '—'}
                      </td>
                      <td className="py-2.5 pr-4 text-[#64748B] text-xs">
                        {tx.durationMs != null ? `${tx.durationMs}ms` : '—'}
                      </td>
                      <td className="py-2.5 pr-4 text-[#F87171] text-xs max-w-[200px] truncate">
                        {tx.errorMessage ?? '—'}
                      </td>
                      <td className="py-2.5 text-[#64748B] text-xs">
                        {tx.createdAt.toLocaleDateString('es-AR')}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}
