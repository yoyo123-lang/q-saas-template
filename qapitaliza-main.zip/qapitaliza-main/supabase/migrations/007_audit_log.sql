-- ============================================================
-- 007 — Audit Log
-- Registro de acciones admin y eventos de funnel.
-- Depende de: 001 (profiles)
-- Rollback: 007_audit_log_rollback.sql
-- ============================================================

CREATE TYPE audit_action AS ENUM (
  -- Moderación de listados
  'LISTING_APPROVED',
  'LISTING_REJECTED',
  'LISTING_FEATURED',
  'LISTING_UNFEATURED',
  'LISTING_SOLD',
  'LISTING_PAUSED',        -- vendedor pausó su listado
  'LISTING_REACTIVATED',   -- vendedor reactivó un listado pausado
  'LISTING_EDITED',        -- vendedor editó un listado publicado (puede requerir re-moderación)

  -- Gestión de usuarios
  'USER_SUSPENDED',
  'USER_ROLE_CHANGED',
  'USER_DELETED',
  'USER_DEACTIVATED',      -- soft-delete iniciado por el usuario (baja de cuenta)
  'USER_REACTIVATED',      -- cuenta reactivada dentro del periodo de 90 días

  -- Eventos de funnel (analytics)
  'SIGNUP_COMPLETED',
  'LISTING_CREATED',
  'LISTING_SUBMITTED',     -- enviado a revisión
  'LISTING_PUBLISHED',
  'LISTING_VIEWED',
  'INQUIRY_SENT',
  'INQUIRY_REPLIED',
  'INQUIRY_CONVERTED',
  'FAVORITE_ADDED',
  'FAVORITE_REMOVED'
);

CREATE TABLE public.audit_log (
  id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id     UUID         REFERENCES public.profiles(id) ON DELETE SET NULL,  -- NULL si fue sistema
  action       audit_action NOT NULL,
  entity_type  TEXT         NOT NULL,   -- 'listing' | 'user' | 'inquiry' | 'favorite'
  entity_id    UUID,                    -- UUID de la entidad afectada
  metadata     JSONB        NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  public.audit_log             IS 'Registro inmutable de acciones admin y eventos de funnel.';
COMMENT ON COLUMN public.audit_log.actor_id    IS 'Usuario que realizó la acción. NULL si fue el sistema.';
COMMENT ON COLUMN public.audit_log.entity_type IS 'Tipo de entidad afectada: listing, user, inquiry, favorite.';
COMMENT ON COLUMN public.audit_log.metadata    IS 'Datos adicionales. Ej: {"reason": "...", "old_role": "BUYER", "new_role": "SELLER"}';
