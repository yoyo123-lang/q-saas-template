/**
 * Centralized analytics event tracking module.
 *
 * All funnel events defined in BUSINESS_MODEL.md §Eventos de funnel must be
 * dispatched through this module to keep tracking consistent and auditable.
 *
 * Usage:
 *   import { trackEvent } from '@/lib/analytics/events'
 *   await trackEvent('LISTING_VIEWED', 'listing', listingId)
 *   await trackEvent('INQUIRY_SENT', 'inquiry', inquiryId, userId)
 *
 * TODO (Sesión 05): pass actorId from the SSR session cookie once auth is available.
 */

import { getPrisma } from '@/lib/prisma'
import type { AuditAction, Prisma } from '@prisma/client'

/**
 * Records a funnel event in AuditLog.
 *
 * @param action     - AuditAction enum value (e.g. 'LISTING_VIEWED')
 * @param entityType - The entity being acted on (e.g. 'listing', 'inquiry')
 * @param entityId   - ID of the entity
 * @param actorId    - ID of the authenticated user, or null for anonymous actions
 * @param metadata   - Optional structured data to store with the event
 */
export async function trackEvent(
  action: AuditAction,
  entityType: string,
  entityId: string,
  actorId: string | null = null,
  metadata?: Prisma.InputJsonValue
): Promise<void> {
  try {
    const prisma = getPrisma()
    await prisma.auditLog.create({
      data: {
        action,
        entityType,
        entityId,
        actorId,
        ...(metadata ? { metadata } : {}),
      },
    })
  } catch (e) {
    // Analytics must never break the main flow
    console.error(`[analytics] Failed to track event ${action} for ${entityType}:${entityId}`, e)
  }
}
