'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { approveStage } from '@/lib/actions'

interface ApproveStageFormProps {
  stageId: string
  orgId: string
}

export function ApproveStageForm({ stageId, orgId }: ApproveStageFormProps) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  function handleSubmit(formData: FormData) {
    if (!window.confirm('¿Confirmás la aprobación de esta etapa? Se enviará al cliente para su revisión.')) {
      return
    }
    setError(null)
    startTransition(async () => {
      try {
        await approveStage(formData)
        setSuccess(true)
        setTimeout(() => router.push('/revision'), 800)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error al aprobar la etapa')
      }
    })
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-2">
      <input type="hidden" name="stageId" value={stageId} />
      <input type="hidden" name="orgId" value={orgId} />

      <button
        type="submit"
        disabled={isPending || success}
        className="px-5 py-2.5 rounded-lg bg-[#10B981] text-white text-sm font-semibold hover:bg-[#059669] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {success ? '✓ Aprobada' : isPending ? 'Aprobando...' : '✓ Aprobar etapa'}
      </button>

      {error && <p className="text-[#F87171] text-xs">{error}</p>}
    </form>
  )
}
