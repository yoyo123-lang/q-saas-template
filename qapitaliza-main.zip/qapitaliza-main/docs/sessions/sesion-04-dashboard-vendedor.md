# Sesión 04 — Dashboard Vendedor

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 03 — Auth completo (login, registro, OAuth, recuperar contraseña, perfil).

Esta sesión construye el dashboard completo del vendedor: vista general con estadísticas, gestión de listados, wizard de creación (4 pasos) y edición con tabs.

Leer antes de empezar:
- `PLAN.md` — Etapa 5
- `docs/frontend/04-dashboards.md` — especificación del dashboard vendedor (§1 al §4)
- `docs/frontend/02-componentes-base.md` — componentes existentes y nuevos

## Estado actual

Ya existe:
- Auth funcionando con roles
- Componentes UI: Button, Card, Badge, Input, Textarea, Select, Modal, Accordion, Avatar, Pagination
- `src/lib/data/listings.ts` con queries básicas del catálogo público

## Tarea de esta sesión

### 1. Instalar dependencias nuevas

```bash
npm install recharts @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities
```

### 2. Layout del dashboard `src/app/(dashboard)/layout.tsx`

Auth guard: verificar sesión con Supabase. Sin sesión → redirect `/login`. Layout: `flex h-screen`. `<Sidebar variant="dashboard">` + `<main className="flex-1 ml-[280px] overflow-y-auto">`.

### 3. `src/components/layout/sidebar.tsx`

Ver `docs/frontend/02-componentes-base.md` §9. Props: `variant: 'dashboard' | 'admin'`, `activeItem: string`, `user`.

Nav items dashboard:
- Dashboard → `/dashboard`
- Mis activos → `/mis-activos`
- Consultas → `/consultas` (con badge de conteo de no leídas)
- Favoritos → `/favoritos`
- Perfil → `/perfil`

Separador + botón "Nuevo listado" (outline amber con ícono Plus).

Footer sidebar: avatar con iniciales (color por rol), nombre, rol en texto muted, botón logout (ícono LogOut).

**Nav item activo:** barra izquierda 3px amber + fondo amber/8% + texto amber. Resto: texto slate-400, hover fondo slate-800.

### 4. Componentes nuevos para dashboard

#### `src/components/ui/stat-card.tsx`
Ver `docs/frontend/02-componentes-base.md` §8. Props: label, value, icon, trend `{value, positive}`, pulse (dot pulsante amber), highlight (valor en amber).

#### `src/components/shared/activity-item.tsx`
Row con dot de color + texto + timestamp. Colores por tipo: azul=consulta, amber=destacado, verde=aprobado, gris=default.

#### `src/components/ui/dropdown-menu.tsx`
Menú de opciones para las tablas. Abre con click en ícono MoreHorizontal. Items: label + ícono + onClick + opcional `danger: true` (color rojo).

### 5. Dashboard general `/dashboard`

`src/app/(dashboard)/dashboard/page.tsx` — Server Component.

Fetch en paralelo con `Promise.all()`:
```ts
const [stats, recentActivity, previewListings] = await Promise.all([
  getSellerStats(userId),
  getRecentActivity(userId, 5),
  getListings({ sellerId: userId, limit: 4 })
])
```

Agregar a `src/lib/data/listings.ts`:
```ts
export async function getSellerStats(sellerId: string): Promise<SellerStats>
export async function getRecentActivity(sellerId: string, limit: number): Promise<Activity[]>
```

Secciones (ver `docs/frontend/04-dashboards.md` §1):
1. Header con saludo
2. 4 `<StatCard>`: activos publicados, vistas totales (con trend), consultas activas (con pulse), revenue total listado (con highlight)
3. `<AreaChart>` de Recharts — "Vistas de tus activos" — línea amber, fill amber/10, fondo navy-950, grid lines slate-800. Dropdown de período (7d/30d/90d) que actualiza el gráfico vía estado local
4. Lista de `<ActivityItem>` — actividad reciente (últimas 5)
5. Preview tabla de 4 activos con link "Ver todos →" a `/mis-activos`

### 6. Componente `<ListingsTable />`

`src/components/listings/listings-table.tsx`. Columnas:
- Thumbnail (40×40px rounded-lg) + nombre del activo (link a editar)
- Tipo (badge info)
- Precio (con moneda)
- Estado (`<Badge>` según status: success=PUBLISHED, amber=PENDING_REVIEW/FEATURED, muted=DRAFT, danger=REJECTED, info=SOLD)
- Vistas
- Consultas
- Menú ⋯ (`<DropdownMenu>`) con: Editar, Ver página pública, Pausar/Reanudar, Eliminar

Eliminar: abre `<Modal>` de confirmación antes de ejecutar la Server Action.

Filas con hover slate-800. Headers: uppercase tracking-wider text-xs text-slate-500.

### 7. Mis Activos `/mis-activos`

`src/app/(dashboard)/mis-activos/page.tsx`.

Tabs horizontales (Todos/Publicados/Borradores/En revisión/Vendidos) con conteo. Tab activo: borde inferior amber. Implementar como searchParam `?status=`.

Barra superior: barra de búsqueda + botón "Nuevo listado" (amber, Plus).

`<ListingsTable />` + `<Pagination />`.

Estado vacío: `<EmptyState icon={Package} title="Todavía no publicaste ningún activo" cta={<Button href="/mis-activos/nuevo">Publicar mi primer activo</Button>} />`

Agregar a `src/lib/data/listings.ts`:
```ts
export async function getSellerListings(sellerId: string, params: SellerListingParams): Promise<PaginatedListings>
```

### 8. Wizard de creación `/mis-activos/nuevo`

`src/app/(dashboard)/mis-activos/nuevo/page.tsx` — Client Component.

#### `src/components/listings/listing-form/stepper.tsx`
4 pasos visuales. Círculo activo: bg-amber-500 text-navy-950. Completado: bg-emerald-500. Pendiente: bg-slate-800 text-slate-400. Línea conector: amber hasta paso activo, slate después.

#### `src/components/ui/tag-input.tsx`
Ver `docs/frontend/06-auth-y-formularios.md` §6. Enter o coma → agrega chip. Backspace con input vacío → elimina último. Click × → elimina ese chip. Suggestions opcionales (dropdown filtrado). Max tags y max longitud configurables.

#### `src/components/ui/image-uploader.tsx`
Drop zone con `border-2 border-dashed border-slate-800 rounded-xl`. Drag active: `border-amber-500`. Click también abre file picker. Validación: máx 5 imágenes, 2MB cada una, solo JPG/PNG/WebP. Preview con thumbnail + botón ×. Reorden con @dnd-kit (drag & drop).

Upload real a Supabase Storage bucket `listing-screenshots` en la Server Action.

#### Paso 1 `src/components/listings/listing-form/step-basic.tsx`
Campos (con `react-hook-form` + zodResolver):
- Título del activo (Input, required)
- Tipo de activo (Select: Sitio Web/Dominio/SaaS/MVP/E-commerce/Proyecto)
- URL del activo (Input con prefix "https://", nullable)
- Descripción (Textarea 6 rows, counter, max 2000 chars)
- Precio (Input numérico con prefix "$") + Moneda (Select: USD/ARS) en 2 columnas
- Tech Stack (`<TagInput>` max 10 tags, suggestions: React, Next.js, WordPress, Shopify, Node.js, Python, Laravel, Vue, Tailwind CSS, TypeScript, PostgreSQL, Supabase)
- Tags (`<TagInput>` max 8 tags)

#### Paso 2 `src/components/listings/listing-form/step-metrics.tsx`
Campos dinámicos según el tipo elegido en Paso 1:

| Tipo | Métricas |
|---|---|
| WEBSITE | Visitas/mes, Domain Authority, Edad (meses) |
| DOMAIN | Domain Authority, Año de registro |
| SAAS/MVP | MRR (USD), Usuarios activos, Churn rate (%), Edad (meses) |
| ECOMMERCE | Órdenes/mes, Revenue mensual, Edad (meses) |
| PROJECT | Usuarios activos, Edad (meses) |

Cada métrica tiene: Input numérico + Select de fuente (SELF_REPORTED/SCREENSHOT/ANALYTICS_CONNECTED) + Input de evidencia URL (nullable).

#### Paso 3 `src/components/listings/listing-form/step-images.tsx`
`<ImageUploader />` con instrucciones. "Arrastá o hacé click para subir" + "Máximo 5 imágenes · 2MB cada una · JPG, PNG o WebP".

#### Paso 4: Revisión (inline en la página del wizard)
Read-only de todos los datos ingresados en los pasos anteriores. Mostrar como cards de resumen.

Botones del footer: "Guardar borrador" (outline) → Server Action con `status: DRAFT` y `toast.success`. "Enviar a revisión" (solid amber) → Server Action con `status: PENDING_REVIEW` + redirect a `/mis-activos` con toast.

**Persistencia:** Guardar el estado del wizard en `sessionStorage` con key `new-listing-draft`. Al entrar a la página, si hay draft guardado: mostrar Modal "¿Querés continuar donde lo dejaste?".

### 9. Edición `/mis-activos/[id]/editar`

`src/app/(dashboard)/mis-activos/[id]/editar/page.tsx`.

Verificar que `listing.sellerId === currentUser.id` — si no, redirect a `/mis-activos` con toast de error.

Tabs horizontales: Información | Métricas | Imágenes | Configuración. Cada tab es el formulario correspondiente del wizard pero pre-populado.

Sidebar sticky (300px):
- Badge de estado actual
- Botones: "Pausar publicación" / "Reanudar" (según estado), "Marcar como vendido", separador, "Eliminar listado" (danger)
- Stats: Vistas, Consultas, Favoritos
- "Última edición: hace X días"

Footer del form: "Descartar cambios" (ghost) + "Guardar cambios" (solid amber).

### 10. Server Actions en `src/lib/actions/listings.ts`

```ts
export async function createListing(data: CreateListingData): Promise<ActionResult<{ id: string }>>
export async function updateListing(id: string, data: UpdateListingData): Promise<ActionResult>
export async function deleteListing(id: string): Promise<ActionResult>
export async function publishListing(id: string): Promise<ActionResult>   // → PENDING_REVIEW
export async function pauseListing(id: string): Promise<ActionResult>
export async function resumeListing(id: string): Promise<ActionResult>
export async function markAsSold(id: string): Promise<ActionResult>
```

Todas las actions:
1. Verificar sesión activa
2. Verificar `listing.seller_id === currentUser.id` (IDOR protection)
3. Validar con Zod
4. Ejecutar operación
5. Retornar `{ success: boolean, error?: string, data?: T }`

`createListing`: verificar que el vendedor no supera 50 listados activos antes de crear.

`publishListing`: verificar que el listing tiene título, descripción, precio y al menos 1 screenshot.

Trackear eventos en `lib/analytics/events.ts`:
- `LISTING_CREATED` al crear
- `LISTING_SUBMITTED` al publicar

### 11. Schema Zod en `src/lib/schemas/listing.ts`

```ts
export const stepBasicSchema = z.object({ ... })
export const stepMetricsSchema = z.object({ ... }) // dinámico según tipo
export const stepImagesSchema = z.object({ ... })
export const createListingSchema = stepBasicSchema.merge(stepMetricsSchema).merge(stepImagesSchema)
```

### 12. Tests

`src/lib/actions/__tests__/listings.test.ts`:
- CRUD básico
- IDOR: intentar editar listing de otro vendedor → error
- Límite de 50 listados activos
- `publishListing` sin screenshots → error
- Validación de schemas por tipo de activo

## Reglas

- IDOR en toda mutación: verificar ownership ANTES de ejecutar — no asumir
- Los uploads de imágenes van a Supabase Storage, nunca al filesystem del servidor
- El wizard guarda borradores en sessionStorage pero las imágenes solo se suben al hacer submit final

## Checkpoint

La sesión está completa cuando:
- [ ] Sidebar con navegación activa y badge de consultas
- [ ] Dashboard con 4 StatCards, gráfico Recharts y actividad reciente
- [ ] `/mis-activos` con tabs, tabla y paginación funcionales
- [ ] Wizard de 4 pasos completo sin placeholders — cada botón funciona
- [ ] Upload real de imágenes a Supabase Storage
- [ ] Edición con tabs pre-populados y sidebar de acciones
- [ ] IDOR bloqueado (verificado con test)
- [ ] Tests pasan
- [ ] `npm run build` sin errores
