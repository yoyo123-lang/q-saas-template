-- ============================================================
-- 009 — Row Level Security (RLS)
-- Políticas de seguridad a nivel fila para todas las tablas.
-- Sin estas políticas: nadie puede leer ni escribir (Supabase default).
-- Rollback: 009_rls_policies_rollback.sql
-- ============================================================

-- Helper: obtener el UUID del usuario autenticado actual
-- Supabase provee auth.uid() automáticamente.

-- ============================================================
-- PROFILES
-- ============================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Cualquiera puede ver perfiles públicos
CREATE POLICY "profiles_select_public"
  ON public.profiles FOR SELECT
  USING (true);

-- Solo el propio usuario puede actualizar su perfil
CREATE POLICY "profiles_update_own"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Solo el sistema (trigger) puede insertar perfiles — no el usuario directo
-- (La inserción la maneja el trigger en 010_triggers.sql)
CREATE POLICY "profiles_insert_own"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- ============================================================
-- CATEGORIES
-- ============================================================
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Lectura pública
CREATE POLICY "categories_select_public"
  ON public.categories FOR SELECT
  USING (true);

-- Solo ADMIN puede insertar/actualizar/borrar categorías
CREATE POLICY "categories_write_admin"
  ON public.categories FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'ADMIN'
    )
  );

-- ============================================================
-- LISTINGS
-- ============================================================
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;

-- Lectura pública solo de listings PUBLISHED
CREATE POLICY "listings_select_published"
  ON public.listings FOR SELECT
  USING (status = 'PUBLISHED');

-- El vendedor puede ver todos sus propios listings (cualquier status)
CREATE POLICY "listings_select_own_seller"
  ON public.listings FOR SELECT
  USING (auth.uid() = seller_id);

-- Admin puede ver todos los listings
CREATE POLICY "listings_select_admin"
  ON public.listings FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'ADMIN'
    )
  );

-- El vendedor puede insertar sus propios listings
CREATE POLICY "listings_insert_seller"
  ON public.listings FOR INSERT
  WITH CHECK (auth.uid() = seller_id);

-- El vendedor puede actualizar sus propios listings
-- (cambios de status como PUBLISHED → SOLD o PAUSED los valida la Server Action)
CREATE POLICY "listings_update_own_seller"
  ON public.listings FOR UPDATE
  USING (auth.uid() = seller_id)
  WITH CHECK (auth.uid() = seller_id);

-- Admin puede actualizar cualquier listing (moderación)
CREATE POLICY "listings_update_admin"
  ON public.listings FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'ADMIN'
    )
  );

-- El vendedor puede borrar sus propios DRAFT listings
CREATE POLICY "listings_delete_own_draft"
  ON public.listings FOR DELETE
  USING (auth.uid() = seller_id AND status = 'DRAFT');

-- Admin puede borrar cualquier listing
CREATE POLICY "listings_delete_admin"
  ON public.listings FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'ADMIN'
    )
  );

-- ============================================================
-- LISTING METRICS
-- ============================================================
ALTER TABLE public.listing_metrics ENABLE ROW LEVEL SECURITY;

-- Cualquiera puede ver las métricas de listings publicados
CREATE POLICY "listing_metrics_select_published"
  ON public.listing_metrics FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.listings
      WHERE id = listing_id AND status = 'PUBLISHED'
    )
  );

-- El vendedor puede ver las métricas de sus propios listings
CREATE POLICY "listing_metrics_select_own"
  ON public.listing_metrics FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.listings
      WHERE id = listing_id AND seller_id = auth.uid()
    )
  );

-- Admin puede ver todas las métricas
CREATE POLICY "listing_metrics_select_admin"
  ON public.listing_metrics FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'ADMIN')
  );

-- El vendedor puede escribir métricas de sus propios listings
CREATE POLICY "listing_metrics_write_own"
  ON public.listing_metrics FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.listings
      WHERE id = listing_id AND seller_id = auth.uid()
    )
  );

-- ============================================================
-- INQUIRIES
-- ============================================================
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

-- El comprador y el vendedor del listing pueden ver la consulta
CREATE POLICY "inquiries_select_participants"
  ON public.inquiries FOR SELECT
  USING (
    auth.uid() = buyer_id
    OR EXISTS (
      SELECT 1 FROM public.listings
      WHERE id = listing_id AND seller_id = auth.uid()
    )
  );

-- Admin puede ver todas las consultas
CREATE POLICY "inquiries_select_admin"
  ON public.inquiries FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'ADMIN')
  );

-- Solo el comprador puede crear una consulta
-- (la validación de "no consultar propio activo" va en la Server Action)
CREATE POLICY "inquiries_insert_buyer"
  ON public.inquiries FOR INSERT
  WITH CHECK (auth.uid() = buyer_id);

-- Solo el comprador puede actualizar el status de la consulta (cerrar)
CREATE POLICY "inquiries_update_buyer"
  ON public.inquiries FOR UPDATE
  USING (auth.uid() = buyer_id);

-- ============================================================
-- INQUIRY MESSAGES
-- ============================================================
ALTER TABLE public.inquiry_messages ENABLE ROW LEVEL SECURITY;

-- Solo los participantes de la consulta pueden leer los mensajes
CREATE POLICY "inquiry_messages_select_participants"
  ON public.inquiry_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.inquiries i
      WHERE i.id = inquiry_id
        AND (
          i.buyer_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.listings l
            WHERE l.id = i.listing_id AND l.seller_id = auth.uid()
          )
        )
    )
  );

-- Solo los participantes pueden enviar mensajes
-- (la validación adicional de "solo participantes" va también en la Server Action)
CREATE POLICY "inquiry_messages_insert_participants"
  ON public.inquiry_messages FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id
    AND EXISTS (
      SELECT 1 FROM public.inquiries i
      WHERE i.id = inquiry_id
        AND (
          i.buyer_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.listings l
            WHERE l.id = i.listing_id AND l.seller_id = auth.uid()
          )
        )
    )
  );

-- ============================================================
-- FAVORITES
-- ============================================================
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

-- Solo el propio usuario ve sus favoritos
CREATE POLICY "favorites_select_own"
  ON public.favorites FOR SELECT
  USING (auth.uid() = user_id);

-- Solo el propio usuario puede agregar favoritos
CREATE POLICY "favorites_insert_own"
  ON public.favorites FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Solo el propio usuario puede quitar favoritos
CREATE POLICY "favorites_delete_own"
  ON public.favorites FOR DELETE
  USING (auth.uid() = user_id);

-- ============================================================
-- AUDIT LOG
-- ============================================================
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Solo admin puede leer el audit log
CREATE POLICY "audit_log_select_admin"
  ON public.audit_log FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'ADMIN')
  );

-- Nadie puede insertar directamente desde el cliente — solo via Server Action con service_role key
-- (la Server Action usa la clave service_role, que bypasea RLS)
-- No definir política de INSERT intencional aquí.
