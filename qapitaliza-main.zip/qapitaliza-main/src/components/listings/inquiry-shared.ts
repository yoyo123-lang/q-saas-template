/**
 * Shared constants and utilities for inquiry UI components.
 * Centralizes badge variants, status labels, and participant initials
 * to avoid duplication between InquiryCard and ChatView.
 */

/** Maps InquiryStatus to Badge variant */
export const inquiryStatusVariant: Record<string, 'info' | 'success' | 'amber' | 'muted'> = {
  OPEN: 'info',
  REPLIED: 'success',
  CLOSED: 'muted',
  CONVERTED: 'amber',
}

/** Maps InquiryStatus to human-readable Spanish label */
export const inquiryStatusLabel: Record<string, string> = {
  OPEN: 'Abierta',
  REPLIED: 'Respondida',
  CLOSED: 'Cerrada',
  CONVERTED: 'Convertida',
}

/**
 * Returns 1-2 uppercase initials from a participant's display name.
 * Falls back to email if fullName is null.
 */
export function getParticipantInitials(
  participant: { fullName: string | null; email: string }
): string {
  const name = participant.fullName ?? participant.email
  return name
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? '')
    .join('')
}
