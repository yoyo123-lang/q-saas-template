# Plan de Implementación — Sesión 1: Schema base y multi-tenancy (backend)

> Cada tarea es una unidad atómica: test → implementar → verificar → commit.
> Estado: ⬜ pendiente | ✅ completado | ❌ bloqueado

---

## Etapa 1: Schema Prisma completo

**Objetivo:** Modelos de dominio de Fase 1 definidos y validados con `prisma generate`.

| # | Tarea | Archivos afectados | Criterio de aceptación |
|---|---|---|---|
| 1.1 | Agregar enums al schema (MemberRole, IvaCondition, InvoiceType, InvoiceStatus, MovementType, PaymentMethod, SaleStatus, CashRegisterStatus, SubscriptionStatus, PlanSlug, ContactType) | `prisma/schema.prisma` | Enums definidos sin errores |
| 1.2 | Agregar modelos base (Organization, Membership, Plan, Subscription) | `prisma/schema.prisma` | `npx prisma generate` pasa |
| 1.3 | Agregar modelos de catálogo (Category, Product, ProductVariant, PriceList, PriceListItem) | `prisma/schema.prisma` | `npx prisma generate` pasa |
| 1.4 | Agregar modelos de contactos y facturación (Contact, Invoice, InvoiceItem) | `prisma/schema.prisma` | `npx prisma generate` pasa |
| 1.5 | Agregar modelos de ventas, stock y tesorería (Sale, SaleItem, Warehouse, StockMovement, CashRegister, PaymentRecord) | `prisma/schema.prisma` | `npx prisma generate` pasa |
| 1.6 | Relacionar User con Membership | `prisma/schema.prisma` | Schema completo, `npx prisma generate` pasa sin errores |

**Estado Etapa 1:** ✅

---

## Etapa 2: Helper withTenant() (TDD)

**Objetivo:** Función type-safe que filtra queries Prisma por `organizationId` automáticamente.

| # | Tarea | Archivos afectados | Criterio de aceptación |
|---|---|---|---|
| 2.1 | [RED] Tests para `applyTenantFilter()` — función pura | `tests/unit/tenant.test.ts` | Tests fallan (no existe la implementación) |
| 2.2 | [GREEN] Implementar `applyTenantFilter()` y `withTenant()` | `src/lib/tenant.ts` | Tests pasan |
| 2.3 | Tests para aislamiento de tenants (que un filter incorrecto no filtre) | `tests/unit/tenant.test.ts` | Tests verdes |

**Estado Etapa 2:** ✅

---

## Etapa 3: Migración y seed

**Objetivo:** Datos de demo listos para desarrollo local.

| # | Tarea | Archivos afectados | Criterio de aceptación |
|---|---|---|---|
| 3.1 | Crear migración Supabase con SQL de todos los modelos nuevos | `supabase/migrations/20260325000000_add_domain_models.sql` | Archivo SQL válido con todas las tablas, enums e índices |
| 3.2 | Actualizar `seed.ts` con: org demo, warehouse default, plan Micro, product de muestra, cliente de muestra | `prisma/seed.ts` | Seed corre sin errores |

**Estado Etapa 3:** ✅ (seed actualizado y migración SQL creada; seed.ts tiene fix de $transaction sin commitear)

---

## Etapa 4: Tests y verificación final

**Objetivo:** Build limpio, tests verdes.

| # | Tarea | Archivos afectados | Criterio de aceptación |
|---|---|---|---|
| 4.1 | Correr `npm test` — todos los tests pasan | — | Sin errores ni fallos |
| 4.2 | Correr `npm run lint` — sin warnings | — | Sin errores |
| 4.3 | Correr `npm run build` — sin errores | — | Build exitoso |

**Estado Etapa 4:** ✅ (tests pasan; build y lint no verificados al cierre de sesión)

---

## Resumen

| Etapa | Tareas | Estado |
|---|---|---|
| 1 — Schema | 6 | ✅ |
| 2 — withTenant | 3 | ✅ |
| 3 — Migración + seed | 2 | ✅ |
| 4 — Verificación | 3 | ✅ |

---

## Convenciones para esta sesión

- Cada tarea = un commit con mensaje descriptivo
- TDD obligatorio para `withTenant()`: test primero, código después
- `organizationId` es el campo de tenant en todos los modelos de dominio
- No tocar archivos fuera del alcance de esta sesión
