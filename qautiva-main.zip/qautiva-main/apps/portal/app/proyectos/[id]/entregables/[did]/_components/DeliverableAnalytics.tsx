'use client'

import { useEffect, useState } from 'react'

interface Analytics {
  totalViews: number
  last7Days: number
  last30Days: number
}

type State =
  | { status: 'loading' }
  | { status: 'error' }
  | { status: 'ok'; data: Analytics }

export function DeliverableAnalytics({ deliverableId }: { deliverableId: string }) {
  const [state, setState] = useState<State>({ status: 'loading' })

  useEffect(() => {
    fetch(`/api/deliverables/${deliverableId}/analytics`)
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json() as Promise<Analytics>
      })
      .then((data) => setState({ status: 'ok', data }))
      .catch((err) => {
        console.error('[DeliverableAnalytics] fetch falló:', err)
        setState({ status: 'error' })
      })
  }, [deliverableId])

  if (state.status === 'loading') {
    return (
      <div className="mt-4 p-4 bg-gray-50 rounded-lg border animate-pulse">
        <div className="h-4 bg-gray-200 rounded w-32 mb-3" />
        <div className="grid grid-cols-3 gap-4">
          {[0, 1, 2].map((i) => (
            <div key={i} className="text-center">
              <div className="h-8 bg-gray-200 rounded mb-1" />
              <div className="h-3 bg-gray-100 rounded w-16 mx-auto" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (state.status === 'error') {
    return (
      <div className="mt-4 p-4 bg-gray-50 rounded-lg border text-sm text-gray-500">
        No se pudieron cargar las métricas de visitas.
      </div>
    )
  }

  const { data } = state

  return (
    <div className="mt-4 p-4 bg-gray-50 rounded-lg border">
      <h3 className="text-sm font-medium text-gray-700 mb-3">Visitas al sitio</h3>
      <div className="grid grid-cols-3 gap-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-900">{data.totalViews}</div>
          <div className="text-xs text-gray-500">Total</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-900">{data.last30Days}</div>
          <div className="text-xs text-gray-500">Últimos 30 días</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-900">{data.last7Days}</div>
          <div className="text-xs text-gray-500">Últimos 7 días</div>
        </div>
      </div>
    </div>
  )
}
