'use client'

import { useEffect, useRef, useState, useTransition } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'sonner'
import { Camera, Eye, EyeOff, ShieldCheck } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { updateProfile, type ProfileData } from '@/lib/actions/auth'
import { nuevaContrasenaSchema, type NuevaContrasenaData } from '@/lib/schemas/auth'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Modal } from '@/components/ui/modal'
import { Avatar } from '@/components/ui/avatar'
import { PasswordStrength } from '@/components/ui/password-strength'

const profileInfoSchema = z.object({
  nombre: z.string().min(2, 'Ingresá tu nombre completo').max(100),
  empresa: z.string().max(100).optional(),
  sitio_web: z.string().url('URL inválida').or(z.literal('')).optional(),
  bio: z.string().max(500).optional(),
})
type ProfileInfoData = z.infer<typeof profileInfoSchema>

interface NotificationPrefs {
  nuevas_consultas: boolean
  respuestas: boolean
  nuevos_listados: boolean
  resumen_semanal: boolean
}

const defaultNotifPrefs: NotificationPrefs = {
  nuevas_consultas: true,
  respuestas: true,
  nuevos_listados: false,
  resumen_semanal: true,
}

export default function PerfilPage() {
  const [user, setUser] = useState<{
    id: string
    email: string
    nombre: string
    empresa: string
    sitio_web: string
    bio: string
    avatar_url: string | null
    role: string
    created_at: string
    notification_preferences: NotificationPrefs
  } | null>(null)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [notifPrefs, setNotifPrefs] = useState<NotificationPrefs>(defaultNotifPrefs)
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false)
  const [isPendingInfo, startInfoTransition] = useTransition()
  const [isPendingPassword, startPasswordTransition] = useTransition()
  const [isPendingNotif, startNotifTransition] = useTransition()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const infoForm = useForm<ProfileInfoData>({
    resolver: zodResolver(profileInfoSchema),
    mode: 'onBlur',
  })

  const passwordForm = useForm<NuevaContrasenaData>({
    resolver: zodResolver(nuevaContrasenaSchema),
    mode: 'onBlur',
  })

  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const watchNewPassword = passwordForm.watch('password') ?? ''

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(async ({ data: { user: authUser } }) => {
      if (!authUser) return

      const { data: profile } = await supabase
        .from('profiles')
        .select('nombre, empresa, sitio_web, bio, avatar_url, role, notification_preferences')
        .eq('id', authUser.id)
        .single()

      const prefs = profile?.notification_preferences ?? defaultNotifPrefs

      setUser({
        id: authUser.id,
        email: authUser.email ?? '',
        nombre: profile?.nombre ?? authUser.user_metadata?.nombre ?? '',
        empresa: profile?.empresa ?? '',
        sitio_web: profile?.sitio_web ?? '',
        bio: profile?.bio ?? '',
        avatar_url: profile?.avatar_url ?? null,
        role: profile?.role ?? 'BUYER',
        created_at: authUser.created_at ?? '',
        notification_preferences: prefs,
      })

      setNotifPrefs(prefs)

      infoForm.reset({
        nombre: profile?.nombre ?? authUser.user_metadata?.nombre ?? '',
        empresa: profile?.empresa ?? '',
        sitio_web: profile?.sitio_web ?? '',
        bio: profile?.bio ?? '',
      })
    })
  }, [infoForm])

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return

    setIsUploadingAvatar(true)
    try {
      const supabase = createClient()
      const ext = file.name.split('.').pop()
      const path = `${user.id}/avatar.${ext}`

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(path, file, { upsert: true })

      if (uploadError) throw uploadError

      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path)

      await supabase.from('profiles').update({ avatar_url: publicUrl }).eq('id', user.id)
      setUser((prev) => prev ? { ...prev, avatar_url: publicUrl } : prev)
      toast.success('Foto actualizada.')
    } catch {
      toast.error('Error al subir la foto. Intentá de nuevo.')
    } finally {
      setIsUploadingAvatar(false)
    }
  }

  const onSaveInfo = (data: ProfileInfoData) => {
    startInfoTransition(async () => {
      const result = await updateProfile(data as ProfileData)
      if (result.error) {
        toast.error(result.error)
      } else {
        toast.success('Información actualizada.')
      }
    })
  }

  const onChangePassword = (data: NuevaContrasenaData) => {
    startPasswordTransition(async () => {
      const supabase = createClient()
      const { error } = await supabase.auth.updateUser({ password: data.password })
      if (error) {
        toast.error('Error al cambiar la contraseña. Intentá de nuevo.')
      } else {
        toast.success('Contraseña actualizada.')
        setShowPasswordModal(false)
        passwordForm.reset()
      }
    })
  }

  const handleSignOutAll = async () => {
    const supabase = createClient()
    await supabase.auth.signOut({ scope: 'global' })
    toast.success('Todas las sesiones cerradas.')
    window.location.href = '/login'
  }

  const toggleNotif = (key: keyof NotificationPrefs) => {
    const updated = { ...notifPrefs, [key]: !notifPrefs[key] }
    setNotifPrefs(updated)
    startNotifTransition(async () => {
      const result = await updateProfile({ notification_preferences: updated })
      if (result.error) toast.error(result.error)
    })
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-slate-400 text-sm">Cargando perfil...</p>
      </div>
    )
  }

  const initials = user.nombre
    ? user.nombre.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
    : user.email.slice(0, 2).toUpperCase()

  const memberSince = new Date(user.created_at).toLocaleDateString('es-AR', {
    year: 'numeric',
    month: 'long',
  })

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="text-2xl font-semibold text-slate-50">Mi perfil</h1>

      {/* Card Avatar */}
      <Card padding="lg">
        <div className="flex items-center gap-5">
          <div className="relative">
            {user.avatar_url ? (
              <img
                src={user.avatar_url}
                alt={`Avatar de ${user.nombre}`}
                className="size-20 rounded-full object-cover"
              />
            ) : (
              <Avatar
                initials={initials}
                role={user.role as 'BUYER' | 'SELLER' | 'ADMIN'}
                className="size-20 text-xl"
              />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <p className="text-base font-semibold text-slate-50 truncate">
              {user.nombre || '—'}
            </p>
            <p className="text-sm text-slate-400 truncate">{user.email}</p>
            <p className="text-xs text-slate-500 mt-0.5">Miembro desde {memberSince}</p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleAvatarUpload}
          />
          <Button
            variant="outline"
            size="sm"
            icon={<Camera size={14} />}
            loading={isUploadingAvatar}
            onClick={() => fileInputRef.current?.click()}
          >
            Cambiar foto
          </Button>
        </div>
      </Card>

      {/* Card Información personal */}
      <Card padding="lg">
        <h2 className="text-base font-semibold text-slate-50 mb-4">Información personal</h2>
        <form onSubmit={infoForm.handleSubmit(onSaveInfo)} className="space-y-4">
          <Input
            label="Nombre completo"
            type="text"
            {...infoForm.register('nombre')}
            error={infoForm.formState.touchedFields.nombre ? infoForm.formState.errors.nombre?.message : undefined}
          />

          <Input
            label="Email"
            type="email"
            value={user.email}
            disabled
            suffix={<span className="text-xs text-emerald-500 font-medium">Verificado ✓</span>}
          />

          <Input
            label="Empresa"
            type="text"
            placeholder="Tu empresa (opcional)"
            {...infoForm.register('empresa')}
            error={infoForm.formState.touchedFields.empresa ? infoForm.formState.errors.empresa?.message : undefined}
          />

          <Input
            label="Sitio web"
            type="url"
            placeholder="https://tuweb.com"
            {...infoForm.register('sitio_web')}
            error={infoForm.formState.touchedFields.sitio_web ? infoForm.formState.errors.sitio_web?.message : undefined}
          />

          <Textarea
            label="Bio"
            placeholder="Contá algo sobre vos..."
            rows={3}
            maxLength={500}
            {...infoForm.register('bio')}
          />

          <div className="flex justify-end">
            <Button type="submit" variant="solid" loading={isPendingInfo}>
              Guardar cambios
            </Button>
          </div>
        </form>
      </Card>

      {/* Card Seguridad */}
      <Card padding="lg">
        <h2 className="text-base font-semibold text-slate-50 mb-4">Seguridad</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck size={18} className="text-slate-400" />
              <div>
                <p className="text-sm text-slate-50">Contraseña</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowPasswordModal(true)}
            >
              Cambiar contraseña
            </Button>
          </div>

          <div className="border-t border-slate-800 pt-3">
            <Button
              variant="outline-danger"
              size="sm"
              onClick={handleSignOutAll}
            >
              Cerrar todas las sesiones
            </Button>
          </div>
        </div>
      </Card>

      {/* Card Notificaciones */}
      <Card padding="lg">
        <h2 className="text-base font-semibold text-slate-50 mb-4">Notificaciones por email</h2>
        <div className="space-y-4">
          {[
            { key: 'nuevas_consultas' as const, label: 'Nuevas consultas sobre mis activos' },
            { key: 'respuestas' as const, label: 'Respuestas a mis consultas' },
            { key: 'nuevos_listados' as const, label: 'Nuevos activos publicados' },
            { key: 'resumen_semanal' as const, label: 'Resumen semanal del marketplace' },
          ].map(({ key, label }) => (
            <div key={key} className="flex items-center justify-between">
              <span className="text-sm text-slate-300">{label}</span>
              <button
                type="button"
                role="switch"
                aria-checked={notifPrefs[key]}
                aria-label={label}
                onClick={() => toggleNotif(key)}
                disabled={isPendingNotif}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2 focus-visible:ring-offset-navy-900 ${
                  isPendingNotif ? 'opacity-50 cursor-not-allowed' : ''
                } ${notifPrefs[key] ? 'bg-amber-500' : 'bg-slate-700'}`}
              >
                <span
                  className={`inline-block size-3.5 rounded-full bg-white shadow transition-transform ${
                    notifPrefs[key] ? 'translate-x-4' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </Card>

      {/* Modal cambiar contraseña */}
      <Modal
        open={showPasswordModal}
        onClose={() => { setShowPasswordModal(false); passwordForm.reset() }}
        title="Cambiar contraseña"
        size="sm"
      >
        <form onSubmit={passwordForm.handleSubmit(onChangePassword)} className="space-y-4">
          <div className="space-y-1.5">
            <Input
              label="Nueva contraseña"
              type={showNewPassword ? 'text' : 'password'}
              autoComplete="new-password"
              suffix={
                <button
                  type="button"
                  onClick={() => setShowNewPassword((v) => !v)}
                  className="text-slate-400 hover:text-slate-200 transition-colors"
                  aria-label={showNewPassword ? 'Ocultar' : 'Mostrar'}
                >
                  {showNewPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              }
              {...passwordForm.register('password')}
              error={passwordForm.formState.touchedFields.password ? passwordForm.formState.errors.password?.message : undefined}
            />
            <PasswordStrength password={watchNewPassword} />
          </div>

          <Input
            label="Confirmar contraseña"
            type={showConfirmPassword ? 'text' : 'password'}
            autoComplete="new-password"
            suffix={
              <button
                type="button"
                onClick={() => setShowConfirmPassword((v) => !v)}
                className="text-slate-400 hover:text-slate-200 transition-colors"
                aria-label={showConfirmPassword ? 'Ocultar' : 'Mostrar'}
              >
                {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            }
            {...passwordForm.register('confirmPassword')}
            error={passwordForm.formState.touchedFields.confirmPassword ? passwordForm.formState.errors.confirmPassword?.message : undefined}
          />

          <div className="flex gap-3 justify-end">
            <Button
              type="button"
              variant="ghost"
              onClick={() => { setShowPasswordModal(false); passwordForm.reset() }}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="solid" loading={isPendingPassword}>
              Guardar contraseña
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
