import { AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils/cn'

interface ErrorStateProps {
  message?: string
  retry?: () => void
  className?: string
}

export function ErrorState({
  message = 'Ocurrió un error al cargar los datos.',
  retry,
  className,
}: ErrorStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-4 py-16 text-center',
        className
      )}
    >
      <div className="size-12 rounded-full bg-red-500/10 flex items-center justify-center">
        <AlertCircle className="size-5 text-red-500" />
      </div>
      <div className="flex flex-col gap-1.5">
        <p className="text-base font-semibold text-slate-50">Algo salió mal</p>
        <p className="text-sm text-slate-400 max-w-sm">{message}</p>
      </div>
      {retry && (
        <Button variant="outline" size="sm" onClick={retry}>
          Reintentar
        </Button>
      )}
    </div>
  )
}
