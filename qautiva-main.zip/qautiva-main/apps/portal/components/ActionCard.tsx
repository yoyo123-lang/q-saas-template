import Link from 'next/link'

type BadgeVariant = 'warning' | 'active' | 'in-progress' | 'error'

type ActionCardProps = {
  stageTitle: string
  badge: {
    label: string
    variant: BadgeVariant
  }
  description: string
  actionLabel?: string
  actionHref?: string
}

const badgeStyles: Record<BadgeVariant, string> = {
  warning: 'bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30',
  active: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30',
  'in-progress': 'bg-[#3B82F6]/15 text-[#3B82F6] border border-[#3B82F6]/30',
  error: 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30',
}

export function ActionCard({
  stageTitle,
  badge,
  description,
  actionLabel,
  actionHref,
}: ActionCardProps) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl overflow-hidden">
      <div className="flex">
        <div className="w-1 bg-[#8B5CF6] flex-shrink-0 rounded-l-xl" />
        <div className="flex-1 p-5">
          <div className="flex items-start justify-between gap-3 mb-3">
            <h2 className="text-white font-bold text-lg leading-tight">{stageTitle}</h2>
            <span className={`text-xs font-medium px-2.5 py-1 rounded-full flex-shrink-0 ${badgeStyles[badge.variant]}`}>
              {badge.label}
            </span>
          </div>

          <p className="text-[#94A3B8] text-sm leading-relaxed mb-4">{description}</p>

          {actionLabel && actionHref && (
            <Link
              href={actionHref}
              className="inline-block px-4 py-2 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200"
            >
              {actionLabel}
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}
