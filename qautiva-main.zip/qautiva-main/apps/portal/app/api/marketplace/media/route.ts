import { NextRequest, NextResponse } from 'next/server'
import { revalidateTag } from 'next/cache'
import { prisma } from '@qautiva/db'
import { MediumPlatform, MediumStatus, Prisma } from '@qautiva/db'
import { getProfileOrUnauthorized } from '@/lib/api/marketplace-helpers'

// ── Serialización ─────────────────────────────────────────────────────────────

// Prisma retorna Decimal como objetos Decimal.js — los convertimos a number para JSON
function serializeProducts(products: Array<{ price: Prisma.Decimal } & Record<string, unknown>>) {
  return products.map((p) => ({ ...p, price: p.price.toNumber() }))
}

// ── GET /api/marketplace/media ────────────────────────────────────────────────
// Público: no requiere autenticación.
// Retorna medios activos con filtros, include de categorías/productos y paginación.

export async function GET(request: NextRequest): Promise<NextResponse> {
  const sp = request.nextUrl.searchParams

  const platform = sp.get('platform')
  const categoryId = sp.get('categoryId')
  const country = sp.get('country')
  const sort = sp.get('sort') ?? 'relevancia'
  const page = Math.max(1, parseInt(sp.get('page') ?? '1', 10))
  const take = Math.min(50, Math.max(1, parseInt(sp.get('take') ?? '12', 10)))
  const minFollowers = sp.get('minFollowers')
  const maxFollowers = sp.get('maxFollowers')
  const minPrice = sp.get('minPrice')
  const maxPrice = sp.get('maxPrice')

  // Validaciones de query params
  if (platform && !Object.values(MediumPlatform).includes(platform as MediumPlatform)) {
    return NextResponse.json({ error: 'Plataforma inválida' }, { status: 400 })
  }
  if (minFollowers && isNaN(parseInt(minFollowers, 10))) {
    return NextResponse.json({ error: 'minFollowers debe ser un número entero' }, { status: 400 })
  }
  if (maxFollowers && isNaN(parseInt(maxFollowers, 10))) {
    return NextResponse.json({ error: 'maxFollowers debe ser un número entero' }, { status: 400 })
  }
  if (minPrice && isNaN(parseFloat(minPrice))) {
    return NextResponse.json({ error: 'minPrice debe ser un número válido' }, { status: 400 })
  }
  if (maxPrice && isNaN(parseFloat(maxPrice))) {
    return NextResponse.json({ error: 'maxPrice debe ser un número válido' }, { status: 400 })
  }

  const where: Prisma.MediumWhereInput = {
    status: MediumStatus.ACTIVE,
    deletedAt: null,
    ...(platform ? { platform: platform as MediumPlatform } : {}),
    ...(country ? { country } : {}),
    ...(minFollowers ?? maxFollowers
      ? {
          followersCount: {
            ...(minFollowers ? { gte: parseInt(minFollowers, 10) } : {}),
            ...(maxFollowers ? { lte: parseInt(maxFollowers, 10) } : {}),
          },
        }
      : {}),
    ...(categoryId ? { categories: { some: { categoryId } } } : {}),
    ...(minPrice ?? maxPrice
      ? {
          products: {
            some: {
              active: true,
              price: {
                ...(minPrice ? { gte: new Prisma.Decimal(minPrice) } : {}),
                ...(maxPrice ? { lte: new Prisma.Decimal(maxPrice) } : {}),
              },
            },
          },
        }
      : {}),
  }

  const orderBy: Prisma.MediumOrderByWithRelationInput =
    sort === 'seguidores-desc'
      ? { followersCount: 'desc' }
      : // precio-asc / precio-desc: Prisma no soporta ORDER BY MIN(products.price) sin SQL raw
        // Por ahora fallback a createdAt desc. Implementar con $queryRaw cuando sea prioritario.
        { createdAt: 'desc' }

  const [media, total] = await Promise.all([
    prisma.medium.findMany({
      where,
      orderBy,
      skip: (page - 1) * take,
      take,
      include: {
        categories: {
          include: {
            category: { select: { id: true, name: true, slug: true } },
          },
        },
        products: {
          where: { active: true },
          select: {
            id: true,
            type: true,
            name: true,
            price: true,
            deliveryDays: true,
          },
          orderBy: { price: 'asc' },
        },
        user: { select: { displayName: true, avatarUrl: true } },
      },
    }),
    prisma.medium.count({ where }),
  ])

  const serialized = media.map((m) => ({
    ...m,
    products: serializeProducts(m.products),
  }))

  return NextResponse.json({
    media: serialized,
    pagination: { page, take, total, pages: Math.ceil(total / take) },
  })
}

// ── POST /api/marketplace/media ───────────────────────────────────────────────
// Crea un medio nuevo para el editor autenticado.
// El medio queda en estado PENDING_REVIEW hasta que un admin lo apruebe.

type CreateMediumBody = {
  platform: string
  name: string
  url?: string
  description?: string
  country?: string
  language?: string
  followersCount?: number
  monthlyVisits?: number
  domainAuthority?: number
  categoryIds?: string[]
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: CreateMediumBody
  try {
    body = (await request.json()) as CreateMediumBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { platform, name, url, description, country, language, followersCount, monthlyVisits, domainAuthority, categoryIds } = body

  if (!platform || !Object.values(MediumPlatform).includes(platform as MediumPlatform)) {
    return NextResponse.json({ error: 'Plataforma inválida o requerida' }, { status: 400 })
  }
  if (!name || name.trim().length < 3 || name.trim().length > 100) {
    return NextResponse.json({ error: 'El nombre debe tener entre 3 y 100 caracteres' }, { status: 400 })
  }
  // url es NOT NULL en el schema — requerida para todas las plataformas
  // (para webs: URL del sitio; para redes sociales: URL pública del perfil)
  if (!url || !url.trim()) {
    return NextResponse.json({ error: 'La URL del medio es requerida' }, { status: 400 })
  }
  if (description && description.length > 1000) {
    return NextResponse.json({ error: 'La descripción no puede superar los 1000 caracteres' }, { status: 400 })
  }
  if (followersCount !== undefined && (typeof followersCount !== 'number' || followersCount < 0)) {
    return NextResponse.json({ error: 'followersCount debe ser un número mayor o igual a 0' }, { status: 400 })
  }
  if (monthlyVisits !== undefined && (typeof monthlyVisits !== 'number' || monthlyVisits < 0)) {
    return NextResponse.json({ error: 'monthlyVisits debe ser un número mayor o igual a 0' }, { status: 400 })
  }
  if (domainAuthority !== undefined && (typeof domainAuthority !== 'number' || domainAuthority < 0 || domainAuthority > 100)) {
    return NextResponse.json({ error: 'domainAuthority debe ser un número entre 0 y 100' }, { status: 400 })
  }
  if (categoryIds && categoryIds.length > 0) {
    const found = await prisma.category.findMany({ where: { id: { in: categoryIds } }, select: { id: true } })
    if (found.length !== categoryIds.length) {
      return NextResponse.json({ error: 'Una o más categorías no existen' }, { status: 400 })
    }
  }

  try {
    const medium = await prisma.medium.create({
      data: {
        userId: profile.id,
        platform: platform as MediumPlatform,
        name: name.trim(),
        url: url.trim(),
        description: description?.trim() ?? null,
        country: country?.trim() || undefined,
        language: language?.trim() || undefined,
        followersCount: followersCount ?? null,
        monthlyVisits: monthlyVisits ?? null,
        domainAuthority: domainAuthority ?? null,
        ...(categoryIds && categoryIds.length > 0
          ? { categories: { create: categoryIds.map((categoryId) => ({ categoryId })) } }
          : {}),
      },
    })

    console.info('[POST /api/marketplace/media]', { mediumId: medium.id, userId: profile.id })
    revalidateTag('marketplace-catalog')
    return NextResponse.json({ medium }, { status: 201 })
  } catch (err) {
    console.error('[POST /api/marketplace/media] Prisma create failed', {
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al crear el medio' }, { status: 500 })
  }
}

// ── PATCH /api/marketplace/media ──────────────────────────────────────────────
// Actualiza un medio del editor autenticado. Solo el propietario puede editar.

type UpdateMediumBody = {
  id: string
  name?: string
  url?: string
  description?: string
  country?: string
  language?: string
  followersCount?: number
  monthlyVisits?: number
  domainAuthority?: number
  status?: 'PAUSED' | 'ACTIVE'  // Editor solo puede pausar/reactivar
  categoryIds?: string[]
}

export async function PATCH(request: NextRequest): Promise<NextResponse> {
  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: UpdateMediumBody
  try {
    body = (await request.json()) as UpdateMediumBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { id, name, url, description, country, language, followersCount, monthlyVisits, domainAuthority, status, categoryIds } = body

  if (!id) {
    return NextResponse.json({ error: 'El campo id es requerido' }, { status: 400 })
  }

  // Validaciones opcionales
  if (name !== undefined && (name.trim().length < 3 || name.trim().length > 100)) {
    return NextResponse.json({ error: 'El nombre debe tener entre 3 y 100 caracteres' }, { status: 400 })
  }
  if (description !== undefined && description.length > 1000) {
    return NextResponse.json({ error: 'La descripción no puede superar los 1000 caracteres' }, { status: 400 })
  }
  if (status !== undefined && !['PAUSED', 'ACTIVE'].includes(status)) {
    return NextResponse.json({ error: 'El editor solo puede pausar (PAUSED) o reactivar (ACTIVE) un medio' }, { status: 400 })
  }
  if (categoryIds && categoryIds.length > 0) {
    const found = await prisma.category.findMany({ where: { id: { in: categoryIds } }, select: { id: true } })
    if (found.length !== categoryIds.length) {
      return NextResponse.json({ error: 'Una o más categorías no existen' }, { status: 400 })
    }
  }

  // Ownership check
  const existing = await prisma.medium.findUnique({
    where: { id },
    select: { userId: true, deletedAt: true, status: true },
  })
  if (!existing || existing.deletedAt !== null) {
    return NextResponse.json({ error: 'Medio no encontrado' }, { status: 404 })
  }
  if (existing.userId !== profile.id) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }
  // Medios rechazados o suspendidos no se pueden editar (evita evadir moderación)
  if (existing.status === MediumStatus.REJECTED || existing.status === MediumStatus.SUSPENDED) {
    return NextResponse.json({ error: 'No podés editar un medio rechazado o suspendido' }, { status: 403 })
  }
  // Editor solo puede reactivar un medio que estaba pausado por él mismo
  if (status === 'ACTIVE' && existing.status !== MediumStatus.PAUSED) {
    return NextResponse.json({ error: 'Solo podés reactivar un medio que estaba pausado' }, { status: 409 })
  }

  try {
    const updated = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      if (categoryIds !== undefined) {
        await tx.mediumCategory.deleteMany({ where: { mediumId: id } })
        if (categoryIds.length > 0) {
          await tx.mediumCategory.createMany({
            data: categoryIds.map((categoryId) => ({ mediumId: id, categoryId })),
          })
        }
      }

      return tx.medium.update({
        where: { id },
        data: {
          ...(name !== undefined ? { name: name.trim() } : {}),
          ...(url !== undefined ? { url: url.trim() } : {}),
          ...(description !== undefined ? { description: description.trim() } : {}),
          ...(country !== undefined ? { country: country.trim() } : {}),
          ...(language !== undefined ? { language: language.trim() } : {}),
          ...(followersCount !== undefined ? { followersCount } : {}),
          ...(monthlyVisits !== undefined ? { monthlyVisits } : {}),
          ...(domainAuthority !== undefined ? { domainAuthority } : {}),
          ...(status !== undefined ? { status: status as MediumStatus } : {}),
        },
      })
    })

    console.info('[PATCH /api/marketplace/media]', { mediumId: id, userId: profile.id })
    revalidateTag('marketplace-catalog')
    return NextResponse.json({ medium: updated })
  } catch (err) {
    console.error('[PATCH /api/marketplace/media] Prisma update failed', {
      mediumId: id,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al actualizar el medio' }, { status: 500 })
  }
}

// ── DELETE /api/marketplace/media ─────────────────────────────────────────────
// Soft delete: setea deletedAt. Solo el propietario puede eliminar.

export async function DELETE(request: NextRequest): Promise<NextResponse> {
  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: { id: string }
  try {
    body = (await request.json()) as { id: string }
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { id } = body
  if (!id) {
    return NextResponse.json({ error: 'El campo id es requerido' }, { status: 400 })
  }

  // Ownership check
  const existing = await prisma.medium.findUnique({
    where: { id },
    select: { userId: true, deletedAt: true },
  })
  if (!existing || existing.deletedAt !== null) {
    return NextResponse.json({ error: 'Medio no encontrado' }, { status: 404 })
  }
  if (existing.userId !== profile.id) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  try {
    await prisma.medium.update({
      where: { id },
      data: { deletedAt: new Date() },
    })

    console.info('[DELETE /api/marketplace/media]', { mediumId: id, userId: profile.id })
    revalidateTag('marketplace-catalog')
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[DELETE /api/marketplace/media] Prisma update failed', {
      mediumId: id,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al eliminar el medio' }, { status: 500 })
  }
}
