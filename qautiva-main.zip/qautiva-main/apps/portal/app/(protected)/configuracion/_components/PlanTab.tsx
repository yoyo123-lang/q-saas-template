import { InfoRow } from './InfoRow'

const BILLING_PLAN_LABELS: Record<string, string> = {
  FREE_TRIAL: 'Prueba gratuita',
  PREPAID: 'Prepago',
  MONTHLY: 'Mensual',
  YEARLY: 'Anual',
}

const KEY_SOURCE_LABELS: Record<string, string> = {
  BYOK: 'Tus propias keys',
  QAUTIVA_HOSTED: 'Keys de Qautiva',
}

type BillingData = {
  plan: string
  preferredKeySource: string
  trialTokensTotal: number
  trialTokensUsed: number
  trialExpiresAt: Date | string | null
  tokenQuota: number
  tokensUsed: number
  currentPeriodStart: Date | string | null
  currentPeriodEnd: Date | string | null
  balanceUsd: string
}

type OrgData = {
  plan: string
  status: string
}

type Props = {
  billing: BillingData | null
  orgData: OrgData | null
  isLegacy: boolean
}

function TokenBar({ used, total }: { used: number; total: number }) {
  const pct = total > 0 ? Math.min((used / total) * 100, 100) : 0
  const color = pct >= 90 ? '#EF4444' : pct >= 70 ? '#F59E0B' : '#8B5CF6'

  return (
    <div className="flex flex-col gap-1">
      <div className="flex justify-between text-xs text-[#94A3B8]">
        <span>{used.toLocaleString('es-AR')} tokens usados</span>
        <span>{total.toLocaleString('es-AR')} total</span>
      </div>
      <div className="h-2 bg-[#1E293B] rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, backgroundColor: color }}
        />
      </div>
    </div>
  )
}

export function PlanTab({ billing, isLegacy }: Props) {
  if (!billing && !isLegacy) {
    return (
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
        <p className="text-[#94A3B8] text-sm">No hay información de facturación disponible.</p>
      </div>
    )
  }

  const isTrial = billing?.plan === 'FREE_TRIAL'

  const trialExpiry = billing?.trialExpiresAt
    ? new Date(billing.trialExpiresAt).toLocaleDateString('es-AR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      })
    : null

  const trialExpired =
    billing?.trialExpiresAt ? new Date(billing.trialExpiresAt) < new Date() : false

  const periodStart = billing?.currentPeriodStart
    ? new Date(billing.currentPeriodStart).toLocaleDateString('es-AR', { day: 'numeric', month: 'short', year: 'numeric' })
    : null
  const periodEnd = billing?.currentPeriodEnd
    ? new Date(billing.currentPeriodEnd).toLocaleDateString('es-AR', { day: 'numeric', month: 'short', year: 'numeric' })
    : null

  return (
    <div className="flex flex-col gap-6">
      {/* Plan actual */}
      <section>
        <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
          Tu plan
        </h2>
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl px-5">
          {billing && (
            <>
              <InfoRow
                label="Plan"
                value={BILLING_PLAN_LABELS[billing.plan] ?? billing.plan}
              />
              <InfoRow
                label="Fuente de keys"
                value={KEY_SOURCE_LABELS[billing.preferredKeySource] ?? billing.preferredKeySource}
              />
              {parseFloat(billing.balanceUsd) > 0 && (
                <InfoRow
                  label="Balance"
                  value={`USD $${parseFloat(billing.balanceUsd).toFixed(2)}`}
                />
              )}
            </>
          )}
        </div>
      </section>

      {/* Uso de tokens */}
      {billing && (
        <section>
          <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
            Uso de tokens
          </h2>
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4">
            {isTrial ? (
              <>
                <TokenBar used={billing.trialTokensUsed} total={billing.trialTokensTotal} />
                {trialExpiry && (
                  <div className="flex items-center justify-between">
                    <span className="text-[#94A3B8] text-sm">
                      {trialExpired ? 'Tu prueba gratuita venció el' : 'Tu prueba gratuita vence el'}
                    </span>
                    <span className={`text-sm font-medium ${trialExpired ? 'text-[#EF4444]' : 'text-white'}`}>
                      {trialExpiry}
                      {trialExpired && (
                        <span className="ml-2 bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-xs px-2 py-0.5 rounded-full">
                          Expirado
                        </span>
                      )}
                    </span>
                  </div>
                )}
              </>
            ) : (
              <>
                <TokenBar used={billing.tokensUsed} total={billing.tokenQuota} />
                {periodStart && periodEnd && (
                  <InfoRow label="Período" value={`${periodStart} — ${periodEnd}`} />
                )}
              </>
            )}
          </div>
        </section>
      )}

      <p className="text-[#64748B] text-xs">
        ¿Necesitás cambiar de plan? Escribinos a{' '}
        <a href="mailto:hola@qautiva.ar" className="text-[#A78BFA] hover:underline">
          hola@qautiva.ar
        </a>
      </p>
    </div>
  )
}
