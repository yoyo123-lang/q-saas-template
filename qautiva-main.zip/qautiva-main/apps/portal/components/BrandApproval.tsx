'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { BrandOption, ColorSwatch } from '@/app/_lib/interview/types'

export type { BrandOption, ColorSwatch }

type BrandApprovalProps = {
  deliverableId: string
  projectId: string
  title: string
  options: BrandOption[]
  disclaimer?: string
  canApprove: boolean // false si ya fue aprobado/rechazado
}

/** Regex para validar hex de color antes de pasarlo a CSS backgroundColor. */
const HEX_REGEX = /^#[0-9A-Fa-f]{6}$/

function ColorPalette({ colors }: { colors: ColorSwatch[] }) {
  return (
    <div className="flex gap-2 flex-wrap">
      {colors.map((c) => (
        <div key={c.hex} className="flex flex-col items-center gap-1">
          <div
            className="w-8 h-8 rounded-full border border-[#1E293B]"
            // Sanitización: si el hex es inválido, fallback a color neutro para evitar
            // que CSS procese un valor arbitrario proveniente del JSON del deliverable.
            style={{ backgroundColor: HEX_REGEX.test(c.hex) ? c.hex : '#64748B' }}
            title={c.name}
          />
          <span className="text-[#64748B] text-[10px] font-mono">{c.hex}</span>
        </div>
      ))}
    </div>
  )
}

/**
 * Componente de aprobación de opciones de marca (tipo BRAND_OPTIONS).
 * Muestra las opciones disponibles con colores, tipografías y logo.
 * El cliente selecciona una opción y puede aprobar (guardando selectedOptionId en feedback)
 * o rechazar con feedback textual. Ver ADR-0003 para la convención del campo feedback.
 * @param canApprove - false si el entregable ya fue procesado (deshabilita acciones)
 * @param disclaimer - texto explicativo sobre las opciones (generado por brand-generator)
 */
export function BrandApproval({
  deliverableId,
  projectId,
  title,
  options,
  disclaimer,
  canApprove,
}: BrandApprovalProps) {
  const router = useRouter()
  const [selected, setSelected] = useState<string | null>(null)
  const [feedback, setFeedback] = useState('')
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  async function handleAction(action: 'approve' | 'reject') {
    if (action === 'reject' && feedback.trim().length === 0) {
      setError('Escribí tu feedback antes de pedir cambios.')
      return
    }
    setError(null)

    startTransition(async () => {
      const res = await fetch(`/api/deliverables/${deliverableId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, feedback: feedback.trim(), selectedOptionId: selected }),
      })

      if (!res.ok) {
        const data = await res.json() as { error?: string }
        setError(data.error ?? 'Ocurrió un error. Intentalo de nuevo.')
        return
      }

      setDone(true)
      router.push(`/proyectos/${projectId}/progreso`)
    })
  }

  if (done) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <p className="text-[#94A3B8]">Procesando tu respuesta...</p>
      </div>
    )
  }

  // Guard: no debería ocurrir en condiciones normales, pero protege el render.
  if (options.length === 0) {
    return (
      <div className="p-8 max-w-5xl">
        <h1 className="text-2xl font-bold text-white mb-4">{title}</h1>
        <div className="bg-[#1E293B] border border-[#334155] rounded-lg px-6 py-8 text-center">
          <p className="text-[#94A3B8]">No hay opciones de marca disponibles.</p>
          <p className="text-[#64748B] text-sm mt-2">Contactá a soporte si el problema persiste.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-8 max-w-5xl">
      <h1 className="text-2xl font-bold text-white mb-2">{title}</h1>
      <p className="text-[#94A3B8] mb-4">Elegí la opción que más te gusta</p>

      {/* Disclaimer de IA */}
      {disclaimer && (
        <div className="bg-[#1E293B] border border-[#334155] rounded-lg px-4 py-3 mb-8">
          <p className="text-[#94A3B8] text-sm">{disclaimer}</p>
        </div>
      )}

      {/* Grid de opciones */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {options.map((opt) => (
          <button
            key={opt.id}
            type="button"
            disabled={!canApprove || isPending}
            onClick={() => setSelected(opt.id)}
            className={`
              text-left bg-[#0F172A] rounded-xl p-5 border-2 transition-all duration-200
              ${selected === opt.id
                ? 'border-[#8B5CF6] shadow-[0_0_20px_rgba(139,92,246,0.15)]'
                : 'border-[#1E293B] hover:border-[#8B5CF6]/40'
              }
              ${!canApprove ? 'opacity-60 cursor-default' : 'cursor-pointer'}
            `}
          >
            <p className="text-[#A78BFA] text-xs font-semibold uppercase tracking-wider mb-3">
              {opt.label}
            </p>

            {/* Logo */}
            {opt.logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={opt.logoUrl}
                alt={`Logo ${opt.label}`}
                loading="lazy"
                className="w-full h-24 object-contain rounded-lg bg-[#1E293B] mb-4"
              />
            ) : (
              // Logo no generado: indicar al usuario que puede elegir esta opción igual.
              // La degradación (1/3 logos fallido) es informativa, no bloquea la selección.
              <div
                className="w-full h-24 rounded-lg bg-[#1E293B] border border-dashed border-[#334155] flex flex-col items-center justify-center mb-4 gap-1"
                title="El logo no pudo generarse. Podés elegir esta opción igual."
              >
                <span className="text-[#64748B] text-xs">Vista previa no disponible</span>
                <span className="text-[#475569] text-[10px]">Podés seleccionarla igual</span>
              </div>
            )}

            {/* Paleta */}
            <div className="mb-3">
              <p className="text-[#64748B] text-xs mb-2">Colores</p>
              <ColorPalette colors={opt.colors} />
            </div>

            {/* Tipografía */}
            <div className="mb-3">
              <p className="text-[#64748B] text-xs mb-1">Tipografía</p>
              <p className="text-[#94A3B8] text-sm">{opt.headingFont} / {opt.bodyFont}</p>
            </div>

            {/* Personalidad de marca */}
            {opt.brandPersonality && opt.brandPersonality.length > 0 && (
              <div>
                <p className="text-[#64748B] text-xs mb-2">Personalidad</p>
                <div className="flex flex-wrap gap-1">
                  {opt.brandPersonality.map((trait) => (
                    <span
                      key={trait}
                      className="px-2 py-0.5 rounded-full bg-[#1E293B] border border-[#334155] text-[#94A3B8] text-[10px]"
                    >
                      {trait}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Barra inferior */}
      {canApprove && (
        <div className="sticky bottom-0 bg-[#0B0F1A] border-t border-[#1E293B] pt-4 pb-2">
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <label htmlFor="brand-feedback" className="text-[#94A3B8] text-xs mb-1.5 block">
                Feedback o pedido de cambios (opcional para aprobar, obligatorio para rechazar)
              </label>
              <textarea
                id="brand-feedback"
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Escribí tu feedback o pedí cambios..."
                rows={2}
                className="w-full bg-[#1E293B] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-3 py-2 text-white text-sm placeholder-[#64748B] resize-none outline-none transition-colors duration-200"
              />
              {error && <p className="text-[#EF4444] text-xs mt-1">{error}</p>}
            </div>
            <div className="flex gap-2 flex-shrink-0 pb-[2px]">
              <button
                type="button"
                disabled={isPending}
                onClick={() => handleAction('reject')}
                className="px-4 py-2 rounded-lg border border-[#1E293B] text-[#94A3B8] hover:text-white hover:border-[#EF4444]/50 text-sm font-medium transition-colors duration-200 disabled:opacity-50"
              >
                Necesito más opciones
              </button>
              <button
                type="button"
                disabled={isPending || selected === null}
                onClick={() => handleAction('approve')}
                className="px-5 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#A78BFA] text-white text-sm font-medium transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isPending ? 'Enviando...' : 'Confirmar selección'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
