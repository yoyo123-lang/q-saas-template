# Revisión: Data & Analytics Reviewer
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de Data & Analytics Reviewer (Capa 2)

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 1 alto, 2 medios, 1 bajo
- Contrato base: `docs/BUSINESS_MODEL.md` §Métricas clave y §Eventos de funnel

## Hallazgos

### [ALTO → CORREGIDO] Evento `listing_viewed` no se registraba en AuditLog
- Dónde: `src/lib/data/listings.ts:incrementListingViews`
- Evento requerido: BUSINESS_MODEL.md §Eventos de funnel: `listing_viewed` — prioridad Media.
- Problema: La función solo hacía `viewCount++` sin crear el registro de audit. El equipo no podría saber cuándo se vio un listing específico, ni qué listado es más visto por periodo.
- Fix aplicado: `incrementListingViews` ahora ejecuta en `Promise.all`:
  1. `listing.update({ viewCount: { increment: 1 } })`
  2. `auditLog.create({ action: 'LISTING_VIEWED', entityType: 'listing', entityId: id, actorId: null })`

### [MEDIO] Los 6 eventos de funnel de alta prioridad no están implementados aún
- Eventos faltantes: `signup_completed`, `listing_created`, `listing_submitted`, `listing_published`, `inquiry_sent`, `inquiry_replied`, `inquiry_converted`, `favorite_added`.
- Contexto: Estos eventos corresponden a Sesiones 03–06 (auth, formulario de listing, consultas). No son un bug de esta sesión, sino un recordatorio para las próximas.
- Recomendación: Crear un módulo centralizado `src/lib/analytics/events.ts` que defina y dispare todos los eventos cuando se implementen las acciones correspondientes.

### [MEDIO] `actorId: null` en `listing_viewed` — no se puede segmentar por usuario
- Dónde: `src/lib/data/listings.ts:157`
- Problema: Las vistas registradas en AuditLog no tienen `actorId` porque en SSR público no hay sesión disponible. No se puede calcular visitantes únicos por usuario registrado.
- Aceptable en MVP: En Sesión 05, cuando haya auth en SSR, pasar el `userId` de la cookie de sesión.
- Recomendación: Dejar comentario en el código recordando pasar `actorId` cuando esté disponible.

### [BAJO] No hay módulo centralizado de eventos de analytics
- Dónde: `src/lib/analytics/` (no existe)
- Problema: BUSINESS_MODEL.md lista 9 eventos de funnel. Actualmente el único evento implementado (`LISTING_VIEWED`) está disperso en el DAL. Si se sigue este patrón, cada módulo tendrá su propia lógica de tracking inconsistente.
- Recomendación: Crear `src/lib/analytics/events.ts` con funciones tipadas antes de implementar el siguiente evento. Ejemplo: `trackEvent(action: AuditAction, entityType: string, entityId: string, actorId?: string)`.

## Eventos del funnel verificados

| Evento | Estado | Dónde se disparará |
|--------|--------|--------------------|
| `signup_completed` | ⏳ Pendiente | Sesión 03 (auth) |
| `listing_created` | ⏳ Pendiente | Sesión 04 (formulario listing) |
| `listing_submitted` | ⏳ Pendiente | Sesión 04 |
| `listing_published` | ⏳ Pendiente | Sesión 05 (admin) |
| `listing_viewed` | ✅ Implementado | `src/lib/data/listings.ts` |
| `inquiry_sent` | ⏳ Pendiente | Sesión 06 (consultas) |
| `inquiry_replied` | ⏳ Pendiente | Sesión 06 |
| `inquiry_converted` | ⏳ Pendiente | Sesión 06 |
| `favorite_added` | ⏳ Pendiente | Sesión 05 |

## Métricas de negocio medibles con datos actuales

| Métrica | Medible ahora | Notas |
|---------|---------------|-------|
| Total listados activos | ✅ `COUNT(listings WHERE status=PUBLISHED)` | |
| Listados por tipo | ✅ `GROUP BY type` | |
| Tasa de aprobación | ⏳ Parcial | Requiere datos de PENDING_REVIEW + PUBLISHED |
| Consultas activas | ⏳ Pendiente | Módulo de consultas no implementado aún |
| GMV potencial | ✅ `SUM(askingPrice WHERE status=PUBLISHED)` | |
| Usuarios registrados | ✅ `COUNT(profiles) GROUP BY role` | |

## Lo que está bien
- AuditLog en schema tiene índices en `action`, `entityType+entityId`, `createdAt` — queries de analytics serán eficientes ✓
- El enum `AuditAction` tiene todos los eventos del funnel pre-definidos ✓
- Cookie de deduplicación garantiza que los views en AuditLog son más representativos que simples refreshes ✓

## Recomendaciones generales
- Crear `src/lib/analytics/events.ts` como módulo centralizado antes de la Sesión 03.
- Pasar `actorId` a `listing_viewed` cuando la sesión esté disponible (Sesión 05).
- Considerar integrar PostHog o Plausible para analytics de producto complementario.
