import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

const VALID_MARGIN_TYPES = ['PERCENTAGE', 'FIXED_ARS'] as const
type MarginType = typeof VALID_MARGIN_TYPES[number]

function isValidMarginType(value: unknown): value is MarginType {
  return typeof value === 'string' && (VALID_MARGIN_TYPES as readonly string[]).includes(value)
}

export async function POST(request: NextRequest) {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  if (typeof body !== 'object' || body === null) {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { id, marginType, marginValue, isActive } = body as Record<string, unknown>

  if (typeof id !== 'string' || !id) {
    return NextResponse.json({ error: 'id requerido' }, { status: 400 })
  }
  if (!isValidMarginType(marginType)) {
    return NextResponse.json({ error: 'marginType inválido' }, { status: 400 })
  }
  if (typeof marginValue !== 'number' || marginValue < 0 || !isFinite(marginValue)) {
    return NextResponse.json({ error: 'marginValue inválido' }, { status: 400 })
  }
  if (typeof isActive !== 'boolean') {
    return NextResponse.json({ error: 'isActive requerido' }, { status: 400 })
  }

  const existing = await prisma.tldPricing.findUnique({ where: { id }, select: { id: true } })
  if (!existing) {
    return NextResponse.json({ error: 'TLD no encontrado' }, { status: 404 })
  }

  const updated = await prisma.tldPricing.update({
    where: { id },
    data: { marginType, marginValue, isActive },
    select: { id: true, tld: true, marginType: true, marginValue: true, isActive: true },
  })

  return NextResponse.json({
    tldPricing: { ...updated, marginValue: updated.marginValue.toString() },
  })
}
