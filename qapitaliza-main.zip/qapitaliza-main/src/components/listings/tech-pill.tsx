interface TechPillProps {
  tech: string
}

export function TechPill({ tech }: TechPillProps) {
  return (
    <span className="font-mono text-xs bg-slate-800 text-slate-50 px-3 py-1 rounded-full">
      {tech}
    </span>
  )
}
