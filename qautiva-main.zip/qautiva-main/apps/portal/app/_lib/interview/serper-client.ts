/**
 * Cliente para Serper API (https://serper.dev).
 * Lee la API key de IntegrationConfig en la DB (encriptada con AES-256-GCM).
 *
 * Si no hay key configurada, las funciones retornan null (degradación elegante).
 * Solo server-side. Nunca importar en Client Components.
 */
import { createDecipheriv } from 'crypto'
import { prisma } from '@qautiva/db'

// ── Tipos ─────────────────────────────────────────────────────────────────────

export type SerperSearchResult = {
  organic: Array<{ title: string; link: string; snippet: string; position: number }>
  peopleAlsoAsk?: Array<{ question: string; snippet: string }>
  relatedSearches?: Array<{ query: string }>
}

export type SerperPlacesResult = {
  places: Array<{
    title: string
    address: string
    rating: number
    reviews: number
    website?: string
    phone?: string
    category?: string
  }>
}

// ── Decryption (copiado de apps/admin/lib/encryption.ts) ──────────────────────

function decrypt(encoded: string): string {
  const secret = process.env.INTEGRATION_ENCRYPTION_KEY
  if (!secret) {
    throw new Error('INTEGRATION_ENCRYPTION_KEY is not set')
  }
  const key = Buffer.from(secret, 'base64')
  if (key.length !== 32) {
    throw new Error(`INTEGRATION_ENCRYPTION_KEY must decode to exactly 32 bytes, got ${key.length}`)
  }
  const parts = encoded.split(':')
  if (parts.length !== 3) {
    throw new Error('Invalid encrypted format: expected {iv}:{ciphertext}:{authTag}')
  }
  const iv = Buffer.from(parts[0]!, 'base64')
  const ciphertext = Buffer.from(parts[1]!, 'base64')
  const authTag = Buffer.from(parts[2]!, 'base64')

  const decipher = createDecipheriv('aes-256-gcm', key, iv, { authTagLength: 16 })
  decipher.setAuthTag(authTag)

  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8')
}

// ── Cache de API key ───────────────────────────────────────────────────────────

// Cache con TTL para permitir rotación de key sin restart del servidor.
// undefined = no intentado aún | null = intentado, no hay key | string = key activa
let _cachedApiKey: string | null | undefined = undefined
let _cacheTime = 0
const CACHE_TTL_MS = 5 * 60 * 1000 // 5 minutos

/**
 * Lee la Serper API key de IntegrationConfig en la DB y la desencripta.
 * Cache en memoria con TTL de 5 minutos (permite rotación de key sin restart).
 *
 * @returns La API key desencriptada, o null si no hay key configurada.
 */
async function getSerperApiKey(): Promise<string | null> {
  if (_cachedApiKey !== undefined && Date.now() - _cacheTime < CACHE_TTL_MS) return _cachedApiKey

  const config = await prisma.integrationConfig.findUnique({
    where: { service: 'SERPER' },
    select: { isActive: true, encryptedKey: true },
  })

  if (!config?.isActive || !config.encryptedKey) {
    _cachedApiKey = null
    _cacheTime = Date.now()
    return null
  }

  try {
    _cachedApiKey = decrypt(config.encryptedKey)
    _cacheTime = Date.now()
  } catch {
    // No loguear el error completo para evitar exponer material criptográfico
    console.error('[serper-client] Error desencriptando Serper API key — verificar INTEGRATION_ENCRYPTION_KEY')
    _cachedApiKey = null
  }

  return _cachedApiKey
}

// ── Helpers de fetch ───────────────────────────────────────────────────────────

const SERPER_TIMEOUT_MS = 10_000

async function serperPost<T>(
  endpoint: '/search' | '/places',
  body: Record<string, unknown>,
  apiKey: string,
): Promise<T> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), SERPER_TIMEOUT_MS)

  try {
    const res = await fetch(`https://google.serper.dev${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': apiKey,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    })

    if (!res.ok) {
      throw new Error(`Serper ${endpoint} responded ${res.status}: ${await res.text()}`)
    }

    return (await res.json()) as T
  } finally {
    clearTimeout(timer)
  }
}

// ── Funciones públicas ─────────────────────────────────────────────────────────

/**
 * Búsqueda web con Serper.
 *
 * @returns SerperSearchResult, o null si no hay API key configurada o falla.
 */
export async function searchWeb(
  query: string,
  options: { gl?: string; hl?: string; num?: number } = {},
): Promise<SerperSearchResult | null> {
  const apiKey = await getSerperApiKey()
  if (!apiKey) return null

  try {
    return await serperPost<SerperSearchResult>(
      '/search',
      { q: query, gl: options.gl ?? 'ar', hl: options.hl ?? 'es', num: options.num ?? 10 },
      apiKey,
    )
  } catch (err) {
    throw err // Re-throw para que Promise.allSettled lo capture y loguee el caller
  }
}

/**
 * Búsqueda de lugares (Google Maps) con Serper.
 *
 * @returns SerperPlacesResult, o null si no hay API key configurada o falla.
 */
export async function searchPlaces(
  query: string,
  options: { gl?: string; hl?: string; location?: string } = {},
): Promise<SerperPlacesResult | null> {
  const apiKey = await getSerperApiKey()
  if (!apiKey) return null

  const body: Record<string, unknown> = {
    q: query,
    gl: options.gl ?? 'ar',
    hl: options.hl ?? 'es',
  }
  if (options.location) body['location'] = options.location

  try {
    return await serperPost<SerperPlacesResult>('/places', body, apiKey)
  } catch (err) {
    throw err // Re-throw para que Promise.allSettled lo capture y loguee el caller
  }
}
