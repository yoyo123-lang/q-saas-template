# Prompts para Gemini — Panel Admin

> Cada prompt es autocontenido. Copiá y pegá uno a la vez en Gemini.

---

## PROMPT 1: Dashboard Admin (`/admin`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales (sitios web, dominios, MVPs, proyectos). Panel de administración.

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A (negro azulado profundo)
- Fondo cards/sidebar: #0F172A (navy oscuro)
- Fondo hover/inputs: #1E293B (navy medio)
- Acento primario: #F59E0B (amber/dorado) — elementos destacados, CTAs
- Acento hover: #FBBF24
- Texto primario: #F8FAFC | Texto secundario: #94A3B8 | Texto apagado: #64748B
- Bordes: #1E293B
- Success: #10B981 | Warning: #F59E0B | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans (400, 500, 600, 700). Mono: JetBrains Mono.
Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" oscuro + "qapitaliza". Idioma: español argentino.

PÁGINA: Dashboard de administración del marketplace

ESTRUCTURA: Sidebar admin (280px) + contenido principal

SIDEBAR ADMIN (280px, fondo #0B0F1A, borde derecho #1E293B):
- Logo Q amber + "qapitaliza" + badge "Admin" (pill amber pequeña)
- Nav:
  - "Dashboard" — ACTIVO (barra izquierda 3px amber, texto amber) — ícono LayoutDashboard
  - "Listados" — con badge "4" rojo (pendientes de revisión) — ícono Package
  - "Usuarios" — ícono Users
  - "Reportes" — ícono BarChart3
- Divider
  - "Configuración" — ícono Settings
- Abajo: avatar + "Admin" + "admin@qapitaliza.com"

CONTENIDO (padding 32px):

a) HEADER
   - "Dashboard" (28px semibold #F8FAFC)
   - "Vista general del marketplace" (#94A3B8)
   - Selector de período: "Últimos 30 días ▾" (dropdown outline)

b) STAT CARDS — grilla 4 columnas (fondo #0F172A, borde #1E293B, rounded 12px):
   - "Listados totales": "127" (32px bold), "+8 este mes" (verde), ícono Package
   - "Usuarios registrados": "342" (32px bold), "+24 este mes" (verde), ícono Users
   - "Consultas activas": "47" (32px bold), "+15 esta semana" (verde), ícono MessageCircle
   - "Volumen listado": "$2.4M USD" (amber 32px bold), ícono DollarSign

c) GRÁFICOS — 2 columnas

   Gráfico izquierdo (card #0F172A, rounded 12px):
   - "Nuevos listados por semana"
   - Gráfico de barras: barras amber sobre fondo #0B0F1A, 8 semanas de datos
   - Valores: 3, 5, 4, 7, 6, 8, 5, 9

   Gráfico derecho (card #0F172A, rounded 12px):
   - "Registros de usuarios"
   - Gráfico de línea: línea amber con fill amber 10%, 30 días
   - Tendencia ascendente suave

d) SECCIÓN — "Pendientes de revisión" (card #0F172A, rounded 12px)
   - Heading: "Listados pendientes de revisión" + badge "4" rojo + link "Ver todos →" amber
   - Tabla compacta:

   | Activo | Vendedor | Tipo | Precio | Enviado | Acciones |
   |--------|----------|------|--------|---------|----------|
   | AppDelivery | Martín R. | MVP | $12,000 | Hace 2h | [Revisar] (amber) |
   | MiNegocio.ar | Ana L. | Web | $3,800 | Hace 5h | [Revisar] |
   | ToolBox.dev | Carlos M. | Tool | $8,500 | Hace 1d | [Revisar] |
   | EventosBA.com | Laura G. | Web | $5,200 | Hace 2d | [Revisar] |

e) SECCIÓN — "Actividad reciente" (card)
   - Lista con timeline:
     - "AppDelivery enviado a revisión por Martín R." — hace 2h — dot azul
     - "CryptoAlerts.io marcado como Destacado" — hace 4h — dot amber
     - "Nuevo usuario: Pedro Martínez" — hace 6h — dot verde
     - "Consulta cerrada: NotiTech.com" — hace 1d — dot gris
     - "Streaming.lat marcado como Vendido" — hace 2d — dot amber

f) SECCIÓN — Distribución por categoría (card, grilla 5 columnas mini)
   - Sitios Web: 42 (33%) — barra de progreso amber al 33%
   - SaaS/MVPs: 31 (24%) — barra 24%
   - Dominios: 28 (22%) — barra 22%
   - E-commerce: 18 (14%) — barra 14%
   - Proyectos: 8 (6%) — barra 6%
```

---

## PROMPT 2: Moderación de listados (`/admin/listados`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales. Panel de administración.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards/sidebar: #0F172A | Hover: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Warning: #F59E0B | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans. Mono: JetBrains Mono. Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" + badge "Admin". Idioma: español argentino.

PÁGINA: Moderación de listados — gestión de todos los activos del marketplace

ESTRUCTURA: Sidebar admin (280px, "Listados" activo con barra amber y badge "4" rojo) + contenido

CONTENIDO:

a) HEADER
   - "Gestión de listados" (28px semibold #F8FAFC)
   - "Moderá y administrá todos los activos del marketplace" (#94A3B8)

b) FILTROS
   - Tabs: "Todos (127)" | "Pendientes (4)" (con dot rojo) | "Publicados (108)" | "Destacados (6)" | "Rechazados (3)" | "Vendidos (6)"
   - Tab "Pendientes" activo (borde inferior amber)
   - Barra búsqueda + dropdown "Tipo: Todos ▾" + dropdown "Ordenar: Más recientes ▾"

c) TABLA DE LISTADOS (card #0F172A, rounded 12px)

   Headers: #64748B uppercase 12px tracking-wider

   | | Activo | Vendedor | Tipo | Precio | Estado | Fecha | Acciones |
   |--|--------|----------|------|--------|--------|-------|----------|
   | ☐ | [thumb] AppDelivery | Martín R. | MVP | $12,000 | ◎ Pendiente (amber) | 22 mar | [Aprobar ✓] [Rechazar ✗] [Ver] |
   | ☐ | [thumb] MiNegocio.ar | Ana López | Web | $3,800 | ◎ Pendiente (amber) | 22 mar | [Aprobar ✓] [Rechazar ✗] [Ver] |
   | ☐ | [thumb] ToolBox.dev | Carlos M. | Tool | $8,500 | ◎ Pendiente (amber) | 21 mar | [Aprobar ✓] [Rechazar ✗] [Ver] |
   | ☐ | [thumb] EventosBA.com | Laura G. | Web | $5,200 | ◎ Pendiente (amber) | 20 mar | [Aprobar ✓] [Rechazar ✗] [Ver] |

   Botones "Aprobar" en verde outline, "Rechazar" en rojo outline, "Ver" en gris outline.
   Checkbox para selección masiva. Barra de acciones masivas arriba cuando hay seleccionados: "2 seleccionados — [Aprobar todos] [Rechazar todos]"

   Filas con hover #1E293B. Cada fila tiene thumbnail del sitio a la izquierda (40x40, rounded 8px).

d) PANEL DE PREVIEW (se abre al hacer click en "Ver")
   - Slide-in panel desde la derecha (400px, fondo #0F172A, borde izquierdo #1E293B)
   - Screenshot del activo (grande)
   - Título + tipo + precio
   - Descripción completa
   - Métricas reportadas
   - Tech stack
   - Info del vendedor
   - Botones grandes: "Aprobar y publicar" (verde sólido) | "Rechazar" (rojo outline)
   - Campo "Motivo del rechazo" (textarea, solo visible si se clickea rechazar)

e) PAGINACIÓN
```

---

## PROMPT 3: Gestión de usuarios (`/admin/usuarios`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales. Panel de administración.

SISTEMA DE DISEÑO:

Paleta:
- Fondo: #0B0F1A | Cards/sidebar: #0F172A | Hover: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24
- Texto: #F8FAFC, #94A3B8, #64748B | Bordes: #1E293B
- Success: #10B981 | Warning: #F59E0B | Error: #EF4444

Tipografía: DM Sans. Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" + badge "Admin". Idioma: español argentino.

PÁGINA: Gestión de usuarios — administrar todos los usuarios del marketplace

ESTRUCTURA: Sidebar admin (280px, "Usuarios" activo) + contenido

CONTENIDO:

a) HEADER
   - "Usuarios" (28px semibold #F8FAFC)
   - "342 usuarios registrados" (#94A3B8)

b) STAT CARDS MINI — grilla 4 columnas
   - "Total": 342 | "Vendedores": 89 | "Compradores": 248 | "Suspendidos": 5 (rojo)
   Cards compactas fondo #0F172A, rounded 12px

c) FILTROS
   - Tabs: "Todos (342)" | "Vendedores (89)" | "Compradores (248)" | "Admins (3)" | "Suspendidos (5)"
   - Barra búsqueda: "Buscar por nombre o email..."
   - Dropdown: "Ordenar: Más recientes ▾"

d) TABLA (card #0F172A, rounded 12px)

   | Avatar | Nombre | Email | Rol | Listados | Registrado | Estado | Acciones |
   |--------|--------|-------|-----|----------|------------|--------|----------|
   | [MR] | Martín Rodríguez | martin@email.com | Vendedor (pill azul) | 12 | 15 ene 2025 | ● Activo (verde) | ⋯ |
   | [LG] | Laura García | laura@email.com | Compradora (pill violeta) | 0 | 3 mar 2025 | ● Activo (verde) | ⋯ |
   | [CM] | Carlos Méndez | carlos@email.com | Vendedor (azul) | 5 | 20 feb 2025 | ● Activo (verde) | ⋯ |
   | [AL] | Ana López | ana@email.com | Vendedora (azul) | 3 | 8 mar 2025 | ● Activo (verde) | ⋯ |
   | [FR] | Federico Ruiz | fede@email.com | Vendedor (azul) | 8 | 1 ene 2025 | ● Activo (verde) | ⋯ |
   | [PM] | Pedro Martínez | pedro@email.com | Comprador (violeta) | 0 | 12 mar 2026 | ● Activo (verde) | ⋯ |
   | [JD] | Juan Domínguez | juan@email.com | Comprador (violeta) | 0 | 5 feb 2026 | ⚠ Suspendido (rojo) | ⋯ |
   | [SV] | Sofía Vargas | sofia@email.com | Vendedora (azul) | 2 | 28 feb 2026 | ● Activo (verde) | ⋯ |

   Avatar: círculo 36px con iniciales, fondo amber para vendedores, fondo #3B82F6 para compradores.
   Menú ⋯: "Ver perfil" | "Cambiar rol" | "Suspender" | "Eliminar"

   Filas hover #1E293B. Headers uppercase #64748B.

e) PAGINACIÓN: « 1 2 3 ... 35 »
```
