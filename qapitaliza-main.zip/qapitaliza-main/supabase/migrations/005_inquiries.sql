-- ============================================================
-- 005 — Inquiries + Inquiry Messages
-- Sistema de consultas mediadas entre comprador y vendedor.
-- Depende de: 001 (profiles), 003 (listings)
-- Rollback: 005_inquiries_rollback.sql
-- ============================================================

CREATE TYPE inquiry_status AS ENUM (
  'OPEN',       -- consulta abierta, esperando respuesta del vendedor
  'REPLIED',    -- vendedor respondió al menos una vez
  'CLOSED',     -- cerrada por el comprador o por inactividad
  'CONVERTED'   -- marcada como venta concretada
);

CREATE TABLE public.inquiries (
  id          UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id  UUID           NOT NULL REFERENCES public.listings(id)  ON DELETE CASCADE,
  buyer_id    UUID           NOT NULL REFERENCES public.profiles(id)   ON DELETE CASCADE,
  status      inquiry_status NOT NULL DEFAULT 'OPEN',
  created_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  -- Un comprador no puede tener dos consultas abiertas sobre el mismo activo
  UNIQUE (listing_id, buyer_id)
);

COMMENT ON TABLE  public.inquiries            IS 'Consulta de un comprador sobre un activo. Contiene el thread de mensajes.';
COMMENT ON COLUMN public.inquiries.buyer_id   IS 'El comprador que inició la consulta. No puede ser el mismo que el seller del listing.';

-- Mensajes dentro de cada consulta
CREATE TABLE public.inquiry_messages (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  inquiry_id  UUID        NOT NULL REFERENCES public.inquiries(id) ON DELETE CASCADE,
  sender_id   UUID        NOT NULL REFERENCES public.profiles(id)  ON DELETE CASCADE,
  content     TEXT        NOT NULL CHECK (char_length(content) >= 1 AND char_length(content) <= 5000),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  public.inquiry_messages            IS 'Mensajes dentro de una consulta. Solo comprador y vendedor pueden escribir.';
COMMENT ON COLUMN public.inquiry_messages.content    IS 'Contenido del mensaje. Mínimo 1 char, máximo 5000.';
