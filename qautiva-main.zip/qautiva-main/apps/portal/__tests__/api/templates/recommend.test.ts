import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

const mockGetUser = vi.fn()
const mockUserProfileFindUnique = vi.fn()
const mockSessionFindFirst = vi.fn()
const mockTemplateFindMany = vi.fn()
const mockIndustryFindFirst = vi.fn()

// Mock supabase-server (same pattern as other portal tests)
vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

// Mock next/headers
vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

// Mock @qautiva/db
vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: { findUnique: mockUserProfileFindUnique },
    interviewSession: { findFirst: mockSessionFindFirst },
    webTemplate: { findMany: mockTemplateFindMany },
    industryTemplate: { findFirst: mockIndustryFindFirst },
  },
}))

// Mock next/cache
vi.mock('next/cache', () => ({ revalidatePath: vi.fn(), revalidateTag: vi.fn() }))

function makeRequest(sessionId?: string): NextRequest {
  const url = sessionId
    ? `http://localhost:3001/api/templates/recommend?sessionId=${sessionId}`
    : 'http://localhost:3001/api/templates/recommend'
  return new NextRequest(url, { method: 'GET' })
}

const VALID_UUID = '00000000-0000-4000-8000-000000000001'
const TEMPLATE_UUID_1 = '00000000-0000-4000-8000-000000000010'
const TEMPLATE_UUID_2 = '00000000-0000-4000-8000-000000000020'
const TEMPLATE_UUID_3 = '00000000-0000-4000-8000-000000000030'

function setupAuth() {
  mockGetUser.mockResolvedValue({ data: { user: { id: 'auth-user-1' } } })
  mockUserProfileFindUnique.mockResolvedValue({
    teamMemberships: [{ teamId: 'team-1' }],
  })
}

function setupSession(answers: Record<string, string> = {}, industry = 'Veterinaria') {
  mockSessionFindFirst.mockResolvedValue({
    id: VALID_UUID,
    answers,
    project: { industry },
  })
}

function setupTemplates(
  templates: Array<{
    id: string
    name: string
    sections: Record<string, boolean>
    compatibleIndustries: string[]
  }>,
) {
  mockTemplateFindMany.mockResolvedValue(
    templates.map((t) => ({
      ...t,
      description: `Desc ${t.name}`,
      thumbnail: `/thumb/${t.id}.png`,
      usageCount: 0,
    })),
  )
}

describe('GET /api/templates/recommend', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockIndustryFindFirst.mockResolvedValue(null)
  })

  it('returns 401 when not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })
    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    expect(res.status).toBe(401)
  })

  it('returns 404 for missing sessionId', async () => {
    setupAuth()
    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest())
    expect(res.status).toBe(404)
  })

  it('returns 404 for invalid UUID sessionId', async () => {
    setupAuth()
    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest('not-a-uuid'))
    expect(res.status).toBe(404)
  })

  it('returns 403 when user has no team memberships', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'auth-user-1' } } })
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [],
    })
    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    expect(res.status).toBe(403)
  })

  it('returns 404 when session does not belong to user team', async () => {
    setupAuth()
    mockSessionFindFirst.mockResolvedValue(null)
    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    expect(res.status).toBe(404)
  })

  it('returns top 2 templates sorted by score', async () => {
    setupAuth()
    setupSession({ web_objetivo: 'mostrar_servicios', web_agenda: 'si' })
    setupTemplates([
      {
        id: TEMPLATE_UUID_1,
        name: 'Template A',
        sections: { hero: true, services: true, booking: true, about: true },
        compatibleIndustries: ['Veterinaria'],
      },
      {
        id: TEMPLATE_UUID_2,
        name: 'Template B',
        sections: { hero: true, about: true },
        compatibleIndustries: [],
      },
      {
        id: TEMPLATE_UUID_3,
        name: 'Template C',
        sections: { hero: true, services: true, about: true },
        compatibleIndustries: ['Veterinaria'],
      },
    ])

    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(data.templates).toHaveLength(2)
    // Template A: +3 industry + 2*4 sections (hero,services,booking,about) + 0 recommended = 11
    // Template C: +3 industry + 2*3 sections (hero,services,about) + 0 recommended = 9
    // Template B: +0 industry + 2*2 sections (hero,about) + 0 recommended = 4
    expect(data.templates[0].id).toBe(TEMPLATE_UUID_1)
    expect(data.templates[1].id).toBe(TEMPLATE_UUID_3)
  })

  it('includes reason string based on scoring factors', async () => {
    setupAuth()
    setupSession({ web_objetivo: 'informar' })
    setupTemplates([
      {
        id: TEMPLATE_UUID_1,
        name: 'Template A',
        sections: { hero: true, about: true },
        compatibleIndustries: ['Veterinaria'],
      },
    ])

    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    const data = await res.json()

    expect(data.templates[0].reason).toContain('Diseñado para tu rubro')
    expect(data.templates[0].reason).toContain('secciones')
  })

  it('returns fallback reason when no scoring factors match', async () => {
    setupAuth()
    setupSession({ web_objetivo: 'informar' }, 'Gastronomía')
    setupTemplates([
      {
        id: TEMPLATE_UUID_1,
        name: 'Template A',
        sections: {},
        compatibleIndustries: ['Tecnología'],
      },
    ])

    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    const data = await res.json()

    expect(data.templates[0].reason).toBe('Diseño versátil que se adapta a tu negocio.')
  })

  it('adds bonus for IndustryTemplate recommended template', async () => {
    setupAuth()
    setupSession({ web_objetivo: 'informar' })
    mockIndustryFindFirst.mockResolvedValue({ webTemplate: TEMPLATE_UUID_2 })
    setupTemplates([
      {
        id: TEMPLATE_UUID_1,
        name: 'Template A',
        sections: { hero: true, about: true },
        compatibleIndustries: [],
      },
      {
        id: TEMPLATE_UUID_2,
        name: 'Template B',
        sections: { hero: true, about: true },
        compatibleIndustries: [],
      },
    ])

    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    const data = await res.json()

    // Template B gets +1 for being recommended — should be first
    expect(data.templates[0].id).toBe(TEMPLATE_UUID_2)
  })

  it('returns empty array when no templates exist', async () => {
    setupAuth()
    setupSession({})
    setupTemplates([])

    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    const data = await res.json()

    expect(data.ok).toBe(true)
    expect(data.templates).toEqual([])
  })

  it('returns 1 template when only 1 exists', async () => {
    setupAuth()
    setupSession({})
    setupTemplates([
      {
        id: TEMPLATE_UUID_1,
        name: 'Solo',
        sections: { hero: true },
        compatibleIndustries: [],
      },
    ])

    const { GET } = await import('@/app/api/templates/recommend/route')
    const res = await GET(makeRequest(VALID_UUID))
    const data = await res.json()

    expect(data.templates).toHaveLength(1)
  })

  it('verifies ownership via teamId in session query', async () => {
    setupAuth()
    setupSession({})
    setupTemplates([])

    const { GET } = await import('@/app/api/templates/recommend/route')
    await GET(makeRequest(VALID_UUID))

    expect(mockSessionFindFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          id: VALID_UUID,
          teamId: { in: ['team-1'] },
        }),
      }),
    )
  })
})
