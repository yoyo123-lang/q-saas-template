-- ============================================================
-- 001 — Profiles
-- Extiende auth.users de Supabase con datos del perfil público.
-- Rollback: 001_profiles_rollback.sql
-- ============================================================

-- ENUM: rol del usuario en la plataforma
CREATE TYPE user_role AS ENUM ('BUYER', 'SELLER', 'ADMIN');

-- Tabla profiles: 1-a-1 con auth.users
CREATE TABLE public.profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email         TEXT NOT NULL,
  full_name     TEXT,
  avatar_url    TEXT,
  role          user_role NOT NULL DEFAULT 'BUYER',
  bio           TEXT,
  company_name  TEXT,
  website       TEXT,
  -- Soft-delete: datos se mantienen 90 días, listados pasan a PAUSED automáticamente
  deleted_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Comentarios de columnas
COMMENT ON TABLE  public.profiles              IS 'Datos de perfil extendido. Referencia 1-a-1 con auth.users.';
COMMENT ON COLUMN public.profiles.id           IS 'Mismo UUID que auth.users.id';
COMMENT ON COLUMN public.profiles.role         IS 'BUYER (default), SELLER, o ADMIN';
COMMENT ON COLUMN public.profiles.deleted_at   IS 'NULL = activo. Fecha = baja iniciada. Datos se eliminan 90 días después.';
