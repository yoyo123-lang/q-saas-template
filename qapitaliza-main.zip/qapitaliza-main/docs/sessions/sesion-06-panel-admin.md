# Sesión 06 — Panel Admin y Analytics

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 05 — Favoritos, sistema de consultas y chat completos.

Esta sesión construye el panel de administración completo: dashboard con métricas, moderación de listados con slide-in panel y acciones masivas, gestión de usuarios, y el sistema de analytics/funnel.

Leer antes de empezar:
- `PLAN.md` — Etapa 7
- `docs/frontend/05-admin.md` — especificación completa del panel admin
- `docs/frontend/04-dashboards.md` — §8 referencia de sidebar y componentes compartidos

## Estado actual

Ya existe:
- `<Sidebar variant="dashboard">` construido — crear variante `admin` en la misma sesión
- Recharts ya instalado
- `src/lib/actions/listings.ts` con acciones del vendedor — agregar acciones admin
- Trigger `010_triggers.sql` con función `increment_listing_views`

## Tarea de esta sesión

### 1. Layout admin `src/app/(admin)/layout.tsx`

Auth guard: verificar sesión Y que `profile.role === 'ADMIN'`. Si no es admin → redirect `/dashboard` con toast "No tenés acceso a esta sección".

Layout igual que dashboard. `<Sidebar variant="admin">`.

### 2. Variante admin del Sidebar

Actualizar `src/components/layout/sidebar.tsx` para soportar `variant="admin"`:

Nav items admin:
- Dashboard → `/admin`
- Listados → `/admin/listados` (badge rojo con `pendingCount`)
- Usuarios → `/admin/usuarios`
- Reportes → `/admin/reportes` (placeholder — construir en Fase 2)

El badge de "Listados" se carga con `pendingCount` vía polling cada 5 minutos. Implementar en el layout admin con `useInterval`:

```ts
// custom hook src/lib/hooks/use-interval.ts
export function useInterval(callback: () => void, delay: number) { ... }
```

`LogoQ` en variante admin: muestra badge pill "Admin" en amber junto al texto.

### 3. Data access layer admin `src/lib/data/admin.ts`

```ts
export async function getMarketplaceStats(period: string): Promise<MarketplaceStats>
export async function getWeeklyListingsChart(weeks: number): Promise<ChartData[]>
export async function getDailyRegistrationsChart(days: number): Promise<ChartData[]>
export async function getCategoryDistribution(): Promise<CategoryDist[]>
export async function getPendingListingsCount(): Promise<number>
export async function getAllListings(params: AdminListingParams): Promise<PaginatedListings>
export async function getAllUsers(params: AdminUserParams): Promise<PaginatedUsers>
export async function getUserDetail(id: string): Promise<UserDetail>
```

Todas las funciones son solo para admins. La verificación de rol va en la Server Action, no en el DAL.

### 4. Dashboard admin `/admin`

`src/app/(admin)/admin/page.tsx`. Server Component. Leer `?period` de searchParams (default: `30d`).

Ver `docs/frontend/05-admin.md` §1:

**Stat cards (4):** listados totales (con trend), usuarios registrados (con trend), consultas activas, volumen listado (highlight amber).

**Gráficos (2 columnas):**
- `<BarChart>` Recharts: "Nuevos listados por semana". Barras amber con `radius={[4,4,0,0]}`. Tooltip custom.
- `<AreaChart>` Recharts: "Registros de usuarios". Línea amber + fill amber/10.
Ambos: `ResponsiveContainer width="100%"`, fondo navy-950, grid lines slate-800 (`stroke="#1E293B"`).

**Pendientes de revisión:** tabla compacta con 5 filas. Columnas: activo | vendedor | tipo | precio | hace cuánto | botón "Revisar" (amber outline → `/admin/listados/{id}`).

**Actividad reciente:** 5 `<ActivityItem>` con eventos del AuditLog.

**Distribución por categoría:** barras HTML/CSS (no chart) con `width: X%` en amber, porcentaje, conteo.

**Selector de período** en el header: "Últimos 7 días | 30 días | Este mes | Este año". Al cambiar: `router.push` con `?period=`.

### 5. Componentes admin nuevos

#### `src/components/admin/admin-listings-table.tsx`

Ver `docs/frontend/05-admin.md` §2.

Checkbox por fila para selección masiva. Cuando `selectedIds.length > 0`: mostrar barra flotante encima de la tabla:
```
N seleccionados — [Aprobar todos] [Rechazar todos] [Cancelar]
```

Columnas: ☐ | thumbnail | Activo (link) | Vendedor | Tipo | Precio | Estado badge | Fecha | Acciones

Botones de acción por fila:
- "Aprobar ✓" (`outline-success`, size sm)
- "Rechazar ✗" (`outline-danger`, size sm)
- "Ver" (`ghost`, size sm) → abre `<ListingPreviewPanel />`

#### `src/components/admin/listing-preview-panel.tsx`

Ver `docs/frontend/05-admin.md` §2 (panel de preview).

Slide-in desde la derecha: `fixed right-0 top-0 h-screen w-[420px] bg-navy-900 border-l border-slate-800 transform transition-transform duration-300`. Abre: `translate-x-0`. Cerrado: `translate-x-full`.

Overlay oscuro cuando abierto.

Contenido (scroll interno):
- Header: título del activo + botón × para cerrar
- Screenshot grande
- Tipo + precio + badges
- Descripción completa
- Métricas declaradas
- Tech stack pills
- Info vendedor con link a perfil

Footer sticky dentro del panel:
- Botón "Aprobar y publicar" (`bg-emerald-500 hover:bg-emerald-400 text-white w-full`)
- Botón "Rechazar" (outline-danger, full width) → al hacer click: expande `<Textarea>` para el motivo
- Si motivo visible: botón "Confirmar rechazo" (outline-danger) — **deshabilitado si el textarea tiene menos de 20 caracteres**
- Helper bajo el textarea: "Mínimo 20 caracteres · {n} / 500"

### 6. Moderación de listados `/admin/listados`

`src/app/(admin)/admin/listados/page.tsx`. Lee searchParams: `status`, `type`, `sort`, `q`, `page`.

Tabs: Todos | Pendientes (dot rojo pulsante) | Publicados | Destacados | Rechazados | Vendidos.

Barra de filtros: búsqueda + dropdown Tipo + dropdown Ordenar.

`<AdminListingsTable>` + `<Pagination>`.

Estado de `selectedIds` y el panel de preview se manejan en este componente.

### 7. Revisión individual `/admin/listados/[id]`

`src/app/(admin)/admin/listados/[id]/page.tsx`.

Vista full-page parecida al detalle público pero con diferencias:
- Sin botones de comprador (no "Consultar", no "Guardar favorito")
- Sidebar sticky con acciones admin:
  - "Aprobar y publicar" (emerald sólido)
  - "Rechazar" con textarea de motivo (mínimo 20 chars)
  - "Destacar" / "Quitar destacado"
  - "Marcar como vendido"
- Si el listing tiene `rejection_reason` previo → mostrar en card amarilla "Rechazado anteriormente: {reason}"
- Link "Ver perfil del vendedor" → `/admin/usuarios/{sellerId}`

### 8. Gestión de usuarios `/admin/usuarios`

`src/app/(admin)/admin/usuarios/page.tsx`. Ver `docs/frontend/05-admin.md` §4.

4 stat cards mini: Total | Vendedores | Compradores | Suspendidos (highlight danger).

Tabs: Todos | Vendedores | Compradores | Admins | Suspendidos.

Tabla con columnas: Avatar | Nombre | Email | Rol (badge: info=SELLER, muted=BUYER, amber=ADMIN) | Listados | Registrado | Estado | ⋯

`<DropdownMenu>` por fila:
- "Ver perfil" → `/admin/usuarios/{id}`
- "Cambiar rol" → abre Modal con Select de nuevo rol
- "Suspender" → abre Modal con textarea de motivo (required)
- "Eliminar" → abre Modal con advertencia "Acción irreversible. El usuario será eliminado en 90 días."

### 9. Perfil de usuario `/admin/usuarios/[id]`

`src/app/(admin)/admin/usuarios/[id]/page.tsx`.

- Card de info del usuario (avatar, nombre, email, rol, fecha de registro)
- Grid de sus listados (mismo `<ListingCard>` en modo compacto)
- Tabla del historial de AuditLog del usuario

### 10. Server Actions admin `src/lib/actions/admin.ts`

Todas verifican `currentUser.role === 'ADMIN'` al inicio. Si no → throw error.

```ts
export async function approveListing(id: string): Promise<ActionResult>
export async function rejectListing(id: string, reason: string): Promise<ActionResult>
// reason: validar min 20 chars con Zod
export async function featureListing(id: string): Promise<ActionResult>
export async function unfeatureListing(id: string): Promise<ActionResult>
export async function markListingAsSold(id: string): Promise<ActionResult>
export async function suspendUser(id: string, reason: string): Promise<ActionResult>
export async function changeUserRole(id: string, role: 'BUYER' | 'SELLER' | 'ADMIN'): Promise<ActionResult>
export async function deleteUser(id: string): Promise<ActionResult>  // soft delete
```

Cada action escribe en `audit_log` con `actor_id`, `action`, `entity_type`, `entity_id`, y `metadata` relevante (ej: `{ reason, old_status, new_status }`).

### 11. Analytics `src/lib/analytics/events.ts`

```ts
export async function trackEvent(
  action: AuditAction,
  entityType: string,
  entityId: string,
  actorId: string,
  metadata?: Record<string, unknown>
): Promise<void>
```

Insertar en `audit_log` usando el service_role client (bypasea RLS).

Llamar a `trackEvent` desde todas las Server Actions en los momentos clave:
- `signUp` → `SIGNUP_COMPLETED`
- `createListing` → `LISTING_CREATED`
- `publishListing` → `LISTING_SUBMITTED`
- `approveListing` → `LISTING_PUBLISHED` + `LISTING_APPROVED`
- `getListing` (en page.tsx del detalle) → `LISTING_VIEWED`
- `createInquiry` → `INQUIRY_SENT`
- `sendMessage` (primer respuesta del vendedor) → `INQUIRY_REPLIED`
- `closeInquiry` con status CONVERTED → `INQUIRY_CONVERTED`
- `toggleFavorite` (add) → `FAVORITE_ADDED`

### 12. Tests

`src/lib/actions/__tests__/admin.test.ts`:
- `approveListing` ejecutado por no-admin → error
- `rejectListing` sin motivo → error
- `rejectListing` con motivo < 20 chars → error
- `rejectListing` válido → listing.status = REJECTED, audit_log creado
- `suspendUser` → profile.status actualizado (agregar columna `status` a profiles si no existe)
- `changeUserRole` → profile.role actualizado, audit_log creado

## Reglas

- Las acciones admin usan el service_role key de Supabase — nunca el anon key
- El slide-in panel no navega — la revisión individual es una ruta separada para cuando se necesita más contexto
- El motivo de rechazo mínimo 20 chars se valida tanto en el cliente (deshabilitar botón) como en la Server Action (Zod)

## Checkpoint

La sesión está completa cuando:
- [ ] Dashboard admin con gráficos Recharts, stats y distribución de categorías
- [ ] Badge de "Listados pendientes" se actualiza con polling cada 5 min
- [ ] Tabla de listados con selección masiva y acciones masivas (aprobar/rechazar todos)
- [ ] Slide-in panel funciona — aprueba y rechaza sin navegar
- [ ] Motivo de rechazo: botón deshabilitado si < 20 chars (verificar en UI y en server action)
- [ ] `/admin/listados/[id]` muestra historial de rechazo si aplica
- [ ] Gestión de usuarios con Suspender/Cambiar rol/Eliminar funcionales
- [ ] `trackEvent` llamado en todos los eventos de funnel definidos
- [ ] Tests pasan
- [ ] `npm run build` sin errores
