import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockRequireAdminSession = vi.fn()
const mockOrgFindUnique = vi.fn()
const mockMessageCreate = vi.fn()
const mockRevalidatePath = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  requireAdminSession: mockRequireAdminSession,
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    organization: { findUnique: mockOrgFindUnique },
    message: { create: mockMessageCreate },
    stage: { findUnique: vi.fn() },
    adminNote: { create: vi.fn() },
    $transaction: vi.fn(),
  },
}))

vi.mock('@/lib/audit', () => ({
  logAudit: vi.fn(),
}))

vi.mock('next/cache', () => ({
  revalidatePath: mockRevalidatePath,
}))

function makeFormData(fields: Record<string, string>): FormData {
  const fd = new FormData()
  for (const [key, val] of Object.entries(fields)) {
    fd.append(key, val)
  }
  return fd
}

describe('sendAdminMessage', () => {
  beforeEach(() => {
    vi.resetModules()
    mockRequireAdminSession.mockReset()
    mockOrgFindUnique.mockReset()
    mockMessageCreate.mockReset()
    mockRevalidatePath.mockReset()
  })

  it('lanza si falta orgId', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { sendAdminMessage } = await import('../../lib/actions')
    await expect(sendAdminMessage(makeFormData({ content: 'Hola' }))).rejects.toThrow('orgId requerido')
  })

  it('lanza si orgId es solo espacios', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { sendAdminMessage } = await import('../../lib/actions')
    await expect(sendAdminMessage(makeFormData({ orgId: '   ', content: 'Hola' }))).rejects.toThrow(
      'orgId requerido',
    )
  })

  it('lanza si falta content', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { sendAdminMessage } = await import('../../lib/actions')
    await expect(sendAdminMessage(makeFormData({ orgId: 'org-1' }))).rejects.toThrow('Contenido requerido')
  })

  it('lanza si content supera 2000 caracteres', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { sendAdminMessage } = await import('../../lib/actions')
    await expect(
      sendAdminMessage(makeFormData({ orgId: 'org-1', content: 'x'.repeat(2001) })),
    ).rejects.toThrow('2000 caracteres')
  })

  it('lanza si la organización no existe', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockOrgFindUnique.mockResolvedValueOnce(null)

    const { sendAdminMessage } = await import('../../lib/actions')
    await expect(
      sendAdminMessage(makeFormData({ orgId: 'org-inexistente', content: 'Hola' })),
    ).rejects.toThrow('Organización no encontrada')
  })

  it('lanza si prisma.message.create falla', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockOrgFindUnique.mockResolvedValueOnce({ id: 'org-1' })
    mockMessageCreate.mockRejectedValueOnce(new Error('DB error'))

    const { sendAdminMessage } = await import('../../lib/actions')
    await expect(
      sendAdminMessage(makeFormData({ orgId: 'org-1', content: 'Hola' })),
    ).rejects.toThrow('No se pudo enviar el mensaje')
  })

  it('crea mensaje con sender ADMIN y revalida el path del cliente', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockOrgFindUnique.mockResolvedValueOnce({ id: 'org-1' })
    mockMessageCreate.mockResolvedValueOnce({ id: 'msg-1' })

    const { sendAdminMessage } = await import('../../lib/actions')
    await sendAdminMessage(makeFormData({ orgId: 'org-1', content: 'Revisá los cambios' }))

    expect(mockMessageCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          organizationId: 'org-1',
          sender: 'ADMIN',
          channel: 'WEB',
          content: 'Revisá los cambios',
        }),
      }),
    )
    expect(mockRevalidatePath).toHaveBeenCalledWith('/clientes/org-1')
  })

  it('incluye stageNumber si es un número válido (1-6)', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockOrgFindUnique.mockResolvedValueOnce({ id: 'org-1' })
    mockMessageCreate.mockResolvedValueOnce({ id: 'msg-2' })

    const { sendAdminMessage } = await import('../../lib/actions')
    await sendAdminMessage(makeFormData({ orgId: 'org-1', content: 'Todo OK', stageNumber: '3' }))

    expect(mockMessageCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ stageNumber: 3 }),
      }),
    )
  })

  it('omite stageNumber si el valor está fuera de rango (0, 7, NaN)', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockOrgFindUnique.mockResolvedValueOnce({ id: 'org-1' })
    mockMessageCreate.mockResolvedValueOnce({ id: 'msg-3' })

    const { sendAdminMessage } = await import('../../lib/actions')
    await sendAdminMessage(makeFormData({ orgId: 'org-1', content: 'Todo OK', stageNumber: '0' }))

    const callArg = mockMessageCreate.mock.calls[0][0]
    expect(callArg.data).not.toHaveProperty('stageNumber')
  })

  it('recorta espacios del content antes de guardar', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockOrgFindUnique.mockResolvedValueOnce({ id: 'org-1' })
    mockMessageCreate.mockResolvedValueOnce({ id: 'msg-4' })

    const { sendAdminMessage } = await import('../../lib/actions')
    await sendAdminMessage(makeFormData({ orgId: 'org-1', content: '  Hola equipo  ' }))

    expect(mockMessageCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ content: 'Hola equipo' }),
      }),
    )
  })
})
