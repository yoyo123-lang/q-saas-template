import { getPrisma } from '@/lib/prisma'

export interface FavoriteListing {
  id: string
  slug: string
  title: string
  type: string
  askingPrice: string
  monthlyRevenue: string | null
  monthlyTraffic: number | null
  screenshotUrls: string[]
  techStack: string[]
  verificationStatus: string
  featuredUntil: Date | null
  status: string
}

/** Max favorites returned per user (protects against unbounded queries). */
const MAX_FAVORITES = 200

/**
 * Returns the listing IDs favorited by the user.
 * Used to mark cards in the catalog without loading full listing data.
 */
export async function getFavoriteIds(userId: string): Promise<string[]> {
  const prisma = getPrisma()
  const favorites = await prisma.favorite.findMany({
    where: { userId },
    select: { listingId: true },
    take: MAX_FAVORITES,
  })
  return favorites.map((f) => f.listingId)
}

/**
 * Returns full listing data for all favorites of a user, ordered by date added.
 * Only returns listings that are still PUBLISHED or PAUSED (excludes SOLD/REJECTED/DRAFT).
 */
export async function getFavorites(userId: string): Promise<FavoriteListing[]> {
  const prisma = getPrisma()
  const favorites = await prisma.favorite.findMany({
    where: { userId },
    include: {
      listing: {
        select: {
          id: true,
          slug: true,
          title: true,
          type: true,
          askingPrice: true,
          monthlyRevenue: true,
          monthlyTraffic: true,
          screenshotUrls: true,
          techStack: true,
          verificationStatus: true,
          featuredUntil: true,
          status: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
    take: MAX_FAVORITES,
  })

  return favorites
    .filter((f) => ['PUBLISHED', 'PAUSED'].includes(f.listing.status))
    .map((f) => ({
      ...f.listing,
      askingPrice: f.listing.askingPrice.toString(),
      monthlyRevenue: f.listing.monthlyRevenue?.toString() ?? null,
    }))
}

/**
 * Returns whether a specific listing is favorited by the user.
 */
export async function isFavorited(userId: string, listingId: string): Promise<boolean> {
  const prisma = getPrisma()
  const favorite = await prisma.favorite.findUnique({
    where: { userId_listingId: { userId, listingId } },
    select: { id: true },
  })
  return !!favorite
}
