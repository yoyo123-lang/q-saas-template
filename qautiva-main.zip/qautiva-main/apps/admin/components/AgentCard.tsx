import Link from 'next/link'
import type { AutomationLevel } from '@qautiva/db'
import { AutomationToggle } from './AutomationToggle'

export interface AgentCardProps {
  id: string
  agentNumber: number
  name: string
  description: string
  automationLevel: AutomationLevel
  approvalRate: number
  avgTime: number
}

/**
 * Tarjeta de agente IA con toggle de automatización, stats y link a detalle.
 * AutomationToggle es read-only en la lista; la edición es en /agentes/[id].
 */
export function AgentCard({
  id,
  agentNumber,
  name,
  description,
  automationLevel,
  approvalRate,
  avgTime,
}: AgentCardProps) {
  const avgTimeLabel =
    avgTime >= 60 ? `${(avgTime / 60).toFixed(avgTime % 60 === 0 ? 0 : 1)} hs` : `${avgTime} min`

  return (
    <div className="flex flex-col gap-3 p-5 bg-[#0F172A] rounded-xl border border-[#1E293B] hover:border-[#334155] transition-colors">
      {/* Número + nombre */}
      <div>
        <p className="text-xs text-[#64748B] font-mono mb-0.5">{agentNumber} —</p>
        <h3 className="text-white font-semibold text-base leading-tight">{name}</h3>
        <p className="text-[#94A3B8] text-sm mt-0.5">{description}</p>
      </div>

      {/* Toggle */}
      <AutomationToggle value={automationLevel} readOnly />

      {/* Stats */}
      <p className="text-[#64748B] text-xs">
        {approvalRate > 0 ? `${approvalRate.toFixed(0)}% aprobación primer intento` : 'Sin datos de aprobación'}
        {' | '}
        {avgTime > 0 ? `Tiempo promedio: ${avgTimeLabel}` : 'Tiempo no registrado'}
      </p>

      {/* Link */}
      <Link
        href={`/agentes/${id}`}
        className="text-[#A78BFA] hover:text-[#8B5CF6] text-sm font-medium transition-colors"
      >
        Configurar →
      </Link>
    </div>
  )
}
