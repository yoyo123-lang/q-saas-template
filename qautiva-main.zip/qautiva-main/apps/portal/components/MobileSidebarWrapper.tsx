'use client'

import { useEffect, useRef } from 'react'
import { usePathname } from 'next/navigation'
import { X } from 'lucide-react'
import { useSidebar } from './SidebarContext'

type Props = {
  sidebar: React.ReactNode
  children: React.ReactNode
}

/** Breakpoint md de Tailwind en px */
const MD_BREAKPOINT = 768

/**
 * Wrapper que implementa el patrón de sidebar responsive:
 * - Mobile (<md): drawer deslizable desde la izquierda con overlay oscuro.
 *   Se abre/cierra vía SidebarContext (hamburger en TopBar).
 *   Se cierra automáticamente al navegar, al presionar Escape, o al rotar a landscape.
 * - Desktop (≥md): sidebar siempre visible, sin overlay ni animación.
 *
 * Recibe `sidebar` como prop (Server Component tree) y `children` como contenido principal.
 * Ambos se renderizan server-side; este componente solo gestiona el layout/visibilidad.
 */
export function MobileSidebarWrapper({ sidebar, children }: Props) {
  const { open, close } = useSidebar()
  const pathname = usePathname()
  const sidebarRef = useRef<HTMLDivElement>(null)

  // Cerrar al navegar a otra página
  useEffect(() => {
    close()
  }, [pathname, close])

  // Cerrar al resize a desktop (evita overflow bloqueado en landscape)
  useEffect(() => {
    function handleResize() {
      if (window.innerWidth >= MD_BREAKPOINT) close()
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [close])

  // Bloquear scroll del body cuando el drawer está abierto en mobile
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  // Mover foco al drawer al abrirse (accesibilidad)
  useEffect(() => {
    if (open && sidebarRef.current) {
      sidebarRef.current.focus()
    }
  }, [open])

  // Cerrar con Escape
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') close()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [close])

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* Overlay — solo mobile cuando está abierto */}
      {open && (
        <div
          className="fixed inset-0 bg-black/60 z-30 md:hidden"
          aria-hidden="true"
          onClick={close}
        />
      )}

      {/* Sidebar wrapper */}
      <div
        ref={sidebarRef}
        // tabIndex para poder recibir foco programático
        tabIndex={-1}
        className={[
          // Mobile: posición fija, fuera de pantalla por defecto, desliza al abrirse
          'fixed inset-y-0 left-0 z-40 flex-shrink-0 outline-none',
          'transition-transform duration-300 ease-in-out',
          open ? 'translate-x-0' : '-translate-x-full',
          // Desktop: posición relativa, siempre visible, sin translate
          'md:relative md:translate-x-0 md:flex',
        ].join(' ')}
      >
        {/* Botón cerrar — solo mobile */}
        <button
          type="button"
          onClick={close}
          aria-label="Cerrar menú"
          className="md:hidden absolute top-3 right-3 z-50 p-1.5 rounded-lg text-[#94A3B8] hover:text-white hover:bg-[#1E293B] transition-colors"
        >
          <X size={18} aria-hidden="true" />
        </button>

        {sidebar}
      </div>

      <main className="flex-1 overflow-auto min-w-0">{children}</main>
    </div>
  )
}
