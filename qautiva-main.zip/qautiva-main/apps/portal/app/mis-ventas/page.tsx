import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { OrderStatusBadge } from '@/lib/order-status'
import { formatARS } from '@/lib/format'

export const metadata: Metadata = { title: 'Mis Ventas — Qautiva' }

export default async function MisVentasPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login?next=/mis-ventas')

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true },
  })
  if (!profile) redirect('/login')

  const orders = await prisma.order.findMany({
    where: { medium: { userId: profile.id } },
    select: {
      id: true,
      status: true,
      editorPayout: true,
      createdAt: true,
      expiresAt: true,
      deliveryDeadline: true,
      product: { select: { name: true } },
      medium: { select: { id: true, name: true } },
      advertiser: { select: { displayName: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  type RawOrder = (typeof orders)[number]

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Mis Ventas</h1>
        <p className="text-[#94A3B8] text-sm mt-1">
          Pedidos que recibiste como editor
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-10 text-center">
          <p className="text-white font-semibold mb-2">Aún no recibiste pedidos</p>
          <p className="text-[#94A3B8] text-sm mb-4">
            Asegurate de tener medios activos con productos para que los anunciantes puedan comprarte.
          </p>
          <Link
            href="/mis-medios"
            className="inline-block bg-[#1E3A5F] hover:bg-[#1E4D8C] text-[#60A5FA] text-sm font-medium px-5 py-2 rounded-lg transition-colors"
          >
            Ver mis medios
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {orders.map((order: RawOrder) => {
            const now = new Date()
            const isExpiredPending =
              order.status === 'PENDING' &&
              order.expiresAt != null &&
              new Date(order.expiresAt) < now

            return (
              <Link
                key={order.id}
                href={`/mis-ventas/${order.id}`}
                className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 hover:border-[#334155] transition-colors block"
              >
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      {isExpiredPending ? (
                        <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-[#EF4444]/15 text-[#F87171]">
                          Expirada
                        </span>
                      ) : (
                        <OrderStatusBadge status={order.status} />
                      )}
                    </div>
                  <p className="text-white font-semibold text-sm truncate">{order.product.name}</p>
                  <p className="text-[#64748B] text-xs mt-0.5">
                    {order.medium.name}
                    {order.advertiser.displayName ? ` · por ${order.advertiser.displayName}` : ''}
                  </p>
                </div>

                <div className="shrink-0 flex flex-col items-end gap-1">
                  <p className="text-[#34D399] font-semibold text-sm">
                    {formatARS(order.editorPayout?.toNumber() ?? 0)}
                  </p>
                  <p className="text-[#475569] text-xs">
                    {new Date(order.createdAt).toLocaleDateString('es-AR', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </p>
                </div>
              </div>
            </Link>
            )
          })}
        </div>
      )}
    </div>
  )
}
