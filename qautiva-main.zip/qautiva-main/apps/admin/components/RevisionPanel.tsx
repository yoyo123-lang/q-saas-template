import Link from 'next/link'
import { DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL, PLAN_BADGE } from '@/lib/badges'
import type { StageDetail } from '@/app/(protected)/revision/page'
import { ApproveStageForm } from '@/components/forms/ApproveStageForm'
import { RejectStageForm } from '@/components/forms/RejectStageForm'

// ── Helpers ────────────────────────────────────────────────────────────────────

function formatDate(date: Date): string {
  return new Date(date).toLocaleString('es-AR', {
    day: 'numeric', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

// ── Props ──────────────────────────────────────────────────────────────────────

interface RevisionPanelProps {
  stage: StageDetail | null
  queueCount: number
  requestedStageId: string
}

// ── Componente ─────────────────────────────────────────────────────────────────

export function RevisionPanel({ stage, queueCount, requestedStageId }: RevisionPanelProps) {
  // El stage no existe o ya no está en ADMIN_REVIEW
  if (!stage) {
    return (
      <div className="flex flex-col gap-5">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm">
          <Link href="/revision" className="text-[#60A5FA] hover:underline">
            Cola de revisión
          </Link>
          <span className="text-[#475569]">/</span>
          <span className="text-[#64748B]">Etapa no encontrada</span>
        </div>

        <div className="flex flex-col items-center justify-center flex-1 gap-3 py-12">
          <p className="text-[#34D399] text-2xl">✓</p>
          <p className="text-white font-semibold">Esta etapa ya fue revisada</p>
          <p className="text-[#64748B] text-sm">
            La etapa solicitada ya no está en cola de revisión.
          </p>
          <Link
            href="/revision"
            className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
          >
            Volver a la cola {queueCount > 0 && `(${queueCount} pendientes)`}
          </Link>
        </div>
      </div>
    )
  }

  const planBadge = PLAN_BADGE[stage.organization.plan]
  const initial = stage.organization.name.charAt(0).toUpperCase()

  return (
    <div className="flex flex-col gap-5">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm">
        <Link href="/revision" className="text-[#60A5FA] hover:underline">
          Cola de revisión {queueCount > 0 && `(${queueCount})`}
        </Link>
        <span className="text-[#475569]">/</span>
        <span className="text-white">{stage.organization.name}</span>
        <span className="text-[#475569]">/</span>
        <span className="text-[#64748B]">Etapa {stage.number} — {stage.name}</span>
      </div>

      {/* Header del cliente */}
      <div className="flex items-center gap-3 p-4 rounded-xl bg-[#0F172A] border border-[#F59E0B]/30">
        <div className="w-10 h-10 rounded-full bg-[#F59E0B]/15 flex items-center justify-center flex-shrink-0">
          <span className="text-[#FBBF24] font-bold text-sm">{initial}</span>
        </div>
        <div className="flex flex-col gap-1 flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-white font-semibold">{stage.organization.name}</p>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${planBadge.className}`}>
              {planBadge.label}
            </span>
            <span className="text-[#64748B] text-xs">{stage.organization.industry}</span>
          </div>
          <p className="text-[#94A3B8] text-xs">
            Etapa {stage.number} — {stage.name} · Actualizada {formatDate(stage.updatedAt)}
          </p>
        </div>
        <Link
          href={`/clientes/${stage.organization.id}?tab=progreso`}
          className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-[#1E293B] text-[#94A3B8] text-xs hover:bg-[#334155] transition-colors"
        >
          Ver ficha completa
        </Link>
      </div>

      {/* Entregables */}
      <div className="flex flex-col gap-2">
        <h2 className="text-[#94A3B8] text-xs font-medium uppercase tracking-wide">
          Entregables ({stage.deliverables.length})
        </h2>
        {stage.deliverables.length === 0 ? (
          <p className="text-[#64748B] text-sm">Sin entregables en esta etapa.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {stage.deliverables.map((d) => {
              const badge = DELIVERABLE_STATUS_BADGE[d.status]
              return (
                <div
                  key={d.id}
                  className="flex items-center gap-3 p-3 rounded-lg bg-[#0F172A] border border-[#1E293B]"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm">{d.title}</p>
                    <p className="text-[#64748B] text-xs mt-0.5">{DELIVERABLE_TYPE_LABEL[d.type]}</p>
                  </div>
                  <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
                    {badge.label}
                  </span>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Acciones */}
      <div className="flex flex-col gap-3 pt-2">
        <h2 className="text-[#94A3B8] text-xs font-medium uppercase tracking-wide">Decisión</h2>
        <div className="flex gap-3 flex-wrap">
          <ApproveStageForm
            stageId={stage.id}
            orgId={stage.organization.id}
          />
          <RejectStageForm
            stageId={stage.id}
            orgId={stage.organization.id}
            stageName={`Etapa ${stage.number} — ${stage.name}`}
          />
        </div>
      </div>
    </div>
  )
}
