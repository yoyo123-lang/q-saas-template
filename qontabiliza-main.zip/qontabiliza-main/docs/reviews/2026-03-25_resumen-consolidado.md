# Resumen Consolidado de Revisión
**Fecha:** 2026-03-25
**Sesión:** S1 — Schema de dominio completo + helper withTenant()
**Archivos revisados:** `prisma/schema.prisma`, `src/lib/tenant.ts`, `tests/unit/tenant.test.ts`, `prisma/seed.ts`, `supabase/migrations/20260325000000_add_domain_models.sql`

---

## Totales por severidad

| Rol                      | CRÍTICO | ALTO | MEDIO | BAJO | Total |
|--------------------------|---------|------|-------|------|-------|
| Code Reviewer            | 1       | 4    | 4     | 2    | 11    |
| QA Engineer              | 2       | 2    | 3     | 1    | 8     |
| Security Auditor         | 2       | 3    | 2     | 1    | 8     |
| Performance Engineer     | 0       | 2    | 3     | 1    | 6     |
| DevOps / SRE             | 1       | 3    | 2     | 1    | 7     |
| Consistency Reviewer     | 1       | 2    | 3     | 1    | 7     |
| Product Reviewer         | 0       | 2    | 3     | 1    | 6     |
| Business Logic Reviewer  | 1       | 3    | 3     | 1    | 8     |
| **TOTAL**                | **8**   | **21** | **23** | **9** | **61** |

> Nota: un mismo problema puede ser reportado por varios roles con distinto enfoque.
> Los problemas únicos a corregir son los listados abajo.

---

## Hallazgos críticos — acción inmediata requerida

### C1 — `"organization"` en `TENANT_SCOPED_MODELS` sin campo `organizationId` en el modelo
**Archivos:** `src/lib/tenant.ts:8`, `prisma/schema.prisma:106-131`
**Roles:** Code Reviewer (CR-01), Security Auditor (SEC-05), Consistency Reviewer (CON-01)
**Descripción:** `Organization` no tiene campo `organizationId`. Incluirlo en el Set hace que `withTenant(id).organization.findMany()` inyecte un filtro por un campo inexistente → error de runtime. Además, si el error fuera swallowed, retornaría TODAS las organizaciones del sistema (fuga de datos).
**Fix:** Remover `"organization"` de `TENANT_SCOPED_MODELS`. Para acceder a la org propia usar `prisma.organization.findUnique({ where: { id: organizationId } })`.

### C2 — IDOR: `findUnique` y `findUniqueOrThrow` no interceptados por `withTenant`
**Archivo:** `src/lib/tenant.ts:53-89`
**Roles:** Code Reviewer (CR-02), Security Auditor (SEC-01), QA (QA-01)
**Descripción:** Cualquier lookup por ID puede acceder a registros de otros tenants. OWASP A01:2021 — Broken Access Control.
**Fix:** Interceptar `findUnique` y `findUniqueOrThrow` en el bloque `$allModels` e inyectar `organizationId` en el `where`.

### C3 — Sin Row Level Security en Supabase — bypas completo de tenant isolation
**Archivo:** `supabase/migrations/20260325000000_add_domain_models.sql`
**Roles:** Security Auditor (SEC-02)
**Descripción:** Sin RLS, cualquier usuario autenticado en Supabase puede consultar la API REST directamente y obtener datos de todos los tenants.
**Fix:** Agregar `ENABLE ROW LEVEL SECURITY` + políticas de tenant en cada tabla de dominio, o deshabilitar el acceso directo a la API REST de Supabase para las tablas sensibles.

### C4 — No hay enforcement del plan activo antes de operaciones de escritura
**Archivo:** `prisma/schema.prisma:180-196`
**Roles:** Business Logic Reviewer (BL-01)
**Descripción:** Tenants con suscripción CANCELLED/SUSPENDED pueden crear facturas y ventas sin ninguna restricción.
**Fix:** Agregar guard que verifique `Subscription.status IN ('ACTIVE', 'TRIAL')` en endpoints/Server Actions de escritura.

### C5 — Doble sistema de migraciones — dos fuentes de verdad que van a divergir
**Archivos:** `prisma/schema.prisma` + `supabase/migrations/*.sql`
**Roles:** DevOps/SRE (SRE-01), Consistency Reviewer (CON-02)
**Descripción:** Mantener dos schemas sincronizados manualmente es insostenible. Van a divergir.
**Fix:** Elegir uno (recomendado: Prisma Migrate) y eliminar el otro.

### C6 — `withTenant` no tiene tests — la función core de seguridad es un punto ciego
**Archivo:** `tests/unit/tenant.test.ts`
**Roles:** QA Engineer (QA-01, QA-02)
**Descripción:** Solo `applyTenantFilter` (función auxiliar) está testeada. `withTenant()` que es lo que se usa en producción, no tiene ningún test.
**Fix:** Agregar tests de integración que verifiquen que `withTenant` efectivamente aísla tenants.

---

## Issues agrupados por archivo para facilitar el fix

### `src/lib/tenant.ts`
- C1: Remover `"organization"` del Set
- C2: Interceptar `findUnique`, `findUniqueOrThrow`
- CR-02: Interceptar `create`, `update`, `delete`, `upsert`
- SEC-06: Interceptar `count`, `aggregate`, `groupBy`
- PERF-03: Memoizar por organizationId
- CR-10: Tipar con `Prisma.ModelName`

### `tests/unit/tenant.test.ts`
- C6: Agregar tests de integración para `withTenant`
- QA-03: Tests para organizationId vacío/inválido
- QA-04: Documentar operaciones no interceptadas con tests

### `prisma/schema.prisma`
- C5: Decidir si se elimina en favor de Prisma Migrate
- CR-03: Eliminar modelo `Project` (template leftover)
- CR-04: Agregar FK relation en `CashRegister.openedById/closedById`
- CON-04: Agregar `subtotal` y `taxAmount` a `Sale`
- PERF-01: Agregar `@@index([organizationId, productId, warehouseId])` en StockMovement
- PERF-05: Agregar `@@index([organizationId, status, issuedAt])` en Invoice
- BL-02: Considerar modelo `ProductStock` para stock actual
- PROD-02: Documentar lógica de generación de `Invoice.number`

### `supabase/migrations/20260325000000_add_domain_models.sql`
- C3: Agregar RLS policies
- SRE-02: Agregar DOWN migration

### `prisma/seed.ts`
- CR-05: Cambiar `update: plan` a `update: {}` para no sobreescribir precios
- SRE-05: Envolver en `prisma.$transaction`
- PERF-06: Transacción para atomicidad

---

## Prioridad de corrección sugerida

**Inmediato (antes del próximo commit):**
1. C1 — Remover `"organization"` del Set (1 línea, 0 riesgo)
2. C2 — Interceptar `findUnique`/`findUniqueOrThrow` en withTenant
3. C6 — Tests básicos de integración para withTenant
4. CR-03 — Eliminar modelo Project del schema

**Próxima sesión:**
5. C3 — RLS en Supabase
6. C5 — Resolver doble sistema de migraciones
7. CR-02 — Interceptar create/update/delete
8. CR-04 — FK en CashRegister openedById/closedById

**Backlog técnico:**
9. C4 — Enforcement de plan activo
10. BL-02 — Modelo ProductStock para stock actual
11. PERF-01 — Índice compuesto en StockMovement
12. CON-04 — Unificar modelo de totales en Sale

---

*Revisión generada el 2026-03-25. No se modificó ningún archivo de código en esta revisión.*
