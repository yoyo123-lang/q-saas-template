import type { BrandKit, BusinessData } from '@qautiva/stitch'
import { personalizeTemplate, getDesignContext } from '@qautiva/stitch'

// ── Tipos ─────────────────────────────────────────────────────────────────────

/** Template web con campos Stitch — subconjunto de WebTemplate de Prisma */
export interface StitchWebTemplate {
  source: string
  stitchProjectId: string | null
  stitchScreenId: string | null
  htmlBase: string | null
  name: string
}

/** Resultado de personalización con Stitch */
export interface StitchPersonalizeResult {
  html: string
  css: string
  usedFallback: false
}

/** Resultado cuando se usó fallback Handlebars */
export interface FallbackResult {
  html: string
  css: string
  usedFallback: true
  fallbackReason: string
}

export type PersonalizeResult = StitchPersonalizeResult | FallbackResult

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Personaliza un template web con Stitch usando los datos del cliente.
 * Solo aplica si el template tiene `source === 'STITCH'` y tiene `stitchProjectId`.
 *
 * Reutiliza `buildInterviewContent()` y `buildTemplateContext()` de website-generator.ts
 * para construir el contexto de personalización — no duplica esa lógica.
 *
 * Si Stitch falla (API down, timeout, screen no existe), lanza el error
 * para que el caller pueda manejar el fallback a Handlebars.
 *
 * @param webTemplate - Template con fuente STITCH y IDs de Stitch
 * @param brandKit - Kit de marca del cliente (puede ser null o parcial)
 * @param businessData - Datos del negocio del cliente
 * @returns HTML/CSS personalizado, o lanza Error si Stitch falla
 */
export async function personalizeWithStitch(
  webTemplate: StitchWebTemplate,
  brandKit: Record<string, unknown> | null,
  businessData: { name: string; description?: string; services?: string[]; industry?: string | null },
): Promise<{ html: string; css: string }> {
  if (webTemplate.source !== 'STITCH') {
    throw new Error('[stitch-personalizer] Template no es de fuente STITCH')
  }
  if (!webTemplate.stitchProjectId || !webTemplate.stitchScreenId) {
    throw new Error('[stitch-personalizer] Template STITCH sin stitchProjectId/stitchScreenId')
  }

  // Mapear brandKit al tipo BrandKit del package
  const mappedBrandKit: BrandKit | null = brandKit
    ? {
        businessName: typeof brandKit['businessName'] === 'string' ? brandKit['businessName'] : null,
        logoUrl: typeof brandKit['logoUrl'] === 'string' ? brandKit['logoUrl'] : null,
        primaryColor: typeof brandKit['primaryColor'] === 'string' ? brandKit['primaryColor'] : null,
        secondaryColor: typeof brandKit['secondaryColor'] === 'string' ? brandKit['secondaryColor'] : null,
        accentColor: typeof brandKit['accentColor'] === 'string' ? brandKit['accentColor'] : null,
        slogan: typeof brandKit['slogan'] === 'string' ? brandKit['slogan'] : null,
      }
    : null

  // Si brandKit es null o todos los campos son null, usar null (el personalizer lo maneja)
  const hasAnyBrandData = mappedBrandKit && Object.values(mappedBrandKit).some(v => v !== null)

  const mappedBusinessData: BusinessData = {
    name: businessData.name || webTemplate.name,
    description: businessData.description ?? null,
    services: businessData.services,
    industry: businessData.industry ?? null,
  }

  console.info('[stitch-personalizer] starting Stitch personalization', {
    templateName: webTemplate.name,
    stitchProjectId: webTemplate.stitchProjectId,
    stitchScreenId: webTemplate.stitchScreenId,
    hasBrandKit: !!hasAnyBrandData,
    businessName: mappedBusinessData.name,
  })

  const result = await personalizeTemplate({
    stitchProjectId: webTemplate.stitchProjectId,
    stitchScreenId: webTemplate.stitchScreenId,
    brandKit: hasAnyBrandData ? mappedBrandKit : null,
    businessData: mappedBusinessData,
    designContext: getDesignContext(),
  })

  console.info('[stitch-personalizer] Stitch personalization completed', {
    templateName: webTemplate.name,
    htmlSizeBytes: result.html.length,
  })

  return result
}
