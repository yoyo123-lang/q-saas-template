'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import type { StrategicBrief } from '@/app/_lib/interview/types'

/** Ensures value is always an array — handles null, undefined, AND wrong types from AI output */
function safeArray<T>(value: T[] | null | undefined): T[] {
  return Array.isArray(value) ? value : []
}

type Props = {
  deliverableId: string
  projectId: string
  title: string
  brief: StrategicBrief | null
  canApprove: boolean
}

const estrategiaLabels: Record<string, string> = {
  bajo_costo: 'Bajo costo',
  diferenciacion: 'Diferenciación',
  enfoque: 'Enfoque en nicho',
}

/**
 * Renderiza el Brief Estratégico (tipo BRIEF) en la vista del cliente.
 * Muestra el contenido del brief y permite aprobar o pedir cambios.
 * @param canApprove - false si ya fue procesado (deshabilita acciones)
 */
export function BriefDeliverable({ deliverableId, projectId, title, brief: briefRaw, canApprove }: Props) {
  const brief = (briefRaw ?? {}) as StrategicBrief
  const router = useRouter()
  const [feedback, setFeedback] = useState('')
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  async function handleAction(action: 'approve' | 'reject') {
    if (action === 'reject' && feedback.trim().length === 0) {
      setError('Escribí tu feedback antes de pedir cambios.')
      return
    }
    setError(null)

    startTransition(async () => {
      const res = await fetch(`/api/deliverables/${deliverableId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, feedback: feedback.trim() }),
      })

      if (!res.ok) {
        const data = await res.json() as { error?: string }
        setError(data.error ?? 'Ocurrió un error. Intentalo de nuevo.')
        return
      }

      router.push(`/proyectos/${projectId}/progreso`)
    })
  }

  return (
    <div className="p-8 max-w-3xl space-y-6">
      <h1 className="text-2xl font-bold text-white">{title}</h1>

      {/* Mensaje central — destacado */}
      <div className="bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 rounded-xl p-5">
        <p className="text-[#8B5CF6] text-xs font-medium uppercase tracking-wide mb-2">
          Mensaje central
        </p>
        <p className="text-white text-xl font-semibold leading-snug">
          {brief.direccionComunicacional?.mensajeCentral ?? ''}
        </p>
        <p className="text-[#94A3B8] text-sm mt-2">{brief.direccionComunicacional?.tonoSugerido ?? ''}</p>
      </div>

      {/* Posicionamiento */}
      <BriefSection title="Posicionamiento">
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-[#8B5CF6]/15 text-[#A78BFA]">
            {estrategiaLabels[brief.posicionamiento?.estrategia ?? ''] ?? brief.posicionamiento?.estrategia ?? ''}
          </span>
        </div>
        <BriefRow label="Nicho específico" value={brief.posicionamiento?.nichoEspecifico ?? ''} />
        <BriefRow label="Ventaja competitiva" value={brief.posicionamiento?.ventajaCompetitiva ?? ''} />
        <BriefRow label="Justificación" value={brief.posicionamiento?.justificacion ?? ''} />
        {safeArray(brief.posicionamiento?.riesgos).length > 0 && (
          <BriefList label="Riesgos" items={safeArray(brief.posicionamiento?.riesgos)} />
        )}
      </BriefSection>

      {/* Tu negocio */}
      <BriefSection title="Tu negocio">
        <BriefRow label="Descripción" value={brief.negocio?.descripcion ?? ''} />
        <BriefRow label="Estado" value={brief.negocio?.estado ?? ''} />
        {brief.negocio?.antiguedad && (
          <BriefRow label="Antigüedad" value={brief.negocio.antiguedad} />
        )}
        <BriefRow label="Recursos disponibles" value={brief.negocio?.recursosDisponibles ?? ''} />
        {safeArray(brief.negocio?.restricciones).length > 0 && (
          <BriefList label="Restricciones" items={safeArray(brief.negocio?.restricciones)} />
        )}
      </BriefSection>

      {/* Tu cliente */}
      <BriefSection title="Tu cliente">
        <BriefRow label="Perfil" value={brief.audiencia?.perfilCliente ?? ''} />
        <BriefRow label="Cómo compra" value={brief.audiencia?.comoCompra ?? ''} />
        <BriefRow label="Dolor principal" value={brief.audiencia?.dolorPrincipal ?? ''} />
        <BriefRow label="Canal de adquisición" value={brief.audiencia?.canalAdquisicion ?? ''} />
      </BriefSection>

      {/* Mercado */}
      <BriefSection title="Mercado">
        <BriefRow label="Zona geográfica" value={brief.mercado?.zonaGeografica ?? ''} />
        <BriefRow label="Alcance" value={brief.mercado?.alcance ?? ''} />
        {safeArray(brief.mercado?.competidores).length > 0 && (
          <div className="mt-3">
            <p className="text-[#64748B] text-xs mb-2">Competidores</p>
            <div className="space-y-2">
              {safeArray(brief.mercado?.competidores).map((c, i) => (
                <div key={i} className="bg-[#0B0F1A] rounded-lg p-3">
                  <p className="text-white text-sm font-medium">{c.nombre}</p>
                  <p className="text-[#10B981] text-xs mt-1">✓ {c.fortaleza}</p>
                  <p className="text-[#EF4444] text-xs mt-0.5">✗ {c.debilidad}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        {safeArray(brief.mercado?.espaciosVacios).length > 0 && (
          <BriefList label="Espacios vacíos" items={safeArray(brief.mercado?.espaciosVacios)} />
        )}
        {safeArray(brief.mercado?.tendencias).length > 0 && (
          <BriefList label="Tendencias" items={safeArray(brief.mercado?.tendencias)} />
        )}
      </BriefSection>

      {/* Dirección comunicacional */}
      <BriefSection title="Dirección comunicacional">
        {safeArray(brief.direccionComunicacional?.territoriosTematicos).length > 0 && (
          <BriefList
            label="Territorios temáticos"
            items={safeArray(brief.direccionComunicacional?.territoriosTematicos)}
          />
        )}
        {safeArray(brief.direccionComunicacional?.queNoDecir).length > 0 && (
          <BriefList
            label="Qué NO decir"
            items={safeArray(brief.direccionComunicacional?.queNoDecir)}
            variant="negative"
          />
        )}
        <BriefRow label="Rango de precios a comunicar" value={brief.direccionComunicacional?.rangoPrecios ?? ''} />
      </BriefSection>

      {/* Decisiones pendientes */}
      {safeArray(brief.decisionesPendientes).length > 0 && (
        <BriefSection title="Decisiones pendientes">
          <div className="space-y-4">
            {safeArray(brief.decisionesPendientes).map((d, i) => (
              <div key={i}>
                <p className="text-white text-sm font-medium mb-2">{d.tema}</p>
                <div className="space-y-2">
                  {safeArray(d.opciones).map((o, j) => (
                    <div key={j} className="bg-[#0B0F1A] rounded-lg p-3">
                      <p className="text-[#A78BFA] text-xs font-medium">{o.opcion}</p>
                      <p className="text-[#10B981] text-xs mt-1">+ {o.pro}</p>
                      <p className="text-[#EF4444] text-xs mt-0.5">- {o.contra}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </BriefSection>
      )}

      {/* Acciones */}
      {canApprove && (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 space-y-4">
          <p className="text-white text-sm font-medium">¿Estás de acuerdo con este análisis?</p>
          <textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="Si querés pedir cambios, escribí tu feedback aquí..."
            rows={3}
            maxLength={2000}
            className="w-full bg-[#0B0F1A] border border-[#1E293B] rounded-lg px-3 py-2.5 text-[#94A3B8] text-sm placeholder:text-[#475569] focus:outline-none focus:border-[#8B5CF6]/50 resize-none"
          />
          {error && <p className="text-[#EF4444] text-sm">{error}</p>}
          <div className="flex gap-3">
            <button
              type="button"
              disabled={isPending}
              onClick={() => handleAction('approve')}
              className="px-5 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Aprobar brief
            </button>
            <button
              type="button"
              disabled={isPending}
              onClick={() => handleAction('reject')}
              className="px-5 py-2 bg-[#1E293B] text-[#94A3B8] text-sm font-medium rounded-lg hover:bg-[#334155] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Pedir cambios
            </button>
          </div>
        </div>
      )}

      {!canApprove && (
        <div className="bg-[#10B981]/10 border border-[#10B981]/30 rounded-xl px-5 py-4">
          <p className="text-[#10B981] text-sm font-medium">Brief aprobado</p>
          <p className="text-[#94A3B8] text-xs mt-1">Ya aprobaste este análisis. Avanzamos a la siguiente etapa.</p>
        </div>
      )}
    </div>
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function BriefSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <h4 className="text-white text-sm font-semibold mb-4">{title}</h4>
      <div className="space-y-3">{children}</div>
    </div>
  )
}

function BriefRow({ label, value }: { label: string; value: string }) {
  if (!value || value.trim() === '') return null
  return (
    <div>
      <p className="text-[#64748B] text-xs mb-0.5">{label}</p>
      <p className="text-[#94A3B8] text-sm leading-relaxed">{value}</p>
    </div>
  )
}

function BriefList({
  label,
  items,
  variant = 'neutral',
}: {
  label: string
  items: string[]
  variant?: 'neutral' | 'negative'
}) {
  const safeItems = safeArray(items)
  if (safeItems.length === 0) return null
  return (
    <div>
      <p className="text-[#64748B] text-xs mb-1.5">{label}</p>
      <ul className="space-y-1">
        {safeItems.map((item, i) => (
          <li key={i} className="flex items-start gap-2">
            <span
              className={`flex-shrink-0 mt-1.5 w-1 h-1 rounded-full ${
                variant === 'negative' ? 'bg-[#EF4444]' : 'bg-[#8B5CF6]'
              }`}
              aria-hidden="true"
            />
            <span className="text-[#94A3B8] text-sm leading-relaxed">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
