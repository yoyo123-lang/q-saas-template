/**
 * GET /api/ads/google/callback?code=xxx&state=xxx
 *
 * Callback de Google OAuth. Intercambia el code por tokens y guarda la cuenta.
 * Redirige al portal del cliente si todo sale bien.
 */
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { exchangeGoogleCode } from '@qautiva/ads/google'
import { encryptToken } from '@qautiva/ads/shared'

const STATE_COOKIE = 'ads_google_oauth_state'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get('code')
  const state = searchParams.get('state')
  const error = searchParams.get('error')

  // El usuario canceló el flujo en Google
  if (error) {
    console.warn('[ads/google/callback] User denied access or error:', error)
    return redirectWithError('Cancelaste la conexión con Google Ads. Podés intentarlo de nuevo.')
  }

  if (!code || !state) {
    return redirectWithError('Respuesta inválida de Google. Intentá de nuevo.')
  }

  // 1. Verificar CSRF: el state debe coincidir con la cookie
  const cookieStore = cookies()
  const storedState = cookieStore.get(STATE_COOKIE)?.value

  if (!storedState || storedState !== state) {
    console.error('[ads/google/callback] State mismatch — possible CSRF', {
      storedState: storedState ? '[present]' : '[missing]',
      receivedState: '[present]',
    })
    return redirectWithError('Sesión inválida. Iniciá el proceso de conexión de nuevo.')
  }

  // Extraer projectId del state (formato: `${projectId}|${nonce}`)
  const projectId = state.split('|')[0]
  if (!projectId) {
    return redirectWithError('Estado de sesión inválido.')
  }

  // 2. Verificar autenticación
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return redirectWithError('Tu sesión expiró. Iniciá sesión e intentá de nuevo.')
  }

  // 3. Verificar ownership del proyecto
  const profile = await prisma.userProfile.findFirst({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile) {
    console.error('[ads/google/callback] Profile not found', { userId: user.id })
    return redirectWithError('Perfil no encontrado.')
  }

  const teamIds = profile.teamMemberships.map(m => m.teamId)
  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, teamId: true },
  })

  if (!project) {
    console.error('[ads/google/callback] Project not found or unauthorized', { userId: user.id, projectId })
    return redirectWithError('Proyecto no encontrado.')
  }

  // 4. Intercambiar code por tokens
  let tokens
  try {
    tokens = await exchangeGoogleCode(code)
  } catch (err) {
    console.error('[ads/google/callback] Token exchange failed', { userId: user.id, projectId })
    return redirectWithError('No pudimos conectar con Google Ads. Intentá de nuevo.')
  }

  // 5. Obtener info de la cuenta vía REST (sin gRPC — evita bundling issues en callback)
  let accountInfo = { customerId: 'unknown', name: 'Cuenta Google Ads', currency: 'ARS', timezone: 'America/Argentina/Buenos_Aires' }
  try {
    const developerToken = process.env.GOOGLE_ADS_DEVELOPER_TOKEN
    if (developerToken) {
      const res = await fetch(
        'https://googleads.googleapis.com/v19/customers:listAccessibleCustomers',
        {
          headers: {
            Authorization: `Bearer ${tokens.accessToken}`,
            'developer-token': developerToken,
          },
          signal: AbortSignal.timeout(10_000),
        },
      )
      if (res.ok) {
        const data = await res.json() as { resourceNames?: string[] }
        const firstCustomer = data.resourceNames?.[0]
        if (firstCustomer) {
          // Formato: "customers/123456789" → "123-456-789"
          const rawId = firstCustomer.replace('customers/', '')
          accountInfo.customerId = rawId
          accountInfo.name = `Google Ads (${rawId})`
        }
      }
    }
  } catch {
    // Non-fatal: guardamos igual con nombre genérico
    console.warn('[ads/google/callback] Could not fetch account info — using defaults', { userId: user.id, projectId })
  }

  // 6. Encriptar tokens y guardar en DB
  try {
    await prisma.adAccount.upsert({
      where: {
        projectId_platform_externalId: {
          projectId: project.id,
          platform: 'GOOGLE_ADS',
          externalId: accountInfo.customerId,
        },
      },
      create: {
        projectId: project.id,
        teamId: project.teamId,
        platform: 'GOOGLE_ADS',
        externalId: accountInfo.customerId,
        name: accountInfo.name,
        accessToken: encryptToken(tokens.accessToken),
        refreshToken: encryptToken(tokens.refreshToken),
        tokenExpiresAt: tokens.expiresAt,
        status: 'ACTIVE',
        metadata: {
          currency: accountInfo.currency,
          timezone: accountInfo.timezone,
          scope: tokens.scope,
        },
      },
      update: {
        accessToken: encryptToken(tokens.accessToken),
        refreshToken: encryptToken(tokens.refreshToken),
        tokenExpiresAt: tokens.expiresAt,
        status: 'ACTIVE',
        revokedAt: null,
        metadata: {
          currency: accountInfo.currency,
          timezone: accountInfo.timezone,
          scope: tokens.scope,
        },
      },
    })
  } catch (err) {
    console.error('[ads/google/callback] Failed to save AdAccount', { userId: user.id, projectId })
    return redirectWithError('No pudimos guardar la conexión. Contactá a soporte.')
  }

  // 7. Limpiar cookie de state y redirigir al progreso del proyecto
  const successUrl = `/proyectos/${project.id}/publicidad?connected=google`
  const response = NextResponse.redirect(new URL(successUrl, request.url))
  response.cookies.delete(STATE_COOKIE)

  return response
}

function redirectWithError(message: string): NextResponse {
  // Redirigir al portal con error en query param — la UI lo muestra como toast/banner
  // La cookie se limpia siempre para evitar replay de state tokens
  const url = new URL('/proyectos', process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3001')
  url.searchParams.set('ads_error', message)
  const response = NextResponse.redirect(url)
  response.cookies.delete(STATE_COOKIE)
  return response
}
