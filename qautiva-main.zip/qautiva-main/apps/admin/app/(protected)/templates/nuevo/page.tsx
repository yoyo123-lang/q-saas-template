import { StitchGenerator } from './_components/StitchGenerator'

export default function NuevoTemplatePage() {
  return <StitchGenerator />
}
