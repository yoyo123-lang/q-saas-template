import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockRequireAdminSession = vi.fn()
const mockStageFindUnique = vi.fn()
const mockStageUpdate = vi.fn()
const mockAdminNoteCreate = vi.fn()
const mockTransaction = vi.fn()
const mockRevalidatePath = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  requireAdminSession: mockRequireAdminSession,
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    organization: { findUnique: vi.fn() },
    stage: {
      findUnique: mockStageFindUnique,
      update: mockStageUpdate,
    },
    adminNote: {
      create: mockAdminNoteCreate,
    },
    $transaction: mockTransaction,
  },
}))

vi.mock('@/lib/audit', () => ({
  logAudit: vi.fn(),
}))

vi.mock('next/cache', () => ({
  revalidatePath: mockRevalidatePath,
}))

function makeFormData(fields: Record<string, string>): FormData {
  const fd = new FormData()
  for (const [key, val] of Object.entries(fields)) {
    fd.append(key, val)
  }
  return fd
}

// ── approveStage ──────────────────────────────────────────────────────────────

describe('approveStage', () => {
  beforeEach(() => {
    vi.resetModules()
    mockRequireAdminSession.mockReset()
    mockStageFindUnique.mockReset()
    mockStageUpdate.mockReset()
    mockRevalidatePath.mockReset()
  })

  it('lanza si falta stageId', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })

    const { approveStage } = await import('../../lib/actions')
    await expect(approveStage(makeFormData({ orgId: 'org-1' }))).rejects.toThrow('stageId requerido')
  })

  it('lanza si falta orgId', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })

    const { approveStage } = await import('../../lib/actions')
    await expect(approveStage(makeFormData({ stageId: 'stage-1' }))).rejects.toThrow('orgId requerido')
  })

  it('lanza si la etapa no existe', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce(null)

    const { approveStage } = await import('../../lib/actions')
    await expect(approveStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1' }))).rejects.toThrow(
      'Etapa no encontrada',
    )
  })

  it('lanza si la etapa pertenece a otra org (IDOR)', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'ADMIN_REVIEW',
      number: 2,
      organizationId: 'org-OTRA',
    })

    const { approveStage } = await import('../../lib/actions')
    await expect(approveStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1' }))).rejects.toThrow(
      'no pertenece a la organización',
    )
  })

  it('lanza si la etapa no está en ADMIN_REVIEW', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'CLIENT_REVIEW',
      number: 2,
      organizationId: 'org-1',
    })

    const { approveStage } = await import('../../lib/actions')
    await expect(approveStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1' }))).rejects.toThrow(
      'ya no está pendiente de revisión',
    )
  })

  it('lanza si prisma.update falla', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'ADMIN_REVIEW',
      number: 2,
      organizationId: 'org-1',
    })
    mockStageUpdate.mockRejectedValueOnce(new Error('DB error'))

    const { approveStage } = await import('../../lib/actions')
    await expect(approveStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1' }))).rejects.toThrow(
      'No se pudo aprobar',
    )
  })

  it('aprueba la etapa y revalida los paths correctos', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'ADMIN_REVIEW',
      number: 2,
      organizationId: 'org-1',
    })
    mockStageUpdate.mockResolvedValueOnce({ id: 'stage-1', status: 'CLIENT_REVIEW' })

    const { approveStage } = await import('../../lib/actions')
    await approveStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1' }))

    expect(mockStageUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: 'stage-1' },
        data: expect.objectContaining({
          adminApproved: true,
          status: 'CLIENT_REVIEW',
        }),
      }),
    )
    expect(mockRevalidatePath).toHaveBeenCalledWith('/revision')
    expect(mockRevalidatePath).toHaveBeenCalledWith('/clientes/org-1')
  })
})

// ── rejectStage ───────────────────────────────────────────────────────────────

describe('rejectStage', () => {
  beforeEach(() => {
    vi.resetModules()
    mockRequireAdminSession.mockReset()
    mockStageFindUnique.mockReset()
    mockTransaction.mockReset()
    mockRevalidatePath.mockReset()
  })

  it('lanza si falta stageId', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })

    const { rejectStage } = await import('../../lib/actions')
    await expect(
      rejectStage(makeFormData({ orgId: 'org-1', feedback: 'Hay errores' })),
    ).rejects.toThrow('stageId requerido')
  })

  it('lanza si falta feedback', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })

    const { rejectStage } = await import('../../lib/actions')
    await expect(
      rejectStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1' })),
    ).rejects.toThrow('motivo de rechazo es requerido')
  })

  it('lanza si feedback supera 1000 caracteres', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })

    const { rejectStage } = await import('../../lib/actions')
    await expect(
      rejectStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1', feedback: 'x'.repeat(1001) })),
    ).rejects.toThrow('1000 caracteres')
  })

  it('lanza si la etapa no existe', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce(null)

    const { rejectStage } = await import('../../lib/actions')
    await expect(
      rejectStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1', feedback: 'Hay errores' })),
    ).rejects.toThrow('Etapa no encontrada')
  })

  it('lanza si la etapa pertenece a otra org (IDOR)', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'ADMIN_REVIEW',
      number: 2,
      name: 'Marca',
      organizationId: 'org-OTRA',
    })

    const { rejectStage } = await import('../../lib/actions')
    await expect(
      rejectStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1', feedback: 'Hay errores' })),
    ).rejects.toThrow('no pertenece a la organización')
  })

  it('lanza si la etapa no está en ADMIN_REVIEW', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'REVISION',
      number: 2,
      name: 'Marca',
      organizationId: 'org-1',
    })

    const { rejectStage } = await import('../../lib/actions')
    await expect(
      rejectStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1', feedback: 'Hay errores' })),
    ).rejects.toThrow('ya no está pendiente de revisión')
  })

  it('rechaza la etapa con transaction y revalida paths', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'ADMIN_REVIEW',
      number: 2,
      name: 'Marca',
      organizationId: 'org-1',
    })
    mockTransaction.mockResolvedValueOnce([{}, {}])

    const { rejectStage } = await import('../../lib/actions')
    await rejectStage(makeFormData({ stageId: 'stage-1', orgId: 'org-1', feedback: 'Faltan detalles' }))

    expect(mockTransaction).toHaveBeenCalled()
    expect(mockRevalidatePath).toHaveBeenCalledWith('/revision')
    expect(mockRevalidatePath).toHaveBeenCalledWith('/clientes/org-1')
  })

  it('recorta espacios del feedback antes de guardar', async () => {
    mockRequireAdminSession.mockResolvedValueOnce({ userId: 'admin-1' })
    mockStageFindUnique.mockResolvedValueOnce({
      id: 'stage-1',
      status: 'ADMIN_REVIEW',
      number: 2,
      name: 'Marca',
      organizationId: 'org-1',
    })
    // Capturar el array que se pasa a $transaction para verificar el contenido de la nota
    mockTransaction.mockImplementationOnce(async (ops: unknown[]) => ops)

    const { rejectStage } = await import('../../lib/actions')
    await rejectStage(
      makeFormData({ stageId: 'stage-1', orgId: 'org-1', feedback: '  Faltan detalles  ' }),
    )

    // El $transaction recibe un array de promesas de Prisma — verificamos que fue llamado
    expect(mockTransaction).toHaveBeenCalled()
  })
})
