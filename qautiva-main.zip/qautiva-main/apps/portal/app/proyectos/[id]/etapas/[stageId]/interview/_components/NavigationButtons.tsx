/**
 * Botones de navegación del Interview Engine.
 *
 * - [Anterior]: retrocede un paso (oculto en el primer paso)
 * - [Siguiente]: avanza un paso (visible si no es el último)
 * - [Enviar respuestas]: envía la entrevista (visible en el último paso)
 *
 * El retroceso intra-etapa es funcionalidad BÁSICA (plan A3).
 */

type Props = {
  currentStep: number
  isLastStep: boolean
  isLoading: boolean
  onBack?: () => void
  onNext?: () => void
  onSubmit?: () => void
}

export function NavigationButtons({
  currentStep,
  isLastStep,
  isLoading,
  onBack,
  onNext,
  onSubmit,
}: Props) {
  return (
    <div className="flex items-center justify-between gap-3 mt-2">
      {/* Botón Anterior */}
      <div>
        {currentStep > 0 && onBack ? (
          <button
            type="button"
            onClick={onBack}
            disabled={isLoading}
            className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#94A3B8] hover:text-white bg-[#0F172A] hover:bg-[#1E293B] border border-[#1E293B] hover:border-[#334155] rounded-lg transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              aria-hidden="true"
            >
              <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Anterior
          </button>
        ) : (
          // Placeholder para mantener el layout cuando no hay botón Anterior
          <div />
        )}
      </div>

      {/* Botón Siguiente / Enviar */}
      <div>
        {isLastStep ? (
          <button
            type="button"
            onClick={onSubmit}
            disabled={isLoading}
            className="flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-[#10B981] hover:bg-[#059669] rounded-lg transition-colors duration-150 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <svg
                  className="animate-spin"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  aria-hidden="true"
                >
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
                Enviando...
              </>
            ) : (
              <>
                Enviar respuestas
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  aria-hidden="true"
                >
                  <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </>
            )}
          </button>
        ) : (
          <button
            type="button"
            onClick={onNext}
            disabled={isLoading}
            className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-lg transition-colors duration-150 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <svg
                  className="animate-spin"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  aria-hidden="true"
                >
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
                Guardando...
              </>
            ) : (
              <>
                Siguiente
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  aria-hidden="true"
                >
                  <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  )
}
