'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { AccountsPanel } from './AccountsPanel'
import { JobsTable } from './JobsTable'

interface StitchAccountData {
  id: string
  label: string
  usedToday: number
  dailyLimit: number
  lastResetAt: string
  active: boolean
}

interface QueueJob {
  id: string
  queueStatus: 'QUEUED' | 'GENERATING' | 'DONE' | 'ERROR'
  queuedAt: string | null
  styleId: string | null
  compatibleIndustries: string[]
  status: 'DRAFT' | 'ACTIVE'
  stitchAccount: { id: string; label: string } | null
  queueError: string | null
  createdAt: string
  updatedAt: string
}

interface QueueViewProps {
  initialAccounts: StitchAccountData[]
  initialJobs: QueueJob[]
  initialCounts: { pending: number; generating: number; done: number }
  initialPaused: boolean
}

const POLL_INTERVAL_MS = 6_000 // Polling cada 6s cuando hay jobs GENERATING

export function QueueView({ initialAccounts, initialJobs, initialCounts, initialPaused }: QueueViewProps) {
  const [accounts, setAccounts] = useState<StitchAccountData[]>(initialAccounts)
  const [jobs, setJobs] = useState<QueueJob[]>(initialJobs)
  const [counts, setCounts] = useState(initialCounts)
  const [isPaused, setIsPaused] = useState(initialPaused)
  const [error, setError] = useState<string | null>(null)

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const hasGenerating = jobs.some((j) => j.queueStatus === 'GENERATING')
  const hasCredits = accounts
    .filter((a) => a.active)
    .some((a) => a.usedToday < a.dailyLimit)

  const refresh = useCallback(async () => {
    try {
      const [jobsRes, accountsRes, configRes] = await Promise.all([
        fetch('/api/stitch/queue?limit=100'),
        fetch('/api/stitch/accounts'),
        fetch('/api/stitch/queue/config'),
      ])

      if (!jobsRes.ok || !accountsRes.ok) return

      const [jobsData, accountsData, configData] = await Promise.all([
        jobsRes.json() as Promise<{ jobs: QueueJob[]; pagination: { total: number } }>,
        accountsRes.json() as Promise<{ accounts: StitchAccountData[] }>,
        configRes.ok ? configRes.json() as Promise<{ paused: boolean }> : Promise.resolve({ paused: isPaused }),
      ])

      setIsPaused(configData.paused)

      const newJobs = jobsData.jobs
      setJobs(newJobs)
      setAccounts(accountsData.accounts)
      setCounts({
        pending: newJobs.filter((j) => j.queueStatus === 'QUEUED').length,
        generating: newJobs.filter((j) => j.queueStatus === 'GENERATING').length,
        done: newJobs.filter((j) => j.queueStatus === 'DONE').length,
      })
    } catch {
      // No mostrar error en refresh automático
    }
  }, [])

  // Polling mientras haya jobs GENERATING
  useEffect(() => {
    if (hasGenerating) {
      pollRef.current = setInterval(() => void refresh(), POLL_INTERVAL_MS)
    } else {
      if (pollRef.current) {
        clearInterval(pollRef.current)
        pollRef.current = null
      }
    }
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [hasGenerating, refresh])

  async function handleTogglePause() {
    setError(null)
    const res = await fetch('/api/stitch/queue/config', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paused: !isPaused }),
    })
    const data = (await res.json()) as { paused?: boolean; error?: string }
    if (!res.ok) {
      setError(data.error ?? 'Error al cambiar estado de la cola')
      return
    }
    setIsPaused(data.paused ?? !isPaused)
  }

  async function handleFactory(targetCount: 1 | 2 | 3) {
    setError(null)
    const res = await fetch('/api/stitch/queue/factory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetCount }),
    })

    const data = (await res.json()) as { enqueued?: number; skipped?: number; error?: string }

    if (!res.ok) {
      throw new Error(data.error ?? 'Error al encolar')
    }

    await refresh()
    return `${data.enqueued} jobs encolados, ${data.skipped} saltados`
  }

  async function handleRun(jobId: string) {
    setError(null)
    const res = await fetch(`/api/stitch/queue/${jobId}/run`, { method: 'POST' })
    const data = (await res.json()) as { error?: string }

    if (!res.ok) {
      setError(data.error ?? 'Error al ejecutar el job')
      return
    }

    await refresh()
  }

  async function handleDelete(jobId: string) {
    setError(null)
    const res = await fetch(`/api/stitch/queue/${jobId}`, { method: 'DELETE' })
    const data = (await res.json()) as { error?: string }

    if (!res.ok) {
      setError(data.error ?? 'Error al cancelar el job')
      return
    }

    setJobs((prev) => prev.filter((j) => j.id !== jobId))
    setCounts((prev) => ({ ...prev, pending: Math.max(0, prev.pending - 1) }))
  }

  return (
    <div className="flex flex-col gap-6">
      {error && (
        <div className="px-4 py-3 border border-red-400/20 bg-red-400/10 rounded-lg text-red-400 text-sm">
          {error}
        </div>
      )}

      <AccountsPanel
        accounts={accounts}
        pendingCount={counts.pending}
        generatingCount={counts.generating}
        doneCount={counts.done}
        isPaused={isPaused}
        onFactory={handleFactory}
        onRefresh={() => void refresh()}
        onTogglePause={handleTogglePause}
      />

      <JobsTable
        jobs={jobs}
        hasCredits={hasCredits}
        onRun={handleRun}
        onDelete={handleDelete}
      />

      {hasGenerating && (
        <p className="text-xs text-[#475569] text-center">
          Hay {counts.generating} job{counts.generating !== 1 ? 's' : ''} generando. Actualizando automáticamente...
        </p>
      )}
    </div>
  )
}
