export const dynamic = 'force-dynamic'

import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { formatDate } from '@/lib/format'

export const metadata: Metadata = { title: 'Mis dominios — Qautiva' }

type DomainStatus = 'ACTIVE' | 'PENDING_PAYMENT' | 'PENDING' | 'REGISTERING' | 'RENEWAL_DUE' | 'FAILED' | 'EXPIRED' | 'CANCELLED'

type StatusFilter = 'all' | 'activos' | 'pendientes'

const PAGE_SIZE = 20

const STATUS_BADGE = {
  ACTIVE:          { label: 'Activo',           className: 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40' },
  PENDING_PAYMENT: { label: 'Pago pendiente',   className: 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40' },
  PENDING:         { label: 'Procesando',       className: 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40' },
  REGISTERING:     { label: 'Registrando',      className: 'bg-[#3B82F6]/20 text-[#60A5FA] border border-[#3B82F6]/40' },
  RENEWAL_DUE:     { label: 'Renovación próx.', className: 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40' },
  FAILED:          { label: 'Fallido',          className: 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40' },
  EXPIRED:         { label: 'Expirado',         className: 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40' },
  CANCELLED:       { label: 'Cancelado',        className: 'bg-[#64748B]/20 text-[#94A3B8] border border-[#64748B]/40' },
} as const

function StatusBadge({ status }: { status: DomainStatus }) {
  const badge = STATUS_BADGE[status] ?? { label: status, className: 'bg-[#64748B]/20 text-[#94A3B8] border border-[#64748B]/40' }
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-medium ${badge.className}`}>
      {badge.label}
    </span>
  )
}

function filterLabel(f: StatusFilter): string {
  if (f === 'activos') return 'Activos'
  if (f === 'pendientes') return 'Pendientes'
  return 'Todos'
}

const STATUS_FILTERS: StatusFilter[] = ['all', 'activos', 'pendientes']

export default async function DominiosPage({
  searchParams,
}: {
  searchParams?: { status?: string; registered?: string; page?: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  let profile = null
  try {
    profile = await prisma.userProfile.findUnique({
      where: { authUserId: user.id },
      select: {
        teamMemberships: {
          select: { teamId: true },
          orderBy: { createdAt: 'asc' },
        },
      },
    })
  } catch {
    // La tabla puede no existir todavía (migración pendiente)
  }

  const teamId = profile?.teamMemberships[0]?.teamId

  if (!teamId) {
    return (
      <div className="p-8 max-w-3xl">
        <h1 className="text-2xl font-bold text-[#F8FAFC] mb-4">Mis dominios</h1>
        <p className="text-[#94A3B8]">No hay un equipo asignado a tu cuenta.</p>
      </div>
    )
  }

  const rawFilter = searchParams?.status as StatusFilter | undefined
  const activeFilter: StatusFilter =
    rawFilter && STATUS_FILTERS.includes(rawFilter) ? rawFilter : 'all'

  const page = Math.max(1, parseInt(searchParams?.page ?? '1', 10) || 1)

  const statusWhere =
    activeFilter === 'activos'
      ? { status: 'ACTIVE' as DomainStatus }
      : activeFilter === 'pendientes'
        ? { status: 'PENDING' as DomainStatus }
        : {}

  const where = { teamId, deletedAt: null, ...statusWhere }

  let domains: Array<{
    id: string
    domainName: string
    tld: string
    status: string
    period: number
    paidAmountArs: unknown
    registeredAt: Date | null
    expiresAt: Date | null
    autoRenew: boolean
    createdAt: Date
  }> = []
  let totalCount = 0
  let domainsUnavailable = false

  try {
    ;[domains, totalCount] = await Promise.all([
      prisma.domain.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: PAGE_SIZE,
        skip: (page - 1) * PAGE_SIZE,
        select: {
          id: true,
          domainName: true,
          tld: true,
          status: true,
          period: true,
          paidAmountArs: true,
          registeredAt: true,
          expiresAt: true,
          autoRenew: true,
          createdAt: true,
        },
      }),
      prisma.domain.count({ where }),
    ])
  } catch {
    // La tabla Domain puede no existir todavía (migración pendiente)
    domainsUnavailable = true
  }

  const totalPages = Math.ceil(totalCount / PAGE_SIZE)

  if (domainsUnavailable) {
    return (
      <div className="p-6 max-w-5xl">
        <h1 className="text-2xl font-bold text-[#F8FAFC] mb-6">Mis dominios</h1>
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">Próximamente disponible.</p>
        </div>
      </div>
    )
  }

  const showRegistered = searchParams?.registered === '1'

  return (
    <div className="p-6 max-w-5xl">
      {showRegistered && (
        <div
          role="status"
          className="mb-4 px-4 py-3 rounded-lg bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40 text-sm"
        >
          Dominio registrado correctamente. Puede demorar unos minutos en activarse.
        </div>
      )}

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-[#F8FAFC]">Mis dominios</h1>
        <Link
          href="/dominios/buscar"
          className="px-4 py-2 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200"
        >
          Buscar dominio
        </Link>
      </div>

      {/* Filtros */}
      <div className="flex gap-2 mb-6">
        {STATUS_FILTERS.map((f) => (
          <Link
            key={f}
            href={f === 'all' ? '/dominios' : `/dominios?status=${f}`}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors duration-200 ${
              activeFilter === f
                ? 'bg-[#8B5CF6] text-white'
                : 'text-[#94A3B8] hover:text-white hover:bg-[#1E293B]'
            }`}
          >
            {filterLabel(f)}
          </Link>
        ))}
      </div>

      {domains.length === 0 ? (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8] mb-4">
            Todavía no tenés dominios registrados.
          </p>
          <Link
            href="/dominios/buscar"
            className="text-[#8B5CF6] text-sm font-medium hover:text-[#A78BFA] transition-colors duration-200"
          >
            Buscar un dominio
          </Link>
        </div>
      ) : (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1E293B]">
                <th className="text-left px-4 py-3 text-[#94A3B8] font-medium">Dominio</th>
                <th className="text-left px-4 py-3 text-[#94A3B8] font-medium">Estado</th>
                <th className="text-left px-4 py-3 text-[#94A3B8] font-medium">Vence</th>
                <th className="text-left px-4 py-3 text-[#94A3B8] font-medium">Renovación auto</th>
              </tr>
            </thead>
            <tbody>
              {domains.map((d, i) => (
                <tr
                  key={d.id}
                  className={`${i < domains.length - 1 ? 'border-b border-[#1E293B]' : ''}`}
                >
                  <td className="px-4 py-3 text-[#F8FAFC] font-medium">
                    {d.domainName}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={d.status as DomainStatus} />
                  </td>
                  <td className="px-4 py-3 text-[#94A3B8]">
                    {d.expiresAt ? formatDate(d.expiresAt) : '—'}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-medium ${
                        d.autoRenew
                          ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40'
                          : 'text-[#94A3B8]'
                      }`}
                    >
                      {d.autoRenew ? 'Sí' : 'No'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Paginación */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <Link
            href={page > 1 ? `/dominios?${new URLSearchParams({ ...(activeFilter !== 'all' ? { status: activeFilter } : {}), page: String(page - 1) }).toString()}` : '#'}
            aria-disabled={page <= 1}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors duration-200 ${
              page <= 1
                ? 'text-[#64748B] pointer-events-none'
                : 'text-[#94A3B8] hover:text-white hover:bg-[#1E293B]'
            }`}
          >
            Anterior
          </Link>
          <span className="text-[#64748B] text-sm">
            Página {page} de {totalPages}
          </span>
          <Link
            href={page < totalPages ? `/dominios?${new URLSearchParams({ ...(activeFilter !== 'all' ? { status: activeFilter } : {}), page: String(page + 1) }).toString()}` : '#'}
            aria-disabled={page >= totalPages}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors duration-200 ${
              page >= totalPages
                ? 'text-[#64748B] pointer-events-none'
                : 'text-[#94A3B8] hover:text-white hover:bg-[#1E293B]'
            }`}
          >
            Siguiente
          </Link>
        </div>
      )}
    </div>
  )
}
