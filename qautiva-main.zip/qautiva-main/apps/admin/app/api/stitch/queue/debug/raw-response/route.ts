import { NextResponse } from 'next/server'

/**
 * GET /api/stitch/queue/debug/raw-response
 *
 * DESHABILITADO en producción. Consume 1 crédito de Stitch por ejecución.
 *
 * Para reactivar este endpoint de debug:
 * 1. Descomentar el código de abajo
 * 2. Agregar los imports: requireAdminSession, debugStitchRawResponsesStreamed, prisma
 * 3. Deploy a Vercel
 * 4. Acceder como admin a /api/stitch/queue/debug/raw-response
 * 5. Ver NDJSON streamed en el browser — cada paso de Stitch aparece como una línea JSON
 * 6. RECORDAR deshabilitar de nuevo después de diagnosticar
 *
 * Referencia: docs/KNOWN_ISSUES.md → "2026-03-20 — Stitch API: outputComponents[0]"
 * Código fuente del flujo de debug: packages/stitch/src/debug-raw.ts
 *
 * --- Código deshabilitado ---
 *
 * import { requireAdminSession } from '@/lib/supabase-server'
 * import { debugStitchRawResponsesStreamed } from '@qautiva/stitch'
 * import { prisma } from '@qautiva/db'
 *
 * export const maxDuration = 300
 *
 * export async function GET(): Promise<Response> {
 *   try { await requireAdminSession() } catch {
 *     return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
 *   }
 *   const account = await prisma.stitchAccount.findFirst({
 *     where: { active: true },
 *     select: { apiKey: true, label: true },
 *     orderBy: { usedToday: 'asc' },
 *   })
 *   if (!account?.apiKey) {
 *     return NextResponse.json({ error: 'No hay cuentas Stitch activas' }, { status: 500 })
 *   }
 *   const stream = new ReadableStream({
 *     async start(controller) {
 *       const encoder = new TextEncoder()
 *       const send = (data: Record<string, unknown>) => {
 *         controller.enqueue(encoder.encode(JSON.stringify(data) + '\n'))
 *       }
 *       send({ step: 'start', account: account.label, startedAt: new Date().toISOString() })
 *       for await (const event of debugStitchRawResponsesStreamed(account.apiKey)) {
 *         send(event)
 *       }
 *       controller.close()
 *     },
 *   })
 *   return new Response(stream, {
 *     headers: {
 *       'Content-Type': 'text/plain; charset=utf-8',
 *       'Cache-Control': 'no-cache',
 *       'X-Content-Type-Options': 'nosniff',
 *     },
 *   })
 * }
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    {
      error: 'Endpoint de debug deshabilitado',
      help: 'Ver comentario en este archivo para instrucciones de reactivación',
    },
    { status: 410 },
  )
}
