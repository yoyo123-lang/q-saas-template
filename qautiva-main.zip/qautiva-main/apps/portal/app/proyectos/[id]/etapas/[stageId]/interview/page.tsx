import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { InterviewClient } from './client'
import { STAGE_LABELS } from './_types'
import { TemplateSelectionClient } from './_components/TemplateSelectionClient'
import TemplateRecommendationClient from './_components/TemplateRecommendationClient'

export const metadata: Metadata = { title: 'Entrevista — Qautiva' }

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export default async function InterviewPage({
  params,
}: {
  params: { id: string; stageId: string }
}) {
  // Validar formato UUID de los params antes de usarlos en queries
  if (!UUID_RE.test(params.id) || !UUID_RE.test(params.stageId)) notFound()

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) notFound()

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) notFound()

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  // Verificar que la etapa pertenece a este proyecto y al team del usuario
  const stage = await prisma.stage.findFirst({
    where: {
      id: params.stageId,
      project: { id: params.id, teamId: { in: teamIds }, deletedAt: null },
    },
    select: {
      id: true,
      number: true,
      stageKey: true,
      name: true,
      project: { select: { industry: true } },
    },
  })
  if (!stage) notFound()

  // Queries independientes en paralelo: bienvenida y sesión existente (si aplica)
  const [stageWelcome, existingSession] = await Promise.all([
    prisma.stageWelcome.findUnique({ where: { stageKey: stage.stageKey } }),
    stage.stageKey === 'WEBSITE'
      ? prisma.interviewSession.findUnique({
          where: { stageId: stage.id },
          select: {
            id: true,
            selectedWebTemplateId: true,
            flowDefinition: true,
            status: true,
          },
        })
      : Promise.resolve(null),
  ])

  const stageName = STAGE_LABELS[stage.number] ?? `Etapa ${stage.number}`

  // Gate para la etapa WEBSITE: verificar que haya template seleccionado antes de procesar.
  // Si la entrevista terminó (PROCESSING) pero no hay template → mostrar recomendación.
  // Este gate es independiente del prefijo de IDs (web_/website_) para cubrir todos los casos.
  if (stage.stageKey === 'WEBSITE') {
    const flowDef = (existingSession?.flowDefinition ?? []) as Array<{ id: string }>
    const isV1 = flowDef.some((q) => q.id.startsWith('website_'))

    // Gate universal: sesión en PROCESSING o ERROR sin template → seleccionar diseño primero.
    // ERROR cubre el caso donde el cron procesó la sesión antes de que el usuario eligiera template.
    if (
      existingSession &&
      (existingSession.status === 'PROCESSING' || existingSession.status === 'ERROR') &&
      !existingSession.selectedWebTemplateId
    ) {
      return (
        <TemplateRecommendationClient
          sessionId={existingSession.id}
          projectId={params.id}
          stageId={stage.id}
        />
      )
    }

    // Sesiones v1 legacy: template primero, luego entrevista
    if (isV1 && !existingSession?.selectedWebTemplateId) {
      return (
        <TemplateSelectionClient
          projectId={params.id}
          stageId={stage.id}
          stageNumber={stage.number}
          industry={stage.project?.industry ?? ''}
        />
      )
    }
  }

  return (
    <InterviewClient
      projectId={params.id}
      stageId={stage.id}
      stageNumber={stage.number}
      stageKey={stage.stageKey}
      stageName={stageName}
      welcomeData={
        stageWelcome
          ? {
              title: stageWelcome.title,
              description: stageWelcome.description,
              estimatedTime: stageWelcome.estimatedTime,
              whatYouGet: stageWelcome.whatYouGet,
              icon: stageWelcome.icon ?? undefined,
              fastTrackText: stageWelcome.fastTrackText ?? undefined,
            }
          : undefined
      }
    />
  )
}
