import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import Link from 'next/link'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { MediumStatus } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { OrderForm } from './OrderForm'

export const metadata: Metadata = { title: 'Crear pedido — Qautiva' }

async function getProductWithMedium(productId: string, mediumId: string) {
  return prisma.product.findFirst({
    where: {
      id: productId,
      mediumId,
      active: true,
      medium: { status: MediumStatus.ACTIVE, deletedAt: null },
    },
    select: {
      id: true,
      name: true,
      description: true,
      type: true,
      price: true,
      deliveryDays: true,
      includesWriting: true,
      medium: {
        select: {
          id: true,
          name: true,
          platform: true,
          userId: true,
        },
      },
    },
  })
}

export default async function ComprarPage({
  params,
}: {
  params: { mediumId: string; productId: string }
}) {
  // Auth requerida para comprar
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect(`/login?next=/marketplace/${params.mediumId}/comprar/${params.productId}`)
  }

  const product = await getProductWithMedium(params.productId, params.mediumId)
  if (!product) notFound()

  // El editor no puede comprarse a sí mismo
  if (product.medium.userId === user.id) {
    redirect(`/marketplace/${params.mediumId}`)
  }

  const formProduct = {
    id: product.id,
    name: product.name,
    price: product.price.toNumber(),
    deliveryDays: product.deliveryDays,
    includesWriting: product.includesWriting,
  }

  const formMedium = {
    id: product.medium.id,
    name: product.medium.name,
    platform: product.medium.platform,
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      {/* Breadcrumb */}
      <nav aria-label="Navegación" className="text-sm text-[#64748B] mb-6 flex items-center gap-2 flex-wrap">
        <Link href="/marketplace" className="hover:text-[#94A3B8] transition-colors">
          Marketplace
        </Link>
        <span>/</span>
        <Link
          href={`/marketplace/${product.medium.id}`}
          className="hover:text-[#94A3B8] transition-colors"
        >
          {product.medium.name}
        </Link>
        <span>/</span>
        <span className="text-[#94A3B8]">Crear pedido</span>
      </nav>

      <h1 className="text-2xl font-bold text-white mb-1">Crear pedido</h1>
      <p className="text-[#64748B] text-sm mb-6">{product.name}</p>

      <OrderForm product={formProduct} medium={formMedium} />
    </div>
  )
}
