# Sesión 1: Schema base y multi-tenancy (backend)

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 1
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md → formato de IMPLEMENTATION_PLAN.md
- docs/MULTI-AGENT.md → flujo de sub-agentes
- docs/TDD.md → test primero, código después
- docs/CONVENTIONS.md → convenciones del proyecto
- docs/ARCHITECTURE.md → arquitectura actual

## Objetivo

Modelos Organization, Membership, y todos los modelos de dominio de Fase 1 en Prisma. Helper `withTenant()` para queries scoped. Migración ejecutada. Tests unitarios.

## Pre-requisitos

Ninguno — es la primera sesión.

## Etapas

### Etapa 1: Schema Prisma completo
- Organization (name, slug, plan, settings, fiscalData)
- Membership (userId, organizationId, role: OWNER/ADMIN/MEMBER)
- Product, Category, ProductVariant
- PriceList, PriceListItem
- Contact (clientes y proveedores, con CUIT, condición IVA, domicilio fiscal)
- Invoice, InvoiceItem (factura A/B/C, NC, ND)
- Sale, SaleItem
- StockMovement, Warehouse
- CashRegister, PaymentRecord
- Subscription, Plan (Micro/Starter/Pro/Max)
- Todos los modelos con `tenantId` (excepto User y Plan)

### Etapa 2: Helper withTenant()
- Función que recibe tenantId y retorna un wrapper de Prisma que agrega `where: { tenantId }` automáticamente
- Debe funcionar con findMany, findFirst, findUnique, create, update, delete
- Type-safe con TypeScript

### Etapa 3: Migración y seed
- Ejecutar `npx prisma migrate dev`
- Seed con datos de ejemplo: un tenant demo, productos de muestra, un cliente, un proveedor

### Etapa 4: Tests unitarios
- Tests para withTenant: verificar que filtra correctamente por tenant
- Tests para validar que un tenant no puede acceder datos de otro
- Tests para los modelos (crear, leer, actualizar)

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md con las tareas atómicas
2. TDD: test primero → código después
3. Un commit por tarea atómica completada
4. Micro-revisión después de cada tarea
5. Al terminar: build + lint + test deben pasar

## Restricciones

- No instales dependencias sin mencionarlo explícitamente
- No toques archivos fuera del alcance de esta sesión
- Seguí las convenciones existentes del proyecto
