import Link from 'next/link'
import { MailCheck, Package, Eye, MessageCircle, DollarSign, ArrowRight } from 'lucide-react'
import { createClient } from '@/lib/supabase/server'
import { getPrisma } from '@/lib/prisma'
import { getSellerStats, getRecentActivity } from '@/lib/data/listings'
import { StatCard } from '@/components/ui/stat-card'
import { ActivityItem } from '@/components/shared/activity-item'
import { Badge } from '@/components/ui/badge'
import { ViewsChart } from '@/components/listings/views-chart'
import { statusBadgeVariant, statusLabels, typeLabels } from '@/lib/constants/listing-labels'

interface Props {
  searchParams: Promise<{ verificar?: string }>
}

function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`
  return String(n)
}

export default async function DashboardPage({ searchParams }: Props) {
  const supabase = await createClient()
  // Layout guarantees the user is authenticated; non-null assertion is safe here
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const { data: { user } } = await supabase.auth.getUser()
  const authedUser = user!

  const params = await searchParams
  const showVerifyBanner = params.verificar === '1'

  const prisma = getPrisma()

  // Ensure profile exists — the DB trigger may not have fired yet
  // (e.g. signInWithIdToken upserts auth.users, skipping AFTER INSERT trigger)
  let profile = await prisma.profile.findUnique({
    where: { id: authedUser.id },
    select: { fullName: true },
  })

  if (!profile) {
    await prisma.profile.upsert({
      where: { id: authedUser.id },
      create: {
        id: authedUser.id,
        email: authedUser.email ?? '',
        fullName: authedUser.user_metadata?.full_name ?? authedUser.user_metadata?.name ?? '',
        avatarUrl: authedUser.user_metadata?.avatar_url ?? null,
        role: 'BUYER',
      },
      update: {},
    })
    profile = await prisma.profile.findUnique({
      where: { id: authedUser.id },
      select: { fullName: true },
    })
  }

  const userName = profile?.fullName ?? authedUser.email?.split('@')[0] ?? 'Vendedor'

  const [stats, recentActivity] = await Promise.all([
    getSellerStats(authedUser.id),
    getRecentActivity(authedUser.id, 5),
  ])

  // Filter to seller's listings for preview
  const sellerPreview = await prisma.listing.findMany({
    where: { sellerId: authedUser.id },
    orderBy: { updatedAt: 'desc' },
    take: 4,
    select: {
      id: true,
      title: true,
      type: true,
      askingPrice: true,
      currency: true,
      status: true,
      viewCount: true,
    },
  })

  return (
    <div className="space-y-6">
      {showVerifyBanner && (
        <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/[0.08] px-4 py-3">
          <MailCheck size={18} className="text-amber-500 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-amber-400">Verificá tu email</p>
            <p className="text-xs text-slate-400 mt-0.5">
              Te enviamos un link de confirmación. Revisá tu casilla (incluso spam) para activar tu cuenta.
            </p>
          </div>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-slate-50">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">Bienvenido, {userName}</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label="Activos publicados"
          value={stats.publishedCount}
          icon={<Package size={20} className="text-amber-500" />}
        />
        <StatCard
          label="Vistas totales"
          value={formatNumber(stats.totalViews)}
          icon={<Eye size={20} className="text-amber-500" />}
          trend={{ value: 'este mes', positive: true }}
        />
        <StatCard
          label="Consultas activas"
          value={stats.activeInquiries}
          icon={<MessageCircle size={20} className="text-amber-500" />}
          pulse={stats.activeInquiries > 0}
        />
        <StatCard
          label="Revenue total listado"
          value={`$${formatNumber(stats.totalListedRevenue)} USD`}
          icon={<DollarSign size={20} className="text-amber-500" />}
          highlight
        />
      </div>

      {/* Chart + Activity */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <ViewsChart />
        </div>

        {/* Actividad reciente */}
        <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
          <h2 className="font-semibold text-slate-50 mb-2">Actividad reciente</h2>
          {recentActivity.length === 0 ? (
            <p className="text-sm text-slate-500 py-8 text-center">Sin actividad reciente</p>
          ) : (
            <div className="divide-y divide-slate-800">
              {recentActivity.map((item) => (
                <ActivityItem key={item.id} {...item} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Preview mis activos */}
      <div className="bg-navy-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <h2 className="font-semibold text-slate-50">Mis activos</h2>
          <Link
            href="/mis-activos"
            className="flex items-center gap-1 text-sm text-amber-500 hover:underline"
          >
            Ver todos <ArrowRight size={14} />
          </Link>
        </div>

        {sellerPreview.length === 0 ? (
          <div className="px-6 py-12 text-center text-slate-500 text-sm">
            Todavía no publicaste ningún activo.{' '}
            <Link href="/mis-activos/nuevo" className="text-amber-500 hover:underline">
              Publicá el primero
            </Link>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-800">
                {['Activo', 'Tipo', 'Precio', 'Estado', 'Vistas'].map((h) => (
                  <th
                    key={h}
                    className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sellerPreview.map((listing) => (
                <tr key={listing.id} className="border-b border-slate-800 last:border-0 hover:bg-slate-800/50 transition-colors">
                  <td className="px-6 py-3">
                    <Link
                      href={`/mis-activos/${listing.id}/editar`}
                      className="text-sm text-slate-200 hover:text-amber-500 transition-colors font-medium line-clamp-1"
                    >
                      {listing.title}
                    </Link>
                  </td>
                  <td className="px-6 py-3">
                    <Badge variant="info">{typeLabels[listing.type] ?? listing.type}</Badge>
                  </td>
                  <td className="px-6 py-3 text-sm text-slate-300">
                    ${Number(listing.askingPrice).toLocaleString()} {listing.currency}
                  </td>
                  <td className="px-6 py-3">
                    <Badge variant={statusBadgeVariant[listing.status] ?? 'muted'}>
                      {statusLabels[listing.status] ?? listing.status}
                    </Badge>
                  </td>
                  <td className="px-6 py-3 text-sm text-slate-400">{listing.viewCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
