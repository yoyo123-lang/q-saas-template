import { cn } from '@/lib/utils/cn'

interface SkeletonCardProps {
  className?: string
}

function Skeleton({ className }: { className?: string }) {
  return (
    <div className={cn('animate-pulse bg-slate-800 rounded', className)} />
  )
}

export function SkeletonCard({ className }: SkeletonCardProps) {
  return (
    <div
      className={cn(
        'bg-navy-900 border border-slate-800 rounded-xl overflow-hidden',
        className
      )}
    >
      {/* Screenshot placeholder */}
      <Skeleton className="w-full h-40 rounded-none" />

      <div className="p-5 flex flex-col gap-3">
        {/* Badges row */}
        <div className="flex gap-2">
          <Skeleton className="h-5 w-16 rounded-full" />
          <Skeleton className="h-5 w-20 rounded-full" />
        </div>

        {/* Title */}
        <Skeleton className="h-5 w-3/4" />

        {/* Price */}
        <Skeleton className="h-7 w-1/3" />

        <hr className="border-slate-800" />

        {/* Metrics row */}
        <div className="flex gap-4">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
        </div>

        {/* Tech stack */}
        <div className="flex gap-2">
          <Skeleton className="h-5 w-14 rounded-full" />
          <Skeleton className="h-5 w-16 rounded-full" />
          <Skeleton className="h-5 w-12 rounded-full" />
        </div>

        {/* Buttons */}
        <div className="flex gap-2 pt-1">
          <Skeleton className="h-9 flex-1 rounded-lg" />
          <Skeleton className="h-9 flex-1 rounded-lg" />
        </div>
      </div>
    </div>
  )
}
