'use client'

/**
 * Visor de un deliverable tipo AD_VISUALS.
 * Muestra un grid de piezas generadas con metadata (formato, ángulo, score).
 * Mantiene un toggle "Ver JSON" para debugging.
 *
 * Patrón: igual a AdCreativesViewer — recibe data: unknown, parsea defensivamente.
 */

import { useState } from 'react'

// ── Tipos locales ──────────────────────────────────────────────────────────────

type AdVisual = {
  format?: string
  aspectRatio?: string
  resolution?: string
  imageUrl?: string
  angle?: string
  generatedAt?: string
  attempt?: number
  validationScore?: number
}

type AdVisualBrandContext = {
  dominantColors?: string[]
  style?: string
  logoUsed?: boolean
}

type AdVisuals = {
  visuals?: AdVisual[]
  brandContext?: AdVisualBrandContext
  disclaimer?: string
}

// ── Helpers ────────────────────────────────────────────────────────────────────

const FORMAT_LABELS: Record<string, string> = {
  feed_square: 'Feed 1:1',
  feed_portrait: 'Feed 4:5',
  story: 'Story 9:16',
}

function ScoreBadge({ score }: { score?: number }) {
  if (score === undefined) return null
  const color = score >= 70 ? '#10B981' : score >= 40 ? '#F59E0B' : '#EF4444'
  return (
    <span
      style={{ color, borderColor: `${color}33`, backgroundColor: `${color}15` }}
      className="text-[10px] font-medium px-1.5 py-0.5 rounded-full border"
    >
      {score}/100
    </span>
  )
}

function VisualCard({ visual }: { visual: AdVisual }) {
  const [imgError, setImgError] = useState(false)
  const formatLabel = FORMAT_LABELS[visual.format ?? ''] ?? (visual.format ?? '—')
  const angleLabel = visual.angle ?? '—'

  return (
    <div className="rounded-lg bg-[#0B0F1A] border border-[#1E293B] overflow-hidden">
      {/* Imagen */}
      <div className="relative bg-[#0B0F1A]" style={{ paddingBottom: visual.aspectRatio === '9:16' ? '177.78%' : visual.aspectRatio === '4:5' ? '125%' : '100%' }}>
        {!imgError && visual.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={visual.imageUrl}
            alt={`${formatLabel} — ${angleLabel}`}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-[#475569]">
            <span className="text-xs">Sin imagen</span>
          </div>
        )}
      </div>

      {/* Metadata */}
      <div className="p-2.5 space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] text-[#64748B] font-medium">{formatLabel}</span>
          <ScoreBadge score={visual.validationScore} />
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] text-[#475569] italic">{angleLabel}</span>
          {visual.attempt && visual.attempt > 1 && (
            <span className="text-[10px] text-[#F59E0B]">Regenerada</span>
          )}
        </div>
        {visual.resolution && (
          <span className="text-[10px] text-[#334155]">{visual.resolution}</span>
        )}
        {visual.imageUrl && (
          <a
            href={visual.imageUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="block text-[10px] text-[#475569] hover:text-[#8B5CF6] transition-colors truncate"
          >
            Ver imagen ↗
          </a>
        )}
      </div>
    </div>
  )
}

// ── Componente principal ──────────────────────────────────────────────────────

type Props = { data: unknown }

export function AdVisualsViewer({ data }: Props) {
  const [showJson, setShowJson] = useState(false)

  let visuals: AdVisuals
  try {
    visuals = (typeof data === 'string' ? JSON.parse(data) : data) as AdVisuals
  } catch {
    return <pre className="text-xs text-[#94A3B8] whitespace-pre-wrap">{String(data)}</pre>
  }

  if (!visuals || typeof visuals !== 'object') {
    return <pre className="text-xs text-[#94A3B8] whitespace-pre-wrap">{JSON.stringify(data, null, 2)}</pre>
  }

  const items = visuals.visuals ?? []
  const ctx = visuals.brandContext

  return (
    <div className="space-y-4 mt-2">
      {visuals.disclaimer && (
        <p className="text-[10px] text-[#475569] italic">{visuals.disclaimer}</p>
      )}

      {/* Contexto de marca */}
      {ctx && (
        <div className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] space-y-1.5">
          <p className="text-[10px] text-[#64748B] uppercase tracking-wider">Contexto de marca</p>
          {ctx.dominantColors && ctx.dominantColors.length > 0 && (
            <div className="flex items-center gap-1.5">
              {ctx.dominantColors.map((c) => (
                <span
                  key={c}
                  title={c}
                  className="w-3 h-3 rounded-full border border-white/10"
                  style={{ backgroundColor: c }}
                />
              ))}
              <span className="text-[10px] text-[#475569]">{ctx.dominantColors.join(', ')}</span>
            </div>
          )}
          {ctx.style && (
            <p className="text-xs text-[#94A3B8]">{ctx.style}</p>
          )}
          {ctx.logoUsed !== undefined && (
            <p className="text-[10px] text-[#475569]">Logo: {ctx.logoUsed ? 'incluido' : 'no disponible'}</p>
          )}
        </div>
      )}

      {/* Contador */}
      <div className="flex items-center justify-between">
        <p className="text-[10px] text-[#64748B] uppercase tracking-wider">
          Piezas generadas: {items.length}
        </p>
        {items.length < 6 && items.length > 0 && (
          <span className="text-[10px] text-[#F59E0B]">{items.length} de 6 piezas</span>
        )}
      </div>

      {/* Grid de imágenes */}
      {items.length > 0 ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {items.map((visual, i) => (
            <VisualCard key={`${visual.format}-${visual.angle}-${i}`} visual={visual} />
          ))}
        </div>
      ) : (
        <p className="text-xs text-[#64748B]">No hay piezas visuales en este deliverable.</p>
      )}

      {/* Toggle JSON */}
      <button
        type="button"
        onClick={() => setShowJson((v) => !v)}
        className="flex items-center gap-1.5 text-[10px] text-[#475569] hover:text-[#64748B] transition-colors mt-1"
      >
        <span className="font-mono">{showJson ? '▾' : '▸'}</span>
        Ver JSON crudo
      </button>
      {showJson && (
        <pre className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-xs font-mono overflow-x-auto max-h-64 overflow-y-auto whitespace-pre-wrap break-words">
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  )
}
