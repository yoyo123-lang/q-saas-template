# Playbook E2E — Patrones Generativos

> Cómo generar tests E2E para entidades y flujos nuevos.
> Usar junto con el comando `/project:e2e`.

---

## Estructura de tests en este proyecto

```
e2e/
├── 00-smoke.spec.ts        ← Nivel 0: health, landing, login, redirects (sin auth)
├── 01-registro-y-login.spec.ts
├── 02-catalogo.spec.ts
├── 03-crear-listado.spec.ts
├── 04-flujo-consulta.spec.ts
├── 05-admin-moderacion.spec.ts
└── fixtures/
    └── auth.ts             ← Fixture de auth Supabase (usuario sintético)
```

**Convención de naming:**
- `NN-nombre-del-flujo.spec.ts` donde `NN` es el número de orden
- Smoke tests siempre en `00-smoke.spec.ts` (se corren solos en CI básico)
- Tests que requieren auth: importar `{ test, expect }` desde `./fixtures/auth`
- Tests sin auth: importar directo de `@playwright/test`

---

## Niveles de test

| Nivel | Qué testea | Auth requerida | Corre en CI básico |
|---|---|---|---|
| 0 | Smoke: la app arranca, rutas básicas cargan | No | Sí |
| 1 | Flujos de UI sin auth (landing, catálogo, páginas públicas) | No | Sí |
| 2 | Flujos autenticados (dashboard, crear entidad, ver listado) | Sí | Solo con Supabase secrets |
| 3 | Flujos de negocio completos (compra, consulta, moderación) | Sí (roles múltiples) | Solo con Supabase secrets |

---

## Patrones generativos

### Patrón 1: Ruta pública sin auth

Para cualquier página pública nueva (ej: `/como-funciona`, `/faq`):

```typescript
import { test, expect } from '@playwright/test'

test.describe('[nombre de la página]', () => {
  test('carga sin errores', async ({ page }) => {
    await page.goto('/ruta-de-la-pagina')
    await expect(page).not.toHaveTitle(/error/i)
    await expect(page.locator('body')).not.toContainText('Internal Server Error')
  })

  test('contiene elemento clave', async ({ page }) => {
    await page.goto('/ruta-de-la-pagina')
    await expect(page.getByRole('heading', { name: /título esperado/i })).toBeVisible()
  })
})
```

### Patrón 2: Ruta protegida (redirect a login sin sesión)

```typescript
import { test, expect } from '@playwright/test'

test('[nombre-ruta] redirige a login sin sesión', async ({ page }) => {
  await page.goto('/ruta-protegida')
  await expect(page).toHaveURL(/\/login/)
})
```

### Patrón 3: CRUD de entidad (con auth fixture)

Para una entidad nueva (ej: `Propuesta`, `Oferta`):

```typescript
import { test, expect } from './fixtures/auth'

test.describe('[Entidad]: CRUD', () => {
  // Listar — empty state o tabla
  test('lista muestra empty state o registros', async ({ authedPage }) => {
    await authedPage.goto('/ruta-de-lista')
    const hasContent =
      (await authedPage.locator('table').count()) > 0 ||
      (await authedPage.getByText(/no tenés|todavía no|sin \w+/i).count()) > 0
    expect(hasContent).toBe(true)
  })

  // Crear — formulario básico
  test('formulario de creación carga', async ({ authedPage }) => {
    await authedPage.goto('/ruta-de-lista/nuevo')
    await expect(authedPage.locator('form')).toBeVisible()
  })

  test('validación muestra errores con datos vacíos', async ({ authedPage }) => {
    await authedPage.goto('/ruta-de-lista/nuevo')
    await authedPage.click('button[type="submit"]')
    // Esperar algún mensaje de error de validación
    await expect(authedPage.locator('[role="alert"], .error, [data-error]').first()).toBeVisible({ timeout: 3000 })
  })

  test('creación exitosa con datos válidos', async ({ authedPage }) => {
    await authedPage.goto('/ruta-de-lista/nuevo')

    // Completar el formulario con datos mínimos válidos
    await authedPage.fill('input[name="campo"]', 'Valor de prueba E2E')
    await authedPage.click('button[type="submit"]')

    // Verificar redirect o mensaje de éxito
    await expect(authedPage).toHaveURL(/\/ruta-de-lista|\/confirmacion/, { timeout: 8000 })
  })
})
```

### Patrón 4: Flujo de negocio multi-paso (wizard)

```typescript
import { test, expect } from './fixtures/auth'

test.describe('[Flujo]: wizard multi-paso', () => {
  test('paso 1 carga y avanza', async ({ authedPage }) => {
    await authedPage.goto('/ruta-del-wizard')
    await expect(authedPage.getByText(/paso 1|información básica/i)).toBeVisible()

    // Completar paso 1
    await authedPage.fill('input[name="campo-requerido"]', 'valor')
    await authedPage.click('button:has-text("Continuar")')

    // Verificar llegada al paso 2
    await expect(authedPage.getByText(/paso 2/i)).toBeVisible({ timeout: 5000 })
  })

  test('paso anterior funciona (navegación back)', async ({ authedPage }) => {
    await authedPage.goto('/ruta-del-wizard')
    // completar paso 1...
    await authedPage.click('button:has-text("Continuar")')
    await authedPage.click('button:has-text("Anterior")')
    await expect(authedPage.getByText(/paso 1|información básica/i)).toBeVisible()
  })
})
```

### Patrón 5: Flujo de rol múltiple (vendedor + comprador + admin)

Cuando el flujo requiere acciones de distintos roles, usar múltiples fixtures:

```typescript
import { test, expect } from '@playwright/test'
import { createTestUser } from './fixtures/auth'

// Este patrón requiere múltiples contextos de browser.
// Usar test.step para claridad.
test('flujo completo: vendedor publica, comprador consulta', async ({ browser }) => {
  const sellerContext = await browser.newContext()
  const buyerContext = await browser.newContext()

  // ... inyectar sesiones de cada rol
  // ... realizar acciones de cada actor
  // ... verificar estado final

  await sellerContext.close()
  await buyerContext.close()
})
```

---

## Selectores preferidos (por orden de prioridad)

1. **Por rol semántico**: `getByRole('button', { name: /texto/i })` — más robusto
2. **Por label**: `getByLabel('Email')` — bueno para inputs de formulario
3. **Por texto**: `getByText(/texto/i)` — para verificar contenido
4. **Por placeholder**: `getByPlaceholder('...')` — alternativa para inputs
5. **Por atributo data-testid**: `locator('[data-testid="mi-elemento"]')` — para elementos difíciles de seleccionar semánticamente
6. **CSS selector**: `locator('input[name="campo"]')` — último recurso

> Agregar `data-testid` a elementos clave en el código si los selectores semánticos son frágiles.

---

## Timeouts y retries

```typescript
// Default de este proyecto (ver playwright.config.ts):
// - retries: 2 en CI, 0 local
// - workers: 1 (tests secuenciales, evita race conditions)

// Para esperas explícitas, preferir:
await expect(elemento).toBeVisible({ timeout: 8000 })  // por default usa actionTimeout

// Evitar:
await page.waitForTimeout(2000)  // nunca usar sleep fijo
```

---

## Variables de entorno para E2E

| Variable | Uso | Requerida para |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | URL del proyecto Supabase | Todos los tests |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Clave pública de Supabase | Todos los tests |
| `SUPABASE_SERVICE_ROLE_KEY` | Crear/borrar usuarios de test | Fixture de auth (nivel 2+) |
| `DATABASE_URL` | Prisma (health check) | Smoke tests con DB |
| `E2E_TEST_PASSWORD` | Password del usuario de test | Fixture de auth (default: E2eTestPass123!) |
| `BASE_URL` | URL base del app | Override para correr contra Vercel preview |

Para correr E2E contra una Vercel preview URL:
```bash
BASE_URL=https://mi-preview.vercel.app npm run test:e2e e2e/00-smoke.spec.ts
```

---

## Checklist antes de commitear un test nuevo

- [ ] El test no tiene `await page.waitForTimeout(N)` — usar esperas por elemento
- [ ] El test limpia su estado (la fixture de auth hace cleanup automático)
- [ ] Si el test crea datos en DB, los borra al terminar
- [ ] El test tiene un nombre descriptivo en español (es el idioma del proyecto)
- [ ] Si requiere auth, importa desde `./fixtures/auth`, no de `@playwright/test`
- [ ] El test fue corrido localmente y pasa

---

*Última actualización: 2026-03-24*
