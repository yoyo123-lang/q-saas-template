import type { Metadata } from 'next'
import { DomainSearch } from './DomainSearch'

export const metadata: Metadata = { title: 'Buscar dominio — Qautiva' }

export default function BuscarDominioPage() {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-[#F8FAFC] mb-2">Buscá tu dominio</h1>
      <p className="text-[#94A3B8] mb-8">
        Ingresá el nombre que querés registrar y te mostramos las opciones disponibles.
      </p>
      <DomainSearch />
    </div>
  )
}
