import Link from 'next/link'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { unstable_cache } from 'next/cache'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { TopBar } from '@/components/TopBar'
import { DeleteProjectButton } from './_components/DeleteProjectButton'

const PAGE_SIZE = 20

const getUserHasMedios = unstable_cache(
  async (authUserId: string) => {
    const profile = await prisma.userProfile.findUnique({
      where: { authUserId },
      select: { _count: { select: { media: { where: { deletedAt: null } } } } },
    })
    return (profile?._count.media ?? 0) > 0
  },
  ['user-has-medios'],
  { revalidate: 60, tags: ['user-has-medios'] },
)

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  SETUP: 'Configurando',
  GENERATING: 'Generando',
  IN_PROGRESS: 'En proceso',
  COMPLETED: 'Completado',
  PAUSED: 'Pausado',
  ERROR: 'Error',
}

const STATUS_COLORS: Record<string, string> = {
  SETUP: 'text-[#94A3B8] bg-[#1E293B]',
  GENERATING: 'text-[#A78BFA] bg-[#8B5CF6]/10',
  IN_PROGRESS: 'text-[#34D399] bg-[#059669]/10',
  COMPLETED: 'text-[#60A5FA] bg-[#2563EB]/10',
  PAUSED: 'text-[#F59E0B] bg-[#D97706]/10',
  ERROR: 'text-[#EF4444] bg-[#EF4444]/10',
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('')
}

interface ProyectosPageProps {
  searchParams: { page?: string }
}

export default async function ProyectosPage({ searchParams }: ProyectosPageProps) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const rawPage = parseInt(searchParams.page ?? '1', 10)
  if (isNaN(rawPage) || rawPage < 1) redirect('/proyectos?page=1')
  const page = isNaN(rawPage) || rawPage < 1 ? 1 : rawPage

  const hasMedios = await getUserHasMedios(user.id)

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    include: {
      teamMemberships: { select: { teamId: true } },
    },
  })

  if (!profile) redirect('/onboarding')

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const whereClause = { teamId: { in: teamIds }, deletedAt: null }

  const [projects, totalCount, billing] = await Promise.all([
    prisma.project.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      select: {
        id: true,
        name: true,
        industry: true,
        city: true,
        status: true,
        _count: {
          select: {
            stages: true,
            deliverables: { where: { status: 'CLIENT_APPROVED' } },
          },
        },
      },
    }),
    prisma.project.count({ where: whereClause }),
    teamIds.length > 0
      ? prisma.billingAccount.findFirst({
          where: { teamId: { in: teamIds } },
          select: { preferredKeySource: true, plan: true, balanceUsd: true },
        })
      : Promise.resolve(null),
  ])

  const hasMore = page * PAGE_SIZE < totalCount
  const hasPrev = page > 1

  const showBalanceBanner =
    billing?.preferredKeySource === 'QAUTIVA_HOSTED' &&
    billing?.plan === 'PREPAID' &&
    Number(billing?.balanceUsd ?? 0) === 0

  return (
    <div className="min-h-screen bg-[#0B0F1A] flex flex-col">
      <TopBar hasMedios={hasMedios} />
      <main className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
      {showBalanceBanner && (
        <div className="mb-6 flex items-center justify-between p-4 rounded-lg bg-[#F59E0B]/10 border border-[#F59E0B]/30">
          <p className="text-[#F59E0B] text-sm">
            Cargá saldo para activar la generación IA en tus proyectos.
          </p>
          <a
            href="/configuracion"
            className="ml-4 flex-shrink-0 px-3 py-1.5 rounded-lg bg-[#F59E0B] text-black text-xs font-medium hover:bg-[#FCD34D] transition-colors"
          >
            Cargar saldo
          </a>
        </div>
      )}

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Mis proyectos</h1>
        <p className="text-[#64748B] text-sm mt-1">
          {totalCount === 0
            ? 'Todavía no tenés proyectos.'
            : `${totalCount} proyecto${totalCount !== 1 ? 's' : ''}`}
        </p>
      </div>

      {totalCount === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="text-6xl mb-6">🚀</div>
          <h2 className="text-xl font-bold text-white mb-3">Todavía no tenés proyectos</h2>
          <p className="text-[#64748B] text-sm mb-8 max-w-sm">
            Creá tu primer proyecto y la IA va a generar tu marca, sitio web, campañas y más.
          </p>
          <Link
            href="/proyectos/nuevo"
            className="px-6 py-3 rounded-lg bg-[#8B5CF6] text-white font-medium hover:bg-[#A78BFA] transition-colors duration-200"
          >
            Lanzá tu primer negocio
          </Link>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.map((project) => {
              const statusLabel = STATUS_LABELS[project.status] ?? project.status
              const statusColor = STATUS_COLORS[project.status] ?? STATUS_COLORS.SETUP
              const initials = getInitials(project.name)
              const approvedCount = project._count.deliverables
              const totalStages = project._count.stages

              return (
                <div
                  key={project.id}
                  className="group relative rounded-xl bg-[#0F172A] border border-[#1E293B] hover:border-[#8B5CF6]/50 transition-all duration-200"
                >
                  <Link
                    href={`/proyectos/${project.id}/progreso`}
                    className="block p-5"
                  >
                    <div className="flex items-start gap-3 mb-4">
                      <div className="w-10 h-10 rounded-lg bg-[#8B5CF6]/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-[#A78BFA] text-sm font-bold">{initials}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-white text-sm font-medium truncate group-hover:text-[#A78BFA] transition-colors">
                          {project.name}
                        </h3>
                        <p className="text-[#64748B] text-xs truncate">
                          {project.industry}{project.city ? ` · ${project.city}` : ''}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColor}`}>
                        {statusLabel}
                      </span>
                      {totalStages > 0 && (
                        <span className="text-[#64748B] text-xs">
                          {approvedCount}/{totalStages} etapas
                        </span>
                      )}
                    </div>
                  </Link>

                  {/* Botón eliminar — esquina superior derecha, visible al hover */}
                  <div className="absolute top-3 right-3">
                    <DeleteProjectButton projectId={project.id} projectName={project.name} />
                  </div>
                </div>
              )
            })}
          </div>

          {(hasPrev || hasMore) && (
            <div className="mt-8 flex items-center justify-center gap-4">
              {hasPrev ? (
                <Link
                  href={`/proyectos?page=${page - 1}`}
                  className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm font-medium hover:bg-[#334155] hover:text-white transition-colors"
                >
                  Anterior
                </Link>
              ) : (
                <span className="px-4 py-2 rounded-lg bg-[#0F172A] text-[#475569] text-sm font-medium cursor-not-allowed">
                  Anterior
                </span>
              )}

              <span className="text-[#64748B] text-sm">
                Página {page}
              </span>

              {hasMore ? (
                <Link
                  href={`/proyectos?page=${page + 1}`}
                  className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm font-medium hover:bg-[#334155] hover:text-white transition-colors"
                >
                  Siguiente
                </Link>
              ) : (
                <span className="px-4 py-2 rounded-lg bg-[#0F172A] text-[#475569] text-sm font-medium cursor-not-allowed">
                  Siguiente
                </span>
              )}
            </div>
          )}
        </>
      )}
        </div>
      </main>
    </div>
  )
}
