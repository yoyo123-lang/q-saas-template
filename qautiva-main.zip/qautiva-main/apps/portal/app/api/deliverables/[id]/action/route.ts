import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { revalidatePath } from 'next/cache'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

type ActionBody = {
  action: 'approve' | 'reject'
  feedback?: string
  selectedOptionId?: string
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: ActionBody
  try {
    body = await request.json() as ActionBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { action, feedback, selectedOptionId } = body

  if (action !== 'approve' && action !== 'reject') {
    return NextResponse.json({ error: 'Acción inválida. Debe ser "approve" o "reject"' }, { status: 400 })
  }

  if (action === 'reject' && (!feedback || feedback.trim().length === 0)) {
    return NextResponse.json({ error: 'El feedback es obligatorio al rechazar un entregable' }, { status: 400 })
  }

  if (feedback && feedback.trim().length > 2000) {
    return NextResponse.json({ error: 'El feedback es demasiado largo (máx 2000 caracteres)' }, { status: 400 })
  }

  const orgId = user.app_metadata?.org_id as string | undefined

  type DeliverableRow = {
    id: string
    teamId: string | null
    status: string
    type: string
    content: unknown
    stageId: string | null
    projectId: string | null
    project: { name: string } | null
  }
  let deliverable: DeliverableRow | null = null

  const deliverableSelect = {
    id: true,
    teamId: true,
    status: true,
    type: true,
    content: true,
    stageId: true,
    projectId: true,
    project: { select: { name: true } },
  } as const

  if (orgId) {
    // Usuarios legados: verificar por organizationId
    deliverable = await prisma.deliverable.findFirst({
      where: { id: params.id, organizationId: orgId },
      select: deliverableSelect,
    })
  } else {
    // Self-service: verificar por team membership del usuario
    const profile = await prisma.userProfile.findUnique({
      where: { authUserId: user.id },
      select: { teamMemberships: { select: { teamId: true } } },
    })

    if (!profile || profile.teamMemberships.length === 0) {
      return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
    }

    const teamIds = profile.teamMemberships.map((m) => m.teamId)
    deliverable = await prisma.deliverable.findFirst({
      where: { id: params.id, teamId: { in: teamIds }, project: { deletedAt: null } },
      select: deliverableSelect,
    })

    // Guard de permisos: MEMBER solo tiene lectura — approve/reject son decisiones de ADMIN/OWNER
    if (deliverable?.teamId) {
      const perm = await checkTeamPermission(user.id, deliverable.teamId, ['ADMIN', 'OWNER'])
      if (!perm.authorized) {
        return NextResponse.json(
          { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden aprobar o rechazar entregables.' },
          { status: 403 },
        )
      }
    }
  }

  if (!deliverable) {
    return NextResponse.json({ error: 'Entregable no encontrado' }, { status: 404 })
  }

  if (deliverable.status !== 'SENT_TO_CLIENT') {
    return NextResponse.json(
      { error: 'Este entregable no está disponible para aprobación' },
      { status: 409 },
    )
  }

  const newStatus = action === 'approve' ? 'CLIENT_APPROVED' : 'REVISION_REQUESTED'

  // Para approve con selección de opción, registrar la opción elegida en el feedback
  const feedbackValue =
    action === 'reject'
      ? feedback?.trim()
      : selectedOptionId
        ? `selected:${selectedOptionId}`
        : null

  try {
    await prisma.$transaction(async (tx) => {
      await tx.deliverable.update({
        where: { id: params.id },
        data: { status: newStatus, feedback: feedbackValue },
      })

      // Al aprobar: marcar la etapa como COMPLETED para desbloquear la siguiente
      if (action === 'approve' && deliverable.stageId) {
        await tx.stage.update({
          where: { id: deliverable.stageId },
          data: { status: 'COMPLETED' },
        })
      }

      // Al aprobar BRAND_OPTIONS: persistir la opción elegida como brandKit del proyecto
      if (
        action === 'approve' &&
        deliverable.type === 'BRAND_OPTIONS' &&
        selectedOptionId &&
        deliverable.projectId
      ) {
        const content = deliverable.content as { options?: Array<Record<string, unknown>> } | null
        const chosenOption = content?.options?.find((o) => o['id'] === selectedOptionId)
        if (chosenOption) {
          const businessName = deliverable.project?.name ?? undefined
          await tx.project.update({
            where: { id: deliverable.projectId },
            data: {
              brandKit: {
                ...chosenOption,
                ...(businessName ? { businessName } : {}),
              },
            },
          })
        }
      }
    })
  } catch (err) {
    console.error('[deliverable-action] Prisma update failed', {
      deliverableId: params.id,
      action,
      newStatus,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error interno al procesar la acción' }, { status: 500 })
  }

  if (deliverable.projectId) {
    revalidatePath(`/proyectos/${deliverable.projectId}/entregables`)
    revalidatePath(`/proyectos/${deliverable.projectId}/progreso`)
  }

  console.info('[deliverable-action]', { deliverableId: params.id, action, userId: user.id, newStatus })
  return NextResponse.json({ ok: true, status: newStatus })
}
