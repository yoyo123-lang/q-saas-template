import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { cookies } from 'next/headers'

/**
 * Crea un cliente Supabase para uso en Server Components y Server Actions.
 * Usa las cookies de la request para mantener la sesión.
 */
export async function createSupabaseServerClient() {
  const cookieStore = await cookies()
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet: Array<{ name: string; value: string; options: CookieOptions }>) {
          cookiesToSet.forEach(({ name, value, options }) =>
            cookieStore.set(name, value, options),
          )
        },
      },
    },
  )
}

/**
 * Verifica que hay una sesión activa con rol ADMIN.
 * Lanza error si no hay sesión o el rol no es ADMIN.
 */
export async function requireAdminSession(): Promise<{ userId: string }> {
  const supabase = await createSupabaseServerClient()
  const { data: { user }, error } = await supabase.auth.getUser()

  if (error || !user) {
    throw new Error('No autorizado: sesión requerida')
  }

  const role = user.app_metadata?.['role'] as string | undefined
  if (role !== 'ADMIN') {
    throw new Error('No autorizado: se requiere rol ADMIN')
  }

  return { userId: user.id }
}
