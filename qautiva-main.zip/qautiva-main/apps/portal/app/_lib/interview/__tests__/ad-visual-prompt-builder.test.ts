/**
 * Tests de ad-visual-prompt-builder.ts
 *
 * Cubre: generación de 6 specs, fallback de defaults, sanitización anti-injection,
 * uso de copy del AdCreatives, fallback a CampaignPlan.
 */

import { describe, it, expect } from 'vitest'
import { buildAdVisualPrompts, AD_VISUAL_FORMATS, AD_VISUAL_ANGLES } from '../ad-visual-prompt-builder'
import type { BuildPromptsInput } from '../ad-visual-prompt-builder'

// ── Fixtures ──────────────────────────────────────────────────────────────────

const BASE_PROJECT = { name: 'Qautiva', industry: 'SaaS', country: 'AR' }

const BRAND_OPTIONS_DELIVERABLE = {
  type: 'BRAND_OPTIONS',
  content: {
    options: [
      {
        id: 'option-a',
        label: 'Profesional',
        colors: [
          { hex: '#1a1a2e', name: 'Marino' },
          { hex: '#16213e', name: 'Azul oscuro' },
          { hex: '#0f3460', name: 'Azul medio' },
        ],
        brandPersonality: ['profesional', 'confiable', 'moderno'],
        logoUrl: 'https://example.com/logo.png',
      },
    ],
  },
}

const AD_CREATIVES_DELIVERABLE = {
  type: 'AD_CREATIVES',
  content: {
    metaAds: {
      feed: [
        {
          headline: 'Tu negocio al siguiente nivel',
          callToAction: 'Probá gratis',
          description: 'Plataforma de marketing impulsada por IA',
        },
      ],
    },
  },
}

const CAMPAIGN_PLAN_DELIVERABLE = {
  type: 'CAMPAIGN_PLAN',
  content: {
    oferta: {
      mensajePrincipal: 'Aumentá tus ventas con IA',
      callToAction: 'Comenzá ahora',
    },
  },
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('buildAdVisualPrompts', () => {
  it('genera exactamente 6 specs (2 ángulos × 3 formatos)', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    expect(specs).toHaveLength(Object.keys(AD_VISUAL_FORMATS).length * AD_VISUAL_ANGLES.length)
  })

  it('cada spec tiene los campos requeridos', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [BRAND_OPTIONS_DELIVERABLE, AD_CREATIVES_DELIVERABLE],
      logoAvailable: true,
    }
    const { specs } = buildAdVisualPrompts(input)
    for (const spec of specs) {
      expect(spec.format).toBeDefined()
      expect(spec.aspectRatio).toBeDefined()
      expect(spec.resolution).toBeDefined()
      expect(spec.angle).toMatch(/hero shot|lifestyle/)
      expect(spec.prompt.length).toBeGreaterThan(50)
    }
  })

  it('incluye headline del AdCreatives en el prompt', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [AD_CREATIVES_DELIVERABLE],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    const somePrompt = specs[0]?.prompt ?? ''
    expect(somePrompt).toContain('Tu negocio al siguiente nivel')
  })

  it('fallback a CampaignPlan si no hay AdCreatives', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [CAMPAIGN_PLAN_DELIVERABLE],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    const somePrompt = specs[0]?.prompt ?? ''
    expect(somePrompt).toContain('Aumentá tus ventas con IA')
  })

  it('usa colores del BRAND_OPTIONS en el prompt y en brandContext', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [BRAND_OPTIONS_DELIVERABLE],
      logoAvailable: false,
    }
    const { specs, brandContext } = buildAdVisualPrompts(input)
    expect(brandContext.dominantColors).toContain('#1a1a2e')
    expect(specs[0]?.prompt).toContain('#1a1a2e')
  })

  it('usa defaults de marca cuando no hay BRAND_OPTIONS', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [],
      logoAvailable: false,
    }
    const { brandContext } = buildAdVisualPrompts(input)
    // Defaults: #1a1a1a, #ffffff, #e5e5e5
    expect(brandContext.dominantColors).toContain('#1a1a1a')
    expect(brandContext.logoUsed).toBe(false)
  })

  it('incluye instrucción de logo si logoAvailable=true', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [BRAND_OPTIONS_DELIVERABLE],
      logoAvailable: true,
    }
    const { specs, brandContext } = buildAdVisualPrompts(input)
    expect(brandContext.logoUsed).toBe(true)
    expect(specs[0]?.prompt).toContain('logo')
  })

  it('no incluye instrucción de logo si logoAvailable=false', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    expect(specs[0]?.prompt).not.toContain('brand logo is provided as a reference image')
  })

  it('sanitiza texto con caracteres de control del usuario', () => {
    const input: BuildPromptsInput = {
      project: { name: 'Evil\x00Biz\x1fInc', industry: 'Malware\x07', country: 'AR' },
      previousDeliverables: [],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    // Los caracteres de control deben haberse reemplazado por espacio
    expect(specs[0]?.prompt).not.toContain('\x00')
    expect(specs[0]?.prompt).not.toContain('\x1f')
    expect(specs[0]?.prompt).not.toContain('\x07')
  })

  it('delimita datos del cliente con "CLIENT DATA"', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    expect(specs[0]?.prompt).toContain('CLIENT DATA')
  })

  it('incluye instrucción de zona segura para stories', () => {
    const input: BuildPromptsInput = {
      project: BASE_PROJECT,
      previousDeliverables: [],
      logoAvailable: false,
    }
    const { specs } = buildAdVisualPrompts(input)
    const storySpec = specs.find((s) => s.format === 'story')
    expect(storySpec?.prompt).toContain('safe zone')
  })
})
