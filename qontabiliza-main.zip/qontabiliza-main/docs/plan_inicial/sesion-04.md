# Sesión 04: Listas de precios + Clientes y proveedores

## Objetivo
Listas de precios funcionales (crear lista, asignar precios por producto). CRUD completo de clientes y proveedores con datos fiscales argentinos (CUIT, condición IVA, domicilio). Al terminar, el catálogo está completo y los clientes están listos para facturar.

## Pre-requisitos
- Sesión 03 completada (productos y categorías)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/app/api/v1/products/` (patrón API de S03)
3. Leer `src/app/dashboard/products/` (patrón UI de S03)
4. Leer `prisma/schema.prisma` — revisar modelos PriceList, PriceListItem, Contact

---

## Etapa 1: Listas de precios

### Tarea 1.1: Validaciones Zod para PriceList
**Archivo nuevo**: `src/lib/validations/price-list.ts`

Schemas:
- `createPriceListSchema`: name (requerido), description (optional), isDefault (boolean)
- `updatePriceListSchema`: parcial
- `setPriceListItemSchema`: productId (cuid), price (number, min 0)
- `bulkSetPriceListItemsSchema`: array de { productId, price }

### Tarea 1.2: API routes PriceList
**Archivos nuevos**:
- `src/app/api/v1/price-lists/route.ts` — GET (list), POST (crear)
- `src/app/api/v1/price-lists/[id]/route.ts` — GET (con items), PUT, DELETE
- `src/app/api/v1/price-lists/[id]/items/route.ts` — GET (items paginados), PUT (bulk upsert)

Comportamiento:
- Si se marca una lista como default, desmarcar la anterior default
- GET con items: incluir producto name y precio base para comparar
- Bulk upsert: recibe array de { productId, price }, crea o actualiza cada item

### Tarea 1.3: UI de listas de precios
**Archivo nuevo**: `src/app/dashboard/products/price-lists/page.tsx`
**Archivo nuevo**: `src/app/dashboard/products/price-lists/[id]/page.tsx`

Página de listado:
- Tabla con nombre, descripción, cantidad de productos, default badge
- Botón crear nueva lista

Página de detalle/edición de lista:
- Header con nombre y descripción (editables)
- Tabla de productos con 2 columnas de precio: "Precio base" y "Precio en esta lista"
- Input inline para editar precio de cada producto en la lista
- Búsqueda/filtro de productos
- Botón "Guardar cambios" que hace bulk upsert

### Tarea 1.4: Integrar precios en búsqueda de productos
**Archivo a modificar**: `src/app/api/v1/products/route.ts`

Agregar query param `priceListId` al GET de productos. Si se envía, incluir el precio de esa lista en la respuesta (además del precio base). Esto se usa en el POS (sesión 9).

**Commit**: `feat(price-lists): add price list CRUD with bulk price assignment`

---

## Etapa 2: Clientes y proveedores — Backend

### Tarea 2.1: Validaciones Zod para Contact
**Archivo nuevo**: `src/lib/validations/contact.ts`

Schemas:
- `createContactSchema`:
  - type: enum CUSTOMER | SUPPLIER | BOTH (default CUSTOMER)
  - name (requerido, min 1, max 200)
  - tradeName (optional)
  - email (optional, formato email)
  - phone (optional)
  - address, city, province, zipCode (optional strings)
  - cuit (optional, validar formato: XX-XXXXXXXX-X, validar dígito verificador)
  - ivaCondition: enum del schema Prisma (default CONSUMIDOR_FINAL)
  - notes (optional)
- `updateContactSchema`: parcial de create
- `contactFilterSchema`: search, type, ivaCondition, page, perPage

Validación de CUIT:
```typescript
// Algoritmo de dígito verificador CUIT:
// 1. Multiplicar cada dígito por [5,4,3,2,7,6,5,4,3,2]
// 2. Sumar los productos
// 3. Calcular 11 - (suma % 11)
// 4. Si es 11 → 0, si es 10 → 9 (o inválido según el tipo)
// 5. El resultado debe ser igual al último dígito
```

### Tarea 2.2: API routes Contact
**Archivos nuevos**:
- `src/app/api/v1/contacts/route.ts` — GET (list paginado), POST (crear)
- `src/app/api/v1/contacts/[id]/route.ts` — GET (con resumen), PUT, DELETE

Comportamiento:
- GET list: paginado, filtros por type, ivaCondition, búsqueda (name, tradeName, cuit)
- GET detail: incluir resumen de últimas facturas y saldo pendiente (para cuando existan)
- Soft delete
- Tenant-scoped

### Tarea 2.3: Tests de integración
**Archivo nuevo**: `src/app/api/v1/contacts/__tests__/contacts.test.ts`

Tests:
- CRUD completo
- Validación de CUIT (formato y dígito verificador)
- Filtros por tipo y condición IVA
- Búsqueda por nombre y CUIT
- Tenant isolation

**Commit**: `feat(contacts): add Contact CRUD endpoints with CUIT validation`

---

## Etapa 3: Clientes y proveedores — Frontend

### Tarea 3.1: Hook useContacts
**Archivo nuevo**: `src/hooks/use-contacts.ts`

Similar a useProducts. Expone:
- `contacts`, `pagination`, `filters`
- CRUD methods
- `setFilters`, `setPage`

### Tarea 3.2: Listado de clientes
**Archivo nuevo**: `src/app/dashboard/contacts/page.tsx`

Layout:
- Tabs: "Clientes" / "Proveedores" / "Todos" (filtra por type)
- Botón "Nuevo cliente" / "Nuevo proveedor"
- DataTable con columnas: Nombre, CUIT, Condición IVA, Teléfono, Email, Acciones
- Filtros: búsqueda, condición IVA
- Empty state diferenciado para clientes y proveedores

### Tarea 3.3: Formulario de crear/editar contacto
**Archivo nuevo**: `src/app/dashboard/contacts/new/page.tsx`
**Archivo nuevo**: `src/app/dashboard/contacts/[id]/edit/page.tsx`

Formulario con secciones:
1. **Tipo**: Radio/toggle — Cliente, Proveedor, Ambos
2. **Datos básicos**: nombre (razón social), nombre de fantasía, email, teléfono
3. **Datos fiscales**: CUIT (con máscara XX-XXXXXXXX-X), condición IVA (dropdown)
4. **Domicilio**: dirección, ciudad, provincia (dropdown con las 24 provincias argentinas), código postal
5. **Notas**: textarea opcional

Validación client-side con react-hook-form + zod.
Input de CUIT con máscara automática y validación de dígito verificador en tiempo real.

### Tarea 3.4: Página de detalle de contacto
**Archivo nuevo**: `src/app/dashboard/contacts/[id]/page.tsx`

Vista con:
- Datos del contacto
- Badge de tipo (Cliente / Proveedor / Ambos)
- Badge de condición IVA
- Sección "Últimas facturas" (vacía por ahora, se llena en S06)
- Sección "Cuenta corriente" (vacía por ahora)
- Botón "Editar"

**Commit**: `feat(ui): add contacts pages (list, create, edit, detail) with fiscal data`

---

## Etapa 4: Códigos de barras y búsqueda rápida

### Tarea 4.1: Búsqueda por código de barras
**Archivo nuevo**: `src/app/api/v1/products/search/route.ts`

Endpoint GET `/api/v1/products/search?q=XXXXX`:
- Busca por barcode exacto (prioridad alta)
- Busca por SKU exacto
- Busca por nombre (contains, case insensitive)
- Retorna máximo 10 resultados
- Incluye precio base y stock actual
- Este endpoint se usa después en el POS para búsqueda rápida

### Tarea 4.2: Componente de búsqueda rápida de producto
**Archivo nuevo**: `src/components/shared/product-search.tsx`

Componente reutilizable (se usa en POS, en facturas, en movimientos de stock):
- Input con debounce (300ms)
- Llama a `/api/v1/products/search`
- Dropdown con resultados mostrando: nombre, SKU, precio, stock
- Al seleccionar un producto, llama callback `onSelect(product)`
- Soporte para input de código de barras (detecta enter rápido = scanner)

### Tarea 4.3: Tests del endpoint de búsqueda
**Archivo nuevo**: `src/app/api/v1/products/search/__tests__/search.test.ts`

Tests:
- Búsqueda por barcode retorna match exacto
- Búsqueda por SKU retorna match exacto
- Búsqueda por nombre retorna resultados parciales
- Límite de 10 resultados
- Tenant isolation

**Commit**: `feat(products): add barcode/SKU quick search endpoint and reusable search component`

---

## Checklist de cierre de sesión

- [ ] Listas de precios: CRUD + bulk assignment + UI
- [ ] Contactos: CRUD con validación de CUIT + UI
- [ ] Formularios con datos fiscales argentinos (condición IVA, provincias)
- [ ] Búsqueda rápida por código de barras/SKU
- [ ] Componente ProductSearch reutilizable
- [ ] Tests de integración para APIs nuevas
- [ ] Formato argentino en todos los precios y fechas
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
