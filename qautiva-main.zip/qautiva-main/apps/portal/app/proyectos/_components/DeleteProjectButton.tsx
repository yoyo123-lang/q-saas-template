'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Trash2, X, AlertTriangle } from 'lucide-react'

interface DeleteProjectButtonProps {
  projectId: string
  projectName: string
}

export function DeleteProjectButton({ projectId, projectName }: DeleteProjectButtonProps) {
  const [showModal, setShowModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  // Cerrar modal con Escape
  useEffect(() => {
    if (!showModal) return
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape' && !loading) {
        setShowModal(false)
        setError(null)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [showModal, loading])

  function handleTrashClick(e: React.MouseEvent) {
    e.preventDefault()
    e.stopPropagation()
    setError(null)
    setShowModal(true)
  }

  function handleCancel(e: React.MouseEvent) {
    e.preventDefault()
    e.stopPropagation()
    setShowModal(false)
    setError(null)
  }

  async function handleConfirm(e: React.MouseEvent) {
    e.preventDefault()
    e.stopPropagation()
    setLoading(true)
    setError(null)

    try {
      const res = await fetch(`/api/projects/${projectId}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json().catch((err: unknown) => { console.error('[DeleteProjectButton] Failed to parse error response', err); return {} })
        setError((data as { error?: string }).error ?? 'Error al eliminar. Intentá de nuevo.')
        setLoading(false)
        return
      }
      setShowModal(false)
      router.refresh()
    } catch {
      setError('Error de red. Intentá de nuevo.')
      setLoading(false)
    }
  }

  return (
    <>
      {/* Botón papelera — siempre visible en mobile, solo en hover en desktop */}
      <button
        onClick={handleTrashClick}
        aria-label="Eliminar proyecto"
        className="opacity-60 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-200 p-1.5 rounded-lg text-[#64748B] hover:text-[#EF4444] hover:bg-[#EF4444]/10"
      >
        <Trash2 size={14} />
      </button>

      {/* Modal de confirmación */}
      {showModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={handleCancel}
        >
          <div
            className="w-full max-w-sm rounded-xl bg-[#0F172A] border border-[#1E293B] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-[#EF4444]/10 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle size={18} className="text-[#EF4444]" />
                </div>
                <h2 className="text-white font-semibold text-sm">Eliminar proyecto</h2>
              </div>
              <button
                onClick={handleCancel}
                className="text-[#64748B] hover:text-white transition-colors p-1"
              >
                <X size={16} />
              </button>
            </div>

            <p className="text-[#94A3B8] text-sm mb-1">
              ¿Estás seguro de que querés eliminar{' '}
              <span className="text-white font-medium break-words">&ldquo;{projectName}&rdquo;</span>?
            </p>
            <p className="text-[#64748B] text-xs mb-5">
              Esta acción no se puede deshacer.
            </p>

            {error && (
              <p className="text-[#EF4444] text-xs mb-4 bg-[#EF4444]/10 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <div className="flex gap-3">
              <button
                onClick={handleCancel}
                disabled={loading}
                className="flex-1 py-2 rounded-lg border border-[#1E293B] text-[#94A3B8] text-sm font-medium hover:text-white hover:border-[#334155] transition-colors disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirm}
                disabled={loading}
                className="flex-1 py-2 rounded-lg bg-[#EF4444] text-white text-sm font-medium hover:bg-[#DC2626] transition-colors disabled:opacity-50"
              >
                {loading ? 'Eliminando…' : 'Eliminar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
