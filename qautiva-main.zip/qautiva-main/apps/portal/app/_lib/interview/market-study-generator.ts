import { searchWeb, searchPlaces } from './serper-client'
import { getOpenAIClient } from './openai-client'
import { executeToolCall, type BillingContext, type ToolDefinition } from './ai-tool-call'
import { registerAiUsage } from '../billing/register-ai-usage'
import { buildInterviewSummary } from './brief-generator'
import type { QuestionBlock, MarketStudy, StrategicBrief } from './types'

// ── Tool definition ───────────────────────────────────────────────────────────

const GENERATE_MARKET_STUDY_TOOL: ToolDefinition = {
  name: 'generate_market_study',
  description:
    'Genera el Estudio de Mercado completo a partir de las respuestas del cliente y los datos de internet.',
  input_schema: {
    type: 'object' as const,
    additionalProperties: false,
    properties: {
      resumenEjecutivo: {
        type: 'object',
        additionalProperties: false,
        properties: {
          panorama: { type: 'string' },
          nivelCompetencia: { type: 'string', enum: ['baja', 'media', 'alta', 'saturada'] },
          oportunidadPrincipal: { type: 'string' },
        },
        required: ['panorama', 'nivelCompetencia', 'oportunidadPrincipal'],
      },
      competidores: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            nombre: { type: 'string' },
            website: { type: ['string', 'null'] },
            googleRating: { type: ['number', 'null'] },
            googleReviews: { type: ['number', 'null'] },
            fortalezasDigitales: { type: 'array', items: { type: 'string' } },
            debilidadesDigitales: { type: 'array', items: { type: 'string' } },
            posicionamiento: { type: 'string' },
          },
          required: [
            'nombre',
            'website',
            'googleRating',
            'googleReviews',
            'fortalezasDigitales',
            'debilidadesDigitales',
            'posicionamiento',
          ],
        },
      },
      presenciaDigital: {
        type: 'object',
        additionalProperties: false,
        properties: {
          resultadosBusqueda: { type: 'string' },
          keywordsCompetidores: { type: 'array', items: { type: 'string' } },
          keywordsOportunidad: { type: 'array', items: { type: 'string' } },
          googleMapsPropio: {
            type: 'object',
            additionalProperties: false,
            properties: {
              encontrado: { type: 'boolean' },
              rating: { type: ['number', 'null'] },
              reviews: { type: ['number', 'null'] },
              sugerenciaMejora: { type: 'string' },
            },
            required: ['encontrado', 'rating', 'reviews', 'sugerenciaMejora'],
          },
        },
        required: ['resultadosBusqueda', 'keywordsCompetidores', 'keywordsOportunidad', 'googleMapsPropio'],
      },
      tendencias: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            tendencia: { type: 'string' },
            impacto: { type: 'string', enum: ['positivo', 'negativo', 'neutro'] },
            accion: { type: 'string' },
          },
          required: ['tendencia', 'impacto', 'accion'],
        },
      },
      oportunidades: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            descripcion: { type: 'string' },
            prioridad: { type: 'string', enum: ['alta', 'media', 'baja'] },
            accionRecomendada: { type: 'string' },
            evidencia: { type: 'string' },
          },
          required: ['descripcion', 'prioridad', 'accionRecomendada', 'evidencia'],
        },
      },
      amenazas: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            descripcion: { type: 'string' },
            severidad: { type: 'string', enum: ['alta', 'media', 'baja'] },
            mitigacion: { type: 'string' },
          },
          required: ['descripcion', 'severidad', 'mitigacion'],
        },
      },
      recomendaciones: {
        type: 'object',
        additionalProperties: false,
        properties: {
          inmediatas: { type: 'array', items: { type: 'string' } },
          medianoPlazo: { type: 'array', items: { type: 'string' } },
          metricasClave: { type: 'array', items: { type: 'string' } },
        },
        required: ['inmediatas', 'medianoPlazo', 'metricasClave'],
      },
    },
    required: [
      'resumenEjecutivo',
      'competidores',
      'presenciaDigital',
      'tendencias',
      'oportunidades',
      'amenazas',
      'recomendaciones',
    ],
  },
}

// ── Prompts ───────────────────────────────────────────────────────────────────

const SYNTHESIS_SYSTEM_PROMPT = `Sos El Investigador de Qautiva. Tu trabajo es generar un Estudio de Mercado completo y accionable para un negocio argentino.

Tenés dos fuentes de información:
1. Las respuestas del cliente en la entrevista de investigación
2. Datos reales de internet (búsquedas de Google y Google Maps), si están disponibles

El estudio debe:
- Usar DATOS REALES de internet cuando estén disponibles — no inventar URLs, ratings ni reseñas
- Si no hay datos de internet, basar el análisis en las respuestas del cliente e indicar "según información del cliente"
- Ser específico para la zona geográfica del negocio
- Incluir URLs reales donde se encontró la información
- Analizar la presencia digital real de los competidores
- Identificar oportunidades concretas basadas en datos

Acción: Llamá a generate_market_study con el estudio completo.`

// ── Búsquedas Serper ───────────────────────────────────────────────────────────

type SerperData = {
  hasData: boolean
  queries: Record<string, unknown>
}

/** Extrae string de answers, sanitiza y trunca para uso seguro en queries de búsqueda */
function safeQuery(value: unknown, maxLength = 100): string {
  if (typeof value !== 'string') return ''
  return value.trim().replace(/\s+/g, ' ').slice(0, maxLength)
}

async function researchWithSerper(
  answers: Record<string, unknown>,
  brief: StrategicBrief | null,
): Promise<SerperData> {
  const zonaGeografica = safeQuery(
    brief?.mercado?.zonaGeografica ?? answers['research_3'] ?? answers['location'],
  )

  const competidores = (brief?.mercado?.competidores ?? []) as Array<{ nombre: string }>
  const competitor1 = safeQuery(competidores[0]?.nombre ?? answers['research_2'])
  const competitor2 = safeQuery(competidores[1]?.nombre)

  const rubro = safeQuery(brief?.negocio?.descripcion ?? answers['research_1'])
  const keywords = safeQuery(answers['research_4'] ?? answers['research_1'] ?? rubro)
  const nombreNegocio = safeQuery(answers['business_name'] ?? answers['research_1'])

  const queries: Array<{ key: string; fn: () => Promise<unknown> }> = []

  if (competitor1) {
    queries.push({
      key: 'competidor1',
      fn: () => searchWeb(`${competitor1} ${zonaGeografica}`.trim()),
    })
  }
  if (competitor2) {
    queries.push({
      key: 'competidor2',
      fn: () => searchWeb(`${competitor2} ${zonaGeografica}`.trim()),
    })
  }
  if (rubro && zonaGeografica) {
    queries.push({
      key: 'competidoresMaps',
      fn: () => searchPlaces(`${rubro} en ${zonaGeografica}`, { location: zonaGeografica }),
    })
  }
  if (keywords) {
    queries.push({
      key: 'keywords',
      fn: () => searchWeb(String(keywords)),
    })
  }
  const industria = rubro.split(' ').slice(0, 3).join(' ')
  if (industria) {
    queries.push({
      key: 'tendencias',
      fn: () => searchWeb(`tendencias ${industria} Argentina 2026`),
    })
  }
  if (nombreNegocio && zonaGeografica) {
    queries.push({
      key: 'negocioPropio',
      fn: () => searchPlaces(`${nombreNegocio} ${zonaGeografica}`.trim()),
    })
  }

  const limited = queries.slice(0, 6)
  const results = await Promise.allSettled(limited.map((q) => q.fn()))

  const data: Record<string, unknown> = {}
  let hasData = false
  let failures = 0
  for (let i = 0; i < limited.length; i++) {
    const result = results[i]!
    if (result.status === 'fulfilled' && result.value !== null) {
      data[limited[i]!.key] = result.value
      hasData = true
    } else if (result.status === 'rejected') {
      failures++
      console.warn('[market-study-generator] Serper query failed', {
        query: limited[i]!.key,
        error: result.reason instanceof Error ? result.reason.message : String(result.reason),
      })
    }
  }

  if (failures > 0) {
    console.warn(`[market-study-generator] ${failures}/${limited.length} Serper queries fallaron — estudio generado con datos parciales`)
  }

  return { hasData, queries: data }
}

// ── Fallback: OpenAI web search ──────────────────────────────────────────────

/**
 * Fallback cuando Serper no está disponible: usa gpt-4o-search-preview de OpenAI
 * para buscar información de competidores y mercado en internet.
 *
 * Retorna texto con los hallazgos para inyectar en el prompt de síntesis.
 * Si OPENAI_API_KEY no está configurada, retorna null (degradación elegante).
 */
async function researchWithOpenAISearch(
  answers: Record<string, unknown>,
  brief: StrategicBrief | null,
  billingContext?: BillingContext,
): Promise<string | null> {
  let openai
  try {
    openai = getOpenAIClient()
  } catch {
    console.warn('[market-study-generator] OpenAI no configurado — estudio sin datos de internet')
    return null
  }

  const zonaGeografica = safeQuery(
    brief?.mercado?.zonaGeografica ?? answers['research_3'] ?? answers['location'],
  )
  const competidores = (brief?.mercado?.competidores ?? []) as Array<{ nombre: string }>
  const rubro = safeQuery(brief?.negocio?.descripcion ?? answers['research_1'])
  const nombreNegocio = safeQuery(answers['business_name'] ?? answers['research_1'])

  const competidoresTexto = competidores.map((c) => c.nombre).filter(Boolean).join(', ')

  const searchPrompt = [
    `Investigá el mercado de "${rubro}" en ${zonaGeografica || 'Argentina'}.`,
    competidoresTexto
      ? `Competidores mencionados: ${competidoresTexto}. Buscá información sobre ellos (sitio web, reseñas de Google, fortalezas, debilidades).`
      : `Buscá los principales competidores del rubro en la zona.`,
    nombreNegocio
      ? `El negocio del cliente se llama "${nombreNegocio}" — buscá si tiene presencia en Google Maps y qué rating tiene.`
      : '',
    'Buscá tendencias actuales del rubro en Argentina.',
    'Para cada competidor encontrado, incluí: nombre, sitio web, rating de Google, cantidad de reseñas.',
    'Respondé en español con datos concretos y URLs reales. No inventes datos.',
  ].filter(Boolean).join('\n')

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-search-preview',
      web_search_options: { search_context_size: 'medium' },
      messages: [{ role: 'user', content: searchPrompt }],
    })

    const content = response.choices[0]?.message?.content
    if (!content) {
      console.warn('[market-study-generator] OpenAI search devolvió respuesta vacía')
      return null
    }

    if (billingContext) {
      void registerAiUsage({
        teamId: billingContext.teamId,
        projectId: billingContext.projectId,
        provider: 'OPENAI',
        model: 'gpt-4o-search-preview',
        operation: 'market_research_web_search',
        source: billingContext.source,
        tokensIn: response.usage?.prompt_tokens ?? 0,
        tokensOut: response.usage?.completion_tokens ?? 0,
      })
    }

    console.info('[market-study-generator] OpenAI search fallback exitoso', {
      promptLength: searchPrompt.length,
      responseLength: content.length,
    })

    return content
  } catch (err) {
    console.error('[market-study-generator] OpenAI search fallback falló', {
      error: err instanceof Error ? err.message : String(err),
    })
    return null
  }
}

// ── Truncado de datos Serper ──────────────────────────────────────────────────

const MAX_ORGANIC_RESULTS = 5
const MAX_SNIPPET_CHARS = 200
const MAX_PLACES = 8

function truncateSerperData(queries: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(queries)) {
    if (typeof value !== 'object' || value === null) {
      out[key] = value
      continue
    }
    const obj = value as Record<string, unknown>
    if (Array.isArray(obj['organic'])) {
      out[key] = {
        organic: (obj['organic'] as Array<Record<string, unknown>>)
          .slice(0, MAX_ORGANIC_RESULTS)
          .map((r) => ({
            title: r['title'],
            link: r['link'],
            snippet: typeof r['snippet'] === 'string' ? r['snippet'].slice(0, MAX_SNIPPET_CHARS) : r['snippet'],
            position: r['position'],
          })),
        ...(obj['relatedSearches'] ? { relatedSearches: obj['relatedSearches'] } : {}),
      }
    } else if (Array.isArray(obj['places'])) {
      out[key] = {
        places: (obj['places'] as Array<Record<string, unknown>>).slice(0, MAX_PLACES),
      }
    } else {
      out[key] = value
    }
  }
  return out
}

// ── Validación ────────────────────────────────────────────────────────────────

function validateMarketStudy(raw: unknown): MarketStudy {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error('[market-study-generator] Output no es un objeto')
  }
  const obj = raw as Record<string, unknown>
  if (typeof obj['resumenEjecutivo'] !== 'object' || obj['resumenEjecutivo'] === null) {
    throw new Error('[market-study-generator] Falta resumenEjecutivo')
  }
  const res = obj['resumenEjecutivo'] as Record<string, unknown>
  if (typeof res['panorama'] !== 'string') {
    throw new Error('[market-study-generator] resumenEjecutivo.panorama debe ser string')
  }
  if (!Array.isArray(obj['competidores'])) {
    throw new Error('[market-study-generator] competidores debe ser un array')
  }
  for (const c of obj['competidores'] as unknown[]) {
    if (typeof c !== 'object' || c === null) {
      throw new Error('[market-study-generator] competidores[*] debe ser un objeto')
    }
    const comp = c as Record<string, unknown>
    if (typeof comp['nombre'] !== 'string') {
      throw new Error('[market-study-generator] competidores[*].nombre debe ser string')
    }
    if (!Array.isArray(comp['fortalezasDigitales'])) {
      throw new Error('[market-study-generator] competidores[*].fortalezasDigitales debe ser array')
    }
    if (!Array.isArray(comp['debilidadesDigitales'])) {
      throw new Error('[market-study-generator] competidores[*].debilidadesDigitales debe ser array')
    }
  }
  if (typeof obj['presenciaDigital'] !== 'object' || obj['presenciaDigital'] === null) {
    throw new Error('[market-study-generator] Falta presenciaDigital')
  }
  if (!Array.isArray(obj['tendencias'])) {
    throw new Error('[market-study-generator] tendencias debe ser un array')
  }
  for (const t of obj['tendencias'] as unknown[]) {
    if (typeof t !== 'object' || t === null) {
      throw new Error('[market-study-generator] tendencias[*] debe ser un objeto')
    }
    const trend = t as Record<string, unknown>
    if (typeof trend['tendencia'] !== 'string') {
      throw new Error('[market-study-generator] tendencias[*].tendencia debe ser string')
    }
  }
  if (!Array.isArray(obj['oportunidades'])) {
    throw new Error('[market-study-generator] oportunidades debe ser un array')
  }
  if (!Array.isArray(obj['amenazas'])) {
    throw new Error('[market-study-generator] amenazas debe ser un array')
  }
  if (typeof obj['recomendaciones'] !== 'object' || obj['recomendaciones'] === null) {
    throw new Error('[market-study-generator] Falta recomendaciones')
  }
  return raw as MarketStudy
}

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Genera el MarketStudy combinando datos de Serper + síntesis AI.
 * Usa el provider/modelo configurado en TrialConfig (admin panel).
 *
 * @param flowDefinition - Preguntas de la entrevista RESEARCH
 * @param answers - Respuestas del usuario
 * @param briefContent - Brief de etapa 1, si existe (contexto adicional)
 * @returns MarketStudy estructurado
 * @throws Error si el modelo falla o no devuelve el output esperado
 */
export async function generateMarketStudy(
  flowDefinition: QuestionBlock[],
  answers: Record<string, unknown>,
  briefContent: StrategicBrief | null,
  billingContext?: BillingContext,
): Promise<MarketStudy> {
  const interviewContent = buildInterviewSummary(flowDefinition, answers)
  const serperData = await researchWithSerper(answers, briefContent)

  const briefSection = briefContent
    ? `\n\n## Brief Estratégico (Etapa 1):\n${JSON.stringify(briefContent, null, 2)}`
    : ''

  let internetDataSection: string
  if (serperData.hasData) {
    internetDataSection = `\n\n## Datos de internet (búsqueda automatizada):\n${JSON.stringify(truncateSerperData(serperData.queries), null, 2)}`
  } else {
    console.info('[market-study-generator] Serper sin datos — intentando fallback OpenAI search')
    const openaiSearchResult = await researchWithOpenAISearch(answers, briefContent, billingContext)
    if (openaiSearchResult) {
      internetDataSection = `\n\n## Datos de internet (investigación web):\n${openaiSearchResult}`
    } else {
      internetDataSection = '\n\n## Datos de internet: No disponibles (generá el estudio solo con las respuestas del cliente)'
    }
  }

  const userMessage =
    `Acá está la información para el Estudio de Mercado:\n\n## Entrevista de investigación:\n${interviewContent}` +
    briefSection +
    internetDataSection +
    '\n\nGenerá el Estudio de Mercado completo.'

  const result = await executeToolCall({
    system: SYNTHESIS_SYSTEM_PROMPT,
    userMessage,
    tool: GENERATE_MARKET_STUDY_TOOL,
    maxTokens: 8192,
    logPrefix: 'market-study-generator',
    billingContext: billingContext ? { ...billingContext, operation: 'market_study' } : undefined,
  })

  return validateMarketStudy(result.input)
}
