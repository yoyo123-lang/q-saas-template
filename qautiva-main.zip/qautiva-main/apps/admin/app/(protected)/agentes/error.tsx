'use client'

import { useEffect } from 'react'
import Link from 'next/link'

interface ErrorBoundaryProps {
  error: Error & { digest?: string }
  reset: () => void
}

export default function AgentesError({ error, reset }: ErrorBoundaryProps) {
  useEffect(() => {
    console.error('[admin:agentes] error en página de agentes:', error)
  }, [error])

  return (
    <div className="flex flex-col items-center justify-center h-full gap-4 p-6">
      <div className="text-center">
        <p className="text-[#EF4444] font-semibold text-lg mb-1">
          No se pudo cargar los agentes
        </p>
        <p className="text-[#64748B] text-sm">
          Ocurrió un error al conectar con la base de datos.
        </p>
        {error.digest && (
          <p className="text-[#475569] text-xs mt-2 font-mono">Ref: {error.digest}</p>
        )}
      </div>
      <div className="flex gap-3">
        <button
          onClick={reset}
          className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
        >
          Reintentar
        </button>
        <Link
          href="/"
          className="px-4 py-2 rounded-lg bg-[#0F172A] text-[#64748B] text-sm hover:bg-[#1E293B] transition-colors border border-[#1E293B]"
        >
          Ir al inicio
        </Link>
      </div>
    </div>
  )
}
