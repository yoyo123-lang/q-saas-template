import Link from 'next/link'
import type { DeliverableStatus, DeliverableType } from '@qautiva/db'

type DeliverableCardProps = {
  id: string
  title: string
  type: DeliverableType
  status: DeliverableStatus
  updatedAt: Date
  /** Override the navigation href. Defaults to /entregables/{id} */
  href?: string
}

const TYPE_LABELS: Record<DeliverableType, string> = {
  BRIEF: 'Brief estratégico',
  MARKET_STUDY: 'Estudio de mercado',
  BRAND_MANUAL: 'Manual de marca',
  BRAND_OPTIONS: 'Propuesta de marca',
  WEBSITE_PREVIEW: 'Preview del sitio',
  CAMPAIGN_PLAN: 'Plan de campañas',
  AD_CREATIVES: 'Piezas publicitarias',
  AD_VISUALS: 'Piezas gráficas',
  MEDIA_ARTICLES: 'Notas publicadas',
}

type StatusInfo = {
  label: string
  className: string
  requiresAction: boolean
}

const STATUS_INFO: Record<DeliverableStatus, StatusInfo> = {
  DRAFT: {
    label: 'Borrador',
    className: 'bg-[#64748B]/15 text-[#64748B] border border-[#64748B]/30',
    requiresAction: false,
  },
  ADMIN_APPROVED: {
    label: 'En revisión',
    className: 'bg-[#3B82F6]/15 text-[#3B82F6] border border-[#3B82F6]/30',
    requiresAction: false,
  },
  SENT_TO_CLIENT: {
    label: 'Esperando tu aprobación',
    className: 'bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30',
    requiresAction: true,
  },
  CLIENT_APPROVED: {
    label: 'Aprobado',
    className: 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30',
    requiresAction: false,
  },
  REVISION_REQUESTED: {
    label: 'Cambios solicitados',
    className: 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30',
    requiresAction: false,
  },
  REGENERATING: {
    label: 'Regenerando',
    className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30',
    requiresAction: false,
  },
  // Fase A: nuevos estados del flujo self-service
  GENERATING: {
    label: 'Generando',
    className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30',
    requiresAction: false,
  },
  READY: {
    label: 'Listo para revisar',
    className: 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30',
    requiresAction: true,
  },
  FAILED: {
    label: 'Error en generación',
    className: 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30',
    requiresAction: false,
  },
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('es-AR', { day: 'numeric', month: 'short', year: 'numeric' })
}

/**
 * Tarjeta navegable que representa un entregable en el listado.
 * Muestra tipo, título, estado y fecha de actualización.
 * El borde se torna ámbar cuando el entregable requiere acción del cliente (SENT_TO_CLIENT).
 */
export function DeliverableCard({ id, title, type, status, updatedAt, href }: DeliverableCardProps) {
  const statusInfo = STATUS_INFO[status]

  return (
    <Link
      href={href ?? `/entregables/${id}`}
      className={`
        block bg-[#0F172A] border rounded-xl p-5
        hover:border-[#8B5CF6]/50 transition-colors duration-200
        ${statusInfo.requiresAction ? 'border-[#F59E0B]/40' : 'border-[#1E293B]'}
      `}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-[#64748B] text-xs mb-1">{TYPE_LABELS[type]}</p>
          <h3 className="text-white font-semibold text-base leading-tight truncate">{title}</h3>
          <p className="text-[#64748B] text-xs mt-2">Actualizado {formatDate(updatedAt)}</p>
        </div>
        <div className="flex flex-col items-end gap-2 flex-shrink-0">
          <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusInfo.className}`}>
            {statusInfo.label}
          </span>
          {statusInfo.requiresAction && (
            <span className="text-[#F59E0B] text-xs font-medium">Acción requerida →</span>
          )}
        </div>
      </div>
    </Link>
  )
}
