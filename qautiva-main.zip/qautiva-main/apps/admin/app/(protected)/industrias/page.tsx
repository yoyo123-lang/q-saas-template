import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import { IndustriaRowActions } from './_row-actions'

export const dynamic = 'force-dynamic'

function formatDate(date: Date): string {
  return date.toLocaleDateString('es-AR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  })
}

function formatPercent(value: number): string {
  return `${(value * 100).toFixed(1)}%`
}

export default async function IndustriasPage() {
  const industries = await prisma.industryTemplate.findMany({
    orderBy: { name: 'asc' },
    select: {
      id: true,
      name: true,
      clientCount: true,
      successRate: true,
      createdAt: true,
    },
  })

  return (
    <div className="p-8 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Industrias</h1>
        <Link
          href="/industrias/nueva"
          className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] transition-colors"
        >
          + Nueva industria
        </Link>
      </div>

      {/* Estado vacío */}
      {industries.length === 0 && (
        <div className="border border-[#1E293B] rounded-lg p-12 text-center">
          <p className="text-[#64748B] text-sm">
            No hay industrias todavía. Creá la primera para empezar a configurar templates.
          </p>
        </div>
      )}

      {/* Tabla */}
      {industries.length > 0 && (
        <div className="border border-[#1E293B] rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1E293B] bg-[#0F172A]">
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Nombre</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Clientes</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Tasa de éxito</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Creada</th>
                <th className="text-right px-4 py-3 text-[#64748B] font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {industries.map((industry, idx) => (
                <tr
                  key={industry.id}
                  className={`border-b border-[#1E293B] last:border-0 ${idx % 2 === 0 ? 'bg-[#0B0F1A]' : 'bg-[#0F172A]/50'}`}
                >
                  <td className="px-4 py-3 text-white font-medium">{industry.name}</td>
                  <td className="px-4 py-3 text-[#94A3B8]">{industry.clientCount}</td>
                  <td className="px-4 py-3 text-[#94A3B8]">{formatPercent(industry.successRate)}</td>
                  <td className="px-4 py-3 text-[#94A3B8]">{formatDate(industry.createdAt)}</td>
                  <td className="px-4 py-3">
                    <IndustriaRowActions
                      id={industry.id}
                      name={industry.name}
                      clientCount={industry.clientCount}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
