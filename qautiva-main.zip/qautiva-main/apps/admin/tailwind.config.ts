import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: { 950: '#0B0F1A', 900: '#0F172A', 800: '#1E293B' },
        accent: { DEFAULT: '#8B5CF6', light: '#A78BFA' },
        status: { success: '#10B981', warning: '#F59E0B', error: '#EF4444' },
      },
      fontFamily: {
        display: ['"Satoshi"', '"DM Sans"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Fira Code"', 'monospace'],
      },
      borderRadius: { card: '12px' },
    },
  },
  plugins: [],
}

export default config
