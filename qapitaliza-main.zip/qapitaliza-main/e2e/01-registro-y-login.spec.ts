import { test, expect } from '@playwright/test'

/**
 * E2E: Registro y Login
 * Prerequisite: a test email account that can receive magic links / OTP
 * For CI, use Supabase test mode or seed with a pre-confirmed user.
 */

const TEST_EMAIL = process.env.E2E_TEST_EMAIL ?? 'e2e+test@qapitaliza.com'
const TEST_PASSWORD = process.env.E2E_TEST_PASSWORD ?? 'TestPass123!'

test.describe('Registro y Login', () => {
  test('Login con credenciales incorrectas muestra error', async ({ page }) => {
    await page.goto('/login')

    await page.fill('input[type="email"]', 'nobody@example.com')
    await page.fill('input[type="password"]', 'wrongpassword')
    await page.click('button[type="submit"]')

    // Match only words unique to error toasts (not already present in the login form)
    // "incorrectos" → invalid_credentials | "verificada" → email_not_confirmed
    // "intentá" → generic error | "demasiados" → rate-limit
    await expect(
      page.getByText(/incorrectos|verificada|intentá de nuevo|demasiados/i)
    ).toBeVisible({ timeout: 10000 })
  })

  test('Página de login tiene links a registro y recuperación', async ({ page }) => {
    await page.goto('/login')

    await expect(page.getByRole('link', { name: /registrate/i })).toBeVisible()
    await expect(
      page.getByRole('link', { name: /olvidaste.+contraseña/i })
    ).toBeVisible()
  })

  test('Link de registro navega a /registro', async ({ page }) => {
    await page.goto('/login')
    await page.getByRole('link', { name: /registrate/i }).click()
    await expect(page).toHaveURL(/\/registro/)
  })

  test('Página de registro tiene link a /login', async ({ page }) => {
    await page.goto('/registro')
    // "Iniciá sesión" — match by the unique word "sesión" in the link's accessible name
    await expect(page.getByRole('link', { name: /sesión/i })).toBeVisible()
  })

  test('Login exitoso redirige al dashboard (requires seed user)', async ({ page }) => {
    // This test requires a pre-confirmed seed user in the database.
    // Skip if no test credentials are configured.
    if (!process.env.E2E_TEST_EMAIL || !process.env.E2E_TEST_PASSWORD) {
      test.skip()
      return
    }

    await page.goto('/login')
    await page.fill('input[type="email"]', TEST_EMAIL)
    await page.fill('input[type="password"]', TEST_PASSWORD)
    await page.click('button[type="submit"]')

    await expect(page).toHaveURL(/\/dashboard/, { timeout: 10000 })
  })
})
