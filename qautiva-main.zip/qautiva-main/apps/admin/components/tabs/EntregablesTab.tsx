import { DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL } from '@/lib/badges'
import type { OrgWithDetails, OrgStage, OrgDeliverable } from '@/lib/types'

type DeliverableWithStage = OrgDeliverable & { stageName: string; stageNumber: number }

// ── Componente ─────────────────────────────────────────────────────────────────

interface EntregablesTabProps {
  stages: OrgWithDetails['stages']
}

export function EntregablesTab({ stages }: EntregablesTabProps) {
  const deliverables: DeliverableWithStage[] = stages.flatMap((stage: OrgStage) =>
    stage.deliverables.map((d) => ({
      ...d,
      stageName: stage.name,
      stageNumber: stage.number,
    })),
  )

  if (deliverables.length === 0) {
    return <p className="text-[#64748B] text-sm">No hay entregables registrados aún.</p>
  }

  return (
    <div className="flex flex-col gap-2 overflow-y-auto flex-1 pb-4">
      {deliverables.map((d) => {
        const badge = DELIVERABLE_STATUS_BADGE[d.status]
        return (
          <div
            key={d.id}
            className="flex items-start gap-4 p-3 rounded-xl bg-[#0F172A] border border-[#1E293B]"
          >
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm leading-snug">{d.title}</p>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className="text-[#64748B] text-xs">{DELIVERABLE_TYPE_LABEL[d.type]}</span>
                <span className="text-[#475569] text-xs">·</span>
                <span className="text-[#64748B] text-xs">
                  {d.stageNumber}. {d.stageName}
                </span>
                <span className="text-[#475569] text-xs">· v{d.version}</span>
              </div>
              {d.feedback && (
                <p className="text-[#F87171] text-xs mt-1 italic">&ldquo;{d.feedback}&rdquo;</p>
              )}
            </div>
            <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
              {badge.label}
            </span>
          </div>
        )
      })}
    </div>
  )
}
