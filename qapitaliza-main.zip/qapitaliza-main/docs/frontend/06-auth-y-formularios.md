# Auth y Formularios — Especificación Frontend

> Cubre páginas de autenticación y las reglas generales de formularios en toda la app.

---

## Rutas de Auth

```
app/
  (auth)/
    layout.tsx      ← layout 2 columnas decorativa/formulario
    login/
      page.tsx
    registro/
      page.tsx
    recuperar/
      page.tsx      ← solicitar reset de contraseña
    nueva-contrasena/
      page.tsx      ← confirmar nueva contraseña (con token)
```

---

## Layout Auth — 2 columnas

**Archivo:** `app/(auth)/layout.tsx`

```tsx
<div className="min-h-screen grid grid-cols-2">
  {/* Columna decorativa */}
  <div className="bg-navy-950 mesh-gradient-amber flex flex-col items-center justify-center p-12">
    <LogoQ size="lg" showText />
    <p className="text-slate-400 text-base mt-3">El marketplace de activos digitales</p>
    <div className="mt-8 text-sm text-slate-500">
      Más de 340 emprendedores ya operan en Qapitaliza
    </div>
    {/* slot para contenido extra por página (features list, etc.) */}
    <AuthDecorativeContent />
  </div>

  {/* Columna formulario */}
  <div className="bg-navy-900 flex items-center justify-center p-12">
    {children}
  </div>
</div>
```

`<AuthDecorativeContent />` — componente que cambia según la página:
- Login: stat "340+ emprendedores"
- Registro: lista de 3 features con check amber

---

## 1. Login (`/login`)

**Archivo:** `app/(auth)/login/page.tsx`

### Formulario

```tsx
<form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
  <div>
    <h1 className="text-2xl font-semibold text-slate-50">Iniciá sesión</h1>
    <p className="text-sm text-slate-400 mt-1">Ingresá a tu cuenta para comprar o vender activos</p>
  </div>

  <Button variant="ghost" className="w-full border border-slate-800 bg-slate-800 hover:border-amber-500/30"
    onClick={handleGoogleLogin}>
    <GoogleIcon /> Continuar con Google
  </Button>

  <Divider label="o" />

  <Input label="Email" type="email" placeholder="tu@email.com" {...register('email')} error={errors.email} />

  <div className="space-y-1">
    <Input label="Contraseña" type="password" showToggle {...register('password')} error={errors.password} />
    <Link href="/recuperar" className="text-xs text-amber-500 float-right">¿Olvidaste tu contraseña?</Link>
  </div>

  <Button type="submit" variant="solid" size="full" loading={isLoading}>
    Iniciar sesión
  </Button>

  <p className="text-sm text-center text-slate-400">
    ¿No tenés cuenta?{' '}
    <Link href="/registro" className="text-amber-500 hover:text-amber-400">Registrate</Link>
  </p>
</form>
```

### Validación (Zod)

```ts
const loginSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres'),
})
```

### Rate limiting

El backend rechaza después de 5 intentos en 1 minuto. El frontend debe:
- Mostrar error claro: "Demasiados intentos. Intentá de nuevo en X minutos"
- Deshabilitar el botón con countdown si recibe 429

### Flujo post-login

```ts
const redirectAfterLogin = (user: User) => {
  const next = searchParams.get('next')
  if (next && next.startsWith('/')) return router.push(next)
  if (user.role === 'ADMIN') return router.push('/admin')
  return router.push('/dashboard')
}
```

---

## 2. Registro (`/registro`)

**Archivo:** `app/(auth)/registro/page.tsx`

### Formulario

Mismo layout de columna que login.

```ts
const registerSchema = z.object({
  nombre: z.string().min(2, 'Ingresá tu nombre completo').max(100),
  email: z.string().email('Email inválido'),
  password: z.string()
    .min(8, 'Mínimo 8 caracteres')
    .regex(/[A-Z]/, 'Debe tener al menos una mayúscula')
    .regex(/[0-9]/, 'Debe tener al menos un número'),
  confirmPassword: z.string(),
  rol: z.enum(['BUYER', 'SELLER']),
  acceptTerms: z.literal(true, { errorMap: () => ({ message: 'Debés aceptar los términos' }) }),
}).refine(data => data.password === data.confirmPassword, {
  message: 'Las contraseñas no coinciden',
  path: ['confirmPassword'],
})
```

### Indicador de fuerza de contraseña

```tsx
<PasswordStrength password={watchPassword} />
```

```ts
// Lógica de fuerza
const getStrength = (password: string): { level: 0|1|2|3; label: string; color: string } => {
  let score = 0
  if (password.length >= 8) score++
  if (/[A-Z]/.test(password)) score++
  if (/[0-9]/.test(password)) score++
  if (/[^A-Za-z0-9]/.test(password)) score++

  return [
    { level: 0, label: '', color: 'bg-slate-800' },
    { level: 1, label: 'Débil', color: 'bg-red-500' },
    { level: 2, label: 'Media', color: 'bg-amber-500' },
    { level: 3, label: 'Fuerte', color: 'bg-emerald-500' },
  ][Math.min(score, 3)]
}
```

Barra: 3 segmentos, se llenan progresivamente con el color correspondiente.

### Selector de rol

```tsx
<div className="grid grid-cols-2 gap-3">
  <RoleCard
    value="BUYER"
    selected={watch('rol') === 'BUYER'}
    onClick={() => setValue('rol', 'BUYER')}
    icon={<ShoppingBag size={24} />}
    title="Quiero comprar"
    description="Explorá activos digitales para invertir"
  />
  <RoleCard
    value="SELLER"
    selected={watch('rol') === 'SELLER')}
    onClick={() => setValue('rol', 'SELLER')}
    icon={<Upload size={24} />}
    title="Quiero vender"
    description="Publicá tus sitios, dominios y proyectos"
  />
</div>
<p className="text-xs text-slate-500 text-center mt-1">(Podés hacer ambas cosas después)</p>
```

`<RoleCard>` seleccionada: `border-amber-500 bg-amber-500/[0.08] shadow-[0_0_0_1px_rgba(245,158,11,0.3)]`

### Flujo post-registro

1. Supabase crea el usuario con email + password
2. Server Action crea el `Profile` en DB con `role`
3. Supabase envía email de verificación
4. Redirigir a `/dashboard` con banner: "Verificá tu email para activar todas las funciones"

---

## 3. Recuperar Contraseña (`/recuperar`)

**Archivo:** `app/(auth)/recuperar/page.tsx`

Formulario simple: solo email.

```tsx
<form onSubmit={handleSubmit}>
  <Input label="Email" type="email" placeholder="tu@email.com" {...register('email')} />
  <Button type="submit" variant="solid" size="full" loading={isLoading}>
    Enviar instrucciones
  </Button>
</form>
```

Post-submit: mostrar estado de éxito aunque el email no exista (por seguridad):
```
"Si existe una cuenta con ese email, recibirás las instrucciones en los próximos minutos."
```

---

## 4. Nueva Contraseña (`/nueva-contrasena`)

**Archivo:** `app/(auth)/nueva-contrasena/page.tsx`

Lee `token` del searchParam (lo maneja Supabase Auth). Si no hay token válido → redirigir a `/recuperar` con mensaje de error.

Campos: contraseña nueva + confirmar contraseña. Misma validación y strength indicator que en registro.

---

## 5. Reglas globales de formularios

### Librería

- **react-hook-form** para manejo de estado
- **zod** para esquemas de validación
- `zodResolver` como resolver de react-hook-form

```ts
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
```

### Validación

- Validar en `onSubmit` y también en `onBlur` para campos individuales
- Mostrar errores debajo del campo, en rojo, con el componente `<Input error="...">` nativo
- Nunca mostrar errores de campos que el usuario todavía no tocó (`touchedFields`)

### Submit

- Mientras el submit está en curso: deshabilitar el botón y mostrar spinner
- Si el submit falla: mostrar toast de error + habilitar el botón nuevamente
- Si el submit tiene éxito: mostrar toast de éxito + ejecutar la redirección/acción correspondiente

### Toast notifications

Librería: **Sonner** (`sonner`). Configuración en `app/layout.tsx`:

```tsx
import { Toaster } from 'sonner'

// En layout:
<Toaster
  theme="dark"
  toastOptions={{
    style: { background: '#0F172A', border: '1px solid #1E293B', color: '#F8FAFC' },
  }}
  position="top-right"
/>
```

Uso:
```ts
import { toast } from 'sonner'

toast.success('Cambios guardados')
toast.error('Ocurrió un error. Intentá de nuevo.')
toast.loading('Guardando...')  // se reemplaza con success o error
```

### Estados de carga en Server Actions

Pattern recomendado con `useTransition`:

```ts
const [isPending, startTransition] = useTransition()

const handleSubmit = (data: FormData) => {
  startTransition(async () => {
    const result = await serverAction(data)
    if (result.error) {
      toast.error(result.error)
    } else {
      toast.success('Guardado correctamente')
      router.push('/siguiente-ruta')
    }
  })
}
```

### Manejo de errores de red

```ts
// En cualquier Server Action
try {
  // lógica
  return { success: true }
} catch (error) {
  console.error('[ActionName]', error)
  return { success: false, error: 'Ocurrió un error inesperado. Intentá de nuevo.' }
}
```

Nunca exponer mensajes internos de error a la UI.

---

## 6. TagInput — componente de chips

**Archivo:** `src/components/ui/TagInput.tsx`

Usado en: crear/editar listado (tech stack, tags).

```tsx
interface TagInputProps {
  value: string[]
  onChange: (tags: string[]) => void
  placeholder?: string
  max?: number
  maxTagLength?: number
  suggestions?: string[]  // opciones autocomplete (tech stack conocidos)
}
```

Comportamiento:
- Tipear + Enter o coma → agrega el tag
- Click `×` en pill → elimina el tag
- Si `max` alcanzado → deshabilitar input con mensaje "Máximo X tags"
- Tecla Backspace con input vacío → elimina el último tag
- Suggestions: dropdown que filtra por texto ingresado

Pills: `bg-slate-800 text-slate-50 text-xs font-mono px-2.5 py-1 rounded-full flex items-center gap-1.5`

---

## 7. Responsive — breakpoints

| Breakpoint | px | Comportamiento |
|---|---|---|
| `sm` | 640px | — |
| `md` | 768px | Layout auth pasa a 1 columna (solo formulario) |
| `lg` | 1024px | Grid catálogo pasa de 3 a 2 columnas |
| `xl` | 1280px | Default — layouts de 3 col y sidebar 280px |

Sidebar en mobile (`< md`): drawer lateral con overlay, controlado por estado.

Grid de ListingCards:
```tsx
<div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
```

Grid de StatCards:
```tsx
<div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
```
