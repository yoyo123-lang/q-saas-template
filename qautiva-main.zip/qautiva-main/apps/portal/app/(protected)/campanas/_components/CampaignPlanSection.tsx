'use client'

import type { CampaignPlan } from '@/app/_lib/interview/types'
import type { DeliverableStatus } from '@qautiva/db'

const PLATFORM_LABEL: Record<string, string> = {
  GOOGLE_ADS: 'Google Ads',
  META: 'Meta Ads (Facebook / Instagram)',
}

const STATUS_BADGE: Record<string, { label: string; className: string }> = {
  READY: { label: 'Listo para revisar', className: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' },
  SENT_TO_CLIENT: { label: 'Enviado', className: 'bg-violet-500/10 text-violet-400 border border-violet-500/20' },
  CLIENT_APPROVED: { label: 'Aprobado', className: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' },
  REVISION_REQUESTED: { label: 'Revisión solicitada', className: 'bg-amber-500/10 text-amber-400 border border-amber-500/20' },
  GENERATING: { label: 'Generando…', className: 'bg-blue-500/10 text-blue-400 border border-blue-500/20' },
  DRAFT: { label: 'Borrador', className: 'bg-slate-500/10 text-slate-400 border border-slate-500/20' },
}

function formatARS(amount: number): string {
  return '$' + amount.toLocaleString('es-AR')
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="text-xs font-semibold text-[#64748B] uppercase tracking-wider mb-3">
      {children}
    </h3>
  )
}

function InfoCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-4 rounded-lg bg-[#0B0F1A] border border-[#1E293B]">
      {children}
    </div>
  )
}

type Props = {
  plan: CampaignPlan
  status: DeliverableStatus
  version: number
}

export function CampaignPlanSection({ plan, status, version }: Props) {
  const badge = STATUS_BADGE[status] ?? { label: status, className: 'bg-slate-500/10 text-slate-400 border border-slate-500/20' }

  return (
    <section className="mb-10">
      {/* Encabezado */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-white">Plan de campaña</h2>
        <div className="flex items-center gap-2">
          <span className="text-[#64748B] text-xs">v{version}</span>
          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-medium ${badge.className}`}>
            {badge.label}
          </span>
        </div>
      </div>

      {/* Disclaimer */}
      {plan.disclaimer && (
        <p className="text-xs text-[#64748B] italic mb-6 p-3 rounded-lg border border-[#1E293B] bg-[#0F172A]">
          {plan.disclaimer}
        </p>
      )}

      <div className="space-y-6">
        {/* Resumen */}
        <div>
          <SectionTitle>Objetivo y presupuesto</SectionTitle>
          <InfoCard>
            <p className="text-sm text-white leading-relaxed mb-3">{plan.resumen.objetivos}</p>
            <div className="flex flex-wrap gap-4 text-sm">
              <div>
                <span className="text-[#64748B] text-xs">Duración estimada</span>
                <p className="text-[#94A3B8] font-medium">{plan.resumen.duracionEstimada}</p>
              </div>
              <div>
                <span className="text-[#64748B] text-xs">Presupuesto recomendado</span>
                <p className="text-[#94A3B8] font-medium">
                  {formatARS(plan.resumen.presupuestoRecomendado.min)} – {formatARS(plan.resumen.presupuestoRecomendado.max)} / mes
                </p>
              </div>
            </div>
            {plan.resumen.presupuestoRecomendado.justificacion && (
              <p className="text-xs text-[#64748B] mt-2">{plan.resumen.presupuestoRecomendado.justificacion}</p>
            )}
          </InfoCard>
        </div>

        {/* Plataformas */}
        {plan.plataformas.length > 0 && (
          <div>
            <SectionTitle>Plataformas</SectionTitle>
            <div className="space-y-3">
              {plan.plataformas.map((p, i) => (
                <InfoCard key={i}>
                  <p className="text-sm font-medium text-white mb-1">
                    {PLATFORM_LABEL[p.nombre] ?? p.nombre}
                  </p>
                  <p className="text-xs text-[#94A3B8] mb-3">{p.razon}</p>
                  <div className="flex flex-wrap gap-2">
                    {p.formatos.map((f, j) => (
                      <span key={j} className="px-2 py-1 rounded-md bg-[#1E293B] text-xs text-[#94A3B8]">
                        {f.tipo} — {formatARS(f.presupuestoSugerido)}
                      </span>
                    ))}
                  </div>
                </InfoCard>
              ))}
            </div>
          </div>
        )}

        {/* Audiencias */}
        {plan.audiencias.length > 0 && (
          <div>
            <SectionTitle>Audiencias</SectionTitle>
            <div className="space-y-3">
              {plan.audiencias.map((a, i) => (
                <InfoCard key={i}>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-medium text-white">{a.nombre}</p>
                    <span className="text-xs text-[#64748B] flex-shrink-0">{a.tamanioEstimado}</span>
                  </div>
                  <p className="text-xs text-[#94A3B8] mb-2">{a.descripcion}</p>
                  {a.criterios.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {a.criterios.map((c, j) => (
                        <span key={j} className="px-2 py-0.5 rounded-full bg-[#1E293B] text-[10px] text-[#64748B]">
                          {c}
                        </span>
                      ))}
                    </div>
                  )}
                </InfoCard>
              ))}
            </div>
          </div>
        )}

        {/* Oferta */}
        {plan.oferta && (
          <div>
            <SectionTitle>Mensaje y oferta</SectionTitle>
            <InfoCard>
              <p className="text-sm text-white mb-2">{plan.oferta.mensajePrincipal}</p>
              <p className="text-xs text-[#64748B] mb-3">CTA: <span className="text-[#94A3B8]">{plan.oferta.callToAction}</span></p>
              {plan.oferta.variantesCreativas.length > 0 && (
                <div className="space-y-1">
                  {plan.oferta.variantesCreativas.map((v, i) => (
                    <p key={i} className="text-xs text-[#64748B]">· {v}</p>
                  ))}
                </div>
              )}
            </InfoCard>
          </div>
        )}

        {/* Calendario */}
        {plan.calendario.length > 0 && (
          <div>
            <SectionTitle>Calendario</SectionTitle>
            <div className="space-y-3">
              {plan.calendario.map((fase, i) => (
                <InfoCard key={i}>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-white">{fase.fase}</p>
                    <span className="text-xs text-[#64748B]">{fase.duracion} — {formatARS(fase.presupuesto)}</span>
                  </div>
                  <ul className="space-y-1">
                    {fase.actividades.map((act, j) => (
                      <li key={j} className="text-xs text-[#94A3B8]">· {act}</li>
                    ))}
                  </ul>
                </InfoCard>
              ))}
            </div>
          </div>
        )}

        {/* KPIs */}
        {plan.metricas?.kpisObjetivo.length > 0 && (
          <div>
            <SectionTitle>Métricas objetivo</SectionTitle>
            <div className="flex flex-wrap gap-3">
              {plan.metricas.kpisObjetivo.map((kpi, i) => (
                <div key={i} className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] min-w-[140px]">
                  <p className="text-[10px] text-[#64748B] uppercase tracking-wider mb-1">{kpi.nombre}</p>
                  <p className="text-sm font-medium text-white">{kpi.meta}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
