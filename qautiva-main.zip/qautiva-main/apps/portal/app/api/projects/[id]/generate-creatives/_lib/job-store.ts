/**
 * Job store en memoria para la generación asíncrona de Ad Visuals.
 *
 * Cada job vive en este Map durante el ciclo de vida del proceso de Node.
 * Suficiente para el MVP — la generación tarda <180s y el polling empieza inmediatamente.
 *
 * TTL de limpieza: 1 hora por job para evitar memory leaks en instancias longevas.
 */

import type { AdVisuals } from '@/app/_lib/interview/types'

// ── Tipos ──────────────────────────────────────────────────────────────────────

export type JobStatus = 'pending' | 'running' | 'done' | 'failed'

export type GenerationJob = {
  id: string
  projectId: string
  status: JobStatus
  result?: AdVisuals
  error?: string
  createdAt: number
  updatedAt: number
}

// ── Store ──────────────────────────────────────────────────────────────────────

const JOB_TTL_MS = 60 * 60 * 1000 // 1 hora

const store = new Map<string, GenerationJob>()

/**
 * Limpia jobs expirados del store (más de 1 hora de vida).
 * Se llama antes de cada escritura para evitar acumulación.
 */
function evictExpired(): void {
  const now = Date.now()
  for (const [id, job] of store.entries()) {
    if (now - job.createdAt > JOB_TTL_MS) {
      store.delete(id)
    }
  }
}

export function createJob(id: string, projectId: string): GenerationJob {
  evictExpired()
  const now = Date.now()
  const job: GenerationJob = {
    id,
    projectId,
    status: 'pending',
    createdAt: now,
    updatedAt: now,
  }
  store.set(id, job)
  return job
}

export function getJob(id: string): GenerationJob | undefined {
  return store.get(id)
}

export function updateJob(
  id: string,
  update: Partial<Pick<GenerationJob, 'status' | 'result' | 'error'>>,
): void {
  const job = store.get(id)
  if (!job) return
  Object.assign(job, { ...update, updatedAt: Date.now() })
}

// ── Inflight tracking ──────────────────────────────────────────────────────────
// Evita que un proyecto tenga dos generaciones activas simultáneamente.
// Se usa un Set separado del job store para poder consultarlo sin el jobId.

const inflightProjects = new Set<string>()

export function addInflightProject(projectId: string): void {
  inflightProjects.add(projectId)
}

export function removeInflightProject(projectId: string): void {
  inflightProjects.delete(projectId)
}

export function isProjectInflight(projectId: string): boolean {
  return inflightProjects.has(projectId)
}
