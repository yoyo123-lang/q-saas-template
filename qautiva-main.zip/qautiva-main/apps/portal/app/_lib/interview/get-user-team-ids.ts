import { prisma } from '@qautiva/db'

/**
 * Devuelve los teamIds del usuario autenticado, o null si no tiene membresías.
 * Helper compartido entre las rutas de interview para evitar duplicación.
 */
export async function getUserTeamIds(authUserId: string): Promise<string[] | null> {
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) return null

  return profile.teamMemberships.map((m) => m.teamId)
}
