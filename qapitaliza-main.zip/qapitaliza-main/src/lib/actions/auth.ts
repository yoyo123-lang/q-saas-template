'use server'

import { headers } from 'next/headers'
import { createClient } from '@/lib/supabase/server'
import { loginSchema, registerSchema, type LoginData, type RegisterData } from '@/lib/schemas/auth'
import { loginRateLimit, recuperarRateLimit, registerRateLimit } from '@/lib/rate-limit'
import { trackEvent } from '@/lib/analytics/events'

export interface ActionResult {
  success: boolean
  error?: string
}

export interface ProfileData {
  nombre?: string
  empresa?: string
  sitio_web?: string
  bio?: string
  notification_preferences?: {
    nuevas_consultas: boolean
    respuestas: boolean
    nuevos_listados: boolean
    resumen_semanal: boolean
  }
}

async function getClientIp(): Promise<string> {
  const headersList = await headers()
  return (
    headersList.get('x-forwarded-for')?.split(',')[0]?.trim() ??
    headersList.get('x-real-ip') ??
    'unknown'
  )
}

export async function signIn(data: LoginData): Promise<ActionResult> {
  try {
    const parsed = loginSchema.safeParse(data)
    if (!parsed.success) {
      return { success: false, error: 'Datos inválidos.' }
    }

    const ip = await getClientIp()
    const rateLimit = loginRateLimit(ip)
    if (!rateLimit.success) {
      return {
        success: false,
        error: `Demasiados intentos. Intentá de nuevo en ${rateLimit.retryAfter} segundos.`,
      }
    }

    const supabase = await createClient()
    const { error } = await supabase.auth.signInWithPassword({
      email: parsed.data.email,
      password: parsed.data.password,
    })

    if (error) {
      return { success: false, error: 'Email o contraseña incorrectos.' }
    }

    return { success: true }
  } catch {
    return { success: false, error: 'Ocurrió un error inesperado. Intentá de nuevo.' }
  }
}

export async function signUp(data: RegisterData): Promise<ActionResult> {
  try {
    const parsed = registerSchema.safeParse(data)
    if (!parsed.success) {
      return { success: false, error: 'Datos inválidos.' }
    }

    const ip = await getClientIp()
    const rateLimit = registerRateLimit(ip)
    if (!rateLimit.success) {
      return {
        success: false,
        error: `Demasiados intentos de registro. Intentá de nuevo en ${Math.ceil(rateLimit.retryAfter / 60)} minutos.`,
      }
    }

    const supabase = await createClient()
    const { data: authData, error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        data: {
          nombre: parsed.data.nombre,
          role: parsed.data.rol,
        },
      },
    })

    if (error) {
      return { success: false, error: 'Error al crear la cuenta. Intentá de nuevo.' }
    }

    // Registrar evento de funnel — nunca debe romper el flujo principal
    if (authData.user) {
      await trackEvent('SIGNUP_COMPLETED', 'user', authData.user.id, authData.user.id)
    }

    return { success: true }
  } catch {
    return { success: false, error: 'Ocurrió un error inesperado. Intentá de nuevo.' }
  }
}

export async function requestPasswordReset(email: string, redirectTo: string): Promise<ActionResult> {
  try {
    const ip = await getClientIp()
    const rateLimit = recuperarRateLimit(ip)
    if (!rateLimit.success) {
      return {
        success: false,
        error: `Demasiados intentos. Intentá de nuevo en ${Math.ceil(rateLimit.retryAfter / 60)} minutos.`,
      }
    }

    const supabase = await createClient()
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo })
    if (error) {
      console.error('[requestPasswordReset] error de Supabase:', error.message)
    }

    // Siempre retornar éxito: no revelar si el email existe o no
    return { success: true }
  } catch (err) {
    console.error('[requestPasswordReset] error inesperado:', err)
    return { success: true } // idem: no revelar nada al usuario
  }
}

export async function signOut(): Promise<void> {
  const supabase = await createClient()
  await supabase.auth.signOut()
}

export async function updateProfile(data: ProfileData): Promise<ActionResult> {
  try {
    const supabase = await createClient()
    const { data: { user }, error: userError } = await supabase.auth.getUser()

    if (userError || !user) {
      return { success: false, error: 'No autorizado.' }
    }

    const updates: Record<string, unknown> = {}
    if (data.nombre !== undefined) updates.nombre = data.nombre
    if (data.empresa !== undefined) updates.empresa = data.empresa
    if (data.sitio_web !== undefined) updates.sitio_web = data.sitio_web
    if (data.bio !== undefined) updates.bio = data.bio
    if (data.notification_preferences !== undefined) {
      updates.notification_preferences = data.notification_preferences
    }

    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', user.id)

    if (error) {
      return { success: false, error: 'Error al guardar los cambios.' }
    }

    return { success: true }
  } catch {
    return { success: false, error: 'Ocurrió un error inesperado. Intentá de nuevo.' }
  }
}
