# Sesión 09: Ventas y POS (frontend)

## Objetivo
Pantalla de punto de venta completa: buscar productos, armar carrito, seleccionar cliente, elegir medios de pago, cobrar, emitir ticket/factura. UI de caja diaria (abrir/cerrar). Al terminar, un vendedor puede operar el POS completo desde el navegador.

## Pre-requisitos
- Sesión 08 completada (SaleService, CashRegisterService, APIs de ventas y caja)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/app/api/v1/sales/` (endpoints de S08)
3. Leer `src/lib/services/sale-service.ts` (para entender el flujo)
4. Leer `src/components/shared/product-search.tsx` (componente reutilizable)
5. Leer `src/components/shared/contact-search.tsx` (componente reutilizable)

---

## Etapa 1: Layout del POS

### Tarea 1.1: Página principal del POS
**Archivo nuevo**: `src/app/dashboard/pos/page.tsx`

Layout a pantalla completa (sin sidebar del dashboard — el POS necesita todo el espacio):
- Header mínimo: logo, nombre de la org, nombre del cajero, botón "Salir del POS"
- Dos columnas:
  - **Izquierda (60%)**: búsqueda y catálogo de productos
  - **Derecha (40%)**: carrito y cobro

Si no hay caja abierta → mostrar dialog de apertura de caja antes de permitir vender.

### Tarea 1.2: Layout especial para POS
**Archivo nuevo**: `src/app/dashboard/pos/layout.tsx`

Layout que:
- NO renderiza el sidebar normal del dashboard
- Tiene su propio header mínimo
- Ocupa el 100% del viewport
- Incluye TenantProvider (heredado del dashboard layout)

### Tarea 1.3: Hook usePOS
**Archivo nuevo**: `src/hooks/use-pos.ts`

Hook que maneja el estado completo del POS:

```typescript
// Estado:
// - cart: CartItem[] — items en el carrito
// - contact: Contact | null — cliente seleccionado
// - payments: PaymentEntry[] — medios de pago ingresados
// - cashRegister: CashRegister | null — caja actual
// - isProcessing: boolean
//
// CartItem { product: Product, quantity: number, unitPrice: number, ivaRate: number, discount: number, subtotal: number }
// PaymentEntry { method: PaymentMethod, amount: number, reference?: string }
//
// Acciones:
// addToCart(product, quantity?)
// updateCartItem(index, updates)
// removeFromCart(index)
// clearCart()
// setContact(contact | null)
// addPayment(payment)
// removePayment(index)
// processSale(): Promise<SaleResult>
//
// Calculados:
// cartSubtotal, cartIva, cartDiscount, cartTotal
// totalPaid (sum de payments.amount)
// change (totalPaid - cartTotal, si > 0)
// canProcess (cart.length > 0 && totalPaid >= cartTotal)
```

**Commit**: `feat(pos): add POS layout, page structure and usePOS hook`

---

## Etapa 2: Panel izquierdo — Catálogo y búsqueda

### Tarea 2.1: Barra de búsqueda del POS
**Archivo nuevo**: `src/components/pos/pos-product-search.tsx`

Input de búsqueda optimizado para POS:
- Autofocus al entrar a la página
- Búsqueda por nombre, SKU, o código de barras
- Debounce de 200ms (más rápido que el estándar para POS)
- Si el resultado es un match exacto por barcode → agregar automáticamente al carrito (flujo de scanner)
- Si hay múltiples resultados → mostrar grilla/lista de resultados
- Enter en búsqueda vacía → no hacer nada
- Escape → limpiar búsqueda

### Tarea 2.2: Grilla de productos
**Archivo nuevo**: `src/components/pos/pos-product-grid.tsx`

Vista de productos para selección rápida:
- Grilla de cards (no tabla — más táctil/visual)
- Cada card muestra: nombre, precio, stock disponible
- Click en card → agregar 1 unidad al carrito
- Si el producto tiene variantes → mostrar sub-selector de variante
- Si stock = 0 y trackStock = true → card deshabilitada con badge "Sin stock"
- Tabs de categorías arriba para filtrar rápido (o "Todos")

### Tarea 2.3: Selector de categorías
**Archivo nuevo**: `src/components/pos/pos-category-tabs.tsx`

Tabs horizontales con scroll:
- "Todos" (default)
- Una tab por cada categoría con productos activos
- Al seleccionar: filtra la grilla de productos
- Badge con cantidad de productos por categoría

**Commit**: `feat(pos): add product search, grid and category tabs for POS`

---

## Etapa 3: Panel derecho — Carrito y cobro

### Tarea 3.1: Componente de carrito
**Archivo nuevo**: `src/components/pos/pos-cart.tsx`

Lista de items en el carrito:
- Por cada item: nombre, cantidad (editable inline), precio unitario, subtotal
- Botón +/- para ajustar cantidad rápidamente
- Botón X para eliminar item
- Input de descuento por item (% o monto fijo — toggle)
- Si el item no tiene stock suficiente para la cantidad → warning visual

Pie del carrito:
- Subtotal
- Descuento total
- IVA
- **TOTAL** (grande y prominente)
- Botón "Cobrar" (disabled si carrito vacío)
- Botón "Limpiar carrito" (con confirmación)

### Tarea 3.2: Selector de cliente
**Archivo nuevo**: `src/components/pos/pos-client-selector.tsx`

Sección encima del carrito:
- Default: "Consumidor Final" (sin contacto — ventas rápidas)
- Botón "Cambiar cliente" → abre ContactSearch
- Al seleccionar: muestra nombre, CUIT, condición IVA
- Determina y muestra tipo de factura que se va a emitir (A/B/C)
- Toggle "Emitir factura" (activado por defecto si el cliente NO es consumidor final)

### Tarea 3.3: Panel de cobro
**Archivo nuevo**: `src/components/pos/pos-payment-panel.tsx`

Se muestra al hacer click en "Cobrar" (puede ser un dialog o panel que reemplaza el carrito):

1. **Total a cobrar** (grande)
2. **Medios de pago**:
   - Botones grandes para cada medio: Efectivo, Débito, Crédito, Transferencia, QR (Qobra)
   - Al seleccionar uno: input de monto (pre-rellenado con total pendiente)
   - Se pueden agregar múltiples medios (ej: $5.000 efectivo + $3.000 débito)
   - Lista de medios agregados con monto
3. **Efectivo**: input de "Recibido", cálculo automático de vuelto
4. **Total pagado** vs **Total a cobrar**
5. **Botón "Confirmar venta"** (enabled solo si pagado >= total)
   - Loading state mientras procesa
   - Si falla ARCA → mostrar error y permitir reintentar

**Commit**: `feat(pos): add cart, client selector and payment panel`

---

## Etapa 4: Post-venta y caja diaria

### Tarea 4.1: Dialog de post-venta
**Archivo nuevo**: `src/components/pos/pos-sale-complete.tsx`

Dialog que se muestra después de confirmar la venta:
- "Venta completada ✓"
- Número de venta
- Si tiene factura: tipo + número + CAE
- Total cobrado, vuelto (si pagó en efectivo)
- Botones:
  - "Imprimir ticket" (window.print con formato de ticket)
  - "Descargar PDF" (si tiene factura)
  - "Nueva venta" (limpia todo y vuelve al POS)

### Tarea 4.2: Ticket de venta (print)
**Archivo nuevo**: `src/components/pos/pos-ticket-print.tsx`

Componente oculto que se muestra al imprimir (via CSS `@media print`):
- Formato ticket (ancho 80mm / 58mm — común en impresoras POS)
- Datos de la empresa
- Fecha y hora
- Items con cantidad, descripción, precio
- Total
- Medio de pago
- Si tiene factura: CAE y datos fiscales
- "Gracias por su compra"

### Tarea 4.3: Páginas de caja diaria
**Archivo nuevo**: `src/app/dashboard/cash-register/page.tsx`

Vista de tesorería:
- Si hay caja abierta: mostrar resumen (monto inicial, ventas del turno, total esperado)
- Botón "Cerrar caja" → dialog para ingresar monto real → muestra diferencia
- Si no hay caja abierta: botón "Abrir caja" → input de monto inicial
- Historial de cajas anteriores con resumen

### Tarea 4.4: Hook useCashRegister
**Archivo nuevo**: `src/hooks/use-cash-register.ts`

Hook:
- `currentRegister`: caja abierta actual
- `isOpen`: boolean
- `openRegister(amount)`: abre caja
- `closeRegister(closingAmount)`: cierra caja
- `registerHistory`: historial de cajas

**Commit**: `feat(pos): add post-sale dialog, ticket print, and cash register UI`

---

## Checklist de cierre de sesión

- [ ] POS con layout fullscreen
- [ ] Búsqueda de productos con soporte para scanner de códigos de barras
- [ ] Grilla de productos con categorías
- [ ] Carrito editable con cantidades, descuentos
- [ ] Selector de cliente con determinación automática de tipo de factura
- [ ] Panel de cobro con múltiples medios de pago
- [ ] Cálculo de vuelto para efectivo
- [ ] Flujo completo: buscar → agregar → cobrar → facturar → ticket
- [ ] Ticket imprimible (formato POS 80mm)
- [ ] Caja diaria: abrir, resumen, cerrar con arqueo
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
