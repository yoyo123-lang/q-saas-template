'use client'

import { Accordion } from '@/components/ui/accordion'

interface FaqItem {
  q: string
  a: string
}

interface AccordionFaqProps {
  items: FaqItem[]
}

export function AccordionFaq({ items }: AccordionFaqProps) {
  const accordionItems = items.map((item, i) => ({
    id: `faq-${i}`,
    title: item.q,
    content: item.a,
  }))

  return <Accordion items={accordionItems} />
}
