import { PrismaClient } from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'

// Singleton de Prisma — evita crear nuevas conexiones por cada request.
// Prisma v7 requiere un driver adapter para conectarse a la base de datos.
// prisma.config.ts solo aplica para CLI (generate, migrate).

type GlobalWithPrisma = typeof globalThis & { _prisma?: PrismaClient }

export function getPrisma(): PrismaClient {
  const g = globalThis as GlobalWithPrisma
  if (!g._prisma) {
    const connectionString = process.env.DATABASE_URL
    if (!connectionString) {
      throw new Error('DATABASE_URL is not set')
    }
    const adapter = new PrismaPg({ connectionString })
    g._prisma = new PrismaClient({ adapter })
  }
  return g._prisma
}
