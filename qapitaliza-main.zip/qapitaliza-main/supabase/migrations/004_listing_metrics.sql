-- ============================================================
-- 004 — Listing Metrics
-- Métricas verificables de cada activo, con fuente y evidencia.
-- Depende de: 003 (listings)
-- Rollback: 004_listing_metrics_rollback.sql
-- ============================================================

CREATE TYPE metric_type AS ENUM (
  'MONTHLY_REVENUE',
  'MONTHLY_TRAFFIC',
  'DOMAIN_AUTHORITY',
  'EMAIL_SUBSCRIBERS',
  'SOCIAL_FOLLOWERS'
);

CREATE TYPE metric_source AS ENUM (
  'SELF_REPORTED',        -- vendedor lo declara sin evidencia
  'SCREENSHOT',           -- captura de pantalla adjunta
  'ANALYTICS_CONNECTED',  -- conectado a Google Analytics u otra herramienta
  'QOBRA_VERIFIED'        -- verificado por Qobra (Fase 2+)
);

CREATE TABLE public.listing_metrics (
  id           UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id   UUID          NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  metric_type  metric_type   NOT NULL,
  value        NUMERIC(15, 2) NOT NULL,
  period       TEXT,                     -- Ej: "2026-02" (YYYY-MM) o "2025" para anual
  source       metric_source NOT NULL DEFAULT 'SELF_REPORTED',
  evidence_url TEXT,                     -- URL de captura o link público de analytics
  created_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

  -- Un tipo de métrica por período por listing
  UNIQUE (listing_id, metric_type, period)
);

COMMENT ON TABLE  public.listing_metrics              IS 'Métricas verificables del activo. Múltiples por listing.';
COMMENT ON COLUMN public.listing_metrics.period       IS 'Período al que corresponde la métrica. Formato YYYY-MM o YYYY.';
COMMENT ON COLUMN public.listing_metrics.evidence_url IS 'Link a captura o analytics público que respalda el valor.';
