import { type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'

const UUID_V4_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

const PREVIEW_HEADERS = {
  'Content-Type': 'text/html; charset=utf-8',
  'X-Frame-Options': 'SAMEORIGIN',
  'Content-Security-Policy': "default-src 'self' 'unsafe-inline' data:; img-src * data:;",
  'Cache-Control': 'private, no-cache',
}

type WebsiteContent = {
  html?: unknown
  css?: unknown
  copy?: {
    seo?: {
      title?: unknown
      description?: unknown
    }
  }
}

function injectSeoTags(html: string, seo: { title?: unknown; description?: unknown }): string {
  const title = typeof seo.title === 'string' ? seo.title : ''
  const description = typeof seo.description === 'string' ? seo.description : ''

  if (!title && !description) return html
  if (html.includes('<title>')) return html

  const seoBlock = [
    title ? `<title>${escapeHtml(title)}</title>` : '',
    description ? `<meta name="description" content="${escapeHtml(description)}" />` : '',
    title ? `<meta property="og:title" content="${escapeHtml(title)}" />` : '',
    description ? `<meta property="og:description" content="${escapeHtml(description)}" />` : '',
  ]
    .filter(Boolean)
    .join('\n    ')

  return html.replace('</head>', `    ${seoBlock}\n  </head>`)
}

function injectCssStyle(html: string, css: string): string {
  if (!css.trim()) return html
  if (html.includes('/* Qautiva generated */')) return html

  const styleBlock = `<style>/* Qautiva generated */\n${css}\n</style>`
  return html.replace('</head>', `  ${styleBlock}\n  </head>`)
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

function buildFinalHtml(html: string, content: WebsiteContent): string {
  if (!html.includes('<head>')) return html

  let result = html
  const seo = content.copy?.seo
  if (seo) {
    result = injectSeoTags(result, seo)
  }

  const css = typeof content.css === 'string' ? content.css : ''
  if (css) {
    result = injectCssStyle(result, css)
  }

  return result
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  if (!UUID_V4_REGEX.test(params.id)) {
    return new Response('Not found', { status: 404 })
  }

  const deliverable = await prisma.deliverable.findUnique({
    where: { id: params.id },
    select: { type: true, content: true },
  })

  if (!deliverable || deliverable.type !== 'WEBSITE_PREVIEW') {
    return new Response('Not found', { status: 404 })
  }

  const content = deliverable.content as WebsiteContent | null
  if (!content || typeof content.html !== 'string' || !content.html) {
    return new Response('Not found', { status: 404 })
  }

  const finalHtml = buildFinalHtml(content.html, content)

  // Registrar visita (fire-and-forget, Next.js 14 no soporta after())
  // Truncar headers para prevenir DoS por valores gigantes
  const MAX_UA_LEN = 500
  const MAX_REFERER_LEN = 500
  const rawUserAgent = request.headers.get('user-agent')
  const rawReferer = request.headers.get('referer')
  const userAgent = rawUserAgent ? rawUserAgent.slice(0, MAX_UA_LEN) : null
  const referer = rawReferer ? rawReferer.slice(0, MAX_REFERER_LEN) : null

  prisma.deliverableView.create({
    data: { deliverableId: params.id, userAgent, referer },
  }).catch((err: unknown) => console.error('[preview] error registrando visita:', err))

  return new Response(finalHtml, { headers: PREVIEW_HEADERS })
}
