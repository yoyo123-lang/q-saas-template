'use server'

import { getPrisma } from '@/lib/prisma'
import { trackEvent } from '@/lib/analytics/events'
import { checkRateLimit } from '@/lib/rate-limit'
import { sendNewInquiryEmail, sendNewMessageEmail } from '@/lib/notifications/email'
import { sendMessageSchema } from '@/lib/schemas/inquiry'
import { getAuthenticatedUser } from '@/lib/supabase/auth-helpers'
import type { ActionResult } from '@/lib/actions/listings'
import type { InquiryMessageData } from '@/lib/data/inquiries'

/** Max new inquiries a user can open per day */
const INQUIRY_DAILY_LIMIT = 10

/** Max messages a user can send per minute (anti-spam) */
const MESSAGE_PER_MINUTE_LIMIT = 20

/** Min gap between email notifications for the same inquiry+participant pair (ms) */
const EMAIL_THROTTLE_MS = 60 * 60 * 1000 // 1 hour

// Simple in-memory store to track last notification time per inquiry+participant.
// Known limitation: single-instance only (same as rate-limit store). See KNOWN_ISSUES.md.
const lastEmailSent = new Map<string, number>()

// ─── Helpers ─────────────────────────────────────────────────

function shouldSendEmail(key: string): boolean {
  const last = lastEmailSent.get(key)
  if (!last) return true
  return Date.now() - last > EMAIL_THROTTLE_MS
}

function markEmailSent(key: string): void {
  lastEmailSent.set(key, Date.now())
}

// ─── Actions ─────────────────────────────────────────────────

/**
 * Creates a new inquiry for a listing.
 *
 * Validations:
 * - Must be authenticated
 * - Cannot inquire on own listing (seller)
 * - Listing must be PUBLISHED
 * - No duplicate inquiry from same buyer on same listing (returns existing id)
 * - Rate limit: max 10 new inquiries per day per user
 */
export async function createInquiry(
  listingId: string
): Promise<ActionResult<{ inquiryId: string }>> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    const prisma = getPrisma()

    // Rate limiting: 10 new inquiries per 24h per user
    const rateLimit = checkRateLimit(`inquiry:${user.id}`, {
      limit: INQUIRY_DAILY_LIMIT,
      windowSeconds: 86400,
    })
    if (!rateLimit.success) {
      return {
        success: false,
        error: `Alcanzaste el límite de consultas diarias. Podés enviar más en ${Math.ceil(rateLimit.retryAfter / 3600)} hora(s).`,
      }
    }

    const listing = await prisma.listing.findUnique({
      where: { id: listingId },
      select: {
        id: true,
        title: true,
        status: true,
        sellerId: true,
        seller: { select: { email: true, fullName: true } },
      },
    })

    if (!listing) return { success: false, error: 'Activo no encontrado.' }

    // Cannot inquire on own listing
    if (listing.sellerId === user.id) {
      return { success: false, error: 'No podés consultar sobre tu propio activo.' }
    }

    // Listing must be published
    if (listing.status !== 'PUBLISHED') {
      return { success: false, error: 'Solo podés consultar activos publicados.' }
    }

    // Return existing inquiry if already created (idempotent)
    const existing = await prisma.inquiry.findUnique({
      where: { listingId_buyerId: { listingId, buyerId: user.id } },
      select: { id: true },
    })
    if (existing) {
      return { success: true, data: { inquiryId: existing.id } }
    }

    const inquiry = await prisma.inquiry.create({
      data: { listingId, buyerId: user.id, status: 'OPEN' },
    })

    void trackEvent('INQUIRY_SENT', 'inquiry', inquiry.id, user.id)

    // Notify seller (fire-and-forget)
    const buyerProfile = await prisma.profile.findUnique({
      where: { id: user.id },
      select: { fullName: true, email: true },
    })
    const buyerName = buyerProfile?.fullName ?? buyerProfile?.email ?? 'Un comprador'
    void sendNewInquiryEmail(listing.seller.email, listing.title, buyerName)

    return { success: true, data: { inquiryId: inquiry.id } }
  } catch (e) {
    console.error('[createInquiry]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al crear la consulta. Intentá de nuevo.' }
  }
}

/**
 * Sends a message in an existing inquiry.
 *
 * Validations:
 * - Must be authenticated
 * - User must be buyer OR seller of the inquiry (IDOR — invariant 6 from BUSINESS_MODEL)
 * - Inquiry must not be CLOSED
 * - Content: 1–5000 chars
 * - Rate limit: max 20 messages per minute per user (anti-spam)
 */
export async function sendMessage(
  inquiryId: string,
  content: string
): Promise<ActionResult<InquiryMessageData>> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    // Anti-spam rate limit for messages
    const rateLimit = checkRateLimit(`msg:${user.id}`, {
      limit: MESSAGE_PER_MINUTE_LIMIT,
      windowSeconds: 60,
    })
    if (!rateLimit.success) {
      return { success: false, error: 'Estás enviando mensajes muy rápido. Esperá un momento.' }
    }

    const parsed = sendMessageSchema.safeParse({ content: content.trim() })
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? 'Mensaje inválido.' }
    }

    const prisma = getPrisma()

    const inquiry = await prisma.inquiry.findUnique({
      where: { id: inquiryId },
      include: {
        listing: {
          select: {
            title: true,
            sellerId: true,
            seller: { select: { email: true, fullName: true } },
          },
        },
        buyer: { select: { id: true, email: true, fullName: true } },
      },
    })

    if (!inquiry) return { success: false, error: 'Consulta no encontrada.' }

    // Participant check — IDOR protection (invariant 6: only buyer or seller)
    const isBuyer = inquiry.buyerId === user.id
    const isSeller = inquiry.listing.sellerId === user.id
    if (!isBuyer && !isSeller) {
      return { success: false, error: 'No tenés permiso para participar en esta consulta.' }
    }

    // Cannot message in a closed inquiry
    if (inquiry.status === 'CLOSED') {
      return { success: false, error: 'Esta consulta está cerrada.' }
    }

    const message = await prisma.inquiryMessage.create({
      data: { inquiryId, senderId: user.id, content: parsed.data.content },
      include: {
        sender: { select: { id: true, fullName: true, email: true, role: true } },
      },
    })

    // Update inquiry status: OPEN → REPLIED when seller responds first time
    if (inquiry.status === 'OPEN' && isSeller) {
      await prisma.inquiry.update({
        where: { id: inquiryId },
        data: { status: 'REPLIED', updatedAt: new Date() },
      })
    } else {
      await prisma.inquiry.update({
        where: { id: inquiryId },
        data: { updatedAt: new Date() },
      })
    }

    void trackEvent('INQUIRY_REPLIED', 'inquiry', inquiryId, user.id)

    // Throttled email notification to the other participant
    const emailKey = `msg:${inquiryId}:${isBuyer ? 'seller' : 'buyer'}`
    if (shouldSendEmail(emailKey)) {
      markEmailSent(emailKey)
      const senderName = message.sender.fullName ?? message.sender.email
      if (isBuyer) {
        void sendNewMessageEmail(inquiry.listing.seller.email, inquiry.listing.title, senderName)
      } else {
        void sendNewMessageEmail(inquiry.buyer.email, inquiry.listing.title, senderName)
      }
    }

    return {
      success: true,
      data: {
        id: message.id,
        inquiryId: message.inquiryId,
        senderId: message.senderId,
        content: message.content,
        createdAt: message.createdAt,
        sender: message.sender as InquiryMessageData['sender'],
      },
    }
  } catch (e) {
    console.error('[sendMessage]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al enviar el mensaje. Intentá de nuevo.' }
  }
}

/**
 * Closes an inquiry.
 *
 * Per BUSINESS_MODEL.md regla 12: any participant (buyer, seller, or admin) can close.
 */
export async function closeInquiry(inquiryId: string): Promise<ActionResult> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.' }

    const prisma = getPrisma()

    const inquiry = await prisma.inquiry.findUnique({
      where: { id: inquiryId },
      select: {
        buyerId: true,
        status: true,
        listing: { select: { sellerId: true } },
      },
    })

    if (!inquiry) return { success: false, error: 'Consulta no encontrada.' }

    // Regla 12: buyer, seller, o admin pueden cerrar (BUSINESS_MODEL.md)
    const isBuyer = inquiry.buyerId === user.id
    const isSeller = inquiry.listing.sellerId === user.id
    const isParticipant = isBuyer || isSeller

    // For admin: check role in profile
    let isAdmin = false
    if (!isParticipant) {
      const profile = await prisma.profile.findUnique({
        where: { id: user.id },
        select: { role: true },
      })
      isAdmin = profile?.role === 'ADMIN'
    }

    if (!isParticipant && !isAdmin) {
      return { success: false, error: 'No tenés permiso para cerrar esta consulta.' }
    }

    if (inquiry.status === 'CLOSED') {
      return { success: false, error: 'La consulta ya está cerrada.' }
    }

    await prisma.inquiry.update({
      where: { id: inquiryId },
      data: { status: 'CLOSED', updatedAt: new Date() },
    })

    void trackEvent('INQUIRY_CLOSED', 'inquiry', inquiryId, user.id)

    return { success: true }
  } catch (e) {
    console.error('[closeInquiry]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al cerrar la consulta.' }
  }
}
