/**
 * Wrapper local de createServerClient para uso en Server Components y Route Handlers del portal.
 * Re-exporta desde @qautiva/db para no duplicar la lógica de configuración.
 *
 * IMPORTANTE: Solo importar en Server Components y Route Handlers.
 * Para Client Components usar lib/supabase-browser.ts
 */
export { createServerClient } from '@qautiva/db'
