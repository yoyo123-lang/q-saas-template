import { NextResponse, type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'
import { getProfileOrUnauthorized } from '@/lib/api/marketplace-helpers'

type ContactBody = {
  firstName: string
  lastName: string
  orgName?: string
  address1: string
  city: string
  state: string
  postalCode: string
  country: string
  phone: string
  email: string
}

type RegisterBody = {
  domain: string
  period?: number
  contact: ContactBody
}

function isValidEmail(email: string): boolean {
  // RFC 5321: mínimo local@domain donde domain tiene al menos un punto
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254
}

function isValidPhone(phone: string): boolean {
  // Debe empezar con +, seguido de al menos 7 dígitos
  return /^\+\d{7,15}$/.test(phone)
}

function validateContact(contact: ContactBody): string | null {
  const required: (keyof ContactBody)[] = [
    'firstName', 'lastName', 'address1', 'city',
    'state', 'postalCode', 'country', 'phone', 'email',
  ]
  for (const field of required) {
    if (!contact[field]?.trim()) {
      return `El campo ${field} es requerido`
    }
  }
  if (!isValidEmail(contact.email)) return 'El email no es válido'
  if (!isValidPhone(contact.phone)) return 'El teléfono debe comenzar con +'
  if (contact.country.length !== 2) return 'El país debe ser un código ISO de 2 letras'
  return null
}

function calcFinalPriceArs(
  registrationPriceUsd: { toString(): string },
  marginType: string,
  marginValue: { toString(): string },
  exchangeRate: number,
): number {
  const costUsd = Number(registrationPriceUsd.toString())
  const margin = Number(marginValue.toString())
  if (marginType === 'PERCENTAGE') {
    return (costUsd * exchangeRate) * (1 + margin / 100)
  }
  return (costUsd * exchangeRate) + margin
}

const ROLE_PRIORITY: Record<string, number> = { OWNER: 3, ADMIN: 2, MEMBER: 1 }

async function getTeamContext(profileId: string): Promise<{ teamId: string; teamRole: string } | null> {
  const userProfile = await prisma.userProfile.findUnique({
    where: { id: profileId },
    select: {
      teamMemberships: {
        select: { teamId: true, role: true },
      },
    },
  })
  if (!userProfile?.teamMemberships.length) return null
  // Tomar el membership con rol más alto
  const best = userProfile.teamMemberships.reduce((prev, curr) =>
    (ROLE_PRIORITY[curr.role] ?? 0) > (ROLE_PRIORITY[prev.role] ?? 0) ? curr : prev
  )
  return { teamId: best.teamId, teamRole: best.role }
}

/**
 * POST /api/domains/register
 *
 * Crea un registro de dominio en estado PENDING_PAYMENT.
 * El cron /api/cron/domains/process lo procesa contra OpenSRS cuando el pago se confirma.
 */
export async function POST(request: NextRequest) {
  const reqId = crypto.randomUUID()

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  const teamCtx = await getTeamContext(profile.id)
  if (!teamCtx) {
    return NextResponse.json({ error: 'No se encontró el team del usuario' }, { status: 404 })
  }
  const { teamId, teamRole } = teamCtx

  // Guard de permisos: solo ADMIN y OWNER pueden registrar dominios
  if (!(['ADMIN', 'OWNER'] as string[]).includes(teamRole)) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden registrar dominios.' },
      { status: 403 },
    )
  }

  let body: RegisterBody
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'El cuerpo de la solicitud no es JSON válido' }, { status: 400 })
  }

  const { domain, period, contact } = body

  if (!domain || typeof domain !== 'string') {
    return NextResponse.json({ error: 'El campo domain es requerido' }, { status: 400 })
  }
  const domainName = domain.trim().toLowerCase()
  if (!domainName.includes('.')) {
    return NextResponse.json({ error: 'El dominio debe incluir un TLD (ej: ejemplo.com)' }, { status: 400 })
  }

  const periodValue = period ?? 1
  if (!Number.isInteger(periodValue) || periodValue < 1 || periodValue > 10) {
    return NextResponse.json({ error: 'El período debe ser un número entero entre 1 y 10' }, { status: 400 })
  }

  if (!contact || typeof contact !== 'object') {
    return NextResponse.json({ error: 'Los datos de contacto son requeridos' }, { status: 400 })
  }
  const contactError = validateContact(contact)
  if (contactError) {
    return NextResponse.json({ error: contactError }, { status: 400 })
  }

  const tld = domainName.split('.').slice(1).join('.')

  const tldPricing = await prisma.tldPricing.findUnique({
    where: { tld },
    select: {
      registrationPriceUsd: true,
      marginType: true,
      marginValue: true,
      isActive: true,
    },
  })

  if (!tldPricing || !tldPricing.isActive) {
    return NextResponse.json({ error: 'El TLD solicitado no está disponible' }, { status: 400 })
  }

  const exchangeRate = parseFloat(process.env.EXCHANGE_RATE_USD_ARS ?? '1200')
  if (!isFinite(exchangeRate) || exchangeRate <= 0) {
    console.error('[POST /api/domains/register] EXCHANGE_RATE_USD_ARS inválido o no configurado', {
      rawValue: process.env.EXCHANGE_RATE_USD_ARS,
    })
    return NextResponse.json(
      { error: 'Error de configuración en precios. Contactá a soporte.' },
      { status: 500 },
    )
  }
  const finalPriceArs = calcFinalPriceArs(
    tldPricing.registrationPriceUsd,
    tldPricing.marginType,
    tldPricing.marginValue,
    exchangeRate,
  )

  const existing = await prisma.domain.findFirst({
    where: { domainName, deletedAt: null, status: { notIn: ['FAILED', 'CANCELLED'] } },
    select: { id: true, status: true },
  })
  if (existing) {
    return NextResponse.json(
      { error: 'El dominio ya está registrado o en proceso de registro.' },
      { status: 409 },
    )
  }

  const paidAmountArsRounded = Math.round(finalPriceArs)
  const costUsdNum = Number(tldPricing.registrationPriceUsd.toString())
  const revenueUsd = exchangeRate > 0
    ? Number((paidAmountArsRounded / exchangeRate - costUsdNum).toFixed(4))
    : null

  const newDomain = await prisma.domain.create({
    data: {
      teamId,
      domainName,
      tld,
      status: 'PENDING_PAYMENT',
      period: periodValue,
      costUsd: tldPricing.registrationPriceUsd,
      paidAmountArs: paidAmountArsRounded,
      exchangeRate,
      revenueUsd,
      registrantInfo: contact,
    },
    select: { id: true },
  })

  console.info('[POST /api/domains/register]', { reqId, domainName, teamId })

  return NextResponse.json({
    domainId: newDomain.id,
    domain: domainName,
    priceArs: paidAmountArsRounded,
  })
}
