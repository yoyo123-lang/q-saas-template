import Link from 'next/link'
import { Avatar } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { inquiryStatusVariant, inquiryStatusLabel, getParticipantInitials } from './inquiry-shared'
import type { InquiryListItem, InquiryParticipant } from '@/lib/data/inquiries'

function formatRelativeTime(date: Date): string {
  const diff = Date.now() - new Date(date).getTime()
  const minutes = Math.floor(diff / 60000)
  if (minutes < 1) return 'ahora'
  if (minutes < 60) return `hace ${minutes}m`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `hace ${hours}h`
  const days = Math.floor(hours / 24)
  return `hace ${days}d`
}

interface InquiryCardProps {
  inquiry: InquiryListItem
  /** ID of the current user — used to determine which participant to show */
  currentUserId: string
}

export function InquiryCard({ inquiry, currentUserId }: InquiryCardProps) {
  const isBuyer = inquiry.buyerId === currentUserId
  // Show the other participant
  const otherParticipant: InquiryParticipant = isBuyer
    ? ({
        id: inquiry.listing.sellerId,
        fullName: null, // not loaded in list view
        email: 'Vendedor',
        role: 'SELLER' as const,
      } satisfies InquiryParticipant)
    : inquiry.buyer

  const isUnread = inquiry.status === 'OPEN' && !isBuyer

  return (
    // Use div + role="link" to avoid nested <a> elements (inquiry title link inside)
    // Navigation handled by the outer div's onClick and the inner Link for the listing
    <div
      className={[
        'flex items-start gap-4 p-5 rounded-xl border transition-colors',
        'bg-navy-900 hover:bg-slate-800',
        isUnread ? 'border-l-4 border-l-amber-500 border-slate-800' : 'border-slate-800',
      ].join(' ')}
    >
      <Avatar
        initials={getParticipantInitials(otherParticipant)}
        role={otherParticipant.role}
        size="md"
        className="mt-0.5 flex-shrink-0"
      />

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap mb-1">
          <span className="text-sm font-medium text-slate-50">
            {otherParticipant.fullName ?? otherParticipant.email}
          </span>
          <span className="text-slate-600">·</span>
          {/* Link to the listing — standalone link, no nesting issue */}
          <Link
            href={`/explorar/${inquiry.listing.slug}`}
            className="text-sm text-amber-500 hover:underline truncate max-w-[200px]"
          >
            {inquiry.listing.title}
          </Link>
        </div>

        {inquiry.lastMessage ? (
          <p className="text-sm text-slate-400 truncate leading-snug">
            {inquiry.lastMessage.senderId === currentUserId && (
              <span className="text-slate-500 mr-1">Vos:</span>
            )}
            {inquiry.lastMessage.content}
          </p>
        ) : (
          <p className="text-sm text-slate-500 italic">Sin mensajes aún</p>
        )}
      </div>

      <div className="flex flex-col items-end gap-2 flex-shrink-0">
        <span className="text-xs text-slate-500">
          {formatRelativeTime(inquiry.lastMessage?.createdAt ?? inquiry.createdAt)}
        </span>
        <Badge variant={inquiryStatusVariant[inquiry.status] ?? 'muted'}>
          {inquiryStatusLabel[inquiry.status] ?? inquiry.status}
        </Badge>
        {/* Navigate to chat via a dedicated link (avoids nested <a> anti-pattern) */}
        <Link
          href={`/consultas/${inquiry.id}`}
          className="text-xs text-amber-500 hover:underline mt-1"
        >
          Ver consulta →
        </Link>
      </div>
    </div>
  )
}
