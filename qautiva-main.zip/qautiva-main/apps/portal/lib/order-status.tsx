import { OrderStatus } from '@qautiva/db'

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  PENDING: 'Pendiente',
  ACCEPTED: 'Aceptado',
  DELIVERED: 'Entregado',
  IN_REVIEW: 'En revisión',
  REVISION: 'Con correcciones',
  COMPLETED: 'Completado',
  CANCELLED: 'Cancelado',
  DISPUTED: 'En disputa',
}

export const ORDER_STATUS_COLOR: Record<OrderStatus, string> = {
  PENDING: 'bg-[#2D2A0F] text-yellow-400',
  ACCEPTED: 'bg-[#0F2942] text-[#93C5FD]',
  DELIVERED: 'bg-[#1E3A5F] text-[#60A5FA]',
  IN_REVIEW: 'bg-[#2D2A0F] text-yellow-400',
  REVISION: 'bg-[#3B2A0F] text-orange-400',
  COMPLETED: 'bg-[#0F2E2A] text-[#34D399]',
  CANCELLED: 'bg-[#1E293B] text-[#64748B]',
  DISPUTED: 'bg-[#3B1414] text-red-400',
}

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${ORDER_STATUS_COLOR[status]}`}>
      {ORDER_STATUS_LABEL[status]}
    </span>
  )
}
