import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import crypto from 'crypto'

function sanitizeNext(next: string | null): string {
  if (next && next.startsWith('/') && !next.startsWith('//')) return next
  return '/dashboard'
}

function getGoogleClientId(): string {
  const id = process.env.GOOGLE_CLIENT_ID
  if (!id) {
    throw new Error(
      '[config] Variable de entorno requerida no está configurada: "GOOGLE_CLIENT_ID". ' +
        'Agregala a .env.local.'
    )
  }
  return id
}

/**
 * Inicia el flujo OAuth con Google usando nuestra propia redirect_uri.
 * De esta forma el account chooser de Google muestra el dominio de la app,
 * no el de Supabase.
 *
 * GET /api/auth/google?next=/ruta-destino
 */
export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const next = sanitizeNext(requestUrl.searchParams.get('next'))

  const state = crypto.randomBytes(32).toString('hex')
  const redirectUri = `${requestUrl.origin}/auth/callback`

  const cookieStore = await cookies()
  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax' as const,
    maxAge: 60 * 10, // 10 minutos
    path: '/',
  }
  cookieStore.set('oauth_state', state, cookieOptions)
  cookieStore.set('oauth_next', next, cookieOptions)

  const params = new URLSearchParams({
    client_id: getGoogleClientId(),
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    access_type: 'online',
  })

  return NextResponse.redirect(
    `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`
  )
}
