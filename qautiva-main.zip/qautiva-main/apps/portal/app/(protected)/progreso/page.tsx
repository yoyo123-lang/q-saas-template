import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import Link from 'next/link'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import type { StageStatus, DeliverableStatus } from '@qautiva/db'

export const metadata: Metadata = { title: 'Mi progreso — Qautiva' }
import { StageProgress } from '@/components/StageProgress'
import { ActionCard } from '@/components/ActionCard'

const STAGE_LABELS = [
  'Tu negocio',
  'Mercado',
  'Marca',
  'Web',
  'Campañas',
  'Medios',
]

const COMPLETED_STATUSES: DeliverableStatus[] = ['CLIENT_APPROVED']
const NEEDS_ACTION_STATUSES: DeliverableStatus[] = ['SENT_TO_CLIENT']

function toVisualStatus(
  stageStatus: StageStatus,
  index: number,
  activeStageIndex: number,
): 'completed' | 'active' | 'pending' {
  if (stageStatus === 'COMPLETED') return 'completed'
  if (index === activeStageIndex) return 'active'
  return 'pending'
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })
}

type CompletedItem = {
  id: string
  title: string
  approvedDate: string
  viewHref: string
}

function CompletedItemRow({ item }: { item: CompletedItem }) {
  return (
    <div className="flex items-center gap-3 bg-[#0F172A] px-4 py-3 rounded-lg">
      <div className="w-5 h-5 rounded-full bg-[#10B981]/15 flex items-center justify-center flex-shrink-0">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true">
          <path
            d="M1.5 5L4 7.5L8.5 2.5"
            stroke="#10B981"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <span className="text-white text-sm font-medium flex-1">{item.title}</span>
      <span className="text-[#64748B] text-xs">{item.approvedDate}</span>
      <Link
        href={item.viewHref}
        className="text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors duration-200"
      >
        Ver
      </Link>
    </div>
  )
}

export default async function ProgresoPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  const orgId = user?.app_metadata?.org_id as string | undefined

  if (!orgId) {
    return (
      <div className="p-8 max-w-3xl">
        <h1 className="text-2xl font-bold text-white mb-4">Mi progreso</h1>
        <p className="text-[#94A3B8]">No hay un proyecto asignado a tu cuenta.</p>
      </div>
    )
  }

  const [stages, deliverables] = await Promise.all([
    prisma.stage.findMany({
      where: { organizationId: orgId },
      orderBy: { number: 'asc' },
      select: { id: true, number: true, name: true, status: true },
    }),
    prisma.deliverable.findMany({
      where: { organizationId: orgId },
      orderBy: { updatedAt: 'desc' },
      select: { id: true, title: true, status: true, stageId: true, updatedAt: true },
    }),
  ])

  const activeIndex = stages.findIndex((s) => s.status !== 'COMPLETED')
  const activeStageIndex = activeIndex === -1 ? stages.length - 1 : activeIndex

  const visualStages = stages.map((s, i) => ({
    number: s.number,
    label: STAGE_LABELS[s.number - 1] ?? s.name,
    status: toVisualStatus(s.status, i, activeStageIndex),
  }))

  const completedItems: CompletedItem[] = deliverables
    .filter((d) => COMPLETED_STATUSES.includes(d.status))
    .map((d) => ({
      id: d.id,
      title: d.title,
      approvedDate: `Aprobado ${formatDate(d.updatedAt)}`,
      viewHref: `/entregables/${d.id}`,
    }))

  const pendingDeliverable = deliverables.find((d) =>
    NEEDS_ACTION_STATUSES.includes(d.status),
  )

  const activeStage = stages[activeStageIndex]
  const activeStageLabel = activeStage
    ? `Etapa ${activeStage.number} — ${STAGE_LABELS[activeStage.number - 1] ?? activeStage.name}`
    : null

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold text-white mb-6">Mi progreso</h1>

      {visualStages.length > 0 ? (
        <>
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 mb-6">
            <StageProgress stages={visualStages} />
          </div>

          {activeStageLabel && (
            <div className="mb-6">
              {pendingDeliverable ? (
                <ActionCard
                  stageTitle={activeStageLabel}
                  badge={{ label: 'Esperando tu aprobación', variant: 'warning' }}
                  description="Hay un entregable listo para que lo revises y apruebes. Tu opinión es clave para avanzar."
                  actionLabel="Ver entregable"
                  actionHref={`/entregables/${pendingDeliverable.id}`}
                />
              ) : (
                <ActionCard
                  stageTitle={activeStageLabel}
                  badge={{ label: 'En proceso', variant: 'in-progress' }}
                  description={`Estamos trabajando en tu ${STAGE_LABELS[activeStageIndex] ?? 'etapa'}. Te avisamos cuando esté listo para revisar.`}
                />
              )}
            </div>
          )}

          {completedItems.length > 0 && (
            <div>
              <h2 className="text-[#94A3B8] text-sm font-medium mb-3">Etapas completadas</h2>
              <div className="flex flex-col gap-2">
                {completedItems.map((item) => (
                  <CompletedItemRow key={item.id} item={item} />
                ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">
            Tu proceso todavía no arrancó. Pronto vas a ver el progreso acá.
          </p>
        </div>
      )}
    </div>
  )
}
