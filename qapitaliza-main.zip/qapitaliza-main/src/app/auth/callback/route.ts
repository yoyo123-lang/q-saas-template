import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { createClient } from '@/lib/supabase/server'

/**
 * Validates a redirect path to prevent open redirect attacks.
 * Blocks protocol-relative URLs like //evil.com that pass startsWith('/').
 */
function sanitizeRedirect(next: string | null): string {
  if (next && next.startsWith('/') && !next.startsWith('//')) {
    return next
  }
  return '/dashboard'
}

/**
 * Exchanges a Google authorization code for an id_token via Google's token endpoint.
 * Requires GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET env vars.
 */
async function exchangeGoogleCode(code: string, redirectUri: string): Promise<string> {
  const clientId = process.env.GOOGLE_CLIENT_ID
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET
  if (!clientId || !clientSecret) {
    throw new Error('Google OAuth credentials (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET) not configured')
  }

  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }),
  })

  if (!response.ok) {
    throw new Error(`Google token exchange failed: ${response.status}`)
  }

  const tokens = await response.json()
  if (!tokens.id_token) throw new Error('No id_token in Google response')
  return tokens.id_token as string
}

export async function GET(request: Request) {
  const url = new URL(request.url)
  const code = url.searchParams.get('code')
  const state = url.searchParams.get('state')
  const next = url.searchParams.get('next')

  if (!code) {
    return NextResponse.redirect(new URL('/login?error=oauth', url.origin))
  }

  const cookieStore = await cookies()
  const savedState = cookieStore.get('oauth_state')?.value
  const savedNext = cookieStore.get('oauth_next')?.value ?? null

  // --- Flujo Google OAuth directo (state cookie coincide) ---
  if (state && savedState && state === savedState) {
    cookieStore.delete('oauth_state')
    cookieStore.delete('oauth_next')

    try {
      const idToken = await exchangeGoogleCode(code, `${url.origin}/auth/callback`)
      const supabase = await createClient()
      const { data: { session }, error } = await supabase.auth.signInWithIdToken({
        provider: 'google',
        token: idToken,
      })

      if (!error && session) {
        // Prevent role spoofing: OAuth users cannot have ADMIN role.
        // ADMIN accounts must be provisioned server-side, not via OAuth flow.
        if (session.user.user_metadata?.role === 'ADMIN') {
          await supabase.auth.updateUser({ data: { role: 'BUYER' } })
        }
        return NextResponse.redirect(new URL(sanitizeRedirect(savedNext), url.origin))
      }
    } catch {
      // fall through to error redirect
    }

    return NextResponse.redirect(new URL('/login?error=oauth', url.origin))
  }

  // --- Flujo Supabase PKCE (confirmación de email, reset de contraseña, etc.) ---
  const supabase = await createClient()
  const { data: { session }, error } = await supabase.auth.exchangeCodeForSession(code)
  if (!error && session) {
    if (session.user.user_metadata?.role === 'ADMIN') {
      await supabase.auth.updateUser({ data: { role: 'BUYER' } })
    }
    return NextResponse.redirect(new URL(sanitizeRedirect(next), url.origin))
  }

  return NextResponse.redirect(new URL('/login?error=oauth', url.origin))
}
