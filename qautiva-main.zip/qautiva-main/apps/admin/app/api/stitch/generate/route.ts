import { NextRequest, NextResponse } from 'next/server'
import { waitUntil } from '@vercel/functions'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { generateTemplate } from '@qautiva/stitch'
import { processStitchHtml, validateHandlebarsCompilation } from '@qautiva/stitch'

export const maxDuration = 300

interface GenerateBody {
  industry: string
  sections: string[]
  prompt: string
  /** Si se provee, regenera un template existente. Si no, crea un draft nuevo. */
  templateId?: string
}

function isValidUUID(id: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
}

const LOCK_TIMEOUT_MS = 5 * 60 * 1000 // 5 minutos

/**
 * Corre la generación en background (después de enviar la respuesta 202).
 * Actualiza el WebTemplate con el resultado o limpia el lock en caso de error.
 */
async function runGeneration(
  templateId: string,
  params: { industry: string; sections: string[]; prompt: string },
): Promise<void> {
  const { industry, sections, prompt } = params
  try {
    const result = await generateTemplate({ industry, sections, prompt })
    const { html, css, thumbnailUrl, stitchProjectId, stitchScreenId } = result

    const processResult = processStitchHtml(html, sections)
    if (!processResult.success) {
      await prisma.webTemplate.update({
        where: { id: templateId },
        data: { generatingAt: null, queueError: `processStitchHtml:${processResult.reason}` },
      })
      console.error(`[stitch:generate] processStitchHtml failed (${templateId}): ${processResult.reason}`)
      console.error(`[stitch:generate] HTML snippet (${templateId}): ${html.slice(0, 500)}`)
      return
    }

    const validationResult = validateHandlebarsCompilation(processResult.processedHtml)
    if (!validationResult.valid) {
      await prisma.webTemplate.update({
        where: { id: templateId },
        data: { generatingAt: null, queueError: `handlebars:${validationResult.error?.slice(0, 500) ?? 'unknown'}` },
      })
      console.error(`[stitch:generate] Handlebars validation failed (${templateId}): ${validationResult.error}`)
      return
    }

    await prisma.webTemplate.update({
      where: { id: templateId },
      data: {
        source: 'STITCH',
        stitchProjectId,
        stitchScreenId,
        htmlBase: processResult.processedHtml,
        css,
        thumbnail: thumbnailUrl,
        generationPrompt: prompt,
        variables: processResult.extractedVariables,
        sections: processResult.detectedSections,
        generatingAt: null,
      },
    })
  } catch (err) {
    await prisma.webTemplate
      .update({
        where: { id: templateId },
        data: { generatingAt: null, queueError: (err instanceof Error ? err.message : String(err)).slice(0, 500) },
      })
      .catch(() => {})
    console.error('[stitch:generate] background error', err instanceof Error ? err.message : String(err))
  }
}

/**
 * POST /api/stitch/generate
 *
 * Inicia la generación de un template con Stitch de forma asíncrona.
 * Responde 202 inmediatamente con {templateId} y corre la generación en background.
 * El cliente hace polling a GET /api/stitch/generate/status?templateId=X para ver el resultado.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: GenerateBody
  try {
    body = (await req.json()) as GenerateBody
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { industry, sections, prompt, templateId } = body

  if (!industry || !industry.trim()) {
    return NextResponse.json({ error: 'industry es requerido' }, { status: 400 })
  }
  if (!prompt || !prompt.trim()) {
    return NextResponse.json({ error: 'prompt es requerido' }, { status: 400 })
  }
  if (!Array.isArray(sections)) {
    return NextResponse.json({ error: 'sections debe ser un array' }, { status: 400 })
  }
  if (templateId !== undefined && !isValidUUID(templateId)) {
    return NextResponse.json({ error: 'templateId debe ser un UUID válido' }, { status: 400 })
  }

  let jobTemplateId: string

  if (templateId) {
    // Regenerar template existente
    const existing = await prisma.webTemplate.findUnique({
      where: { id: templateId },
      select: { id: true, generatingAt: true },
    })

    if (!existing) {
      return NextResponse.json({ error: 'Template no encontrado' }, { status: 404 })
    }

    if (existing.generatingAt !== null) {
      const lockAge = Date.now() - existing.generatingAt.getTime()
      if (lockAge < LOCK_TIMEOUT_MS) {
        return NextResponse.json({ error: 'Generación ya en progreso' }, { status: 409 })
      }
    }

    await prisma.webTemplate.update({
      where: { id: templateId },
      data: { generatingAt: new Date(), queueError: null },
    })

    jobTemplateId = templateId
  } else {
    // Crear draft nuevo para esta generación
    const draft = await prisma.webTemplate.create({
      data: {
        name: `__draft__${crypto.randomUUID()}`,
        compatibleIndustries: [industry],
        sections: {},
        generatingAt: new Date(),
      },
    })
    jobTemplateId = draft.id
  }

  // Lanzar generación en background — se ejecuta después de enviar la respuesta
  waitUntil(runGeneration(jobTemplateId, { industry, sections, prompt }))

  return NextResponse.json({ templateId: jobTemplateId, status: 'generating' }, { status: 202 })
}
