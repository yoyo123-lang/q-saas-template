import { randomUUID } from 'crypto'
import { prisma, Prisma, type UsageSource } from '@qautiva/db'
import { generateAdCreatives } from './ad-creative-generator'
import { generateAdVisuals, regenerateAdVisual } from './ad-visual-generator'
import { validateAdVisuals, applyValidationScores } from './ad-visual-validator'
import { type BillingContext } from './ai-tool-call'
import { generateBrandOptions } from './brand-generator'
import { generateStrategicBrief } from './brief-generator'
import { generateCampaignPlan } from './campaign-strategy-generator'
import { generateMarketStudy } from './market-study-generator'
import type { BrandOptions, MarketStudy, QuestionBlock, StrategicBrief } from './types'
import { generateWebsiteCopy, applyWebsiteCopy } from './website-generator'
import { personalizeWithStitch } from './stitch-personalizer'
import { getRequiredSections } from './section-mapper'
import { checkBillingEligibility } from '../billing/check-eligibility'

export type SessionToProcess = {
  id: string
  flowDefinition: Prisma.JsonValue
  answers: Prisma.JsonValue
  stageId: string
  stageKey: string
  projectId: string
  teamId: string | null
  retryCount: number
  maxRetries: number
  selectedWebTemplateId: string | null
  project: {
    brandKit: unknown | null
  } | null
}

/**
 * Determina la fuente de consumo de IA según el plan del equipo.
 * Usado para construir el BillingContext antes de llamar a los generators.
 */
async function resolveUsageSource(teamId: string | null): Promise<UsageSource> {
  if (!teamId) return 'TRIAL'
  try {
    const billing = await prisma.billingAccount.findUnique({
      where: { teamId },
      select: { plan: true, preferredKeySource: true },
    })
    if (!billing) return 'TRIAL'
    if (billing.plan === 'FREE_TRIAL') return 'TRIAL'
    if (billing.preferredKeySource === 'BYOK') return 'BYOK'
    return 'QAUTIVA_HOSTED'
  } catch (err) {
    console.error('CRITICAL: [session-processor] No se pudo resolver usageSource — abortando sesión.', {
      teamId,
      error: err instanceof Error ? err.message : String(err),
    })
    throw err
  }
}

/**
 * Genera el Preview del Sitio Web para una sesión WEBSITE y la transiciona a COMPLETED.
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
async function processWebsiteSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  if (!session.selectedWebTemplateId) {
    console.error(`[${logPrefix}] website session missing selectedWebTemplateId`, { sessionId: session.id })
    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: { status: 'ERROR', lastError: 'No hay template web seleccionado' },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}] CRITICAL: failed to mark session as ERROR`, { sessionId: session.id, dbError: dbErr instanceof Error ? dbErr.message : String(dbErr) })
    }
    return false
  }

  const webTemplate = await prisma.webTemplate.findUnique({
    where: { id: session.selectedWebTemplateId },
    select: { name: true, htmlBase: true, variables: true, sections: true, css: true, source: true, stitchProjectId: true, stitchScreenId: true },
  })

  if (!webTemplate) {
    console.error(`[${logPrefix}] webTemplate not found`, {
      sessionId: session.id,
      templateId: session.selectedWebTemplateId,
    })
    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: { status: 'ERROR', lastError: 'Template web no encontrado' },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}] CRITICAL: failed to mark session as ERROR`, { sessionId: session.id, dbError: dbErr instanceof Error ? dbErr.message : String(dbErr) })
    }
    return false
  }

  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const answers = (session.answers ?? {}) as Record<string, unknown>
  const brandKit = (session.project?.brandKit ?? null) as Record<string, unknown> | null

  // Cargar deliverables de etapas anteriores para enriquecer el contexto del copywriter
  let previousDeliverables: Array<{ type: string; content: unknown }> = []
  try {
    previousDeliverables = await prisma.deliverable.findMany({
      where: {
        projectId: session.projectId,
        isActive: true,
        type: { in: ['BRIEF', 'MARKET_STUDY', 'BRAND_OPTIONS'] },
      },
      select: { type: true, content: true },
      orderBy: { createdAt: 'desc' },
    })
    // Deduplicar: si hay múltiples activos del mismo tipo, tomar solo el más reciente
    // (ya ordenados por createdAt desc)
    const seen = new Set<string>()
    previousDeliverables = previousDeliverables.filter((d) => {
      if (seen.has(d.type)) return false
      seen.add(d.type)
      return true
    })
  } catch (err) {
    console.warn(`[${logPrefix}][WEBSITE] No se pudieron cargar deliverables anteriores — continuando sin ellos`, {
      sessionId: session.id,
      error: err instanceof Error ? err.message : String(err),
    })
  }

  // Detectar sesión v2 y derivar secciones activas desde respuestas
  const isV2 = flowDefinition.some((q) => q.id.startsWith('web_'))
  const activeSections = isV2
    ? getRequiredSections(answers as Record<string, string>)
    : undefined

  console.info(`[${logPrefix}][WEBSITE] context loaded`, {
    sessionId: session.id,
    isV2,
    activeSections: activeSections ?? 'n/a (v1)',
    previousDeliverablesCount: previousDeliverables.length,
    previousDeliverablesTypes: previousDeliverables.map((d) => d.type),
  })

  const source = await resolveUsageSource(session.teamId)
  const billingContext: BillingContext = {
    teamId: session.teamId,
    projectId: session.projectId,
    source,
    operation: 'website_copy',
  }

  let copy
  try {
    copy = await generateWebsiteCopy({
      flowDefinition,
      answers,
      webTemplate: {
        name: webTemplate.name,
        htmlBase: webTemplate.htmlBase ?? null,
        variables: (webTemplate.variables ?? null) as Record<string, string> | null,
        sections: (webTemplate.sections ?? {}) as Record<string, boolean>,
        css: webTemplate.css ?? null,
      },
      brandKit,
      previousDeliverables: previousDeliverables.length > 0 ? previousDeliverables : undefined,
      activeSections,
      billingContext,
    })
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}] website copy generation failed`, { sessionId: session.id, error: errorMsg })

    // Errores de validación del output del modelo ([website-generator]) no mejoran con retry
    // porque los inputs son los mismos. Ir directo a ERROR para no dejar la sesión stuck.
    const isValidationError = errorMsg.includes('[website-generator]')
    const newRetryCount = session.retryCount + 1
    const exhausted = isValidationError || newRetryCount >= session.maxRetries

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? {
              status: 'ERROR',
              lastError: errorMsg.slice(0, 500),
              retryCount: newRetryCount,
            }
          : {
              lastError: errorMsg.slice(0, 500),
              retryCount: newRetryCount,
              // null permite al cron/usuario reclamar el lock inmediatamente para reintentar
              processingStartedAt: null,
            },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}] CRITICAL: failed to update session after generation error — session may be stuck in PROCESSING`, {
        sessionId: session.id,
        originalError: errorMsg,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  if (!webTemplate.htmlBase) {
    console.warn(`[${logPrefix}] webTemplate.htmlBase es null — el deliverable tendrá HTML vacío`, {
      sessionId: session.id,
      templateId: session.selectedWebTemplateId,
    })
  }
  // Extraer datos de contacto de las respuestas tpl_* para inyectar en el template
  const contactAnswers: Record<string, string> = {}
  for (const [tplKey, varKey] of [['tpl_whatsapp', 'whatsapp'], ['tpl_email', 'email'], ['tpl_redes', 'redes']] as const) {
    const val = answers[tplKey]
    if (typeof val === 'string' && val.trim()) contactAnswers[varKey] = val.trim()
  }

  // ── Bifurcación STITCH vs MANUAL ─────────────────────────────────────────────
  // La bifurcación se hace aquí (NO en applyWebsiteCopy) para no romper tests existentes.
  let filledHtml = ''
  let usedStitchFallback = false

  const isStitchTemplate = webTemplate.source === 'STITCH' && !!webTemplate.stitchProjectId

  if (isStitchTemplate) {
    // Construir businessData para Stitch a partir de las respuestas y el brandKit
    const businessName = (brandKit && typeof brandKit['businessName'] === 'string')
      ? brandKit['businessName']
      : webTemplate.name
    const businessServices = (() => {
      // Intentar extraer servicios de las respuestas o del copy
      const servicesSection = copy.sections['services']
      if (servicesSection?.items) return servicesSection.items.map(i => i.title)
      const answeredServices = answers['services'] ?? answers['tpl_services']
      if (typeof answeredServices === 'string') return [answeredServices]
      if (Array.isArray(answeredServices)) return answeredServices.filter((s): s is string => typeof s === 'string')
      return []
    })()

    try {
      console.info(`[${logPrefix}][WEBSITE] usando Stitch para personalización`, {
        sessionId: session.id,
        stitchProjectId: webTemplate.stitchProjectId,
      })
      const stitchResult = await personalizeWithStitch(
        {
          source: webTemplate.source,
          stitchProjectId: webTemplate.stitchProjectId,
          stitchScreenId: webTemplate.stitchScreenId,
          htmlBase: webTemplate.htmlBase,
          name: webTemplate.name,
        },
        brandKit,
        {
          name: businessName,
          services: businessServices,
        },
      )
      filledHtml = stitchResult.html
      console.info(`[${logPrefix}][WEBSITE] Stitch personalization OK`, { sessionId: session.id, htmlSize: filledHtml.length })
    } catch (stitchErr) {
      // Fallback a Handlebars si Stitch falla
      usedStitchFallback = true
      const stitchErrMsg = stitchErr instanceof Error ? stitchErr.message : String(stitchErr)
      console.warn(`[${logPrefix}][WEBSITE] Stitch falló — fallback a Handlebars`, {
        sessionId: session.id,
        error: stitchErrMsg,
      })
      filledHtml = webTemplate.htmlBase
        ? applyWebsiteCopy(webTemplate.htmlBase, copy, brandKit, activeSections, Object.keys(contactAnswers).length > 0 ? contactAnswers : undefined)
        : ''
    }
  } else {
    // Flujo MANUAL: igual que antes, sin cambios
    filledHtml = webTemplate.htmlBase
      ? applyWebsiteCopy(webTemplate.htmlBase, copy, brandKit, activeSections, Object.keys(contactAnswers).length > 0 ? contactAnswers : undefined)
      : ''
  }

  try {
    await prisma.$transaction(async (tx) => {
      const newDeliverableId = randomUUID()

      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          id: newDeliverableId,
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'WEBSITE_PREVIEW',
          title: 'Preview del sitio web',
          content: {
            html: filledHtml,
            css: webTemplate.css ?? '',
            copy,
            templateId: session.selectedWebTemplateId,
            previewUrl: `/api/preview/${newDeliverableId}`,
            // Badge de fallback: visible en admin cuando Stitch falló y se usó Handlebars
            ...(usedStitchFallback ? { usedStitchFallback: true } : {}),
          } as unknown as Prisma.InputJsonValue,
          status: 'SENT_TO_CLIENT',
          isActive: true,
        },
      })
      await tx.interviewSession.update({
        where: { id: session.id, status: 'PROCESSING' },
        data: { status: 'COMPLETED', completedAt: new Date(), lastError: null },
      })
    })
    console.info(`[${logPrefix}][WEBSITE] session completed successfully`, { sessionId: session.id })
    return true
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      // P2025 = el WHERE status='PROCESSING' no matcheó — otro actor cambió el estado.
      // Verificar el estado real para distinguir "ya completada" (ok) de "pasó a ERROR" (fallo).
      const current = await prisma.interviewSession.findUnique({
        where: { id: session.id },
        select: { status: true },
      })
      if (current?.status === 'COMPLETED') return true
      console.error(`[${logPrefix}] transaction failed: session no longer PROCESSING`, {
        sessionId: session.id,
        currentStatus: current?.status,
      })
      return false
    }
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][WEBSITE] transaction failed`, {
      sessionId: session.id,
      error: errorMsg,
    })
    try {
      const newRetryCount = session.retryCount + 1
      const exhausted = newRetryCount >= session.maxRetries
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount }
          : { lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][WEBSITE] CRITICAL: failed to update session after transaction error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }
}

/**
 * Genera el Estudio de Mercado para una sesión RESEARCH y la transiciona a COMPLETED.
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
async function processResearchSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  console.info(`[${logPrefix}][RESEARCH] starting market study generation`, { sessionId: session.id, projectId: session.projectId })

  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const answers = (session.answers ?? {}) as Record<string, unknown>

  // Cargar el Brief de etapa 1 como contexto (puede no existir aún)
  let briefContent: StrategicBrief | null = null
  try {
    const briefDeliverable = await prisma.deliverable.findFirst({
      where: { projectId: session.projectId, type: 'BRIEF', isActive: true },
      select: { content: true },
      orderBy: { createdAt: 'desc' },
    })
    if (briefDeliverable?.content) {
      briefContent = briefDeliverable.content as unknown as StrategicBrief
    }
  } catch (err) {
    console.warn(`[${logPrefix}][RESEARCH] No se pudo cargar Brief de etapa 1 — continuando sin él`, {
      sessionId: session.id,
      projectId: session.projectId,
      error: err instanceof Error ? err.message : String(err),
    })
  }

  const source = await resolveUsageSource(session.teamId)
  const billingContext: BillingContext = {
    teamId: session.teamId,
    projectId: session.projectId,
    source,
    operation: 'market_study',
  }

  let study
  try {
    study = await generateMarketStudy(flowDefinition, answers, briefContent, billingContext)
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][RESEARCH] market study generation failed`, { sessionId: session.id, projectId: session.projectId, error: errorMsg })

    const newRetryCount = session.retryCount + 1
    const exhausted = newRetryCount >= session.maxRetries

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: errorMsg.slice(0, 500), retryCount: newRetryCount }
          : { lastError: errorMsg.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][RESEARCH] CRITICAL: failed to update session after generation error — session may be stuck in PROCESSING`, {
        sessionId: session.id,
        originalError: errorMsg,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'MARKET_STUDY',
          title: 'Estudio de mercado',
          content: study as unknown as Prisma.InputJsonValue,
          status: 'SENT_TO_CLIENT',
          isActive: true,
        },
      })
      await tx.interviewSession.update({
        where: { id: session.id, status: 'PROCESSING' },
        data: { status: 'COMPLETED', completedAt: new Date(), lastError: null },
      })
    })
    console.info(`[${logPrefix}][RESEARCH] session completed successfully`, { sessionId: session.id })
    return true
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      const current = await prisma.interviewSession.findUnique({
        where: { id: session.id },
        select: { status: true },
      })
      if (current?.status === 'COMPLETED') return true
      console.error(`[${logPrefix}][RESEARCH] transaction failed: session no longer PROCESSING`, {
        sessionId: session.id,
        currentStatus: current?.status,
      })
      return false
    }
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][RESEARCH] transaction failed`, {
      sessionId: session.id,
      error: errorMsg,
    })
    // Transicionar a ERROR para no dejar la sesión pegada en PROCESSING
    try {
      const newRetryCount = session.retryCount + 1
      const exhausted = newRetryCount >= session.maxRetries
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount }
          : { lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][RESEARCH] CRITICAL: failed to update session after transaction error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }
}

/**
 * Genera las 3 opciones de marca (BRAND_OPTIONS) para una sesión BRAND y la transiciona a COMPLETED.
 * Carga Brief (etapa 1) y Market Study (etapa 2) como contexto adicional.
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
async function processBrandSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const answers = (session.answers ?? {}) as Record<string, unknown>

  // Cargar Brief (etapa 1) como contexto — opcional
  let briefContent: StrategicBrief | null = null
  try {
    const briefDeliverable = await prisma.deliverable.findFirst({
      where: { projectId: session.projectId, type: 'BRIEF', isActive: true },
      select: { content: true },
      orderBy: { createdAt: 'desc' },
    })
    if (briefDeliverable?.content) {
      briefContent = briefDeliverable.content as unknown as StrategicBrief
    }
  } catch (err) {
    console.warn(`[${logPrefix}][BRAND] No se pudo cargar Brief de etapa 1 — continuando sin él`, {
      sessionId: session.id,
      error: err instanceof Error ? err.message : String(err),
    })
  }

  // Cargar Market Study (etapa 2) como contexto — opcional
  let marketStudy: MarketStudy | null = null
  try {
    const studyDeliverable = await prisma.deliverable.findFirst({
      where: { projectId: session.projectId, type: 'MARKET_STUDY', isActive: true },
      select: { content: true },
      orderBy: { createdAt: 'desc' },
    })
    if (studyDeliverable?.content) {
      marketStudy = studyDeliverable.content as unknown as MarketStudy
    }
  } catch (err) {
    console.warn(`[${logPrefix}][BRAND] No se pudo cargar Market Study de etapa 2 — continuando sin él`, {
      sessionId: session.id,
      error: err instanceof Error ? err.message : String(err),
    })
  }

  const source = await resolveUsageSource(session.teamId)
  const billingContext: BillingContext = {
    teamId: session.teamId,
    projectId: session.projectId,
    source,
    operation: 'brand_generation',
  }

  let brandOptions
  try {
    brandOptions = await generateBrandOptions(flowDefinition, answers, session.projectId, briefContent, marketStudy, billingContext)
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][BRAND] brand options generation failed`, {
      sessionId: session.id,
      projectId: session.projectId,
      error: errorMsg,
    })

    const newRetryCount = session.retryCount + 1
    const exhausted = newRetryCount >= session.maxRetries

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: errorMsg.slice(0, 500), retryCount: newRetryCount }
          : { lastError: errorMsg.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][BRAND] CRITICAL: failed to update session after generation error — session may be stuck in PROCESSING`, {
        sessionId: session.id,
        originalError: errorMsg,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'BRAND_OPTIONS',
          title: 'Opciones de marca',
          content: brandOptions as unknown as Prisma.InputJsonValue,
          status: 'SENT_TO_CLIENT',
          isActive: true,
        },
      })
      await tx.interviewSession.update({
        where: { id: session.id, status: 'PROCESSING' },
        data: { status: 'COMPLETED', completedAt: new Date(), lastError: null },
      })
    })
    console.info(`[${logPrefix}][BRAND] session completed successfully`, { sessionId: session.id })
    return true
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      const current = await prisma.interviewSession.findUnique({
        where: { id: session.id },
        select: { status: true },
      })
      if (current?.status === 'COMPLETED') return true
      console.error(`[${logPrefix}][BRAND] transaction failed: session no longer PROCESSING`, {
        sessionId: session.id,
        currentStatus: current?.status,
      })
      return false
    }
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][BRAND] transaction failed`, {
      sessionId: session.id,
      error: errorMsg,
    })
    try {
      const newRetryCount = session.retryCount + 1
      const exhausted = newRetryCount >= session.maxRetries
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount }
          : { lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][BRAND] CRITICAL: failed to update session after transaction error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }
}

/**
 * Genera el Plan de Campaña Publicitaria para una sesión CAMPAIGNS y la transiciona a COMPLETED.
 * Carga deliverables de las 4 etapas anteriores como contexto.
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
async function processCampaignsSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  console.info(`[${logPrefix}][CAMPAIGNS] starting campaign plan generation`, {
    sessionId: session.id,
    projectId: session.projectId,
  })

  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const answers = (session.answers ?? {}) as Record<string, unknown>

  // Cargar deliverables de etapas 1-4 como contexto para el generador
  let previousDeliverables: Array<{ type: string; content: unknown }> = []
  // Cargar deliverables y metadatos del proyecto en paralelo (son independientes)
  const [deliverablesResult, projectResult] = await Promise.allSettled([
    prisma.deliverable.findMany({
      where: {
        projectId: session.projectId,
        isActive: true,
        type: { in: ['BRIEF', 'MARKET_STUDY', 'BRAND_OPTIONS', 'WEBSITE_PREVIEW'] },
      },
      select: { type: true, content: true },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.project.findUnique({
      where: { id: session.projectId },
      select: { name: true, industry: true, country: true },
    }),
  ])

  if (deliverablesResult.status === 'fulfilled') {
    // Deduplicar: si hay múltiples del mismo tipo, tomar solo el más reciente
    const seen = new Set<string>()
    previousDeliverables = deliverablesResult.value.filter((d) => {
      if (seen.has(d.type)) return false
      seen.add(d.type)
      return true
    })
  } else {
    console.warn(`[${logPrefix}][CAMPAIGNS] No se pudieron cargar deliverables anteriores — continuando sin ellos`, {
      sessionId: session.id,
      error: deliverablesResult.reason instanceof Error ? deliverablesResult.reason.message : String(deliverablesResult.reason),
    })
  }

  let project: { name: string; industry: string | null; country: string | null } = {
    name: '',
    industry: null,
    country: null,
  }
  if (projectResult.status === 'fulfilled' && projectResult.value) {
    project = projectResult.value
  } else if (projectResult.status === 'rejected') {
    console.warn(`[${logPrefix}][CAMPAIGNS] No se pudo cargar el proyecto — continuando sin metadatos`, {
      sessionId: session.id,
      error: projectResult.reason instanceof Error ? projectResult.reason.message : String(projectResult.reason),
    })
  }

  console.info(`[${logPrefix}][CAMPAIGNS] context loaded`, {
    sessionId: session.id,
    previousDeliverablesCount: previousDeliverables.length,
    previousDeliverablesTypes: previousDeliverables.map((d) => d.type),
  })

  const source = await resolveUsageSource(session.teamId)
  const billingContext: BillingContext = {
    teamId: session.teamId,
    projectId: session.projectId,
    source,
    operation: 'campaign_strategy',
  }

  let plan
  try {
    plan = await generateCampaignPlan({
      flowDefinition,
      answers,
      project,
      previousDeliverables,
      billingContext,
    })
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][CAMPAIGNS] campaign plan generation failed`, {
      sessionId: session.id,
      projectId: session.projectId,
      error: errorMsg,
    })

    // Errores de validación del output del modelo no mejoran con retry
    const isValidationError = errorMsg.includes('[campaign-strategy-generator]')
    const newRetryCount = session.retryCount + 1
    const exhausted = isValidationError || newRetryCount >= session.maxRetries

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: errorMsg.slice(0, 500), retryCount: newRetryCount }
          : { lastError: errorMsg.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][CAMPAIGNS] CRITICAL: failed to update session after generation error — session may be stuck in PROCESSING`, {
        sessionId: session.id,
        originalError: errorMsg,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'CAMPAIGN_PLAN',
          title: 'Plan de Campaña Publicitaria',
          content: plan as unknown as Prisma.InputJsonValue,
          // READY: requiere revisión del admin antes de enviarse al cliente
          status: 'READY',
          isActive: true,
        },
      })
      await tx.interviewSession.update({
        where: { id: session.id, status: 'PROCESSING' },
        data: { status: 'COMPLETED', completedAt: new Date(), lastError: null },
      })
    })
    console.info(`[${logPrefix}][CAMPAIGNS] session completed successfully`, { sessionId: session.id })
    return true
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      const current = await prisma.interviewSession.findUnique({
        where: { id: session.id },
        select: { status: true },
      })
      if (current?.status === 'COMPLETED') return true
      console.error(`[${logPrefix}][CAMPAIGNS] transaction failed: session no longer PROCESSING`, {
        sessionId: session.id,
        currentStatus: current?.status,
      })
      return false
    }
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][CAMPAIGNS] transaction failed`, {
      sessionId: session.id,
      error: errorMsg,
    })
    try {
      const newRetryCount = session.retryCount + 1
      const exhausted = newRetryCount >= session.maxRetries
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount }
          : { lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][CAMPAIGNS] CRITICAL: failed to update session after transaction error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }
}

/**
 * Genera las piezas publicitarias (AD_CREATIVES) para una sesión CREATIVES y la transiciona a COMPLETED.
 * Carga BRIEF y CAMPAIGN_PLAN como contexto. Consulta las cuentas conectadas para filtrar plataformas.
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
async function processCreativesSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  console.info(`[${logPrefix}][CREATIVES] starting ad creatives generation`, {
    sessionId: session.id,
    projectId: session.projectId,
  })

  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const answers = (session.answers ?? {}) as Record<string, unknown>

  // Cargar deliverables y datos del proyecto en paralelo
  const [deliverablesResult, projectResult, adAccountsResult] = await Promise.allSettled([
    prisma.deliverable.findMany({
      where: {
        projectId: session.projectId,
        isActive: true,
        type: { in: ['BRIEF', 'CAMPAIGN_PLAN', 'BRAND_OPTIONS'] },
      },
      select: { type: true, content: true },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.project.findUnique({
      where: { id: session.projectId },
      select: { name: true, industry: true, country: true },
    }),
    // Cuentas activas conectadas para saber qué plataformas están disponibles
    prisma.adAccount.findMany({
      where: { projectId: session.projectId, status: 'ACTIVE' },
      select: { platform: true },
    }),
  ])

  let previousDeliverables: Array<{ type: string; content: unknown }> = []
  if (deliverablesResult.status === 'fulfilled') {
    const seen = new Set<string>()
    previousDeliverables = deliverablesResult.value.filter((d) => {
      if (seen.has(d.type)) return false
      seen.add(d.type)
      return true
    })
  } else {
    console.warn(`[${logPrefix}][CREATIVES] No se pudieron cargar deliverables anteriores`, {
      sessionId: session.id,
      error: deliverablesResult.reason instanceof Error ? deliverablesResult.reason.message : String(deliverablesResult.reason),
    })
  }

  let project: { name: string; industry: string | null; country: string | null } = {
    name: '',
    industry: null,
    country: null,
  }
  if (projectResult.status === 'fulfilled' && projectResult.value) {
    project = projectResult.value
  }

  // Determinar plataformas conectadas
  const connectedPlatforms: Array<'GOOGLE_ADS' | 'META'> = []
  if (adAccountsResult.status === 'fulfilled') {
    for (const acct of adAccountsResult.value) {
      if ((acct.platform === 'GOOGLE_ADS' || acct.platform === 'META') &&
          !connectedPlatforms.includes(acct.platform)) {
        connectedPlatforms.push(acct.platform)
      }
    }
  } else {
    console.warn(`[${logPrefix}][CREATIVES] No se pudieron cargar las cuentas de anuncios; generando sin filtro de plataforma`, {
      sessionId: session.id,
      error: adAccountsResult.reason instanceof Error ? adAccountsResult.reason.message : String(adAccountsResult.reason),
    })
  }

  console.info(`[${logPrefix}][CREATIVES] context loaded`, {
    sessionId: session.id,
    previousDeliverablesTypes: previousDeliverables.map((d) => d.type),
    connectedPlatforms,
  })

  const source = await resolveUsageSource(session.teamId)
  const billingContext: BillingContext = {
    teamId: session.teamId,
    projectId: session.projectId,
    source,
    operation: 'ad_creatives',
  }

  let creatives
  try {
    creatives = await generateAdCreatives({
      flowDefinition,
      answers,
      project,
      previousDeliverables,
      connectedPlatforms,
      billingContext,
    })
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][CREATIVES] ad creatives generation failed`, {
      sessionId: session.id,
      projectId: session.projectId,
      error: errorMsg,
    })

    const isValidationError = errorMsg.includes('[ad-creative-generator]')
    const newRetryCount = session.retryCount + 1
    const exhausted = isValidationError || newRetryCount >= session.maxRetries

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: errorMsg.slice(0, 500), retryCount: newRetryCount }
          : { lastError: errorMsg.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][CREATIVES] CRITICAL: failed to update session after generation error — session may be stuck in PROCESSING`, {
        sessionId: session.id,
        originalError: errorMsg,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  try {
    await prisma.$transaction(async (tx) => {
      // Desactivar solo AD_CREATIVES anteriores — no tocar AD_VISUALS de intentos previos
      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, type: 'AD_CREATIVES', isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'AD_CREATIVES',
          title: 'Piezas publicitarias',
          content: creatives as unknown as Prisma.InputJsonValue,
          // READY: requiere revisión del admin antes de enviarse al cliente
          status: 'READY',
          isActive: true,
        },
      })
      await tx.interviewSession.update({
        where: { id: session.id, status: 'PROCESSING' },
        data: { status: 'COMPLETED', completedAt: new Date(), lastError: null },
      })
    })
    console.info(`[${logPrefix}][CREATIVES] copy saved and session completed`, { sessionId: session.id })
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      const current = await prisma.interviewSession.findUnique({
        where: { id: session.id },
        select: { status: true },
      })
      if (current?.status === 'COMPLETED') return true
      console.error(`[${logPrefix}][CREATIVES] transaction failed: session no longer PROCESSING`, {
        sessionId: session.id,
        currentStatus: current?.status,
      })
      return false
    }
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][CREATIVES] transaction failed`, {
      sessionId: session.id,
      error: errorMsg,
    })
    try {
      const newRetryCount = session.retryCount + 1
      const exhausted = newRetryCount >= session.maxRetries
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount }
          : { lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][CREATIVES] CRITICAL: failed to update session after transaction error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  // Generar piezas visuales (AD_VISUALS) si META está conectado.
  // La sesión ya está COMPLETED — el fracaso de visuals no bloquea la sesión.
  if (connectedPlatforms.includes('META')) {
    await generateAndSaveAdVisuals({
      session,
      project,
      previousDeliverables,
      billingContext,
      logPrefix,
    })
  }

  return true
}

// ── Generación y persistencia de AD_VISUALS ───────────────────────────────────

type GenerateVisualsArgs = {
  session: SessionToProcess
  project: { name: string; industry: string | null; country: string | null }
  previousDeliverables: Array<{ type: string; content: unknown }>
  billingContext: BillingContext
  logPrefix: string
}

/**
 * Orquesta la generación, validación y persistencia de piezas visuales Meta Ads.
 * No lanza — todos los errores son registrados y la función retorna silenciosamente.
 * La sesión ya está COMPLETED cuando esta función corre.
 */
async function generateAndSaveAdVisuals({
  session,
  project,
  previousDeliverables,
  billingContext,
  logPrefix,
}: GenerateVisualsArgs): Promise<void> {
  console.info(`[${logPrefix}][AD_VISUALS] starting visual generation`, {
    sessionId: session.id,
    projectId: session.projectId,
  })

  const brandOptionsDeliverable = previousDeliverables.find((d) => d.type === 'BRAND_OPTIONS')
  const brandOptions = (brandOptionsDeliverable?.content as BrandOptions | null) ?? null

  const visualInput = {
    project,
    previousDeliverables,
    projectId: session.projectId,
    sessionId: session.id,
    brandOptions,
  }

  // 1. Generación inicial
  let adVisuals
  try {
    adVisuals = await generateAdVisuals(visualInput)
  } catch (err) {
    console.error(`[${logPrefix}][AD_VISUALS] generation failed — skipping visuals`, {
      sessionId: session.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return
  }

  // 2. Validación (degradación si falla: aceptar todo)
  const validationResult = await validateAdVisuals(adVisuals, billingContext)

  // 3. Regenerar piezas con score bajo (máx MAX_REGENERATIONS, definido en el validador)
  if (!validationResult.validationFailed && validationResult.toRegenerate.length > 0) {
    console.info(`[${logPrefix}][AD_VISUALS] regenerating ${validationResult.toRegenerate.length} piece(s)`, {
      sessionId: session.id,
      toRegenerate: validationResult.toRegenerate,
    })

    // Regenerar en paralelo (máx 2 piezas, independientes)
    const regenResults = await Promise.all(
      validationResult.toRegenerate.map((visualId) =>
        regenerateAdVisual(visualId, visualInput).then((result) => ({ visualId, result })),
      ),
    )
    for (const { visualId, result } of regenResults) {
      if (result) {
        const idx = adVisuals.visuals.findIndex((v) => `${v.format}-${v.angle}` === visualId)
        if (idx >= 0) adVisuals.visuals[idx] = result
      }
    }
  }

  // 4. Aplicar scores de validación a las piezas finales
  const finalVisuals = applyValidationScores(adVisuals.visuals, validationResult)
  const finalAdVisuals = { ...adVisuals, visuals: finalVisuals }

  // 5. Persistir AD_VISUALS (transacción separada a la del copy)
  try {
    await prisma.$transaction(async (tx) => {
      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, type: 'AD_VISUALS', isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'AD_VISUALS',
          title: 'Piezas visuales Meta Ads',
          content: finalAdVisuals as unknown as Prisma.InputJsonValue,
          status: 'READY',
          isActive: true,
        },
      })
    })
    console.info(`[${logPrefix}][AD_VISUALS] saved successfully`, {
      sessionId: session.id,
      visualsCount: finalAdVisuals.visuals.length,
    })
  } catch (err) {
    console.error(`[${logPrefix}][AD_VISUALS] failed to save visuals — copy is intact`, {
      sessionId: session.id,
      error: err instanceof Error ? err.message : String(err),
    })
  }
}

/**
 * Procesa la sesión de intake inicial. Lee las respuestas del usuario para determinar
 * qué etapas del proyecto ya tiene cubiertas y actualiza su activation en consecuencia.
 *
 * Claves de respuesta esperadas en session.answers:
 * - has_brand: 'yes' | 'no' → si 'yes', BRAND = PROVIDED_BY_CLIENT
 * - has_website: 'yes' | 'no' → si 'yes', WEBSITE = PROVIDED_BY_CLIENT
 * - needs_campaigns: 'yes' | 'no' → si 'no', CAMPAIGNS = SKIP
 * - needs_media: 'yes' | 'no' → si 'no', MEDIA = SKIP
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
async function processIntakeSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  console.info(`[${logPrefix}][INTAKE] processIntakeSession started`, {
    sessionId: session.id,
    projectId: session.projectId,
  })

  const answers = (session.answers ?? {}) as Record<string, unknown>

  const activationUpdates: Array<{ stageKey: string; activation: 'ACTIVE' | 'SKIP' | 'PROVIDED_BY_CLIENT' }> = []

  if (answers['has_brand'] === 'yes') {
    activationUpdates.push({ stageKey: 'BRAND', activation: 'PROVIDED_BY_CLIENT' })
  }
  if (answers['has_website'] === 'yes') {
    activationUpdates.push({ stageKey: 'WEBSITE', activation: 'PROVIDED_BY_CLIENT' })
  }
  if (answers['needs_campaigns'] === 'no') {
    activationUpdates.push({ stageKey: 'CAMPAIGNS', activation: 'SKIP' })
  }
  if (answers['needs_media'] === 'no') {
    activationUpdates.push({ stageKey: 'MEDIA', activation: 'SKIP' })
  }

  try {
    await prisma.$transaction(async (tx) => {
      for (const { stageKey, activation } of activationUpdates) {
        await tx.stage.updateMany({
          where: { projectId: session.projectId, stageKey },
          data: {
            activation,
            status: activation !== 'ACTIVE' ? 'COMPLETED' : undefined,
            completedAt: activation !== 'ACTIVE' ? new Date() : undefined,
          },
        })
      }

      await tx.interviewSession.update({
        where: { id: session.id },
        data: {
          status: 'COMPLETED',
          completedAt: new Date(),
        },
      })

      await tx.stage.update({
        where: { id: session.stageId },
        data: {
          status: 'COMPLETED',
          completedAt: new Date(),
        },
      })
    })

    console.info(`[${logPrefix}][INTAKE] completed`, {
      sessionId: session.id,
      activationUpdates,
    })

    return true
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}][INTAKE] CRITICAL: failed to process intake session`, {
      sessionId: session.id,
      error: errorMsg,
    })

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: {
          status: 'ERROR',
          lastError: errorMsg.slice(0, 500),
          retryCount: session.retryCount + 1,
        },
      })
      await prisma.stage.update({
        where: { id: session.stageId },
        data: {
          status: 'FAILED',
          errorMessage: errorMsg.slice(0, 500),
        },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}][INTAKE] CRITICAL: failed to update session after error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }
}

/**
 * Genera el Brief Estratégico para una sesión y la transiciona a COMPLETED.
 * Usada tanto por el cron de recovery como por el endpoint admin de retry.
 *
 * @returns true si completó exitosamente, false si hubo error
 * @throws nunca — todos los errores se capturan y loguean
 */
export async function processSession(session: SessionToProcess, logPrefix: string): Promise<boolean> {
  console.info(`[${logPrefix}] processSession started`, {
    sessionId: session.id,
    stageKey: session.stageKey,
    retryCount: session.retryCount,
  })

  // Verificar activation del stage: si es SKIP o PROVIDED_BY_CLIENT, completar sin procesar
  const stageRecord = await prisma.stage.findUnique({
    where: { id: session.stageId },
    select: { activation: true },
  })

  if (stageRecord?.activation === 'SKIP' || stageRecord?.activation === 'PROVIDED_BY_CLIENT') {
    console.info(`[${logPrefix}] Stage skipped due to activation=${stageRecord.activation}`, {
      sessionId: session.id,
      stageId: session.stageId,
      stageKey: session.stageKey,
    })
    await prisma.interviewSession.update({
      where: { id: session.id },
      data: {
        status: 'COMPLETED',
        completedAt: new Date(),
      },
    })
    await prisma.stage.update({
      where: { id: session.stageId },
      data: {
        status: 'COMPLETED',
        completedAt: new Date(),
      },
    })
    return true
  }

  // Guard de billing: verificar elegibilidad antes de procesar.
  // Se verifica también aquí (además de en los endpoints) para proteger el path del cron de recovery,
  // que llama processSession directamente sin pasar por los guards de los endpoints.
  // INTAKE no consume tokens de IA — se excluye de este check.
  if (session.teamId && session.stageKey !== 'INTAKE') {
    try {
      const billing = await checkBillingEligibility(session.teamId)
      if (!billing.eligible) {
        console.warn(`[${logPrefix}] billing inelegible — sesión no procesada`, {
          sessionId: session.id,
          reason: billing.reason,
          plan: billing.billingPlan,
        })
        await prisma.interviewSession.update({
          where: { id: session.id },
          data: {
            status: 'ERROR',
            lastError: `Billing inelegible: ${billing.reason ?? 'plan insuficiente'}`,
          },
        })
        return false
      }
    } catch (err) {
      console.error(`[${logPrefix}] billing check failed en processSession — bloqueando por seguridad`, {
        sessionId: session.id,
        teamId: session.teamId,
        err,
      })
      // Fail-closed: no procesar si no se puede verificar billing
      return false
    }
  }

  if (session.stageKey === 'INTAKE') {
    return processIntakeSession(session, logPrefix)
  }

  if (session.stageKey === 'WEBSITE') {
    return processWebsiteSession(session, logPrefix)
  }

  if (session.stageKey === 'RESEARCH') {
    return processResearchSession(session, logPrefix)
  }

  if (session.stageKey === 'BRAND') {
    return processBrandSession(session, logPrefix)
  }

  if (session.stageKey === 'CAMPAIGNS') {
    return processCampaignsSession(session, logPrefix)
  }

  if (session.stageKey === 'CREATIVES') {
    return processCreativesSession(session, logPrefix)
  }

  const flowDefinition = (session.flowDefinition ?? []) as QuestionBlock[]
  const answers = (session.answers ?? {}) as Record<string, unknown>

  const source = await resolveUsageSource(session.teamId)
  const billingContext: BillingContext = {
    teamId: session.teamId,
    projectId: session.projectId,
    source,
    operation: 'brief_generation',
  }

  let brief
  try {
    brief = await generateStrategicBrief(flowDefinition, answers, billingContext)
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}] brief generation failed`, { sessionId: session.id, error: errorMsg })

    const newRetryCount = session.retryCount + 1
    const exhausted = newRetryCount >= session.maxRetries

    try {
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? {
              // Reintentos agotados: transicionar a ERROR para que el usuario y el admin lo vean
              status: 'ERROR',
              lastError: errorMsg.slice(0, 500),
              retryCount: newRetryCount,
            }
          : {
              lastError: errorMsg.slice(0, 500),
              retryCount: newRetryCount,
              processingStartedAt: null, // liberar sesión para que el cron la procese en el próximo ciclo
            },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}] CRITICAL: failed to update session after brief generation error — session may be stuck in PROCESSING`, {
        sessionId: session.id,
        originalError: errorMsg,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.deliverable.updateMany({
        where: { stageId: session.stageId, isActive: true },
        data: { isActive: false },
      })
      await tx.deliverable.create({
        data: {
          projectId: session.projectId,
          teamId: session.teamId,
          stageId: session.stageId,
          type: 'BRIEF',
          title: 'Brief Estratégico',
          content: brief as unknown as Prisma.InputJsonValue,
          // SENT_TO_CLIENT: plataforma self-service — el cliente aprueba directamente sin intermediación del admin
          status: 'SENT_TO_CLIENT',
          isActive: true,
        },
      })
      await tx.interviewSession.update({
        where: { id: session.id, status: 'PROCESSING' },
        data: { status: 'COMPLETED', completedAt: new Date(), lastError: null },
      })
    })
    console.info(`[${logPrefix}] session completed successfully`, { sessionId: session.id })
    return true
  } catch (err) {
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      const current = await prisma.interviewSession.findUnique({
        where: { id: session.id },
        select: { status: true },
      })
      if (current?.status === 'COMPLETED') return true
      console.error(`[${logPrefix}] transaction failed: session no longer PROCESSING`, {
        sessionId: session.id,
        currentStatus: current?.status,
      })
      return false
    }
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[${logPrefix}] transaction failed`, {
      sessionId: session.id,
      error: errorMsg,
    })
    try {
      const newRetryCount = session.retryCount + 1
      const exhausted = newRetryCount >= session.maxRetries
      await prisma.interviewSession.update({
        where: { id: session.id },
        data: exhausted
          ? { status: 'ERROR', lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount }
          : { lastError: `Transaction failed: ${errorMsg}`.slice(0, 500), retryCount: newRetryCount, processingStartedAt: null },
      })
    } catch (dbErr) {
      console.error(`[${logPrefix}] CRITICAL: failed to update session after transaction error`, {
        sessionId: session.id,
        dbError: dbErr instanceof Error ? dbErr.message : String(dbErr),
      })
    }
    return false
  }
}
