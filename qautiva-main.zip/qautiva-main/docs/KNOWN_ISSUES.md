# Errores Conocidos y Patrones Problemáticos

> **Este es el archivo más importante a largo plazo.**
> Acá se anota todo lo que Claude Code hace mal, se equivoca seguido, o genera problemas recurrentes.
> Cada entrada evita que el mismo error se repita. Esto es lo que realmente hace que Claude Code mejore con el tiempo.
>
> Empieza vacío. Se llena con el uso.

## Cómo usar este archivo

### Cuándo agregar algo

- Claude Code generó código que rompió algo y no se dio cuenta
- Claude Code repitió un error que ya se había corregido antes
- Claude Code tomó una decisión que contradice la arquitectura del proyecto
- Un patrón del proyecto es contraintuitivo y Claude lo hace mal
- Alguna dependencia o API tiene comportamiento inesperado que causa bugs

### Formato de cada entrada

```markdown
### [Fecha] — Descripción corta del problema

**Qué pasó**: [Qué hizo Claude Code mal]
**Por qué está mal**: [Qué consecuencia tuvo o podría tener]
**Qué hacer en vez**: [La forma correcta]
**Archivos afectados**: [Dónde prestar atención]
```

---

## Registro de errores

### 2026-03-20 — Stitch API: outputComponents[0] NO es la screen, es el designSystem

**Qué pasó**: La función `tryExtractScreenFromRaw` en `generate-template.ts` asumía que `outputComponents[0]` contenía la screen generada (con `htmlCode.downloadUrl` y `screenshot`). En la API actual de Stitch, `outputComponents[0]` es el **designSystem** y `outputComponents[1].design.screens[0]` es la screen con el HTML. Al no encontrar la screen en `[0]`, el código caía al fallback `list_screens` que devuelve `{}` (objeto vacío), y fallaba con "No se encontró screen con HTML".

**Por qué está mal**: Todos los jobs de la cola de Stitch fallaban silenciosamente. Los templates nunca se generaban. El error era difícil de diagnosticar porque:
1. Los logs solo mostraban el JSON truncado de `generate_screen_from_text` (800 chars) que cortaba antes de llegar a `outputComponents[1]`
2. `list_screens` devuelve `{}` (no un array vacío `[]`), así que el polling agotaba los 10 intentos sin resultado
3. El timeout de 240s hacía que los errores tardaran mucho en aparecer

**Estructura real de la respuesta de `generate_screen_from_text`**:
```
outputComponents[0] → { designSystem: { ... } }           // Design system, NO screen
outputComponents[1] → { design: { screens: [{ id, htmlCode, screenshot, ... }] } }  // LA SCREEN
outputComponents[2] → { text: "..." }                      // Mensaje de la IA
outputComponents[3+] → { suggestion: "..." }               // Sugerencias
```

**Qué hacer en vez**: Iterar TODOS los `outputComponents` buscando el primero que tenga `design.screens[0]` con `id` o `name`. No asumir posición fija. El fix itera con `for (const oc of components)`.

**Dato extra**: `list_screens` devuelve `{}` (no `[]`) cuando no hay screens o cuando el timing no es correcto. No es confiable como fallback. Siempre preferir extraer la screen del response inline de `generate_screen_from_text`.

**Archivos afectados**: `packages/stitch/src/generate-template.ts` (función `tryExtractScreenFromRaw`)

**Cómo se diagnosticó**: Se creó un endpoint de debug streaming (`/api/stitch/queue/debug/raw-response`) que ejecuta el flujo completo y devuelve cada paso como NDJSON. Esto permitió ver la estructura real de la respuesta sin que el timeout cortara los datos. Archivo: `packages/stitch/src/debug-raw.ts`.

---

<!--
Agregar entradas nuevas acá arriba (las más recientes primero).
Ejemplo:

### 2025-02-18 — No usar JSON.parse() sin try/catch

---

### 2026-03-11 — TokenUsageSummary: usar sentinel 'TEAM' para resúmenes a nivel team (no NULL)

**Qué pasó**: El plan original usaba `projectId String?` (nullable) en `TokenUsageSummary` con `@@unique([teamId, projectId, provider, month])`. En PostgreSQL, `NULL != NULL` en UNIQUE constraints, por lo que múltiples filas con `projectId = NULL` para el mismo team/provider/mes eran permitidas, rompiendo la unicidad del resumen a nivel team.

**Por qué está mal**: El job de billing que actualiza los resúmenes crearía filas duplicadas para el resumen del team completo, causando doble-conteo en los dashboards.

**Qué hacer en vez**: Usar `projectId String @default("TEAM")` donde `'TEAM'` es el sentinel value para "resumen del team". Al leer: `WHERE projectId = 'TEAM'` para resúmenes del team, `WHERE projectId = '<uuid>'` para resúmenes por proyecto.

**Archivos afectados**: `packages/db/prisma/schema.prisma` (TokenUsageSummary), cualquier job/query que escriba en TokenUsageSummary (Etapa 6).

---

### 2026-03-11 — Inconsistencia de mecanismo de admin en RLS: jwt root vs app_metadata

**Qué pasó**: Las políticas RLS antiguas (Organization, Stage, Deliverable, etc.) usan `auth.jwt() ->> 'role' = 'ADMIN'` (claim en el ROOT del JWT). Las nuevas políticas de Etapa 1 usan `(auth.jwt() -> 'app_metadata' ->> 'role') = 'ADMIN'` (más seguro — solo servidor puede escribir app_metadata).

**Por qué está mal**: Si se configura el rol de admin en `app_metadata` (approach correcto), los admins no podrán acceder a las tablas antiguas vía RLS. Si la app admin usa `service_role` para las tablas antiguas (lo que hace actualmente), no hay impacto inmediato. El problema surge si alguien agrega una query client-side a tablas antiguas que dependa de que el admin sea reconocido por RLS.

**Qué hacer en vez**: SIEMPRE usar `(auth.jwt() -> 'app_metadata' ->> 'role') = 'ADMIN'` en políticas nuevas. Las políticas antiguas se corregen en Fase C cuando se eliminen las tablas viejas. Mientras tanto: las operaciones de admin en tablas antiguas van SIEMPRE via `service_role`.

**Archivos afectados**: `packages/db/prisma/rls.sql` (políticas antiguas líneas 1-241), cualquier nueva policy que se agregue.

---

### 2026-03-11 — Trigger SQL: usar COALESCE para email NULL de OAuth

**Qué pasó**: El trigger `handle_new_user` hacía `INSERT INTO "UserProfile" (..., email, ...) VALUES (..., NEW.email, ...)`. Si `NEW.email` es NULL (algunos proveedores OAuth no garantizan email), el INSERT falla con NOT NULL violation y el UserProfile no se crea.

**Por qué está mal**: El usuario puede registrarse (auth.users INSERT succeed) pero no tiene UserProfile/Team/BillingAccount. Queda en estado inválido. El wizard de onboarding tiene recovery, pero es un flujo de excepción.

**Qué hacer en vez**: Siempre usar `COALESCE(NEW.email, '')` en el trigger. Usar `NULLIF(split_part(COALESCE(NEW.email, ''), '@', 1), '')` para el displayName cuando el email está vacío, con fallback final `'usuario'`.

**Archivos afectados**: `packages/db/prisma/migrations/001_handle_new_user_trigger.sql`. Si se crea un trigger similar para otro evento, usar el mismo patrón.

**Qué pasó**: Claude Code usó JSON.parse() directo sin manejo de error, y cuando el string no era JSON válido crasheó la aplicación
**Por qué está mal**: JSON.parse con input no confiable siempre puede fallar
**Qué hacer en vez**: Envolver en try/catch o usar una función utilitaria safeJsonParse()
**Archivos afectados**: Todo lugar donde se parsee JSON de fuentes externas
-->

### 2026-03-20 — Cola Stitch: `selectBestAccount` no es atómica bajo concurrencia

**Qué pasó**: `selectBestAccount()` hace `updateMany` de reset + `findMany` como dos queries separadas. Si dos admins ejecutan jobs simultáneamente, ambos ven el reset y leen la misma cuenta con `usedToday = 0`. Ambos hacen `{ increment: 1 }` sobre el mismo valor base, pudiendo exceder `dailyLimit`.

**Por qué está bien aceptado**: El flujo es manual (admin clickea "Run" en la UI). La concurrencia real es mínima. El `dailyLimit` de Stitch tiene margen y el error no causa pérdida de datos, solo un conteo de `usedToday` ligeramente incorrecto.

**Qué hacer si escala**: Reemplazar con `UPDATE stitchAccount SET usedToday = usedToday + 1 WHERE id = (SELECT id FROM stitchAccount WHERE ... ORDER BY usedToday ASC LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING id, "apiKey"` como query atómica, o usar una transacción con `SELECT FOR UPDATE`.

**Archivos afectados**: `apps/admin/app/api/stitch/queue/[id]/run/route.ts:selectBestAccount`

---

### 2026-03-18 — Fase 5.2 Ads: no hay selector de cuenta cuando el usuario tiene múltiples cuentas

**Qué pasó**: Los callbacks de Google Ads y Meta Ads toman automáticamente la primera cuenta disponible. Si el usuario administra múltiples cuentas (MCC en Google, múltiples ad accounts en Meta), se conecta la primera sin preguntarle.

**Por qué está mal**: Un freelancer o agencia con múltiples clientes conecta la cuenta equivocada sin posibilidad de elegir. Tiene que desconectar y reconectar esperando otro orden.

**Qué hacer**: Crear una pantalla de selección post-callback donde el usuario elija qué cuenta conectar de una lista. Requiere:
1. Guardar la lista de cuentas disponibles en la sesión (cookie httpOnly cifrada o Redis) durante el callback
2. Nueva route `/api/ads/google/select` y `/api/ads/meta/select` que muestren el picker
3. Completar el upsert solo después de la selección

**Estimado**: 1 día de trabajo. Pendiente para Fase 5.6 o iteración post-MVP.

**Archivos afectados**: `apps/portal/app/api/ads/google/callback/route.ts:104-109`, `apps/portal/app/api/ads/meta/callback/route.ts:102-107`

---

### 2026-03-18 — Fase 5.2 Ads: tokens de Meta no se revocan en el proveedor al desconectar

**Qué pasó**: `DELETE /api/ads/accounts` solo marca la cuenta como `DISCONNECTED` en la DB pero no llama a la API de Meta/Google para revocar el token. El access token sigue siendo válido en el lado del proveedor hasta que expire naturalmente.

**Por qué está mal**: Si el token de DB se compromete después de la "desconexión", el atacante todavía puede usarlo hasta su expiración (hasta 60 días para Meta).

**Qué hacer**: Agregar llamadas de revocación:
- Google: `POST https://oauth2.googleapis.com/revoke?token=<access_token>`
- Meta: `DELETE /{user-id}/permissions` con el access token

**Estimado**: 2-3 horas. Pendiente para después del MVP.

**Archivos afectados**: `apps/portal/app/api/ads/accounts/route.ts:120-123`

---

### 2026-03-18 — Fase 5.2 Ads: no hay renovación automática de tokens de Meta

**Qué pasó**: Meta emite tokens long-lived con duración de ~60 días y sin refresh token. No hay cron/worker que los renueve ni alertas proactivas al usuario antes del vencimiento.

**Por qué está mal**: Las cuentas pasan silenciosamente a estado `EXPIRED` a los 60 días. El usuario no recibe aviso.

**Qué hacer**: Implementar job periódico (cron o queue) que:
1. Busque cuentas META con `tokenExpiresAt < NOW() + 7 days`
2. Llame a la API de extensión de token de Meta
3. Actualice `tokenExpiresAt` y mande notificación al usuario si falla

**Estimado**: Parte de Fase 5.6 (metrics sync). Requiere definir la estrategia de jobs del proyecto.

**Archivos afectados**: `apps/portal/app/api/ads/meta/callback/route.ts`, nuevo job a crear.

---

### 2026-03-11 — Rate limiting ausente en endpoints del marketplace (órdenes y mensajes)

**Qué pasó**: Los endpoints `POST /api/marketplace/orders` y `POST /api/marketplace/orders/[id]/messages` no tienen rate limiting. Identificado en el checkpoint de APIs de la Etapa 1 (revisión Security Auditor). Un usuario autenticado puede crear órdenes o enviar mensajes de forma ilimitada y programática, generando spam a editores.

**Por qué está mal**: Sin rate limiting, un actor malicioso puede saturar la bandeja de un editor con órdenes PENDING o inundar el chat de una orden con mensajes, degradando la UX y potencialmente la base de datos.

**Por qué no está corregido**: El rate limiting requiere un store externo (Redis/KV) para funcionar en entornos serverless. Ver la entrada 2026-03-10 sobre el mismo problema en `/api/contact`. Agregar una dependencia (Upstash Redis, Vercel KV) sin decisión explícita viola las reglas del proyecto.

**Qué hacer cuando se decida**: Implementar con Upstash Redis + `@upstash/ratelimit` (ya documentado en KNOWN_ISSUES 2026-03-10). Límites sugeridos:
- `POST /api/marketplace/orders`: 10 órdenes/hora por `profile.id`
- `POST /api/marketplace/orders/[id]/messages`: 30 mensajes/hora por `profile.id` + `orderId`

**Archivos afectados**: `apps/portal/app/api/marketplace/orders/route.ts`, `apps/portal/app/api/marketplace/orders/[id]/messages/route.ts`

---

### 2026-03-11 — Edit tool falla con caracteres box-drawing UTF-8 en old_string

**Qué pasó**: Al intentar editar líneas que contienen `──` (U+2500, box-drawing) en comentarios (e.g., `# ── Base de datos ─────`), el Edit tool no encontró el `old_string` y falló con "String not found in file". Ocurrió en `.env.example`.

**Por qué está mal**: Se pierde tiempo reintentando el Edit con distintas variantes del string.

**Qué hacer en vez**: Cuando la línea a editar contiene caracteres UTF-8 no-ASCII especiales (box-drawing, emojis, etc.), usar el Write tool directamente para reescribir el archivo completo (previa lectura con Read).

**Archivos afectados**: Cualquier archivo con comentarios decorativos que usen box-drawing (`──`, `═══`, etc.).

---

### 2026-03-11 — Write tool falla con "File has not been read yet" aunque el archivo existe

**Qué pasó**: Al intentar `Write` sobre un archivo existente sin haberlo leído antes en la misma conversación, el tool retorna error "File has not been read yet — read it first before writing". Ocurrió en `message-bridge.ts` y `.env.example`.

**Por qué está mal**: El flujo se interrumpe y es necesario hacer `Read` + `Write` en dos pasos en vez de uno.

**Qué hacer en vez**: Siempre leer el archivo con `Read` antes de usar `Write` para sobreescribirlo. Si se quiere editar, usar `Edit` (que también requiere lectura previa). El Read previo puede ser con un límite mínimo si solo se necesita habilitar el Write.

**Archivos afectados**: Cualquier archivo existente que se intente sobreescribir con Write.

---

### 2026-03-11 — Prompt injection en agentes IA: riesgo aceptado por diseño

**Qué pasó**: La revisión de seguridad (Etapa 4.4) identificó que un admin podría escribir instrucciones maliciosas en el system prompt de un agente IA (ej: `[IGNORE PREVIOUS INSTRUCTIONS]...`) que luego se pasarían al LLM y podrían alterar su comportamiento.

**Por qué no se corrige**: La feature ES que el admin configure los system prompts. Sanitizar el contenido rompería la funcionalidad. El riesgo está acotado porque solo usuarios con rol ADMIN (verificado por middleware + requireAdminSession) pueden escribir prompts.

**Mitigación actual**: Acceso restringido a ADMIN autenticados. Middleware bloquea cualquier otro rol.

**Qué hacer cuando sea relevante**: Si se abren los prompts a usuarios no-admin, agregar sanitización de patrones de inyección. Considerar un LLM guardrail (prompt shielding) al invocar el agente.

**Archivos afectados**: `apps/admin/lib/actions.ts:updateAgentConfig`, `apps/admin/app/(protected)/agentes/[id]/page.tsx`

---

### 2026-03-11 — Placeholder Supabase keys en next.config.mjs (admin + portal)

**Qué pasó**: `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY` tienen fallbacks de placeholder en `next.config.mjs` para permitir `next build` sin un `.env` local. Si alguien hace deploy sin configurar las env vars reales, la app arranca con auth completamente rota (Supabase no conecta) pero sin error visible en el startup.

**Por qué está mal**: El middleware falla silenciosamente y redirige todo a login, que tampoco funciona. El síntoma de cara al usuario es una pantalla de login que gira para siempre.

**Qué hacer en vez**: Antes de activar el env de producción, verificar con el health check (`/api/health`) que devuelva `checks.auth: "ok"`. Agregar validación explícita de env vars al startup (issue abierto).

**Archivos afectados**: `apps/admin/next.config.mjs:4-8`, `apps/portal/next.config.mjs:4-8`

---

### 2026-03-10 — Rate limiting in-memory no funciona en serverless (Vercel/Edge)

**Qué pasó**: El endpoint `/api/contact` de la landing usa un `Map` en memoria del proceso para rate limiting. En entornos serverless (Vercel Functions), cada request puede iniciar una instancia nueva del proceso, por lo que el Map siempre empieza vacío y el rate limiting nunca se activa.

**Por qué está mal**: Un atacante puede enviar requests ilimitados al endpoint de contacto. En entornos long-running (Docker, PM2), el Map crece indefinidamente sin cleanup de entradas expiradas.

**Decisión tomada**: Para Etapa 2 (lanzamiento), el reCAPTCHA v3 es la barrera principal. El rate limiting in-memory queda como defensa secundaria con valor limitado en serverless.

**Qué hacer cuando se escale**: Reemplazar con rate limiting basado en store externo:
- Opción A: [Upstash Redis](https://upstash.com/) + `@upstash/ratelimit`
- Opción B: Vercel KV (si se usa Vercel)
- Agregar cleanup periódico de entries expiradas si se mantiene in-memory

**Archivos afectados**: `apps/landing/app/api/contact/route.ts:4-18`

---

### 2026-03-10 — Footer de landing renderiza año de copyright estático si el componente es SSG

**Qué pasó**: `Footer.tsx` usa `{new Date().getFullYear()}` para el copyright. En Next.js con Static Site Generation, esto se evalúa en build time, no en runtime. Si el sitio se construye en 2026 y se sirve en 2027, mostrará "2026".

**Por qué está mal**: El año del copyright puede quedar desactualizado entre deploys.

**Qué hacer en vez**: Para un sitio de landing con deploys frecuentes, esto es aceptable. Si se necesita el año dinámico en runtime, convertir Footer a Server Component y confirmar que no hay `'use client'` en el árbol padre.

**Archivos afectados**: `apps/landing/components/Footer.tsx`

---

*El CLAUDE.md más efectivo no es el que se escribe una vez: es el que se actualiza cada vez que algo sale mal.*

---

## Billing — Gemini imagen no expone token usage (2026-03-18)

**Síntoma**: `generateLogoWithGemini()` en `brand-generator.ts` llama a la API de Gemini imagen (`gemini-2.0-flash-exp-image-generation`) pero la respuesta no incluye datos de `usage.input_tokens` / `usage.output_tokens`.

**Impacto**: Las generaciones de logo no se registran en `TokenUsage`. Los costos de imágenes Gemini no se trackan en billing.

**Workaround**: El registro del billing se omite para llamadas de imagen. El costo real existe pero no se registra.

**Resolución futura**: Si Gemini expone pricing de imagen, agregar una entrada en `AiModelPricing` para `provider=GOOGLE_GEMINI, model=gemini-imagen` y registrar con un costo fijo por imagen.

**Archivos afectados**: `apps/portal/app/_lib/interview/brand-generator.ts` (línea Gemini imagen)

---

## Billing — registerAiUsage no-atómica: TokenUsage y BillingAccount en operaciones separadas (2026-03-18)

**Síntoma**: `registerAiUsage()` llama a `recordTokenUsage()` y luego `updateBillingConsumption()` como dos operaciones de DB separadas (no en una transacción).

**Impacto**: Si `recordTokenUsage()` tiene éxito pero `updateBillingConsumption()` falla, queda un `TokenUsage` insertado pero `trialTokensUsed`/`balanceUsd` sin actualizar. El consumo queda registrado pero el saldo no se descuenta.

**Decisión de diseño**: La separación es intencional. `registerAiUsage` es fire-and-forget — debe priorizar que el `TokenUsage` siempre se inserte (trazabilidad). Un fallo de `updateBillingConsumption` loguea CRITICAL. El CHECK constraint de `balanceUsd >= 0` (Fase 2 task 2.5) protege contra saldo negativo.

**Resolución futura**: Envolver en `prisma.$transaction()` si se necesita atomicidad estricta. Requiere rediseño del flujo de error.

**Archivos afectados**: `apps/portal/app/_lib/billing/register-ai-usage.ts`

---

## Billing — fire-and-forget puede perderse en Vercel serverless (2026-03-18)

**Síntoma**: `void registerAiUsage(...)` en `executeToolCall` y generators dispara la promise sin `await`. En Vercel, el runtime puede terminar la función cuando se envía la response al cliente, antes de que las promises pendientes se resuelvan.

**Impacto**: Registros de `TokenUsage` podrían perderse silenciosamente en funciones con respuestas rápidas.

**Resolución futura**: Usar `waitUntil()` de `@vercel/functions` para garantizar que las promises de billing completen. Requiere actualizar a Next.js 15+ (usa `after()`) o instalar `@vercel/functions`.

**Archivos afectados**: `apps/portal/app/_lib/interview/ai-tool-call.ts`, generators

---

## Billing — cache de AiModelPricing y FeeConfig pendiente (2026-03-18)

**Síntoma**: `recordTokenUsage()` hace 3 queries a la DB por cada llamada AI (pricing + billingAccount + feeConfig).

**Impacto**: ~20-80ms de overhead adicional por operación de AI. `AiModelPricing` y `FeeConfig` cambian raramente — son candidatos ideales para cache con TTL.

**Resolución futura**: Implementar cache en memoria con TTL de 5 minutos (similar al patrón de `ai-config.ts`) para `AiModelPricing` y `FeeConfig`.

**Archivos afectados**: `apps/portal/app/_lib/billing/record-token-usage.ts`

---

## KI-001: MONTHLY/YEARLY sin lógica de excedente (2026-03-19)

**Síntoma**: Usuarios con planes MONTHLY/YEARLY quedan bloqueados cuando su saldo llega a $0, igual que PREPAID. Según el modelo de negocio (BUSINESS_MODEL.md regla 5), deberían poder continuar con cargo de excedente.

**Causa raíz**: No existe implementación de cobro de excedente. `checkBillingEligibility()` bloquea cuando `balanceUsd < 0`, sin distinción entre planes de suscripción y prepago.

**Impacto**: Usuarios de suscripción activos pueden quedar bloqueados. Revenue potencial perdido.

**Solución pendiente**: Implementar mecanismo de facturación de excedente para planes MONTHLY/YEARLY. Requiere integración con pasarela de pago (Stripe u equivalente). Crear issue en el backlog.

**Archivos**: `apps/portal/app/_lib/billing/check-eligibility.ts:101-114`

---

## KI-002: Lógica de billing duplicada entre portal y telegram-bot (2026-03-19)

**Síntoma**: `checkBotBillingEligibility()` y `registerBotTokenUsage()` en `services/telegram-bot/src/billing.ts` son duplicados de las funciones equivalentes del portal.

**Causa raíz**: El telegram-bot no puede importar código del portal (workspaces separados con diferentes clientes Prisma). Decisión documentada en `docs/decisions/ADR-0019-billing-logic-duplicada-bot-portal.md`.

**Riesgo**: Si cambia una regla de negocio (nuevo plan, nuevo cálculo de fee), hay que actualizar en dos lugares. Alta probabilidad de divergencia silenciosa.

**Mitigación actual**: Tests en ambos módulos verifican el mismo comportamiento. Cambios en billing deben hacerse en ambos archivos simultáneamente.

**Solución ideal**: Extraer lógica de billing a un paquete compartido `@qautiva/billing` que puedan importar tanto el portal como el bot. Pendiente de refactoring mayor.

**Archivos**: `services/telegram-bot/src/billing.ts`, `apps/portal/app/_lib/billing/`

---

## Billing — registerBotTokenUsage no-atómica: 4 queries sin transacción (2026-03-18)

**Síntoma**: `registerBotTokenUsage()` en el bot de Telegram ejecuta 4 queries secuenciales: (1) findUnique AiModelPricing, (2) findUnique BillingAccount, (3) create TokenUsage, (4) update BillingAccount. No están envueltas en una transacción.

**Impacto**: Si el paso 3 tiene éxito pero el 4 falla (o viceversa), queda estado inconsistente: TokenUsage insertado pero balance no descontado, o trialTokensUsed no incrementado pero registro de uso existente.

**Decisión de diseño**: Intencional. `registerBotTokenUsage` es fire-and-forget — prioriza la inserción del TokenUsage (trazabilidad) sobre la atomicidad. El catch loguea CRITICAL para alerting. El CHECK constraint `balanceUsd >= 0` protege contra saldo negativo en PREPAID/subscripciones.

**Resolución futura**: Envolver en `prisma.$transaction()` si se necesita atomicidad estricta. Mismo patrón que `registerAiUsage` en el portal.

**Archivos afectados**: `services/telegram-bot/src/billing.ts:registerBotTokenUsage`

---

## Billing — TOCTOU en bot de Telegram: billing check vs. llamada real al LLM (2026-03-18)

**Síntoma**: `checkBotBillingEligibility()` se ejecuta en `message-bridge.ts` antes de llamar al LLM. Entre ese check y el consumo real de tokens puede pasar tiempo suficiente para que el saldo cambie (otro request concurrente del portal o del bot).

**Mitigación actual**: El bot de Telegram tiene un proceso persistente con un solo hilo de ejecución por usuario (el handler de grammy es secuencial por chat_id). El riesgo real es entre el bot y el portal ejecutando concurrentemente para el mismo team. El CHECK constraint `balanceUsd >= 0` previene saldo negativo en PREPAID.

**Riesgo residual**: Un usuario FREE_TRIAL cuyo saldo cae a 0 entre el check y el consumo puede exceder `trialTokensTotal`. El exceso es ≤1 llamada al LLM (tokens de una sola respuesta).

**Resolución futura**: Misma que el portal — hacer el check dentro de una transacción que reserve tokens antes de la ejecución. Requiere rediseño de `generateResponse`.

**Archivos afectados**: `services/telegram-bot/src/message-bridge.ts`, `services/telegram-bot/src/billing.ts`

---

## Billing — TOCTOU en guard de elegibilidad vs. ejecución real (2026-03-18)

**Síntoma**: `checkBillingEligibility()` se ejecuta ANTES del lock atómico en `/process`. El consumo real de tokens ocurre en background (vía `waitUntil`). Entre el check y el consumo real pueden pasar segundos o minutos.

**Mitigación actual**: La state machine de la sesión previene concurrencia: `/advance submit` tiene protección P2025 (Prisma optimistic lock), y `/process` usa `updateMany` con lock atómico. Solo UN request puede tener el lock por sesión. El CHECK constraint `balanceUsd >= 0` previene saldo negativo.

**Riesgo residual**: Un usuario FREE_TRIAL podría intentar múltiples requests concurrentes a `/process` en una sesión ya en ERROR (que no tiene el lock de avance). El lock de `/process` mitiga esto (`PROCESSING_LOCK_MS = 2 minutos`).

**Resolución futura**: Hacer el billing check dentro de una transacción que también reserve/descuente tokens antes de la ejecución. Requiere rediseño del flujo de processSession.

**Archivos afectados**: `apps/portal/app/api/interview/sessions/[id]/process/route.ts`, `apps/portal/app/_lib/billing/check-eligibility.ts`
