'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

/**
 * Llama a router.refresh() cada `intervalMs` milisegundos para re-fetchear datos del servidor.
 * Usado en pantallas de "generando" para detectar cuando el proyecto está listo.
 */
export function AutoRefresh({ intervalMs = 30_000 }: { intervalMs?: number }) {
  const router = useRouter()

  useEffect(() => {
    const id = setInterval(() => { router.refresh() }, intervalMs)
    return () => { clearInterval(id) }
  }, [router, intervalMs])

  return null
}
