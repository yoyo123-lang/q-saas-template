'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { Heart } from 'lucide-react'
import { toast } from 'sonner'
import { toggleFavorite } from '@/lib/actions/favorites'
import { createInquiry } from '@/lib/actions/inquiries'

interface ListingActionsProps {
  listingId: string
  slug: string
  /** True if the current user is the listing owner */
  isOwnListing: boolean
  /** True if the current user has this listing favorited */
  initialIsFavorited: boolean
}

/**
 * Client component that handles the interactive sidebar buttons on /explorar/[slug].
 * Shows the "Consultar al vendedor" and "Guardar en favoritos" buttons with proper
 * optimistic updates and loading states.
 */
export function ListingActions({
  listingId,
  slug,
  isOwnListing,
  initialIsFavorited,
}: ListingActionsProps) {
  const router = useRouter()
  const [isFavorited, setIsFavorited] = useState(initialIsFavorited)
  const [isPendingConsult, startConsult] = useTransition()
  const [isPendingFav, startFav] = useTransition()

  function handleConsult() {
    startConsult(async () => {
      const result = await createInquiry(listingId)
      if (result.success && result.data) {
        router.push(`/consultas/${result.data.inquiryId}`)
      } else {
        toast.error(result.error ?? 'Error al crear la consulta.')
      }
    })
  }

  function handleFavorite() {
    // Optimistic update
    setIsFavorited((prev) => !prev)
    startFav(async () => {
      const result = await toggleFavorite(listingId)
      if (!result.success) {
        // Revert
        setIsFavorited((prev) => !prev)
        toast.error(result.error ?? 'Error al actualizar favoritos.')
        return
      }
      if (result.data) {
        setIsFavorited(result.data.isFavorited)
        toast.success(result.data.isFavorited ? 'Guardado en favoritos' : 'Eliminado de favoritos')
      }
    })
  }

  if (isOwnListing) {
    return (
      <div className="flex flex-col gap-3">
        <button
          disabled
          title="Este es tu activo"
          className="flex items-center justify-center w-full px-4 py-3 rounded-lg bg-slate-700 text-slate-400 font-semibold text-base cursor-not-allowed"
        >
          Este es tu activo
        </button>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-3">
      <button
        onClick={handleConsult}
        disabled={isPendingConsult}
        className="flex items-center justify-center w-full px-4 py-3 rounded-lg bg-amber-500 text-navy-950 font-semibold text-base hover:bg-amber-400 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {isPendingConsult ? 'Cargando...' : 'Consultar al vendedor'}
      </button>

      <button
        onClick={handleFavorite}
        disabled={isPendingFav}
        className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-lg border border-amber-500 text-amber-500 font-medium text-base hover:bg-amber-500/10 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
      >
        <Heart className={`size-5 ${isFavorited ? 'fill-amber-500' : ''}`} />
        {isFavorited ? 'Guardado' : 'Guardar en favoritos'}
      </button>
    </div>
  )
}
