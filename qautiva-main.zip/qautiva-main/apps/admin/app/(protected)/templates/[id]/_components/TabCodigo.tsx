'use client'

import { useState, useEffect } from 'react'
import { updateTemplateCode } from '../../actions'
import type { ActionState } from '../../actions'

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar código'}
    </button>
  )
}

// Variables disponibles por defecto para documentación
const DEFAULT_VARIABLE_DOCS: Record<string, string> = {
  business_name: 'Nombre del negocio',
  tagline: 'Slogan o frase del negocio',
  primary_color: 'Color primario de la marca',
  secondary_color: 'Color secundario de la marca',
  logo_url: 'URL del logo',
  phone: 'Teléfono de contacto',
  whatsapp: 'Número de WhatsApp',
  address: 'Dirección física',
  email: 'Email de contacto',
  instagram_url: 'URL de Instagram',
  facebook_url: 'URL de Facebook',
}

interface TabCodigoProps {
  templateId: string
  htmlBase: string
  css: string
  variables: Record<string, string> | null
}

export function TabCodigo({
  templateId,
  htmlBase: initialHtml,
  css: initialCss,
  variables: initialVariables,
}: TabCodigoProps) {
  const [variablesJson, setVariablesJson] = useState(
    initialVariables ? JSON.stringify(initialVariables, null, 2) : '',
  )
  const [jsonError, setJsonError] = useState('')
  const [showSuccess, setShowSuccess] = useState(false)
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  useEffect(() => {
    if (state?.ok) {
      setShowSuccess(true)
      const t = setTimeout(() => setShowSuccess(false), 3000)
      return () => clearTimeout(t)
    }
  }, [state])

  function handleVariablesChange(value: string) {
    setVariablesJson(value)
    if (!value.trim()) {
      setJsonError('')
      return
    }
    try {
      JSON.parse(value)
      setJsonError('')
    } catch {
      setJsonError('JSON inválido')
    }
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', templateId)
    formData.set('variables', variablesJson)
    try {
      const result = await updateTemplateCode(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-5">
      {/* HTML base */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="htmlBase" className="text-sm font-medium text-[#94A3B8]">
          HTML base
        </label>
        <p className="text-[#64748B] text-xs">
          Usá <code className="text-[#8B5CF6]">{'{business_name}'}</code>,{' '}
          <code className="text-[#8B5CF6]">{'{primary_color}'}</code>, etc. como variables.
        </p>
        <textarea
          id="htmlBase"
          name="htmlBase"
          defaultValue={initialHtml}
          rows={14}
          spellCheck={false}
          placeholder="<!DOCTYPE html>..."
          className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm font-mono placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors resize-y"
        />
      </div>

      {/* CSS */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="css" className="text-sm font-medium text-[#94A3B8]">
          CSS
        </label>
        <textarea
          id="css"
          name="css"
          defaultValue={initialCss}
          rows={8}
          spellCheck={false}
          placeholder=":root { --primary: {primary_color}; } ..."
          className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm font-mono placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors resize-y"
        />
      </div>

      {/* Variables */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="variables" className="text-sm font-medium text-[#94A3B8]">
          Variables disponibles{' '}
          <span className="text-[#64748B] font-normal">(JSON)</span>
        </label>
        <p className="text-[#64748B] text-xs">
          Definí qué variables acepta este template y su descripción para el editor.
        </p>
        <textarea
          id="variables"
          value={variablesJson}
          onChange={(e) => handleVariablesChange(e.target.value)}
          rows={6}
          spellCheck={false}
          placeholder={JSON.stringify(DEFAULT_VARIABLE_DOCS, null, 2)}
          className={`px-3 py-2 bg-[#0B0F1A] border rounded-lg text-white text-sm font-mono placeholder-[#475569] focus:outline-none transition-colors resize-y ${
            jsonError ? 'border-red-400/50 focus:border-red-400' : 'border-[#1E293B] focus:border-[#8B5CF6]'
          }`}
        />
        {jsonError && <p className="text-xs text-red-400">{jsonError}</p>}
      </div>

      <div className="flex items-center gap-3 pt-2 border-t border-[#1E293B]">
        <SaveButton pending={isPending} />
        {showSuccess && <p className="text-sm text-green-400">Guardado correctamente.</p>}
        {state && !state.ok && <p className="text-sm text-red-400">{state.error}</p>}
      </div>
    </form>
  )
}
