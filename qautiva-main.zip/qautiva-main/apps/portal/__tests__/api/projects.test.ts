import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockGetUser = vi.fn()
const mockUserProfileFindUnique = vi.fn()
const mockProjectFindFirst = vi.fn()
const mockProjectCreate = vi.fn()
const mockProjectUpdate = vi.fn()
const mockStageCreateMany = vi.fn()
const mockOrganizationCreate = vi.fn()
const mockStageUpdateMany = vi.fn()
const mockUserProfileUpdate = vi.fn()
const mockTransaction = vi.fn()

vi.mock('@supabase/ssr', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/cache', () => ({
  revalidatePath: vi.fn(),
}))

vi.mock('@/app/_lib/project-slug', () => ({
  buildSlug: vi.fn().mockReturnValue('mi-negocio-abc123'),
}))

vi.mock('@/app/_lib/organization-legacy', () => ({
  createOrganizationLegacy: vi.fn().mockResolvedValue({ id: 'org-1' }),
}))

vi.mock('@/app/onboarding/_constants/industries', () => ({
  INDUSTRIES: ['Tecnología', 'Gastronomía', 'Salud', 'Retail'],
}))

const mockTeam = { id: 'team-1' }
const mockProfile = {
  id: 'profile-1',
  teamMemberships: [{ team: mockTeam, teamId: 'team-1' }],
}
const mockProfileWithTeamIds = {
  id: 'profile-1',
  teamMemberships: [{ teamId: 'team-1' }],
}
// UUID v4 válido — la ruta valida el formato antes del IDOR check
const PROJECT_UUID = '00000000-0000-4000-a000-000000000001'

const mockProject = {
  id: PROJECT_UUID,
  teamId: 'team-1',
  name: 'Mi Negocio',
  slug: 'mi-negocio-abc123',
  industry: 'Tecnología',
}

vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: { findUnique: mockUserProfileFindUnique },
    project: {
      findFirst: mockProjectFindFirst,
      create: mockProjectCreate,
      update: mockProjectUpdate,
    },
    $transaction: mockTransaction,
  },
  Prisma: {},
}))

function makeRequest(body: unknown) {
  return new Request('http://localhost:3001/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

describe('POST /api/projects', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockProjectFindFirst.mockReset()
    mockProjectCreate.mockReset()
    mockProjectUpdate.mockReset()
    mockStageCreateMany.mockReset()
    mockOrganizationCreate.mockReset()
    mockStageUpdateMany.mockReset()
    mockUserProfileUpdate.mockReset()
    mockTransaction.mockReset()

    mockTransaction.mockImplementation(async (cb: (tx: unknown) => unknown) => {
      const tx = {
        project: { update: mockProjectUpdate },
        stage: { createMany: mockStageCreateMany, updateMany: mockStageUpdateMany },
        organization: { create: mockOrganizationCreate },
        userProfile: { update: mockUserProfileUpdate },
      }
      return cb(tx)
    })
    mockProjectUpdate.mockResolvedValue({})
    mockStageCreateMany.mockResolvedValue({ count: 1 })
    mockOrganizationCreate.mockResolvedValue({ id: 'org-1' })
    mockStageUpdateMany.mockResolvedValue({})
    mockUserProfileUpdate.mockResolvedValue({})
  })

  // ── Auth ──────────────────────────────────────────────────────────────────

  it('devuelve 401 si no hay usuario', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: null } })
    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 1, name: 'Test', industry: 'Tecnología' }))
    expect(res.status).toBe(401)
  })

  it('devuelve 403 si onboarding no está completo', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: false } } },
    })
    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 1, name: 'Test', industry: 'Tecnología' }))
    expect(res.status).toBe(403)
  })

  // ── Step 1 ────────────────────────────────────────────────────────────────

  it('step1 con datos válidos: crea Project y retorna projectId', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)
    // Segunda llamada: checkTeamPermission
    mockUserProfileFindUnique.mockResolvedValueOnce({ teamMemberships: [{ role: 'ADMIN' }] })
    mockProjectCreate.mockResolvedValueOnce({ id: 'project-1' })

    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 1, name: 'Mi Negocio', industry: 'Tecnología' }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.projectId).toBe('project-1')
    expect(mockProjectCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          name: 'Mi Negocio',
          industry: 'Tecnología',
          status: 'SETUP',
          selectedServices: [],
        }),
      }),
    )
  })

  it('step1 sin nombre: retorna 400', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)
    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 1, industry: 'Tecnología' }))
    expect(res.status).toBe(400)
  })

  it('step1 con industria inválida: retorna 400', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)
    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 1, name: 'Mi Negocio', industry: 'Industria Falsa XYZ' }))
    expect(res.status).toBe(400)
  })

  it('step1 con nombre de más de 100 chars: retorna 400', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfile)
    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 1, name: 'A'.repeat(101), industry: 'Tecnología' }))
    expect(res.status).toBe(400)
  })

  // ── Step 2 ────────────────────────────────────────────────────────────────

  it('step2 con datos válidos: crea Stages + Org + pone status GENERATING', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfileWithTeamIds)
    mockProjectFindFirst.mockResolvedValueOnce(mockProject)
    // Segunda llamada: checkTeamPermission
    mockUserProfileFindUnique.mockResolvedValueOnce({ teamMemberships: [{ role: 'ADMIN' }] })

    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 2, projectId: PROJECT_UUID, services: ['BRAND', 'WEBSITE'] }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.projectId).toBe(PROJECT_UUID)
    expect(mockStageCreateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.arrayContaining([
          expect.objectContaining({ name: 'Marca' }),
          expect.objectContaining({ name: 'Sitio web' }),
        ]),
      }),
    )
    expect(mockProjectUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'GENERATING' }),
      }),
    )
  })

  it('step2 sin servicios: retorna 400', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfileWithTeamIds)
    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 2, projectId: 'project-1', services: [] }))
    expect(res.status).toBe(400)
  })

  it('step2 con projectId de otro usuario: retorna 404 (IDOR check)', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-2', app_metadata: { onboarding_complete: true } } },
    })
    // El perfil del usuario 2 tiene team-2, pero el proyecto pertenece a team-1
    mockUserProfileFindUnique.mockResolvedValueOnce({
      id: 'profile-2',
      teamMemberships: [{ teamId: 'team-2' }],
    })
    mockProjectFindFirst.mockResolvedValueOnce(null) // no encontrado porque teamId no coincide

    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 2, projectId: 'project-1', services: ['BRAND'] }))
    expect(res.status).toBe(404)
  })

  it('step2 con projectId inexistente: retorna 404', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'u-1', app_metadata: { onboarding_complete: true } } },
    })
    mockUserProfileFindUnique.mockResolvedValueOnce(mockProfileWithTeamIds)
    mockProjectFindFirst.mockResolvedValueOnce(null)

    const { POST } = await import('../../app/api/projects/route')
    const res = await POST(makeRequest({ step: 2, projectId: 'id-que-no-existe', services: ['BRAND'] }))
    expect(res.status).toBe(404)
  })
})
