import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

/**
 * GET /api/stitch/accounts
 *
 * Lista todas las cuentas Stitch registradas con sus créditos actuales.
 * Resetea usedToday si lastResetAt es de un día anterior (inline reset).
 */
export async function GET(_req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Reset inline de cuentas con lastResetAt anterior a hoy
  await prisma.stitchAccount.updateMany({
    where: {
      active: true,
      lastResetAt: { lt: today },
    },
    data: {
      usedToday: 0,
      lastResetAt: new Date(),
    },
  })

  const accounts = await prisma.stitchAccount.findMany({
    select: {
      id: true,
      label: true,
      // apiKey NUNCA se devuelve en respuestas
      usedToday: true,
      dailyLimit: true,
      lastResetAt: true,
      active: true,
      createdAt: true,
    },
    orderBy: { createdAt: 'asc' },
  })

  return NextResponse.json({ accounts })
}

/**
 * POST /api/stitch/accounts
 *
 * Registra una nueva cuenta Stitch.
 * Body: { label, apiKey, dailyLimit? }
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: { label: string; apiKey: string; dailyLimit?: number }
  try {
    body = (await req.json()) as { label: string; apiKey: string; dailyLimit?: number }
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { label, apiKey, dailyLimit } = body

  if (!label || !label.trim()) {
    return NextResponse.json({ error: 'label es requerido' }, { status: 400 })
  }
  if (!apiKey || !apiKey.trim()) {
    return NextResponse.json({ error: 'apiKey es requerido' }, { status: 400 })
  }
  if (dailyLimit !== undefined && (typeof dailyLimit !== 'number' || dailyLimit < 1)) {
    return NextResponse.json({ error: 'dailyLimit debe ser un número positivo' }, { status: 400 })
  }

  const account = await prisma.stitchAccount.create({
    data: {
      label: label.trim(),
      apiKey: apiKey.trim(),
      ...(dailyLimit !== undefined ? { dailyLimit } : {}),
    },
    select: {
      id: true,
      label: true,
      usedToday: true,
      dailyLimit: true,
      active: true,
      createdAt: true,
    },
  })

  return NextResponse.json({ account }, { status: 201 })
}
