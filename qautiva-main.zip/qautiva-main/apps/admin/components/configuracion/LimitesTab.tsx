'use client'

import { useState, useEffect } from 'react'
import { saveFeeConfig } from '@/app/(protected)/configuracion/actions'
import type { ActionState } from '@/app/(protected)/configuracion/actions'
import type { FeeConfig } from '@qautiva/db'
import { SubmitButton } from './shared'

interface Props {
  feeConfigs: FeeConfig[]
}

const PLAN_LABELS: Record<string, string> = {
  FREE_TRIAL:  'Trial gratuito',
  PREPAID:     'Prepago',
  MONTHLY:     'Mensual',
  YEARLY:      'Anual',
}

const SOURCE_LABELS: Record<string, string> = {
  BYOK:            'BYOK (clave propia)',
  QAUTIVA_HOSTED:  'Hosted (Qautiva)',
}


function FeeRow({ fee }: { fee: FeeConfig }) {
  const [editing, setEditing] = useState(false)
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  // Cerrar el form solo cuando la action confirma éxito — no antes (ALTO-2)
  useEffect(() => {
    if (state?.ok) setEditing(false)
  }, [state])

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await saveFeeConfig(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <tr className="border-b border-[#1E293B] last:border-0">
      <td className="px-4 py-3 text-sm text-[#94A3B8]">
        {PLAN_LABELS[fee.plan] ?? fee.plan}
      </td>
      <td className="px-4 py-3 text-sm text-[#94A3B8]">
        {SOURCE_LABELS[fee.keySource] ?? fee.keySource}
      </td>
      <td className="px-4 py-3 text-sm text-white font-mono">
        {Number(fee.feePercentage).toFixed(2)}%
      </td>
      <td className="px-4 py-3 text-sm text-[#64748B]">
        {fee.description ?? '—'}
      </td>
      <td className="px-4 py-3">
        <span className={`text-xs px-2 py-0.5 rounded-full ${
          fee.isActive
            ? 'bg-[#10B981]/10 text-[#10B981]'
            : 'bg-[#1E293B] text-[#475569]'
        }`}>
          {fee.isActive ? 'Activo' : 'Inactivo'}
        </span>
      </td>
      <td className="px-4 py-3">
        {editing ? (
          <form action={handleSubmit} className="flex items-center gap-2">
            <input type="hidden" name="id" value={fee.id} />
            <input
              type="number"
              name="feePercentage"
              aria-label="Fee (%)"
              defaultValue={Number(fee.feePercentage)}
              step="0.01"
              min="0"
              max="100"
              className="w-20 bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] text-white text-xs rounded px-2 py-1 outline-none"
            />
            <label className="flex items-center gap-1.5 text-xs text-[#94A3B8]">
              <input
                type="checkbox"
                name="isActive"
                defaultChecked={fee.isActive}
                className="accent-[#8B5CF6]"
              />
              Activo
            </label>
            <SubmitButton size="sm" pending={isPending} />
            <button
              type="button"
              onClick={() => setEditing(false)}
              className="text-xs text-[#64748B] hover:text-[#94A3B8] transition-colors"
            >
              Cancelar
            </button>
          </form>
        ) : (
          <div className="flex items-center gap-3">
            <button
              onClick={() => setEditing(true)}
              className="text-xs text-[#8B5CF6] hover:text-[#A78BFA] transition-colors"
            >
              Editar
            </button>
            {state && !state.ok && (
              <span className="text-xs text-[#EF4444]">{state.error}</span>
            )}
            {state?.ok && (
              <span className="text-xs text-[#10B981]">Guardado</span>
            )}
          </div>
        )}
      </td>
    </tr>
  )
}

export function LimitesTab({ feeConfigs }: Props) {
  return (
    <div className="pt-6">
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-[#1E293B]">
          <h2 className="text-white font-semibold">Fees por plan</h2>
          <p className="text-[#64748B] text-xs mt-1">
            Los fees se aplican sobre el costo de tokens de IA procesados.
          </p>
        </div>
        {feeConfigs.length === 0 ? (
          <p className="px-5 py-8 text-[#64748B] text-sm text-center">
            No hay configuraciones de fee. Creá registros desde la DB.
          </p>
        ) : (
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-[#1E293B]">
                {['Plan', 'Fuente de key', 'Fee %', 'Descripción', 'Estado', 'Acciones'].map(h => (
                  <th key={h} className="px-4 py-2.5 text-xs font-medium text-[#64748B] uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {feeConfigs.map(fee => (
                <FeeRow key={fee.id} fee={fee} />
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
