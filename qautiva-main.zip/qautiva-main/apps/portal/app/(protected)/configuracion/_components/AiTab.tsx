'use client'

import { useState, useTransition } from 'react'
import { ApiKeyCard, type ApiKeyData } from './ApiKeyCard'
import { AddApiKeyForm } from './AddApiKeyForm'

type Props = {
  apiKeys: ApiKeyData[]
  preferredKeySource: string
  billingPlan: string
}

export function AiTab({ apiKeys: initialKeys, preferredKeySource: initialSource }: Props) {
  const [isPending, startTransition] = useTransition()
  const [keys, setKeys] = useState<ApiKeyData[]>(initialKeys)
  const [keySource, setKeySource] = useState(initialSource)
  const [showAddForm, setShowAddForm] = useState(false)
  const [modeError, setModeError] = useState<string | null>(null)
  const [revokeError, setRevokeError] = useState<string | null>(null)

  function handleModeChange(newSource: string) {
    if (newSource === keySource || isPending) return
    setModeError(null)

    startTransition(async () => {
      const res = await fetch('/api/settings/ai-mode', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preferredKeySource: newSource }),
      })
      const data = await res.json()
      if (!res.ok) {
        setModeError(data.error ?? 'Error al cambiar el modo')
        return
      }
      setKeySource(newSource)
    })
  }

  async function handleRevoke(id: string) {
    setRevokeError(null)
    const res = await fetch(`/api/settings/api-keys/${id}`, { method: 'DELETE' })
    const data = await res.json()
    if (!res.ok) {
      setRevokeError(data.error ?? 'Error al revocar la key')
      return
    }
    setKeys((prev) => prev.filter((k) => k.id !== id))
  }

  function handleAdded(newKey: ApiKeyData) {
    setKeys((prev) => [...prev, newKey])
    setShowAddForm(false)
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Modo de IA */}
      <section>
        <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
          Modo de IA
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={() => handleModeChange('QAUTIVA_HOSTED')}
            disabled={isPending}
            className={`
              p-4 rounded-xl border text-left transition-all disabled:opacity-50
              ${keySource === 'QAUTIVA_HOSTED'
                ? 'border-[#8B5CF6] bg-[#8B5CF6]/10'
                : 'border-[#1E293B] bg-[#0F172A] hover:border-[#334155]'
              }
            `}
          >
            <p className="text-white text-sm font-medium mb-1">Keys de Qautiva</p>
            <p className="text-[#94A3B8] text-xs">Usamos nuestras propias keys. Más simple, sin configuración.</p>
          </button>

          <button
            onClick={() => handleModeChange('BYOK')}
            disabled={isPending}
            className={`
              p-4 rounded-xl border text-left transition-all disabled:opacity-50
              ${keySource === 'BYOK'
                ? 'border-[#8B5CF6] bg-[#8B5CF6]/10'
                : 'border-[#1E293B] bg-[#0F172A] hover:border-[#334155]'
              }
            `}
          >
            <p className="text-white text-sm font-medium mb-1">Tus propias keys</p>
            <p className="text-[#94A3B8] text-xs">Conectás tus propias API keys de Anthropic, OpenAI o Google. Más control, sin pasar por Qautiva.</p>
          </button>
        </div>

        {modeError && (
          <div className="mt-3 bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm rounded-lg px-4 py-2">
            {modeError}
          </div>
        )}
      </section>

      {/* API Keys */}
      <section>
        <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
          Tus API keys
        </h2>
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl px-5">
          {keys.length > 0 ? (
            keys.map((k) => (
              <ApiKeyCard key={k.id} apiKey={k} onRevoke={handleRevoke} />
            ))
          ) : (
            <p className="text-[#94A3B8] text-sm py-4">No tenés API keys configuradas.</p>
          )}

          {revokeError && (
            <div className="my-2 bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm rounded-lg px-4 py-2">
              {revokeError}
            </div>
          )}

          {showAddForm ? (
            <AddApiKeyForm onAdded={handleAdded} onCancel={() => setShowAddForm(false)} />
          ) : (
            <div className="py-4">
              <button
                onClick={() => setShowAddForm(true)}
                className="text-[#A78BFA] hover:text-[#8B5CF6] text-sm font-medium transition-colors"
              >
                + Agregar API key
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
