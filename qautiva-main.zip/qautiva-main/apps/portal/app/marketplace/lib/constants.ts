import { MediumPlatform } from '@qautiva/db/types'

export const PLATFORM_LABEL: Record<MediumPlatform, string> = {
  WEBSITE: 'Web',
  INSTAGRAM: 'Instagram',
  FACEBOOK: 'Facebook',
  TWITTER: 'X (Twitter)',
  TIKTOK: 'TikTok',
  YOUTUBE: 'YouTube',
}

export const PLATFORM_COLOR: Record<MediumPlatform, string> = {
  WEBSITE: 'bg-[#1E3A5F] text-[#60A5FA]',
  INSTAGRAM: 'bg-[#4A1942] text-[#F472B6]',
  FACEBOOK: 'bg-[#1E3A5F] text-[#93C5FD]',
  TWITTER: 'bg-[#0F2942] text-[#38BDF8]',
  TIKTOK: 'bg-[#0F2E2A] text-[#34D399]',
  YOUTUBE: 'bg-[#3B1414] text-[#F87171]',
}

export const PLATFORM_OPTIONS = [
  { value: '', label: 'Todas las plataformas' },
  { value: 'WEBSITE', label: 'Web' },
  { value: 'INSTAGRAM', label: 'Instagram' },
  { value: 'FACEBOOK', label: 'Facebook' },
  { value: 'TWITTER', label: 'X (Twitter)' },
  { value: 'TIKTOK', label: 'TikTok' },
  { value: 'YOUTUBE', label: 'YouTube' },
] as const

export const SORT_OPTIONS = [
  { value: 'relevancia', label: 'Relevancia' },
  { value: 'seguidores-desc', label: 'Más seguidores' },
] as const

/** Regex para validar UUID v4 */
export const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
