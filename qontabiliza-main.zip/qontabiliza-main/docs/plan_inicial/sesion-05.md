# Sesión 05: Facturación ARCA (backend)

## Objetivo
Integración completa con ARCA vía Afip SDK. Servicio de facturación que genera comprobantes electrónicos (Factura A/B/C, NC/ND). Gestión de certificados por tenant. Tests contra el entorno de homologación de ARCA. Al terminar, se pueden emitir facturas electrónicas reales (en modo testing).

## Pre-requisitos
- Sesión 04 completada (contactos con datos fiscales, productos con precios)
- Instalar dependencia: `@afipsdk/afip.js` (npm package del Afip SDK)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `prisma/schema.prisma` — revisar modelos Invoice, InvoiceItem
3. Leer `src/lib/validations/contact.ts` — entender validación de CUIT
4. Investigar API de `@afipsdk/afip.js` — métodos principales:
   - `new Afip({ CUIT, cert, key, production })` — constructor
   - `afip.ElectronicBilling.createVoucher(data)` — crear comprobante
   - `afip.ElectronicBilling.getLastVoucher(pointOfSale, voucherType)` — último número
   - `afip.ElectronicBilling.getVoucherInfo(number, pointOfSale, voucherType)` — consultar

---

## Etapa 1: Servicio ARCA (Afip SDK wrapper)

### Tarea 1.1: Instalar Afip SDK
**Comando**: `npm install @afipsdk/afip.js`

### Tarea 1.2: Servicio AfipService
**Archivo nuevo**: `src/lib/services/afip-service.ts`

```typescript
// Clase AfipService que wrappea Afip SDK para Qontabiliza.
// Constructor recibe datos del tenant: CUIT, certificado, clave, environment, punto de venta.
//
// Métodos públicos:
//
// createInvoice(params: CreateInvoiceParams): Promise<AfipInvoiceResult>
//   - Determina tipo de comprobante según condición IVA del emisor y receptor
//   - Obtiene último número de comprobante para ese tipo y punto de venta
//   - Llama a createVoucher con los datos formateados
//   - Retorna: { cae, caeExpiration, voucherNumber, fullResult }
//
// createCreditNote(params: CreateCreditNoteParams): Promise<AfipInvoiceResult>
//   - Similar pero para NC, con referencia al comprobante original
//
// createDebitNote(params: CreateDebitNoteParams): Promise<AfipInvoiceResult>
//   - Similar pero para ND
//
// getLastVoucherNumber(voucherType: number, pointOfSale: number): Promise<number>
//
// getVoucherInfo(number: number, pointOfSale: number, voucherType: number)
//
// Métodos privados:
//
// determineVoucherType(emisorIva, receptorIva, isCredit, isDebit): number
//   - RI → RI: Factura A (1), NC A (3), ND A (2)
//   - RI → CF/Mono/Exento: Factura B (6), NC B (8), ND B (7)
//   - Mono → cualquiera: Factura C (11), NC C (13), ND C (12)
//
// formatVoucherData(params): AfipVoucherData
//   - Formatea fechas a YYYYMMDD
//   - Calcula neto gravado, IVA, total
//   - Agrupa IVA por alícuota
//   - Estructura según requerimientos de ARCA
```

### Tarea 1.3: Tipos para facturación
**Archivo nuevo**: `src/types/invoice.ts`

```typescript
// Interfaces:
// - CreateInvoiceParams { contactId, items[], organizationId }
// - InvoiceItemParam { productId?, description, quantity, unitPrice, ivaRate }
// - AfipInvoiceResult { cae, caeExpiration, voucherNumber, fullResult }
// - InvoiceResponse — lo que retorna la API al frontend
// - InvoiceListResponse — paginado
//
// Constantes:
// - VOUCHER_TYPES: mapeo de InvoiceType enum a código numérico de ARCA
//   FACTURA_A: 1, FACTURA_B: 6, FACTURA_C: 11, etc.
// - IVA_CODES: mapeo de alícuota a código de ARCA
//   0%: 3, 2.5%: 9, 5%: 8, 10.5%: 4, 21%: 5, 27%: 6
```

**Commit**: `feat(arca): add AfipService wrapper for electronic billing`

---

## Etapa 2: Servicio de facturación de negocio

### Tarea 2.1: InvoiceService
**Archivo nuevo**: `src/lib/services/invoice-service.ts`

```typescript
// Servicio de nivel de negocio que orquesta la creación de facturas.
// NO conoce Afip SDK directamente — usa AfipService.
//
// Métodos:
//
// createInvoice(params): Promise<Invoice>
//   1. Validar datos del contacto (tiene CUIT si es Factura A)
//   2. Validar datos de la organización (tiene certificado ARCA configurado)
//   3. Calcular montos: subtotal, IVA por alícuota, total
//   4. Llamar AfipService.createInvoice()
//   5. Si ARCA autoriza:
//      - Guardar Invoice en DB con CAE y número
//      - Guardar InvoiceItems
//      - Retornar invoice completa
//   6. Si ARCA rechaza:
//      - Guardar Invoice en DB con status REJECTED y el error en arcaResult
//      - Retornar con error descriptivo
//
// createCreditNote(invoiceId, items?): Promise<Invoice>
//   1. Cargar factura original
//   2. Si no se pasan items, NC por el total
//   3. Llamar AfipService.createCreditNote() con referencia a original
//   4. Guardar con relatedInvoiceId = invoiceId
//   5. Actualizar factura original: status = CANCELLED (si NC es por el total)
//
// getNextNumber(organizationId, voucherType, pointOfSale): Promise<number>
//   - Consulta ARCA por último número y retorna +1
//
// calculateTotals(items: InvoiceItemParam[]): InvoiceTotals
//   - Calcula subtotal (neto gravado), IVA desglosado por alícuota, total
//   - Este método es puro (sin side effects) — fácil de testear
```

### Tarea 2.2: Tests unitarios de InvoiceService
**Archivo nuevo**: `src/lib/services/__tests__/invoice-service.test.ts`

Tests:
- `calculateTotals`: cálculo correcto con IVA 21%, 10.5%, mezcla de alícuotas, items sin IVA
- `calculateTotals`: redondeo a 2 decimales
- `determineVoucherType`: RI→RI = A, RI→CF = B, Mono→cualquiera = C
- Mock de AfipService para testear flujo de `createInvoice` sin llamar a ARCA real

### Tarea 2.3: Tests contra homologación ARCA
**Archivo nuevo**: `src/lib/services/__tests__/afip-service.integration.test.ts`

Tests de integración (se ejecutan contra entorno testing de ARCA):
- Crear Factura B a Consumidor Final (caso más simple)
- Obtener último número de comprobante
- Consultar comprobante recién creado

**Nota**: Afip SDK tiene un modo testing automático. Se usa CUIT de testing 20409378472 (CUIT de prueba de ARCA).

**Commit**: `feat(invoicing): add InvoiceService with business logic and tests`

---

## Etapa 3: API routes de facturación

### Tarea 3.1: Validaciones Zod para Invoice
**Archivo nuevo**: `src/lib/validations/invoice.ts`

Schemas:
- `createInvoiceSchema`:
  - contactId (cuid, requerido)
  - type (opcional — se auto-determina por condición IVA, pero se puede forzar)
  - items: array de { productId?, description, quantity (min 0.0001), unitPrice (min 0), ivaRate }
  - Validar que items no esté vacío
- `invoiceFilterSchema`: search, type, status, contactId, dateFrom, dateTo, page, perPage
- `createCreditNoteSchema`: invoiceId (cuid), items? (opcional, si no se envía es NC por el total)

### Tarea 3.2: API routes
**Archivos nuevos**:
- `src/app/api/v1/invoices/route.ts` — GET (list), POST (crear y enviar a ARCA)
- `src/app/api/v1/invoices/[id]/route.ts` — GET (detalle con items)
- `src/app/api/v1/invoices/[id]/credit-note/route.ts` — POST (emitir NC asociada)

Comportamiento POST crear:
1. Validar input con Zod
2. Validar tenant + permisos
3. Llamar `InvoiceService.createInvoice()`
4. Retornar factura con CAE o error de ARCA

Comportamiento GET list:
- Paginado
- Filtros: tipo, estado, contacto, rango de fechas
- Incluir nombre del contacto
- Ordenado por fecha descendente

### Tarea 3.3: Configuración ARCA por tenant
**Archivo nuevo**: `src/app/api/v1/organizations/[id]/arca-config/route.ts`

Endpoints:
- GET: retornar estado de configuración ARCA (tiene cert? tiene punto de venta? environment)
- PUT: actualizar certificado, clave, punto de venta, environment
  - Validar que el certificado y clave sean PEM válidos
  - Validar conectividad con ARCA (llamar getLastVoucher para verificar)

Este endpoint se usa en la página de configuración de la organización para subir el certificado digital.

**Commit**: `feat(api): add Invoice endpoints and ARCA configuration`

---

## Etapa 4: Gestión de certificados y seguridad

### Tarea 4.1: Upload de certificado ARCA
**Archivo nuevo**: `src/lib/services/arca-config-service.ts`

```typescript
// Servicio para gestionar la configuración ARCA de un tenant:
//
// validateCertificate(certPem: string, keyPem: string): boolean
//   - Verificar que el PEM es un certificado X.509 válido
//   - Verificar que la key matchea el certificado
//
// testConnection(org: Organization): Promise<{ success: boolean, error?: string }>
//   - Intenta llamar getLastVoucher a ARCA
//   - Retorna success o el error descriptivo
//
// Nota de seguridad:
//   - Los certificados se guardan en DB encriptados (campo @db.Text)
//   - En producción se debería usar un servicio de secretos (ej: Vault, AWS Secrets Manager)
//   - Para el MVP, guardar en DB es aceptable
```

### Tarea 4.2: UI de configuración ARCA
**Archivo nuevo**: `src/app/dashboard/settings/arca/page.tsx`

Página en Settings → Configuración ARCA:
- Estado actual: ✅ Configurado / ❌ No configurado
- Upload de certificado (.crt/.pem) y clave privada (.key/.pem)
- Input de punto de venta (número)
- Toggle testing/producción
- Botón "Probar conexión" que llama testConnection
- Instrucciones de cómo obtener el certificado en ARCA (link a documentación)

### Tarea 4.3: Tests de integración API
**Archivo nuevo**: `src/app/api/v1/invoices/__tests__/invoices.test.ts`

Tests:
- Crear factura (con mock de AfipService)
- Listar facturas con filtros
- Obtener detalle de factura
- Emitir nota de crédito
- Validación: no permitir factura A a consumidor final
- Tenant isolation

**Commit**: `feat(arca): add certificate management, ARCA settings page, and tests`

---

## Checklist de cierre de sesión

- [ ] Afip SDK instalado y configurado
- [ ] AfipService wrapper funcional
- [ ] InvoiceService con lógica de negocio (cálculos, tipos de comprobante)
- [ ] API routes de facturación (crear, listar, detalle, NC)
- [ ] Configuración ARCA por tenant (certificados, punto de venta)
- [ ] Tests unitarios de cálculos y determinación de tipo
- [ ] Tests de integración contra homologación ARCA
- [ ] Tests de API routes
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
