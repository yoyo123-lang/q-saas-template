import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { Prisma, prisma, createServiceClient } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { encrypt, keyHint } from '@/lib/encryption'
import { validateApiKey } from '@/app/_lib/validate-api-key'
import type { User } from '@supabase/supabase-js'

const VALID_MODES = ['trial', 'hosted', 'byok'] as const

/**
 * POST /api/onboarding
 * Paso 2: configura el modo de IA (trial / hosted / byok). No crea Project ni Organization.
 * Requiere sesión Supabase válida.
 */
export async function POST(request: Request) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const step = typeof body.step === 'number' ? body.step : Number(body.step)

  if (step === 2) return handleStep2(body, user)

  return NextResponse.json({ error: 'Step inválido' }, { status: 400 })
}

/**
 * Paso 2: configura el modo de IA del usuario (trial / hosted / byok).
 * - trial: aplica tokens gratuitos con TTL desde TrialConfig
 * - hosted: plan PREPAID con keys de Qautiva (saldo $0, no bloquea)
 * - byok: encripta la API key con AES-256-GCM y la valida contra el proveedor (timeout 10s)
 * Marca onboarding_complete en Supabase. Retorna { ok: true }.
 * NO crea Project, Stages ni Organization.
 */
async function handleStep2(body: Record<string, unknown>, user: User) {
  const authUserId = user.id
  const mode = body.mode as 'trial' | 'hosted' | 'byok' | undefined

  if (!mode) {
    return NextResponse.json({ error: 'mode es obligatorio' }, { status: 400 })
  }

  if (!(VALID_MODES as readonly string[]).includes(mode)) {
    return NextResponse.json({ error: 'Mode inválido' }, { status: 400 })
  }

  let profile = await prisma.userProfile.findUnique({
    where: { authUserId },
    include: {
      teamMemberships: {
        include: { team: { include: { billing: true } } },
        orderBy: { createdAt: 'asc' },
        take: 1,
      },
    },
  })

  // Lazy creation: si el trigger handle_new_user falló silenciosamente,
  // crear UserProfile + Team + TeamMember + BillingAccount acá.
  if (!profile || profile.teamMemberships.length === 0) {
    profile = await ensureProfileWithTeam(authUserId, user)
  }

  const membership = profile.teamMemberships[0]!
  const team = membership.team
  const billing = team.billing

  if (!billing) {
    console.warn(`[onboarding] step2: team ${team.id} no tiene BillingAccount.`)
  }

  try {
    await prisma.$transaction(async (tx) => {
      if (mode === 'trial') {
        await applyTrialMode(tx, team.id, billing?.id)
      } else if (mode === 'hosted') {
        await applyHostedMode(tx, team.id, billing?.id)
      } else if (mode === 'byok') {
        await applyByokMode(tx, body, team.id, billing?.id)
      }

      await tx.userProfile.update({
        where: { id: profile.id },
        data: { onboardingStep: 2 },
      })
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Error interno'
    return NextResponse.json({ error: message }, { status: 400 })
  }

  const serviceClient = createServiceClient()
  await serviceClient.auth.admin.updateUserById(authUserId, {
    app_metadata: { onboarding_complete: true },
  })

  return NextResponse.json({ ok: true })
}

// ── Lazy creation (recuperación si el trigger falló) ──────────────────────────

type ProfileWithTeam = Prisma.UserProfileGetPayload<{
  include: {
    teamMemberships: {
      include: { team: { include: { billing: true } } }
    }
  }
}>

/**
 * Crea UserProfile + Team + TeamMember + BillingAccount si el trigger
 * handle_new_user falló silenciosamente al registrar al usuario.
 * Replica la misma lógica del trigger SQL para mantener consistencia.
 */
async function ensureProfileWithTeam(authUserId: string, user: User): Promise<ProfileWithTeam> {
  const displayName =
    user.user_metadata?.full_name ??
    user.user_metadata?.name ??
    user.email?.split('@')[0] ??
    'usuario'
  const email = user.email ?? ''

  const result = await prisma.$transaction(async (tx) => {
    // Crear o recuperar UserProfile (idempotente por unique authUserId)
    const profileRecord = await tx.userProfile.upsert({
      where: { authUserId },
      create: {
        authUserId,
        displayName,
        email,
        onboardingStep: 1,
      },
      update: {},
    })

    // Verificar si ya tiene team membership
    const existingMembership = await tx.teamMember.findFirst({
      where: { userId: profileRecord.id },
      include: { team: { include: { billing: true } } },
    })

    if (existingMembership) {
      return { profile: profileRecord, membership: existingMembership }
    }

    // Crear Team personal
    const team = await tx.team.create({
      data: {
        name: displayName,
        slug: `team-${crypto.randomUUID().slice(0, 8)}`,
      },
    })

    // Crear TeamMember como OWNER
    const membership = await tx.teamMember.create({
      data: {
        teamId: team.id,
        userId: profileRecord.id,
        role: 'OWNER',
      },
      include: { team: { include: { billing: true } } },
    })

    // Crear BillingAccount con trial si está activo
    const trialConfig = await tx.trialConfig.findUnique({ where: { id: 1 } })
    const now = new Date()
    const trialActive =
      trialConfig?.isActive === true &&
      (!trialConfig.validFrom || trialConfig.validFrom <= now) &&
      (!trialConfig.validUntil || trialConfig.validUntil >= now)

    if (trialActive && trialConfig) {
      await tx.billingAccount.create({
        data: {
          teamId: team.id,
          plan: 'FREE_TRIAL',
          trialTokensTotal: trialConfig.tokenAmount,
          trialExpiresAt: new Date(now.getTime() + trialConfig.maxDurationDays * 24 * 60 * 60 * 1000),
        },
      })
    } else {
      await tx.billingAccount.create({
        data: {
          teamId: team.id,
          plan: 'PREPAID',
          trialTokensTotal: 0,
        },
      })
    }

    // Re-fetch membership con billing incluido
    const finalMembership = await tx.teamMember.findUniqueOrThrow({
      where: { id: membership.id },
      include: { team: { include: { billing: true } } },
    })

    return { profile: profileRecord, membership: finalMembership }
  })

  console.warn(`[onboarding] lazy-created profile for authUserId=${authUserId} (trigger may have failed)`)

  return {
    ...result.profile,
    teamMemberships: [result.membership],
  } as ProfileWithTeam
}

// ── Helpers de modo ────────────────────────────────────────────────────────────

async function applyTrialMode(
  tx: Prisma.TransactionClient,
  teamId: string,
  billingId: string | undefined,
) {
  const trialConfig = await tx.trialConfig.findUnique({ where: { id: 1 } })
  const trialDays = trialConfig?.maxDurationDays ?? 14
  const trialTokens = trialConfig?.tokenAmount ?? 50000

  if (billingId) {
    await tx.billingAccount.update({
      where: { teamId },
      data: {
        plan: 'FREE_TRIAL',
        preferredKeySource: 'QAUTIVA_HOSTED',
        trialTokensTotal: trialTokens,
        trialTokensUsed: 0,
        trialExpiresAt: new Date(Date.now() + trialDays * 24 * 60 * 60 * 1000),
      },
    })
  }
}

async function applyHostedMode(tx: Prisma.TransactionClient, teamId: string, billingId: string | undefined) {
  if (billingId) {
    await tx.billingAccount.update({
      where: { teamId },
      data: {
        preferredKeySource: 'QAUTIVA_HOSTED',
        plan: 'PREPAID',
      },
    })
  }
}

async function applyByokMode(tx: Prisma.TransactionClient, body: Record<string, unknown>, teamId: string, billingId: string | undefined) {
  const rawKey = (body.apiKey as string | undefined)?.trim()
  const provider = body.provider as 'ANTHROPIC' | 'OPENAI' | 'GOOGLE_GEMINI' | undefined

  const VALID_PROVIDERS = ['ANTHROPIC', 'OPENAI', 'GOOGLE_GEMINI']
  if (!rawKey || !provider || !VALID_PROVIDERS.includes(provider)) {
    throw new Error('apiKey y provider son obligatorios para modo BYOK')
  }

  const encryptedKey = encrypt(rawKey)
  const hint = keyHint(rawKey, 4)

  let isValid: boolean | null = null
  try {
    const result = await Promise.race([
      validateApiKey(provider, rawKey),
      new Promise<'timeout'>((resolve) => setTimeout(() => resolve('timeout'), 10000)),
    ])
    isValid = result === 'timeout' ? null : result
  } catch {
    isValid = null
  }

  await tx.apiKey.create({
    data: {
      teamId,
      provider,
      encryptedKey,
      keyHint: hint,
      isValid,
    },
  })

  if (billingId) {
    await tx.billingAccount.update({
      where: { teamId },
      data: {
        preferredKeySource: 'BYOK',
        plan: 'PREPAID',
      },
    })
  }
}
