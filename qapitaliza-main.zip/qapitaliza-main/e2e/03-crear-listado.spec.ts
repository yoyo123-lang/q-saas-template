import { test, expect } from '@playwright/test'

/**
 * E2E: Crear listado (wizard)
 * Requires: an authenticated SELLER session.
 * Set E2E_SELLER_EMAIL and E2E_SELLER_PASSWORD env vars.
 */

test.describe('Crear listado', () => {
  test.beforeEach(async ({ page }) => {
    if (!process.env.E2E_SELLER_EMAIL || !process.env.E2E_SELLER_PASSWORD) {
      test.skip()
      return
    }

    // Login as seller
    await page.goto('/login')
    await page.fill('input[type="email"]', process.env.E2E_SELLER_EMAIL)
    await page.fill('input[type="password"]', process.env.E2E_SELLER_PASSWORD)
    await page.click('button[type="submit"]')
    await expect(page).toHaveURL(/\/dashboard/, { timeout: 10000 })
  })

  test('Sidebar tiene link "Nuevo listado"', async ({ page }) => {
    await page.goto('/mis-activos')
    await expect(page.getByRole('link', { name: /nuevo listado/i })).toBeVisible()
  })

  test('Wizard de nuevo listado carga y muestra paso 1', async ({ page }) => {
    await page.goto('/mis-activos/nuevo')
    await expect(page.getByText(/información básica/i)).toBeVisible()
  })

  test('Wizard avanza al paso 2 con datos válidos', async ({ page }) => {
    await page.goto('/mis-activos/nuevo')

    // Fill step 1
    await page.fill('input[name="title"]', 'Mi activo de prueba E2E')
    await page.selectOption('select[name="type"]', 'WEBSITE')
    await page.fill('input[name="askingPrice"]', '5000')

    // Fill description (textarea)
    await page.fill('textarea[name="description"]', 'Descripción de prueba para el test E2E con suficiente longitud para pasar la validación mínima requerida.')

    await page.click('button:has-text("Continuar")')
    await expect(page.getByText(/métricas/i)).toBeVisible({ timeout: 5000 })
  })

  test('Mis activos muestra tabla o empty state', async ({ page }) => {
    await page.goto('/mis-activos')
    const hasContent =
      (await page.locator('table').count()) > 0 ||
      (await page.getByText(/sin activos|todavía no/i).count()) > 0
    expect(hasContent).toBe(true)
  })
})
