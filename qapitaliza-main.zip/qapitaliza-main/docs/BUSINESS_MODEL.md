# Modelo de Negocio

> Este archivo documenta las reglas de negocio del proyecto.
> Es la fuente de verdad para los roles de revisión de capa 2 (Business Logic, Data/Analytics).
> Sin este archivo completo, esos roles no pueden funcionar.

> **Estado**: Borrador inicial basado en documento de onboarding (2026-03-23).
> Requiere validación de Federico en: monetización, límites operativos, y políticas de baja.

---

## Tipo de proyecto

- [x] Marketplace

---

## Propuesta de valor

### ¿Qué problema resuelve?

Comprar un sitio web, dominio con historia o proyecto digital hoy implica moverse en plataformas internacionales (Flippa, Empire Flippers, Motion Invest), en inglés, con precios en USD altos y reglas pensadas para otro contexto. Quien tiene un proyecto digital que ya no atiende no tiene un canal claro para venderlo en el mercado hispanohablante. No existe un marketplace regional que combine activos digitales, MVPs vibecodeados, crowdfunding de proyectos, y fondos de comercio tradicionales.

### ¿Para quién? (segmentos de usuario)

1. **Emprendedores digitales** que quieren arrancar con algo que ya tiene tracción
2. **Marketers y agencias** que buscan dominios con antigüedad, sitios con tráfico, o proyectos encaminados
3. **Desarrolladores/vibecodeadores** que construyen MVPs y quieren monetizarlos sin operar el negocio
4. **Inversores** que buscan activos digitales con flujos de ingreso comprobables
5. **Micro-inversores** que quieren participar con montos chicos en proyectos en etapa temprana (crowdfunding, post-MVP)

### ¿Cómo se diferencia de alternativas?

- Único marketplace regional hispanohablante para activos digitales
- MVPs vibecodeados como categoría de producto (ningún otro marketplace los contempla)
- Validación de métricas integrada con ecosistema Q (Qobra para ingresos, Qontacta para base de clientes) — futuro
- Visión de extensión a fondos de comercio tradicionales y crowdfunding regulado

---

## Monetización

### Modelo de ingresos

> **Estado**: A definir. Opciones en evaluación:

- Comisión por transacción exitosa (% sobre precio de venta)
- Fee de listado (cobrar por publicar un activo)
- Freemium: listados básicos gratis, listados destacados pagos
- Combinación de las anteriores

### Planes y límites

> **Estado**: MVP sin billing. Definir post-validación.

| Plan | Precio | Límites | Features exclusivas |
|------|--------|---------|---------------------|
| MVP (único) | Gratis | Hasta 50 listados activos por vendedor | Todas las features del MVP |

### Ciclo de billing

- Período: No aplica en MVP (sin billing)
- Pasarela de pago: A definir. Probablemente MercadoPago (Fase 1.5 con crowdfunding)

---

## Reglas de negocio

> Estas son las reglas que el CÓDIGO debe cumplir. El Business Logic Reviewer valida contra esta lista.

### Autenticación y acceso

- Quién puede registrarse: Cualquier persona con email válido o cuenta de Google
- Métodos de login: email + password, Google OAuth
- Roles de usuario: BUYER, SELLER, ADMIN
- Un usuario puede tener un solo rol activo (un SELLER también puede comprar, pero su rol principal determina su dashboard)
- ADMIN solo se asigna manualmente (no hay auto-registro como admin)

### Qué puede hacer cada rol

| Acción | BUYER | SELLER | ADMIN |
|--------|-------|--------|-------|
| Explorar catálogo público | Si | Si | Si |
| Ver detalle de activo | Si | Si | Si |
| Agregar a favoritos | Si | Si | Si |
| Enviar consulta sobre un activo | Si | Si (no sobre sus propios activos) | Si |
| Crear/editar listados | No | Si | Si |
| Publicar listado (requiere moderación) | No | Si (pasa a PENDING_REVIEW) | Si (publicación directa) |
| Responder consultas recibidas | No | Si (solo las de sus listados) | Si |
| Moderar listados (aprobar/rechazar) | No | No | Si |
| Gestionar usuarios | No | No | Si |
| Ver métricas del marketplace | No | No | Si |

### Reglas por plan/rol

1. CUANDO un SELLER crea un listado ENTONCES el estado inicial es DRAFT
2. CUANDO un SELLER envía un listado a revisión ENTONCES el estado pasa a PENDING_REVIEW
3. CUANDO un ADMIN aprueba un listado ENTONCES el estado pasa a PUBLISHED y se registra publishedAt
4. CUANDO un ADMIN rechaza un listado ENTONCES el estado pasa a REJECTED con motivo obligatorio (mínimo 20 caracteres)
5. CUANDO un SELLER tiene 50 listados activos (PUBLISHED + PENDING_REVIEW + DRAFT) ENTONCES no puede crear más y ve mensaje de límite
6. CUANDO un BUYER envía más de 10 consultas en 24 horas ENTONCES se bloquea temporalmente con mensaje de rate limit
7. CUANDO un SELLER intenta consultar su propio listado ENTONCES se muestra error "No podés consultar tu propio activo"

### Reglas de dominio específicas

1. Todo listado requiere: título, tipo, descripción, precio, moneda. Los demás campos son opcionales
2. El slug se genera automáticamente desde el título y debe ser único. Si hay colisión, se agrega sufijo numérico
3. Un listado PUBLISHED puede ser pausado (PAUSED) por el vendedor en cualquier momento
4. Un listado PAUSED puede ser reactivado a PUBLISHED sin nueva moderación
5. Un listado marcado como SOLD no puede volver a activarse
6. Los screenshots se suben a Supabase Storage: máximo 5 imágenes, máximo 2MB cada una, solo JPG/PNG/WebP
7. Las métricas del activo (ingresos, tráfico, etc.) son autodeclaradas en MVP. El campo `source` indica el nivel de verificación
8. El viewCount se incrementa por visita única (no por refresh). Implementación mínima: por IP o por sesión
9. Los favoritos son privados del usuario. No se muestra contador público de favoritos en MVP
10. Las consultas (Inquiry) tienen un hilo de mensajes (InquiryMessage). Ambas partes pueden escribir
11. Una consulta OPEN pasa a REPLIED cuando el vendedor responde por primera vez
12. Una consulta puede cerrarse por cualquiera de las partes o por un admin
13. Baja de cuenta: soft-delete, datos se mantienen 90 días, listados pasan a PAUSED automáticamente

### Políticas de seguridad aplicadas al negocio

1. Rate limiting en login: máximo 5 intentos por minuto por IP
2. Rate limiting en registro: máximo 3 registros por hora por IP
3. Rate limiting en catálogo público: máximo 60 requests por minuto por IP
4. Rate limiting en consultas: máximo 10 consultas nuevas por día por usuario
5. Toda Server Action que modifica un listado DEBE verificar que `listing.sellerId === currentUser.id` (protección IDOR)
6. Toda Server Action que modifica una consulta DEBE verificar que el usuario es participante (buyer o seller del listing)

---

## Entidades de dominio

```
User (via Supabase Auth + tabla profiles)
  ├── Profile (1:1 — datos extendidos del usuario)
  ├── Listing[] (como vendedor)
  ├── Inquiry[] (como comprador)
  ├── Favorite[] (listados guardados)
  └── InquiryMessage[] (mensajes enviados)

Listing (activo listado para venta)
  ├── ListingMetric[] (métricas verificables)
  ├── Inquiry[] (consultas recibidas)
  ├── Favorite[] (usuarios que lo guardaron)
  └── Category (clasificación)

Category (tipos de activos)
  └── Category[] (subcategorías opcionales)

Inquiry (consulta comprador → vendedor)
  └── InquiryMessage[] (hilo de conversación)

AuditLog (registro de acciones administrativas)
```

### Invariantes de datos

1. Todo listing tiene exactamente un sellerId que referencia a un User existente con rol SELLER o ADMIN
2. Todo listing tiene un slug único a nivel global
3. Un listing con status SOLD no puede tener status diferente después (estado terminal)
4. Un listing con status REJECTED puede volver a DRAFT para edición
5. Todo inquiry tiene un buyerId diferente al sellerId del listing asociado
6. Todo inquiryMessage tiene un senderId que es el buyerId del inquiry O el sellerId del listing
7. El askingPrice de un listing debe ser > 0
8. No puede haber dos favoritos del mismo usuario para el mismo listing

---

## Métricas clave

> El Data/Analytics Reviewer valida que estas métricas estén siendo medidas.

### Métricas de negocio

| Metrica | Definicion | Donde se mide |
|---------|-----------|---------------|
| Total listados activos | Count de listings con status PUBLISHED | Dashboard admin |
| Listados por tipo | Distribucion de listings por type (WEBSITE, DOMAIN, MVP, etc.) | Dashboard admin |
| Tasa de aprobacion | % de listings que pasan de PENDING_REVIEW a PUBLISHED | Dashboard admin |
| Consultas activas | Count de inquiries con status OPEN o REPLIED | Dashboard admin |
| Tasa de conversion de consultas | % de inquiries que pasan a CONVERTED | Dashboard admin |
| Usuarios registrados | Count total de users por rol | Dashboard admin |
| GMV potencial | Suma de askingPrice de listings PUBLISHED | Dashboard admin |

### Eventos de funnel

| Evento | Cuando se dispara | Prioridad |
|--------|-------------------|-----------|
| signup_completed | Usuario completa registro (email confirmado o OAuth exitoso) | Alta |
| listing_created | Vendedor crea un listado (status DRAFT) | Alta |
| listing_submitted | Vendedor envia listado a revision (status PENDING_REVIEW) | Alta |
| listing_published | Admin aprueba listado (status PUBLISHED) | Alta |
| listing_viewed | Comprador ve pagina de detalle de un activo | Media |
| inquiry_sent | Comprador envia primera consulta sobre un activo | Critica |
| inquiry_replied | Vendedor responde una consulta por primera vez | Critica |
| inquiry_converted | Consulta se marca como CONVERTED (transaccion iniciada) | Critica |
| favorite_added | Usuario agrega un listado a favoritos | Media |

### Alertas de negocio

1. Listing en PENDING_REVIEW por mas de 48 horas sin moderar
2. Seller con mas de 5 listados REJECTED consecutivos
3. Tasa de consultas sin respuesta > 30% en 7 dias

---

## Integraciones externas

| Servicio | Para que se usa | Criticidad |
|----------|-----------------|------------|
| Supabase Auth | Autenticacion (email + Google OAuth) | Alta |
| Supabase Database (PostgreSQL) | Base de datos principal | Alta |
| Supabase Storage | Upload de screenshots de activos | Media |
| Vercel | Hosting y deploy | Alta |
| Resend (o Supabase) | Emails transaccionales (notificaciones de consultas) | Media |
| Google OAuth | Login social | Media |

### Integraciones futuras (post-MVP)

| Servicio | Para que se usa | Fase |
|----------|-----------------|------|
| Qobra | Validacion automatica de ingresos de activos | Fase 2 |
| Qontacta | Validacion automatica de base de clientes | Fase 2 |
| Qontrata | Contratos de compraventa | Fase 2 |
| MercadoPago | Pasarela de pago para crowdfunding | Fase 1.5 |
| CazaDominios.ar | Feed de dominios valiosos por expirar | Fase 2 |

---

## Historial de cambios

| Fecha | Que cambio | Por que |
|-------|-----------|---------|
| 2026-03-23 | Creacion inicial desde documento de onboarding | Prerequisito para roles de revision capa 2 y para definir reglas de negocio del MVP |
