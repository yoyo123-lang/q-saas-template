'use client'

import { useRef, useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { rejectStage } from '@/lib/actions'

interface RejectStageFormProps {
  stageId: string
  orgId: string
  stageName: string
}

export function RejectStageForm({ stageId, orgId, stageName }: RejectStageFormProps) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const router = useRouter()

  function handleSubmit(formData: FormData) {
    setError(null)
    startTransition(async () => {
      try {
        await rejectStage(formData)
        setSuccess(true)
        setTimeout(() => router.push('/revision'), 800)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error al rechazar la etapa')
      }
    })
  }

  function handleCancel() {
    formRef.current?.reset()
    setExpanded(false)
    setError(null)
  }

  if (!expanded) {
    return (
      <button
        type="button"
        onClick={() => setExpanded(true)}
        className="px-5 py-2.5 rounded-lg bg-[#EF4444]/15 text-[#F87171] text-sm font-semibold border border-[#EF4444]/30 hover:bg-[#EF4444]/25 transition-colors"
      >
        ✕ Pedir cambios
      </button>
    )
  }

  return (
    <form ref={formRef} action={handleSubmit} className="flex flex-col gap-2 w-full max-w-lg">
      <input type="hidden" name="stageId" value={stageId} />
      <input type="hidden" name="orgId" value={orgId} />

      <label className="text-[#F87171] text-xs font-medium">
        Motivo de rechazo — {stageName}
      </label>
      <textarea
        name="feedback"
        rows={3}
        maxLength={1000}
        placeholder="Describí qué necesita corregirse antes de enviarlo al cliente..."
        className="w-full px-3 py-2 rounded-lg bg-[#0F172A] border border-[#EF4444]/30 text-white text-sm placeholder-[#475569] resize-none focus:outline-none focus:border-[#EF4444]/60 transition-colors"
        required
        disabled={isPending || success}
      />

      {error && <p className="text-[#F87171] text-xs">{error}</p>}

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={isPending || success}
          className="px-4 py-2 rounded-lg bg-[#EF4444]/15 text-[#F87171] text-sm font-semibold border border-[#EF4444]/30 hover:bg-[#EF4444]/25 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {success ? '✓ Enviado' : isPending ? 'Enviando...' : 'Confirmar rechazo'}
        </button>
        <button
          type="button"
          onClick={handleCancel}
          disabled={isPending || success}
          className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
        >
          Cancelar
        </button>
      </div>
    </form>
  )
}
