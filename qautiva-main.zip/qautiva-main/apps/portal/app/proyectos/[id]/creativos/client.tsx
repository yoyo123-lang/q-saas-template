'use client'

/**
 * Wizard de generación de creativos para Meta Ads.
 *
 * Estados:
 *   idle       → formulario vacío, empty state si no hay generaciones previas
 *   composing  → usuario está escribiendo en el textarea
 *   generating → generación en curso (polling activo)
 *   done       → resultados listos
 *
 * Flujo: escribir mensaje → generar → ver resultados (máx 2 clics)
 */

import { useState, useRef, useCallback, useEffect } from 'react'
import type { AdVisuals } from '@/app/_lib/interview/types'
import { AdVisualsGallery } from '@/components/AdVisualsGallery'

// ── Constantes ────────────────────────────────────────────────────────────────

const MAX_MESSAGE_LENGTH = 500
const MAX_POLL_ATTEMPTS = 70 // ~4 min con backoff

/**
 * Backoff exponencial para el polling:
 *   - intentos 0-4:   3s (total: ~15s)
 *   - intentos 5-14:  5s (total: ~50s adicionales)
 *   - intentos 15+:  10s (el resto)
 */
function getPollInterval(attempt: number): number {
  if (attempt < 5) return 3_000
  if (attempt < 15) return 5_000
  return 10_000
}

// ── Tipos ────────────────────────────────────────────────────────────────────

type WizardState = 'idle' | 'composing' | 'generating' | 'done'

type ProjectContext = {
  hasBrief: boolean
  hasBrandOptions: boolean
  hasCampaignPlan: boolean
  brandColors: string[]
  brandPersonality: string[]
  campaignMessage: string | null
}

type Props = {
  projectId: string
  context: ProjectContext
  previousVisuals: AdVisuals | null
  todayCount: number
  dailyLimit: number
}

// ── Sub-componentes ──────────────────────────────────────────────────────────

function ContextChip({
  label,
  available,
}: {
  label: string
  available: boolean
}) {
  return (
    <span
      className={`
        inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium
        ${available
          ? 'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20'
          : 'bg-[#475569]/10 text-[#64748B] border border-[#475569]/20'}
      `}
    >
      <span aria-hidden="true">{available ? '●' : '○'}</span>
      {label}
    </span>
  )
}

function GeneratingProgress({ elapsed }: { elapsed: number }) {
  // Estimación: ~90s promedio, mostrar progreso pseudo-determinístico
  const estimated = 90
  const pct = Math.min(95, Math.round((elapsed / estimated) * 100))

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-sm">
        <span className="text-[#94A3B8]">Generando 6 piezas publicitarias…</span>
        <span className="text-[#64748B] tabular-nums">{elapsed}s</span>
      </div>
      <div className="h-1.5 bg-[#1E293B] rounded-full overflow-hidden">
        <div
          className="h-full bg-[#8B5CF6] rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${pct}%` }}
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Progreso de generación"
        />
      </div>
      <p className="text-[#64748B] text-xs">
        La generación puede tardar entre 30 segundos y 3 minutos. No cerrés esta pestaña.
      </p>
    </div>
  )
}

// ── Componente principal ──────────────────────────────────────────────────────

export function CreativosClient({ projectId, context, previousVisuals, todayCount, dailyLimit }: Props) {
  const [state, setState] = useState<WizardState>(previousVisuals ? 'done' : 'idle')
  const [message, setMessage] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<AdVisuals | null>(previousVisuals)
  const [generatingElapsed, setGeneratingElapsed] = useState(0)
  const [generationsToday, setGenerationsToday] = useState(todayCount)

  const pollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const pollAttemptsRef = useRef(0)
  const isGeneratingRef = useRef(false) // A3: guard de concurrencia para handleGenerate

  const stopTimers = useCallback(() => {
    if (pollTimerRef.current) clearTimeout(pollTimerRef.current)
    if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current)
    pollTimerRef.current = null
    elapsedTimerRef.current = null
    isGeneratingRef.current = false
  }, [])

  // A1: limpiar timers al desmontar para evitar setState sobre componente desmontado
  useEffect(() => {
    return () => {
      stopTimers()
    }
  }, [stopTimers])

  const startPolling = useCallback((jobId: string) => {
    pollAttemptsRef.current = 0
    setGeneratingElapsed(0)

    // Contador de segundos para el progress bar
    elapsedTimerRef.current = setInterval(() => {
      setGeneratingElapsed((prev) => prev + 1)
    }, 1_000)

    const poll = async () => {
      if (pollAttemptsRef.current >= MAX_POLL_ATTEMPTS) {
        stopTimers()
        setState('idle')
        setError('La generación tardó demasiado. Intentá de nuevo.')
        return
      }
      pollAttemptsRef.current++

      try {
        const res = await fetch(`/api/projects/${projectId}/generate-creatives/${jobId}`)
        if (!res.ok) {
          // Error HTTP — seguir poling salvo 404 (job expirado)
          if (res.status === 404) {
            stopTimers()
            setState('idle')
            setError('El job expiró. Intentá generar de nuevo.')
            return
          }
          // Otros errores: reintentar
        } else {
          const data = await res.json() as { status: string; result?: AdVisuals; error?: string }

          if (data.status === 'done' && data.result) {
            stopTimers()
            setResult(data.result)
            setState('done')
            return
          }

          if (data.status === 'failed') {
            stopTimers()
            setState('idle')
            setError(data.error ?? 'Error en la generación. Intentá de nuevo.')
            return
          }
        }
      } catch {
        // Error de red — seguir reintentando
      }

      pollTimerRef.current = setTimeout(poll, getPollInterval(pollAttemptsRef.current))
    }

    pollTimerRef.current = setTimeout(poll, getPollInterval(pollAttemptsRef.current))
  }, [projectId, stopTimers])

  const handleGenerate = async () => {
    // A3: guard de concurrencia — evitar doble-click que dispare 2 requests
    if (isGeneratingRef.current) return
    const trimmed = message.trim()
    if (!trimmed) return

    isGeneratingRef.current = true
    setError(null)
    setState('generating')

    try {
      const res = await fetch(`/api/projects/${projectId}/generate-creatives`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: trimmed }),
      })

      const data = await res.json() as { jobId?: string; error?: string; dailyCount?: number }

      if (!res.ok || !data.jobId) {
        isGeneratingRef.current = false
        setState('composing')
        setError(data.error ?? 'Error al iniciar la generación.')
        return
      }

      if (data.dailyCount !== undefined) {
        setGenerationsToday(data.dailyCount)
      }

      startPolling(data.jobId)
    } catch {
      isGeneratingRef.current = false
      setState('composing')
      setError('Error de conexión. Revisá tu internet e intentá de nuevo.')
    }
  }

  const handleNewGeneration = () => {
    setMessage('')
    setError(null)
    setState('composing')
  }

  const isGenerating = state === 'generating'
  const canGenerate = message.trim().length > 0 && !isGenerating && generationsToday < dailyLimit
  const remaining = dailyLimit - generationsToday

  return (
    <div className="flex flex-col min-h-full">
      {/* Header */}
      <div className="px-8 pt-8 pb-4">
        <h1 className="text-2xl font-bold text-white mb-1">Creativos para Meta Ads</h1>
        <p className="text-[#94A3B8] text-sm">
          Describí lo que querés comunicar y generamos 6 piezas publicitarias listas para Meta.
        </p>
      </div>

      <div className="flex-1 px-8 pb-8 space-y-6 max-w-4xl">

        {/* Panel de contexto */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
          <p className="text-[#64748B] text-xs uppercase tracking-wider mb-3">Contexto disponible</p>
          <div className="flex flex-wrap gap-2">
            <ContextChip label="Brief estratégico" available={context.hasBrief} />
            <ContextChip label="Identidad de marca" available={context.hasBrandOptions} />
            <ContextChip label="Plan de campaña" available={context.hasCampaignPlan} />
          </div>
          {!context.hasBrief && !context.hasBrandOptions && !context.hasCampaignPlan && (
            <p className="text-[#64748B] text-xs mt-3">
              No hay datos de etapas anteriores disponibles. Se usarán valores estándar para la marca.
            </p>
          )}
          {(context.brandColors.length > 0 || context.brandPersonality.length > 0) && (
            <div className="mt-3 flex flex-wrap gap-3">
              {context.brandColors.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[#64748B] text-xs">Paleta:</span>
                  {context.brandColors.map((color) => (
                    <span
                      key={color}
                      className="w-4 h-4 rounded-full border border-white/10 flex-shrink-0"
                      style={{ backgroundColor: color }}
                      title={color}
                      aria-label={`Color ${color}`}
                    />
                  ))}
                </div>
              )}
              {context.brandPersonality.length > 0 && (
                <span className="text-[#64748B] text-xs">
                  Personalidad: {context.brandPersonality.slice(0, 3).join(', ')}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Formulario */}
        {state !== 'done' && (
          <div className="space-y-4">
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-white mb-2">
                ¿Qué querés comunicar?
              </label>
              <textarea
                id="message"
                value={message}
                onChange={(e) => {
                  setMessage(e.target.value)
                  if (state === 'idle' && e.target.value.length > 0) setState('composing')
                  if (state === 'composing' && e.target.value.length === 0) setState('idle')
                }}
                disabled={isGenerating}
                maxLength={MAX_MESSAGE_LENGTH}
                rows={4}
                placeholder={
                  context.campaignMessage
                    ? `Sugerencia: "${context.campaignMessage.slice(0, 80)}..."`
                    : 'Ej: "Lanzamos nuestra nueva colección de verano con 30% de descuento los primeros 3 días"'
                }
                className="
                  w-full bg-[#0F172A] border border-[#1E293B] rounded-xl px-4 py-3
                  text-white text-sm placeholder-[#475569]
                  focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6]/30
                  disabled:opacity-50 disabled:cursor-not-allowed
                  resize-none transition-colors duration-200
                "
                aria-label="Mensaje para los creativos"
                aria-describedby="message-hint"
              />
              <div id="message-hint" className="flex justify-between mt-1.5">
                <span className="text-[#64748B] text-xs">
                  {message.length > 0
                    ? 'Incluí el mensaje clave, oferta o evento que querés destacar'
                    : 'Contanos el mensaje principal de tu campaña'}
                </span>
                <span className={`text-xs tabular-nums ${message.length > MAX_MESSAGE_LENGTH * 0.9 ? 'text-[#F59E0B]' : 'text-[#64748B]'}`}>
                  {message.length}/{MAX_MESSAGE_LENGTH}
                </span>
              </div>
            </div>

            {isGenerating ? (
              <GeneratingProgress elapsed={generatingElapsed} />
            ) : (
              <div className="flex items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={handleGenerate}
                  disabled={!canGenerate}
                  aria-label="Generar 6 piezas publicitarias para Meta Ads"
                  className="
                    min-h-[44px] px-6 py-2.5 rounded-xl text-sm font-semibold
                    bg-[#8B5CF6] text-white
                    hover:bg-[#A78BFA] active:bg-[#7C3AED]
                    disabled:opacity-40 disabled:cursor-not-allowed
                    transition-colors duration-200
                  "
                >
                  Generar creativos
                </button>
                <span className="text-[#64748B] text-xs">
                  {remaining} generación{remaining !== 1 ? 'es' : ''} disponible{remaining !== 1 ? 's' : ''} hoy
                </span>
              </div>
            )}
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="bg-[#EF4444]/10 border border-[#EF4444]/20 rounded-xl px-4 py-3">
            <p className="text-[#EF4444] text-sm">{error}</p>
          </div>
        )}

        {/* Resultados */}
        {state === 'done' && result && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-white font-semibold">
                {result.visuals.length} pieza{result.visuals.length !== 1 ? 's' : ''} generada{result.visuals.length !== 1 ? 's' : ''}
              </h2>
              {remaining > 0 && (
                <button
                  type="button"
                  onClick={handleNewGeneration}
                  className="
                    min-h-[44px] px-4 py-2 rounded-lg text-xs font-medium
                    text-[#A78BFA] border border-[#8B5CF6]/30
                    hover:bg-[#8B5CF6]/10 transition-colors duration-200
                  "
                  aria-label="Generar una nueva tanda de creativos"
                >
                  Nueva generación
                </button>
              )}
            </div>
            {result.visuals.length < 6 && (
              <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-lg px-4 py-3">
                <p className="text-[#F59E0B] text-sm">
                  {result.visuals.length} de 6 piezas generadas. Algunas piezas no pudieron generarse.
                </p>
              </div>
            )}
            <AdVisualsGallery visuals={result.visuals} />
            {result.disclaimer && (
              <p className="text-[#64748B] text-xs italic">{result.disclaimer}</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
