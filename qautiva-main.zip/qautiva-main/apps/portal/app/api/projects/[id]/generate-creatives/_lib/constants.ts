/**
 * Constantes compartidas entre el endpoint de generación (route.ts)
 * y la página del portal (creativos/page.tsx).
 *
 * Centralizar aquí evita el magic number duplicado.
 */

/** Máximo de generaciones de AD_VISUALS por proyecto por día. */
export const MAX_DAILY_AD_VISUALS = 10
