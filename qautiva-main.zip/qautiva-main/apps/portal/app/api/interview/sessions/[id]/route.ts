import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'

/**
 * GET /api/interview/sessions/[id]
 * Retorna el estado actual de la sesión para polling del ProcessingScreen.
 *
 * Returns: { ok: true, session: { id, status, currentStep, totalSteps, answersVersion } }
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } },
) {
  // Validar UUID
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  // 1 sola query: buscar la sesión por PK (usa índice primario) e incluir el teamId
  // del perfil en la misma llamada para verificar ownership en memoria — evita el
  // segundo roundtrip a DB que tenía la versión anterior (findProfile + findSession).
  const [session, profile] = await Promise.all([
    prisma.interviewSession.findUnique({
      where: { id: params.id },
      select: {
        id: true,
        teamId: true,
        status: true,
        currentStep: true,
        totalSteps: true,
        answersVersion: true,
        processingStartedAt: true,
        retryCount: true,
        maxRetries: true,
        project: { select: { deletedAt: true } },
      },
    }),
    prisma.userProfile.findUnique({
      where: { authUserId: user.id },
      select: { teamMemberships: { select: { teamId: true } } },
    }),
  ])

  // Verificar ownership en memoria: más rápido que un JOIN en DB para este caso.
  const teamIds = profile?.teamMemberships.map((m) => m.teamId) ?? []
  if (
    !session ||
    !session.teamId ||
    !teamIds.includes(session.teamId) ||
    session.project?.deletedAt !== null
  ) {
    // Respuesta uniforme para evitar enumeración de IDs existentes
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Omitir campos internos de la respuesta (teamId, project)
  const { teamId: _t, project: _p, ...publicSession } = session

  // Sesiones stuck en PROCESSING: si llevan más de 200s sin completarse, el worker de
  // Vercel probablemente murió sin marcar ERROR. Auto-resetear a ERROR para que el
  // usuario pueda reintentar con el botón de la UI (o el cron con /process).
  if (publicSession.status === 'PROCESSING' && publicSession.processingStartedAt) {
    const stuckSec = Math.floor((Date.now() - new Date(publicSession.processingStartedAt).getTime()) / 1000)
    if (stuckSec > 60) {
      console.warn('[session/get] stuck in PROCESSING', { sessionId: params.id, stuckSec })
    }
    if (stuckSec > 200) {
      console.error('[session/get] auto-resetting stuck session to ERROR', { sessionId: params.id, stuckSec })
      await prisma.interviewSession.update({
        where: { id: params.id },
        data: {
          status: 'ERROR',
          lastError: `Tiempo de procesamiento agotado (${stuckSec}s). Usá el botón Reintentar.`,
          processingStartedAt: null,
        },
      })
      publicSession.status = 'ERROR'
      publicSession.processingStartedAt = null
    }
  }

  return NextResponse.json({ ok: true, session: publicSession }, {
    headers: { 'Cache-Control': 'no-store' },
  })
}
