# Plan: Deuda Técnica + Optimización de Portal

## Objetivo
Saldar la deuda técnica del portal y optimizar la velocidad de carga y uso de recursos, priorizando impacto real sobre perfección teórica.

> **Última actualización**: 2026-03-15 — Rebased sobre main (65 commits nuevos).
> Items ya resueltos por commits recientes marcados con ✅.

---

## Estado post-merge de main

### ✅ Ya resuelto (no requiere trabajo)
- **Validación JSON en merge-flow**: `isValidQuestionBlock()` ya valida estructura antes del cast
- **Límite de payload en answers**: 50KB limit + validación de questionId + answerHistory cap a 100 entries
- **Status-leaking en advance**: Errores genéricos reemplazan mensajes que exponían estado interno
- **Auth helpers en orders/products**: Ya importan de `lib/api/marketplace-helpers.ts`
- **Fixes de accesibilidad**: htmlFor/id pairs en formularios, maxLength en inputs

### ⚠️ Deuda nueva introducida por los 65 commits
- **DomainRegisterForm.tsx**: Tiene `.catch(() => {})` en fetch de precios (silent failure)
- **TemplateSelectionClient.tsx**: 363 líneas (componente grande, pero aceptable por ahora)
- **Solo 2 usos de revalidateTag** en ~34 rutas API (cache invalidation débil)

---

## Etapa 1: Refactor auth helper en media route (último duplicado)
**Archivos**:
- `apps/portal/app/api/marketplace/media/route.ts` (413 líneas — único que aún duplica auth)
- `apps/portal/lib/api/marketplace-helpers.ts` (ya centralizado)

**Qué se hace**: `media/route.ts` es la única ruta marketplace que todavía define `getProfileOrUnauthorized()` inline (líneas 7-40). Las demás ya importan del helper. Reemplazar la definición local con import de `marketplace-helpers.ts`.
**Cómo verificar**: `npm run build` pasa, GET /api/marketplace/media responde igual.
**Riesgos**: Bajo — refactor mecánico de 1 archivo.
**Estado**: ⬜ Pendiente

---

## Etapa 2: Dividir QuestionCard.tsx (872 líneas → módulos)
**Archivos**:
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/QuestionCard.tsx` (refactor)
- NUEVO: `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/inputs/` (directorio)

**Qué se hace**: Extraer cada input type (TextInput, TextareaInput, MultipleChoiceInput, MultiSelectInput, RatingInput, FileUploadInput, ColorPickerInput, BudgetRangeInput, DateInput, InlineHelpButton) a archivos separados en `inputs/`. QuestionCard queda como orquestador (~80 líneas). InputRenderer importa los componentes.
**Cómo verificar**: `npm run build`, la entrevista funciona igual visualmente, tests existentes pasan.
**Riesgos**: Medio — verificar que el state drilling funcione igual. No cambiar lógica, solo mover código.
**Estado**: ⬜ Pendiente

---

## Etapa 3: Agregar loading.tsx + Suspense boundaries
**Archivos**:
- NUEVO: `apps/portal/app/proyectos/loading.tsx`
- NUEVO: `apps/portal/app/proyectos/[id]/loading.tsx`
- NUEVO: `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/loading.tsx`
- NUEVO: `apps/portal/app/onboarding/loading.tsx`
- NUEVO: `apps/portal/app/(protected)/loading.tsx`
- NUEVO: `apps/portal/app/(protected)/dominios/loading.tsx`

**Qué se hace**: Agregar skeletons de carga para las rutas principales del portal (incluida la nueva sección de dominios). Usar el mismo patrón del `marketplace/loading.tsx` existente (animate-pulse, dark theme). Mejora percepción de velocidad (LCP/FCP).
**Cómo verificar**: Navegar entre páginas, verificar que se muestre skeleton antes del contenido.
**Riesgos**: Bajo — archivos nuevos, no tocan código existente.
**Estado**: ⬜ Pendiente

---

## Etapa 4: Caching estratégico + revalidateTag en mutaciones
**Archivos**:
- `apps/portal/app/proyectos/page.tsx` (tiene `force-dynamic` + solo 1 `unstable_cache`)
- `apps/portal/app/marketplace/page.tsx` (tiene 2 caches, verificar cobertura)
- `apps/portal/app/proyectos/[id]/page.tsx` (cache de proyecto individual)
- Rutas API que mutan datos — actualmente solo 2 usan `revalidateTag`

**Qué se hace**:
1. Evaluar si `force-dynamic` en `/proyectos/page.tsx` es necesario o si `unstable_cache` con TTL 30s alcanza
2. Cachear queries estables: datos de proyecto (30s), stages (30s), dominios (60s)
3. Agregar `revalidateTag()` en rutas API que mutan datos:
   - `/api/projects` POST → invalidar tag `projects`
   - `/api/marketplace/orders` POST → invalidar tag `orders`
   - `/api/marketplace/products` POST/PATCH/DELETE → invalidar tag `products`
   - `/api/interview/sessions/[id]/answer` POST → invalidar tag `session-{id}`
   - `/api/deliverables/[id]/action` POST → invalidar tag `deliverables`
   - `/api/interview/sessions/[id]/template` PATCH → invalidar tag `session-{id}`
4. Mantener `force-dynamic` solo donde haya datos que DEBEN ser real-time (chat, metricas)

**Cómo verificar**: Medir tiempos de carga antes/después. Verificar que datos se actualizan tras mutaciones.
**Riesgos**: Medio — cache stale puede confundir al usuario. TTLs cortos + revalidateTag mitigan.
**Estado**: ⬜ Pendiente

---

## Etapa 5: Corregir silent failures en .catch()
**Archivos**:
- `apps/portal/app/proyectos/_components/DeleteProjectButton.tsx`
- `apps/portal/app/proyectos/nuevo/servicios/client.tsx`
- `apps/portal/app/proyectos/nuevo/client.tsx`
- `apps/portal/app/onboarding/api-key/client.tsx`
- `apps/portal/app/(protected)/dominios/registrar/DomainRegisterForm.tsx` ← NUEVO (deuda de los 65 commits)

**Qué se hace**: Reemplazar `res.json().catch(() => ({}))` y `.catch(() => {})` por handler que loguee y devuelva `{ error: 'Error de conexión' }` para que el usuario vea feedback.
**Cómo verificar**: `npm run build`, simular error de red y verificar que se muestre mensaje.
**Riesgos**: Bajo — cambio puntual en 5 archivos, misma interfaz.
**Estado**: ⬜ Pendiente

---

## Etapa 6: Dynamic import para Recharts + code splitting
**Archivos**:
- `apps/portal/components/MetricsChart.tsx`
- `apps/portal/app/(protected)/metricas/page.tsx` (o donde se importa MetricsChart)

**Qué se hace**:
1. Recharts es ~200KB gzipped. Solo se usa en `/metricas` (org con status=LAUNCHED). Importar con `next/dynamic` + `ssr: false` para que no se cargue en el bundle principal
2. Verificar que `@anthropic-ai/sdk` solo se importa en server-side (no llega al client bundle)

**Cómo verificar**: `npm run build`, verificar que el chunk de Recharts solo se carga en `/metricas`.
**Riesgos**: Bajo — dynamic import es patrón estándar de Next.js.
**Estado**: ⬜ Pendiente

---

## Etapa 7: Consolidar state en interview client + useCallback
**Archivos**:
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx` (652 líneas)

**Qué se hace**:
1. Consolidar `session`, `uiState`, `errorMsg` en un solo `useReducer` con estados claros
2. Envolver handlers en `useCallback` para evitar re-renders innecesarios del QuestionCard (más liviano post-Etapa 2)

**Cómo verificar**: `npm run build`, la entrevista funciona igual. Verificar con React DevTools que QuestionCard no re-renderiza innecesariamente.
**Riesgos**: Medio — cambio de state management, requiere testing cuidadoso del flujo completo.
**Estado**: ⬜ Pendiente

---

## Etapa 8: Tests para paths críticos sin cobertura
**Archivos**:
- NUEVO: `apps/portal/__tests__/api/marketplace/orders.test.ts`
- NUEVO: `apps/portal/__tests__/api/marketplace/products.test.ts`
- NUEVO: `apps/portal/__tests__/api/interview/answer.test.ts`
- NUEVO: `apps/portal/__tests__/lib/merge-flow.test.ts`
- NUEVO: `apps/portal/__tests__/api/interview/feedback.test.ts` ← nuevo endpoint
- NUEVO: `apps/portal/__tests__/api/deliverables/action.test.ts` ← nuevo endpoint

**Qué se hace**: Tests unitarios para:
1. Marketplace: crear orden, listar productos, enviar mensaje
2. Interview: submit answer (happy path + max size 50KB, concurrent, invalid questionId)
3. Interview: feedback (rating 1-5, validación de campos)
4. Deliverables: approve → stage completion, reject flow
5. merge-flow: JSON válido, inválido, array vacío, estructura incompleta
6. Auth helper centralizado (post-Etapa 1)

**Cómo verificar**: `npm run test` pasa con todos los tests nuevos.
**Riesgos**: Bajo — archivos nuevos, no tocan código existente.
**Estado**: ⬜ Pendiente

---

## Cosas que NO se van a tocar

- **Admin app** — tiene sus propios issues (debounce, filtros) pero está fuera del scope "portal"
- **Landing** — ya es SSG puro, no necesita optimización
- **Telegram bot** — scope separado
- **Rate limiting** — requiere decisión de dependencia (Upstash) pendiente
- **RLS policies viejas** — planificado para Phase C
- **Paginación completa** — ya planificada en Etapa 3 del IMPLEMENTATION_PLAN principal
- **packages/domains/** — módulo nuevo, bien testeado (8 test files), no tiene deuda significativa
- **TemplateSelectionClient.tsx** — 363 líneas, aceptable por ahora (componente complejo por naturaleza)

---

## Orden de ejecución recomendado

```
Etapa 1 (media auth helper)   → 15 min, cierra último duplicado
Etapa 5 (silent failures)     → 30 min, mejora UX de errores (incluye DomainRegisterForm nuevo)
Etapa 6 (Recharts dynamic)    → 20 min, reduce bundle ~200KB
Etapa 2 (QuestionCard split)  → 1-2h, desbloquea Etapa 7
Etapa 3 (loading states)      → 1h, mejora percepción (incluye dominios)
Etapa 4 (caching + revalidate)→ 2h, mejora velocidad real
Etapa 7 (state interview)     → 1h, depende de Etapa 2
Etapa 8 (tests)               → 2-3h, valida todo + cubre endpoints nuevos
```

Total: ~8 sesiones de trabajo atómicas.
