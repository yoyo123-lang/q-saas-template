# Sesión 06: Facturación ARCA (frontend) + PDF

## Objetivo
UI completa para crear facturas, listar facturas con filtros, ver detalle, y generar PDF fiscal descargable. Emisión de notas de crédito/débito desde la UI. Al terminar, el usuario puede facturar electrónicamente desde el navegador.

## Pre-requisitos
- Sesión 05 completada (backend de facturación, AfipService, InvoiceService)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/app/api/v1/invoices/` (endpoints de S05)
3. Leer `src/types/invoice.ts` (tipos de S05)
4. Leer `src/components/shared/product-search.tsx` (componente reutilizable de S04)
5. Leer `src/hooks/use-products.ts` como patrón de hook

---

## Etapa 1: Hook y listado de facturas

### Tarea 1.1: Hook useInvoices
**Archivo nuevo**: `src/hooks/use-invoices.ts`

Hook que expone:
- `invoices`: lista paginada
- `pagination`, `filters` (type, status, contactId, dateFrom, dateTo, search)
- `setFilters`, `setPage`
- `isLoading`, `error`
- `createInvoice(data)`: llama POST y refresca lista
- `refetch()`

### Tarea 1.2: Página de listado de facturas
**Archivo nuevo**: `src/app/dashboard/invoices/page.tsx`

Layout:
- Título "Facturación" con breadcrumb
- Botón "Nueva factura"
- Barra de filtros:
  - Búsqueda (por número, nombre de cliente)
  - Tipo (dropdown: Todas, Factura A, B, C, NC A, B, C, ND A, B, C)
  - Estado (dropdown: Todos, Borrador, Autorizada, Rechazada, Anulada)
  - Rango de fechas (date pickers)
- DataTable con columnas:
  - Tipo + Número (ej: "FC A 00001-00000123")
  - Fecha de emisión (formato argentino: dd/mm/yyyy)
  - Cliente (nombre)
  - Total (formato argentino: $1.234,56)
  - Estado (badge con color: verde=autorizada, amarillo=borrador, rojo=rechazada, gris=anulada)
  - Acciones (Ver, PDF, NC)
- Paginación
- Empty state: "No hay comprobantes. Creá tu primera factura."

### Tarea 1.3: Formateo de número de comprobante
**Archivo a modificar**: `src/lib/utils.ts`

Agregar helper:
```typescript
// formatVoucherNumber(pointOfSale: number, number: number): string
// Ej: formatVoucherNumber(1, 123) → "00001-00000123"
//
// formatVoucherType(type: InvoiceType): string
// Ej: formatVoucherType("FACTURA_A") → "FC A"
// Ej: formatVoucherType("NOTA_CREDITO_B") → "NC B"
//
// formatFullVoucherNumber(type, pointOfSale, number): string
// Ej: "FC A 00001-00000123"
```

**Commit**: `feat(ui): add invoice list page with filters and voucher formatting`

---

## Etapa 2: Formulario de nueva factura

### Tarea 2.1: Página de crear factura
**Archivo nuevo**: `src/app/dashboard/invoices/new/page.tsx`

Formulario con secciones:

**1. Cliente**:
- Componente de búsqueda de contacto (similar a ProductSearch pero para contactos)
- Al seleccionar: mostrar datos fiscales (CUIT, condición IVA)
- Si el cliente es RI: se emite Factura A. Si es CF/Mono/Exento: Factura B/C (según emisor)
- Mostrar tipo de comprobante auto-determinado
- Opción "Consumidor Final" rápida (sin seleccionar contacto)

**2. Items**:
- Tabla editable con columnas: Producto, Descripción, Cantidad, Precio Unit., IVA%, Subtotal
- Usar `ProductSearch` para agregar productos
- Al seleccionar producto: auto-completar descripción, precio e IVA
- Permitir items "libres" (sin producto asociado — escribir descripción manual)
- Botón "Agregar ítem" al final de la tabla
- Botón eliminar por fila

**3. Resumen de montos** (calculado en tiempo real):
- Subtotal (neto gravado)
- IVA desglosado por alícuota (ej: "IVA 21%: $X", "IVA 10,5%: $Y")
- Otros impuestos (si aplica)
- **Total**

**4. Acciones**:
- Botón "Emitir factura" (envía a ARCA y crea)
- Botón "Cancelar"
- Loading state mientras se procesa en ARCA

### Tarea 2.2: Componente ContactSearch
**Archivo nuevo**: `src/components/shared/contact-search.tsx`

Similar a ProductSearch pero para contactos:
- Input con debounce
- Busca en `/api/v1/contacts?search=X`
- Dropdown con nombre, CUIT, condición IVA
- Callback `onSelect(contact)`

### Tarea 2.3: Componente InvoiceItemsEditor
**Archivo nuevo**: `src/components/invoices/invoice-items-editor.tsx`

Componente que maneja la tabla editable de items:
- Estado local con array de items
- Cálculos en tiempo real (subtotal por fila, totales)
- Validación: al menos 1 item, cantidades > 0, precios >= 0
- Callback `onChange(items, totals)` al componente padre

**Commit**: `feat(ui): add invoice creation form with contact search and items editor`

---

## Etapa 3: Detalle de factura y notas de crédito

### Tarea 3.1: Página de detalle de factura
**Archivo nuevo**: `src/app/dashboard/invoices/[id]/page.tsx`

Vista con:
- Header: tipo + número formateado, fecha, estado (badge)
- Datos del emisor (organización)
- Datos del receptor (cliente)
- Tabla de items (solo lectura)
- Resumen de montos
- Datos ARCA: CAE, vencimiento CAE
- Si tiene notas de crédito/débito asociadas: listado con links
- Acciones:
  - "Descargar PDF"
  - "Emitir Nota de Crédito" (solo si está Autorizada y no Anulada)
  - "Emitir Nota de Débito" (solo si está Autorizada)

### Tarea 3.2: Formulario de nota de crédito
**Archivo nuevo**: `src/app/dashboard/invoices/[id]/credit-note/page.tsx`

Formulario pre-cargado con datos de la factura original:
- Muestra factura de referencia (tipo + número)
- Items de la factura original (editables — se puede hacer NC parcial)
- Checkboxes para seleccionar qué items incluir
- Ajuste de cantidades (NC parcial por cantidad)
- Resumen de montos de la NC
- Botón "Emitir Nota de Crédito"

### Tarea 3.3: Feedback de ARCA
**Archivo nuevo**: `src/components/invoices/arca-result-dialog.tsx`

Dialog/modal que muestra el resultado de ARCA después de emitir:
- **Éxito**: "Comprobante autorizado ✓" con CAE y número. Botones: "Ver factura", "Descargar PDF", "Emitir otra"
- **Error**: Mostrar errores de ARCA de forma legible. Los errores de ARCA son crípticos (ej: "Error 10016") — mapear los más comunes a mensajes claros:
  - 10016: "CUIT del receptor inválido"
  - 10013: "Punto de venta no habilitado"
  - 10048: "El monto no puede ser 0"
  - Otros: mostrar código + mensaje original de ARCA

**Commit**: `feat(ui): add invoice detail, credit notes, and ARCA feedback dialog`

---

## Etapa 4: Generación de PDF fiscal

### Tarea 4.1: Instalar dependencia de PDF
**Comando**: Evaluar entre `@react-pdf/renderer` (React components → PDF) o `jspdf` + `jspdf-autotable` (más ligero).

Recomendación: usar `@react-pdf/renderer` — permite definir el layout del PDF como componentes React, es más mantenible para un PDF complejo como una factura fiscal.

**Nota**: si `@react-pdf/renderer` da problemas con Next.js 15 server-side, usar `jspdf` como fallback.

### Tarea 4.2: Template de factura PDF
**Archivo nuevo**: `src/lib/pdf/invoice-template.tsx`

Generar PDF con formato fiscal argentino estándar:

```
┌─────────────────────────────────────────────┐
│ [LOGO]  RAZÓN SOCIAL DEL EMISOR      [TIPO]│
│         Dirección fiscal               A/B/C│
│         CUIT: XX-XXXXXXXX-X                 │
│         Condición IVA: Resp. Inscripto      │
├─────────────────────────────────────────────┤
│ Comprobante: FC A 00001-00000123            │
│ Fecha: 25/03/2026                           │
│ CAE: XXXXXXXXXXXXXX  Vto: dd/mm/yyyy        │
├─────────────────────────────────────────────┤
│ Cliente: Nombre / Razón Social              │
│ CUIT: XX-XXXXXXXX-X                        │
│ Condición IVA: Responsable Inscripto        │
│ Domicilio: Dirección                        │
├─────────────────────────────────────────────┤
│ Cant. │ Descripción │ P.Unit │ IVA% │ Total│
│ ──────┼─────────────┼────────┼──────┼──────│
│  2,00 │ Producto 1  │ $1.000 │  21% │$2420 │
│  1,00 │ Producto 2  │ $500   │ 10.5%│ $552 │
├─────────────────────────────────────────────┤
│                          Subtotal: $1.500,00│
│                          IVA 21%:    $420,00│
│                          IVA 10,5%:   $52,50│
│                          TOTAL:    $1.972,50│
├─────────────────────────────────────────────┤
│ [Código QR ARCA]                            │
│ (QR con URL de verificación de ARCA)        │
└─────────────────────────────────────────────┘
```

Todos los números en formato argentino (punto de miles, coma decimal).

### Tarea 4.3: Endpoint de PDF
**Archivo nuevo**: `src/app/api/v1/invoices/[id]/pdf/route.ts`

Endpoint GET que:
1. Carga la factura con items y datos de la organización
2. Genera el PDF con el template
3. Retorna como `Content-Type: application/pdf`
4. Header `Content-Disposition: attachment; filename="FC-A-00001-00000123.pdf"`

### Tarea 4.4: Botón de descarga en UI
**Archivo a modificar**: `src/app/dashboard/invoices/[id]/page.tsx`

Agregar botón "Descargar PDF" que:
- Llama a `/api/v1/invoices/{id}/pdf`
- Descarga el archivo
- Loading state mientras genera

**Commit**: `feat(pdf): add fiscal invoice PDF generation with Argentine format`

---

## Checklist de cierre de sesión

- [ ] Listado de facturas con filtros y paginación
- [ ] Formulario de nueva factura con búsqueda de cliente y productos
- [ ] Cálculos de IVA en tiempo real (desglosado por alícuota)
- [ ] Determinación automática de tipo de comprobante
- [ ] Detalle de factura con datos ARCA
- [ ] Emisión de nota de crédito (total y parcial)
- [ ] Generación de PDF con formato fiscal argentino
- [ ] QR de ARCA en el PDF
- [ ] Feedback claro de errores de ARCA
- [ ] Formato argentino en todos los montos y fechas
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
