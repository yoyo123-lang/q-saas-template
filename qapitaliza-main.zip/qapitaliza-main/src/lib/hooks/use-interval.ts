import { useEffect, useRef } from 'react'

/**
 * Runs `callback` on every `delay` milliseconds interval.
 * The callback ref is always up-to-date, so it's safe to use inside without
 * adding it to the dependency array.
 */
export function useInterval(callback: () => void, delay: number) {
  const savedCallback = useRef(callback)

  useEffect(() => {
    savedCallback.current = callback
  }, [callback])

  useEffect(() => {
    const id = setInterval(() => savedCallback.current(), delay)
    return () => clearInterval(id)
  }, [delay])
}
