'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { CheckCircle, XCircle, Eye } from 'lucide-react'
import { cn } from '@/lib/utils/cn'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Modal } from '@/components/ui/modal'
import { ListingPreviewPanel } from '@/components/admin/listing-preview-panel'
import { approveListing, rejectListing } from '@/lib/actions/admin'
import type { AdminListingItem } from '@/lib/data/admin'

const STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Borrador',
  PENDING_REVIEW: 'En revisión',
  PUBLISHED: 'Publicado',
  PAUSED: 'Pausado',
  SOLD: 'Vendido',
  REJECTED: 'Rechazado',
}

const STATUS_VARIANTS: Record<string, 'success' | 'amber' | 'info' | 'muted' | 'danger'> = {
  DRAFT: 'muted',
  PENDING_REVIEW: 'amber',
  PUBLISHED: 'success',
  PAUSED: 'muted',
  SOLD: 'info',
  REJECTED: 'danger',
}

const TYPE_LABELS: Record<string, string> = {
  WEBSITE: 'Sitio web',
  DOMAIN: 'Dominio',
  SAAS: 'SaaS',
  ECOMMERCE: 'E-commerce',
  PROJECT: 'Proyecto',
  OTHER: 'Otro',
}

function timeAgo(date: Date): string {
  const diffMs = Date.now() - new Date(date).getTime()
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
  if (diffDays === 0) return 'Hoy'
  if (diffDays === 1) return 'Ayer'
  if (diffDays < 30) return `Hace ${diffDays} días`
  if (diffDays < 365) return `Hace ${Math.floor(diffDays / 30)} meses`
  return `Hace ${Math.floor(diffDays / 365)} años`
}

interface AdminListingsTableProps {
  listings: AdminListingItem[]
}

export function AdminListingsTable({ listings }: AdminListingsTableProps) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [previewListing, setPreviewListing] = useState<AdminListingItem | null>(null)
  const [isPanelOpen, setIsPanelOpen] = useState(false)
  const [bulkRejectOpen, setBulkRejectOpen] = useState(false)
  const [bulkRejectReason, setBulkRejectReason] = useState('')
  const [bulkLoading, setBulkLoading] = useState(false)

  const allSelected = listings.length > 0 && selectedIds.length === listings.length

  function toggleAll() {
    setSelectedIds(allSelected ? [] : listings.map((l) => l.id))
  }

  function toggleOne(id: string) {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    )
  }

  function openPreview(listing: AdminListingItem) {
    setPreviewListing(listing)
    setIsPanelOpen(true)
  }

  async function handleApprove(id: string) {
    const result = await approveListing(id)
    if (result.success) {
      startTransition(() => router.refresh())
    }
  }

  async function handleReject(id: string, reason: string) {
    const result = await rejectListing(id, reason)
    if (result.success) {
      startTransition(() => router.refresh())
    }
  }

  async function handleBulkApprove() {
    await Promise.all(selectedIds.map((id) => approveListing(id)))
    setSelectedIds([])
    startTransition(() => router.refresh())
  }

  async function handleBulkRejectConfirm() {
    const reason = bulkRejectReason.trim()
    if (reason.length < 20) return
    setBulkLoading(true)
    await Promise.all(selectedIds.map((id) => rejectListing(id, reason)))
    setBulkLoading(false)
    setBulkRejectOpen(false)
    setBulkRejectReason('')
    setSelectedIds([])
    startTransition(() => router.refresh())
  }

  return (
    <>
      {/* Bulk action bar */}
      {selectedIds.length > 0 && (
        <div className="flex items-center gap-3 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mb-4">
          <span className="text-sm text-amber-500 font-medium">
            {selectedIds.length} seleccionado{selectedIds.length !== 1 ? 's' : ''}
          </span>
          <div className="flex-1" />
          <Button
            variant="outline-success"
            size="sm"
            onClick={handleBulkApprove}
            loading={isPending}
          >
            Aprobar todos
          </Button>
          <Button variant="outline-danger" size="sm" onClick={() => setBulkRejectOpen(true)} loading={isPending}>
            Rechazar todos
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setSelectedIds([])}>
            Cancelar
          </Button>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/50">
              <th className="px-4 py-3 text-left">
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={toggleAll}
                  className="rounded border-slate-600 bg-slate-800 text-amber-500 focus:ring-amber-500"
                  aria-label="Seleccionar todos"
                />
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide">
                Activo
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden md:table-cell">
                Vendedor
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden lg:table-cell">
                Tipo
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide">
                Precio
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden md:table-cell">
                Estado
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden lg:table-cell">
                Fecha
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-slate-400 uppercase tracking-wide">
                Acciones
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {listings.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center text-slate-500">
                  No hay listados para mostrar.
                </td>
              </tr>
            ) : (
              listings.map((listing) => (
                <tr
                  key={listing.id}
                  className={cn(
                    'hover:bg-slate-800/30 transition-colors',
                    selectedIds.includes(listing.id) && 'bg-amber-500/5'
                  )}
                >
                  {/* Checkbox */}
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(listing.id)}
                      onChange={() => toggleOne(listing.id)}
                      className="rounded border-slate-600 bg-slate-800 text-amber-500 focus:ring-amber-500"
                      aria-label={`Seleccionar ${listing.title}`}
                    />
                  </td>

                  {/* Thumbnail + title */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {listing.screenshotUrls?.[0] ? (
                        <img
                          src={listing.screenshotUrls[0]}
                          alt={listing.title}
                          className="size-10 rounded-lg object-cover flex-shrink-0"
                        />
                      ) : (
                        <div className="size-10 rounded-lg bg-slate-800 flex-shrink-0" />
                      )}
                      <Link
                        href={`/admin/listados/${listing.id}`}
                        className="text-slate-200 hover:text-amber-500 font-medium truncate max-w-[180px] transition-colors"
                      >
                        {listing.title}
                      </Link>
                    </div>
                  </td>

                  {/* Seller */}
                  <td className="px-4 py-3 text-slate-400 hidden md:table-cell">
                    {listing.seller.fullName ?? listing.seller.email}
                  </td>

                  {/* Type */}
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <span className="text-slate-400 text-xs">
                      {TYPE_LABELS[listing.type] ?? listing.type}
                    </span>
                  </td>

                  {/* Price */}
                  <td className="px-4 py-3 text-amber-500 font-medium whitespace-nowrap">
                    {listing.currency} {Number(listing.askingPrice).toLocaleString()}
                  </td>

                  {/* Status */}
                  <td className="px-4 py-3 hidden md:table-cell">
                    <Badge variant={STATUS_VARIANTS[listing.status] ?? 'muted'}>
                      {STATUS_LABELS[listing.status] ?? listing.status}
                    </Badge>
                  </td>

                  {/* Date */}
                  <td className="px-4 py-3 text-slate-500 text-xs hidden lg:table-cell whitespace-nowrap">
                    {timeAgo(listing.createdAt)}
                  </td>

                  {/* Actions */}
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1.5">
                      <Button
                        variant="outline-success"
                        size="sm"
                        onClick={() => handleApprove(listing.id)}
                        title="Aprobar"
                      >
                        <CheckCircle className="size-3.5" />
                        <span className="hidden lg:inline">Aprobar</span>
                      </Button>
                      <Button
                        variant="outline-danger"
                        size="sm"
                        onClick={() => openPreview(listing)}
                        title="Rechazar — abre panel"
                      >
                        <XCircle className="size-3.5" />
                        <span className="hidden lg:inline">Rechazar</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openPreview(listing)}
                        title="Ver preview"
                      >
                        <Eye className="size-3.5" />
                        <span className="hidden lg:inline">Ver</span>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Preview panel */}
      <ListingPreviewPanel
        listing={previewListing}
        isOpen={isPanelOpen}
        onClose={() => setIsPanelOpen(false)}
        onApprove={handleApprove}
        onReject={handleReject}
      />

      {/* Bulk reject modal */}
      <Modal
        open={bulkRejectOpen}
        onClose={() => { setBulkRejectOpen(false); setBulkRejectReason('') }}
        title={`Rechazar ${selectedIds.length} listado${selectedIds.length !== 1 ? 's' : ''}`}
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-400">
            Este motivo se aplicará a todos los listados seleccionados.
          </p>
          <textarea
            className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-500 resize-none focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="Motivo del rechazo (mínimo 20 caracteres)..."
            value={bulkRejectReason}
            onChange={(e) => setBulkRejectReason(e.target.value)}
            rows={3}
            maxLength={500}
            autoFocus
          />
          <p className="text-xs text-slate-500 text-right">
            {bulkRejectReason.length} / 500
            {bulkRejectReason.trim().length < 20 && ` — mínimo 20`}
          </p>
          <div className="flex gap-3">
            <Button
              variant="outline-danger"
              size="md"
              onClick={handleBulkRejectConfirm}
              loading={bulkLoading}
              disabled={bulkRejectReason.trim().length < 20}
              className="flex-1"
            >
              Confirmar rechazo
            </Button>
            <Button
              variant="ghost"
              size="md"
              onClick={() => { setBulkRejectOpen(false); setBulkRejectReason('') }}
              className="flex-1"
            >
              Cancelar
            </Button>
          </div>
        </div>
      </Modal>
    </>
  )
}
