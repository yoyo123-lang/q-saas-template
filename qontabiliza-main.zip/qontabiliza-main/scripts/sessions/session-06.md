# Sesión 6: Facturación ARCA (frontend) + PDF

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 6
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Crear facturas desde la UI, ver listado, generar PDF descargable con formato fiscal argentino.

## Pre-requisitos

Sesión 5 completada (AfipService, API routes de facturación).

## Etapas

### Etapa 1: Formulario de nueva factura
- Seleccionar cliente (con autocompletado)
- Determinar tipo de comprobante automáticamente según condición IVA del emisor y receptor
- Agregar ítems (producto, cantidad, precio unitario, alícuota IVA)
- Cálculos automáticos: subtotal, IVA discriminado, total
- Validación completa antes de emitir

### Etapa 2: Listado de facturas
- DataTable con columnas: número, tipo, fecha, cliente, total, estado
- Filtros: rango de fechas, tipo de comprobante, cliente
- Búsqueda por número de comprobante
- Paginación server-side

### Etapa 3: Generación de PDF
- Formato fiscal argentino (datos del emisor, receptor, detalle, CAE, vencimiento CAE)
- Código QR con datos fiscales (requerido por ARCA)
- Usar @react-pdf/renderer o similar
- Descarga directa y opción de envío por email (preparar interfaz)

### Etapa 4: Detalle de factura + Notas de crédito/débito
- Página de detalle de factura con toda la información
- Botón "Emitir nota de crédito" asociada a la factura
- Botón "Emitir nota de débito" asociada
- Historial de comprobantes relacionados

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
