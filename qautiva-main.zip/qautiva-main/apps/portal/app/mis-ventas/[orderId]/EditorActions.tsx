'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { OrderStatus } from '@qautiva/db/types'

type Props = {
  orderId: string
  currentStatus: OrderStatus
}

export function EditorActions({ orderId, currentStatus }: Props) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Entrega
  const [deliveryUrl, setDeliveryUrl] = useState('')
  const [deliveryNotes, setDeliveryNotes] = useState('')
  const [showDeliveryForm, setShowDeliveryForm] = useState(false)

  // Rechazo
  const [rejectReason, setRejectReason] = useState('')
  const [showRejectForm, setShowRejectForm] = useState(false)

  const canAcceptOrReject = currentStatus === OrderStatus.PENDING
  const canDeliver = currentStatus === OrderStatus.ACCEPTED || currentStatus === OrderStatus.REVISION

  if (!canAcceptOrReject && !canDeliver) return null

  async function patch(status: OrderStatus, extra?: Record<string, string>) {
    setError(null)
    setLoading(true)
    try {
      const res = await fetch(`/api/marketplace/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, ...extra }),
      })
      const data = (await res.json()) as { error?: string }
      if (!res.ok) {
        setError(data.error ?? 'Ocurrió un error.')
        return
      }
      router.refresh()
    } catch {
      setError('No se pudo conectar con el servidor.')
    } finally {
      setLoading(false)
    }
  }

  function handleDeliver(e: React.FormEvent) {
    e.preventDefault()
    if (!deliveryUrl.trim()) {
      setError('La URL de entrega es requerida.')
      return
    }
    try {
      new URL(deliveryUrl.trim())
    } catch {
      setError('Ingresá una URL válida.')
      return
    }
    patch(OrderStatus.DELIVERED, {
      deliveryUrl: deliveryUrl.trim(),
      ...(deliveryNotes.trim() ? { deliveryNotes: deliveryNotes.trim() } : {}),
    })
  }

  const inputClass =
    'w-full bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-[#334155] placeholder-[#475569]'

  return (
    <section aria-label="Acciones de la venta" className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4">
      <h2 className="text-white font-semibold">Acciones</h2>

      {/* PENDING: aceptar o rechazar */}
      {canAcceptOrReject && (
        <>
          <p className="text-[#94A3B8] text-sm">
            Tenés{' '}
            <span className="text-yellow-400 font-medium">3 días</span>
            {' '}para aceptar o rechazar este pedido.
          </p>

          {showRejectForm ? (
            <div className="flex flex-col gap-3">
              <label htmlFor="rejectReason" className="text-white font-semibold text-sm">
                Motivo del rechazo <span className="text-[#64748B] font-normal">(opcional)</span>
              </label>
              <textarea
                id="rejectReason"
                rows={3}
                maxLength={2000}
                placeholder="Explicale al anunciante por qué no podés aceptar este pedido…"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className={`${inputClass} resize-none`}
              />
              <div className="flex gap-2 flex-wrap">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() =>
                    patch(
                      OrderStatus.CANCELLED,
                      rejectReason.trim() ? { cancellationReason: rejectReason.trim() } : {},
                    )
                  }
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#3B1414] text-red-400 hover:bg-[#4A1A1A] disabled:opacity-50 transition-colors"
                >
                  Confirmar rechazo
                </button>
                <button
                  type="button"
                  onClick={() => { setShowRejectForm(false); setRejectReason('') }}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          ) : (
            <div className="flex gap-2 flex-wrap">
              <button
                type="button"
                disabled={loading}
                onClick={() => patch(OrderStatus.ACCEPTED)}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-[#0F2E2A] text-[#34D399] hover:bg-[#0F3A34] disabled:opacity-50 transition-colors"
              >
                ✓ Aceptar pedido
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={() => setShowRejectForm(true)}
                className="px-4 py-2 rounded-lg text-sm font-medium bg-[#3B1414] text-red-400 hover:bg-[#4A1A1A] disabled:opacity-50 transition-colors"
              >
                Rechazar
              </button>
            </div>
          )}
        </>
      )}

      {/* ACCEPTED / REVISION: entregar */}
      {canDeliver && (
        <>
          {currentStatus === OrderStatus.REVISION && (
            <p className="text-orange-400 text-sm">
              El anunciante pidió correcciones. Realizalas y volvé a entregar.
            </p>
          )}
          {showDeliveryForm ? (
            <form onSubmit={handleDeliver} className="flex flex-col gap-3">
              <div>
                <label htmlFor="deliveryUrl" className="text-white font-semibold block mb-1 text-sm">
                  URL del contenido publicado <span className="text-red-400">*</span>
                </label>
                <input
                  id="deliveryUrl"
                  type="url"
                  placeholder="https://tusitioweb.com/articulo-publicado"
                  value={deliveryUrl}
                  onChange={(e) => setDeliveryUrl(e.target.value)}
                  className={inputClass}
                  required
                />
              </div>
              <div>
                <label htmlFor="deliveryNotes" className="text-white font-semibold block mb-1 text-sm">
                  Notas adicionales <span className="text-[#64748B] font-normal">(opcional)</span>
                </label>
                <textarea
                  id="deliveryNotes"
                  rows={2}
                  maxLength={2000}
                  placeholder="Cualquier detalle relevante para el anunciante…"
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  className={`${inputClass} resize-none`}
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                <button
                  type="submit"
                  disabled={loading}
                  aria-busy={loading}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E3A5F] text-[#60A5FA] hover:bg-[#1E4D8C] disabled:opacity-50 transition-colors"
                >
                  {loading ? 'Enviando…' : 'Marcar como entregado'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowDeliveryForm(false)}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </form>
          ) : (
            <button
              type="button"
              disabled={loading}
              onClick={() => setShowDeliveryForm(true)}
              className="self-start px-4 py-2 rounded-lg text-sm font-medium bg-[#1E3A5F] text-[#60A5FA] hover:bg-[#1E4D8C] disabled:opacity-50 transition-colors"
            >
              Registrar entrega
            </button>
          )}
        </>
      )}

      {error && (
        <p role="alert" className="text-red-400 text-xs">{error}</p>
      )}
    </section>
  )
}
