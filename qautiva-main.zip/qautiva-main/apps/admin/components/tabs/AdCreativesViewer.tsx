'use client'

/**
 * Visor legible de un deliverable tipo AD_CREATIVES.
 * Muestra variantes de copy por plataforma/formato en cards legibles.
 * Mantiene un toggle "Ver JSON" para debugging.
 */

import { useState } from 'react'

type AdCopyVariant = {
  headline?: string
  description?: string
  callToAction?: string
  angle?: string
}

type AdCreatives = {
  googleAds?: { search?: AdCopyVariant[] } | null
  metaAds?: { feed?: AdCopyVariant[]; story?: AdCopyVariant[] } | null
  guiaDeTono?: { tono?: string; palabrasClave?: string[] }
  disclaimer?: string
}

type Section = { label: string; variants: AdCopyVariant[] }

function VariantRow({ variant, index }: { variant: AdCopyVariant; index: number }) {
  return (
    <div className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-[#475569]">Variante {index + 1}</span>
        {variant.angle && <span className="text-[10px] text-[#475569] italic truncate max-w-[60%]">{variant.angle}</span>}
      </div>
      {variant.headline && (
        <p className="text-sm font-medium text-white">{variant.headline}</p>
      )}
      {variant.description && (
        <p className="text-xs text-[#94A3B8]">{variant.description}</p>
      )}
      {variant.callToAction && (
        <span className="inline-block px-2 py-0.5 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 text-[10px] text-[#A78BFA]">
          {variant.callToAction}
        </span>
      )}
    </div>
  )
}

type Props = { data: unknown }

export function AdCreativesViewer({ data }: Props) {
  const [showJson, setShowJson] = useState(false)

  let creatives: AdCreatives
  try {
    creatives = (typeof data === 'string' ? JSON.parse(data) : data) as AdCreatives
  } catch {
    return <pre className="text-xs text-[#94A3B8] whitespace-pre-wrap">{String(data)}</pre>
  }

  if (!creatives || typeof creatives !== 'object') {
    return <pre className="text-xs text-[#94A3B8] whitespace-pre-wrap">{JSON.stringify(data, null, 2)}</pre>
  }

  const sections: Section[] = [
    { label: 'Google Search', variants: creatives.googleAds?.search ?? [] },
    { label: 'Meta Feed', variants: creatives.metaAds?.feed ?? [] },
    { label: 'Meta Story', variants: creatives.metaAds?.story ?? [] },
  ].filter((s) => s.variants.length > 0)

  return (
    <div className="space-y-4 mt-2">
      {creatives.disclaimer && (
        <p className="text-[10px] text-[#475569] italic">{creatives.disclaimer}</p>
      )}

      {creatives.guiaDeTono?.tono && (
        <div>
          <p className="text-[10px] text-[#64748B] uppercase tracking-wider mb-1">Tono</p>
          <p className="text-xs text-[#94A3B8]">{creatives.guiaDeTono.tono}</p>
        </div>
      )}

      {sections.map((section) => (
        <div key={section.label}>
          <p className="text-[10px] text-[#64748B] uppercase tracking-wider mb-2">{section.label}</p>
          <div className="space-y-2">
            {section.variants.map((v, i) => (
              <VariantRow key={i} variant={v} index={i} />
            ))}
          </div>
        </div>
      ))}

      {sections.length === 0 && (
        <p className="text-xs text-[#64748B]">No hay piezas publicitarias en este deliverable.</p>
      )}

      {/* Toggle JSON */}
      <button
        type="button"
        onClick={() => setShowJson((v) => !v)}
        className="flex items-center gap-1.5 text-[10px] text-[#475569] hover:text-[#64748B] transition-colors mt-1"
      >
        <span className="font-mono">{showJson ? '▾' : '▸'}</span>
        Ver JSON crudo
      </button>
      {showJson && (
        <pre className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-xs font-mono overflow-x-auto max-h-64 overflow-y-auto whitespace-pre-wrap break-words">
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  )
}
