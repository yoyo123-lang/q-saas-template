# Performance Engineer Review
**Fecha:** 2026-03-25
**Archivos revisados:**
- `src/lib/tenant.ts`
- `prisma/schema.prisma`

---

## Hallazgos

### ALTO

#### PERF-01 — Missing composite index en StockMovement para cálculo de stock actual
**Archivo:** `prisma/schema.prisma:527-531`
**Descripción:** La query más frecuente en el módulo de stock es "¿cuánto stock tiene el producto X en el depósito Y?". Esa query necesita filtrar por `(organizationId, productId, warehouseId)`. Los índices actuales son: `organizationId`, `warehouseId`, `productId`, `(organizationId, movedAt)`. No existe un índice compuesto `(organizationId, productId, warehouseId)`, lo que fuerza un multi-index scan o full scan del índice de `productId`.
**Fix sugerido:**
```prisma
@@index([organizationId, productId, warehouseId])
```

#### PERF-02 — `withTenant()` no impone límite de paginación en `findMany`
**Archivo:** `src/lib/tenant.ts:57-62`
**Descripción:** El interceptor de `findMany` inyecta el filtro de tenant pero no impone `take` máximo. Una query `db.invoice.findMany()` sin paginación retornaría TODAS las facturas de un tenant. Para un comercio con 50.000 facturas por año, esto es una query catastrófica.
**Fix sugerido:** Considerar agregar un `take` default (ej: 100) si no se especifica, o al menos loguear un warning cuando `take` no está presente.

---

### MEDIO

#### PERF-03 — `withTenant()` crea una nueva Prisma extension por llamada
**Archivo:** `src/lib/tenant.ts:53-54`
**Descripción:** `prisma.$extends({...})` es una operación que crea un nuevo objeto Proxy en cada invocación. Si `withTenant()` se llama múltiples veces en una misma request (ej: en diferentes Server Components o helpers), el overhead se acumula.
**Fix sugerido:** Memoizar con un `Map<string, ReturnType<typeof withTenant>>` con tamaño máximo acotado (ej: LRU de 100 entradas, ya que el número de orgs activas en memoria es limitado).

#### PERF-04 — N+1 potencial en Sale → SaleItem y Invoice → InvoiceItem
**Archivo:** `prisma/schema.prisma:429-455, 369-397`
**Descripción:** No hay `include` por defecto ni ningún mecanismo que fuerce eager loading. El patrón típico de un listado de ventas fetcheando items por separado es un N+1 clásico. Con 50 ventas en pantalla = 51 queries.
**Fix sugerido:** Documentar en los comentarios del schema que `SaleItem` e `InvoiceItem` deben cargarse siempre con `include: { items: true }`. Considerar agregar un helper `getSaleWithItems(id)` que encapsule el include correcto.

#### PERF-05 — Missing composite index en Invoice para queries de período fiscal
**Archivo:** `prisma/schema.prisma:393-396`
**Descripción:** El índice `(organizationId, issuedAt)` existe, pero queries fiscales típicas filtran por `(organizationId, status, issuedAt)` (ej: todas las facturas ISSUED del mes). Sin índice compuesto de los tres campos, PostgreSQL usa el de 2 campos y filtra `status` en memoria.
**Fix sugerido:**
```prisma
@@index([organizationId, status, issuedAt])
```

---

### BAJO

#### PERF-06 — Seed ejecuta upserts secuenciales sin transacción
**Archivo:** `prisma/seed.ts:84-237`
**Descripción:** Cada `upsert` es un round-trip a la BD. El seed tiene ~10 upserts ejecutados en secuencia. Para un seed de producción más grande, esto sería lento. Además, si el seed falla a mitad (ej: al crear el producto después de crear la categoría), la BD queda en estado parcial.
**Fix sugerido:** Envolver el seed en `prisma.$transaction([...])` para atomicidad. Para performance, agrupar operaciones independientes.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 0        |
| ALTO      | 2        |
| MEDIO     | 3        |
| BAJO      | 1        |
| **Total** | **6**    |
