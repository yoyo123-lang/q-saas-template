import type { Metadata } from 'next'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import { QueueView } from './_components/QueueView'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Cola de diseños Stitch | Qautiva Admin' }

export default async function TemplatesColaPage() {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Reset inline de cuentas si lastResetAt es anterior a hoy
  await prisma.stitchAccount.updateMany({
    where: {
      active: true,
      lastResetAt: { lt: today },
    },
    data: {
      usedToday: 0,
      lastResetAt: new Date(),
    },
  })

  const [accounts, jobs, queueConfig] = await Promise.all([
    prisma.stitchAccount.findMany({
      select: {
        id: true,
        label: true,
        usedToday: true,
        dailyLimit: true,
        lastResetAt: true,
        active: true,
      },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.webTemplate.findMany({
      where: { NOT: { queueStatus: null } },
      select: {
        id: true,
        queueStatus: true,
        queuedAt: true,
        styleId: true,
        compatibleIndustries: true,
        status: true,
        stitchAccount: {
          select: { id: true, label: true },
        },
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { queuedAt: 'desc' },
      take: 500,
    }),
    prisma.stitchQueueConfig.findUnique({ where: { id: 1 } }),
  ])

  const counts = {
    pending: jobs.filter((j) => j.queueStatus === 'QUEUED').length,
    generating: jobs.filter((j) => j.queueStatus === 'GENERATING').length,
    done: jobs.filter((j) => j.queueStatus === 'DONE').length,
  }

  // Serializar fechas para los client components
  const serializedAccounts = accounts.map((a) => ({
    ...a,
    lastResetAt: a.lastResetAt.toISOString(),
  }))

  const serializedJobs = jobs.map((j) => ({
    ...j,
    queuedAt: j.queuedAt?.toISOString() ?? null,
    createdAt: j.createdAt.toISOString(),
    updatedAt: j.updatedAt.toISOString(),
  }))

  return (
    <div className="p-8 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Cola de diseños Stitch</h1>
          <p className="text-[#64748B] text-sm mt-1">
            Generación masiva de templates por industria. Sin consumir cupo hasta que ejecutes.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/templates"
            className="px-4 py-2 bg-[#1E293B] text-[#94A3B8] text-sm font-medium rounded-lg hover:bg-[#1E293B]/80 hover:text-white transition-colors"
          >
            Ver templates
          </Link>
          <Link
            href="/templates/nuevo"
            className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] transition-colors"
          >
            Generar nuevo
          </Link>
        </div>
      </div>

      <QueueView
        initialAccounts={serializedAccounts}
        initialJobs={serializedJobs as Parameters<typeof QueueView>[0]['initialJobs']}
        initialCounts={counts}
        initialPaused={queueConfig?.paused ?? false}
      />
    </div>
  )
}
