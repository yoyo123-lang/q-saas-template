import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import {
  isCommercialLeadAnswer,
  getLeadServiceKey,
  buildCommercialLead,
  notifyCommercialLeadTelegram,
  type CommercialLead,
} from '../commercial-leads'

// ── isCommercialLeadAnswer ───────────────────────────────────────────────────

describe('isCommercialLeadAnswer', () => {
  it('returns true for web_agenda = me_interesa', () => {
    expect(isCommercialLeadAnswer('web_agenda', 'me_interesa')).toBe(true)
  })

  it('returns true for web_pagos = me_interesa', () => {
    expect(isCommercialLeadAnswer('web_pagos', 'me_interesa')).toBe(true)
  })

  it('returns false for web_agenda = si', () => {
    expect(isCommercialLeadAnswer('web_agenda', 'si')).toBe(false)
  })

  it('returns false for web_agenda = no', () => {
    expect(isCommercialLeadAnswer('web_agenda', 'no')).toBe(false)
  })

  it('returns false for unrelated questions', () => {
    expect(isCommercialLeadAnswer('web_objetivo', 'me_interesa')).toBe(false)
    expect(isCommercialLeadAnswer('web_blog', 'me_interesa')).toBe(false)
    expect(isCommercialLeadAnswer('web_empleo', 'me_interesa')).toBe(false)
  })

  it('returns false for non-string answers', () => {
    expect(isCommercialLeadAnswer('web_agenda', 123)).toBe(false)
    expect(isCommercialLeadAnswer('web_agenda', null)).toBe(false)
    expect(isCommercialLeadAnswer('web_agenda', undefined)).toBe(false)
  })
})

// ── getLeadServiceKey ────────────────────────────────────────────────────────

describe('getLeadServiceKey', () => {
  it('returns qontacta for web_agenda', () => {
    expect(getLeadServiceKey('web_agenda')).toBe('qontacta')
  })

  it('returns qobra for web_pagos', () => {
    expect(getLeadServiceKey('web_pagos')).toBe('qobra')
  })

  it('returns null for unknown questions', () => {
    expect(getLeadServiceKey('web_objetivo')).toBeNull()
    expect(getLeadServiceKey('web_blog')).toBeNull()
    expect(getLeadServiceKey('random_question')).toBeNull()
  })
})

// ── buildCommercialLead ──────────────────────────────────────────────────────

describe('buildCommercialLead', () => {
  it('creates a lead for web_agenda', () => {
    const result = buildCommercialLead('web_agenda', [])
    expect(result).not.toBeNull()
    expect(result).toHaveLength(1)
    expect(result![0].service).toBe('qontacta')
    expect(result![0].label).toBe('Qontacta (agenda/CRM)')
    expect(result![0].questionId).toBe('web_agenda')
    expect(result![0].createdAt).toBeDefined()
  })

  it('creates a lead for web_pagos', () => {
    const result = buildCommercialLead('web_pagos', [])
    expect(result).not.toBeNull()
    expect(result![0].service).toBe('qobra')
  })

  it('returns null for unknown questions', () => {
    expect(buildCommercialLead('web_objetivo', [])).toBeNull()
  })

  it('deduplicates by service key', () => {
    const existing: CommercialLead[] = [
      { service: 'qontacta', label: 'Qontacta (agenda/CRM)', questionId: 'web_agenda', createdAt: '2026-01-01' },
    ]
    const result = buildCommercialLead('web_agenda', existing)
    expect(result).toBeNull()
  })

  it('allows different services', () => {
    const existing: CommercialLead[] = [
      { service: 'qontacta', label: 'Qontacta (agenda/CRM)', questionId: 'web_agenda', createdAt: '2026-01-01' },
    ]
    const result = buildCommercialLead('web_pagos', existing)
    expect(result).not.toBeNull()
    expect(result).toHaveLength(2)
    expect(result![1].service).toBe('qobra')
  })
})

// ── notifyCommercialLeadTelegram ─────────────────────────────────────────────

describe('notifyCommercialLeadTelegram', () => {
  const originalEnv = process.env

  beforeEach(() => {
    process.env = { ...originalEnv }
    vi.spyOn(global, 'fetch').mockResolvedValue(new Response('{}', { status: 200 }))
  })

  afterEach(() => {
    process.env = originalEnv
    vi.restoreAllMocks()
  })

  it('does nothing if TELEGRAM_BOT_TOKEN is missing', async () => {
    delete process.env.TELEGRAM_BOT_TOKEN
    delete process.env.TELEGRAM_CHAT_ID

    await notifyCommercialLeadTelegram({
      service: 'qontacta',
      label: 'Qontacta',
      projectId: 'proj-1',
      sessionId: 'sess-1',
    })

    expect(global.fetch).not.toHaveBeenCalled()
  })

  it('sends Telegram message when configured', async () => {
    process.env.TELEGRAM_BOT_TOKEN = 'test-token'
    process.env.TELEGRAM_CHAT_ID = '123456'

    await notifyCommercialLeadTelegram({
      service: 'qontacta',
      label: 'Qontacta (agenda/CRM)',
      projectId: 'proj-1',
      sessionId: 'sess-1',
    })

    expect(global.fetch).toHaveBeenCalledTimes(1)
    const [url, options] = (global.fetch as ReturnType<typeof vi.fn>).mock.calls[0]
    expect(url).toContain('api.telegram.org/bottest-token/sendMessage')
    const body = JSON.parse(options.body)
    expect(body.chat_id).toBe('123456')
    expect(body.text).toContain('Qontacta')
    expect(body.text).toContain('proj-1')
  })

  it('uses TELEGRAM_LEADS_CHAT_ID over TELEGRAM_CHAT_ID when available', async () => {
    process.env.TELEGRAM_BOT_TOKEN = 'test-token'
    process.env.TELEGRAM_CHAT_ID = '123456'
    process.env.TELEGRAM_LEADS_CHAT_ID = '789012'

    await notifyCommercialLeadTelegram({
      service: 'qobra',
      label: 'Qobra',
      projectId: 'proj-1',
      sessionId: 'sess-1',
    })

    const body = JSON.parse((global.fetch as ReturnType<typeof vi.fn>).mock.calls[0][1].body)
    expect(body.chat_id).toBe('789012')
  })

  it('handles fetch errors gracefully', async () => {
    process.env.TELEGRAM_BOT_TOKEN = 'test-token'
    process.env.TELEGRAM_CHAT_ID = '123456'
    vi.spyOn(global, 'fetch').mockRejectedValue(new Error('network error'))

    // Should not throw
    await expect(
      notifyCommercialLeadTelegram({
        service: 'qontacta',
        label: 'Qontacta',
        projectId: 'proj-1',
        sessionId: 'sess-1',
      }),
    ).resolves.toBeUndefined()
  })
})
