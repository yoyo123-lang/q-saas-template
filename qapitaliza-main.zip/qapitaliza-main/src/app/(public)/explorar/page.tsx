import { Suspense } from 'react'
import { getListings } from '@/lib/data/listings'
import { getFavoriteIds } from '@/lib/data/favorites'
import { createClient } from '@/lib/supabase/server'
import { FilterSidebar } from '@/components/listings/filter-sidebar'
import { ResultsGrid } from '@/components/listings/results-grid'
import { ErrorState } from '@/components/shared/error-state'
import { SkeletonCard } from '@/components/ui/skeleton-card'

interface ExplorarPageProps {
  searchParams: Promise<{
    q?: string
    category?: string
    priceMin?: string
    priceMax?: string
    revenueMin?: string
    verified?: string
    tech?: string | string[]
    sort?: string
    page?: string
  }>
}

export const metadata = {
  title: 'Explorar activos',
  description: 'Explorá el catálogo de sitios web, dominios, SaaS y proyectos digitales disponibles.',
}

type ListingItem = {
  id: string
  slug: string
  title: string
  type: string
  askingPrice: string
  monthlyRevenue: string | null
  monthlyTraffic: number | null
  screenshotUrls: string[]
  techStack: string[]
  verificationStatus: string
  featuredUntil: Date | string | null
}

async function loadData(params: Awaited<ExplorarPageProps['searchParams']>, page: number) {
  const tech = params.tech
    ? Array.isArray(params.tech)
      ? params.tech
      : [params.tech]
    : undefined

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [{ items: rawItems, total }, favoriteIds] = await Promise.all([
    getListings({
      q: params.q,
      category: params.category,
      priceMin: params.priceMin ? parseFloat(params.priceMin) : undefined,
      priceMax: params.priceMax ? parseFloat(params.priceMax) : undefined,
      revenueMin: params.revenueMin ? parseFloat(params.revenueMin) : undefined,
      verified: params.verified === 'true' ? true : undefined,
      tech,
      sort: params.sort as 'newest' | 'price_asc' | 'price_desc' | 'views' | undefined,
      page,
    }),
    user ? getFavoriteIds(user.id) : Promise.resolve([]),
  ])

  const items: ListingItem[] = rawItems.map((item) => ({
    ...item,
    askingPrice: item.askingPrice.toString(),
    monthlyRevenue: item.monthlyRevenue?.toString() ?? null,
  }))

  return { items, total, favoriteIds, isAuthenticated: !!user }
}

export default async function ExplorarPage({ searchParams }: ExplorarPageProps) {
  const params = await searchParams
  const page = Math.max(1, parseInt(params.page ?? '1', 10) || 1)

  let data: Awaited<ReturnType<typeof loadData>> | null = null
  let loadError = false

  try {
    data = await loadData(params, page)
  } catch (e) {
    console.error('[ExplorarPage] Failed to load listings:', e)
    loadError = true
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50">Explorar activos</h1>
        <p className="text-slate-400 mt-1">
          Encontrá el activo digital que estás buscando.
        </p>
      </div>

      {loadError || !data ? (
        <ErrorState message="No pudimos cargar los activos en este momento. Intentá de nuevo más tarde." />
      ) : (
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8 items-start">
          <Suspense fallback={null}>
            <FilterSidebar />
          </Suspense>

          <Suspense
            fallback={
              <div className="flex-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)}
                </div>
              </div>
            }
          >
            <ResultsGrid
              items={data.items}
              total={data.total}
              currentPage={page}
              initialFavoriteIds={data.favoriteIds}
              isAuthenticated={data.isAuthenticated}
            />
          </Suspense>
        </div>
      )}
    </div>
  )
}
