import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

/**
 * PATCH /api/interview/sessions/[id]/template
 * Guarda el template web seleccionado por el cliente en la etapa WEBSITE.
 * Ajusta usageCount de forma atómica dentro de una transacción interactiva para
 * evitar race conditions si el usuario cambia de selección en múltiples pestañas.
 *
 * Body: { templateId: string }
 * Returns: { ok: true }
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  if (!UUID_RE.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  let body: { templateId?: unknown }
  try {
    body = (await request.json()) as { templateId?: unknown }
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { templateId } = body
  if (!templateId || typeof templateId !== 'string' || !UUID_RE.test(templateId)) {
    return NextResponse.json({ error: 'templateId inválido' }, { status: 400 })
  }

  // Verificar ownership: usuario → team → sesión
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const session = await prisma.interviewSession.findFirst({
    where: {
      id: params.id,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: { id: true, teamId: true },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Fail-closed: verificar teamId antes de cualquier guard
  if (!session.teamId) {
    console.error('[template] session sin teamId — error de datos, bloqueando ejecución', {
      sessionId: params.id,
    })
    return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
  }

  // Guard de permisos: MEMBER solo tiene lectura
  const perm = await checkTeamPermission(user.id, session.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden realizar esta acción.' },
      { status: 403 },
    )
  }

  // Verificar que el template existe y está activo antes de la transacción
  const template = await prisma.webTemplate.findUnique({
    where: { id: templateId },
    select: { id: true, status: true },
  })

  if (!template || template.status !== 'ACTIVE') {
    return NextResponse.json({ error: 'Template no disponible' }, { status: 404 })
  }

  try {
    // Transacción interactiva: lee y escribe dentro del mismo snapshot para
    // evitar race conditions si dos requests concurrentes cambian el template.
    await prisma.$transaction(async (tx) => {
      // Leer el estado actual DENTRO de la transacción
      const current = await tx.interviewSession.findUnique({
        where: { id: session.id },
        select: { selectedWebTemplateId: true, status: true },
      })

      const previousTemplateId = current?.selectedWebTemplateId ?? null
      const isNewSelection = previousTemplateId !== templateId

      // If the session errored because the cron ran before the user selected a template,
      // reset it to PROCESSING so it can be processed correctly after this selection.
      const wasErroredWithoutTemplate = current?.status === 'ERROR' && !previousTemplateId

      await tx.interviewSession.update({
        where: { id: session.id },
        data: {
          selectedWebTemplateId: templateId,
          ...(wasErroredWithoutTemplate ? {
            status: 'PROCESSING',
            lastError: null,
            retryCount: 0,
            processingStartedAt: null,
          } : {}),
        },
      })

      if (isNewSelection) {
        await tx.webTemplate.update({
          where: { id: templateId },
          data: { usageCount: { increment: 1 } },
        })

        // Decrementar el anterior con guarda para no ir a negativo
        if (previousTemplateId) {
          await tx.webTemplate.updateMany({
            where: { id: previousTemplateId, usageCount: { gt: 0 } },
            data: { usageCount: { decrement: 1 } },
          })
        }
      }
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[interview/sessions/template] transaction failed', {
      sessionId: params.id,
      templateId,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al guardar el diseño. Intentá de nuevo.' }, { status: 500 })
  }
}
