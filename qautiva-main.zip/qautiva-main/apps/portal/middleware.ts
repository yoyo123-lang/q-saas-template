import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet: Array<{ name: string; value: string; options: CookieOptions }>) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options as Parameters<typeof supabaseResponse.cookies.set>[2]),
          )
        },
      },
    },
  )

  const {
    data: { user },
  } = await supabase.auth.getUser()

  const pathname = request.nextUrl.pathname

  // Rutas públicas: accesibles sin autenticación de Supabase
  const isPublicPath =
    pathname.startsWith('/login') ||
    pathname.startsWith('/auth') ||
    pathname.startsWith('/onboarding') ||
    pathname === '/api/health' ||
    pathname === '/api/onboarding' ||
    pathname.startsWith('/api/cron/')

  // Rutas de API que usan Bearer token propio (no cookies de Supabase).
  // Solo estas rutas específicas — no todas las /api/ para evitar bypass genérico.
  const isBearerAuthRoute =
    pathname.startsWith('/api/admin/') ||
    pathname.startsWith('/api/cron/')

  // Usuario no autenticado en ruta protegida
  if (!user && !isPublicPath) {
    if (isBearerAuthRoute && request.headers.get('authorization')?.startsWith('Bearer ')) {
      // Pasar al endpoint para que valide su propio Bearer token
      return supabaseResponse
    }
    // Rutas de API: 401 JSON (no redirect, es una API)
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }
    // Rutas de página: redirigir al login
    const url = request.nextUrl.clone()
    url.pathname = '/login'
    return NextResponse.redirect(url)
  }

  if (user && !isPublicPath) {
    const meta = user.app_metadata ?? {}

    // Expand-contract (Fase A):
    // - org_id: usuarios pre-self-service (agencia). Tienen acceso completo.
    // - onboarding_complete: usuarios self-service nuevos. Deben haber completado el wizard.
    const isLegacyUser = Boolean(meta.org_id)
    const hasCompletedOnboarding = Boolean(meta.onboarding_complete)

    if (!isLegacyUser && !hasCompletedOnboarding) {
      const url = request.nextUrl.clone()
      url.pathname = '/onboarding'
      return NextResponse.redirect(url)
    }
  }

  // Exponer pathname para Server Components (ej: onboarding layout progress bar)
  supabaseResponse.headers.set('x-pathname', pathname)
  return supabaseResponse
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
