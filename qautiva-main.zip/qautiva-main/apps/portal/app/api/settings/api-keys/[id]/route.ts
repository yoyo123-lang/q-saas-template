import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { getTeamForUser } from '@/app/_lib/get-team-for-user'

/**
 * DELETE /api/settings/api-keys/[id]
 * Revoca (elimina) una API key del equipo del usuario.
 * Verifica ownership antes de eliminar.
 * Retorna 409 si intentan eliminar la última key estando en modo BYOK.
 */
export async function DELETE(
  _request: Request,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const team = await getTeamForUser(user.id)
  if (!team) {
    return NextResponse.json({ error: 'No se encontró el equipo' }, { status: 404 })
  }

  // Guard de permisos: solo ADMIN y OWNER pueden revocar API keys
  if (!(['ADMIN', 'OWNER'] as string[]).includes(team.teamRole)) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden revocar API keys.' },
      { status: 403 },
    )
  }

  const apiKey = await prisma.apiKey.findUnique({
    where: { id: params.id },
    select: { id: true, teamId: true },
  })

  if (!apiKey) {
    return NextResponse.json({ error: 'API key no encontrada' }, { status: 404 })
  }

  if (apiKey.teamId !== team.teamId) {
    return NextResponse.json({ error: 'No tenés permiso para revocar esta key' }, { status: 403 })
  }

  // Verificar si es la última key en modo BYOK
  const billing = await prisma.billingAccount.findUnique({
    where: { teamId: team.teamId },
    select: { preferredKeySource: true },
  })

  if (billing?.preferredKeySource === 'BYOK') {
    const keyCount = await prisma.apiKey.count({ where: { teamId: team.teamId } })
    if (keyCount <= 1) {
      return NextResponse.json(
        { error: 'No podés revocar la última API key estando en modo BYOK. Cambiá el modo de IA primero.' },
        { status: 409 },
      )
    }
  }

  await prisma.apiKey.delete({ where: { id: params.id } })

  revalidatePath('/configuracion')

  return NextResponse.json({ ok: true })
}
