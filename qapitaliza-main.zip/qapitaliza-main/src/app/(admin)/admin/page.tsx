import Link from 'next/link'
import { Package, Users, MessageCircle, DollarSign, ArrowRight } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { ListingsBarChart, RegistrationsAreaChart } from '@/components/admin/admin-charts'
import {
  getMarketplaceStats,
  getWeeklyListingsChart,
  getDailyRegistrationsChart,
  getCategoryDistribution,
  getAllListings,
  getRecentAdminActivity,
} from '@/lib/data/admin'

const PERIOD_OPTIONS = [
  { label: 'Últimos 7 días', value: '7d' },
  { label: 'Últimos 30 días', value: '30d' },
  { label: 'Este mes', value: 'month' },
  { label: 'Este año', value: 'year' },
]

function formatM(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`
  if (value >= 1_000) return `${(value / 1_000).toFixed(0)}K`
  return value.toLocaleString()
}

const ACTION_LABELS: Record<string, string> = {
  LISTING_APPROVED: 'Listado aprobado',
  LISTING_REJECTED: 'Listado rechazado',
  LISTING_FEATURED: 'Listado destacado',
  LISTING_UNFEATURED: 'Destacado removido',
  USER_SUSPENDED: 'Usuario suspendido',
  USER_ROLE_CHANGED: 'Rol de usuario cambiado',
}

interface PageProps {
  searchParams: Promise<{ period?: string }>
}

export default async function AdminDashboardPage({ searchParams }: PageProps) {
  const { period = '30d' } = await searchParams

  const chartDays = period === '7d' ? 7 : period === 'month' ? 30 : period === 'year' ? 365 : 30
  const chartWeeks = period === '7d' ? 4 : period === 'month' ? 12 : period === 'year' ? 52 : 12

  const [stats, weeklyListings, dailyRegistrations, categoryDist, pendingListings, recentActivity] =
    await Promise.all([
      getMarketplaceStats(),
      getWeeklyListingsChart(chartWeeks),
      getDailyRegistrationsChart(chartDays),
      getCategoryDistribution(),
      getAllListings({ status: 'pending', limit: 5 }),
      getRecentAdminActivity(5),
    ])

  const statCards = [
    {
      label: 'Listados totales',
      value: stats.totalListings.toLocaleString(),
      trend: `+${stats.listingsTrend} este mes`,
      icon: Package,
      highlight: false,
    },
    {
      label: 'Usuarios registrados',
      value: stats.totalUsers.toLocaleString(),
      trend: `+${stats.usersTrend} este mes`,
      icon: Users,
      highlight: false,
    },
    {
      label: 'Consultas activas',
      value: stats.activeInquiries.toLocaleString(),
      trend: null,
      icon: MessageCircle,
      highlight: false,
    },
    {
      label: 'Volumen listado',
      value: `$${formatM(stats.totalVolume)} USD`,
      trend: null,
      icon: DollarSign,
      highlight: true,
    },
  ]

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Dashboard</h1>
          <p className="text-slate-400 text-sm mt-0.5">Resumen general del marketplace</p>
        </div>
        {/* Period selector */}
        <div className="flex items-center gap-1 bg-slate-800/50 p-1 rounded-lg border border-slate-700">
          {PERIOD_OPTIONS.map((opt) => (
            <a
              key={opt.value}
              href={`/admin?period=${opt.value}`}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                period === opt.value
                  ? 'bg-amber-500 text-navy-950'
                  : 'text-slate-400 hover:text-slate-50'
              }`}
            >
              {opt.label}
            </a>
          ))}
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <div
            key={card.label}
            className={`p-5 rounded-xl border ${
              card.highlight
                ? 'bg-amber-500/5 border-amber-500/20'
                : 'bg-navy-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                {card.label}
              </p>
              <card.icon
                className={card.highlight ? 'text-amber-500' : 'text-slate-500'}
                size={16}
              />
            </div>
            <p
              className={`text-2xl font-bold ${card.highlight ? 'text-amber-500' : 'text-slate-50'}`}
            >
              {card.value}
            </p>
            {card.trend && <p className="text-xs text-slate-500 mt-1">{card.trend}</p>}
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ListingsBarChart data={weeklyListings} />
        <RegistrationsAreaChart data={dailyRegistrations} />
      </div>

      {/* Bottom grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pending listings table — spans 2 cols */}
        <div className="lg:col-span-2 bg-navy-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <h2 className="font-semibold text-slate-50">Listados pendientes de revisión</h2>
              {pendingListings.total > 0 && (
                <Badge variant="danger">{pendingListings.total}</Badge>
              )}
            </div>
            <Link
              href="/admin/listados?status=pending"
              className="text-xs text-amber-500 hover:underline flex items-center gap-1"
            >
              Ver todos
              <ArrowRight className="size-3" />
            </Link>
          </div>

          {pendingListings.items.length === 0 ? (
            <p className="text-sm text-slate-500 py-4">Sin listados pendientes.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-800">
                    <th className="pb-2 text-left text-xs font-medium text-slate-400">Activo</th>
                    <th className="pb-2 text-left text-xs font-medium text-slate-400 hidden md:table-cell">
                      Vendedor
                    </th>
                    <th className="pb-2 text-left text-xs font-medium text-slate-400 hidden md:table-cell">
                      Tipo
                    </th>
                    <th className="pb-2 text-left text-xs font-medium text-slate-400">Precio</th>
                    <th className="pb-2 text-left text-xs font-medium text-slate-400 hidden lg:table-cell">
                      Enviado
                    </th>
                    <th className="pb-2 text-right text-xs font-medium text-slate-400">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {pendingListings.items.map((listing) => (
                    <tr key={listing.id} className="hover:bg-slate-800/20 transition-colors">
                      <td className="py-2.5 pr-3 max-w-[160px]">
                        <span className="text-slate-200 text-xs font-medium truncate block">
                          {listing.title}
                        </span>
                      </td>
                      <td className="py-2.5 pr-3 text-slate-400 text-xs hidden md:table-cell">
                        {listing.seller.fullName ?? listing.seller.email}
                      </td>
                      <td className="py-2.5 pr-3 text-slate-400 text-xs hidden md:table-cell">
                        {listing.type}
                      </td>
                      <td className="py-2.5 pr-3 text-amber-500 text-xs font-medium whitespace-nowrap">
                        {listing.currency} {Number(listing.askingPrice).toLocaleString()}
                      </td>
                      <td className="py-2.5 pr-3 text-slate-500 text-xs hidden lg:table-cell whitespace-nowrap">
                        {new Date(listing.createdAt).toLocaleDateString('es-AR')}
                      </td>
                      <td className="py-2.5 text-right">
                        <Link
                          href={`/admin/listados/${listing.id}`}
                          className="text-xs text-amber-500 hover:underline font-medium"
                        >
                          Revisar →
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right column: activity + category */}
        <div className="space-y-4">
          {/* Recent activity */}
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
            <h2 className="font-semibold text-slate-50 mb-4">Actividad reciente</h2>
            {recentActivity.length === 0 ? (
              <p className="text-sm text-slate-500">Sin actividad reciente.</p>
            ) : (
              <ul className="space-y-3">
                {recentActivity.map((log) => (
                  <li key={log.id} className="flex items-start gap-2">
                    <div className="size-1.5 rounded-full bg-amber-500 mt-1.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-slate-300">
                        {ACTION_LABELS[log.action] ?? log.action}
                      </p>
                      <p className="text-xs text-slate-500">
                        {new Date(log.createdAt).toLocaleDateString('es-AR')}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Category distribution */}
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
            <h2 className="font-semibold text-slate-50 mb-4">Distribución por categoría</h2>
            {categoryDist.length === 0 ? (
              <p className="text-sm text-slate-500">Sin datos de categorías.</p>
            ) : (
              <div className="space-y-3">
                {categoryDist.slice(0, 6).map((cat) => (
                  <div key={cat.slug} className="flex items-center gap-3">
                    <span className="text-xs text-slate-400 w-20 truncate">{cat.label}</span>
                    <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all"
                        style={{ width: `${cat.percentage}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-50 w-8 text-right">{cat.count}</span>
                    <span className="text-xs text-slate-500 w-10 text-right">
                      {cat.percentage}%
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
