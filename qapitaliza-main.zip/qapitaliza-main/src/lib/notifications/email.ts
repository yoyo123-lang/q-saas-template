/**
 * Email notifications module using Resend.
 *
 * Templates are plain-text for the MVP. HTML templates can be added later.
 * If RESEND_API_KEY is not configured, emails are skipped with a warning
 * so missing env vars never break the main flow in development.
 */

import { Resend } from 'resend'

function getResend(): Resend | null {
  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) {
    console.warn('[email] RESEND_API_KEY not configured — email skipped')
    return null
  }
  return new Resend(apiKey)
}

function getFromAddress(): string {
  return process.env.RESEND_FROM_EMAIL ?? 'Qapitaliza <noreply@qapitaliza.com>'
}

function getAppUrl(): string {
  return process.env.NEXT_PUBLIC_APP_URL ?? 'https://qapitaliza.com'
}

/**
 * Notifica al vendedor cuando un comprador inicia una consulta.
 */
export async function sendNewInquiryEmail(
  to: string,
  listingTitle: string,
  buyerName: string
): Promise<void> {
  const resend = getResend()
  if (!resend) return

  const appUrl = getAppUrl()

  try {
    await resend.emails.send({
      from: getFromAddress(),
      to,
      subject: `Nueva consulta sobre "${listingTitle}"`,
      text: [
        `Hola,`,
        ``,
        `${buyerName} inició una consulta sobre tu activo "${listingTitle}" en Qapitaliza.`,
        ``,
        `Ingresá a tu panel para responder:`,
        `${appUrl}/consultas`,
        ``,
        `— El equipo de Qapitaliza`,
      ].join('\n'),
    })
  } catch (e) {
    // Email failures must never break the main flow
    console.error('[email] Failed to send new inquiry notification:', e)
  }
}

/**
 * Notifica al otro participante cuando llega un nuevo mensaje.
 * Solo se envía si la última notificación fue hace más de 1 hora (anti-spam).
 *
 * El control del throttle se delega al caller (server action).
 */
export async function sendNewMessageEmail(
  to: string,
  listingTitle: string,
  senderName: string
): Promise<void> {
  const resend = getResend()
  if (!resend) return

  const appUrl = getAppUrl()

  try {
    await resend.emails.send({
      from: getFromAddress(),
      to,
      subject: `Nuevo mensaje sobre "${listingTitle}"`,
      text: [
        `Hola,`,
        ``,
        `${senderName} te envió un mensaje sobre el activo "${listingTitle}" en Qapitaliza.`,
        ``,
        `Ingresá a tu panel para responder:`,
        `${appUrl}/consultas`,
        ``,
        `— El equipo de Qapitaliza`,
      ].join('\n'),
    })
  } catch (e) {
    console.error('[email] Failed to send new message notification:', e)
  }
}
