# ADR-0002: Decisiones arquitectónicas fundamentales — Auth, Telegram, reCAPTCHA

> **Fecha**: 2026-03-10
> **Estado**: Aceptada

## Contexto

El proyecto Qautiva requiere tres integraciones clave que no estaban definidas en el spec original:

1. **Autenticación**: El spec mencionaba "Supabase Auth" sin detallar el flujo. Los playbooks del proyecto tienen implementaciones con NextAuth v5. Había que elegir uno.
2. **Bot de Telegram**: Los playbooks describen una implementación en Python/FastAPI, pero el proyecto es un monorepo TypeScript con Next.js. Había que decidir el stack del bot.
3. **reCAPTCHA v3**: Necesario para proteger formularios públicos y login. Sin complejidad de decisión, pero sí de integración al plan.

Adicionalmente, el cliente confirmó que Telegram no es solo para notificaciones sino para interacción del cliente en el proceso, lo cual requiere integración bidireccional con el ChatPanel del portal.

## Opciones consideradas

### Decisión 1: Autenticación

#### Opción A: NextAuth v5 con Prisma adapter
- **Pros**: Playbooks existentes en el proyecto, control total sobre sesiones, framework-agnostic
- **Contras**: Dependencia extra, sesiones en DB (1 query por request), no tiene RLS nativo, hay que verificar ownership manualmente en cada query, riesgo de data leak si se olvida un WHERE

#### Opción B: Supabase Auth con RLS
- **Pros**: Ya incluido con Supabase ($0 extra), Google OAuth built-in, JWT stateless (escala sin queries de sesión), RLS resuelve autorización multi-tenant a nivel de DB (imposible ver datos de otra org incluso con bugs en el código), Realtime integrado con contexto de auth
- **Contras**: Vendor lock-in con Supabase, menos control sobre el flujo de sesión, sharp edges con Next.js App Router (requiere `@supabase/ssr` específico), redirect URIs de Google no soportan wildcards (problema con preview URLs de Vercel)

### Decisión 2: Stack del bot de Telegram

#### Opción A: Python/FastAPI (como los playbooks)
- **Pros**: Playbooks ya escritos y testeados, python-telegram-bot es maduro
- **Contras**: Segundo lenguaje en el stack, segundo deploy ($5-10/mo extra), no comparte tipos Prisma (mapeo manual), doble mantenimiento de dependencias, barrera de entrada para contributors que solo saben TS

#### Opción B: TypeScript con grammY
- **Pros**: Mismo lenguaje que todo el proyecto, comparte Prisma client directamente, grammY es TypeScript-first (41K descargas/semana, activo), Anthropic SDK para TS funciona, se despliega junto al admin ($0 extra), un solo ecosistema de dependencias
- **Contras**: Los playbooks hay que reescribirlos en TS, grammY es menos maduro que python-telegram-bot (pero suficiente para nuestro uso)

## Decisión

### Auth: Elegimos Opción B (Supabase Auth con RLS)

**Porque** en un sistema multi-tenant donde cada cliente solo debe ver SU organización, Row Level Security es la diferencia entre "la autorización depende de que no nos olvidemos un WHERE" y "la base de datos impide el acceso cruzado por diseño". El costo es $0 extra (ya tenemos Supabase), escala mejor (JWT stateless vs sessions en DB), y el OAuth con Google es built-in.

### Telegram: Elegimos Opción B (TypeScript con grammY)

**Porque** un solo lenguaje en el stack reduce el costo de mantenimiento a largo plazo. Compartir tipos Prisma elimina una clase entera de bugs de mapeo. El deploy junto al admin ahorra $5-10/mo que a escala se acumula. grammY es producción-ready para nuestro caso de uso.

## Consecuencias

### Lo que ganamos
- Autorización multi-tenant a prueba de bugs (RLS)
- $0 extra de costo por auth y $0 extra de infra por el bot
- Stack unificado en TypeScript (menor barrera de entrada, un solo CI pipeline)
- JWT stateless escala sin presión en la DB
- Mensajes de Telegram y web en la misma tabla con Realtime propagando a ambos canales

### Lo que perdemos o se complica
- Vendor lock-in con Supabase (migrar auth a otro proveedor requiere esfuerzo)
- Los playbooks de NextAuth y python-telegram-bot no se pueden copiar-pegar; sirven como referencia pero hay que reescribir
- Sharp edges de Supabase Auth con Next.js App Router (redirect URIs, cookies, server vs client components)
- RLS requiere índices en todas las columnas de policy (si se olvida un índice → sequential scan en cada query)

### Lo que hay que tener en cuenta a futuro
- Si Supabase cambia pricing o degrada el servicio, la migración es costosa (auth + RLS + Realtime + Storage están acoplados)
- Cuando el bot supere ~1000 usuarios concurrentes, migrar de long-polling a webhooks + queue
- Los preview URLs de Vercel necesitan manejo especial para Google OAuth redirect (server actions con origin dinámico)
- Monitorear costos de Anthropic API para el bot — es el costo dominante a escala
