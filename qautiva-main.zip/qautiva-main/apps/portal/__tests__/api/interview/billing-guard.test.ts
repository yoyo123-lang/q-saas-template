/**
 * Tests de integración: billing guard en /process y /advance (submit).
 *
 * Verifica que los endpoints retornan 402 cuando el billing no es elegible,
 * y 503 cuando la consulta de billing falla.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// ── Mocks ──────────────────────────────────────────────────────────────────────

const { mockGetUser, mockGetUserTeamIds, mockCheckBillingEligibility,
  mockInterviewSessionFindFirst, mockInterviewSessionUpdateMany,
  mockUserProfileFindUnique, mockInterviewSessionUpdate } = vi.hoisted(() => ({
  mockGetUser: vi.fn(),
  mockGetUserTeamIds: vi.fn(),
  mockCheckBillingEligibility: vi.fn(),
  mockInterviewSessionFindFirst: vi.fn(),
  mockInterviewSessionUpdateMany: vi.fn(),
  mockUserProfileFindUnique: vi.fn(),
  mockInterviewSessionUpdate: vi.fn(),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('@/app/_lib/interview/get-user-team-ids', () => ({
  getUserTeamIds: mockGetUserTeamIds,
}))

vi.mock('@/app/_lib/billing/check-eligibility', () => ({
  checkBillingEligibility: mockCheckBillingEligibility,
}))

vi.mock('@vercel/functions', () => ({
  waitUntil: vi.fn(),
}))

vi.mock('@/app/_lib/interview/session-processor', () => ({
  processSession: vi.fn().mockResolvedValue(undefined),
}))

vi.mock('@/app/_lib/interview/merge-flow', () => ({
  isAnswerEmpty: (v: unknown) => {
    if (v === null || v === undefined) return true
    if (typeof v === 'string') return v.trim().length === 0
    if (Array.isArray(v)) return v.length === 0
    return false
  },
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    interviewSession: {
      findFirst: mockInterviewSessionFindFirst,
      updateMany: mockInterviewSessionUpdateMany,
      update: mockInterviewSessionUpdate,
    },
    userProfile: { findUnique: mockUserProfileFindUnique },
  },
  Prisma: {
    PrismaClientKnownRequestError: class PrismaClientKnownRequestError extends Error {
      code: string
      constructor(message: string, { code }: { code: string }) {
        super(message)
        this.code = code
      }
    },
  },
}))

// ── Imports ────────────────────────────────────────────────────────────────────

import { POST as processPost } from '@/app/api/interview/sessions/[id]/process/route'
import { POST as advancePost } from '@/app/api/interview/sessions/[id]/advance/route'

// ── Constantes ─────────────────────────────────────────────────────────────────

const SESSION_UUID = '00000000-0000-4000-a000-000000000001'
const USER_ID = 'user-auth-id'
const TEAM_ID = 'team-1'

const mockUser = { id: USER_ID }
const mockSession = {
  id: SESSION_UUID,
  status: 'PROCESSING',
  retryCount: 0,
  maxRetries: 3,
  processingStartedAt: null,
  flowDefinition: [],
  answers: {},
  stageId: 'stage-1',
  projectId: 'proj-1',
  teamId: TEAM_ID,
  selectedWebTemplateId: null,
  stage: { stageKey: 'WEBSITE' },
  project: { brandKit: null },
}

function makeProcessRequest() {
  return new NextRequest(`http://localhost:3001/api/interview/sessions/${SESSION_UUID}/process`, {
    method: 'POST',
  })
}

function makeAdvanceRequest(action: string) {
  return new NextRequest(`http://localhost:3001/api/interview/sessions/${SESSION_UUID}/advance`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action }),
  })
}

const routeParams = { params: { id: SESSION_UUID } }

// ── Tests: /process ────────────────────────────────────────────────────────────

describe('POST /api/interview/sessions/[id]/process — billing guard', () => {
  beforeEach(() => {
    mockGetUser.mockReset()
    mockGetUserTeamIds.mockReset()
    mockCheckBillingEligibility.mockReset()
    mockInterviewSessionFindFirst.mockReset()
    mockInterviewSessionUpdateMany.mockReset()
    mockUserProfileFindUnique.mockReset()

    mockGetUser.mockResolvedValue({ data: { user: mockUser } })
    mockGetUserTeamIds.mockResolvedValue([TEAM_ID])
    mockInterviewSessionFindFirst.mockResolvedValue(mockSession)
    // checkTeamPermission debe pasar (ADMIN) para que el billing guard se ejecute
    mockUserProfileFindUnique.mockResolvedValue({ teamMemberships: [{ role: 'ADMIN' }] })
  })

  it('trial expirado → 402 con reason', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      reason: 'Trial expirado. Actualizá tu plan para continuar.',
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(402)
    const body = await res.json()
    expect(body.error).toMatch(/trial.*expirado/i)
  })

  it('session sin teamId → 500 (fail-closed, error de datos)', async () => {
    mockInterviewSessionFindFirst.mockResolvedValueOnce({ ...mockSession, teamId: null })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(500)
    expect(mockCheckBillingEligibility).not.toHaveBeenCalled()
  })

  it('saldo = 0 (PREPAID) → 402 con reason', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      reason: 'Saldo insuficiente. Recargá tu cuenta para continuar.',
      billingPlan: 'PREPAID',
      source: 'QAUTIVA_HOSTED',
    })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(402)
    const body = await res.json()
    expect(body.error).toMatch(/saldo.*insuficiente/i)
  })

  it('billing check falla (DB error) → 503', async () => {
    mockCheckBillingEligibility.mockRejectedValueOnce(new Error('CRITICAL: BillingAccount no encontrado'))

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(503)
    const body = await res.json()
    expect(body.error).toMatch(/facturación/i)
  })

  it('trial activo con tokens → 202 (guard pasa, procesamiento inicia)', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: true,
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })
    mockInterviewSessionUpdateMany.mockResolvedValueOnce({ count: 1 })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(202)
    expect(mockCheckBillingEligibility).toHaveBeenCalledWith(TEAM_ID)
  })

  it('BYOK → 202 (guard siempre pasa)', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: true,
      billingPlan: 'FREE_TRIAL',
      source: 'BYOK',
    })
    mockInterviewSessionUpdateMany.mockResolvedValueOnce({ count: 1 })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(202)
  })

  it('eligible=false sin reason → 402 con mensaje genérico de fallback', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      // reason undefined — no se incluye
      billingPlan: 'PREPAID',
      source: 'QAUTIVA_HOSTED',
    })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(402)
    const body = await res.json()
    expect(body.error).toBe('Tu plan no tiene saldo suficiente para continuar.')
  })

  it('402 → lock (updateMany) NO se llama', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      reason: 'Trial expirado.',
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })

    await processPost(makeProcessRequest(), routeParams)

    expect(mockInterviewSessionUpdateMany).not.toHaveBeenCalled()
  })
})

// ── Tests: /advance (submit) ───────────────────────────────────────────────────

describe('POST /api/interview/sessions/[id]/advance (submit) — billing guard', () => {
  const mockSessionForAdvance = {
    id: SESSION_UUID,
    currentStep: 2,
    totalSteps: 3,
    status: 'IN_PROGRESS',
    teamId: TEAM_ID,
    answers: { q1: 'respuesta 1', q2: 'respuesta 2' },
    flowDefinition: [
      { id: 'q1', skippable: true },
      { id: 'q2', skippable: true },
    ],
  }

  beforeEach(() => {
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockCheckBillingEligibility.mockReset()
    mockInterviewSessionFindFirst.mockReset()
    mockInterviewSessionUpdate.mockReset()

    mockGetUser.mockResolvedValue({ data: { user: mockUser } })
    // Objeto combinado: satisface ownership check (teamId) y checkTeamPermission (role)
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'ADMIN' }],
    })
    mockInterviewSessionFindFirst.mockResolvedValue(mockSessionForAdvance)
  })

  it('trial expirado → 402 con reason', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      reason: 'Trial expirado. Actualizá tu plan para continuar.',
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(402)
    const body = await res.json()
    expect(body.error).toMatch(/trial.*expirado/i)
  })

  it('tokens agotados → 402 con reason', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      reason: 'Tokens de trial agotados. Actualizá tu plan para continuar.',
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(402)
    const body = await res.json()
    expect(body.error).toMatch(/tokens.*agotados/i)
  })

  it('billing check falla → 503', async () => {
    mockCheckBillingEligibility.mockRejectedValueOnce(new Error('CRITICAL: BillingAccount no encontrado'))

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(503)
  })

  it('trial activo → submit transiciona a PROCESSING', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: true,
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })
    mockInterviewSessionUpdate.mockResolvedValueOnce({
      id: SESSION_UUID,
      currentStep: 2,
      totalSteps: 3,
      status: 'PROCESSING',
      startedAt: null,
      processingStartedAt: null,
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(200)
    expect(mockCheckBillingEligibility).toHaveBeenCalledWith(TEAM_ID)
    const body = await res.json()
    expect(body.session.status).toBe('PROCESSING')
  })

  it('eligible=false sin reason → 402 con mensaje genérico de fallback', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      billingPlan: 'PREPAID',
      source: 'QAUTIVA_HOSTED',
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(402)
    const body = await res.json()
    expect(body.error).toBe('Tu plan no tiene saldo suficiente para continuar.')
  })

  it('402 → update de sesión a PROCESSING NO se llama', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: false,
      reason: 'Trial expirado.',
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })

    await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(mockInterviewSessionUpdate).not.toHaveBeenCalled()
  })

  it('acciones que NO son submit no llaman a billing check (start, next, back, pause)', async () => {
    const nonSubmitActions = ['start', 'next', 'back', 'pause']

    for (const action of nonSubmitActions) {
      mockCheckBillingEligibility.mockReset()
      // Configurar session según la acción
      const sessionForAction = {
        ...mockSessionForAdvance,
        status: action === 'start' ? 'NOT_STARTED' : 'IN_PROGRESS',
        currentStep: action === 'back' ? 1 : action === 'next' ? 1 : 0,
      }
      mockInterviewSessionFindFirst.mockResolvedValue(sessionForAction)
      mockInterviewSessionUpdate.mockResolvedValueOnce({
        id: SESSION_UUID, currentStep: 0, totalSteps: 3, status: 'IN_PROGRESS',
        startedAt: null, processingStartedAt: null,
      })

      await advancePost(makeAdvanceRequest(action), routeParams)

      expect(mockCheckBillingEligibility).not.toHaveBeenCalled()
    }
  })
})
