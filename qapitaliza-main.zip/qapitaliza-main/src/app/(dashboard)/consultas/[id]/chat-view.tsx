'use client'

import { useState, useEffect, useRef, useTransition } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Send, Check } from 'lucide-react'
import { toast } from 'sonner'
import { Avatar } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Modal } from '@/components/ui/modal'
import { sendMessage, closeInquiry } from '@/lib/actions/inquiries'
import { inquiryStatusVariant, inquiryStatusLabel, getParticipantInitials } from '@/components/listings/inquiry-shared'
import type { InquiryWithMessages, InquiryMessageData } from '@/lib/data/inquiries'

interface ChatViewProps {
  inquiry: InquiryWithMessages
  currentUserId: string
}

export function ChatView({ inquiry, currentUserId }: ChatViewProps) {
  const [messages, setMessages] = useState<InquiryMessageData[]>(inquiry.messages)
  const [status, setStatus] = useState(inquiry.status)
  const [content, setContent] = useState('')
  const [showCloseModal, setShowCloseModal] = useState(false)
  const [isPendingSend, startSend] = useTransition()
  const [isPendingClose, startClose] = useTransition()
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const isBuyer = inquiry.buyerId === currentUserId
  const isClosed = status === 'CLOSED'
  const seller = inquiry.listing.seller
  const buyer = inquiry.buyer
  const otherParticipant = isBuyer ? seller : buyer

  // Scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  function handleSend() {
    const trimmed = content.trim()
    if (!trimmed || isClosed || isPendingSend) return

    // Optimistic update
    const optimisticId = `optimistic-${Date.now()}`
    const optimisticMsg: InquiryMessageData = {
      id: optimisticId,
      inquiryId: inquiry.id,
      senderId: currentUserId,
      content: trimmed,
      createdAt: new Date(),
      sender: isBuyer
        ? { id: buyer.id, fullName: buyer.fullName, email: buyer.email, role: buyer.role }
        : { id: seller.id, fullName: seller.fullName, email: seller.email, role: seller.role },
    }
    setMessages((prev) => [...prev, optimisticMsg])
    setContent('')

    startSend(async () => {
      const result = await sendMessage(inquiry.id, trimmed)
      if (!result.success || !result.data) {
        // Revert optimistic message — never leave phantom messages
        setMessages((prev) => prev.filter((m) => m.id !== optimisticId))
        setContent(trimmed)
        toast.error(result.error ?? 'Error al enviar el mensaje.')
        textareaRef.current?.focus()
        return
      }
      // Replace optimistic with real message
      setMessages((prev) =>
        prev.map((m) => (m.id === optimisticId ? result.data! : m))
      )
    })
  }

  function handleClose() {
    startClose(async () => {
      const result = await closeInquiry(inquiry.id)
      if (!result.success) {
        toast.error(result.error ?? 'Error al cerrar la consulta.')
        return
      }
      setStatus('CLOSED')
      setShowCloseModal(false)
      toast.success('Consulta cerrada.')
    })
  }

  const price = parseFloat(inquiry.listing.askingPrice)
  const isVerified = inquiry.listing.verificationStatus === 'VERIFIED'

  // isBuyer or isSeller can close (regla 12 BUSINESS_MODEL.md)
  const isSeller = inquiry.listing.seller.id === currentUserId
  const canClose = (isBuyer || isSeller) && !isClosed

  return (
    <>
      {/* Header */}
      <div className="flex items-center gap-4 mb-6 flex-wrap">
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <Link href="/consultas" className="hover:text-amber-500 transition-colors">
            Consultas
          </Link>
          <span>/</span>
          <span className="text-slate-50 truncate max-w-[200px]">
            {inquiry.listing.title}
          </span>
        </div>
        <Badge variant={inquiryStatusVariant[status] ?? 'muted'} className="ml-auto">
          {inquiryStatusLabel[status] ?? status}
        </Badge>
        {canClose && (
          <button
            onClick={() => setShowCloseModal(true)}
            className="px-3 py-1.5 text-sm rounded-lg border border-slate-600 text-slate-400 hover:border-slate-400 hover:text-slate-50 transition-colors"
          >
            Cerrar consulta
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6 items-start">
        {/* ── Left: thread ── */}
        <div className="flex flex-col bg-navy-900 border border-slate-800 rounded-xl overflow-hidden">
          {/* Messages */}
          <div
            role="log"
            aria-label="Mensajes de la consulta"
            aria-live="polite"
            className="flex-1 overflow-y-auto p-5 flex flex-col gap-4 min-h-[400px] max-h-[60vh]"
          >
            {messages.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-8">
                Enviá el primer mensaje para iniciar la conversación.
              </p>
            )}
            {messages.map((msg) => {
              const isOwn = msg.senderId === currentUserId
              const senderInitials = getParticipantInitials(
                isOwn
                  ? (isBuyer ? buyer : seller)
                  : otherParticipant
              )
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  {!isOwn && (
                    <Avatar
                      initials={senderInitials}
                      role={msg.sender.role}
                      size="sm"
                      className="mt-1 flex-shrink-0"
                    />
                  )}
                  <div className={`max-w-[70%] flex flex-col gap-1 ${isOwn ? 'items-end' : 'items-start'}`}>
                    {!isOwn && (
                      <span className="text-xs text-slate-500">
                        {msg.sender.fullName ?? msg.sender.email}
                      </span>
                    )}
                    <div
                      className={[
                        'px-4 py-2.5 rounded-2xl text-sm leading-relaxed border',
                        isOwn
                          ? 'bg-amber-500/15 border-amber-500/20 text-slate-100 rounded-tr-sm'
                          : 'bg-navy-950 border-slate-800 text-slate-200 rounded-tl-sm',
                      ].join(' ')}
                    >
                      {msg.content}
                    </div>
                    <span className="text-xs text-slate-600">
                      {new Date(msg.createdAt).toLocaleTimeString('es-AR', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>
              )
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Input area */}
          <div className="border-t border-slate-800 p-4 flex gap-3 items-end">
            <textarea
              ref={textareaRef}
              id="chat-message-input"
              rows={2}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isClosed || isPendingSend}
              placeholder={
                isClosed
                  ? 'La consulta está cerrada.'
                  : 'Escribí tu mensaje... (Enter para enviar, Shift+Enter para nueva línea)'
              }
              maxLength={5000}
              aria-label="Escribí tu mensaje"
              aria-disabled={isClosed || isPendingSend}
              className={[
                'flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5',
                'text-sm text-slate-50 placeholder:text-slate-500 resize-none',
                'focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent',
                'transition-all duration-150',
                (isClosed || isPendingSend) ? 'opacity-50 cursor-not-allowed' : '',
              ].join(' ')}
            />
            <button
              onClick={handleSend}
              disabled={!content.trim() || isClosed || isPendingSend}
              aria-label="Enviar mensaje"
              className={[
                'flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors flex-shrink-0',
                'bg-amber-500 text-navy-950 hover:bg-amber-400',
                'disabled:opacity-50 disabled:cursor-not-allowed',
              ].join(' ')}
            >
              <Send className="size-4" />
              Enviar
            </button>
          </div>
        </div>

        {/* ── Right: asset info (sticky) ── */}
        <div className="sticky top-24 bg-navy-900 border border-slate-800 rounded-xl overflow-hidden">
          {/* Screenshot */}
          {inquiry.listing.screenshotUrls[0] ? (
            <div className="relative h-36 bg-slate-900">
              <Image
                src={inquiry.listing.screenshotUrls[0]}
                alt={inquiry.listing.title}
                fill
                className="object-cover"
                sizes="340px"
              />
            </div>
          ) : (
            <div className="h-36 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
              <span className="text-slate-500 text-sm">Sin imagen</span>
            </div>
          )}

          <div className="p-5 flex flex-col gap-4">
            <div>
              <h3 className="text-base font-semibold text-slate-50 leading-snug">
                {inquiry.listing.title}
              </h3>
              <p className="text-xl font-bold text-amber-500 mt-1">
                ${price.toLocaleString('en-US')} USD
              </p>
              {isVerified && (
                <p className="text-xs text-emerald-500 flex items-center gap-1 mt-1">
                  <Check className="size-3.5" />
                  Verificado
                </p>
              )}
            </div>

            {/* Seller info */}
            <div className="flex items-center gap-3 border-t border-slate-800 pt-4">
              <Avatar
                initials={getParticipantInitials(seller)}
                role={seller.role}
                size="sm"
              />
              <div>
                <p className="text-sm font-medium text-slate-50">
                  {seller.fullName ?? seller.email}
                </p>
                <p className="text-xs text-slate-500">Vendedor</p>
              </div>
            </div>

            <Link
              href={`/explorar/${inquiry.listing.slug}`}
              className="text-sm text-amber-500 hover:underline"
            >
              Ver listado completo →
            </Link>
          </div>
        </div>
      </div>

      {/* Close inquiry confirmation modal */}
      <Modal
        open={showCloseModal}
        onClose={() => setShowCloseModal(false)}
        title="Cerrar consulta"
        size="sm"
      >
        <p className="text-sm text-slate-400 mb-6">
          ¿Estás seguro que querés cerrar esta consulta? No podrás enviar más mensajes una vez cerrada.
        </p>
        <div className="flex gap-3 justify-end">
          <button
            onClick={() => setShowCloseModal(false)}
            className="px-4 py-2 text-sm rounded-lg border border-slate-700 text-slate-400 hover:border-slate-500 hover:text-slate-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleClose}
            disabled={isPendingClose}
            className="px-4 py-2 text-sm rounded-lg border border-red-500 text-red-400 hover:bg-red-500/10 transition-colors disabled:opacity-50"
          >
            {isPendingClose ? 'Cerrando...' : 'Cerrar consulta'}
          </button>
        </div>
      </Modal>
    </>
  )
}
