import type {
  OrgStatus,
  Plan,
  StageStatus,
  DeliverableStatus,
  DeliverableType,
  InterviewStatus,
  MessageSender,
  MessageChannel,
  SubStatus,
} from '@qautiva/db'

// ── Tipo central de ficha de cliente ──────────────────────────────────────────

export interface OrgWithDetails {
  id: string
  name: string
  industry: string
  plan: Plan
  status: OrgStatus
  websiteUrl: string | null
  createdAt: Date
  stages: {
    id: string
    number: number
    name: string
    status: StageStatus
    adminApproved: boolean
    clientApproved: boolean
    deliverables: {
      id: string
      title: string
      type: DeliverableType
      status: DeliverableStatus
      version: number
      feedback: string | null
      content: unknown  // Json — campo incluido en tab Entrevista
    }[]
    interviewSession: {
      id: string
      status: InterviewStatus
      currentStep: number
      totalSteps: number
      answers: unknown          // Json
      lastError: string | null
      errorDetails: unknown     // Json
      followUpHistory: unknown  // Json
      retryCount: number
      processingStartedAt: Date | null
      startedAt: Date | null
      completedAt: Date | null
      createdAt: Date
    } | null
  }[]
  messages: {
    id: string
    sender: MessageSender
    channel: MessageChannel
    stageNumber: number | null
    content: string
    createdAt: Date
  }[]
  notes: {
    id: string
    content: string
    createdAt: Date
    updatedAt: Date
  }[]
  subscription: {
    status: SubStatus
    planAmount: number
    nextBillingAt: Date | null
  } | null
}

// ── Tipos derivados ────────────────────────────────────────────────────────────

export type OrgStage = OrgWithDetails['stages'][number]
export type OrgDeliverable = OrgStage['deliverables'][number]
export type OrgInterviewSession = NonNullable<OrgStage['interviewSession']>
export type OrgMessage = OrgWithDetails['messages'][number]
export type OrgNote = OrgWithDetails['notes'][number]
