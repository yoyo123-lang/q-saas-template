# Instrucciones de Conexión al Q Company Board

> **Para**: una sesión de Claude Code trabajando en el repo de una BU (ej: Qautiva)
> **Objetivo**: conectar esta BU al Board central de Q Company para recibir docs sincronizados, enviar métricas y recibir directivas
> **Prerrequisito**: que el onboarding de docs ya se haya hecho en el repo de q-company (los archivos BUSINESS_MODEL.md, METRICS_MAP.md y BOARD_CONTEXT.md ya existen en `docs/bu/{slug}/`)

---

## Contexto

Q Company es un grupo empresarial con un Board central (repo `q-company`) que funciona como directorio ejecutivo con roles AI (CFO, CTO, CRO, CSO, VP Product, VP Engineering).

### Flujo de documentos

Los documentos de negocio (BUSINESS_MODEL.md, METRICS_MAP.md, BOARD_CONTEXT.md) se **crean y editan en q-company**. Un workflow de GitHub Actions los sincroniza automáticamente al repo de la BU via PR. La BU **no crea estos archivos** — solo los recibe.

```
q-company (fuente de verdad)
  docs/bu/{slug}/BUSINESS_MODEL.md
  docs/bu/{slug}/METRICS_MAP.md
  docs/bu/{slug}/BOARD_CONTEXT.md
        │
        │  workflow: sync-bu-docs.yml
        │  (push a main → crea PR en repo de la BU)
        ▼
repo de la BU (copia sincronizada)
  docs/board/BUSINESS_MODEL.md
  docs/board/METRICS_MAP.md
  docs/board/BOARD_CONTEXT.md
```

### Comunicación en runtime

- **BU → Board**: métricas, eventos, heartbeat (HTTP POST con API key en header `x-api-key`)
- **Board → BU**: directivas (HTTP POST con firma HMAC-SHA256 en header `x-board-signature`)

---

## TAREA 1: Preparar carpeta para recibir docs sincronizados

Crear la carpeta donde van a llegar los docs desde q-company:

```bash
mkdir -p docs/board
```

Crear un `.gitkeep` para que la carpeta exista aunque todavía no llegó el primer PR de sync:

```bash
touch docs/board/.gitkeep
```

> Los archivos BUSINESS_MODEL.md, METRICS_MAP.md y BOARD_CONTEXT.md van a llegar via PR automático desde q-company. No los crees manualmente.

---

## TAREA 2: Configurar variables de entorno

Pedirle al usuario las credenciales del Board y agregarlas al `.env`:

```env
BOARD_API_KEY=qb_{slug}_{key}       # API key de la BU (la provee el admin del Board)
BOARD_BU_ID={buId}                   # ID de la BU en el Board
BOARD_URL=https://q-company.vercel.app
BOARD_WEBHOOK_SECRET={secret}        # Para verificar directivas recibidas del Board
```

Agregar también al `.env.example` con valores placeholder:

```env
BOARD_API_KEY=qb_slug_your-api-key-here
BOARD_BU_ID=your-bu-id-here
BOARD_URL=https://q-company.vercel.app
BOARD_WEBHOOK_SECRET=your-webhook-secret-here
```

**Reglas de seguridad:**
- Nunca hardcodear keys en el código
- Nunca logear API keys
- HTTPS obligatorio en producción

---

## TAREA 3: Implementar Board Client

Crear un servicio reutilizable para comunicarse con el Board. Adaptar la ruta al stack del proyecto (Next.js, Express, etc.).

### Archivo: `src/lib/board-client.ts` (o equivalente según el proyecto)

```typescript
const BOARD_URL = process.env.BOARD_URL!
const BOARD_API_KEY = process.env.BOARD_API_KEY!
const BOARD_BU_ID = process.env.BOARD_BU_ID!

async function boardFetch(path: string, options: RequestInit = {}) {
  const url = `${BOARD_URL}/api/v1/bu/${BOARD_BU_ID}${path}`

  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': BOARD_API_KEY,
      ...options.headers,
    },
  })

  if (!response.ok) {
    const body = await response.text()
    throw new Error(`Board API error ${response.status}: ${body}`)
  }

  return response.json()
}

/** Enviar heartbeat — llamar cada 5 minutos */
export async function sendHeartbeat(checks: Record<string, string>) {
  return boardFetch('/heartbeat', {
    method: 'POST',
    body: JSON.stringify({
      version: process.env.npm_package_version ?? '0.0.1',
      uptime_seconds: Math.floor(process.uptime()),
      checks,
    }),
  })
}

/** Enviar métricas — máximo 100 por request */
export async function sendMetrics(
  metrics: Array<{ key: string; value: number; period: string; metadata?: Record<string, unknown> }>
) {
  return boardFetch('/metrics', {
    method: 'POST',
    body: JSON.stringify({ metrics }),
  })
}

/** Enviar eventos — máximo 100 por request, occurred_at en UTC */
export async function sendEvents(
  events: Array<{ type: string; payload: Record<string, unknown>; occurred_at: string }>
) {
  return boardFetch('/events', {
    method: 'POST',
    body: JSON.stringify({ events }),
  })
}

/** Actualizar estado de una directiva recibida */
export async function updateDirectiveStatus(
  directiveId: string,
  status: 'in_progress' | 'completed' | 'failed' | 'rejected',
  notes?: string,
  result?: Record<string, unknown>
) {
  return boardFetch(`/directives/${directiveId}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status, notes, result }),
  })
}
```

---

## TAREA 4: Implementar heartbeat

El Board espera un heartbeat cada 5 minutos. Si no llega en 15 min → alerta automática. Adaptar al stack del proyecto:

### Opción A: Cron de Vercel

Crear `app/api/cron/board-heartbeat/route.ts`:

```typescript
import { sendHeartbeat } from '@/lib/board-client'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const authHeader = request.headers.get('authorization')
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const checks: Record<string, string> = { api: 'ok' }
  // Agregar checks de DB, cache, etc. según el proyecto

  await sendHeartbeat(checks)
  return Response.json({ success: true })
}
```

En `vercel.json`:
```json
{
  "crons": [
    { "path": "/api/cron/board-heartbeat", "schedule": "*/5 * * * *" }
  ]
}
```

### Opción B: setInterval (servidor long-running)

```typescript
import { sendHeartbeat } from './lib/board-client'

setInterval(async () => {
  try {
    await sendHeartbeat({ api: 'ok', database: 'ok' })
  } catch (error) {
    console.error('[Board] Heartbeat failed:', error)
  }
}, 5 * 60 * 1000)
```

---

## TAREA 5: Implementar receptor de directivas

El Board envía directivas a la BU via webhook. La BU debe exponer un endpoint para recibirlas.

### Endpoint: `POST /api/v1/directives/receive`

### Validación HMAC (obligatorio — rechazar sin esto)

```typescript
import { createHmac, timingSafeEqual } from 'crypto'

function validateBoardSignature(
  rawBody: string,
  signatureHeader: string,
  secret: string
): boolean {
  const expected = createHmac('sha256', secret)
    .update(rawBody)
    .digest('hex')

  const received = signatureHeader.replace('sha256=', '')

  const a = Buffer.from(expected, 'hex')
  const b = Buffer.from(received, 'hex')

  if (a.length !== b.length) return false
  return timingSafeEqual(a, b)
}
```

### Route handler

```typescript
import { updateDirectiveStatus } from '@/lib/board-client'

export async function POST(request: Request) {
  const rawBody = await request.text()
  const signature = request.headers.get('x-board-signature') ?? ''
  const secret = process.env.BOARD_WEBHOOK_SECRET!

  if (!validateBoardSignature(rawBody, signature, secret)) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = JSON.parse(rawBody)
  const { directive_id, type, title } = body

  console.log(`[Board] Directiva recibida: ${type} — ${title}`)

  // Procesar en background — responder rápido (< 5 segundos)
  processDirectiveInBackground(body).catch(console.error)

  return Response.json({ acknowledged: true, directive_id })
}

async function processDirectiveInBackground(directive: {
  directive_id: string
  type: string
  title: string
  description: string
  execution?: { type: string; repo?: string; labels?: string[] }
}) {
  try {
    await updateDirectiveStatus(directive.directive_id, 'in_progress')

    switch (directive.type) {
      case 'PROMOTION':
        // Activar promoción en el sistema
        break
      case 'FEATURE_REQUEST':
        // Si execution.type === 'github_issue', el Board ya creó el issue
        break
      case 'TECHNICAL_DIRECTIVE':
        // Crear ADR o tarea técnica
        break
      case 'POLICY_CHANGE':
        // Actualizar configuración
        break
      case 'CONFIG_CHANGE':
        // Cambiar parámetro de runtime
        break
      default:
        console.log(`[Board] Tipo no manejado: ${directive.type}`)
    }

    await updateDirectiveStatus(directive.directive_id, 'completed', 'Procesado correctamente')
  } catch (error) {
    await updateDirectiveStatus(
      directive.directive_id,
      'failed',
      error instanceof Error ? error.message : 'Error desconocido'
    )
  }
}
```

### Tipos de directiva y qué hacer

| Tipo | Acción esperada |
|------|----------------|
| `PROMOTION` | Activar promoción con las condiciones del payload |
| `FEATURE_REQUEST` | Registrar como tarea. Si `execution.type = github_issue`, el Board ya lo creó |
| `TECHNICAL_DIRECTIVE` | Crear ADR o tarea técnica |
| `POLICY_CHANGE` | Actualizar configuración según la política |
| `CAMPAIGN` | Activar campaña con assets y timing del payload |
| `CONFIG_CHANGE` | Cambiar parámetro de runtime |

### Flujo completo de una directiva

```
Board envía POST /api/v1/directives/receive
  → BU valida firma HMAC
  → BU responde { acknowledged: true } (< 5 seg)
  → BU reporta status = "in_progress" via PATCH
  → BU procesa según tipo
  → BU reporta status = "completed" (o "failed") via PATCH
```

---

## TAREA 6: Agregar referencia al CLAUDE.md

Agregar esta sección al `CLAUDE.md` del repo:

```markdown
## Conexión con Q Company Board

Esta BU pertenece al grupo Q Company y reporta al Board central.
Ver `docs/board/BOARD_CONTEXT.md` para entender la conexión.

Archivos sincronizados con el Board (llegan via PR automático desde q-company):
- `docs/board/BUSINESS_MODEL.md` — modelo de negocio (fuente de verdad)
- `docs/board/BOARD_CONTEXT.md` — contexto de conexión y directivas
- `docs/board/METRICS_MAP.md` — mapeo de métricas a roles AI del Board

Estos archivos se editan en el repo de q-company, NO acá. Los cambios llegan via PR automático.
```

---

## TAREA 7: Test de conexión

Verificar que la conexión funciona enviando una métrica de prueba:

```typescript
import { sendMetrics } from '@/lib/board-client'

await sendMetrics([
  { key: 'test_metric', value: 1, period: new Date().toISOString().slice(0, 10) }
])
```

Si responde `201` con `{ success: true }`, la conexión está OK.

---

## Checklist final

- [ ] Carpeta `docs/board/` creada (con `.gitkeep`)
- [ ] Variables de entorno configuradas (`BOARD_API_KEY`, `BOARD_BU_ID`, `BOARD_URL`, `BOARD_WEBHOOK_SECRET`)
- [ ] Variables agregadas al `.env.example`
- [ ] Board client creado (`src/lib/board-client.ts` o equivalente)
- [ ] Heartbeat corriendo cada 5 minutos
- [ ] Endpoint `/api/v1/directives/receive` implementado con validación HMAC
- [ ] `CLAUDE.md` actualizado con referencia al Board
- [ ] Test de conexión exitoso (métrica de prueba enviada)
- [ ] Commit con mensaje: `feat: conectar BU al Q Company Board`

---

## Notas para la sesión de Claude Code

- **Los docs de negocio NO se crean acá.** Se crean en q-company y llegan via PR de sync. Si la carpeta `docs/board/` está vacía, es porque el sync no corrió todavía.
- **Las credenciales las provee el admin del Board.** Si el usuario no las tiene, pedírselas antes de avanzar con la implementación técnica.
- **Adaptar al stack del proyecto.** Los ejemplos de código asumen Next.js App Router + TypeScript, pero el concepto aplica a cualquier stack. Investigar el proyecto antes de implementar.
- **Si la API del Board falla**, usar exponential backoff: 2s, 4s, 8s, 16s. Máximo 4 reintentos.
- **El heartbeat es lo más urgente** — si no llega en 15 min, el Board genera alerta.
