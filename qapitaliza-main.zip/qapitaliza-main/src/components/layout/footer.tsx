import Link from 'next/link'
import { LogoQ } from '@/components/shared/logo-q'

const columns = [
  {
    heading: 'Producto',
    links: [
      { href: '/explorar', label: 'Explorar activos' },
      { href: '/como-funciona', label: 'Cómo funciona' },
      { href: '/registro?rol=seller', label: 'Publicar activo' },
    ],
  },
  {
    heading: 'Empresa',
    links: [
      { href: '/nosotros', label: 'Nosotros' },
      { href: '/blog', label: 'Blog' },
      { href: '/contacto', label: 'Contacto' },
    ],
  },
  {
    heading: 'Legal',
    links: [
      { href: '/terminos', label: 'Términos de uso' },
      { href: '/privacidad', label: 'Privacidad' },
      { href: '/cookies', label: 'Cookies' },
    ],
  },
]

export function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="border-t border-slate-800 bg-navy-950">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <LogoQ showText size="sm" />
            <p className="mt-4 text-sm text-slate-500 leading-relaxed max-w-xs">
              Marketplace de activos digitales. Comprá, vendé e invertí con seguridad.
            </p>
          </div>

          {/* Columns */}
          {columns.map((col) => (
            <div key={col.heading}>
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
                {col.heading}
              </h3>
              <ul className="space-y-3">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-slate-500 hover:text-slate-300 transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-slate-600">
            © {year} Qapitaliza. Todos los derechos reservados.
          </p>
          <p className="text-xs text-slate-600">Hecho en Argentina 🇦🇷</p>
        </div>
      </div>
    </footer>
  )
}
