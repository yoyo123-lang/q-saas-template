-- ============================================================
-- ROLLBACK 001 — Profiles
-- ADVERTENCIA: borra todos los perfiles. Irreversible si no hay backup.
-- ============================================================

DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TYPE  IF EXISTS user_role CASCADE;
