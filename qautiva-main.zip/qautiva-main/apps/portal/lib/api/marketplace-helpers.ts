import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { OrderStatus, Prisma } from '@qautiva/db'

// ── Validación de URL ──────────────────────────────────────────────────────────
// Valida que sea http o https. Retorna true si es válida.
export function isValidHttpUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'http:' || parsed.protocol === 'https:'
  } catch {
    return false
  }
}

// ── Auth helper ───────────────────────────────────────────────────────────────
// Retorna el perfil del usuario autenticado, o una respuesta de error lista para retornar.
// Uso: const authResult = await getProfileOrUnauthorized()
//      if (authResult.unauthorized) return authResult.response

export type ProfileOrNull =
  | { profile: { id: string }; unauthorized: false }
  | { profile: null; unauthorized: true; response: NextResponse }

export async function getProfileOrUnauthorized(): Promise<ProfileOrNull> {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return {
      profile: null,
      unauthorized: true,
      response: NextResponse.json({ error: 'No autorizado' }, { status: 401 }),
    }
  }
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true },
  })
  if (!profile) {
    return {
      profile: null,
      unauthorized: true,
      response: NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 }),
    }
  }
  return { profile, unauthorized: false }
}

// ── Ownership helper para órdenes ────────────────────────────────────────────
// Verifica que el usuario sea parte de la orden (anunciante o editor del medio).
// Retorna las parties con status para validaciones adicionales, o una respuesta de error.

export type OrderParties = {
  advertiserId: string
  mediumUserId: string
  status: OrderStatus
}

export type PartiesOrError =
  | { parties: OrderParties; error: false }
  | { parties: null; error: true; response: NextResponse }

export async function getOrderPartiesOrError(
  orderId: string,
  profileId: string,
): Promise<PartiesOrError> {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    select: { advertiserId: true, status: true, medium: { select: { userId: true } } },
  })
  if (!order) {
    return {
      parties: null,
      error: true,
      response: NextResponse.json({ error: 'Orden no encontrada' }, { status: 404 }),
    }
  }
  const isParty = order.advertiserId === profileId || order.medium.userId === profileId
  if (!isParty) {
    return {
      parties: null,
      error: true,
      response: NextResponse.json({ error: 'Sin acceso' }, { status: 403 }),
    }
  }
  return {
    parties: { advertiserId: order.advertiserId, mediumUserId: order.medium.userId, status: order.status },
    error: false,
  }
}

// ── Serialización de Decimal ──────────────────────────────────────────────────
// Prisma retorna campos Decimal como objetos Decimal.js — los convertimos a number para JSON.

export function serializeDecimalPrice<T extends { price: Prisma.Decimal }>(
  record: T,
): Omit<T, 'price'> & { price: number } {
  return { ...record, price: record.price.toNumber() }
}

// ── Campos base compartidos por todos los selects de Order ────────────────────
const ORDER_BASE_SELECT = {
  id: true,
  advertiserId: true,
  mediumId: true,
  productId: true,
  brief: true,
  targetUrl: true,
  anchorText: true,
  status: true,
  expiresAt: true,
  deliveryDeadline: true,
  deliveryUrl: true,
  deliveryNotes: true,
  price: true,
  acceptedAt: true,
  deliveredAt: true,
  completedAt: true,
  cancelledAt: true,
  cancellationReason: true,
  createdAt: true,
  updatedAt: true,
  product: { select: { id: true, type: true, name: true, deliveryDays: true } },
  medium: {
    select: {
      id: true,
      name: true,
      platform: true,
      user: { select: { displayName: true } },
    },
  },
  advertiser: { select: { displayName: true } },
} satisfies Prisma.OrderSelect

// ── Select canónico para respuestas de Order ──────────────────────────────────
// Usar en findMany, create y update para garantizar una forma de respuesta consistente.
// Para el anunciante se omiten commission y editorPayout (datos internos de la plataforma).
// Para el editor se incluye editorPayout (lo que va a cobrar) pero no commission.
export const ORDER_RESPONSE_SELECT = {
  ...ORDER_BASE_SELECT,
  commission: true,
  editorPayout: true,
} satisfies Prisma.OrderSelect

// Select para el anunciante: sin commission ni editorPayout (previene fuga del margen).
export const ORDER_RESPONSE_SELECT_ADVERTISER = ORDER_BASE_SELECT

// Select para el editor: incluye editorPayout (lo que va a cobrar), sin commission.
export const ORDER_RESPONSE_SELECT_EDITOR = {
  ...ORDER_BASE_SELECT,
  editorPayout: true,
} satisfies Prisma.OrderSelect

// ── Filtrado de campos financieros según el rol del usuario ───────────────────
// Aplica después de serializar: el anunciante no ve commission ni editorPayout.
export function filterOrderByRole<T extends Record<string, unknown>>(
  order: T,
  role: 'advertiser' | 'editor' | 'both',
): T {
  if (role === 'advertiser') {
    const { commission: _c, editorPayout: _ep, ...rest } = order as T & {
      commission?: unknown
      editorPayout?: unknown
    }
    return rest as T
  }
  if (role === 'editor') {
    const { commission: _c, ...rest } = order as T & { commission?: unknown }
    return rest as T
  }
  return order
}

// Serializa los 3 campos financieros de Order (price, commission, editorPayout).
export function serializeOrder<
  T extends { price: Prisma.Decimal; commission?: Prisma.Decimal; editorPayout?: Prisma.Decimal },
>(
  order: T,
): Omit<T, 'price' | 'commission' | 'editorPayout'> & {
  price: number
  commission?: number
  editorPayout?: number
} {
  return {
    ...order,
    price: order.price.toNumber(),
    ...(order.commission !== undefined ? { commission: order.commission.toNumber() } : {}),
    ...(order.editorPayout !== undefined ? { editorPayout: order.editorPayout.toNumber() } : {}),
  }
}
