/**
 * Lista canónica de industrias soportadas en el onboarding.
 * Importar en cliente (negocio/page.tsx) y servidor (api/onboarding/route.ts).
 */
export const INDUSTRIES = [
  'Alimentación y gastronomía',
  'Belleza y bienestar',
  'Comercio minorista',
  'Construcción y arquitectura',
  'Educación y formación',
  'Finanzas y servicios profesionales',
  'Inmobiliaria',
  'Moda y textil',
  'Salud y medicina',
  'Tecnología y software',
  'Turismo y hotelería',
  'Otro',
] as const

export type Industry = typeof INDUSTRIES[number]
