-- ============================================================
-- 011 ROLLBACK — INQUIRY_CLOSED + índices
-- NOTA: No se puede eliminar un valor de un enum en Postgres sin
-- recrear el tipo. El rollback solo elimina los índices.
-- Para revertir el enum: recrear el tipo manualmente sin INQUIRY_CLOSED.
-- ============================================================

DROP INDEX IF EXISTS public.idx_inquiries_buyer_id;
DROP INDEX IF EXISTS public.idx_inquiries_updated_at;
DROP INDEX IF EXISTS public.idx_favorites_user_id;
