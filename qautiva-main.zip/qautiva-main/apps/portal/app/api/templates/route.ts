import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'

/**
 * GET /api/templates?industry=Peluquería
 * Devuelve los WebTemplates ACTIVOS (máx. 100) ordenados por popularidad.
 * Si se pasa el query param `industry`, se marca cuál es el recomendado
 * (el que IndustryTemplate.webTemplate apunta para esa industria).
 *
 * Returns: { ok: true, templates: TemplateItem[], recommendedId: string | null }
 */
export async function GET(request: NextRequest) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const industry = request.nextUrl.searchParams.get('industry')

  try {
    const [templates, industryTemplate] = await Promise.all([
      prisma.webTemplate.findMany({
        where: { status: 'ACTIVE' },
        orderBy: [{ usageCount: 'desc' }, { name: 'asc' }],
        take: 100,
        select: {
          id: true,
          name: true,
          description: true,
          thumbnail: true,
          sections: true,
          compatibleIndustries: true,
        },
      }),
      industry
        ? prisma.industryTemplate.findFirst({
            where: { name: industry },
            select: { webTemplate: true },
          })
        : Promise.resolve(null),
    ])

    const recommendedId = industryTemplate?.webTemplate ?? null

    return NextResponse.json(
      { ok: true, templates, recommendedId },
      { headers: { 'Cache-Control': 's-maxage=300, stale-while-revalidate=600' } },
    )
  } catch (err) {
    console.error('[api/templates] query failed', {
      industry,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al cargar los diseños' }, { status: 500 })
  }
}
