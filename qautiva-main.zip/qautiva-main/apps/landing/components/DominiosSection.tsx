const TLDS = [
  { ext: '.com', desc: 'Presencia global' },
  { ext: '.com.ar', desc: 'Identidad argentina' },
  { ext: '.net', desc: 'Tecnología y redes' },
  { ext: '.org', desc: 'Organizaciones' },
  { ext: '.ar', desc: 'Local y directo' },
  { ext: '.store', desc: 'E-commerce' },
]

export function DominiosSection() {
  return (
    <section
      id="registro-dominios"
      className="bg-navy-950 py-20 md:py-24 border-t border-navy-800"
    >
      <div className="max-w-6xl mx-auto px-6">
        {/* Encabezado */}
        <div className="text-center mb-12">
          <p className="text-accent font-semibold text-sm tracking-widest uppercase mb-3">
            Dominios
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Tu nombre en internet,{' '}
            <span className="text-accent">desde hoy.</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Registrá el dominio que mejor represente tu marca. Más de 500 extensiones
            disponibles, gestión simple y renovación automática.
          </p>
        </div>

        {/* Grid de TLDs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mb-12">
          {TLDS.map(({ ext, desc }) => (
            <div
              key={ext}
              className="bg-navy-900 border border-navy-800 hover:border-accent/50 rounded-card p-4 text-center transition-colors duration-200"
            >
              <p className="text-accent font-bold text-xl mb-1">{ext}</p>
              <p className="text-slate-500 text-xs">{desc}</p>
            </div>
          ))}
        </div>

        {/* CTA central */}
        <div className="flex flex-col items-center gap-4">
          <a
            href="https://app.qautiva.ar/dominios/buscar"
            className="inline-flex items-center justify-center bg-accent hover:bg-accent-light text-white font-semibold px-8 py-4 rounded-lg text-lg transition-colors duration-200"
          >
            Buscá tu dominio
          </a>
          <p className="text-slate-500 text-sm">
            Sin sorpresas — el precio que ves es el que pagás
          </p>
        </div>
      </div>
    </section>
  )
}
