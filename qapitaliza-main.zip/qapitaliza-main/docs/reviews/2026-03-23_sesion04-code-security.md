# Revisión: Code Review + Security — Sesión 04
**Fecha:** 2026-03-23
**Rama:** `claude/seller-dashboard-ktGYO`
**Commit:** `5dfcc14`
**Archivos revisados:** `src/lib/actions/listings.ts`, `src/lib/schemas/listing.ts`, `src/lib/data/listings.ts`, `src/components/listings/listings-table.tsx`, `src/components/listings/views-chart.tsx`, `src/app/(dashboard)/mis-activos/page.tsx`, `src/app/(dashboard)/mis-activos/nuevo/page.tsx`, `src/app/(dashboard)/mis-activos/[id]/editar/edit-client.tsx`

---

## CRÍTICO

### [C1] Race condition en `uniqueSlug`
**Archivo:** `src/lib/actions/listings.ts:50-59`
**Descripción:** La función `uniqueSlug` hace un `findFirst` + genera variante en un while-loop sin transacción. Dos creaciones simultáneas con el mismo título pueden generar el mismo slug.
**Impacto:** Violación de constraint `UNIQUE` en la DB, fallo de creación inesperado para el usuario.
**Fix:** Wrappear en transacción o usar `try/catch` sobre el `create` con retry si unique constraint falla.
**Estado:** Pendiente

### [C2] `handleSaveDraft` guarda sin validar
**Archivo:** `src/app/(dashboard)/mis-activos/nuevo/page.tsx:143-155`
**Descripción:** `handleSaveDraft` llama `getValues()` y pasa el resultado directamente a `createListing` con `as CreateListingData`, sin ejecutar validación Zod. El servidor rechazará datos inválidos, pero el usuario no recibe feedback previo.
**Impacto:** UX degradada; el usuario puede guardar un borrador con título de 2 chars y recibir error genérico del servidor.
**Fix:** Ejecutar `trigger(['title', 'type', 'askingPrice'])` antes de llamar `createListing`, o usar una draftSchema parcial.
**Estado:** Pendiente

---

## ALTO

### [A1] `screenshotUrls` acepta URLs arbitrarias sin restricción de dominio
**Archivo:** `src/lib/schemas/listing.ts:49`
**Descripción:** Schema solo valida que sea URL válida. Un actor malicioso podría inyectar URLs de tracking, phishing o SSRF via IDP.
**Fix:** Agregar validación `.refine()` que exija `https://` y restrinja al dominio de Supabase Storage una vez conocido. Mínimo: forzar HTTPS.
**Estado:** Pendiente

### [A2] `console.error` expone stack traces completos de Prisma
**Archivo:** `src/lib/actions/listings.ts:122-124, 170-172, 188-190, ...` (todos los catch)
**Descripción:** `console.error('[createListing]', e)` loguea el error de Prisma completo incluyendo queries, parámetros y stack. En prod, esto puede llegar a Vercel logs accesibles al equipo pero no debería incluir datos de usuario.
**Fix:** `console.error('[createListing]', e instanceof Error ? e.message : String(e))`
**Estado:** Pendiente

### [A3] Sin validación de transición de estado en pauseListing/resumeListing/markAsSold
**Archivo:** `src/lib/actions/listings.ts:232-272`
**Descripción:** `pauseListing` no verifica que el listado esté en PUBLISHED antes de pausar. `markAsSold` puede aplicarse a un DRAFT. Esto rompe el state machine.
**Fix:** Fetch current status antes de update; retornar error si la transición no es válida.
**Estado:** Pendiente

### [A4] Mock data (`Math.random()`) en producción
**Archivo:** `src/components/listings/views-chart.tsx:16-32`
**Descripción:** `generateViewsData` usa `Math.random()` — los datos del gráfico son ficticios, lo que es engañoso para el usuario.
**Fix:** Mostrar estado vacío con mensaje explicativo hasta que se implemente la query real de analytics.
**Estado:** Pendiente

### [A5] `statusBadgeVariant`/`statusLabels`/`typeLabels` duplicados en 4 archivos
**Archivos:** `listings-table.tsx`, `edit-client.tsx`, `nuevo/page.tsx`, `dashboard/page.tsx`
**Descripción:** Las mismas constantes de mapeo definidas en múltiples lugares — single source of truth violation.
**Fix:** Extraer a `src/lib/constants/listing-labels.ts` e importar desde ahí.
**Estado:** Pendiente

---

## MEDIO

### [M1] Dead code en sidebar: `variant === 'dashboard' ? dashboardNav : dashboardNav`
**Archivo:** `src/components/layout/sidebar.tsx`
**Fix:** Eliminar el ternario y usar `dashboardNav` directamente.

### [M2] Doble auth check en dashboard/page.tsx
**Archivo:** `src/app/(dashboard)/dashboard/page.tsx`
**Fix:** El layout ya redirige; la page no necesita re-chequear.

### [M3] `getListings` importado pero no usado en dashboard/page.tsx
**Fix:** Eliminar el import.

### [M4] Race condition en `uniqueSlug` no tiene retry desde el create
**Fix menor:** Ver C1.

### [M5] `onMutate` no pasa a `ListingsTable` desde `mis-activos/page.tsx`
**Archivo:** `src/app/(dashboard)/mis-activos/page.tsx:141`
**Fix:** Ver A5 en QA review; pasar `router.refresh` equivalente desde un wrapper client.

### [M6] Paginación sin truncado en `mis-activos/page.tsx`
**Fix:** Limitar a mostrar máx 7 páginas con `...` para datasets grandes.

### [M7] `edit-client.tsx` cerca del límite de 300 líneas (272)
**Fix:** Extraer sidebar de estado a `<ListingStatusSidebar />`.

### [M8] `price min={0}` HTML vs `.positive()` Zod — inconsistencia
**Fix:** Usar `min={1}` en el input.

---

## BAJO

### [B1] `stepBasicSchema.shape` no garantiza que las keys sean válidas para `trigger()`
**Fix:** Usar lista explícita de campos en vez de `Object.keys(stepBasicSchema.shape)`.

### [B2] `ReviewSummary` definida inline en `nuevo/page.tsx`
**Fix:** Extraer a archivo propio o a `components/listings/listing-form/`.

### [B3] `currency` hardcodeado como `'USD'` en `createListing` (default) puede silenciar el valor del form
**Fix:** El schema ya tiene `.default('USD')` — verificar que el valor del form llegue correctamente.
