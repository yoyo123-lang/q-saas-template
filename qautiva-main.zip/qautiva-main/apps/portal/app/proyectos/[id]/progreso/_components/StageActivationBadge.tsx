'use client'

import { useState } from 'react'

type ActivationValue = 'ACTIVE' | 'SKIP' | 'PROVIDED_BY_CLIENT'

const ACTIVATION_LABELS: Record<ActivationValue, string> = {
  ACTIVE: 'Activa',
  SKIP: 'Saltada',
  PROVIDED_BY_CLIENT: 'Provista por cliente',
}

const ACTIVATION_COLORS: Record<ActivationValue, string> = {
  ACTIVE: 'text-[#10B981] bg-[#10B981]/10 border-[#10B981]/20',
  SKIP: 'text-[#64748B] bg-[#64748B]/10 border-[#64748B]/20',
  PROVIDED_BY_CLIENT: 'text-[#8B5CF6] bg-[#8B5CF6]/10 border-[#8B5CF6]/20',
}

type Props = {
  stageId: string
  activation: ActivationValue
  canEdit: boolean
}

export function StageActivationBadge({ stageId, activation: initialActivation, canEdit }: Props) {
  const [activation, setActivation] = useState(initialActivation)
  const [isEditing, setIsEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleChange(newActivation: ActivationValue) {
    if (newActivation === activation) {
      setIsEditing(false)
      return
    }
    setSaving(true)
    setError(null)
    try {
      const res = await fetch(`/api/stages/${stageId}/activation`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ activation: newActivation }),
      })
      if (res.ok) {
        setActivation(newActivation)
        setIsEditing(false)
      } else {
        const data = await res.json().catch(() => ({}))
        setError(data.error ?? 'Error al cambiar el estado. Intentá de nuevo.')
        setIsEditing(false)
      }
    } catch {
      setError('No se pudo conectar. Verificá tu conexión.')
      setIsEditing(false)
    } finally {
      setSaving(false)
    }
  }

  if (isEditing && canEdit) {
    return (
      <div className="flex items-center gap-1">
        {saving ? (
          <span className="text-[#64748B] text-xs">Guardando...</span>
        ) : (
          <>
            {(['ACTIVE', 'SKIP', 'PROVIDED_BY_CLIENT'] as ActivationValue[]).map((val) => (
              <button
                key={val}
                onClick={() => handleChange(val)}
                className={`text-xs px-2 py-0.5 rounded border transition-colors ${
                  val === activation
                    ? ACTIVATION_COLORS[val]
                    : 'text-[#64748B] bg-transparent border-[#1E293B] hover:border-[#334155]'
                }`}
              >
                {ACTIVATION_LABELS[val]}
              </button>
            ))}
            <button
              onClick={() => setIsEditing(false)}
              aria-label="Cancelar edición"
              className="text-[#64748B] text-xs px-1 hover:text-[#94A3B8]"
            >
              ✕
            </button>
          </>
        )}
      </div>
    )
  }

  return (
    <div>
      <span
        role={canEdit ? 'button' : undefined}
        tabIndex={canEdit ? 0 : -1}
        className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded border ${ACTIVATION_COLORS[activation]} ${canEdit ? 'cursor-pointer hover:opacity-80' : ''}`}
        onClick={canEdit ? () => setIsEditing(true) : undefined}
        onKeyDown={(e) => {
          if (canEdit && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault()
            setIsEditing(true)
          }
        }}
        title={canEdit ? 'Click para cambiar' : undefined}
      >
        {ACTIVATION_LABELS[activation]}
        {canEdit && (
          <span className="text-[#64748B]">▾</span>
        )}
      </span>
      {error && (
        <p className="text-[#EF4444] text-xs mt-0.5" role="alert">{error}</p>
      )}
    </div>
  )
}
