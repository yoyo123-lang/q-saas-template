'use client'

import { useState } from 'react'
import { updateCampaignBase } from '../../actions'
import type { ActionState } from '../../actions'

const PLATAFORMAS_OPTIONS = [
  'Google Ads',
  'Meta Ads',
  'Instagram Ads',
  'TikTok Ads',
  'Email Marketing',
]

type CampaignBase = {
  presupuestoMin: number
  presupuestoMax: number
  presupuestoTipico: number
  plataformas: string[]
  keywords: string[]
}

function SaveButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Guardando...' : 'Guardar campaña base'}
    </button>
  )
}

interface TabCampanasProps {
  industryId: string
  campaignBase: CampaignBase | null
  webTemplate: string
}

export function TabCampanas({ industryId, campaignBase, webTemplate: initialWebTemplate }: TabCampanasProps) {
  const [plataformas, setPlataformas] = useState<string[]>(
    campaignBase?.plataformas ?? [],
  )
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  function togglePlataforma(name: string) {
    setPlataformas((prev) =>
      prev.includes(name) ? prev.filter((p) => p !== name) : [...prev, name],
    )
  }

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    formData.set('id', industryId)
    plataformas.forEach((p) => formData.append('plataformas', p))
    try {
      const result = await updateCampaignBase(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  const inputClass =
    'px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors'

  return (
    <form action={handleSubmit} className="flex flex-col gap-6">
      <input type="hidden" name="id" value={industryId} />

      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 flex flex-col gap-4">
        <h2 className="text-sm font-semibold text-white">Presupuestos</h2>

        <div className="grid grid-cols-3 gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs text-[#64748B]">Presupuesto mínimo ($)</label>
            <input
              type="number"
              name="presupuestoMin"
              min={0}
              step={1}
              defaultValue={campaignBase?.presupuestoMin ?? 0}
              className={inputClass}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs text-[#64748B]">Presupuesto máximo ($)</label>
            <input
              type="number"
              name="presupuestoMax"
              min={0}
              step={1}
              defaultValue={campaignBase?.presupuestoMax ?? 0}
              className={inputClass}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs text-[#64748B]">Presupuesto típico ($)</label>
            <input
              type="number"
              name="presupuestoTipico"
              min={0}
              step={1}
              defaultValue={campaignBase?.presupuestoTipico ?? 0}
              className={inputClass}
            />
          </div>
        </div>
      </div>

      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-white">Plataformas</h2>
        <div className="flex flex-wrap gap-3">
          {PLATAFORMAS_OPTIONS.map((plat) => (
            <label
              key={plat}
              className="flex items-center gap-2 cursor-pointer"
            >
              <input
                type="checkbox"
                checked={plataformas.includes(plat)}
                onChange={() => togglePlataforma(plat)}
                className="w-4 h-4 rounded accent-[#8B5CF6]"
              />
              <span className="text-sm text-[#94A3B8]">{plat}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-white">Keywords de campaña</h2>
        <p className="text-xs text-[#64748B]">Una keyword por línea.</p>
        <textarea
          name="keywordsCampana"
          rows={6}
          defaultValue={campaignBase?.keywords.join('\n') ?? ''}
          placeholder="marketing digital&#10;publicidad online&#10;..."
          className={`${inputClass} resize-y`}
        />
      </div>

      <div className="flex items-center gap-3 pt-2 border-t border-[#1E293B]">
        <SaveButton pending={isPending} />
        {state && (
          state.ok
            ? <p className="text-sm text-green-400">Guardado correctamente.</p>
            : <p className="text-sm text-red-400">{state.error}</p>
        )}
      </div>
    </form>
  )
}
