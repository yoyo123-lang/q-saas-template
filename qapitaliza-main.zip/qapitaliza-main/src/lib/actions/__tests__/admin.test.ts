// Tests for admin action schemas and business logic.
// Server Actions themselves require a full server environment (cookies, DB),
// so we test the schemas and business rules in pure isolation.

import { describe, it, expect } from 'vitest'
import { z } from 'zod'

// ─── Schema definitions (mirrors src/lib/actions/admin.ts) ────────────────────

const rejectListingSchema = z.object({
  reason: z
    .string()
    .min(20, 'El motivo debe tener al menos 20 caracteres.')
    .max(500, 'El motivo no puede superar 500 caracteres.'),
})

const suspendUserSchema = z.object({
  reason: z.string().min(1, 'El motivo de suspensión es requerido.'),
})

const changeRoleSchema = z.object({
  role: z.enum(['BUYER', 'SELLER', 'ADMIN']),
})

// ─── Admin role check (unit simulation) ──────────────────────────────────────

function checkAdminRole(role: string | undefined): boolean {
  return role === 'ADMIN'
}

describe('checkAdminRole', () => {
  it('permite acceso a ADMIN', () => {
    expect(checkAdminRole('ADMIN')).toBe(true)
  })

  it('bloquea acceso a SELLER', () => {
    expect(checkAdminRole('SELLER')).toBe(false)
  })

  it('bloquea acceso a BUYER', () => {
    expect(checkAdminRole('BUYER')).toBe(false)
  })

  it('bloquea acceso sin rol (undefined)', () => {
    expect(checkAdminRole(undefined)).toBe(false)
  })

  it('bloquea acceso con string vacío', () => {
    expect(checkAdminRole('')).toBe(false)
  })
})

// ─── rejectListingSchema ──────────────────────────────────────────────────────

describe('rejectListingSchema', () => {
  it('rechaza motivo vacío', () => {
    const result = rejectListingSchema.safeParse({ reason: '' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].message).toContain('20 caracteres')
    }
  })

  it('rechaza motivo menor a 20 caracteres', () => {
    const result = rejectListingSchema.safeParse({ reason: 'muy corto' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].message).toContain('20 caracteres')
    }
  })

  it('rechaza motivo de exactamente 19 caracteres', () => {
    const result = rejectListingSchema.safeParse({ reason: 'a'.repeat(19) })
    expect(result.success).toBe(false)
  })

  it('acepta motivo de exactamente 20 caracteres', () => {
    const result = rejectListingSchema.safeParse({ reason: 'a'.repeat(20) })
    expect(result.success).toBe(true)
  })

  it('acepta motivo largo y descriptivo', () => {
    const reason = 'El listado no cumple con las políticas del marketplace porque no tiene capturas de pantalla válidas.'
    const result = rejectListingSchema.safeParse({ reason })
    expect(result.success).toBe(true)
  })

  it('rechaza motivo mayor a 500 caracteres', () => {
    const result = rejectListingSchema.safeParse({ reason: 'a'.repeat(501) })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].message).toContain('500 caracteres')
    }
  })

  it('acepta motivo de exactamente 500 caracteres', () => {
    const result = rejectListingSchema.safeParse({ reason: 'a'.repeat(500) })
    expect(result.success).toBe(true)
  })
})

// ─── suspendUserSchema ────────────────────────────────────────────────────────

describe('suspendUserSchema', () => {
  it('rechaza motivo vacío', () => {
    const result = suspendUserSchema.safeParse({ reason: '' })
    expect(result.success).toBe(false)
  })

  it('rechaza motivo solo espacios', () => {
    // The schema itself doesn't trim, but the action does .trim() before checking
    // This tests the raw schema behavior
    const result = suspendUserSchema.safeParse({ reason: '   ' })
    // raw schema allows spaces since min(1) is met
    expect(result.success).toBe(true)
  })

  it('acepta motivo válido', () => {
    const result = suspendUserSchema.safeParse({ reason: 'Violación de términos de servicio.' })
    expect(result.success).toBe(true)
  })
})

// ─── changeRoleSchema ─────────────────────────────────────────────────────────

describe('changeRoleSchema', () => {
  it('acepta BUYER', () => {
    expect(changeRoleSchema.safeParse({ role: 'BUYER' }).success).toBe(true)
  })

  it('acepta SELLER', () => {
    expect(changeRoleSchema.safeParse({ role: 'SELLER' }).success).toBe(true)
  })

  it('acepta ADMIN', () => {
    expect(changeRoleSchema.safeParse({ role: 'ADMIN' }).success).toBe(true)
  })

  it('rechaza rol inválido', () => {
    expect(changeRoleSchema.safeParse({ role: 'MODERATOR' }).success).toBe(false)
  })

  it('rechaza string vacío', () => {
    expect(changeRoleSchema.safeParse({ role: '' }).success).toBe(false)
  })
})

// ─── Reject reason client-side validation (button disable logic) ──────────────

describe('botón Confirmar rechazo — lógica de habilitación', () => {
  function isConfirmDisabled(reason: string): boolean {
    return reason.trim().length < 20
  }

  it('deshabilitado con reason vacío', () => {
    expect(isConfirmDisabled('')).toBe(true)
  })

  it('deshabilitado con reason de 19 caracteres', () => {
    expect(isConfirmDisabled('a'.repeat(19))).toBe(true)
  })

  it('habilitado con reason de 20 caracteres', () => {
    expect(isConfirmDisabled('a'.repeat(20))).toBe(false)
  })

  it('habilitado con reason largo', () => {
    expect(isConfirmDisabled('El listado tiene contenido inapropiado y no cumple las reglas.')).toBe(false)
  })

  it('deshabilitado con solo espacios (trim elimina el contenido)', () => {
    expect(isConfirmDisabled(' '.repeat(20))).toBe(true)
  })
})

// ─── Admin action result shape ─────────────────────────────────────────────────

interface ActionResult {
  success: boolean
  error?: string
}

describe('ActionResult shape', () => {
  it('resultado exitoso tiene success: true', () => {
    const result: ActionResult = { success: true }
    expect(result.success).toBe(true)
    expect(result.error).toBeUndefined()
  })

  it('resultado fallido tiene success: false y error message', () => {
    const result: ActionResult = { success: false, error: 'No autorizado. Se requiere rol ADMIN.' }
    expect(result.success).toBe(false)
    expect(result.error).toBeTruthy()
    expect(result.error).toContain('ADMIN')
  })
})
