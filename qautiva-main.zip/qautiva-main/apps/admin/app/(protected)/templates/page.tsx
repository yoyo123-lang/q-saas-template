import type { Metadata } from 'next'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import { TemplateRowActions } from './_row-actions'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Templates web | Qautiva Admin' }

function formatDate(date: Date): string {
  return date.toLocaleDateString('es-AR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  })
}

export default async function TemplatesPage() {
  const templates = await prisma.webTemplate.findMany({
    orderBy: { createdAt: 'desc' },
    take: 200, // safety limit para el admin
    select: {
      id: true,
      name: true,
      description: true,
      status: true,
      usageCount: true,
      compatibleIndustries: true,
      createdAt: true,
      htmlBase: true,
      queueStatus: true,
    },
  })

  return (
    <div className="p-8 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Templates web</h1>
          <p className="text-[#64748B] text-sm mt-1">
            Plantillas de sitio web personalizables por industria.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/templates/importar"
            className="px-4 py-2 bg-[#1E293B] text-[#94A3B8] text-sm font-medium rounded-lg hover:bg-[#1E293B]/80 hover:text-white transition-colors"
          >
            Importar desde catálogo
          </Link>
          <Link
            href="/templates/nuevo"
            className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] transition-colors"
          >
            + Nuevo template
          </Link>
        </div>
      </div>

      {/* Estado vacío */}
      {templates.length === 0 && (
        <div className="border border-[#1E293B] rounded-lg p-12 text-center">
          <p className="text-[#64748B] text-sm">
            No hay templates todavía. Creá el primero para empezar.
          </p>
        </div>
      )}

      {/* Tabla */}
      {templates.length > 0 && (
        <div className="border border-[#1E293B] rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1E293B] bg-[#0F172A]">
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Nombre</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Industrias</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Usos</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Estado</th>
                <th className="text-left px-4 py-3 text-[#64748B] font-medium">Creado</th>
                <th className="text-right px-4 py-3 text-[#64748B] font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {templates.map((template, idx) => {
                const industries = (template.compatibleIndustries as string[]) ?? []
                return (
                  <tr
                    key={template.id}
                    className={`border-b border-[#1E293B] last:border-0 ${idx % 2 === 0 ? 'bg-[#0B0F1A]' : 'bg-[#0F172A]/50'}`}
                  >
                    <td className="px-4 py-3">
                      <span className="text-white font-medium">{template.name}</span>
                      {template.description && (
                        <p className="text-[#64748B] text-xs mt-0.5 truncate max-w-[200px]">
                          {template.description}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {industries.length === 0 ? (
                        <span className="text-[#475569] text-xs">—</span>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {industries.slice(0, 2).map((ind) => (
                            <span
                              key={ind}
                              className="px-2 py-0.5 bg-[#1E293B] text-[#94A3B8] text-xs rounded-full"
                            >
                              {ind}
                            </span>
                          ))}
                          {industries.length > 2 && (
                            <span className="text-[#64748B] text-xs">
                              +{industries.length - 2}
                            </span>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8]">{template.usageCount}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-1">
                        <span
                          className={`inline-flex w-fit px-2 py-0.5 text-xs rounded-full font-medium ${
                            template.status === 'ACTIVE'
                              ? 'bg-green-400/10 text-green-400'
                              : 'bg-[#1E293B] text-[#64748B]'
                          }`}
                        >
                          {template.status === 'ACTIVE' ? 'Activo' : 'Borrador'}
                        </span>
                        {!template.htmlBase && (
                          <span className="inline-flex w-fit px-2 py-0.5 text-xs rounded-full font-medium bg-yellow-500/10 text-yellow-400">
                            {template.queueStatus === 'GENERATING' ? 'Generando...' :
                             template.queueStatus === 'QUEUED' ? 'En cola' :
                             template.queueStatus === 'ERROR' ? 'Error' :
                             'Sin HTML'}
                          </span>
                        )}
                        {template.htmlBase && template.queueStatus === 'DONE' && template.status !== 'ACTIVE' && (
                          <span className="inline-flex w-fit px-2 py-0.5 text-xs rounded-full font-medium bg-blue-500/10 text-blue-400">
                            Listo para revisar
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8]">{formatDate(template.createdAt)}</td>
                    <td className="px-4 py-3">
                      <TemplateRowActions id={template.id} name={template.name} status={template.status} usageCount={template.usageCount} />
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
