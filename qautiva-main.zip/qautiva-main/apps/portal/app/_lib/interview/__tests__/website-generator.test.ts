import { describe, it, expect, vi } from 'vitest'

// Mock @qautiva/db to avoid Prisma generated client dependency
vi.mock('@qautiva/db', () => ({
  prisma: { trialConfig: { findFirst: vi.fn() } },
  Prisma: {},
}))

// Mock AI SDKs to avoid import errors
vi.mock('@anthropic-ai/sdk', () => ({ default: vi.fn() }))
vi.mock('openai', () => ({ default: vi.fn() }))

import { applyWebsiteCopy, buildTemplateContext, validateWebsiteCopy, type WebsiteCopy } from '../website-generator'

const baseCopy: WebsiteCopy = {
  slogan: 'Tu negocio, online',
  seo: { title: 'Mi Negocio', description: 'Descripción SEO' },
  sections: {
    hero: { heading: 'Bienvenido', subheading: 'Tu solución', body: 'Texto hero', cta: 'Contactanos' },
    about: { heading: 'Sobre nosotros', body: 'Somos una empresa' },
  },
}

const baseHtml = `<!DOCTYPE html>
<html>
<head><title>{{seo_title}}</title><meta name="description" content="{{seo_description}}"></head>
<body>
<h1>{{slogan}}</h1>
<section id="hero"><h2>{{hero_heading}}</h2><p>{{hero_body}}</p><a>{{hero_cta}}</a></section>
<section id="about"><h2>{{about_heading}}</h2><p>{{about_body}}</p></section>
</body>
</html>`

// ── Basic variable replacement ───────────────────────────────────────────────

describe('applyWebsiteCopy — variable replacement', () => {
  it('replaces slogan, seo, and section placeholders', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null)
    expect(result).toContain('Tu negocio, online')
    expect(result).toContain('<title>Mi Negocio</title>')
    expect(result).toContain('content="Descripción SEO"')
    expect(result).toContain('Bienvenido')
    expect(result).toContain('Texto hero')
    expect(result).toContain('Contactanos')
    expect(result).toContain('Sobre nosotros')
  })

  it('escapes HTML in copy values', () => {
    const xssCopy: WebsiteCopy = {
      slogan: '<script>alert("xss")</script>',
      seo: { title: 'Safe', description: 'Safe' },
      sections: {},
    }
    const result = applyWebsiteCopy(baseHtml, xssCopy, null)
    expect(result).not.toContain('<script>')
    expect(result).toContain('&lt;script&gt;')
  })

  it('replaces business_name from brandKit', () => {
    const html = '<p>{{business_name}}</p>'
    const result = applyWebsiteCopy(html, baseCopy, { businessName: 'Mi Panadería' })
    expect(result).toContain('Mi Panadería')
  })

  it('validates logo URL protocol', () => {
    const html = '<img src="{{logo_url}}">'
    const safe = applyWebsiteCopy(html, baseCopy, { logoUrl: 'https://example.com/logo.png' })
    expect(safe).toContain('https://example.com/logo.png')

    // Unsafe URL: placeholder becomes empty string (Handlebars) — unsafe URL NOT injected
    const unsafe = applyWebsiteCopy(html, baseCopy, { logoUrl: 'javascript:alert(1)' })
    expect(unsafe).not.toContain('javascript:')
    expect(unsafe).not.toContain('logo_url') // placeholder replaced with empty string
  })

  it('replaces unknown placeholders with empty string (not literal)', () => {
    const html = '<p>{{unknown_placeholder}}</p>'
    const result = applyWebsiteCopy(html, baseCopy, null)
    expect(result).not.toContain('{{unknown_placeholder}}')
    expect(result).toContain('<p></p>')
  })
})

// ── Service section injection ────────────────────────────────────────────────

describe('applyWebsiteCopy — service section injection', () => {
  it('does not inject when activeSections is undefined (v1 flow)', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null)
    expect(result).not.toContain('id="booking"')
    expect(result).not.toContain('id="payments"')
  })

  it('does not inject when activeSections is empty', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, [])
    expect(result).not.toContain('id="booking"')
  })

  it('injects booking section when active and missing from template', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['hero', 'about', 'booking'])
    expect(result).toContain('id="booking"')
    expect(result).toContain('Reservá tu turno')
    expect(result).toContain('<!-- Qontacta widget placeholder -->')
  })

  it('injects payments section', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['payments'])
    expect(result).toContain('id="payments"')
    expect(result).toContain('Pagá online')
  })

  it('injects careers section', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['careers'])
    expect(result).toContain('id="careers"')
    expect(result).toContain('Trabajá con nosotros')
  })

  it('injects blog section', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['blog'])
    expect(result).toContain('id="blog"')
    expect(result).toContain('Nuestro blog')
  })

  it('injects before </body>', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['booking'])
    const bookingPos = result.indexOf('id="booking"')
    const bodyClosePos = result.indexOf('</body>')
    expect(bookingPos).toBeGreaterThan(-1)
    expect(bodyClosePos).toBeGreaterThan(bookingPos)
  })

  it('does not duplicate if template already has the section (double quotes)', () => {
    const htmlWithBooking = baseHtml.replace('</body>', '<section id="booking">Existing</section></body>')
    const result = applyWebsiteCopy(htmlWithBooking, baseCopy, null, ['booking'])
    const matches = result.match(/id="booking"/g) ?? []
    expect(matches).toHaveLength(1)
  })

  it('does not duplicate if template uses single quotes for id', () => {
    const htmlWithBooking = baseHtml.replace('</body>', "<section id='booking'>Existing</section></body>")
    const result = applyWebsiteCopy(htmlWithBooking, baseCopy, null, ['booking'])
    expect(result.match(/booking/g)!.length).toBeLessThanOrEqual(2) // the existing one + possible css class
  })

  it('injects multiple sections in correct order', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['booking', 'payments', 'blog'])
    const bookingPos = result.indexOf('id="booking"')
    const paymentsPos = result.indexOf('id="payments"')
    const blogPos = result.indexOf('id="blog"')
    expect(bookingPos).toBeLessThan(paymentsPos)
    expect(paymentsPos).toBeLessThan(blogPos)
  })

  it('skips non-service sections in activeSections', () => {
    const result = applyWebsiteCopy(baseHtml, baseCopy, null, ['hero', 'about', 'services', 'contact'])
    // hero and about already exist in template, services/contact are not in SERVICE_SECTION_TEMPLATES
    expect(result).not.toContain('id="services"')
  })

  it('appends to end if no </body> tag', () => {
    const htmlNoBody = '<div>{{slogan}}</div>'
    const result = applyWebsiteCopy(htmlNoBody, baseCopy, null, ['booking'])
    expect(result).toContain('id="booking"')
  })
})

// ── applyWebsiteCopy — error handling ────────────────────────────────────────

describe('applyWebsiteCopy — error handling', () => {
  it('throws descriptive error for invalid Handlebars syntax in template', () => {
    const invalidHtml = '<div>{{#if unclosed</div>'
    expect(() => applyWebsiteCopy(invalidHtml, baseCopy, null)).toThrow('[applyWebsiteCopy]')
  })
})

// ── validateWebsiteCopy ───────────────────────────────────────────────────────

describe('validateWebsiteCopy — valid input', () => {
  it('accepts a valid WebsiteCopy object', () => {
    const input = {
      slogan: 'Mi negocio',
      seo: { title: 'Título', description: 'Descripción' },
      sections: { hero: { heading: 'Bienvenido' } },
    }
    const result = validateWebsiteCopy(input)
    expect(result.slogan).toBe('Mi negocio')
    expect(result.sections['hero']!.heading).toBe('Bienvenido')
  })

  it('accepts sections with extra fields', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: {
        hero: { heading: 'H', subheading: 'S', body: 'B', cta: 'CTA' },
      },
    }
    expect(() => validateWebsiteCopy(input)).not.toThrow()
  })
})

describe('validateWebsiteCopy — invalid input throws', () => {
  it('throws if raw is null', () => {
    expect(() => validateWebsiteCopy(null)).toThrow('[website-generator] Output no es un objeto')
  })

  it('throws if slogan is missing', () => {
    expect(() => validateWebsiteCopy({ seo: { title: 'T', description: 'D' }, sections: {} }))
      .toThrow('[website-generator] Output: slogan debe ser string no vacío')
  })

  it('throws if slogan is empty string', () => {
    expect(() => validateWebsiteCopy({ slogan: '', seo: { title: 'T', description: 'D' }, sections: {} }))
      .toThrow('[website-generator] Output: slogan debe ser string no vacío')
  })

  it('throws if seo is missing', () => {
    expect(() => validateWebsiteCopy({ slogan: 'S', sections: {} }))
      .toThrow('[website-generator] Output: seo debe ser objeto')
  })

  it('throws if seo.title is missing', () => {
    expect(() => validateWebsiteCopy({ slogan: 'S', seo: { description: 'D' }, sections: {} }))
      .toThrow('[website-generator] Output: seo.title debe ser string')
  })

  it('throws if sections is null', () => {
    expect(() => validateWebsiteCopy({ slogan: 'S', seo: { title: 'T', description: 'D' }, sections: null }))
      .toThrow('[website-generator] Output: sections debe ser objeto')
  })

  it('throws if sections is a string', () => {
    expect(() => validateWebsiteCopy({ slogan: 'S', seo: { title: 'T', description: 'D' }, sections: 'hero' }))
      .toThrow('[website-generator] Output: sections debe ser objeto')
  })
})

describe('validateWebsiteCopy — array coercion', () => {
  it('coerces array with key field to object', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: [{ key: 'hero', heading: 'Bienvenido' }],
    }
    const result = validateWebsiteCopy(input)
    expect(result.sections).toHaveProperty('hero')
    expect(result.sections['hero']!.heading).toBe('Bienvenido')
  })

  it('coerces array using heading as key when key/id/name absent', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: [{ heading: 'Mi Seccion' }],
    }
    const result = validateWebsiteCopy(input)
    // Keys are ASCII-sanitized: lowercase, spaces→underscore, non-ASCII removed
    expect(result.sections).toHaveProperty('mi_seccion')
  })

  it('uses section_N fallback key when no identifiable field', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: [{ subheading: 'Sub', body: 'Texto' }],
    }
    const result = validateWebsiteCopy(input)
    expect(Object.keys(result.sections)).toContain('section_0')
  })

  it('deduplicates colliding keys with suffix', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: [
        { key: 'hero', heading: 'Hero 1' },
        { key: 'hero', heading: 'Hero 2' },
      ],
    }
    const result = validateWebsiteCopy(input)
    const keys = Object.keys(result.sections)
    expect(keys).toHaveLength(2)
    expect(keys).toContain('hero')
    expect(keys.some((k) => k.startsWith('hero_'))).toBe(true)
  })

  it('throws if array is empty (no items to coerce)', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: [],
    }
    expect(() => validateWebsiteCopy(input)).toThrow('[website-generator]')
  })
})

describe('validateWebsiteCopy — heading auto-repair', () => {
  it('uses title as heading when heading is missing', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: { hero: { title: 'Mi Hero' } },
    }
    const result = validateWebsiteCopy(input)
    expect(result.sections['hero']!.heading).toBe('Mi Hero')
  })

  it('uses capitalized key as heading when both heading and title are missing', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: { hero: { body: 'Texto' } },
    }
    const result = validateWebsiteCopy(input)
    expect(result.sections['hero']!.heading).toBe('Hero')
  })

  it('formats snake_case key as heading', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: { about_us: { body: 'Texto' } },
    }
    const result = validateWebsiteCopy(input)
    expect(result.sections['about_us']!.heading).toBe('About us')
  })

  it('removes non-object section entries', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: { hero: { heading: 'H' }, bad: 'not an object' },
    }
    const result = validateWebsiteCopy(input)
    expect(result.sections).not.toHaveProperty('bad')
    expect(result.sections).toHaveProperty('hero')
  })
})

// ── validateWebsiteCopy — null stripping (strict mode output) ────────────────

describe('validateWebsiteCopy — null stripping for strict mode', () => {
  it('removes null optional fields from sections', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: {
        hero: { heading: 'H', subheading: null, body: null, cta: null, items: null },
      },
    }
    const result = validateWebsiteCopy(input)
    const hero = result.sections['hero']!
    expect(hero.heading).toBe('H')
    expect(hero.subheading).toBeUndefined()
    expect(hero.body).toBeUndefined()
    expect(hero.cta).toBeUndefined()
    expect(hero.items).toBeUndefined()
  })

  it('keeps defined optional fields intact', () => {
    const input = {
      slogan: 'Test',
      seo: { title: 'T', description: 'D' },
      sections: {
        hero: { heading: 'H', subheading: 'Sub', body: null, cta: 'CTA', items: null },
      },
    }
    const result = validateWebsiteCopy(input)
    const hero = result.sections['hero']!
    expect(hero.subheading).toBe('Sub')
    expect(hero.cta).toBe('CTA')
    expect(hero.body).toBeUndefined()
    expect(hero.items).toBeUndefined()
  })
})

// ── buildTemplateContext ──────────────────────────────────────────────────────

describe('buildTemplateContext', () => {
  it('builds flat context with slogan, seo, and section fields', () => {
    const ctx = buildTemplateContext(baseCopy, null)
    expect(ctx['slogan']).toBe('Tu negocio, online')
    expect(ctx['seo_title']).toBe('Mi Negocio')
    expect(ctx['seo_description']).toBe('Descripción SEO')
    expect(ctx['hero_heading']).toBe('Bienvenido')
    expect(ctx['hero_subheading']).toBe('Tu solución')
    expect(ctx['hero_body']).toBe('Texto hero')
    expect(ctx['hero_cta']).toBe('Contactanos')
    expect(ctx['about_heading']).toBe('Sobre nosotros')
    expect(ctx['about_body']).toBe('Somos una empresa')
  })

  it('includes business_name and logo_url from brandKit', () => {
    const ctx = buildTemplateContext(baseCopy, {
      businessName: 'Mi Panadería',
      logoUrl: 'https://example.com/logo.png',
    })
    expect(ctx['business_name']).toBe('Mi Panadería')
    expect(ctx['logo_url']).toBe('https://example.com/logo.png')
  })

  it('excludes logo_url for unsafe URL protocols', () => {
    const ctx = buildTemplateContext(baseCopy, { logoUrl: 'javascript:alert(1)' })
    expect(ctx).not.toHaveProperty('logo_url')
  })

  it('escapes HTML in all values', () => {
    const xssCopy: WebsiteCopy = {
      slogan: '<script>xss</script>',
      seo: { title: '<b>T</b>', description: 'D' },
      sections: { hero: { heading: '"quote"' } },
    }
    const ctx = buildTemplateContext(xssCopy, null)
    expect(ctx['slogan']).not.toContain('<script>')
    expect(ctx['seo_title']).toBe('&lt;b&gt;T&lt;/b&gt;')
    expect(ctx['hero_heading']).toBe('&quot;quote&quot;')
  })

  it('omits undefined optional section fields', () => {
    const copy: WebsiteCopy = {
      slogan: 'S',
      seo: { title: 'T', description: 'D' },
      sections: { hero: { heading: 'H' } },
    }
    const ctx = buildTemplateContext(copy, null)
    expect(ctx).toHaveProperty('hero_heading')
    expect(ctx).not.toHaveProperty('hero_subheading')
    expect(ctx).not.toHaveProperty('hero_body')
    expect(ctx).not.toHaveProperty('hero_cta')
  })

  it('returns empty object with no sections and null brandKit', () => {
    const copy: WebsiteCopy = {
      slogan: 'S',
      seo: { title: 'T', description: 'D' },
      sections: {},
    }
    const ctx = buildTemplateContext(copy, null)
    expect(ctx['slogan']).toBe('S')
    expect(Object.keys(ctx)).toHaveLength(3) // slogan, seo_title, seo_description
  })
})
