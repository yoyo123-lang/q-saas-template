import Link from 'next/link'
import { UserPlus, Upload, MessageCircle, Handshake, Search, Star, ShieldCheck } from 'lucide-react'
import { Timeline } from '@/components/shared/timeline'
import { AccordionFaq } from '@/components/shared/accordion-faq'

export const metadata = {
  title: 'Cómo funciona',
  description:
    'Aprendé cómo comprar y vender activos digitales en Qapitaliza de forma segura y transparente.',
}

const sellerSteps = [
  {
    icon: UserPlus,
    title: 'Registrate gratis',
    description:
      'Creá tu cuenta en menos de un minuto. No necesitás tarjeta de crédito ni pago inicial.',
  },
  {
    icon: Upload,
    title: 'Publicá tu activo',
    description:
      'Completá el formulario con los datos de tu sitio, SaaS o dominio. Subí screenshots, metrics y descripción.',
  },
  {
    icon: MessageCircle,
    title: 'Recibí consultas',
    description:
      'Compradores interesados te contactan directamente por el chat. Respondé cuando quieras.',
  },
  {
    icon: Handshake,
    title: 'Cerrá la venta',
    description:
      'Acordá los términos y coordiná la transferencia del activo. Nuestro equipo te acompaña en el proceso.',
  },
]

const buyerSteps = [
  {
    icon: Search,
    title: 'Explorá el catálogo',
    description:
      'Filtrá por categoría, precio, revenue y tecnología. Encontrá el activo que se ajusta a tu búsqueda.',
  },
  {
    icon: Star,
    title: 'Evaluá y consultá',
    description:
      'Revisá métricas, screenshots y descripción. Enviá una consulta al vendedor para negociar.',
  },
  {
    icon: ShieldCheck,
    title: 'Cerrá con seguridad',
    description:
      'Coordiná la transferencia acompañado por nuestro equipo. Garantizamos un proceso transparente.',
  },
]

const faqItems = [
  {
    q: '¿Cuánto cuesta publicar un activo?',
    a: 'Publicar en Qapitaliza es completamente gratis. Solo cobramos una comisión del 5% sobre el precio de venta final cuando el activo se vende exitosamente.',
  },
  {
    q: '¿Qué tipos de activos puedo vender?',
    a: 'Podés vender sitios web con tráfico, dominios premium, aplicaciones SaaS, tiendas e-commerce y proyectos digitales en etapa temprana. Si tenés otro tipo de activo digital, contactanos.',
  },
  {
    q: '¿Cómo funciona la verificación de métricas?',
    a: 'Nuestro equipo revisa las métricas que declarás (revenue, tráfico, usuarios) y puede solicitar evidencia como capturas de analytics o acceso de lectura. Los activos verificados tienen mayor confianza con los compradores.',
  },
  {
    q: '¿Cuánto tiempo tarda en publicarse un activo?',
    a: 'Una vez que enviás tu listado para revisión, nuestro equipo lo revisa en 24-48 horas hábiles. Si todo está correcto, lo publicamos inmediatamente.',
  },
  {
    q: '¿Cómo se coordina la transferencia del activo?',
    a: 'Una vez acordado el precio con el vendedor, coordinamos la transferencia en orden: primero el pago, luego la transferencia del dominio/código/accesos. Usamos servicios de escrow cuando el monto lo requiere.',
  },
  {
    q: '¿Puedo comprar activos si no soy de Argentina?',
    a: 'Sí, Qapitaliza opera en toda Latinoamérica. Los precios están en USD y aceptamos transferencias internacionales. Las transacciones se pueden coordinar de forma remota.',
  },
]

export default function ComoFuncionaPage() {
  return (
    <div>
      {/* Hero */}
      <section className="mesh-gradient-amber py-20 text-center px-6">
        <h1 className="text-4xl md:text-5xl font-bold text-slate-50 max-w-3xl mx-auto">
          Cómo funciona <span className="text-amber-500">Qapitaliza</span>
        </h1>
        <p className="mt-4 text-lg text-slate-400 max-w-xl mx-auto">
          Comprar y vender activos digitales de forma segura, transparente y sin complicaciones.
        </p>
      </section>

      <div className="max-w-4xl mx-auto px-6 py-16 space-y-20">
        {/* Para vendedores */}
        <section>
          <h2 className="text-2xl font-semibold text-slate-50 mb-2">Para vendedores</h2>
          <p className="text-slate-400 mb-10">Publicá tu activo y encontrá el comprador ideal.</p>
          <Timeline steps={sellerSteps} />
        </section>

        {/* Para compradores */}
        <section>
          <h2 className="text-2xl font-semibold text-slate-50 mb-2">Para compradores</h2>
          <p className="text-slate-400 mb-10">Encontrá activos con métricas reales y comprá con confianza.</p>
          <Timeline steps={buyerSteps} />
        </section>

        {/* Verificación banner */}
        <section>
          <div className="bg-navy-900 border border-amber-500/20 rounded-2xl p-8 text-center">
            <h2 className="text-xl font-semibold text-slate-50 mb-2">
              Verificación por Qapitaliza
            </h2>
            <p className="text-slate-400 text-sm mb-8 max-w-md mx-auto">
              Revisamos y validamos las métricas de cada activo antes de publicarlo.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {[
                { title: 'Métricas validadas', desc: 'Revenue, tráfico y usuarios verificados con evidencia real.' },
                { title: 'Vendedores confiables', desc: 'Perfiles revisados antes de publicar su primer activo.' },
                { title: 'Proceso transparente', desc: 'Acompañamos cada transacción de inicio a fin.' },
              ].map((item) => (
                <div key={item.title} className="flex flex-col items-center gap-2">
                  <div className="size-8 rounded-full bg-emerald-500/15 flex items-center justify-center">
                    <ShieldCheck className="size-4 text-emerald-500" />
                  </div>
                  <p className="font-medium text-slate-50 text-sm">{item.title}</p>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section>
          <h2 className="text-2xl font-semibold text-slate-50 mb-8">Preguntas frecuentes</h2>
          <div className="bg-navy-900 border border-slate-800 rounded-xl px-6">
            <AccordionFaq items={faqItems} />
          </div>
        </section>

        {/* CTA Final */}
        <section className="text-center">
          <h2 className="text-2xl font-semibold text-slate-50 mb-4">
            ¿Listo para empezar?
          </h2>
          <p className="text-slate-400 mb-8">
            Unite a cientos de emprendedores que ya operan en Qapitaliza.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/registro?rol=seller"
              className="inline-flex items-center justify-center px-8 py-3 rounded-lg bg-amber-500 text-navy-950 font-semibold hover:bg-amber-400 transition-colors"
            >
              Publicá tu activo
            </Link>
            <Link
              href="/explorar"
              className="inline-flex items-center justify-center px-8 py-3 rounded-lg border border-amber-500 text-amber-500 font-medium hover:bg-amber-500/10 transition-colors"
            >
              Explorá el catálogo
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
