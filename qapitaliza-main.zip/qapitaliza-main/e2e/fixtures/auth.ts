/**
 * Fixture de autenticación E2E para Supabase.
 *
 * Estrategia: usa el Admin API de Supabase (service_role key) para crear
 * un usuario de test y obtener una sesión real sin pasar por la UI de login.
 * Hace cleanup automático al finalizar cada test.
 *
 * Requiere en .env.local (o env de CI):
 *   NEXT_PUBLIC_SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 *   E2E_TEST_PASSWORD (opcional, default: 'E2eTestPass123!')
 *
 * Cómo usar:
 *   import { test, expect } from './fixtures/auth'
 *   test('mi test', async ({ authedPage, testUser }) => { ... })
 */

import { test as base, type Page } from '@playwright/test'
import { createClient } from '@supabase/supabase-js'

/** Datos del usuario de test disponibles en el test */
export interface TestUser {
  id: string
  email: string
  role: 'authenticated'
}

/**
 * Extrae el project ref de la URL de Supabase.
 * Ej: https://abcdefgh.supabase.co → 'abcdefgh'
 */
function extractProjectRef(supabaseUrl: string): string {
  const match = supabaseUrl.match(/https?:\/\/([^.]+)\.supabase\.co/)
  if (!match) throw new Error(`No se pudo extraer el project ref de: ${supabaseUrl}`)
  return match[1]
}

export const test = base.extend<{ authedPage: Page; testUser: TestUser }>({
  testUser: [async ({}, use) => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY

    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error(
        'La fixture de auth requiere NEXT_PUBLIC_SUPABASE_URL y SUPABASE_SERVICE_ROLE_KEY. ' +
        'Configurarlas en .env.local o en el entorno de CI.'
      )
    }

    const adminClient = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    })

    const email = `e2e-${Date.now()}@test.qapitaliza.local`
    const password = process.env.E2E_TEST_PASSWORD ?? 'E2eTestPass123!'

    // Crear usuario de test (con email confirmado automáticamente)
    const { data, error } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    })

    if (error || !data.user) {
      throw new Error(`No se pudo crear el usuario de test: ${error?.message}`)
    }

    const testUser: TestUser = {
      id: data.user.id,
      email,
      role: 'authenticated',
    }

    await use(testUser)

    // Cleanup: eliminar el usuario de test
    await adminClient.auth.admin.deleteUser(testUser.id).catch((err) => {
      console.warn(`[fixture] No se pudo eliminar el usuario de test ${testUser.email}:`, err)
    })
  }, { scope: 'test' }],

  authedPage: [async ({ page, testUser }, use) => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
    const password = process.env.E2E_TEST_PASSWORD ?? 'E2eTestPass123!'

    const adminClient = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    })

    // Obtener sesión real via signInWithPassword
    const { data: signInData, error: signInError } = await adminClient.auth.signInWithPassword({
      email: testUser.email,
      password,
    })

    if (signInError || !signInData.session) {
      throw new Error(`No se pudo iniciar sesión con el usuario de test: ${signInError?.message}`)
    }

    const { access_token, refresh_token } = signInData.session
    const projectRef = extractProjectRef(supabaseUrl)

    // @supabase/ssr almacena la sesión en cookies chunkeadas.
    // El formato es: sb-[ref]-auth-token → JSON en chunks de ~3800 bytes.
    const sessionJson = JSON.stringify({
      access_token,
      refresh_token,
      token_type: 'bearer',
      expires_in: 3600,
      expires_at: Math.floor(Date.now() / 1000) + 3600,
    })

    // Para sesiones cortas el JSON cabe en una sola cookie.
    // Si en el futuro supera los 4096 bytes, el middleware de Supabase lo chunkeará
    // automáticamente. En tests esto no debería ocurrir.
    const cookieName = `sb-${projectRef}-auth-token`
    const baseUrl = new URL(process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000')

    await page.context().addCookies([
      {
        name: cookieName,
        value: sessionJson,
        domain: baseUrl.hostname,
        path: '/',
        httpOnly: false, // Supabase SSR usa cookies no-httpOnly para el client
        sameSite: 'Lax',
      },
    ])

    await use(page)
  }, { scope: 'test' }],
})

export { expect } from '@playwright/test'
