# Revisión: Security Auditor
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de Security Auditor

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 1 alto, 2 medios, 2 bajos

## Hallazgos

### [ALTO → CORREGIDO] Botón de favorito no redirigía a `/login` — acción silenciosa
- Dónde: `src/components/listings/listing-card.tsx`
- Problema: Al hacer click en favorito sin sesión, no pasaba nada. El usuario podía pensar que la acción fue guardada (falso positivo de UX).
- Fix aplicado: Si no hay `onFavoriteToggle`, el elemento es un `<Link href="/login">` — redirección explícita.

### [MEDIO] Rate limiting no implementado en páginas públicas
- Dónde: `next.config.ts`, middleware (no existe aún)
- Problema: El BUSINESS_MODEL.md requiere 60 req/min en catálogo público y 10 consultas/día por usuario. No hay middleware de rate limiting.
- Riesgo: Scraping del catálogo, abuse de la búsqueda, DDoS suave.
- Recomendación: Implementar en middleware de Next.js o via Vercel Edge Config en la siguiente sesión.

### [MEDIO] `'unsafe-eval'` en Content-Security-Policy
- Dónde: `next.config.ts:9`
- Problema: La CSP incluye `script-src 'unsafe-eval'`, que permite ejecución de strings como código. Necesario para Next.js dev, pero podría endurecerse en producción.
- Recomendación: Separar CSP por entorno. En producción, quitar `unsafe-eval` y usar nonces.

### [BAJO] `seller.id` (UUID) expuesto en link `/perfil/{id}`
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Problema: El UUID del seller es visible en la URL del perfil. No es un secreto (es un identificador público), pero podría usarse para enumerar usuarios.
- Recomendación: Usar el slug del perfil en lugar del UUID cuando exista.

### [BAJO] Cookie de deduplicación de vistas sin flag `Secure`
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx:63`
- Problema: La cookie `viewed_{id}` tiene `httpOnly: true` pero no `secure: true`.
- Fix: Agregar `secure: process.env.NODE_ENV === 'production'`.

## Lo que está bien
- Prisma ORM usa queries parametrizadas — sin riesgo de SQL injection.
- Variables de entorno en `.env.example` sin valores reales. `.env` en `.gitignore`.
- Headers de seguridad configurados en `next.config.ts` (X-Frame-Options, CSP, X-Content-Type-Options).
- Datos del DB no se exponen en mensajes de error al cliente.
- `robots.ts` creado — protege rutas `/api/`, `/dashboard/`, `/admin/`.

## Recomendaciones generales
- Implementar rate limiting en middleware antes del primer deploy público.
- Separar CSP por entorno (development vs production).
- Auditar dependencias con `npm audit` antes de cada deploy.
