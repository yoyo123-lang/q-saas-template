import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma, Prisma } from '@qautiva/db'
import {
  mergeFlowDefinition,
  hashFlowDefinition,
  getAgentNumberForStage,
} from '@/app/_lib/interview/merge-flow'
import {
  buildTemplatePersonalizationQuestions,
  hasTemplatePersonalizationQuestions,
} from '@/app/_lib/interview/template-personalization'
import type { QuestionBlock } from '@/app/_lib/interview/types'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

type SessionBody = {
  stageId: string
  projectId: string
}

/**
 * Campos que se devuelven al cliente en ambas ramas (nueva y existente).
 * Se mantiene acá para garantizar consistencia del contrato de respuesta.
 */
const SESSION_SELECT = {
  id: true,
  projectId: true,
  teamId: true,
  stageId: true,
  status: true,
  currentStep: true,
  totalSteps: true,
  answersVersion: true,
  answers: true,
  flowDefinition: true,
  templateVersion: true,
  startedAt: true,
  createdAt: true,
  updatedAt: true,
} as const

/**
 * POST /api/interview/sessions
 * Crea una nueva InterviewSession para una etapa, o retoma la existente.
 * Mergea preguntas base (AgentConfig) + industria (IndustryTemplate) → flowDefinition.
 *
 * Body: { stageId, projectId }
 * Returns: { ok: true, session, created: boolean }
 */
export async function POST(request: NextRequest) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: SessionBody
  try {
    body = (await request.json()) as SessionBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { stageId, projectId } = body

  if (!stageId || typeof stageId !== 'string' || stageId.trim().length === 0) {
    return NextResponse.json({ error: 'stageId es obligatorio' }, { status: 400 })
  }
  if (!projectId || typeof projectId !== 'string' || projectId.trim().length === 0) {
    return NextResponse.json({ error: 'projectId es obligatorio' }, { status: 400 })
  }

  // Verificar ownership: el usuario debe pertenecer al team del proyecto
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true, teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)
  const project = await prisma.project.findFirst({
    where: { id: projectId.trim(), teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, teamId: true, industry: true },
  })
  if (!project) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // Guard de permisos: MEMBER solo tiene lectura
  const perm = await checkTeamPermission(user.id, project.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden crear sesiones.' },
      { status: 403 },
    )
  }

  // Verificar que la etapa pertenece al proyecto
  const stage = await prisma.stage.findFirst({
    where: { id: stageId.trim(), projectId: project.id },
    select: { id: true, number: true, stageKey: true },
  })
  if (!stage) {
    return NextResponse.json({ error: 'Etapa no encontrada' }, { status: 404 })
  }

  const isDiscovery = stage.stageKey === 'DISCOVERY'

  // Retomar sesión existente — select explícito para no filtrar info interna al cliente
  const existing = await prisma.interviewSession.findUnique({
    where: { stageId: stage.id },
    select: SESSION_SELECT,
  })
  if (existing) {
    // DISCOVERY usa flujo conversacional. Si la sesión tiene el formato viejo
    // (flowDefinition con múltiples preguntas estáticas y casi sin respuestas),
    // la reseteamos para que empiece desde cero con la entrevista IA.
    if (isDiscovery && !['COMPLETED', 'PROCESSING'].includes(existing.status)) {
      const flow = (existing.flowDefinition ?? []) as QuestionBlock[]
      const answers = (existing.answers ?? {}) as Record<string, unknown>
      const unansweredCount = flow.filter((q) => answers[q.id] === undefined).length
      const isOldFormat = flow.length > 1 && unansweredCount > 1
      if (isOldFormat) {
        const reset = await prisma.interviewSession.update({
          where: { id: existing.id },
          data: {
            flowDefinition: [],
            answers: {},
            answersVersion: { increment: 1 },
            currentStep: 0,
            totalSteps: 0,
            status: 'NOT_STARTED',
            startedAt: null,
          },
          select: SESSION_SELECT,
        })
        return NextResponse.json({ ok: true, session: reset, created: false })
      }
    }

    // E3 (v1 only): para sesiones WEBSITE v1 (preguntas website_*) con template seleccionado,
    // inyectar preguntas tpl_* de personalización del template.
    // Sesiones v2 (preguntas web_*) no usan tpl_* — ver ADR-0018.
    const websiteRebuildableStatuses = ['NOT_STARTED', 'IN_PROGRESS', 'PAUSED']
    const existingFlow = (existing.flowDefinition ?? []) as QuestionBlock[]
    const isV1WebsiteSession = existingFlow.some((q) => q.id.startsWith('website_'))

    if (stage.stageKey === 'WEBSITE' && isV1WebsiteSession && websiteRebuildableStatuses.includes(existing.status)) {
      if (!hasTemplatePersonalizationQuestions(existingFlow)) {
        // selectedWebTemplateId no está en SESSION_SELECT — consulta adicional puntual
        const sessionMeta = await prisma.interviewSession.findUnique({
          where: { stageId: stage.id },
          select: { id: true, selectedWebTemplateId: true },
        })

        if (sessionMeta?.selectedWebTemplateId) {
          const template = await prisma.webTemplate.findUnique({
            where: { id: sessionMeta.selectedWebTemplateId },
            select: { sections: true },
          })

          if (template) {
            const persQuestions = buildTemplatePersonalizationQuestions(
              template.sections as Record<string, boolean>,
            )
            const newFlow = [...existingFlow, ...persQuestions]
            const newHash = hashFlowDefinition(newFlow)

            const updated = await prisma.interviewSession.update({
              where: { id: existing.id },
              data: {
                flowDefinition: newFlow as Prisma.InputJsonValue,
                flowDefinitionHash: newHash,
                totalSteps: newFlow.length,
              },
              select: SESSION_SELECT,
            })

            return NextResponse.json({ ok: true, session: updated, created: false })
          }
        }
      }
    }

    return NextResponse.json({ ok: true, session: existing, created: false })
  }

  // Construir flowDefinition: merge base (AgentConfig) + industria (IndustryTemplate)
  const agentNumber = getAgentNumberForStage(stage.stageKey, stage.number)

  const [agentConfig, industryTemplate] = await Promise.all([
    prisma.agentConfig.findUnique({
      where: { agentNumber },
      select: { interviewPrompt: true },
    }),
    prisma.industryTemplate.findFirst({
      where: { name: project.industry },
      select: { id: true, questions: true },
    }),
  ])

  const industryQuestions = (industryTemplate?.questions ?? null) as Record<
    string,
    QuestionBlock[]
  > | null

  // DISCOVERY siempre comienza con flowDefinition vacío — las preguntas se generan
  // dinámicamente por IA en /next-question. Para otros stages, el merge estático aplica.
  const flowDefinition = isDiscovery
    ? []
    : mergeFlowDefinition(
        stage.number,
        agentConfig?.interviewPrompt ?? null,
        industryQuestions,
      )
  const flowDefinitionHash = hashFlowDefinition(flowDefinition)

  let session
  try {
    session = await prisma.interviewSession.create({
      data: {
        projectId: project.id,
        teamId: project.teamId,
        stageId: stage.id,
        flowDefinition,
        flowDefinitionHash,
        templateVersion: new Date().toISOString().slice(0, 10),
        industryTemplateId: industryTemplate?.id ?? null,
        totalSteps: flowDefinition.length,
        status: 'NOT_STARTED',
      },
      select: SESSION_SELECT,
    })
  } catch (err) {
    // CR1: Si otro request creó la sesión entre nuestro findUnique y este create
    // (unique constraint P2002), retornar la sesión existente en lugar de un error 500
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
      const concurrent = await prisma.interviewSession.findUnique({
        where: { stageId: stage.id },
        select: SESSION_SELECT,
      })
      if (concurrent) {
        return NextResponse.json({ ok: true, session: concurrent, created: false })
      }
    }

    console.error('[interview/sessions] create failed', {
      projectId: project.id,
      stageId: stage.id,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json(
      { error: 'Error al crear la sesión de entrevista' },
      { status: 500 },
    )
  }

  return NextResponse.json({ ok: true, session, created: true }, { status: 201 })
}
