import { cookies } from 'next/headers'
import { NextResponse, type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

const VALID_ACTIVATIONS = ['ACTIVE', 'SKIP', 'PROVIDED_BY_CLIENT'] as const
type StageActivationValue = typeof VALID_ACTIVATIONS[number]

/**
 * PATCH /api/stages/[stageId]/activation
 * Cambia la activation de una etapa. Solo ADMIN y OWNER pueden hacerlo.
 * Si la activation cambia a SKIP o PROVIDED_BY_CLIENT, el stage queda COMPLETED.
 * Si cambia a ACTIVE, el stage vuelve a PENDING (solo si estaba COMPLETED por activation previa).
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: { stageId: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { activation } = body
  if (!activation || !VALID_ACTIVATIONS.includes(activation as StageActivationValue)) {
    return NextResponse.json(
      { error: `activation inválida. Valores permitidos: ${VALID_ACTIVATIONS.join(', ')}` },
      { status: 400 },
    )
  }

  // Cargar el stage y verificar que existe
  const stage = await prisma.stage.findUnique({
    where: { id: params.stageId },
    select: { id: true, teamId: true, activation: true, status: true },
  })

  if (!stage || !stage.teamId) {
    return NextResponse.json({ error: 'Etapa no encontrada' }, { status: 404 })
  }

  // Guard de permisos: solo ADMIN y OWNER
  const perm = await checkTeamPermission(user.id, stage.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden cambiar la activación.' },
      { status: 403 },
    )
  }

  const newActivation = activation as StageActivationValue

  // Determinar el nuevo status según la activation
  // Si pasa a no-ACTIVE: COMPLETED. Si vuelve a ACTIVE desde COMPLETED (solo si era por activation previa): PENDING
  const previouslyCompletedByActivation =
    stage.status === 'COMPLETED' &&
    (stage.activation === 'SKIP' || stage.activation === 'PROVIDED_BY_CLIENT')

  const newStatus =
    newActivation !== 'ACTIVE'
      ? 'COMPLETED'
      : previouslyCompletedByActivation
        ? 'PENDING'
        : stage.status // no cambiar si era COMPLETED por flujo normal

  await prisma.stage.update({
    where: { id: params.stageId },
    data: {
      activation: newActivation,
      status: newStatus,
      completedAt: newActivation !== 'ACTIVE' ? new Date() : (newStatus === 'PENDING' ? null : undefined),
    },
  })

  return NextResponse.json({ stageId: params.stageId, activation: newActivation, status: newStatus })
}
