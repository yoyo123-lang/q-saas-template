/**
 * Pantalla de bienvenida antes de iniciar la entrevista de una etapa.
 * Se muestra cuando InterviewSession.status === 'NOT_STARTED'.
 *
 * Si se provee welcomeData (configurado desde admin en /bienvenidas),
 * usa esos valores. Si no, cae al default genérico basado en stageNumber.
 */

import type { WelcomeData } from '../_types'
import { STAGE_ICONS, STAGE_DESCRIPTIONS } from '../_types'

type Props = {
  stageNumber: number
  stageName: string
  totalSteps: number
  onStart: () => void
  isLoading: boolean
  welcomeData?: WelcomeData
}

export function StageWelcomeScreen({
  stageNumber,
  stageName,
  totalSteps,
  onStart,
  isLoading,
  welcomeData,
}: Props) {
  const iconMeta = STAGE_ICONS[stageNumber] ?? { emoji: '📋', color: '#8B5CF6', bg: '#8B5CF6' }
  const resolvedEmoji = welcomeData?.icon ?? iconMeta.emoji
  const description =
    welcomeData?.description ??
    STAGE_DESCRIPTIONS[stageNumber] ??
    'Respondé las preguntas para avanzar en tu proceso.'
  const title = welcomeData?.title ?? stageName

  return (
    <div className="p-8 max-w-2xl">
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8">
        {/* Ícono de la etapa */}
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 text-2xl"
          style={{ backgroundColor: `${iconMeta.bg}15`, border: `1px solid ${iconMeta.color}30` }}
          aria-hidden="true"
        >
          {resolvedEmoji}
        </div>

        {/* Header */}
        <p className="text-[#94A3B8] text-sm font-medium mb-1">
          Etapa {stageNumber}
        </p>
        <h1 className="text-2xl font-bold text-white mb-3">{title}</h1>
        <p className="text-[#94A3B8] text-base leading-relaxed mb-6">{description}</p>

        {/* Info de duración */}
        {totalSteps > 0 && (
          <div className="flex items-center gap-4 mb-8 pb-6 border-b border-[#1E293B]">
            <InfoChip
              icon={
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 8v4l3 3" strokeLinecap="round" />
                </svg>
              }
              label={`${totalSteps} ${totalSteps === 1 ? 'pregunta' : 'preguntas'}`}
            />
            <InfoChip
              icon={
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                  <path d="M12 6v6l4 2" strokeLinecap="round" />
                </svg>
              }
              label={welcomeData?.estimatedTime ?? `~${Math.max(2, Math.ceil(totalSteps * 1.5))} min`}
            />
          </div>
        )}

        {/* fastTrackText desde admin (opcional) */}
        {welcomeData?.fastTrackText && (
          <p className="text-[#64748B] text-sm mb-6 italic">
            {welcomeData.fastTrackText}
          </p>
        )}

        {/* Mensaje de confianza */}
        <div className="flex items-start gap-3 mb-8">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#10B981"
            strokeWidth="2"
            className="mt-0.5 flex-shrink-0"
            aria-hidden="true"
          >
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
          <p className="text-[#94A3B8] text-sm">
            Podés pausar y retomar en cualquier momento. Tus respuestas se guardan automáticamente.
          </p>
        </div>

        {/* CTA */}
        <button
          onClick={onStart}
          disabled={isLoading}
          className="w-full py-3 px-6 bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors duration-200 flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <svg
                className="animate-spin"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                aria-hidden="true"
              >
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
              Iniciando...
            </>
          ) : (
            <>
              Comenzar entrevista
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                aria-hidden="true"
              >
                <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </>
          )}
        </button>
      </div>
    </div>
  )
}

function InfoChip({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-1.5 text-[#64748B] text-sm">
      {icon}
      <span>{label}</span>
    </div>
  )
}
