/**
 * Tests TDD para el cálculo de revenueUsd en el registro de dominios.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { NextRequest } from 'next/server'

const mockDomainCreate = vi.fn()
const mockDomainFindFirst = vi.fn()
const mockTldPricingFindUnique = vi.fn()
const mockUserProfileFindUnique = vi.fn()

vi.mock('@qautiva/db', () => ({
  prisma: {
    domain: { create: mockDomainCreate, findFirst: mockDomainFindFirst },
    tldPricing: { findUnique: mockTldPricingFindUnique },
    userProfile: { findUnique: mockUserProfileFindUnique },
  },
}))

vi.mock('@/lib/api/marketplace-helpers', () => ({
  getProfileOrUnauthorized: vi.fn().mockResolvedValue({
    unauthorized: false,
    profile: { id: 'profile-1' },
  }),
}))

const { POST } = await import('../register/route')

const makeRequest = (body: object) =>
  new NextRequest('http://localhost/api/domains/register', {
    method: 'POST',
    body: JSON.stringify(body),
    headers: { 'Content-Type': 'application/json' },
  })

const validContact = {
  firstName: 'Juan', lastName: 'Perez', address1: 'Calle 123',
  city: 'Buenos Aires', state: 'BA', postalCode: '1234',
  country: 'AR', phone: '+5491112345678', email: 'juan@test.com',
}

describe('POST /api/domains/register — revenueUsd', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: 'team-1', role: 'OWNER' }],
    })
    mockDomainFindFirst.mockResolvedValue(null) // no existe
    mockDomainCreate.mockResolvedValue({ id: 'domain-1' })
    process.env.EXCHANGE_RATE_USD_ARS = '1200'
  })

  afterEach(() => {
    delete process.env.EXCHANGE_RATE_USD_ARS
  })

  it('calcula revenueUsd correctamente para margen PERCENTAGE', async () => {
    // costo = $10 USD, margen 30%, precio final ARS = 10 * 1200 * 1.30 = 15600 ARS
    // revenueUsd = 15600 / 1200 - 10 = 13 - 10 = 3 USD
    mockTldPricingFindUnique.mockResolvedValue({
      registrationPriceUsd: { toString: () => '10' },
      marginType: 'PERCENTAGE',
      marginValue: { toString: () => '30' },
      isActive: true,
    })

    const req = makeRequest({ domain: 'test.com', contact: validContact })
    await POST(req)

    expect(mockDomainCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          revenueUsd: expect.closeTo(3, 2),
        }),
      }),
    )
  })

  it('retorna 500 si exchangeRate es 0 o inválido (error de configuración)', async () => {
    process.env.EXCHANGE_RATE_USD_ARS = '0'
    mockTldPricingFindUnique.mockResolvedValue({
      registrationPriceUsd: { toString: () => '10' },
      marginType: 'PERCENTAGE',
      marginValue: { toString: () => '30' },
      isActive: true,
    })

    const req = makeRequest({ domain: 'test.com', contact: validContact })
    const res = await POST(req)

    expect(res.status).toBe(500)
    expect(mockDomainCreate).not.toHaveBeenCalled()
  })

  it('retorna 400 si el TLD no está disponible', async () => {
    mockTldPricingFindUnique.mockResolvedValue(null)

    const req = makeRequest({ domain: 'test.xyz', contact: validContact })
    const res = await POST(req)

    expect(res.status).toBe(400)
  })
})
