/**
 * Tests de image-utils.ts
 *
 * Cubre: validateImageBytes, ensureBucket (caché Map), resizeImageForPayload,
 * uploadImageToStorage (URL pública vs signed).
 * Sin llamadas reales a APIs — todo mockeado.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Fixtures ──────────────────────────────────────────────────────────────────

const VALID_PNG = Buffer.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
  // width = 16px (BE), height = 16px (BE) — para que resizeImageForPayload lo lea
  0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
])

const VALID_JPEG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10])

const INVALID_BYTES = Buffer.from([0x00, 0x01, 0x02, 0x03])

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockListBuckets = vi.fn()
const mockCreateBucket = vi.fn()
const mockUpload = vi.fn()
const mockGetPublicUrl = vi.fn()
const mockCreateSignedUrl = vi.fn()

vi.mock('@qautiva/db', () => ({
  createServiceClient: () => ({
    storage: {
      listBuckets: mockListBuckets,
      createBucket: mockCreateBucket,
      from: (bucket: string) => ({
        upload: mockUpload,
        getPublicUrl: mockGetPublicUrl,
        createSignedUrl: mockCreateSignedUrl,
      }),
    },
  }),
}))

// ── Tests: validateImageBytes ─────────────────────────────────────────────────

describe('validateImageBytes', () => {
  it('acepta PNG válido', async () => {
    const { validateImageBytes } = await import('../image-utils')
    expect(() => validateImageBytes(VALID_PNG, 'test')).not.toThrow()
  })

  it('acepta JPEG válido', async () => {
    const { validateImageBytes } = await import('../image-utils')
    expect(() => validateImageBytes(VALID_JPEG, 'test')).not.toThrow()
  })

  it('lanza en buffer vacío', async () => {
    const { validateImageBytes } = await import('../image-utils')
    expect(() => validateImageBytes(Buffer.from([]), 'test')).toThrow('vacía')
  })

  it('lanza en bytes inválidos (no PNG ni JPEG)', async () => {
    const { validateImageBytes } = await import('../image-utils')
    expect(() => validateImageBytes(INVALID_BYTES, 'test')).toThrow('Magic bytes inválidos')
  })

  it('lanza si buffer supera MAX_IMAGE_BYTES', async () => {
    const { validateImageBytes, MAX_IMAGE_BYTES } = await import('../image-utils')
    const big = Buffer.alloc(MAX_IMAGE_BYTES + 1)
    big[0] = 0x89; big[1] = 0x50; big[2] = 0x4e; big[3] = 0x47
    expect(() => validateImageBytes(big, 'test')).toThrow('grande')
  })
})

// ── Tests: ensureBucket ───────────────────────────────────────────────────────

describe('ensureBucket', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    const { _resetBucketCacheForTesting } = await import('../image-utils')
    _resetBucketCacheForTesting()
  })

  it('no crea bucket si ya existe', async () => {
    mockListBuckets.mockResolvedValue({ data: [{ name: 'brand-logos' }], error: null })
    const { ensureBucket } = await import('../image-utils')
    await ensureBucket('brand-logos', true)
    expect(mockCreateBucket).not.toHaveBeenCalled()
  })

  it('crea bucket si no existe', async () => {
    mockListBuckets.mockResolvedValue({ data: [], error: null })
    mockCreateBucket.mockResolvedValue({ error: null })
    const { ensureBucket } = await import('../image-utils')
    await ensureBucket('ad-visuals', false)
    expect(mockCreateBucket).toHaveBeenCalledWith('ad-visuals', { public: false, allowedMimeTypes: ['image/png', 'image/jpeg'] })
  })

  it('ignora error "already exists" al crear bucket', async () => {
    mockListBuckets.mockResolvedValue({ data: [], error: null })
    mockCreateBucket.mockResolvedValue({ error: { message: 'already exists' } })
    const { ensureBucket } = await import('../image-utils')
    await expect(ensureBucket('ad-visuals', false)).resolves.not.toThrow()
  })

  it('usa caché Map — no llama a listBuckets la segunda vez', async () => {
    mockListBuckets.mockResolvedValue({ data: [{ name: 'brand-logos' }], error: null })
    const { ensureBucket } = await import('../image-utils')
    await ensureBucket('brand-logos', true)
    await ensureBucket('brand-logos', true)
    expect(mockListBuckets).toHaveBeenCalledTimes(1)
  })

  it('cachéa buckets independientemente (brand-logos y ad-visuals no se interfieren)', async () => {
    mockListBuckets.mockResolvedValue({ data: [{ name: 'brand-logos' }, { name: 'ad-visuals' }], error: null })
    const { ensureBucket } = await import('../image-utils')
    await ensureBucket('brand-logos', true)
    await ensureBucket('ad-visuals', false)
    // Ambos verificados en una sola llamada a listBuckets (la segunda ya usa caché)
    expect(mockListBuckets).toHaveBeenCalledTimes(2)
  })

  it('lanza si listBuckets falla', async () => {
    mockListBuckets.mockResolvedValue({ data: null, error: { message: 'network error' } })
    const { ensureBucket } = await import('../image-utils')
    await expect(ensureBucket('brand-logos', true)).rejects.toThrow('Error listando buckets')
  })
})

// ── Tests: uploadImageToStorage ───────────────────────────────────────────────

describe('uploadImageToStorage', () => {
  beforeEach(() => vi.clearAllMocks())

  it('devuelve URL pública si isPublic=true', async () => {
    mockUpload.mockResolvedValue({ error: null })
    mockGetPublicUrl.mockReturnValue({ data: { publicUrl: 'https://supabase.io/public/logo.png' } })
    const { uploadImageToStorage } = await import('../image-utils')
    const url = await uploadImageToStorage(VALID_PNG, 'brand-logos', 'proj/logo.png', true)
    expect(url).toBe('https://supabase.io/public/logo.png')
    expect(mockGetPublicUrl).toHaveBeenCalled()
    expect(mockCreateSignedUrl).not.toHaveBeenCalled()
  })

  it('devuelve signed URL si isPublic=false', async () => {
    mockUpload.mockResolvedValue({ error: null })
    mockCreateSignedUrl.mockResolvedValue({ data: { signedUrl: 'https://supabase.io/sign/123' }, error: null })
    const { uploadImageToStorage } = await import('../image-utils')
    const url = await uploadImageToStorage(VALID_PNG, 'ad-visuals', 'proj/ad.png', false)
    expect(url).toBe('https://supabase.io/sign/123')
    expect(mockCreateSignedUrl).toHaveBeenCalledWith('proj/ad.png', 60 * 60 * 24 * 365)
  })

  it('lanza si upload falla', async () => {
    mockUpload.mockResolvedValue({ error: { message: 'quota exceeded' } })
    const { uploadImageToStorage } = await import('../image-utils')
    await expect(uploadImageToStorage(VALID_PNG, 'ad-visuals', 'proj/ad.png', false)).rejects.toThrow('Upload fallido')
  })
})
