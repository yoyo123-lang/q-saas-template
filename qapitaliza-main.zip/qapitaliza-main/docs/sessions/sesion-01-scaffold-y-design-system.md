# Sesión 01 — Scaffold y Design System

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 00 — `.env.example` creado, `BUSINESS_MODEL.md` completo.

Esta sesión arranca el proyecto desde cero. Al terminar debe existir un Next.js funcional con el design system completo y todos los componentes UI primitivos construidos.

Leer antes de empezar:
- `PLAN.md` — Etapa 1 completa
- `docs/frontend/01-design-tokens.md` — tokens de diseño (colores, tipografía, iconografía)
- `docs/frontend/02-componentes-base.md` — especificación de todos los componentes UI
- `supabase/migrations/README.md` — orden de ejecución de migraciones

## Tarea de esta sesión

### 1. Inicializar el proyecto

```bash
npx create-next-app@latest . --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"
```

### 2. Ejecutar migraciones en Supabase

**IMPORTANTE:** Antes de configurar Prisma, abrir el SQL Editor de Supabase y ejecutar los archivos en orden:
`001` → `002` → `003` → `004` → `005` → `006` → `007` → `008` → `009` → `010`

Cada archivo está en `supabase/migrations/`. Ejecutar uno a la vez y verificar que no hay errores antes de continuar con el siguiente.

### 3. Instalar dependencias

```bash
npm install lucide-react tailwind-merge clsx sonner
npm install @prisma/client prisma
npm install @supabase/supabase-js @supabase/ssr
```

### 4. Configurar Prisma

Crear `prisma/schema.prisma` mapeando las tablas ya existentes en Supabase. Usar `datasource db` con `provider = "postgresql"`. Las tablas ya existen — Prisma solo las mapea, no las crea.

### 5. Configurar Supabase clients

Crear:
- `src/lib/supabase/client.ts` — browser client con `createBrowserClient`
- `src/lib/supabase/server.ts` — server client con `createServerClient`
- `src/middleware.ts` — refresh de sesión en todas las rutas

### 6. Design system en `globals.css`

Implementar según `docs/frontend/01-design-tokens.md`:
- CSS custom properties para todos los colores
- Clase `.mesh-gradient-amber` (radial gradient sutil)
- Clase `.card-hover` (transición borde amber en hover)
- Clase `.nav-active` (barra izquierda amber 3px)
- Import de DM Sans y JetBrains Mono desde Google Fonts

### 7. Extender `tailwind.config.ts`

Según `docs/frontend/01-design-tokens.md` §6:
- Colores: `navy.950`, `navy.900`
- Fuentes: `sans: ['DM Sans']`, `mono: ['JetBrains Mono']`

### 8. Crear `src/lib/utils/cn.ts`

```ts
import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
```

### 9. Crear componentes UI primitivos

Crear en `src/components/ui/`. Especificación completa en `docs/frontend/02-componentes-base.md`.

Orden de creación (de menor a mayor dependencia):

1. `button.tsx` — 6 variants (solid, outline, outline-danger, outline-success, ghost, link), 4 sizes, loading state con spinner, disabled state
2. `card.tsx` — props: hover, padding (sm/md/lg), border (default/amber)
3. `badge.tsx` — 5 variants (success, amber, info, muted, danger), prop dot, prop icon
4. `divider.tsx` — con label opcional centrado
5. `input.tsx` — label, helper, error, prefix, suffix, counter, focus ring amber
6. `textarea.tsx` — rows, maxLength con counter automático "X / Y caracteres"
7. `select.tsx` — mismos estilos que input, flecha con ChevronDown de lucide
8. `modal.tsx` — overlay con blur, panel centrado, sizes sm/md/lg, cerrar con Escape y click fuera
9. `accordion.tsx` — expand/collapse animado, solo una abierta a la vez
10. `avatar.tsx` — círculo con iniciales, colores por rol: amber=vendedor, blue=comprador, purple=admin
11. `pagination.tsx` — ← → con página activa en amber, ellipsis para saltos
12. `skeleton-card.tsx` — skeleton animado con pulse para loading state del catálogo

### 10. Crear componentes shared

En `src/components/shared/`:
- `logo-q.tsx` — cuadrado amber 8px radius con "Q" dark, props: size (sm/md/lg), showText, adminBadge
- `empty-state.tsx` — icon, title, description, cta (React.ReactNode opcional)
- `error-state.tsx` — message, retry callback

### 11. Root layout

`src/app/layout.tsx`:
- Metadata global: title template `'%s — Qapitaliza'`, description, openGraph
- Fonts DM Sans y JetBrains Mono via `next/font/google`
- `<Toaster>` de Sonner con `theme="dark"` y estilos navy

### 12. Middleware de auth

`src/middleware.ts`: refresh de sesión Supabase en todas las rutas. Proteger `/dashboard/*` y `/admin/*` — redirigir a `/login` si no hay sesión.

### 13. Headers de seguridad

`next.config.ts` con headers:
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `X-XSS-Protection: 1; mode=block`
- CSP básico

### 14. Health check

`src/app/api/health/route.ts` — responde `{ status: 'ok', timestamp }` con check de conexión a DB.

### 15. Página de prueba temporal

`src/app/test-ui/page.tsx` — página temporal que renderiza una muestra de cada componente para verificar visualmente que el design system está correcto. No se publica en producción.

## Reglas

- Seguir `CLAUDE.md` en todo momento
- Todos los componentes en TypeScript estricto con interfaces explícitas
- Usar `cn()` para todas las clases condicionales — nunca concatenación de strings
- Nunca usar valores hex hardcodeados en componentes — siempre clases Tailwind

## Checkpoint

La sesión está completa cuando:
- [ ] `npm run dev` levanta sin errores
- [ ] Las 10 migraciones SQL están aplicadas en Supabase
- [ ] Prisma puede hacer `prisma db pull` sin errores
- [ ] `/api/health` responde 200
- [ ] `/test-ui` muestra todos los componentes renderizados correctamente
- [ ] El design system (colores amber, navy, tipografía DM Sans) es visible
