'use client'

import { useState } from 'react'
import Image from 'next/image'
import { LogoQ } from '@/components/shared/logo-q'

interface GalleryClientProps {
  screenshots: string[]
  title: string
}

export function GalleryClient({ screenshots, title }: GalleryClientProps) {
  const [activeIdx, setActiveIdx] = useState(0)
  const active = screenshots[activeIdx]

  return (
    <div className="flex flex-col gap-3">
      {/* Main image */}
      <div className="relative w-full h-64 rounded-xl overflow-hidden bg-slate-800">
        {active ? (
          <>
            <Image
              src={active}
              alt={`${title} — screenshot ${activeIdx + 1}`}
              fill
              className="object-cover"
              sizes="(max-width: 1024px) 100vw, 65vw"
              priority
            />
            {screenshots.length > 1 && (
              <span className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded-full">
                {activeIdx + 1} / {screenshots.length}
              </span>
            )}
          </>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900">
            <LogoQ size="lg" />
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {screenshots.length > 1 && (
        <div className="flex gap-2 overflow-x-auto">
          {screenshots.map((src, i) => (
            <button
              key={i}
              onClick={() => setActiveIdx(i)}
              className={`relative h-16 w-24 rounded-lg overflow-hidden flex-shrink-0 border-2 transition-colors ${
                i === activeIdx ? 'border-amber-500' : 'border-slate-800 hover:border-slate-600'
              }`}
              aria-label={`Ver screenshot ${i + 1}`}
            >
              <Image
                src={src}
                alt={`Thumbnail ${i + 1}`}
                fill
                className="object-cover"
                sizes="96px"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
