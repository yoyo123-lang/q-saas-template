import type { Metadata } from 'next'
import { cache } from 'react'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import { ClientHeader } from '@/components/ClientHeader'
import { ClientTabs, type TabCounts } from '@/components/ClientTabs'
import { ProgresoTab } from '@/components/tabs/ProgresoTab'
import { EntregablesTab } from '@/components/tabs/EntregablesTab'
import { ConversacionesTab } from '@/components/tabs/ConversacionesTab'
import { NotasTab } from '@/components/tabs/NotasTab'
import { EntrevistaTab } from '@/components/tabs/EntrevistaTab'
import { CampanasTab } from '@/components/tabs/CampanasTab'
import type { OrgWithDetails } from '@/lib/types'
import { requireAdminSession } from '@/lib/supabase-server'

export const dynamic = 'force-dynamic'

// ── Carga de datos ─────────────────────────────────────────────────────────────

// cache() deduplica llamadas con el mismo id dentro del mismo request
const getOrg = cache(async function getOrg(id: string): Promise<OrgWithDetails | null> {
  return prisma.organization.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      industry: true,
      plan: true,
      status: true,
      websiteUrl: true,
      createdAt: true,
      stages: {
        orderBy: { number: 'asc' },
        select: {
          id: true,
          number: true,
          name: true,
          status: true,
          adminApproved: true,
          clientApproved: true,
          deliverables: {
            orderBy: { createdAt: 'asc' },
            select: {
              id: true,
              title: true,
              type: true,
              status: true,
              version: true,
              feedback: true,
              content: true,
            },
          },
          interviewSession: {
            select: {
              id: true,
              status: true,
              currentStep: true,
              totalSteps: true,
              answers: true,
              lastError: true,
              errorDetails: true,
              followUpHistory: true,
              retryCount: true,
              processingStartedAt: true,
              startedAt: true,
              completedAt: true,
              createdAt: true,
            },
          },
        },
      },
      messages: {
        orderBy: { createdAt: 'asc' },
        take: 300,
        select: {
          id: true,
          sender: true,
          channel: true,
          stageNumber: true,
          content: true,
          createdAt: true,
        },
      },
      notes: {
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: {
          id: true,
          content: true,
          createdAt: true,
          updatedAt: true,
        },
      },
      subscription: {
        select: {
          status: true,
          planAmount: true,
          nextBillingAt: true,
        },
      },
    },
  }) as Promise<OrgWithDetails | null>
})

// ── Metadata ───────────────────────────────────────────────────────────────────
// Reutiliza la misma query que la página para evitar doble hit a la DB.

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const org = await getOrg(params.id)
  return {
    title: org ? `${org.name} | Qautiva Admin` : 'Cliente | Qautiva Admin',
  }
}

// ── Tabs válidas ───────────────────────────────────────────────────────────────

const VALID_TABS = new Set(['progreso', 'entregables', 'conversaciones', 'notas', 'entrevista', 'campanas'])

// ── Página ─────────────────────────────────────────────────────────────────────

interface PageProps {
  params: { id: string }
  searchParams: { tab?: string }
}

export default async function ClientePage({ params, searchParams }: PageProps) {
  await requireAdminSession()
  const org = await getOrg(params.id)
  if (!org) notFound()

  const tab = VALID_TABS.has(searchParams.tab ?? '') ? (searchParams.tab ?? 'progreso') : 'progreso'
  const hasAdminReview = org.stages.some((s) => s.status === 'ADMIN_REVIEW')

  const sessionCount = org.stages.filter((s) => s.interviewSession !== null).length
  const campaignDeliverableCount = org.stages.reduce(
    (n, s) => n + s.deliverables.filter(
      (d) => d.type === 'CAMPAIGN_PLAN' || d.type === 'AD_CREATIVES'
    ).length,
    0,
  )
  const tabCounts: TabCounts = {
    entregables:    org.stages.reduce((n, s) => n + s.deliverables.length, 0),
    conversaciones: org.messages.length,
    notas:          org.notes.length,
    entrevista:     sessionCount,
    campanas:       campaignDeliverableCount,
  }

  return (
    <div className="flex flex-col h-full p-6 gap-5">
      <ClientHeader org={org} hasAdminReview={hasAdminReview} />
      <ClientTabs orgId={org.id} activeTab={tab} counts={tabCounts} />

      {tab === 'progreso'       && <ProgresoTab stages={org.stages} orgId={org.id} />}
      {tab === 'entregables'    && <EntregablesTab stages={org.stages} />}
      {tab === 'conversaciones' && <ConversacionesTab messages={org.messages} orgId={org.id} />}
      {tab === 'notas'          && <NotasTab notes={org.notes} orgId={org.id} />}
      {tab === 'entrevista'     && <EntrevistaTab stages={org.stages} orgId={org.id} />}
      {tab === 'campanas'       && <CampanasTab stages={org.stages} orgId={org.id} />}
    </div>
  )
}
