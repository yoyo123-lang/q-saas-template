'use client'

/**
 * Página de bienvenidas — parte cliente.
 * Maneja la selección de etapa activa, el estado del form y el preview live.
 */

import { useState } from 'react'
import type { StageWelcome } from '@qautiva/db'
import { StageWelcomeForm } from '@/components/forms/StageWelcomeForm'
import type { PreviewFields } from '@/components/forms/StageWelcomeForm'
import { StageWelcomePreview } from '@/components/StageWelcomePreview'

const STAGE_META: Record<string, { label: string; emoji: string; number: number }> = {
  DISCOVERY:  { label: 'Tu negocio',  emoji: '🏢', number: 1 },
  RESEARCH:   { label: 'Mercado',     emoji: '🔍', number: 2 },
  BRAND:      { label: 'Marca',       emoji: '🎨', number: 3 },
  WEBSITE:    { label: 'Web',         emoji: '🌐', number: 4 },
  CAMPAIGNS:  { label: 'Campañas',    emoji: '📣', number: 5 },
  MEDIA:      { label: 'Medios',      emoji: '📺', number: 6 },
}

const STAGE_KEYS = ['DISCOVERY', 'RESEARCH', 'BRAND', 'WEBSITE', 'CAMPAIGNS', 'MEDIA'] as const

type Props = {
  welcomes: StageWelcome[]
}

const EMPTY_PREVIEW: PreviewFields = {
  title: '',
  description: '',
  estimatedTime: '',
  whatYouGet: '',
  icon: '',
  fastTrackText: '',
}

export function BienvenidaClient({ welcomes }: Props) {
  const [activeKey, setActiveKey] = useState<string>('DISCOVERY')
  const [previewFields, setPreviewFields] = useState<PreviewFields>(EMPTY_PREVIEW)
  const [previewMobile, setPreviewMobile] = useState(true)

  const welcomeMap = Object.fromEntries(welcomes.map((w) => [w.stageKey, w]))
  const active = welcomeMap[activeKey]

  return (
    <div className="flex gap-6 min-h-0">
      {/* ── Panel izquierdo: selector + form ───────────────────────────────── */}
      <div className="flex-1 min-w-0 space-y-6">
        {/* Tabs de etapa */}
        <div className="flex flex-wrap gap-2">
          {STAGE_KEYS.map((key) => {
            const meta = STAGE_META[key]!
            const isActive = key === activeKey
            const hasData = Boolean(welcomeMap[key])
            return (
              <button
                key={key}
                onClick={() => setActiveKey(key)}
                className={`
                  flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                  ${isActive
                    ? 'bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#A78BFA]'
                    : 'bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] hover:text-[#F8FAFC] hover:border-[#334155]'
                  }
                `}
              >
                <span>{meta.emoji}</span>
                <span>
                  {meta.number}. {meta.label}
                </span>
                {hasData && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Configurado" />
                )}
              </button>
            )
          })}
        </div>

        {/* Form */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
          <h2 className="text-base font-semibold text-white mb-1">
            {STAGE_META[activeKey]!.emoji} Etapa {STAGE_META[activeKey]!.number} —{' '}
            {STAGE_META[activeKey]!.label}
          </h2>
          <p className="text-xs text-[#475569] mb-5">
            {active
              ? 'Editando configuración guardada en DB.'
              : 'Sin configuración. Al guardar se creará el registro.'}
          </p>
          <StageWelcomeForm
            key={activeKey}
            welcome={active ?? { stageKey: activeKey }}
            onChange={setPreviewFields}
          />
        </div>
      </div>

      {/* ── Panel derecho: preview ──────────────────────────────────────────── */}
      <div className="w-[420px] flex-shrink-0 space-y-4">
        {/* Toggle mobile/desktop */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#475569]">Vista previa:</span>
          <button
            onClick={() => setPreviewMobile(true)}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              previewMobile
                ? 'bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/40'
                : 'bg-[#0F172A] text-[#64748B] border border-[#1E293B] hover:text-[#94A3B8]'
            }`}
          >
            📱 Mobile
          </button>
          <button
            onClick={() => setPreviewMobile(false)}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              !previewMobile
                ? 'bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/40'
                : 'bg-[#0F172A] text-[#64748B] border border-[#1E293B] hover:text-[#94A3B8]'
            }`}
          >
            🖥 Desktop
          </button>
        </div>

        <StageWelcomePreview fields={previewFields} mobile={previewMobile} />
      </div>
    </div>
  )
}
