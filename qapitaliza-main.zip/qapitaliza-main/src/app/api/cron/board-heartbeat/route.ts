import { NextResponse } from 'next/server'
import { getPrisma } from '@/lib/prisma'
import { sendHeartbeat } from '@/lib/board-client'

export const runtime = 'nodejs'

export async function GET(request: Request) {
  const authHeader = request.headers.get('authorization')
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const checks: Record<string, string> = { api: 'ok' }

  if (process.env.DATABASE_URL) {
    try {
      const prisma = getPrisma()
      await prisma.$queryRaw`SELECT 1`
      checks.db = 'ok'
    } catch {
      checks.db = 'error'
    }
  }

  await sendHeartbeat(checks)
  return NextResponse.json({ success: true })
}
