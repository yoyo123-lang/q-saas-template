# Prompts para Gemini — Páginas de Auth

> Cada prompt es autocontenido. Copiá y pegá uno a la vez en Gemini.

---

## PROMPT 1: Login (`/login`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales (sitios web, dominios, MVPs, proyectos digitales).

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A (negro azulado profundo)
- Fondo cards: #0F172A (navy oscuro)
- Fondo inputs: #1E293B (navy medio)
- Acento primario: #F59E0B (amber/dorado)
- Acento hover: #FBBF24
- Glow: rgba(245, 158, 11, 0.15)
- Texto primario: #F8FAFC | Texto secundario: #94A3B8 | Texto apagado: #64748B
- Bordes: #1E293B | Success: #10B981 | Error: #EF4444

Tipografía: DM Sans (400, 500, 600, 700).
Cards: rounded 12px. Buttons: rounded 8px. Inputs: rounded 8px.
Logo: cuadrado amber 8px radius con "Q" en #0B0F1A bold. Idioma: español argentino.

PÁGINA: Login — pantalla de inicio de sesión

ESTRUCTURA:

Layout de 2 columnas 50/50 que ocupa todo el viewport (100vh):

COLUMNA IZQUIERDA (50% — decorativa):
- Fondo: #0B0F1A con radial gradient animado de amber al 8% de opacidad (mesh gradient sutil, efecto de luz dorada)
- Centrado verticalmente:
  - Logo grande: cuadrado amber 64x64px con "Q" en negro, debajo "qapitaliza" en 24px semibold #F8FAFC
  - Tagline: "El marketplace de activos digitales" en 16px #94A3B8
  - Abajo, un testimonial o stat sutil: "Más de 340 emprendedores ya operan en Qapitaliza" en 14px #64748B

COLUMNA DERECHA (50% — formulario):
- Fondo: #0F172A
- Centrado vertical y horizontal:
  - Heading: "Iniciá sesión" (28px semibold #F8FAFC)
  - Subtítulo: "Ingresá a tu cuenta para comprar o vender activos" (14px #94A3B8)
  - Espacio 32px
  - Botón Google OAuth (full width): fondo #1E293B, borde #1E293B, rounded 8px, ícono G de Google a la izquierda, texto "Continuar con Google" en #F8FAFC, hover con borde amber sutil
  - Divider: línea #1E293B con texto "o" centrado en #64748B
  - Campo "Email": label "Email" (14px medium #94A3B8), input fondo #1E293B, borde #1E293B, placeholder "tu@email.com", rounded 8px, focus con borde amber
  - Campo "Contraseña": label "Contraseña", input tipo password, ícono ojo para mostrar/ocultar, link "¿Olvidaste tu contraseña?" en amber alineado a la derecha
  - Espacio 24px
  - Botón "Iniciar sesión" (full width): fondo #F59E0B, texto #0B0F1A font medium, rounded 8px, hover #FBBF24
  - Espacio 16px
  - Texto: "¿No tenés cuenta?" + link "Registrate" en amber
  - Abajo del todo: "Parte del ecosistema Q Company" en 12px #64748B
```

---

## PROMPT 2: Registro (`/register`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A | Fondo cards: #0F172A | Fondo inputs: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24 | Glow: rgba(245, 158, 11, 0.15)
- Texto: #F8FAFC (primario), #94A3B8 (secundario), #64748B (apagado)
- Bordes: #1E293B | Success: #10B981 | Error: #EF4444

Tipografía: DM Sans (400, 500, 600, 700). Inputs/Buttons: rounded 8px. Cards: rounded 12px.
Logo: cuadrado amber con "Q" oscuro. Idioma: español argentino.

PÁGINA: Registro — crear cuenta nueva

ESTRUCTURA:

Layout de 2 columnas 50/50, 100vh:

COLUMNA IZQUIERDA (decorativa):
- Fondo #0B0F1A con mesh gradient amber sutil
- Centrado: logo grande Q amber + "qapitaliza"
- 3 features con ícono check amber:
  - "Publicá activos gratis"
  - "Métricas verificadas"
  - "Soporte en cada transacción"

COLUMNA DERECHA (formulario):
- Fondo #0F172A
- Centrado:
  - Heading: "Creá tu cuenta" (28px semibold #F8FAFC)
  - Subtítulo: "Empezá a comprar y vender activos digitales" (14px #94A3B8)
  - Espacio 24px
  - Botón Google OAuth (full width): fondo #1E293B, ícono G, "Registrate con Google"
  - Divider "o"

  - Campo "Nombre completo": input fondo #1E293B, placeholder "Ej: Martín Rodríguez"
  - Campo "Email": placeholder "tu@email.com"
  - Campo "Contraseña": con indicador de fuerza debajo (barra que se llena: rojo → amber → verde)
  - Campo "Confirmar contraseña"

  - Selector de rol (2 cards seleccionables, layout horizontal):
    - Card "Quiero comprar" (ícono shopping-bag): "Explorá activos digitales para invertir". Borde #1E293B, seleccionada con borde amber y glow
    - Card "Quiero vender" (ícono upload): "Publicá tus sitios, dominios y proyectos". Misma estética
    - Nota: "(Podés hacer ambas cosas después)" en 12px #64748B

  - Checkbox: "Acepto los términos y condiciones y la política de privacidad" con links en amber
  - Espacio 24px
  - Botón "Crear cuenta" (full width amber, texto oscuro)
  - Texto: "¿Ya tenés cuenta?" + link "Iniciá sesión" en amber
```
