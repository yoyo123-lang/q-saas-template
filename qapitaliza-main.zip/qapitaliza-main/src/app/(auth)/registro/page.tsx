'use client'

import { useState, useTransition } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Eye, EyeOff, ShoppingBag, Upload } from 'lucide-react'
import { toast } from 'sonner'
import { createClient } from '@/lib/supabase/client'
import { registerSchema, type RegisterData } from '@/lib/schemas/auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Divider } from '@/components/ui/divider'
import { PasswordStrength } from '@/components/ui/password-strength'
import { RoleCard } from '@/components/auth/role-card'

export default function RegistroPage() {
  const router = useRouter()
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [isPending, startTransition] = useTransition()

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, touchedFields },
  } = useForm<RegisterData>({
    resolver: zodResolver(registerSchema),
    mode: 'onBlur',
    defaultValues: { rol: 'BUYER', acceptTerms: false },
  })

  const watchPassword = watch('password') ?? ''
  const watchRol = watch('rol')

  const handleGoogleLogin = () => {
    window.location.href = '/api/auth/google'
  }

  const onSubmit = (data: RegisterData) => {
    startTransition(async () => {
      const supabase = createClient()

      const { data: authData, error } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            nombre: data.nombre,
            role: data.rol,
          },
        },
      })

      if (error) {
        const code = (error as { code?: string }).code
        if (error.status === 429 || code === 'over_request_rate_limit') {
          toast.error('Demasiados intentos de registro. Esperá unos minutos antes de reintentar.')
          return
        }
        if (code === 'user_already_exists' || error.message?.includes('already registered')) {
          toast.error('Ya existe una cuenta con ese email.')
          return
        }
        toast.error('Error al crear la cuenta. Intentá de nuevo.')
        return
      }

      if (authData.user && data.rol === 'SELLER') {
        await supabase
          .from('profiles')
          .update({ role: 'SELLER' })
          .eq('id', authData.user.id)
      }

      router.push('/dashboard?verificar=1')
    })
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-sm space-y-4">
      <div>
        <h1 className="text-2xl font-semibold text-slate-50">Creá tu cuenta</h1>
        <p className="text-sm text-slate-400 mt-1">
          Unite al marketplace de activos digitales
        </p>
      </div>

      <Button
        type="button"
        variant="ghost"
        size="full"
        className="border border-slate-700 bg-slate-800 hover:border-amber-500/30 hover:bg-slate-800"
        onClick={handleGoogleLogin}
        disabled={isPending}
      >
        <GoogleIcon />
        Continuar con Google
      </Button>

      <Divider label="o" />

      <Input
        label="Nombre completo"
        type="text"
        placeholder="Juan García"
        autoComplete="name"
        {...register('nombre')}
        error={touchedFields.nombre ? errors.nombre?.message : undefined}
      />

      <Input
        label="Email"
        type="email"
        placeholder="tu@email.com"
        autoComplete="email"
        {...register('email')}
        error={touchedFields.email ? errors.email?.message : undefined}
      />

      <div className="space-y-1.5">
        <Input
          label="Contraseña"
          type={showPassword ? 'text' : 'password'}
          autoComplete="new-password"
          suffix={
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="text-slate-400 hover:text-slate-200 transition-colors"
              aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          {...register('password')}
          error={touchedFields.password ? errors.password?.message : undefined}
        />
        <PasswordStrength password={watchPassword} />
      </div>

      <Input
        label="Confirmar contraseña"
        type={showConfirm ? 'text' : 'password'}
        autoComplete="new-password"
        suffix={
          <button
            type="button"
            onClick={() => setShowConfirm((v) => !v)}
            className="text-slate-400 hover:text-slate-200 transition-colors"
            aria-label={showConfirm ? 'Ocultar contraseña' : 'Mostrar contraseña'}
          >
            {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        }
        {...register('confirmPassword')}
        error={touchedFields.confirmPassword ? errors.confirmPassword?.message : undefined}
      />

      <div className="space-y-1">
        <p className="text-sm font-medium text-slate-400">¿Qué querés hacer?</p>
        <div className="grid grid-cols-2 gap-3">
          <RoleCard
            value="BUYER"
            selected={watchRol === 'BUYER'}
            onClick={() => setValue('rol', 'BUYER', { shouldValidate: true })}
            icon={<ShoppingBag size={24} />}
            title="Quiero comprar"
            description="Explorá activos digitales para invertir"
          />
          <RoleCard
            value="SELLER"
            selected={watchRol === 'SELLER'}
            onClick={() => setValue('rol', 'SELLER', { shouldValidate: true })}
            icon={<Upload size={24} />}
            title="Quiero vender"
            description="Publicá tus sitios, dominios y proyectos"
          />
        </div>
        <p className="text-xs text-slate-500 text-center">(Podés hacer ambas cosas después)</p>
        {errors.rol && (
          <p className="text-xs text-red-400">{errors.rol.message}</p>
        )}
      </div>

      <div className="space-y-1">
        <label className="flex items-start gap-2.5 cursor-pointer">
          <input
            type="checkbox"
            className="mt-0.5 accent-amber-500 size-4 flex-shrink-0"
            {...register('acceptTerms')}
          />
          <span className="text-xs text-slate-400">
            Acepto los{' '}
            <Link href="/terminos" className="text-amber-500 hover:text-amber-400">
              Términos de servicio
            </Link>{' '}
            y la{' '}
            <Link href="/privacidad" className="text-amber-500 hover:text-amber-400">
              Política de privacidad
            </Link>
          </span>
        </label>
        {errors.acceptTerms && (
          <p className="text-xs text-red-400">{errors.acceptTerms.message}</p>
        )}
      </div>

      <Button type="submit" variant="solid" size="full" loading={isPending}>
        Crear cuenta
      </Button>

      <p className="text-sm text-center text-slate-400">
        ¿Ya tenés cuenta?{' '}
        <Link href="/login" className="text-amber-500 hover:text-amber-400">
          Iniciá sesión
        </Link>
      </p>
    </form>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
      <path
        d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"
        fill="#4285F4"
      />
      <path
        d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.836.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z"
        fill="#34A853"
      />
      <path
        d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"
        fill="#FBBC05"
      />
      <path
        d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"
        fill="#EA4335"
      />
    </svg>
  )
}
