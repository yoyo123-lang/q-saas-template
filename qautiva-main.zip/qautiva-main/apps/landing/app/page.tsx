import { Navbar } from '@/components/Navbar'
import { Hero } from '@/components/Hero'
import { DominiosSection } from '@/components/DominiosSection'
import { HowItWorks } from '@/components/HowItWorks'
import { Deliverables } from '@/components/Deliverables'
import { WhyDifferent } from '@/components/WhyDifferent'
import { Domains } from '@/components/Domains'
import { Pricing } from '@/components/Pricing'
import { Ecosystem } from '@/components/Ecosystem'
import { FinalCta } from '@/components/FinalCta'
import { Footer } from '@/components/Footer'

export default function HomePage() {
  return (
    <main>
      <Navbar />
      <Hero />
      <DominiosSection />
      <HowItWorks />
      <Deliverables />
      <WhyDifferent />
      <Domains />
      <Pricing />
      <Ecosystem />
      <FinalCta />
      <Footer />
    </main>
  )
}
