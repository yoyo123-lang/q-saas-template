import type { Metadata } from 'next'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import type { OrderStatus } from '@qautiva/db'

export const metadata: Metadata = { title: 'Órdenes | Qautiva Admin' }
export const dynamic = 'force-dynamic'

// ── Helpers de presentación ────────────────────────────────────────────────────

const STATUS_BADGE: Record<OrderStatus, { label: string; className: string }> = {
  PENDING:   { label: 'Pendiente',  className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  ACCEPTED:  { label: 'Aceptada',  className: 'bg-[#3B82F6]/15 text-[#60A5FA]' },
  DELIVERED: { label: 'Entregada', className: 'bg-[#8B5CF6]/15 text-[#A78BFA]' },
  IN_REVIEW: { label: 'En revisión', className: 'bg-[#8B5CF6]/15 text-[#A78BFA]' },
  REVISION:  { label: 'Con correcciones', className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  COMPLETED: { label: 'Completada', className: 'bg-[#10B981]/15 text-[#10B981]' },
  CANCELLED: { label: 'Cancelada', className: 'bg-[#64748B]/15 text-[#94A3B8]' },
  DISPUTED:  { label: 'Disputada', className: 'bg-[#EF4444]/15 text-[#F87171]' },
}

const VALID_STATUSES = [
  'ALL', 'PENDING', 'ACCEPTED', 'DELIVERED', 'DISPUTED',
  'REVISION', 'IN_REVIEW', 'COMPLETED', 'CANCELLED',
] as const
type StatusFilter = typeof VALID_STATUSES[number]

const PAGE_SIZE = 50

// ── Query ──────────────────────────────────────────────────────────────────────

async function getOrders(statusFilter: StatusFilter, page: number) {
  const where = statusFilter !== 'ALL' ? { status: statusFilter as OrderStatus } : {}
  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      select: {
        id: true,
        status: true,
        price: true,
        expiresAt: true,
        createdAt: true,
        advertiser: { select: { displayName: true } },
        medium: {
          select: {
            name: true,
            user: { select: { displayName: true } },
          },
        },
        product: { select: { name: true } },
      },
    }),
    prisma.order.count({ where }),
  ])
  return { orders, total }
}

// ── Page ───────────────────────────────────────────────────────────────────────

interface PageProps {
  searchParams: { status?: string; page?: string }
}

export default async function OrdenesPage({ searchParams }: PageProps) {
  const rawStatus = searchParams.status ?? 'ALL'
  const statusFilter: StatusFilter = (VALID_STATUSES as readonly string[]).includes(rawStatus)
    ? (rawStatus as StatusFilter)
    : 'ALL'

  const rawPage = parseInt(searchParams.page ?? '1', 10)
  const page = isNaN(rawPage) || rawPage < 1 ? 1 : rawPage

  const { orders, total } = await getOrders(statusFilter, page)
  const pages = Math.ceil(total / PAGE_SIZE)
  const now = new Date()

  const tabs: { value: StatusFilter; label: string }[] = [
    { value: 'ALL',       label: 'Todas' },
    { value: 'PENDING',   label: 'Pendientes' },
    { value: 'ACCEPTED',  label: 'Aceptadas' },
    { value: 'DELIVERED', label: 'Entregadas' },
    { value: 'DISPUTED',  label: 'Disputadas' },
    { value: 'COMPLETED', label: 'Completadas' },
    { value: 'CANCELLED', label: 'Canceladas' },
  ]

  return (
    <div className="flex flex-col h-full p-6 gap-5">
      {/* Header */}
      <div>
        <h1 className="text-white text-xl font-bold">Órdenes</h1>
        <p className="text-[#64748B] text-sm mt-0.5">
          {total} orden{total !== 1 ? 'es' : ''}
          {statusFilter !== 'ALL' ? ` en estado "${STATUS_BADGE[statusFilter as OrderStatus]?.label ?? statusFilter}"` : ''}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <Link
            key={tab.value}
            href={`/ordenes?status=${tab.value}`}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              statusFilter === tab.value
                ? 'bg-[#8B5CF6] text-white'
                : 'text-[#64748B] hover:text-white hover:bg-[#1E293B]'
            }`}
          >
            {tab.label}
          </Link>
        ))}
      </div>

      {/* Lista */}
      {orders.length === 0 ? (
        <p className="text-[#64748B] text-sm">Sin órdenes en este estado.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[#1E293B]">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[#64748B] border-b border-[#1E293B] bg-[#0F172A]">
                <th className="px-4 py-3 font-medium">ID</th>
                <th className="px-4 py-3 font-medium">Anunciante</th>
                <th className="px-4 py-3 font-medium">Editor / Medio</th>
                <th className="px-4 py-3 font-medium">Producto</th>
                <th className="px-4 py-3 font-medium">Precio</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3 font-medium">Vence</th>
                <th className="px-4 py-3 font-medium">Fecha</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => {
                const badge = STATUS_BADGE[o.status] ?? { label: o.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }
                const isPending = o.status === 'PENDING'
                const isExpired = isPending && o.expiresAt != null && o.expiresAt < now
                const expiresInHours = isPending && o.expiresAt != null
                  ? Math.floor((o.expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60))
                  : null
                const expiresUrgent = expiresInHours !== null && expiresInHours >= 0 && expiresInHours <= 12
                return (
                  <tr
                    key={o.id}
                    className="border-b border-[#1E293B] last:border-0 hover:bg-[#0F172A] transition-colors"
                  >
                    <td className="px-4 py-3">
                      <Link
                        href={`/ordenes/${o.id}`}
                        className="text-[#A78BFA] hover:underline font-mono text-xs"
                      >
                        {o.id.slice(0, 8)}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8]">{o.advertiser.displayName}</td>
                    <td className="px-4 py-3">
                      <span className="text-white">{o.medium.user.displayName}</span>
                      <span className="text-[#64748B] ml-1 text-xs">({o.medium.name})</span>
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8]">{o.product.name}</td>
                    <td className="px-4 py-3 text-white font-medium">
                      ${Number(o.price).toLocaleString('es-AR')}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
                        {badge.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs">
                      {!isPending || o.expiresAt == null ? (
                        <span className="text-[#64748B]">—</span>
                      ) : isExpired ? (
                        <span className="text-[#EF4444] font-medium">Expirada</span>
                      ) : expiresUrgent ? (
                        <span className="text-[#F59E0B] font-medium" title={o.expiresAt.toLocaleString('es-AR')}>
                          {expiresInHours}h
                        </span>
                      ) : (
                        <span className="text-[#64748B]">
                          {o.expiresAt.toLocaleDateString('es-AR')}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs">
                      {o.createdAt.toLocaleDateString('es-AR')}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Paginación */}
      {pages > 1 && (
        <div className="flex items-center gap-2 text-sm">
          {page > 1 && (
            <Link
              href={`/ordenes?status=${statusFilter}&page=${page - 1}`}
              className="px-3 py-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-[#1E293B] transition-colors"
            >
              ← Anterior
            </Link>
          )}
          <span className="text-[#64748B]">
            Página {page} de {pages}
          </span>
          {page < pages && (
            <Link
              href={`/ordenes?status=${statusFilter}&page=${page + 1}`}
              className="px-3 py-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-[#1E293B] transition-colors"
            >
              Siguiente →
            </Link>
          )}
        </div>
      )}
    </div>
  )
}
