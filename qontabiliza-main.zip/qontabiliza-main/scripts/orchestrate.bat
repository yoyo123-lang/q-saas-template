@echo off
chcp 65001 >nul
title q-orchestrator — qontabiliza

set "PROJECT_SLUG=qontabiliza"

:: ── Buscar orquestador ──
set "ORCHESTRATOR_PATH="

:: Opción 1: carpeta local orchestrator/
if exist "%~dp0..\orchestrator\q-orchestrator.sh" (
    set "ORCHESTRATOR_PATH=%~dp0..\orchestrator"
    goto :found
)

:: Opción 2: q-saas-template en HOME
if exist "%USERPROFILE%\q-saas-template\scripts\orchestrator\q-orchestrator.sh" (
    set "ORCHESTRATOR_PATH=%USERPROFILE%\q-saas-template\scripts\orchestrator"
    goto :found
)

:: Opción 3: variable de entorno
if defined ORCHESTRATOR_PATH (
    if exist "%ORCHESTRATOR_PATH%\q-orchestrator.sh" goto :found
)

echo [ERROR] Orquestador no encontrado.
echo.
echo Opciones:
echo   1. Setea ORCHESTRATOR_PATH con la ruta al orchestrator
echo   2. Clona q-saas-template en %%USERPROFILE%%\q-saas-template
echo   3. Copia la carpeta orchestrator\ a la raiz de este proyecto
pause
exit /b 1

:found

:: ── Buscar Git Bash ──
set "GITBASH="
if exist "C:\Program Files\Git\bin\bash.exe" (
    set "GITBASH=C:\Program Files\Git\bin\bash.exe"
) else (
    for /f "delims=" %%i in ('where bash 2^>nul') do set "GITBASH=%%i"
)

if "%GITBASH%"=="" (
    echo [ERROR] Git Bash no encontrado. Instala Git desde https://git-scm.com
    pause
    exit /b 1
)

:: ── Ejecutar ──
"%GITBASH%" -c "bash '%ORCHESTRATOR_PATH:\=/%/q-orchestrator.sh' --project '%PROJECT_SLUG%' %*"
pause
