import Link from 'next/link'

export const metadata = {
  title: 'Términos y Condiciones — qautiva Marketing',
}

export default function TerminosPage() {
  return (
    <main className="min-h-screen bg-navy-950 flex flex-col items-center justify-center px-6 py-24">
      <div className="max-w-2xl w-full text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Términos y Condiciones</h1>
        <p className="text-slate-400 text-lg mb-8">
          Esta página está en construcción. Próximamente encontrarás aquí nuestros términos y condiciones de uso.
        </p>
        <Link
          href="/"
          className="inline-flex items-center text-slate-400 hover:text-white text-sm transition-colors duration-200 underline underline-offset-2"
        >
          Volver al inicio
        </Link>
      </div>
    </main>
  )
}
