import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockRequireAdminSession = vi.fn()
const mockMediumFindUnique = vi.fn()
const mockMediumUpdate = vi.fn()
const mockRevalidatePath = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  requireAdminSession: mockRequireAdminSession,
}))

// La ruta @/ apunta a apps/portal/ en vitest, pero actions.ts hace un lazy import
// de @/lib/agent-defaults (que es apps/admin/lib/agent-defaults). Lo mockeamos.
vi.mock('@/lib/agent-defaults', () => ({
  getAgentDefault: vi.fn(),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    medium: {
      findUnique: mockMediumFindUnique,
      update: mockMediumUpdate,
    },
  },
}))

vi.mock('next/cache', () => ({
  revalidatePath: mockRevalidatePath,
}))

function makeFormData(fields: Record<string, string>): FormData {
  const fd = new FormData()
  for (const [key, val] of Object.entries(fields)) {
    fd.append(key, val)
  }
  return fd
}

describe('approveMedia', () => {
  beforeEach(() => {
    vi.resetModules()
    mockRequireAdminSession.mockReset()
    mockMediumFindUnique.mockReset()
    mockMediumUpdate.mockReset()
    mockRevalidatePath.mockReset()
  })

  it('lanza error si no hay mediumId', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { approveMedia } = await import('../../lib/actions')
    await expect(approveMedia(makeFormData({}))).rejects.toThrow('mediumId requerido')
  })

  it('lanza error si mediumId es solo espacios', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { approveMedia } = await import('../../lib/actions')
    await expect(approveMedia(makeFormData({ mediumId: '   ' }))).rejects.toThrow('mediumId requerido')
  })

  it('lanza error si el medio no existe', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce(null)

    const { approveMedia } = await import('../../lib/actions')
    await expect(approveMedia(makeFormData({ mediumId: 'm-1' }))).rejects.toThrow('Medio no encontrado')
  })

  it('lanza error si el medio no está en PENDING_REVIEW', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({ id: 'm-1', status: 'ACTIVE', name: 'Blog' })

    const { approveMedia } = await import('../../lib/actions')
    await expect(approveMedia(makeFormData({ mediumId: 'm-1' }))).rejects.toThrow(
      'El medio ya no está pendiente de revisión',
    )
  })

  it('lanza error si prisma.update falla', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({ id: 'm-1', status: 'PENDING_REVIEW', name: 'Blog' })
    mockMediumUpdate.mockRejectedValueOnce(new Error('DB error'))

    const { approveMedia } = await import('../../lib/actions')
    await expect(approveMedia(makeFormData({ mediumId: 'm-1' }))).rejects.toThrow(
      'No se pudo aprobar el medio',
    )
  })

  it('actualiza estado a ACTIVE y revalida paths', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({ id: 'm-1', status: 'PENDING_REVIEW', name: 'Blog' })
    mockMediumUpdate.mockResolvedValueOnce({ id: 'm-1', status: 'ACTIVE' })

    const { approveMedia } = await import('../../lib/actions')
    await approveMedia(makeFormData({ mediumId: 'm-1' }))

    expect(mockMediumUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ id: 'm-1' }),
        data: { status: 'ACTIVE' },
      }),
    )
    expect(mockRevalidatePath).toHaveBeenCalledWith('/medios')
    expect(mockRevalidatePath).toHaveBeenCalledWith('/medios/m-1')
  })
})

describe('rejectMedia', () => {
  beforeEach(() => {
    vi.resetModules()
    mockRequireAdminSession.mockReset()
    mockMediumFindUnique.mockReset()
    mockMediumUpdate.mockReset()
    mockRevalidatePath.mockReset()
  })

  it('lanza error si no hay mediumId', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { rejectMedia } = await import('../../lib/actions')
    await expect(rejectMedia(makeFormData({ reason: 'Motivo' }))).rejects.toThrow('mediumId requerido')
  })

  it('lanza error si no hay reason', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { rejectMedia } = await import('../../lib/actions')
    await expect(rejectMedia(makeFormData({ mediumId: 'm-1' }))).rejects.toThrow(
      'El motivo de rechazo es requerido',
    )
  })

  it('lanza error si reason es solo espacios', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { rejectMedia } = await import('../../lib/actions')
    await expect(rejectMedia(makeFormData({ mediumId: 'm-1', reason: '  ' }))).rejects.toThrow(
      'El motivo de rechazo es requerido',
    )
  })

  it('lanza error si reason supera 1000 caracteres', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { rejectMedia } = await import('../../lib/actions')
    await expect(
      rejectMedia(makeFormData({ mediumId: 'm-1', reason: 'x'.repeat(1001) })),
    ).rejects.toThrow('1000 caracteres')
  })

  it('lanza error si el medio no existe', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce(null)

    const { rejectMedia } = await import('../../lib/actions')
    await expect(rejectMedia(makeFormData({ mediumId: 'm-1', reason: 'Motivo' }))).rejects.toThrow(
      'Medio no encontrado',
    )
  })

  it('lanza error si el medio no está en PENDING_REVIEW', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({ id: 'm-1', status: 'REJECTED', name: 'Blog' })

    const { rejectMedia } = await import('../../lib/actions')
    await expect(rejectMedia(makeFormData({ mediumId: 'm-1', reason: 'Motivo' }))).rejects.toThrow(
      'El medio ya no está pendiente de revisión',
    )
  })

  it('actualiza estado a REJECTED con motivo y revalida paths', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({ id: 'm-1', status: 'PENDING_REVIEW', name: 'Blog' })
    mockMediumUpdate.mockResolvedValueOnce({ id: 'm-1', status: 'REJECTED' })

    const { rejectMedia } = await import('../../lib/actions')
    await rejectMedia(makeFormData({ mediumId: 'm-1', reason: 'Contenido inadecuado' }))

    expect(mockMediumUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ id: 'm-1' }),
        data: { status: 'REJECTED', rejectionReason: 'Contenido inadecuado' },
      }),
    )
    expect(mockRevalidatePath).toHaveBeenCalledWith('/medios')
    expect(mockRevalidatePath).toHaveBeenCalledWith('/medios/m-1')
  })

  it('recorta espacios del reason antes de guardar', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({ id: 'm-1', status: 'PENDING_REVIEW', name: 'Blog' })
    mockMediumUpdate.mockResolvedValueOnce({ id: 'm-1', status: 'REJECTED' })

    const { rejectMedia } = await import('../../lib/actions')
    await rejectMedia(makeFormData({ mediumId: 'm-1', reason: '  Contenido inadecuado  ' }))

    expect(mockMediumUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ rejectionReason: 'Contenido inadecuado' }),
      }),
    )
  })
})
