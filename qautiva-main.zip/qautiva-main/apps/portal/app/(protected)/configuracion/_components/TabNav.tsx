type Tab = {
  id: string
  label: string
}

const ALL_TABS: Tab[] = [
  { id: 'cuenta', label: 'Mi cuenta' },
  { id: 'ia', label: 'IA' },
  { id: 'plan', label: 'Plan y facturación' },
]

const LEGACY_WITH_CAMPAIGNS_TABS: Tab[] = [
  { id: 'cuenta', label: 'Mi cuenta' },
  { id: 'publicidad', label: 'Publicidad' },
]

type Props = {
  activeTab: string
  isLegacy: boolean
  showPublicidad: boolean
}

export function TabNav({ activeTab, isLegacy, showPublicidad }: Props) {
  const tabs = isLegacy
    ? (showPublicidad ? LEGACY_WITH_CAMPAIGNS_TABS : ALL_TABS.slice(0, 1))
    : ALL_TABS

  return (
    <div className="flex gap-1 bg-[#0F172A] border border-[#1E293B] rounded-lg p-1 mb-8 w-fit">
      {tabs.map((tab) => (
        <a
          key={tab.id}
          href={tab.id === 'cuenta' ? '/configuracion' : `/configuracion?tab=${tab.id}`}
          className={`
            px-4 py-1.5 rounded-md text-sm font-medium transition-colors duration-200
            ${activeTab === tab.id
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#94A3B8] hover:text-white'
            }
          `}
        >
          {tab.label}
        </a>
      ))}
    </div>
  )
}
