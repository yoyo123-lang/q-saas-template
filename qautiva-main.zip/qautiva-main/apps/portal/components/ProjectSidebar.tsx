'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import {
  BarChart3,
  ChevronLeft,
  Folder,
  Image,
  Megaphone,
  MessageCircle,
} from 'lucide-react'
import { ChatPanel } from './ChatPanel'

type NavItem = {
  label: string
  href: string
  icon: React.ElementType
}

type ProjectSidebarProps = {
  projectId: string
  projectName: string
  /** Href a la entrevista activa, si existe. Si es null no se muestra el link. */
  interviewHref?: string | null
  /** Href a la página de cuentas publicitarias. Si es null no se muestra el link. */
  adsHref?: string | null
  /** Href a la página de creativos para Meta Ads. Si es null no se muestra el link. */
  creativosHref?: string | null
}

function ProjectAvatar({ name }: { name: string }) {
  const initials = name
    .split(' ')
    .slice(0, 2)
    .map((word) => word[0])
    .join('')
    .toUpperCase()

  return (
    <div className="flex items-center gap-3 px-4 py-3 mb-2">
      <div className="w-8 h-8 rounded-full bg-[#8B5CF6] flex items-center justify-center flex-shrink-0">
        <span className="text-white text-xs font-bold">{initials || '?'}</span>
      </div>
      <span className="text-[#F8FAFC] text-sm font-medium truncate">
        {name || 'Mi proyecto'}
      </span>
    </div>
  )
}

function NavLink({ item, isActive }: { item: NavItem; isActive: boolean }) {
  const Icon = item.icon

  return (
    <Link
      href={item.href}
      className={`
        flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium
        transition-colors duration-200 mx-2
        ${isActive
          ? 'bg-[#8B5CF6] text-white'
          : 'text-[#94A3B8] hover:text-white hover:bg-[#1E293B]'
        }
      `}
    >
      <Icon size={18} aria-hidden="true" />
      {item.label}
    </Link>
  )
}

/**
 * Sidebar de navegación para el dashboard del proyecto self-service.
 * Usa projectId para construir las rutas y para el chat.
 */
export function ProjectSidebar({ projectId, projectName, interviewHref, adsHref, creativosHref }: ProjectSidebarProps) {
  const pathname = usePathname()
  const [chatOpen, setChatOpen] = useState(false)

  const base = `/proyectos/${projectId}`

  const mainItems: NavItem[] = [
    { label: 'Mi progreso', href: `${base}/progreso`, icon: BarChart3 },
    { label: 'Mis archivos', href: `${base}/entregables`, icon: Folder },
  ]

  if (interviewHref) {
    mainItems.push({ label: 'Entrevista', href: interviewHref, icon: MessageCircle })
  }

  if (adsHref) {
    mainItems.push({ label: 'Publicidad', href: adsHref, icon: Megaphone })
  }

  if (creativosHref) {
    mainItems.push({ label: 'Creativos', href: creativosHref, icon: Image })
  }

  const isActive = (href: string) =>
    pathname === href || pathname.startsWith(`${href}/`)

  return (
    <>
      <aside
        className="flex flex-col w-[260px] min-h-0 border-r border-[#1E293B] bg-[#0B0F1A] flex-shrink-0"
        aria-label="Navegación del proyecto"
      >
        {/* Link "Mis proyectos" */}
        <div className="px-4 pt-4 pb-1">
          <Link
            href="/proyectos"
            className="inline-flex items-center gap-1 text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors duration-200"
          >
            <ChevronLeft size={12} aria-hidden="true" />
            Mis proyectos
          </Link>
        </div>

        {/* Proyecto */}
        <ProjectAvatar name={projectName} />

        {/* Separador */}
        <div className="mx-4 mb-3 h-px bg-[#1E293B]" />

        {/* Navegación */}
        <nav className="flex-1 flex flex-col gap-0.5 py-1">
          {mainItems.map((item) => (
            <NavLink key={item.href} item={item} isActive={isActive(item.href)} />
          ))}
        </nav>

        {/* Botón chat + cross-links */}
        <div className="px-4 pb-4">
          <div className="h-px bg-[#1E293B] mb-4" />
          <button
            type="button"
            onClick={() => setChatOpen(true)}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium bg-[#8B5CF6] text-white hover:bg-[#A78BFA] transition-colors duration-200"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            Chateá con el asistente
          </button>

          {/* Cross-links ecosistema */}
          <div className="flex items-center justify-center gap-4 mt-3">
            <a
              href="https://qobra.ar"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors duration-200"
            >
              qobra
            </a>
            <span className="text-[#1E293B] text-xs">·</span>
            <a
              href="https://qontacta.ar"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors duration-200"
            >
              qontacta
            </a>
          </div>
        </div>
      </aside>

      {chatOpen && (
        <ChatPanel onClose={() => setChatOpen(false)} projectId={projectId} />
      )}
    </>
  )
}
