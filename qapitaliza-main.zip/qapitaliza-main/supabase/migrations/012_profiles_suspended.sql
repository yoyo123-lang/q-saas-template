-- Migration 012: Add suspended_at to profiles for user suspension feature
-- Follows the same soft-state pattern as deleted_at
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS suspended_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_profiles_suspended_at
  ON profiles(suspended_at)
  WHERE suspended_at IS NOT NULL;
