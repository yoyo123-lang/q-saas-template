# Comando: /project:e2e

Generá o actualizá tests E2E para la entidad o flujo indicado.

## Contexto del proyecto

- **Framework E2E**: Playwright
- **Tests en**: `e2e/`
- **Fixture de auth**: `e2e/fixtures/auth.ts` (Admin API de Supabase, cleanup automático)
- **Playbook de patrones**: `docs/playbooks/e2e.md`
- **Config**: `playwright.config.ts`
- **Scripts**: `npm run test:e2e` (todos), `npm run test:e2e:headed` (con browser visible)

## Tu tarea

1. **Leer** el playbook completo en `docs/playbooks/e2e.md`
2. **Identificar** qué nivel de test aplica al flujo pedido (0, 1, 2, o 3)
3. **Elegir el patrón generativo** más apropiado del playbook
4. **Leer** los tests existentes en `e2e/` para entender el estilo y evitar duplicados
5. **Crear** el archivo `e2e/NN-nombre-del-flujo.spec.ts` usando el patrón elegido

## Reglas

- Si requiere auth → importar `{ test, expect }` desde `./fixtures/auth`
- Si es público → importar de `@playwright/test`
- Selectores por rol semántico primero (`getByRole`, `getByLabel`, `getByText`)
- Nombres de tests en español
- Sin `waitForTimeout` fijo
- Datos de test únicos si crean registros (usar timestamp: `e2e-${Date.now()}`)

## Después de crear el test

1. Mostrarme el archivo creado
2. Decirme qué env vars necesita para correr
3. Si es nivel 2+, explicar cómo correrlo localmente (requiere Supabase configurado)

## Uso

```
/project:e2e [descripción del flujo o entidad a testear]
```

**Ejemplos:**
- `/project:e2e flujo de favoritos (agregar y quitar un activo)`
- `/project:e2e página de detalle de un listado (pública, sin auth)`
- `/project:e2e flujo de recuperación de contraseña`
- `/project:e2e panel admin: rechazar un listado con motivo`
