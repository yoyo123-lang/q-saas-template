/**
 * Shared authentication helpers for Server Actions.
 * Centralizes the Supabase auth check to avoid duplication across action files.
 */

import { createClient } from '@/lib/supabase/server'
import type { User } from '@supabase/supabase-js'

/**
 * Returns the currently authenticated Supabase user, or null if not authenticated.
 * Use this at the start of every Server Action that requires authentication.
 */
export async function getAuthenticatedUser(): Promise<User | null> {
  const supabase = await createClient()
  const { data: { user }, error } = await supabase.auth.getUser()
  if (error || !user) return null
  return user
}
