'use client'

import { useState, useTransition } from 'react'
import type { ApiKeyData } from './ApiKeyCard'

const PROVIDERS = [
  { value: 'ANTHROPIC', label: 'Anthropic (Claude)' },
  { value: 'OPENAI', label: 'OpenAI (GPT)' },
  { value: 'GOOGLE_GEMINI', label: 'Google Gemini' },
]

type Props = {
  onAdded: (key: ApiKeyData) => void
  onCancel: () => void
}

export function AddApiKeyForm({ onAdded, onCancel }: Props) {
  const [isPending, startTransition] = useTransition()
  const [provider, setProvider] = useState('ANTHROPIC')
  const [key, setKey] = useState('')
  const [label, setLabel] = useState('')
  const [error, setError] = useState<string | null>(null)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (!key.trim()) {
      setError('La API key es obligatoria')
      return
    }

    startTransition(async () => {
      const res = await fetch('/api/settings/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider, key: key.trim(), label: label.trim() || undefined }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error ?? 'Error al agregar la key')
        return
      }
      onAdded(data.key as ApiKeyData)
      setKey('')
      setLabel('')
      setProvider('ANTHROPIC')
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3 pt-4 border-t border-[#1E293B]">
      <div className="flex flex-col gap-1">
        <label htmlFor="apikey-provider" className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
          Proveedor
        </label>
        <select
          id="apikey-provider"
          value={provider}
          onChange={(e) => setProvider(e.target.value)}
          disabled={isPending}
          className="bg-[#0B1120] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        >
          {PROVIDERS.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="apikey-key" className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
          API Key
        </label>
        <input
          id="apikey-key"
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="sk-ant-..."
          disabled={isPending}
          className="bg-[#0B1120] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] font-mono focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="apikey-label" className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
          Nombre <span className="normal-case font-normal">(opcional)</span>
        </label>
        <input
          id="apikey-label"
          type="text"
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="Ej: Producción"
          disabled={isPending}
          maxLength={100}
          className="bg-[#0B1120] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        />
      </div>

      {error && (
        <div className="bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm rounded-lg px-4 py-2">
          {error}
        </div>
      )}

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={isPending}
          className="bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
        >
          {isPending ? 'Validando…' : 'Agregar'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          disabled={isPending}
          className="text-[#94A3B8] hover:text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
        >
          Cancelar
        </button>
      </div>
    </form>
  )
}
