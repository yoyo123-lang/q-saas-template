# Plan de Implementación — Qontabiliza Fase 1 (MVP Vendible)

## Cómo usar este plan

Al inicio de cada sesión, pedile a Claude:

```
Leé docs/plan_inicial/sesion-XX.md y ejecutá el plan.
```

Claude va a:
1. Leer el archivo de la sesión
2. Leer el ROADMAP.md para contexto general
3. Ejecutar cada etapa en orden, con micro-revisión después de cada una
4. Commitear al final de cada etapa

## Sesiones

| Sesión | Archivo | Descripción | Depende de |
|--------|---------|-------------|------------|
| S01 | `sesion-01.md` | Schema base y multi-tenancy (backend) | — |
| S02 | `sesion-02.md` | Multi-tenancy (frontend) y onboarding | S01 |
| S03 | `sesion-03.md` | Productos y catálogo | S02 |
| S04 | `sesion-04.md` | Listas de precios + Clientes y proveedores | S03 |
| S05 | `sesion-05.md` | Facturación ARCA (backend) | S04 |
| S06 | `sesion-06.md` | Facturación ARCA (frontend) + PDF | S05 |
| S07 | `sesion-07.md` | Stock básico | S03 |
| S08 | `sesion-08.md` | Ventas y POS (backend) + Tesorería | S05, S06, S07 |
| S09 | `sesion-09.md` | Ventas y POS (frontend) | S08 |
| S10 | `sesion-10.md` | Reportes, dashboard y suscripciones | S09 |
| S11 | `sesion-11.md` | QA, polish y deploy | Todas |

## Orden visual

```
S01 ──→ S02 ──→ S03 ──→ S04 ──→ S05 ──→ S06 ──┐
                  │                               │
                  └──→ S07 ──────────────────────→ S08 ──→ S09 ──→ S10 ──→ S11
```

## Convenciones del plan

- **Tarea atómica**: la unidad mínima de trabajo. Se commitea al completarla.
- **Etapa**: grupo de tareas atómicas relacionadas. Se hace micro-revisión al terminar.
- **Sesión**: grupo de etapas. Se hace cierre con `/project:cierre` al terminar.
- Cada tarea indica los archivos que toca y el patrón a seguir.
- Los modelos de Prisma se crean todos en S01. Las sesiones siguientes NO modifican el schema (salvo ajustes menores documentados).

## Stack de referencia

- **Framework**: Next.js 15 App Router
- **Lenguaje**: TypeScript strict
- **DB**: PostgreSQL (Supabase) via Prisma 6
- **Auth**: NextAuth v5 con Google OAuth
- **Validación**: Zod 3
- **UI**: Tailwind 4, Radix UI, lucide-react
- **Facturación**: Afip SDK (Node.js)
- **Testing**: Vitest (unitarios), Playwright (E2E)
- **Formato**: argentino obligatorio (fechas dd/mm/yyyy, números con punto de miles y coma decimal)
