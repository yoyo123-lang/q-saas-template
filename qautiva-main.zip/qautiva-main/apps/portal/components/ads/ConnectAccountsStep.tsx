'use client'

import { useState, useEffect, useCallback } from 'react'
import { AdAccountCard } from './AdAccountCard'

interface AdAccount {
  id: string
  platform: 'GOOGLE_ADS' | 'META'
  name: string
  status: 'PENDING_AUTH' | 'ACTIVE' | 'EXPIRED' | 'DISCONNECTED' | 'ERROR'
  tokenExpiresAt: string | null
  metadata: Record<string, unknown> | null
}

interface ConnectAccountsStepProps {
  projectId: string
  /** Mensaje de error desde query param (ej: después de un OAuth fallido) */
  errorMessage?: string | null
  /** Callback cuando el cliente decide continuar sin conectar */
  onSkip?: () => void
}

export function ConnectAccountsStep({ projectId, errorMessage, onSkip }: ConnectAccountsStepProps) {
  const [accounts, setAccounts] = useState<AdAccount[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(errorMessage ?? null)

  const hasGoogle = accounts.some(a => a.platform === 'GOOGLE_ADS' && a.status === 'ACTIVE')
  const hasMeta = accounts.some(a => a.platform === 'META' && a.status === 'ACTIVE')

  const fetchAccounts = useCallback(async () => {
    setIsLoading(true)
    try {
      const res = await fetch(`/api/ads/accounts?projectId=${projectId}`)
      if (!res.ok) throw new Error('Error al cargar cuentas')
      const data = await res.json() as { accounts: AdAccount[] }
      setAccounts(data.accounts)
    } catch {
      setError('No pudimos cargar tus cuentas. Recargá la página.')
    } finally {
      setIsLoading(false)
    }
  }, [projectId])

  useEffect(() => {
    void fetchAccounts()
  }, [fetchAccounts])

  async function handleDisconnect(accountId: string) {
    const res = await fetch(`/api/ads/accounts?accountId=${accountId}`, { method: 'DELETE' })
    if (!res.ok) {
      setError('No pudimos desconectar la cuenta. Intentá de nuevo.')
      return
    }
    await fetchAccounts()
  }

  const activeAccounts = accounts.filter(a => a.status !== 'DISCONNECTED')

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-white">Conectá tus cuentas publicitarias</h2>
        <p className="mt-1 text-sm text-zinc-400">
          Conectá Google Ads y/o Meta Ads para que podamos crear y gestionar tus campañas.
          Tu información está protegida — nunca compartimos tus credenciales.
        </p>
      </div>

      {/* Error banner */}
      {error && (
        <div className="rounded-lg bg-red-500/10 border border-red-500/20 px-4 py-3">
          <p className="text-sm text-red-400">⚠ {error}</p>
          <button onClick={() => setError(null)} className="mt-1 text-xs text-red-400/60 hover:text-red-400">
            Cerrar
          </button>
        </div>
      )}

      {/* Cuentas conectadas */}
      {isLoading ? (
        <div className="space-y-2">
          {[1, 2].map(i => (
            <div key={i} className="h-16 animate-pulse rounded-lg bg-white/5" />
          ))}
        </div>
      ) : activeAccounts.length > 0 ? (
        <div className="space-y-2">
          <p className="text-xs font-medium uppercase tracking-wide text-zinc-500">Cuentas conectadas</p>
          {activeAccounts.map(account => (
            <AdAccountCard
              key={account.id}
              {...account}
              onDisconnect={handleDisconnect}
            />
          ))}
        </div>
      ) : null}

      {/* Botones de conexión */}
      <div className="space-y-3">
        <p className="text-xs font-medium uppercase tracking-wide text-zinc-500">
          {activeAccounts.length > 0 ? 'Conectar otra plataforma' : 'Elegí qué plataformas usar'}
        </p>

        {/* Google Ads */}
        {!hasGoogle && (
          <a
            href={`/api/ads/google/auth?projectId=${projectId}`}
            className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/5 px-4 py-4 hover:bg-white/10 transition-colors group"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-500/15 text-xl">🔵</span>
            <div className="flex-1">
              <p className="text-sm font-medium text-white group-hover:text-blue-300 transition-colors">
                Conectar Google Ads
              </p>
              <p className="text-xs text-zinc-400">Campañas de búsqueda, display y performance max</p>
            </div>
            <span className="text-zinc-500 group-hover:text-white transition-colors">→</span>
          </a>
        )}

        {/* Meta Ads */}
        {!hasMeta && (
          <a
            href={`/api/ads/meta/auth?projectId=${projectId}`}
            className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/5 px-4 py-4 hover:bg-white/10 transition-colors group"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-500/15 text-xl">🟣</span>
            <div className="flex-1">
              <p className="text-sm font-medium text-white group-hover:text-purple-300 transition-colors">
                Conectar Meta Ads
              </p>
              <p className="text-xs text-zinc-400">Campañas en Facebook e Instagram</p>
            </div>
            <span className="text-zinc-500 group-hover:text-white transition-colors">→</span>
          </a>
        )}

        {hasGoogle && hasMeta && (
          <p className="text-sm text-emerald-400">✓ Todas las plataformas están conectadas</p>
        )}
      </div>

      {/* Info de seguridad */}
      <div className="rounded-lg bg-zinc-800/50 px-4 py-3">
        <p className="text-xs text-zinc-400">
          🔒 <strong className="text-zinc-300">Conexión segura.</strong>{' '}
          Tus credenciales se encriptan con AES-256 y nunca salen de nuestros servidores.
          Solo usamos acceso de lectura y creación de campañas — nunca facturación.
        </p>
      </div>

      {/* Opción de saltar */}
      {onSkip && (
        <div className="text-center">
          <button
            onClick={onSkip}
            className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors underline underline-offset-2"
          >
            Continuar sin conectar — generaré la estrategia igual
          </button>
          <p className="mt-1 text-xs text-zinc-600">
            Podrás conectar tus cuentas más adelante
          </p>
        </div>
      )}
    </div>
  )
}
