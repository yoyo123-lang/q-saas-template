import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma, Prisma } from '@qautiva/db'
import type { QuestionBlock } from '@/app/_lib/interview/types'
import { isAnswerEmpty } from '@/app/_lib/interview/merge-flow'
import { checkBillingEligibility } from '@/app/_lib/billing/check-eligibility'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

type AdvanceAction = 'start' | 'next' | 'back' | 'pause' | 'submit'

type AdvanceBody = {
  action: AdvanceAction
}

const VALID_ACTIONS: AdvanceAction[] = ['start', 'next', 'back', 'pause', 'submit']

/**
 * POST /api/interview/sessions/[id]/advance
 * Controla la navegación dentro de una InterviewSession.
 *
 * Acciones:
 * - start:  NOT_STARTED → IN_PROGRESS (primer paso)
 * - next:   avanza currentStep + 1
 * - back:   retrocede currentStep - 1
 * - pause:  IN_PROGRESS → PAUSED (el usuario se fue)
 * - submit: IN_PROGRESS → PROCESSING (validando respuestas requeridas primero)
 *
 * AL1: Para proteger contra concurrencia, el update incluye condiciones de estado
 * en el WHERE. Si el estado/step cambió entre el read y el write, Prisma lanza P2025
 * y se retorna 409 en lugar de aplicar la transición sobre un estado obsoleto.
 *
 * Body: { action }
 * Returns: { ok: true, session: { id, currentStep, totalSteps, status } }
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  // CRÍTICO-SEC: validar que params.id sea un UUID v4 antes de usarlo en queries
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  let body: AdvanceBody
  try {
    body = (await request.json()) as AdvanceBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  if (!body.action || !VALID_ACTIONS.includes(body.action)) {
    return NextResponse.json(
      { error: `Acción inválida. Debe ser una de: ${VALID_ACTIONS.join(', ')}` },
      { status: 400 },
    )
  }

  // Verificar ownership
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const session = await prisma.interviewSession.findFirst({
    where: {
      id: params.id,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: {
      id: true,
      currentStep: true,
      totalSteps: true,
      status: true,
      teamId: true,
      answers: true,
      flowDefinition: true,
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Fail-closed: verificar teamId antes de cualquier guard (non-nullable en schema, pero defensivo)
  if (!session.teamId) {
    console.error('[advance] session sin teamId — error de datos, bloqueando ejecución', {
      sessionId: params.id,
    })
    return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
  }

  // Guard de permisos: MEMBER solo tiene lectura
  const perm = await checkTeamPermission(user.id, session.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden realizar esta acción.' },
      { status: 403 },
    )
  }

  const { action } = body
  const flow = (session.flowDefinition ?? []) as QuestionBlock[]

  // updateData: campos a actualizar
  // whereExtra: condiciones adicionales para el WHERE del update (AL1: protección concurrencia)
  let updateData: Record<string, unknown> = {}
  let whereExtra: Record<string, unknown> = {}

  if (action === 'start') {
    if (session.status !== 'NOT_STARTED') {
      return NextResponse.json({ error: 'La sesión ya fue iniciada' }, { status: 409 })
    }
    updateData = { status: 'IN_PROGRESS', startedAt: new Date() }
    whereExtra = { status: 'NOT_STARTED' }
  } else if (action === 'next') {
    if (!['IN_PROGRESS', 'PAUSED'].includes(session.status)) {
      return NextResponse.json(
        { error: 'No se puede avanzar en el estado actual de la sesión' },
        { status: 409 },
      )
    }
    if (session.currentStep >= session.totalSteps - 1) {
      return NextResponse.json({ error: 'Ya estás en el último paso' }, { status: 409 })
    }
    updateData = { currentStep: session.currentStep + 1, status: 'IN_PROGRESS' }
    whereExtra = { currentStep: session.currentStep }
  } else if (action === 'back') {
    if (!['IN_PROGRESS', 'PAUSED'].includes(session.status)) {
      return NextResponse.json(
        { error: 'No se puede retroceder en el estado actual de la sesión' },
        { status: 409 },
      )
    }
    if (session.currentStep <= 0) {
      return NextResponse.json({ error: 'Ya estás en el primer paso' }, { status: 409 })
    }
    // ME5: al retroceder, volver a IN_PROGRESS si estaba pausado
    updateData = { currentStep: session.currentStep - 1, status: 'IN_PROGRESS' }
    whereExtra = { currentStep: session.currentStep }
  } else if (action === 'pause') {
    // ME4: solo se puede pausar desde IN_PROGRESS (no desde NOT_STARTED)
    if (session.status !== 'IN_PROGRESS') {
      return NextResponse.json(
        { error: 'No se puede pausar en el estado actual de la sesión' },
        { status: 409 },
      )
    }
    updateData = { status: 'PAUSED' }
    whereExtra = { status: 'IN_PROGRESS' }
  } else if (action === 'submit') {
    if (session.status !== 'IN_PROGRESS') {
      return NextResponse.json(
        { error: 'No se puede enviar en el estado actual de la sesión' },
        { status: 409 },
      )
    }

    // Validar que todas las preguntas obligatorias tienen respuesta no vacía.
    // AL3: semántica opt-out — una pregunta ES requerida a menos que tenga
    // validation.required === false explícito o skippable === true.
    // CRÍTICO-QA: verificar también que la respuesta no sea vacía (string "", array [])
    // para que PATCH /answer no pueda "marcar como respondida" una pregunta con valor vacío.
    const answers = (session.answers ?? {}) as Record<string, unknown>
    const missingRequired = flow
      .filter((q) => {
        const isRequired = q.validation?.required !== false && !q.skippable
        const hasAnswer = q.id in answers && !isAnswerEmpty(answers[q.id])
        return isRequired && !hasAnswer
      })
      .map((q) => q.id)

    if (missingRequired.length > 0) {
      return NextResponse.json(
        {
          error: 'Hay preguntas obligatorias sin responder',
          code: 'MISSING_REQUIRED_ANSWERS',
          missingQuestions: missingRequired,
        },
        { status: 422 },
      )
    }

    // Guard de billing: verificar elegibilidad ANTES de transicionar a PROCESSING.
    // Fail-closed: si falta teamId o falla la consulta, se bloquea el submit.
    if (!session.teamId) {
      console.error('[advance/submit] session sin teamId — error de datos, bloqueando submit', {
        sessionId: params.id,
      })
      return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
    }
    try {
      const billing = await checkBillingEligibility(session.teamId)
      if (!billing.eligible) {
        return NextResponse.json(
          {
            error: billing.reason ?? 'Tu plan no tiene saldo suficiente para continuar.',
            action: 'Ir a Configuración > Facturación para recargar o actualizar tu plan.',
          },
          { status: 402 },
        )
      }
    } catch (err) {
      console.error('[advance/submit] billing check failed — bloqueando submit por seguridad', {
        sessionId: params.id,
        teamId: session.teamId,
        err,
      })
      return NextResponse.json(
        { error: 'No se pudo verificar tu cuenta de facturación. Intentá de nuevo en unos segundos. Si el problema persiste, contactá a soporte.' },
        { status: 503 },
      )
    }

    updateData = { status: 'PROCESSING' }
    whereExtra = { status: 'IN_PROGRESS' }
  }

  let updated
  try {
    // AL1: WHERE incluye condiciones de estado/step para proteger contra concurrencia.
    // Si el estado cambió entre el read de arriba y este write, Prisma lanza P2025.
    updated = await prisma.interviewSession.update({
      where: { id: params.id, ...whereExtra },
      data: updateData,
      select: {
        id: true,
        currentStep: true,
        totalSteps: true,
        status: true,
        startedAt: true,
        processingStartedAt: true,
      },
    })
  } catch (err) {
    // Concurrencia detectada: el estado/step cambió entre nuestro read y el write
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2025') {
      return NextResponse.json(
        {
          error: 'La sesión fue modificada en otra pestaña. Por favor recargá la página.',
          code: 'CONCURRENT_MODIFICATION',
        },
        { status: 409 },
      )
    }

    console.error('[interview/sessions/advance] update failed', {
      sessionId: params.id,
      action,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al actualizar la sesión' }, { status: 500 })
  }

  return NextResponse.json({ ok: true, session: updated })
}
