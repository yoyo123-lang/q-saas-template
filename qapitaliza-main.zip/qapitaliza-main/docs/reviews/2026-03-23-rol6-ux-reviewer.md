# Informe de Revisión — ROL 6: UX Reviewer
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol 6 - UX Reviewer

---

## Resumen ejecutivo

La experiencia de usuario en las páginas públicas es sólida — el catálogo tiene filtros claros, los estados vacío y error están cubiertos, y la jerarquía visual es consistente. Se detectaron dos issues funcionales que degradaban la experiencia.

---

## Hallazgos

### [CRÍTICO → CORREGIDO] Botón de favorito no tenía feedback útil sin sesión

**Archivo:** `src/components/listings/listing-card.tsx`

**Problema original:** Al hacer click en el botón de favorito sin sesión (cuando no hay `onFavoriteToggle`), no ocurría nada visible para el usuario. No había feedback, ni mensaje, ni redirección. El usuario quedaba confundido.

**Fix aplicado:** Renderizado condicional:
- Con handler: `<button onClick={() => onFavoriteToggle(id)}>` — funcional
- Sin handler: `<Link href="/login">` — redirige al login con feedback implícito de que es necesario iniciar sesión

El botón mantiene el mismo estilo visual en ambos casos.

---

### [ALTO → CORREGIDO] Price filter inputs navegaban en cada keystroke

**Archivo:** `src/components/listings/filter-sidebar.tsx`

**Problema original:** Escribir "1000" en el input de precio mínimo disparaba 4 navegaciones (`router.push`) — una por cada carácter. Esto causaba parpadeos de la página, estados inconsistentes y una experiencia muy degradada.

**Fix aplicado:** Patrón de estado local + `onBlur`:
1. `onChange` solo actualiza estado local (`localPriceMin`, `localPriceMax`) — sin navegación.
2. `onBlur` dispara `router.push()` — navegación solo al salir del campo.
3. El botón "Limpiar filtros" resetea el estado local además de la URL.

---

### [MEDIO] Botón hamburguesa en Navbar — aria

**Archivo:** `src/components/layout/navbar.tsx`

**Estado:** Aceptable. El botón tiene `aria-label` que cambia entre "Abrir menú" y "Cerrar menú" según el estado. La implementación cubre el requisito de accesibilidad básica.

---

## Puntos positivos

- Estados vacío y error cubiertos en el catálogo.
- Breadcrumb en página de detalle para orientación contextual.
- Badges claros (Verificado, Destacado) con colores semánticos.
- Botones con estados `hover` y `transition-colors` consistentes.
- Skeleton states implícitos via SSR (no hay flash de contenido vacío).
- Texto en español argentino con voseo correcto.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| Favorito sin feedback sin sesión | CRÍTICO | Corregido |
| Price filter navega en keystroke | ALTO | Corregido |
| Hamburguesa aria-expanded | MEDIO | Aceptable (sin cambio) |
