import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'

const STUCK_THRESHOLD_MINUTES = 6

/**
 * GET /api/cron/recover-stuck-stitch-jobs
 *
 * Cron periódico: detecta jobs Stitch atascados en GENERATING y los resetea a QUEUED.
 * Un job se considera atascado si lleva más de STUCK_THRESHOLD_MINUTES en GENERATING.
 * Esto ocurre cuando waitUntil() se corta (timeout de Vercel, deploy de nueva versión,
 * corte de red) sin que runQueueGeneration pueda actualizar el estado.
 *
 * Configurar en vercel.json:
 * { "path": "/api/cron/recover-stuck-stitch-jobs", "schedule": "* /10 * * * *" }
 * (cada 10 minutos)
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env['CRON_SECRET']

  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const stuckBefore = new Date(Date.now() - STUCK_THRESHOLD_MINUTES * 60 * 1000)

  try {
    const result = await prisma.webTemplate.updateMany({
      where: {
        queueStatus: 'GENERATING',
        generatingAt: { lt: stuckBefore },
      },
      data: {
        queueStatus: 'QUEUED',
        generatingAt: null,
        stitchAccountId: null,
      },
    })

    console.info(`[cron:recover-stuck-stitch-jobs] Recuperados ${result.count} jobs atascados`)

    return NextResponse.json({ recovered: result.count, timestamp: new Date().toISOString() })
  } catch (err) {
    console.error('[cron:recover-stuck-stitch-jobs] Error:', err)
    return NextResponse.json({ error: 'Error al recuperar jobs' }, { status: 500 })
  }
}
