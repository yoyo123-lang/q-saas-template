import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// Mock fetch para reCAPTCHA y Telegram
const mockFetch = vi.fn()
vi.stubGlobal('fetch', mockFetch)

// Usar ambiente de dev para saltear reCAPTCHA por defecto
vi.stubEnv('NODE_ENV', 'development')
vi.stubEnv('TELEGRAM_BOT_TOKEN', '')
vi.stubEnv('TELEGRAM_CHAT_ID', '')

function makeRequest(body: unknown, origin = 'http://localhost:3000'): NextRequest {
  return new NextRequest('http://localhost:3000/api/contact', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      origin,
    },
    body: JSON.stringify(body),
  })
}

describe('POST /api/contact', () => {
  beforeEach(async () => {
    mockFetch.mockReset()
    // Resetear el módulo para limpiar el rate limiter in-memory entre tests
    vi.resetModules()
  })

  it('happy path — devuelve 200 con datos válidos', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ success: true, score: 0.9, action: 'contact' }),
    })

    const { POST } = await import('../../app/api/contact/route')
    const req = makeRequest({ name: 'Ana García', email: 'ana@test.com', business: 'Mi negocio', recaptchaToken: 'token123' })
    const res = await POST(req)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data).toEqual({ ok: true })
  })

  it('rechaza con 403 si el origin no está permitido', async () => {
    const { POST } = await import('../../app/api/contact/route')
    const req = makeRequest(
      { name: 'Test', email: 'a@b.com', business: 'test', recaptchaToken: 'tok' },
      'https://evil.com'
    )
    const res = await POST(req)
    expect(res.status).toBe(403)
  })

  it('rechaza con 400 si faltan campos', async () => {
    const { POST } = await import('../../app/api/contact/route')
    const req = makeRequest({ name: 'Ana', email: 'ana@test.com' }) // falta business y token
    const res = await POST(req)
    expect(res.status).toBe(400)
  })

  it('rechaza con 400 si el email es inválido', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ success: true, score: 0.9, action: 'contact' }),
    })

    const { POST } = await import('../../app/api/contact/route')
    const req = makeRequest({ name: 'Ana', email: 'no-es-email', business: 'test', recaptchaToken: 'tok' })
    const res = await POST(req)
    expect(res.status).toBe(400)
    const data = await res.json() as { error: string }
    expect(data.error).toMatch(/email/i)
  })

  it('rechaza con 400 si el nombre queda vacío tras sanitización', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ success: true, score: 0.9, action: 'contact' }),
    })

    const { POST } = await import('../../app/api/contact/route')
    // Nombre con solo símbolos que se eliminan con la sanitización
    const req = makeRequest({ name: '!!!###$$$', email: 'ana@test.com', business: 'test', recaptchaToken: 'tok' })
    const res = await POST(req)
    expect(res.status).toBe(400)
    const data = await res.json() as { error: string }
    expect(data.error).toMatch(/nombre/i)
  })

  it('rechaza con 429 al superar el rate limit', async () => {
    mockFetch.mockResolvedValue({
      ok: true,
      json: async () => ({ success: true, score: 0.9, action: 'contact' }),
    })

    const { POST } = await import('../../app/api/contact/route')
    const validBody = { name: 'Ana García', email: 'ana@test.com', business: 'Mi negocio', recaptchaToken: 'tok' }

    // Hacer 5 requests (límite) desde el mismo IP
    for (let i = 0; i < 5; i++) {
      const req = new NextRequest('http://localhost:3000/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', origin: 'http://localhost:3000', 'x-forwarded-for': '1.2.3.4' },
        body: JSON.stringify(validBody),
      })
      await POST(req)
    }

    // La 6ta debe ser rechazada
    const req = new NextRequest('http://localhost:3000/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', origin: 'http://localhost:3000', 'x-forwarded-for': '1.2.3.4' },
      body: JSON.stringify(validBody),
    })
    const res = await POST(req)
    expect(res.status).toBe(429)
  })
})
