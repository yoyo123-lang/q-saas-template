# Informe de Revisión — ROL B: Data/Analytics Reviewer
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol B - Data/Analytics Reviewer

---

## Resumen ejecutivo

La instrumentación de eventos de negocio para las páginas públicas era incompleta. El evento `listing_viewed` del funnel de conversión no se registraba en el AuditLog — solo se incrementaba un contador numérico sin contexto analítico. Fix aplicado.

---

## Hallazgos

### [ALTO → CORREGIDO] El evento `listing_viewed` no escribía en AuditLog

**Archivo:** `src/lib/data/listings.ts`

**Problema original:** `incrementListingViews` solo hacía `UPDATE listing SET viewCount = viewCount + 1`. El BUSINESS_MODEL.md lista `listing_viewed` como evento de prioridad Media en el funnel. Sin AuditLog, es imposible:
- Reconstruir el historial de vistas por listing
- Analizar patrones de comportamiento (qué listings se ven más, en qué horarios)
- Correlacionar vistas con conversiones a inquiries
- Detectar picos anómalos de tráfico

**Fix aplicado:** `incrementListingViews` ahora ejecuta dos operaciones en paralelo:

```typescript
await Promise.all([
  prisma.listing.update({
    where: { id },
    data: { viewCount: { increment: 1 } },
  }),
  prisma.auditLog.create({
    data: {
      action: 'LISTING_VIEWED',
      entityType: 'listing',
      entityId: id,
      actorId: null,  // null para visitas sin sesión
    },
  }),
])
```

- `actorId: null` para visitas sin sesión — correcto para usuario anónimo.
- Cuando exista autenticación, se puede pasar el `userId` del session token.
- El AuditLog preserva el timestamp exacto de cada vista para análisis temporal.

---

## Puntos positivos

- El contador `viewCount` en el modelo `Listing` permite queries rápidas de ranking sin agregar AuditLog.
- El AuditLog permite análisis granular histórico que el contador no puede proveer.
- La combinación contador + AuditLog es el patrón correcto para métricas de alto volumen.
- La deduplicación por cookie (Rol A) evita inflar el AuditLog con refreshes del mismo usuario.

---

## Eventos pendientes de implementar

Los siguientes eventos del funnel del BUSINESS_MODEL.md no están instrumentados aún — son responsabilidad de etapas futuras:

| Evento | Prioridad | Etapa |
|---|---|---|
| `listing_contact_click` | Alta | Etapa 3 (Inquiries) |
| `listing_favorite_added` | Media | Etapa 3 (Favoritos) |
| `user_registered` | Alta | Etapa 3 (Auth) |
| `inquiry_created` | Alta | Etapa 3 (Inquiries) |
| `listing_published` | Alta | Etapa 4 (Dashboard) |

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| listing_viewed no registra en AuditLog | ALTO | Corregido |
