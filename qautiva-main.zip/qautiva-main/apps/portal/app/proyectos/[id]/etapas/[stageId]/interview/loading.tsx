export default function InterviewLoading() {
  return (
    <div className="min-h-screen bg-[#0B0F1A] flex items-center justify-center p-6">
      <div className="w-full max-w-xl animate-pulse">
        {/* Progress bar */}
        <div className="mb-8">
          <div className="h-1 w-full bg-[#1E293B] rounded-full" />
        </div>
        {/* Question card skeleton */}
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 mb-6">
          <div className="h-3 w-20 bg-[#1E293B] rounded mb-3" />
          <div className="h-6 w-full bg-[#1E293B] rounded mb-2" />
          <div className="h-6 w-3/4 bg-[#1E293B] rounded mb-6" />
          <div className="h-12 w-full bg-[#1E293B] rounded-lg" />
        </div>
        {/* Nav buttons */}
        <div className="flex justify-between">
          <div className="h-10 w-24 bg-[#1E293B] rounded-lg" />
          <div className="h-10 w-24 bg-[#1E293B] rounded-lg" />
        </div>
      </div>
    </div>
  )
}
