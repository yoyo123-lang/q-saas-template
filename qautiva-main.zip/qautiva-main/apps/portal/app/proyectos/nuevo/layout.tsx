import type { Metadata } from 'next'
import { headers } from 'next/headers'
import Image from 'next/image'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Nuevo proyecto | Qautiva',
}

const STEPS = [
  { number: 1, label: 'Tu negocio' },
  { number: 2, label: 'Servicios' },
]

function getCurrentStep(pathname: string): number {
  if (pathname.includes('/servicios')) return 2
  return 1
}

export default function NuevoProyectoLayout({ children }: { children: React.ReactNode }) {
  const headersList = headers()
  const pathname = headersList.get('x-pathname') ?? headersList.get('x-invoke-path') ?? ''
  const currentStep = getCurrentStep(pathname)

  return (
    <div className="min-h-screen bg-[#0B0F1A] flex flex-col">
      <header className="border-b border-[#1E293B] px-6 py-4">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <Link href="/proyectos">
            <Image src="/logo.png" alt="Qautiva" width={64} height={64} priority />
          </Link>

          <div className="flex items-center gap-1">
            {STEPS.map((step, i) => {
              const isCompleted = step.number < currentStep
              const isActive = step.number === currentStep
              return (
                <div key={step.number} className="flex items-center gap-1">
                  <div className="flex flex-col items-center">
                    <div
                      className={[
                        'w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium transition-colors',
                        isCompleted
                          ? 'bg-[#8B5CF6] text-white'
                          : isActive
                            ? 'bg-[#8B5CF6]/20 border border-[#8B5CF6] text-[#A78BFA]'
                            : 'bg-[#1E293B] text-[#64748B]',
                      ].join(' ')}
                    >
                      {isCompleted ? '✓' : step.number}
                    </div>
                    <span className={`text-[10px] mt-0.5 hidden sm:block ${isActive ? 'text-[#A78BFA]' : 'text-[#64748B]'}`}>
                      {step.label}
                    </span>
                  </div>
                  {i < STEPS.length - 1 && (
                    <div
                      className={`w-8 h-px mb-4 ${step.number < currentStep ? 'bg-[#8B5CF6]' : 'bg-[#1E293B]'}`}
                    />
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-8">
        {children}
      </main>
    </div>
  )
}
