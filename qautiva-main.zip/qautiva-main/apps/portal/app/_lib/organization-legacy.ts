import type { Prisma } from '@qautiva/db'

/**
 * Crea una Organization legacy para compatibilidad con el panel de admin (Fase A).
 * El admin usa Organization hasta la migración a Project en Fase B/C.
 * Vincula los stages del proyecto a la Organization creada.
 * Retorna la Organization creada.
 */
export async function createOrganizationLegacy(
  tx: Prisma.TransactionClient,
  project: { id: string; name: string; slug: string; industry: string },
): Promise<{ id: string }> {
  const org = await tx.organization.create({
    data: {
      name: project.name,
      slug: project.slug,
      industry: project.industry,
      status: 'DISCOVERY',
      plan: 'BASE',
    },
  })

  await tx.stage.updateMany({
    where: { projectId: project.id },
    data: { organizationId: org.id },
  })

  return org
}
