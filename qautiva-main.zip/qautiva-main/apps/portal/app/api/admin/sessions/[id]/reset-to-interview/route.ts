import { NextResponse, type NextRequest } from 'next/server'
import { prisma, createServiceClient } from '@qautiva/db'

/**
 * POST /api/admin/sessions/[id]/reset-to-interview
 *
 * Retrocede una sesión en estado PROCESSING o ERROR a IN_PROGRESS,
 * para que el usuario pueda volver a hacer la entrevista.
 *
 * - Conserva answers y currentStep (el usuario retoma donde quedó)
 * - Limpia lastError, processingStartedAt, retryCount
 * - Guarda snapshot en resetHistory para auditoría
 *
 * Autenticación: Bearer token de Supabase de un usuario con rol ADMIN.
 */
export async function POST(
  _request: NextRequest,
  { params }: { params: { id: string } },
) {
  const authHeader = _request.headers.get('authorization')
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null
  if (!token) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const supabaseAdmin = createServiceClient()
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(token)
  if (error || !user || user.app_metadata?.['role'] !== 'ADMIN') {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  const session = await prisma.interviewSession.findFirst({
    where: { id: params.id, project: { deletedAt: null } },
    select: {
      id: true,
      status: true,
      answers: true,
      lastError: true,
      retryCount: true,
      resetHistory: true,
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  if (session.status !== 'PROCESSING' && session.status !== 'ERROR') {
    return NextResponse.json(
      { error: `Estado inválido para resetear: ${session.status}` },
      { status: 409 },
    )
  }

  // Guardar snapshot en resetHistory para auditoría
  const prevHistory = Array.isArray(session.resetHistory) ? session.resetHistory : []
  const resetEntry = {
    answers: session.answers,
    status: session.status,
    lastError: session.lastError,
    retryCount: session.retryCount,
    resetBy: user.id,
    reason: 'admin:reset-to-interview',
    timestamp: new Date().toISOString(),
  }

  await prisma.interviewSession.update({
    where: { id: params.id },
    data: {
      status: 'IN_PROGRESS',
      lastError: null,
      processingStartedAt: null,
      retryCount: 0,
      resetHistory: [...prevHistory, resetEntry],
    },
  })

  console.info('[admin/sessions/reset-to-interview] reset', {
    sessionId: params.id,
    adminUserId: user.id,
    previousStatus: session.status,
  })

  return NextResponse.json({ ok: true })
}
