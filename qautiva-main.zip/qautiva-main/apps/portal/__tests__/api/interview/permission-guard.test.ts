/**
 * Tests de integración: permission guard en endpoints de escritura.
 *
 * Verifica que:
 * - MEMBER recibe 403 al intentar operaciones de escritura (solo ADMIN/OWNER)
 * - ADMIN recibe la respuesta esperada (202/200) al intentar operaciones de escritura
 * - OWNER recibe la respuesta esperada (202/200) al intentar operaciones de escritura
 * - Endpoints cubiertos: process, advance (submit), answer (PATCH), projects POST (step 1)
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// ── Mocks ──────────────────────────────────────────────────────────────────────

const {
  mockGetUser,
  mockGetUserTeamIds,
  mockCheckBillingEligibility,
  mockInterviewSessionFindFirst,
  mockInterviewSessionUpdateMany,
  mockInterviewSessionUpdate,
  mockUserProfileFindUnique,
  mockProjectCreate,
  mockProjectFindUnique,
} = vi.hoisted(() => ({
  mockGetUser: vi.fn(),
  mockGetUserTeamIds: vi.fn(),
  mockCheckBillingEligibility: vi.fn(),
  mockInterviewSessionFindFirst: vi.fn(),
  mockInterviewSessionUpdateMany: vi.fn(),
  mockInterviewSessionUpdate: vi.fn(),
  mockUserProfileFindUnique: vi.fn(),
  mockProjectCreate: vi.fn(),
  mockProjectFindUnique: vi.fn(),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('@/app/_lib/interview/get-user-team-ids', () => ({
  getUserTeamIds: mockGetUserTeamIds,
}))

vi.mock('@/app/_lib/billing/check-eligibility', () => ({
  checkBillingEligibility: mockCheckBillingEligibility,
}))

vi.mock('@vercel/functions', () => ({
  waitUntil: vi.fn(),
}))

vi.mock('@/app/_lib/interview/session-processor', () => ({
  processSession: vi.fn().mockResolvedValue(undefined),
}))

vi.mock('@/app/_lib/interview/merge-flow', () => ({
  isAnswerEmpty: (v: unknown) => {
    if (v === null || v === undefined) return true
    if (typeof v === 'string') return v.trim().length === 0
    if (Array.isArray(v)) return v.length === 0
    return false
  },
  mergeFlowDefinition: vi.fn().mockReturnValue([]),
  hashFlowDefinition: vi.fn().mockReturnValue('hash-1'),
  getAgentNumberForStage: vi.fn().mockReturnValue(1),
}))

vi.mock('@/app/_lib/interview/template-personalization', () => ({
  buildTemplatePersonalizationQuestions: vi.fn().mockReturnValue([]),
  hasTemplatePersonalizationQuestions: vi.fn().mockReturnValue(false),
}))

vi.mock('@/app/_lib/project-slug', () => ({
  buildSlug: vi.fn().mockReturnValue('mi-empresa'),
}))

vi.mock('@/app/_lib/service-stages', () => ({
  CORE_STAGES: [],
  SERVICE_STAGES: {},
  VALID_SERVICES: ['WEB'],
}))

vi.mock('@/app/_lib/organization-legacy', () => ({
  createOrganizationLegacy: vi.fn().mockResolvedValue(undefined),
}))

vi.mock('@/app/onboarding/_constants/industries', () => ({
  INDUSTRIES: ['TECNOLOGIA', 'RETAIL'],
}))

vi.mock('next/cache', () => ({
  revalidatePath: vi.fn(),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    interviewSession: {
      findFirst: mockInterviewSessionFindFirst,
      updateMany: mockInterviewSessionUpdateMany,
      update: mockInterviewSessionUpdate,
    },
    userProfile: { findUnique: mockUserProfileFindUnique },
    project: {
      create: mockProjectCreate,
      findUnique: mockProjectFindUnique,
    },
  },
  Prisma: {
    PrismaClientKnownRequestError: class PrismaClientKnownRequestError extends Error {
      code: string
      constructor(message: string, { code }: { code: string }) {
        super(message)
        this.code = code
      }
    },
  },
}))

// ── Imports ────────────────────────────────────────────────────────────────────

import { POST as processPost } from '@/app/api/interview/sessions/[id]/process/route'
import { POST as advancePost } from '@/app/api/interview/sessions/[id]/advance/route'
import { PATCH as answerPatch } from '@/app/api/interview/sessions/[id]/answer/route'
import { POST as projectsPost } from '@/app/api/projects/route'

// ── Constantes ─────────────────────────────────────────────────────────────────

const SESSION_UUID = '00000000-0000-4000-a000-000000000001'
const USER_ID = 'user-auth-id'
const TEAM_ID = 'team-1'

const mockUser = {
  id: USER_ID,
  app_metadata: { onboarding_complete: true },
}

const mockSession = {
  id: SESSION_UUID,
  status: 'PROCESSING',
  retryCount: 0,
  maxRetries: 3,
  processingStartedAt: null,
  flowDefinition: [],
  answers: {},
  stageId: 'stage-1',
  projectId: 'proj-1',
  teamId: TEAM_ID,
  selectedWebTemplateId: null,
  stage: { stageKey: 'WEBSITE' },
  project: { brandKit: null },
}

const routeParams = { params: { id: SESSION_UUID } }

function makeProcessRequest() {
  return new NextRequest(
    `http://localhost:3001/api/interview/sessions/${SESSION_UUID}/process`,
    { method: 'POST' },
  )
}

function makeProjectsRequest(body: Record<string, unknown>) {
  return new NextRequest('http://localhost:3001/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

/** Configura el mock de userProfile.findUnique para devolver el rol indicado. */
function mockPermission(role: 'OWNER' | 'ADMIN' | 'MEMBER') {
  mockUserProfileFindUnique.mockResolvedValueOnce({
    teamMemberships: [{ role }],
  })
}

/** Configura billing como elegible (para no bloquear en el billing guard). */
function mockBillingEligible() {
  mockCheckBillingEligibility.mockResolvedValueOnce({
    eligible: true,
    billingPlan: 'FREE_TRIAL',
    source: 'TRIAL',
  })
}

// ── Tests: POST /api/interview/sessions/[id]/process — permission guard ────────

describe('POST /api/interview/sessions/[id]/process — permission guard', () => {
  beforeEach(() => {
    mockGetUser.mockReset()
    mockGetUserTeamIds.mockReset()
    mockCheckBillingEligibility.mockReset()
    mockInterviewSessionFindFirst.mockReset()
    mockInterviewSessionUpdateMany.mockReset()
    mockUserProfileFindUnique.mockReset()

    mockGetUser.mockResolvedValue({ data: { user: mockUser } })
    mockGetUserTeamIds.mockResolvedValue([TEAM_ID])
    mockInterviewSessionFindFirst.mockResolvedValue(mockSession)
  })

  it('MEMBER → 403 (sin permisos para disparar generaciones)', async () => {
    mockPermission('MEMBER')

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(403)
    const body = await res.json()
    expect(body.error).toMatch(/permisos insuficientes/i)
    // El billing check NO debe ejecutarse si el permiso falla
    expect(mockCheckBillingEligibility).not.toHaveBeenCalled()
  })

  it('ADMIN → 202 (puede disparar generaciones)', async () => {
    mockPermission('ADMIN')
    mockBillingEligible()
    mockInterviewSessionUpdateMany.mockResolvedValueOnce({ count: 1 })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(202)
  })

  it('OWNER → 202 (puede disparar generaciones)', async () => {
    mockPermission('OWNER')
    mockBillingEligible()
    mockInterviewSessionUpdateMany.mockResolvedValueOnce({ count: 1 })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(202)
  })

  it('MEMBER → 403 — el error message indica qué roles se requieren', async () => {
    mockPermission('MEMBER')

    const res = await processPost(makeProcessRequest(), routeParams)
    const body = await res.json()

    expect(body.error).toMatch(/admin.*owner|owner.*admin/i)
  })

  it('usuario sin membresía en el team → 403', async () => {
    // checkTeamPermission devuelve authorized=false, role=null
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [],
    })

    const res = await processPost(makeProcessRequest(), routeParams)

    expect(res.status).toBe(403)
    expect(mockCheckBillingEligibility).not.toHaveBeenCalled()
  })
})

// ── Tests: POST /api/projects (step 1) — permission guard ─────────────────────

describe('POST /api/projects (step 1) — permission guard', () => {
  const validStep1Body = {
    step: 1,
    name: 'Mi Empresa',
    industry: 'TECNOLOGIA',
  }

  beforeEach(() => {
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockProjectCreate.mockReset()

    mockGetUser.mockResolvedValue({ data: { user: mockUser } })
  })

  it('MEMBER → 403 (no puede crear proyectos)', async () => {
    // Primera llamada: buscar perfil para obtener teamId
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ team: { id: TEAM_ID } }],
    })
    // Segunda llamada: checkTeamPermission verifica el rol
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'MEMBER' }],
    })

    const res = await projectsPost(makeProjectsRequest(validStep1Body))

    expect(res.status).toBe(403)
    const body = await res.json()
    expect(body.error).toMatch(/permisos insuficientes/i)
    // El proyecto NO debe crearse
    expect(mockProjectCreate).not.toHaveBeenCalled()
  })

  it('ADMIN → 200 (puede crear proyectos)', async () => {
    // Primera llamada: perfil con team
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ team: { id: TEAM_ID } }],
    })
    // Segunda llamada: checkTeamPermission con rol ADMIN
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'ADMIN' }],
    })
    mockProjectCreate.mockResolvedValueOnce({ id: 'proj-new-1' })

    const res = await projectsPost(makeProjectsRequest(validStep1Body))

    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.projectId).toBe('proj-new-1')
  })

  it('OWNER → 200 (puede crear proyectos)', async () => {
    // Primera llamada: perfil con team
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ team: { id: TEAM_ID } }],
    })
    // Segunda llamada: checkTeamPermission con rol OWNER
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'OWNER' }],
    })
    mockProjectCreate.mockResolvedValueOnce({ id: 'proj-new-2' })

    const res = await projectsPost(makeProjectsRequest(validStep1Body))

    expect(res.status).toBe(200)
    expect(mockProjectCreate).toHaveBeenCalledOnce()
  })

  it('usuario sin membresía → 404 (sin team)', async () => {
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [],
    })

    const res = await projectsPost(makeProjectsRequest(validStep1Body))

    expect(res.status).toBe(404)
    expect(mockProjectCreate).not.toHaveBeenCalled()
  })

  it('MEMBER → 403 — mensaje indica qué roles se requieren', async () => {
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ team: { id: TEAM_ID } }],
    })
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'MEMBER' }],
    })

    const res = await projectsPost(makeProjectsRequest(validStep1Body))
    const body = await res.json()

    expect(body.error).toMatch(/admin.*owner|owner.*admin/i)
  })
})

// ── Tests: POST /api/interview/sessions/[id]/advance (submit) — permission guard ─

describe('POST /api/interview/sessions/[id]/advance (submit) — permission guard', () => {
  const mockSessionForAdvance = {
    id: SESSION_UUID,
    teamId: TEAM_ID,
    currentStep: 1,
    totalSteps: 3,
    status: 'IN_PROGRESS',
    answers: { q1: 'respuesta 1' },
    flowDefinition: [{ id: 'q1', skippable: true }],
  }

  function makeAdvanceRequest(action: string) {
    return new NextRequest(
      `http://localhost:3001/api/interview/sessions/${SESSION_UUID}/advance`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      },
    )
  }

  beforeEach(() => {
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockCheckBillingEligibility.mockReset()
    mockInterviewSessionFindFirst.mockReset()
    mockInterviewSessionUpdate.mockReset()

    mockGetUser.mockResolvedValue({ data: { user: { id: USER_ID } } })
    // Objeto combinado: satisface ownership check (teamId) y checkTeamPermission (role) por defecto
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'ADMIN' }],
    })
    mockInterviewSessionFindFirst.mockResolvedValue(mockSessionForAdvance)
  })

  it('MEMBER → 403 al intentar submit', async () => {
    // Primera llamada: ownership (teamId), segunda: permission (role)
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ teamId: TEAM_ID }],
    })
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'MEMBER' }],
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(403)
    expect(mockCheckBillingEligibility).not.toHaveBeenCalled()
  })

  it('ADMIN → 200 al hacer submit', async () => {
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: true,
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })
    mockInterviewSessionUpdate.mockResolvedValueOnce({
      id: SESSION_UUID,
      currentStep: 1,
      totalSteps: 3,
      status: 'PROCESSING',
      startedAt: null,
      processingStartedAt: null,
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(200)
  })

  it('OWNER → 200 al hacer submit', async () => {
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ teamId: TEAM_ID }],
    })
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'OWNER' }],
    })
    mockCheckBillingEligibility.mockResolvedValueOnce({
      eligible: true,
      billingPlan: 'FREE_TRIAL',
      source: 'TRIAL',
    })
    mockInterviewSessionUpdate.mockResolvedValueOnce({
      id: SESSION_UUID,
      currentStep: 1,
      totalSteps: 3,
      status: 'PROCESSING',
      startedAt: null,
      processingStartedAt: null,
    })

    const res = await advancePost(makeAdvanceRequest('submit'), routeParams)

    expect(res.status).toBe(200)
  })
})

// ── Tests: PATCH /api/interview/sessions/[id]/answer — permission guard ──────────

describe('PATCH /api/interview/sessions/[id]/answer — permission guard', () => {
  const mockSessionForAnswer = {
    id: SESSION_UUID,
    teamId: TEAM_ID,
    answers: {},
    answersVersion: 0,
    answerHistory: [],
    flowDefinition: [],
    status: 'IN_PROGRESS',
    startedAt: new Date(),
    importedData: null,
    projectId: 'proj-1',
  }

  function makeAnswerRequest() {
    return new NextRequest(
      `http://localhost:3001/api/interview/sessions/${SESSION_UUID}/answer`,
      {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ questionId: 'q1', answer: 'mi respuesta', answersVersion: 0 }),
      },
    )
  }

  beforeEach(() => {
    mockGetUser.mockReset()
    mockUserProfileFindUnique.mockReset()
    mockInterviewSessionFindFirst.mockReset()
    mockInterviewSessionUpdate.mockReset()

    mockGetUser.mockResolvedValue({ data: { user: { id: USER_ID } } })
    // Objeto combinado: satisface ownership check (teamId) y checkTeamPermission (role) por defecto
    mockUserProfileFindUnique.mockResolvedValue({
      teamMemberships: [{ teamId: TEAM_ID, role: 'ADMIN' }],
    })
    mockInterviewSessionFindFirst.mockResolvedValue(mockSessionForAnswer)
  })

  it('MEMBER → 403 al intentar guardar respuesta', async () => {
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ teamId: TEAM_ID }],
    })
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'MEMBER' }],
    })

    const res = await answerPatch(makeAnswerRequest(), routeParams)

    expect(res.status).toBe(403)
    expect(mockInterviewSessionUpdate).not.toHaveBeenCalled()
  })

  it('ADMIN → 200 al guardar respuesta', async () => {
    mockInterviewSessionUpdate.mockResolvedValueOnce({
      id: SESSION_UUID,
      answers: { q1: 'mi respuesta' },
      answersVersion: 1,
      currentStep: 0,
      status: 'IN_PROGRESS',
    })

    const res = await answerPatch(makeAnswerRequest(), routeParams)

    expect(res.status).toBe(200)
  })

  it('OWNER → 200 al guardar respuesta', async () => {
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ teamId: TEAM_ID }],
    })
    mockUserProfileFindUnique.mockResolvedValueOnce({
      teamMemberships: [{ role: 'OWNER' }],
    })
    mockInterviewSessionUpdate.mockResolvedValueOnce({
      id: SESSION_UUID,
      answers: { q1: 'mi respuesta' },
      answersVersion: 1,
      currentStep: 0,
      status: 'IN_PROGRESS',
    })

    const res = await answerPatch(makeAnswerRequest(), routeParams)

    expect(res.status).toBe(200)
  })
})
