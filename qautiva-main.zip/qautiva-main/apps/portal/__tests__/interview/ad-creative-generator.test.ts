import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { AdCreatives } from '../../app/_lib/interview/types'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const { mockCreate } = vi.hoisted(() => ({ mockCreate: vi.fn() }))

vi.mock('@qautiva/db', () => ({
  prisma: {
    trialConfig: {
      findUnique: vi.fn().mockResolvedValue({
        qautivaProvider: 'ANTHROPIC',
        qautivaModel: 'claude-opus-4-6',
      }),
    },
  },
}))

vi.mock('@anthropic-ai/sdk', () => ({
  default: vi.fn().mockImplementation(() => ({
    messages: { create: mockCreate },
  })),
}))

// ── Fixtures ──────────────────────────────────────────────────────────────────

const makeVariant = (headline: string, description: string) => ({
  headline,
  description,
  callToAction: 'Probá gratis',
  angle: 'Ahorro de tiempo',
})

const mockCreatives: AdCreatives = {
  googleAds: {
    search: [
      makeVariant('Software para tu restau', 'Administrá tu restaurante sin esfuerzo. Probá 30 días gratis.'),
      makeVariant('Gestión gastronómica', 'Reducí 2 horas de administración diaria. Sistema especializado.'),
    ],
  },
  metaAds: {
    feed: [
      makeVariant('¿Tu restaurante sigue en planillas?', 'Más de 50 restaurantes en CABA ya digitalizaron su gestión con nosotros. Es hora de sumarte.'),
      makeVariant('Ahorrá tiempo en tu local', 'El software que entiende a los gastronómicos. Probá gratis por 30 días sin tarjeta.'),
    ],
    story: [
      makeVariant('Tu restaurante merece más', 'Digitalizá hoy. Probá gratis.'),
      makeVariant('50 restaurantes ya lo usan', '¿El tuyo también? Probá sin costo.'),
    ],
  },
  guiaDeTono: {
    tono: 'Directo, sin tecnicismos, cercano al dueño del negocio',
    palabrasClave: ['restaurante', 'administración', 'tiempo'],
    evitar: ['tecnología de punta', 'solución integral', 'plataforma'],
  },
  disclaimer: 'Copy generado por IA. Revisá los límites antes de publicar.',
}

beforeEach(async () => {
  mockCreate.mockReset()
  const { invalidateAiConfigCache } = await import(
    '../../app/_lib/interview/ai-config'
  )
  invalidateAiConfigCache()
})

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('generateAdCreatives', () => {
  it('retorna las piezas cuando Claude llama generate_ad_creatives', async () => {
    const { generateAdCreatives } = await import(
      '../../app/_lib/interview/ad-creative-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: mockCreatives }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 100, output_tokens: 500 },
    })

    const result = await generateAdCreatives({
      flowDefinition: [],
      answers: {},
      project: { name: 'Mi Restaurante', industry: 'Gastronomía', country: 'Argentina' },
      previousDeliverables: [],
      connectedPlatforms: ['GOOGLE_ADS', 'META'],
    })

    expect(result.googleAds?.search).toHaveLength(2)
    expect(result.metaAds?.feed).toHaveLength(2)
    expect(result.metaAds?.story).toHaveLength(2)
  })

  it('pasa tool_choice: { type: tool, name: generate_ad_creatives }', async () => {
    const { generateAdCreatives } = await import(
      '../../app/_lib/interview/ad-creative-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: mockCreatives }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    await generateAdCreatives({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
      connectedPlatforms: [],
    })

    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        tool_choice: { type: 'tool', name: 'generate_ad_creatives' },
      }),
    )
  })

  it('pone a null googleAds si GOOGLE_ADS no está conectado', async () => {
    const { generateAdCreatives } = await import(
      '../../app/_lib/interview/ad-creative-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: mockCreatives }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    const result = await generateAdCreatives({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
      connectedPlatforms: ['META'], // Solo Meta conectado
    })

    expect(result.googleAds).toBeNull()
    expect(result.metaAds).not.toBeNull()
  })

  it('pone a null metaAds si META no está conectado', async () => {
    const { generateAdCreatives } = await import(
      '../../app/_lib/interview/ad-creative-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: mockCreatives }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    const result = await generateAdCreatives({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
      connectedPlatforms: ['GOOGLE_ADS'],
    })

    expect(result.metaAds).toBeNull()
    expect(result.googleAds).not.toBeNull()
  })

  it('trunca headlines que excedan el límite de Google Search (30 chars)', async () => {
    const { generateAdCreatives } = await import(
      '../../app/_lib/interview/ad-creative-generator'
    )

    const longHeadline = 'Este headline es demasiado largo para Google Search sin duda'
    expect(longHeadline.length).toBeGreaterThan(30)

    const creativesWithLong: AdCreatives = {
      ...mockCreatives,
      googleAds: {
        search: [
          makeVariant(longHeadline, 'Descripción válida'),
          makeVariant('Headline 2', 'Descripción 2'),
        ],
      },
    }

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: creativesWithLong }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    const result = await generateAdCreatives({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
      connectedPlatforms: ['GOOGLE_ADS'],
    })

    expect(result.googleAds!.search[0]!.headline.length).toBeLessThanOrEqual(30)
  })

  it('antepone el disclaimer mínimo garantizado', async () => {
    const { generateAdCreatives } = await import(
      '../../app/_lib/interview/ad-creative-generator'
    )

    const creativesWithMinimalDisclaimer = { ...mockCreatives, disclaimer: 'X.' }
    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: creativesWithMinimalDisclaimer }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    const result = await generateAdCreatives({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
      connectedPlatforms: [],
    })

    expect(result.disclaimer).toContain('generado por inteligencia artificial')
    expect(result.disclaimer).toContain('X.')
  })

  describe('validateAdCreatives — errores de validación', () => {
    it('lanza si googleAds.search tiene menos de 2 variantes', async () => {
      const { generateAdCreatives } = await import(
        '../../app/_lib/interview/ad-creative-generator'
      )

      const invalid = {
        ...mockCreatives,
        googleAds: { search: [makeVariant('Uno solo', 'Una descripcion')] },
      }
      mockCreate.mockResolvedValueOnce({
        content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: invalid }],
        stop_reason: 'tool_use',
        usage: { input_tokens: 10, output_tokens: 10 },
      })

      await expect(
        generateAdCreatives({ flowDefinition: [], answers: {}, project: { name: 'T', industry: null, country: null }, previousDeliverables: [], connectedPlatforms: [] }),
      ).rejects.toThrow('mínimo 2 variantes')
    })

    it('lanza si falta guiaDeTono', async () => {
      const { generateAdCreatives } = await import(
        '../../app/_lib/interview/ad-creative-generator'
      )

      const invalid = { ...mockCreatives, guiaDeTono: undefined }
      mockCreate.mockResolvedValueOnce({
        content: [{ type: 'tool_use', id: 'x', name: 'generate_ad_creatives', input: invalid }],
        stop_reason: 'tool_use',
        usage: { input_tokens: 10, output_tokens: 10 },
      })

      await expect(
        generateAdCreatives({ flowDefinition: [], answers: {}, project: { name: 'T', industry: null, country: null }, previousDeliverables: [], connectedPlatforms: [] }),
      ).rejects.toThrow('[ad-creative-generator] Falta guiaDeTono')
    })
  })
})
