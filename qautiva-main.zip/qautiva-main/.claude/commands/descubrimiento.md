# Descubrimiento de modelo de negocio

> Skill para descubrir y documentar el modelo de negocio de un proyecto existente.
> Invocar con: `/project:descubrimiento`
> Este es un proceso INTERACTIVO: Claude recorre el código, infiere lo que puede, y pregunta lo que no puede.

## Cuándo usar

- Al adoptar el template en un proyecto existente (ver `docs/ADOPCION_PROYECTOS_EXISTENTES.md`)
- Cuando se necesita actualizar `docs/BUSINESS_MODEL.md` después de cambios grandes
- Cuando se agregan roles de capa 2 (Business Logic, Data/Analytics) por primera vez

## Paso 1: Verificar contexto

Leé en silencio:
- `docs/BUSINESS_MODEL.md` — si ya existe, es una actualización, no un descubrimiento desde cero
- `docs/ARCHITECTURE.md` — para entender el stack y la estructura

Si `BUSINESS_MODEL.md` ya tiene contenido, avisale al usuario:

> Ya existe un BUSINESS_MODEL.md con contenido. ¿Querés que lo actualice con lo que encuentre en el código, o que empiece de cero?

## Paso 2: Recorrer el código

Usá sub-agentes o recorrelo vos mismo. Buscá evidencia concreta de:

### Autenticación y roles
- Archivos de auth (login, registro, middleware de auth)
- Definición de roles (enum, constantes, tabla de roles)
- Middleware de permisos (quién puede qué)
- Provider de OAuth (Google, GitHub, etc.)

### Billing y planes
- Integraciones con pasarelas (Stripe, MercadoPago, Payway)
- Definición de planes (nombres, precios, límites)
- Lógica de trial (duración, qué pasa al vencer)
- Webhooks de pago
- Lógica de upgrade/downgrade

### Entidades de dominio
- Modelos de base de datos (schemas, migrations, models)
- Relaciones entre entidades (foreign keys, joins)
- Campos que implican reglas (status, role, plan, expires_at)

### Tracking y analytics
- Integraciones con analytics (Google Analytics, Mixpanel, Amplitude, PostHog)
- Eventos trackeados (track, identify, page)
- Dashboard o reportes internos

### Integraciones externas
- APIs de terceros (keys en .env, SDKs importados)
- Webhooks (endpoints que reciben callbacks)
- Servicios de email (SendGrid, Resend, SES)

## Paso 3: Generar borrador

Con lo que encontraste, generá un borrador de `docs/BUSINESS_MODEL.md` siguiendo la estructura del template. Para cada sección:

- **Si pudiste inferirlo del código:** Completá con lo que encontraste y citá dónde lo viste (archivo y línea)
- **Si no pudiste inferirlo:** Dejá marcado como `[PREGUNTA PARA EL USUARIO]` con una pregunta concreta

### Formato del borrador

Presentá el borrador al usuario con este formato:

```
## Borrador de Modelo de Negocio

Recorrí el código y esto es lo que encontré. Lo que está marcado con ❓
necesito que me lo confirmes o corrijas.

### Tipo de proyecto
[lo que inferiste]

### Monetización
Encontré [X] planes en `[archivo:línea]`:
- Plan A: $X/mes, límite de Y
- Plan B: $X/mes, límite de Y
❓ ¿Estos planes están vigentes? ¿Falta alguno?

### Roles
Encontré estos roles en `[archivo:línea]`: admin, member, viewer
❓ ¿Qué puede hacer cada uno?

[... etc para cada sección]
```

## Paso 4: Hacer preguntas

Después de presentar el borrador, hacé las preguntas pendientes. Reglas:

- **Máximo 5 preguntas por ronda.** Si hay más, priorizá las más importantes.
- **Preguntas concretas, no abiertas.** "¿El trial dura 14 o 30 días?" > "¿Cómo funciona el trial?"
- **Si el usuario dice "no sé"**, marcar como `[POR DEFINIR]` y seguir.
- **Si el usuario corrige algo que inferiste**, actualizar y agradecer.

Podés hacer hasta 3 rondas de preguntas. Si después de 3 rondas quedan cosas sin resolver, dejá las secciones como `[POR DEFINIR]`.

## Paso 5: Generar documento final

Con las respuestas del usuario, generá la versión final de `docs/BUSINESS_MODEL.md`:

1. Completá todas las secciones del template
2. Las secciones que quedaron sin resolver marcalas como `[POR DEFINIR — razón]`
3. Agregá la fecha en el historial de cambios
4. Mostrá un resumen al usuario:

```
✅ BUSINESS_MODEL.md generado/actualizado.

Secciones completas: X/Y
Secciones pendientes: Z (marcadas como [POR DEFINIR])

Próximo paso recomendado: correr el Business Logic Reviewer para
verificar que el código cumple estas reglas.
```

## Paso 6: Recomendar siguiente acción

Según lo que encontraste, sugerí:

- Si hay reglas de negocio claras → "Podés correr el Business Logic Reviewer ahora"
- Si hay tracking implementado → "Podés correr el Data/Analytics Reviewer ahora"
- Si faltan muchas definiciones → "Te sugiero completar las secciones [POR DEFINIR] antes de correr los roles de revisión"

---

*Documentar el negocio no es burocracia. Es la diferencia entre construir lo correcto y construir correctamente lo incorrecto.*
