# Design Tokens — Qapitaliza

> Fuente de verdad del sistema visual. Todos los componentes deben usar estos tokens.
> No usar valores de color, spacing o tipografía hardcodeados — siempre referenciar los tokens.

---

## 1. Colores

### Paleta base

| Token (CSS var) | Valor hex | Tailwind class | Uso |
|---|---|---|---|
| `--color-bg-primary` | `#0B0F1A` | `bg-navy-950` | Fondo principal de todas las páginas |
| `--color-bg-card` | `#0F172A` | `bg-navy-900` | Fondo de cards, sidebar, panels |
| `--color-bg-hover` | `#1E293B` | `bg-slate-800` | Hover de filas, inputs, items nav inactivos |
| `--color-border` | `#1E293B` | `border-slate-800` | Bordes de cards, inputs, dividers |
| `--color-accent` | `#F59E0B` | `text-amber-500` / `bg-amber-500` | CTAs, badges destacados, íconos activos, precio |
| `--color-accent-hover` | `#FBBF24` | `bg-amber-400` | Hover de botones y links amber |
| `--color-accent-glow` | `rgba(245,158,11,0.15)` | — | Glow en cards seleccionadas, estados activos |
| `--color-text-primary` | `#F8FAFC` | `text-slate-50` | Texto principal, títulos, precios |
| `--color-text-secondary` | `#94A3B8` | `text-slate-400` | Labels, subtítulos, metadata |
| `--color-text-muted` | `#64748B` | `text-slate-500` | Timestamps, helpers, texto apagado |
| `--color-success` | `#10B981` | `text-emerald-500` / `bg-emerald-500` | Estados "Publicado", "Verificado", métricas positivas |
| `--color-error` | `#EF4444` | `text-red-500` / `bg-red-500` | Errores, alertas, "Rechazado", suspendidos |
| `--color-info` | `#3B82F6` | `text-blue-500` | Estados "Respondida", roles "Vendedor" pill |
| `--color-warning` | `#F59E0B` | `text-amber-500` | Warnings, "En revisión" (mismo que accent) |

### Opacidades de estado (backgrounds semitransparentes)

| Uso | Valor | Tailwind equivalente |
|---|---|---|
| Nav item activo background | `rgba(245,158,11,0.08)` | `bg-amber-500/[0.08]` |
| Burbuja de mensaje propio | `rgba(245,158,11,0.15)` | `bg-amber-500/15` |
| Badge "SaaS" info | `rgba(59,130,246,0.15)` | `bg-blue-500/15` |
| Badge "Verificado" success | `rgba(16,185,129,0.15)` | `bg-emerald-500/15` |
| Card hover shadow amber | `rgba(245,158,11,0.30)` | `shadow-amber-500/30` |

---

## 2. Tipografía

### Fuentes

```css
/* globals.css */
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
```

| Variable | Font family | Uso |
|---|---|---|
| `font-sans` | DM Sans | Todo el texto de la UI |
| `font-mono` | JetBrains Mono | Tech stack pills, valores numéricos de código |

### Escala tipográfica

| Nombre | Tamaño | Peso | Color por defecto | Uso |
|---|---|---|---|---|
| `text-hero` | `48px` / `text-5xl` | `700` | `#F8FAFC` | Título landing hero |
| `text-page-title` | `32px` / `text-3xl` | `600` | `#F8FAFC` | Títulos de sección pública ("Explorar activos") |
| `text-dashboard-title` | `28px` / `text-2xl` | `600` | `#F8FAFC` | Títulos de páginas de dashboard |
| `text-card-title` | `18px` / `text-lg` | `600` | `#F8FAFC` | Nombre del activo en cards de catálogo |
| `text-section-heading` | `16px` / `text-base` | `600` | `#F8FAFC` | Headings internos de secciones |
| `text-label` | `14px` / `text-sm` | `500` | `#94A3B8` | Labels de inputs y metadata |
| `text-body` | `14px` / `text-sm` | `400` | `#94A3B8` | Texto descriptivo secundario |
| `text-helper` | `12px` / `text-xs` | `400` | `#64748B` | Helpers, counters, timestamps |
| `text-overline` | `12px` / `text-xs` | `400` | `#64748B` | Labels uppercase con tracking (ej. headers de tabla) |

### Convenciones

- Headers de tabla: `uppercase tracking-wider text-xs text-slate-500`
- Precios principales: `text-amber-500 font-bold text-2xl` (sidebar) / `text-3xl` (hero card)
- Tech stack pills: `font-mono text-xs`
- Timestamps: `text-xs text-slate-500`

---

## 3. Border Radius

| Token | Valor | Uso |
|---|---|---|
| `rounded-card` | `rounded-xl` (12px) | Cards, panels, modals, sidebars |
| `rounded-btn` | `rounded-lg` (8px) | Botones, inputs, selects |
| `rounded-badge` | `rounded-full` | Badges, pills de tipo, status dots |
| `rounded-logo` | `rounded-lg` (8px) | Logo Q cuadrado |
| `rounded-avatar` | `rounded-full` | Avatares de usuario |
| `rounded-thumb` | `rounded-lg` (8px) | Thumbnails de activos en tablas (40x40px) |

---

## 4. Spacing

Usar múltiplos del sistema de Tailwind. Valores críticos:

| Contexto | Valor |
|---|---|
| Padding interno de cards | `p-5` (20px) normal / `p-8` (32px) en formularios |
| Gap entre cards en grilla | `gap-6` (24px) |
| Padding de página principal | `px-8 py-8` (32px) |
| Ancho de sidebar | `w-[280px]` fija |
| Gap entre nav items sidebar | `gap-1` |

---

## 5. Sombras y efectos

```css
/* Card hover con borde amber */
.card-hover {
  transition: border-color 200ms, box-shadow 200ms;
}
.card-hover:hover {
  border-color: rgba(245, 158, 11, 0.30);
  box-shadow: 0 0 0 1px rgba(245, 158, 11, 0.30);
}

/* Mesh gradient amber — hero y decorative panels */
.mesh-gradient-amber {
  background: radial-gradient(
    ellipse 80% 60% at 50% 40%,
    rgba(245, 158, 11, 0.08) 0%,
    transparent 70%
  );
}

/* Borde activo amber — nav items */
.nav-active::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: #F59E0B;
  border-radius: 0 2px 2px 0;
}
```

---

## 6. Tailwind config — extensiones requeridas

```ts
// tailwind.config.ts
export default {
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#0B0F1A',
          900: '#0F172A',
        },
        amber: {
          400: '#FBBF24',
          500: '#F59E0B',
        }
      },
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        card: '12px',
      },
    },
  },
}
```

---

## 7. Iconografía

Librería: **Lucide React** (`lucide-react`). No mezclar con otras librerías de íconos.

| Ícono | Componente Lucide | Uso |
|---|---|---|
| Dashboard | `LayoutDashboard` | Nav sidebar |
| Activos | `Package` | Nav sidebar, stat cards |
| Consultas | `MessageCircle` | Nav sidebar, stat cards |
| Favoritos | `Heart` | Nav sidebar, botón guardar |
| Perfil | `User` | Nav sidebar |
| Nuevo | `Plus` | Botón "Nuevo listado" |
| Búsqueda | `Search` | Barra de búsqueda |
| Ojo | `Eye` | Toggle contraseña, stat vistas |
| Dinero | `DollarSign` | Stat cards revenue |
| Cerrar | `X` | Modals, chips tags |
| Enviar | `Send` | Botón enviar mensaje |
| Menú opciones | `MoreHorizontal` | Menú ⋯ en tablas |
| Ajustes | `Settings` | Nav admin |
| Gráfico | `BarChart3` | Nav admin reportes |
| Usuarios | `Users` | Nav admin / stat |
| Check | `Check` | Items verificados |
| Lock | `Lock` | Seguridad, email verificado |

Tamaño estándar: `size-4` (16px) en nav / `size-5` (20px) en stat cards / `size-6` (24px) en features.
