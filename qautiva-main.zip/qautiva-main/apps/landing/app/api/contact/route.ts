import { NextRequest, NextResponse } from 'next/server'

// CSRF: orígenes permitidos por ambiente
const ALLOWED_ORIGINS =
  process.env.NODE_ENV === 'production'
    ? ['https://qautiva.ar', 'https://www.qautiva.ar']
    : ['http://localhost:3000', 'http://localhost:3001']

// Rate limiting simple in-memory
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT = 5
const RATE_WINDOW_MS = 60_000

function checkRateLimit(ip: string): boolean {
  const now = Date.now()

  // Limpiar entradas expiradas para evitar memory leak
  for (const [key, entry] of rateLimitMap.entries()) {
    if (now > entry.resetAt) rateLimitMap.delete(key)
  }

  const entry = rateLimitMap.get(ip)
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW_MS })
    return true
  }
  if (entry.count >= RATE_LIMIT) return false
  entry.count++
  return true
}

interface ContactBody {
  name: string
  email: string
  business: string
  recaptchaToken: string
}

interface RecaptchaResponse {
  success: boolean
  score?: number
  action?: string
}

async function verifyRecaptcha(token: string): Promise<boolean> {
  const secretKey = process.env.RECAPTCHA_SECRET_KEY

  if (!secretKey) {
    if (process.env.NODE_ENV !== 'production') {
      console.warn('[reCAPTCHA] RECAPTCHA_SECRET_KEY no configurada — saltando verificación en dev')
      return true
    }
    return false
  }

  const response = await fetch('https://www.google.com/recaptcha/api/siteverify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `secret=${secretKey}&response=${token}`,
    signal: AbortSignal.timeout(5000),
  })

  const data = (await response.json()) as RecaptchaResponse
  // 0.7 en prod (Google recomienda ≥0.7 para formularios críticos), 0.5 en dev
  const threshold = process.env.NODE_ENV === 'production' ? 0.7 : 0.5
  return data.success && (data.score ?? 0) >= threshold && data.action === 'contact'
}

async function notifyTelegram(lead: { name: string; email: string; business: string }): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN
  const chatId = process.env.TELEGRAM_CHAT_ID

  if (!token || !chatId) {
    console.warn('[contact] TELEGRAM_BOT_TOKEN o TELEGRAM_CHAT_ID no configurados — lead no notificado por Telegram')
    return
  }

  const text = [
    '🔔 *Nuevo lead — qautiva landing*',
    '',
    `👤 Nombre: ${lead.name}`,
    `📧 Email: ${lead.email}`,
    `💼 Negocio: ${lead.business}`,
  ].join('\n')

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'Markdown' }),
      signal: AbortSignal.timeout(5000),
    })
    if (!res.ok) {
      console.error('[contact] Error al notificar Telegram', { status: res.status })
    }
  } catch (err) {
    // No bloquear la respuesta al usuario si Telegram falla
    console.error('[contact] Timeout o error de red al notificar Telegram', err)
  }
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

function isValidContactBody(body: unknown): body is ContactBody {
  if (typeof body !== 'object' || body === null) return false
  const b = body as Record<string, unknown>
  return (
    typeof b['name'] === 'string' &&
    typeof b['email'] === 'string' &&
    typeof b['business'] === 'string' &&
    typeof b['recaptchaToken'] === 'string'
  )
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  // CSRF: verificar que la request viene de un origen conocido
  const origin = request.headers.get('origin')
  if (origin && !ALLOWED_ORIGINS.includes(origin)) {
    return NextResponse.json({ error: 'Origen no permitido' }, { status: 403 })
  }

  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
  if (!checkRateLimit(ip)) {
    return NextResponse.json(
      { error: 'Demasiadas solicitudes. Esperá un momento antes de intentar de nuevo.' },
      { status: 429 }
    )
  }

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Solicitud inválida' }, { status: 400 })
  }

  if (!isValidContactBody(body)) {
    return NextResponse.json({ error: 'Todos los campos son obligatorios' }, { status: 400 })
  }

  const { name, email, business, recaptchaToken } = body

  if (!name.trim() || !email.trim() || !business.trim() || !recaptchaToken.trim()) {
    return NextResponse.json({ error: 'Todos los campos son obligatorios' }, { status: 400 })
  }

  if (name.length > 100 || email.length > 200 || business.length > 500) {
    return NextResponse.json({ error: 'Datos demasiado largos' }, { status: 400 })
  }

  if (!isValidEmail(email)) {
    return NextResponse.json({ error: 'El email no es válido' }, { status: 400 })
  }

  const isHuman = await verifyRecaptcha(recaptchaToken)
  if (!isHuman) {
    return NextResponse.json({ error: 'Verificación de seguridad fallida' }, { status: 400 })
  }

  const safeName = name.substring(0, 100).replace(/[^\w\s\-áéíóúüñÁÉÍÓÚÜÑ]/g, '')

  if (safeName.trim().length === 0 || !/[a-záéíóúüñ]/i.test(safeName)) {
    return NextResponse.json({ error: 'El nombre no es válido' }, { status: 400 })
  }

  // No loguear nombre (PII) — solo dominio de email para diagnóstico
  const emailDomain = email.split('@')[1] ?? 'unknown'
  console.info('[contact] Nuevo lead recibido', { emailDomain })

  await notifyTelegram({ name: safeName, email, business })

  return NextResponse.json({ ok: true })
}
