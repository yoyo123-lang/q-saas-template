import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'
import { createServiceClient } from '@qautiva/db'

/**
 * POST /api/settings/password
 * Cambia la contraseña del usuario autenticado.
 * Solo funciona para usuarios email/password (bloquea cualquier proveedor OAuth).
 * Verifica la contraseña actual antes de actualizar.
 */
export async function POST(request: Request) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  // Solo para usuarios email/password
  const provider =
    (user.app_metadata?.provider as string | undefined) ??
    (user.identities?.[0]?.provider as string | undefined)

  // Bloquear todos los proveedores OAuth (no solo Google)
  if (provider && provider !== 'email') {
    return NextResponse.json(
      { error: 'Tu cuenta usa un proveedor externo para iniciar sesión. No podés cambiar la contraseña acá.' },
      { status: 400 },
    )
  }

  let body: Record<string, unknown>
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const currentPassword = typeof body.currentPassword === 'string' ? body.currentPassword : ''
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : ''

  if (!currentPassword || !newPassword) {
    return NextResponse.json({ error: 'Campos obligatorios faltantes' }, { status: 400 })
  }

  if (newPassword.length < 8) {
    return NextResponse.json({ error: 'La nueva contraseña debe tener al menos 8 caracteres' }, { status: 400 })
  }

  // Verificar contraseña actual con sign-in
  const email = user.email
  if (!email) {
    return NextResponse.json({ error: 'No se encontró el email del usuario' }, { status: 400 })
  }

  const { error: signInError } = await supabase.auth.signInWithPassword({
    email,
    password: currentPassword,
  })

  if (signInError) {
    return NextResponse.json({ error: 'La contraseña actual es incorrecta' }, { status: 400 })
  }

  // Actualizar contraseña con service role
  const serviceClient = createServiceClient()
  const { error: updateError } = await serviceClient.auth.admin.updateUserById(user.id, {
    password: newPassword,
  })

  if (updateError) {
    console.error('[settings/password] Error al actualizar contraseña:', updateError.message)
    return NextResponse.json({ error: 'Error al actualizar la contraseña' }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}
