import { SkeletonCard } from '@/components/ui/skeleton-card'

export default function ExplorarLoading() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <div className="mb-8">
        <div className="h-9 w-56 bg-slate-800 rounded-lg animate-pulse" />
        <div className="h-4 w-72 bg-slate-800 rounded mt-2 animate-pulse" />
      </div>

      <div className="flex gap-8 items-start">
        {/* Filter sidebar skeleton */}
        <div className="hidden lg:block w-64 flex-shrink-0 space-y-4">
          <div className="h-5 w-24 bg-slate-800 rounded animate-pulse" />
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-9 bg-slate-800 rounded-lg animate-pulse" />
          ))}
        </div>

        {/* Grid skeleton */}
        <div className="flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
