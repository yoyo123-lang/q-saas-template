# Sesión 9: Ventas y POS (frontend)

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 9
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Pantalla de punto de venta funcional — buscar producto, armar carrito, cobrar, emitir ticket/factura.

## Pre-requisitos

Sesión 8 completada (servicio de ventas, tesorería).

## Etapas

### Etapa 1: Layout POS
- Layout a dos columnas: izquierda (búsqueda/catálogo) + derecha (carrito)
- Diseño optimizado para uso rápido (cajero de comercio)
- Responsive: en mobile el carrito se muestra como drawer
- Atajos de teclado para operaciones comunes

### Etapa 2: Búsqueda y selección de productos
- Búsqueda por nombre, código de barras, SKU
- Resultados en tiempo real (debounce 300ms)
- Grilla de categorías para navegación rápida
- Click o scan → agregar al carrito con cantidad 1
- Mostrar stock disponible en cada producto

### Etapa 3: Carrito y cobro
- Lista de ítems con cantidad editable, precio, subtotal
- Selección de cliente (con "Consumidor Final" por defecto)
- Panel de cobro: medio de pago, monto recibido, cálculo de vuelto
- Botón de confirmar venta (llama al servicio de ventas)
- Loading state durante emisión de factura ARCA

### Etapa 4: Post-venta
- Pantalla de confirmación con datos del comprobante
- Opción: imprimir ticket, descargar PDF, enviar por email
- Botón "Nueva venta" que limpia todo
- Historial de ventas del día accesible desde el POS

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
