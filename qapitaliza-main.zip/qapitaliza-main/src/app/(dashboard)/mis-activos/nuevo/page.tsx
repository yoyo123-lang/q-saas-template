'use client'

import { useEffect, useState } from 'react'
import { useForm, FormProvider } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { toast } from 'sonner'
import { Stepper } from '@/components/listings/listing-form/stepper'
import { StepBasic } from '@/components/listings/listing-form/step-basic'
import { StepMetrics } from '@/components/listings/listing-form/step-metrics'
import { StepImages } from '@/components/listings/listing-form/step-images'
import { ReviewSummary } from '@/components/listings/listing-form/review-summary'
import { Button } from '@/components/ui/button'
import { Modal } from '@/components/ui/modal'
import { createListingSchema, type CreateListingData, type CreateListingInput } from '@/lib/schemas/listing'
import { createListing, publishListing } from '@/lib/actions/listings'
import { useRouter } from 'next/navigation'

const DRAFT_KEY = 'new-listing-draft'
const STEP_KEY = 'new-listing-step'

// Explicit field lists avoid Object.keys() fragility with Zod shape types
const STEP1_FIELDS: (keyof CreateListingInput)[] = ['title', 'type', 'url', 'description', 'askingPrice', 'currency', 'techStack', 'tags']
const STEP2_FIELDS: (keyof CreateListingInput)[] = ['monthlyTraffic', 'domainAuthority', 'domainAge', 'registrationYear', 'mrr', 'activeUsers', 'churnRate', 'monthlyOrders', 'monthlyRevenue']
const STEP3_FIELDS: (keyof CreateListingInput)[] = ['screenshotUrls']

const steps = [
  { id: 1, label: 'Información básica' },
  { id: 2, label: 'Métricas' },
  { id: 3, label: 'Imágenes' },
  { id: 4, label: 'Revisión' },
]

export default function NuevoListadoPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [showRestoreModal, setShowRestoreModal] = useState(false)
  const [savingDraft, setSavingDraft] = useState(false)
  const [submittingForReview, setSubmittingForReview] = useState(false)

  const methods = useForm<CreateListingInput>({
    resolver: zodResolver(createListingSchema),
    defaultValues: {
      currency: 'USD',
      techStack: [],
      tags: [],
      screenshotUrls: [],
    },
    mode: 'onBlur',
  })

  const { handleSubmit, getValues, reset, trigger } = methods

  // Check for draft on mount
  useEffect(() => {
    const saved = sessionStorage.getItem(DRAFT_KEY)
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        if (parsed && parsed.title) {
          setShowRestoreModal(true)
        }
      } catch {
        // ignore invalid draft
      }
    }
  }, [])

  // Persist current step so reload doesn't reset progress
  useEffect(() => {
    sessionStorage.setItem(STEP_KEY, String(currentStep))
  }, [currentStep])

  // Auto-save to sessionStorage on change
  useEffect(() => {
    const sub = methods.watch((values) => {
      sessionStorage.setItem(DRAFT_KEY, JSON.stringify(values))
    })
    return () => sub.unsubscribe()
  }, [methods])

  const restoreDraft = () => {
    const saved = sessionStorage.getItem(DRAFT_KEY)
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        reset(parsed)
      } catch {
        // ignore
      }
    }
    const savedStep = Number(sessionStorage.getItem(STEP_KEY))
    if (savedStep >= 1 && savedStep <= 4) setCurrentStep(savedStep)
    setShowRestoreModal(false)
  }

  const discardDraft = () => {
    sessionStorage.removeItem(DRAFT_KEY)
    sessionStorage.removeItem(STEP_KEY)
    setShowRestoreModal(false)
  }

  const goNext = async () => {
    let valid = true
    if (currentStep === 1) valid = await trigger(STEP1_FIELDS)
    else if (currentStep === 2) valid = await trigger(STEP2_FIELDS)
    else if (currentStep === 3) valid = await trigger(STEP3_FIELDS)
    if (valid) setCurrentStep((s) => Math.min(s + 1, 4))
  }

  const goBack = () => setCurrentStep((s) => Math.max(s - 1, 1))

  const handleSaveDraft = async () => {
    const basicValid = await trigger(STEP1_FIELDS)
    if (!basicValid) {
      toast.error('Completá los campos requeridos antes de guardar el borrador')
      return
    }
    setSavingDraft(true)
    const data = getValues()
    const result = await createListing(data as CreateListingData)
    setSavingDraft(false)
    if (result.success) {
      sessionStorage.removeItem(DRAFT_KEY)
      sessionStorage.removeItem(STEP_KEY)
      toast.success('Borrador guardado')
      router.push('/mis-activos')
    } else {
      toast.error(result.error ?? 'Error al guardar')
    }
  }

  const handleSubmitForReview = handleSubmit(async (data) => {
    setSubmittingForReview(true)
    const createResult = await createListing(data as CreateListingData)
    if (!createResult.success || !createResult.data) {
      toast.error(createResult.error ?? 'Error al crear el listado')
      setSubmittingForReview(false)
      return
    }
    const publishResult = await publishListing(createResult.data.id)
    setSubmittingForReview(false)
    if (!publishResult.success) {
      toast.error(publishResult.error ?? 'Error al enviar a revisión')
      return
    }
    sessionStorage.removeItem(DRAFT_KEY)
    toast.success('Listado enviado a revisión. Te avisamos cuando sea aprobado.')
    router.push('/mis-activos')
  })

  const formData = methods.watch()

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-slate-50">Nuevo listado</h1>
        <p className="text-sm text-slate-400 mt-1">Completá los datos de tu activo digital</p>
      </div>

      {/* Stepper */}
      <Stepper steps={steps} currentStep={currentStep} />

      {/* Form */}
      <FormProvider {...methods}>
        <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-base font-semibold text-slate-50 mb-5">
            {steps[currentStep - 1].label}
          </h2>

          {currentStep === 1 && <StepBasic />}
          {currentStep === 2 && <StepMetrics />}
          {currentStep === 3 && <StepImages />}
          {currentStep === 4 && <ReviewSummary data={formData} />}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2">
          <Button
            variant="ghost"
            onClick={goBack}
            disabled={currentStep === 1}
          >
            ← Atrás
          </Button>

          <div className="flex gap-3">
            {currentStep === 4 ? (
              <>
                <Button
                  variant="outline"
                  onClick={handleSaveDraft}
                  loading={savingDraft}
                  disabled={submittingForReview}
                >
                  Guardar borrador
                </Button>
                <Button
                  variant="solid"
                  onClick={handleSubmitForReview}
                  loading={submittingForReview}
                  disabled={savingDraft}
                >
                  Enviar a revisión
                </Button>
              </>
            ) : (
              <Button variant="solid" onClick={goNext}>
                Continuar →
              </Button>
            )}
          </div>
        </div>
      </FormProvider>

      {/* Restore draft modal */}
      <Modal
        open={showRestoreModal}
        onClose={discardDraft}
        title="¿Continuar donde lo dejaste?"
        size="sm"
      >
        <p className="text-sm text-slate-400 mb-6">
          Encontramos un borrador guardado. ¿Querés continuar desde donde lo dejaste?
        </p>
        <div className="flex gap-3 justify-end">
          <Button variant="ghost" onClick={discardDraft}>
            Empezar de cero
          </Button>
          <Button variant="solid" onClick={restoreDraft}>
            Continuar
          </Button>
        </div>
      </Modal>
    </div>
  )
}
