'use client'

import type { AutomationLevel } from '@qautiva/db'

const OPTIONS: { value: AutomationLevel; label: string; className: string }[] = [
  { value: 'MANUAL',    label: 'Manual',    className: 'text-[#FBBF24]' },
  { value: 'SEMI_AUTO', label: 'Semi-auto', className: 'text-[#60A5FA]' },
  { value: 'AUTO',      label: 'Auto',      className: 'text-[#34D399]' },
]

const PILL_CLASS: Record<AutomationLevel, string> = {
  MANUAL:    'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30',
  SEMI_AUTO: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30',
  AUTO:      'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30',
}

interface AutomationToggleProps {
  /** Nivel actual (controlado externamente). */
  value: AutomationLevel
  /** Callback al cambiar el nivel. */
  onChange?: (level: AutomationLevel) => void
  /** Si true, solo muestra el pill de estado sin botones. */
  readOnly?: boolean
}

/**
 * Toggle de 3 estados: Manual | Semi-auto | Auto.
 * Estado activo con pill de color; permite selección exclusiva.
 */
export function AutomationToggle({ value, onChange, readOnly = false }: AutomationToggleProps) {
  if (readOnly) {
    const current = OPTIONS.find((o) => o.value === value)
    if (!current) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-[#1E293B] text-[#64748B] cursor-default">
          {value}
        </span>
      )
    }
    return (
      <span
        title="Editá el nivel en la configuración del agente"
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium cursor-default ${PILL_CLASS[value]}`}
      >
        {current.label}
      </span>
    )
  }

  return (
    <div className="flex gap-1 p-1 bg-[#0B0F1A] rounded-lg border border-[#1E293B]">
      {OPTIONS.map((opt) => {
        const isActive = value === opt.value
        return (
          <button
            key={opt.value}
            type="button"
            onClick={() => onChange?.(opt.value)}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-all duration-150 ${
              isActive
                ? `${PILL_CLASS[opt.value]} shadow-sm`
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            {opt.label}
          </button>
        )
      })}
    </div>
  )
}
