-- ============================================================
-- 003 — Listings
-- Activo digital listado para venta. Entidad central del marketplace.
-- Depende de: 001 (profiles), 002 (categories)
-- Rollback: 003_listings_rollback.sql
-- ============================================================

-- ENUMs
CREATE TYPE listing_type AS ENUM (
  'WEBSITE',    -- sitio web con tráfico y contenido establecido
  'DOMAIN',     -- dominio premium con historial y autoridad
  'SAAS',       -- SaaS, MVPs y aplicaciones web
  'ECOMMERCE',  -- tiendas online con productos y ventas activas
  'PROJECT',    -- proyectos digitales en etapa temprana
  'OTHER'       -- otros activos digitales
);

CREATE TYPE listing_status AS ENUM (
  'DRAFT',           -- creado por el vendedor, no enviado
  'PENDING_REVIEW',  -- enviado, esperando aprobación del admin
  'PUBLISHED',       -- aprobado y visible en el catálogo
  'PAUSED',          -- pausado por el vendedor
  'SOLD',            -- marcado como vendido
  'REJECTED'         -- rechazado por el admin (incluye motivo)
);

CREATE TYPE verification_status AS ENUM (
  'UNVERIFIED',  -- métricas autodeclaradas, sin verificar
  'PENDING',     -- verificación solicitada
  'VERIFIED'     -- métricas verificadas por Qapitaliza
);

CREATE TYPE currency_type AS ENUM ('USD', 'ARS');

-- Tabla listings
CREATE TABLE public.listings (
  id                  UUID              PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id           UUID              NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  category_id         UUID              REFERENCES public.categories(id) ON DELETE SET NULL,

  -- Contenido
  title               TEXT              NOT NULL,
  slug                TEXT              NOT NULL UNIQUE,
  description         TEXT              NOT NULL,
  url                 TEXT,

  -- Clasificación
  type                listing_type      NOT NULL,
  status              listing_status    NOT NULL DEFAULT 'DRAFT',
  verification_status verification_status NOT NULL DEFAULT 'UNVERIFIED',

  -- Precio
  asking_price        NUMERIC(12, 2)    NOT NULL,
  currency            currency_type     NOT NULL DEFAULT 'USD',

  -- Métricas básicas (desnormalizadas para queries rápidas)
  monthly_revenue     NUMERIC(12, 2),
  monthly_traffic     INTEGER,
  domain_age          INTEGER,          -- en meses

  -- Arrays
  tech_stack          TEXT[]            NOT NULL DEFAULT '{}',
  tags                TEXT[]            NOT NULL DEFAULT '{}',
  screenshot_urls     TEXT[]            NOT NULL DEFAULT '{}',

  -- Moderación
  featured_until      TIMESTAMPTZ,
  rejection_reason    TEXT,             -- requerido cuando status = REJECTED

  -- Métricas de actividad
  view_count          INTEGER           NOT NULL DEFAULT 0,

  -- Timestamps
  created_at          TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  published_at        TIMESTAMPTZ
);

COMMENT ON TABLE  public.listings                    IS 'Activos digitales listados para venta.';
COMMENT ON COLUMN public.listings.slug               IS 'URL slug único. Generado desde el título. Ej: cryptoalerts-io';
COMMENT ON COLUMN public.listings.monthly_revenue    IS 'MRR o revenue mensual en la moneda del listing.';
COMMENT ON COLUMN public.listings.domain_age         IS 'Antigüedad del dominio en meses.';
COMMENT ON COLUMN public.listings.featured_until     IS 'NULL = no destacado. Fecha futura = destacado hasta esa fecha.';
COMMENT ON COLUMN public.listings.rejection_reason   IS 'Obligatorio cuando status = REJECTED. Mínimo 20 caracteres.';
COMMENT ON COLUMN public.listings.view_count         IS 'Contador de vistas. Incrementado via función RPC o Server Action.';
