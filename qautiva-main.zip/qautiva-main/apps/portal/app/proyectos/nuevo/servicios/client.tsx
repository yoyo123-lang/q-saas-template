'use client'

import { useState } from 'react'
import LoadingSpinner from '@/app/onboarding/_components/LoadingSpinner'

type ServiceType = 'BRAND' | 'WEBSITE' | 'CAMPAIGNS' | 'MEDIA'

const SERVICES: { id: ServiceType; label: string; description: string; icon: string }[] = [
  {
    id: 'BRAND',
    label: 'Marca',
    description: 'Logo, paleta de colores y manual de marca',
    icon: '🎨',
  },
  {
    id: 'WEBSITE',
    label: 'Sitio web',
    description: 'Landing page o sitio completo listo para publicar',
    icon: '🌐',
  },
  {
    id: 'CAMPAIGNS',
    label: 'Campañas',
    description: 'Google Ads y Meta Ads optimizados para tu rubro',
    icon: '📣',
  },
  {
    id: 'MEDIA',
    label: 'Contenido',
    description: 'Artículos, posts y contenido para medios sociales',
    icon: '✍️',
  },
]

export default function ServiciosClient({ projectId }: { projectId: string }) {
  const [selected, setSelected] = useState<Set<ServiceType>>(new Set())
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  function toggleService(id: ServiceType) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
    setErrorMessage('')
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (selected.size === 0) {
      setErrorMessage('Seleccioná al menos un servicio.')
      return
    }

    setIsLoading(true)
    setErrorMessage('')

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          step: 2,
          projectId,
          services: Array.from(selected),
        }),
      })

      if (!res.ok) {
        const data = await res.json().catch((err: unknown) => { console.error('[ServiciosClient] Failed to parse error response', err); return {} })
        setErrorMessage(data.error ?? 'Error al guardar. Intentá de nuevo.')
        setIsLoading(false)
        return
      }

      window.location.href = `/proyectos/${projectId}/progreso`
    } catch {
      setErrorMessage('Error de red. Verificá tu conexión e intentá de nuevo.')
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full max-w-md">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">¿Qué querés generar?</h1>
        <p className="text-[#94A3B8] text-sm">Seleccioná los servicios que necesitás. Podés agregar más después.</p>
      </div>

      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
        {errorMessage && (
          <div className="mb-4 p-3 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="space-y-3 mb-6">
            {SERVICES.map((service) => {
              const isSelected = selected.has(service.id)
              return (
                <button
                  key={service.id}
                  type="button"
                  onClick={() => toggleService(service.id)}
                  disabled={isLoading}
                  className={[
                    'w-full flex items-start gap-4 p-4 rounded-lg border text-left transition-all duration-150',
                    isSelected
                      ? 'border-[#8B5CF6] bg-[#8B5CF6]/10'
                      : 'border-[#1E293B] bg-[#0B0F1A] hover:border-[#8B5CF6]/40',
                    isLoading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
                  ].join(' ')}
                >
                  <span className="text-2xl leading-none mt-0.5">{service.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-white text-sm font-medium">{service.label}</span>
                      <div
                        className={[
                          'w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 ml-2',
                          isSelected ? 'bg-[#8B5CF6] border-[#8B5CF6]' : 'border-[#1E293B]',
                        ].join(' ')}
                      >
                        {isSelected && (
                          <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12">
                            <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        )}
                      </div>
                    </div>
                    <p className="text-[#64748B] text-xs mt-0.5">{service.description}</p>
                  </div>
                </button>
              )
            })}
          </div>

          <button
            type="submit"
            disabled={isLoading || selected.size === 0}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <LoadingSpinner />
                Lanzando proyecto...
              </>
            ) : selected.size > 0 ? `Continuar con ${selected.size} servicio${selected.size !== 1 ? 's' : ''} →` : 'Seleccioná al menos un servicio'}
          </button>
        </form>
      </div>
    </div>
  )
}
