import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getPrisma } from '@/lib/prisma'
import { EditListadoClient } from './edit-client'

interface Props {
  params: Promise<{ id: string }>
}

export default async function EditarListadoPage({ params }: Props) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const listing = await getPrisma().listing.findUnique({
    where: { id },
    include: {
      _count: { select: { inquiries: true, favorites: true } },
    },
  })

  // IDOR: verify ownership
  if (!listing || listing.sellerId !== user.id) {
    redirect('/mis-activos')
  }

  const serialized = {
    id: listing.id,
    title: listing.title,
    type: listing.type,
    url: listing.url,
    description: listing.description,
    askingPrice: Number(listing.askingPrice),
    currency: listing.currency,
    techStack: listing.techStack,
    tags: listing.tags,
    screenshotUrls: listing.screenshotUrls,
    status: listing.status,
    viewCount: listing.viewCount,
    publishedAt: listing.publishedAt?.toISOString() ?? null,
    updatedAt: listing.updatedAt.toISOString(),
    inquiriesCount: listing._count.inquiries,
    favoritesCount: listing._count.favorites,
  }

  return <EditListadoClient listing={serialized} />
}
