import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import type { OrderStatus } from '@qautiva/db'

// ── Helpers de presentación ────────────────────────────────────────────────────

const STATUS_BADGE: Record<OrderStatus, { label: string; className: string }> = {
  PENDING:   { label: 'Pendiente',         className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  ACCEPTED:  { label: 'Aceptada',         className: 'bg-[#3B82F6]/15 text-[#60A5FA]' },
  DELIVERED: { label: 'Entregada',        className: 'bg-[#8B5CF6]/15 text-[#A78BFA]' },
  IN_REVIEW: { label: 'En revisión',      className: 'bg-[#8B5CF6]/15 text-[#A78BFA]' },
  REVISION:  { label: 'Con correcciones', className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  COMPLETED: { label: 'Completada',       className: 'bg-[#10B981]/15 text-[#10B981]' },
  CANCELLED: { label: 'Cancelada',        className: 'bg-[#64748B]/15 text-[#94A3B8]' },
  DISPUTED:  { label: 'Disputada',        className: 'bg-[#EF4444]/15 text-[#F87171]' },
}

// ── Query ──────────────────────────────────────────────────────────────────────

async function getOrder(id: string) {
  return prisma.order.findUnique({
    where: { id },
    select: {
      id: true,
      status: true,
      brief: true,
      targetUrl: true,
      anchorText: true,
      price: true,
      commission: true,
      editorPayout: true,
      deliveryUrl: true,
      deliveryNotes: true,
      rating: true,
      ratingComment: true,
      expiresAt: true,
      deliveryDeadline: true,
      acceptedAt: true,
      deliveredAt: true,
      completedAt: true,
      cancelledAt: true,
      cancellationReason: true,
      createdAt: true,
      updatedAt: true,
      advertiser: { select: { id: true, displayName: true } },
      medium: {
        select: {
          id: true,
          name: true,
          platform: true,
          url: true,
          user: { select: { id: true, displayName: true } },
        },
      },
      product: {
        select: {
          id: true,
          name: true,
          type: true,
          deliveryDays: true,
          includesWriting: true,
        },
      },
      messages: {
        orderBy: { createdAt: 'asc' },
        take: 50,
        select: {
          id: true,
          content: true,
          senderId: true,
          createdAt: true,
        },
      },
    },
  })
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  return { title: `Orden ${params.id.slice(0, 8)} | Qautiva Admin` }
}

// ── Componente auxiliar para mostrar timestamps ────────────────────────────────

function TimelineRow({ label, date }: { label: string; date: Date | null | undefined }) {
  if (!date) return null
  return (
    <div className="flex items-center gap-3 text-sm">
      <span className="w-2 h-2 rounded-full bg-[#8B5CF6] flex-shrink-0" aria-hidden="true" />
      <span className="text-[#64748B] w-32 flex-shrink-0">{label}</span>
      <span className="text-white">{date.toLocaleString('es-AR')}</span>
    </div>
  )
}

// ── Page ───────────────────────────────────────────────────────────────────────

export default async function OrdenDetailPage({ params }: { params: { id: string } }) {
  const order = await getOrder(params.id)
  if (!order) notFound()

  const badge = STATUS_BADGE[order.status] ?? { label: order.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }

  // Identificar senderId de advertiser vs editor para etiquetas de mensajes
  const advertiserProfileId = order.advertiser.id
  const editorProfileId = order.medium.user.id

  return (
    <div className="flex flex-col p-6 gap-6 max-w-3xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-[#64748B]">
        <Link href="/ordenes" className="hover:text-white transition-colors">
          Órdenes
        </Link>
        <span>/</span>
        <span className="text-white font-mono">{order.id.slice(0, 8)}</span>
      </div>

      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-white text-xl font-bold font-mono">{order.id.slice(0, 8)}</h1>
          <p className="text-[#64748B] text-sm mt-0.5">
            {order.advertiser.displayName} → {order.medium.user.displayName} ({order.medium.name})
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium flex-shrink-0 ${badge.className}`}>
          {badge.label}
        </span>
      </div>

      {/* Partes y producto */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
        <h2 className="text-white text-sm font-semibold">Partes</h2>
        <dl className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm">
          <div>
            <dt className="text-[#64748B]">Anunciante</dt>
            <dd className="text-white">{order.advertiser.displayName}</dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Editor</dt>
            <dd className="text-white">{order.medium.user.displayName}</dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Medio</dt>
            <dd>
              <Link href={`/medios/${order.medium.id}`} className="text-[#A78BFA] hover:underline">
                {order.medium.name}
              </Link>
            </dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Producto</dt>
            <dd className="text-white">
              {order.product.name}
              <span className="text-[#64748B] ml-1 text-xs">({order.product.type})</span>
            </dd>
          </div>
        </dl>
      </section>

      {/* Brief */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
        <h2 className="text-white text-sm font-semibold">Brief del anunciante</h2>
        <p className="text-[#94A3B8] text-sm whitespace-pre-wrap">{order.brief}</p>
        {order.targetUrl && (
          <div className="text-sm">
            <span className="text-[#64748B]">URL destino: </span>
            <a
              href={order.targetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#A78BFA] hover:underline break-all"
            >
              {order.targetUrl}
            </a>
          </div>
        )}
        {order.anchorText && (
          <div className="text-sm">
            <span className="text-[#64748B]">Texto ancla: </span>
            <span className="text-white">{order.anchorText}</span>
          </div>
        )}
      </section>

      {/* Financiero */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
        <h2 className="text-white text-sm font-semibold">Financiero</h2>
        <dl className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <dt className="text-[#64748B]">Precio</dt>
            <dd className="text-white font-medium">
              ${Number(order.price).toLocaleString('es-AR')}
            </dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Comisión Qautiva (10%)</dt>
            <dd className="text-[#F59E0B] font-medium">
              ${Number(order.commission).toLocaleString('es-AR')}
            </dd>
          </div>
          <div>
            <dt className="text-[#64748B]">Pago al editor</dt>
            <dd className="text-[#10B981] font-medium">
              ${Number(order.editorPayout).toLocaleString('es-AR')}
            </dd>
          </div>
        </dl>
      </section>

      {/* Entrega */}
      {(order.deliveryUrl || order.deliveryNotes) && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
          <h2 className="text-white text-sm font-semibold">Entrega</h2>
          {order.deliveryUrl && (
            <div className="text-sm">
              <span className="text-[#64748B]">URL publicada: </span>
              <a
                href={order.deliveryUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#A78BFA] hover:underline break-all"
              >
                {order.deliveryUrl}
              </a>
            </div>
          )}
          {order.deliveryNotes && (
            <div className="text-sm">
              <span className="text-[#64748B]">Notas del editor: </span>
              <span className="text-[#94A3B8]">{order.deliveryNotes}</span>
            </div>
          )}
        </section>
      )}

      {/* Calificación */}
      {order.rating != null && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-2">
          <h2 className="text-white text-sm font-semibold">Calificación del anunciante</h2>
          <div className="flex items-center gap-2">
            <span className="text-[#F59E0B] text-lg">{'★'.repeat(order.rating)}{'☆'.repeat(5 - order.rating)}</span>
            <span className="text-white text-sm font-medium">{order.rating}/5</span>
          </div>
          {order.ratingComment && (
            <p className="text-[#94A3B8] text-sm">{order.ratingComment}</p>
          )}
        </section>
      )}

      {/* Cancelación */}
      {order.cancellationReason && (
        <section className="bg-[#0F172A] rounded-lg border border-[#EF4444]/30 p-4 flex flex-col gap-2">
          <h2 className="text-[#F87171] text-sm font-semibold">Motivo de cancelación</h2>
          <p className="text-[#94A3B8] text-sm">{order.cancellationReason}</p>
        </section>
      )}

      {/* Timeline */}
      <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
        <h2 className="text-white text-sm font-semibold">Línea de tiempo</h2>
        <div className="flex flex-col gap-2">
          <TimelineRow label="Creada"     date={order.createdAt} />
          <TimelineRow label="Expira"     date={order.expiresAt} />
          <TimelineRow label="Aceptada"   date={order.acceptedAt} />
          <TimelineRow label="Plazo entr." date={order.deliveryDeadline} />
          <TimelineRow label="Entregada"  date={order.deliveredAt} />
          <TimelineRow label="Completada" date={order.completedAt} />
          <TimelineRow label="Cancelada"  date={order.cancelledAt} />
        </div>
      </section>

      {/* Mensajes */}
      {order.messages.length > 0 && (
        <section className="bg-[#0F172A] rounded-lg border border-[#1E293B] p-4 flex flex-col gap-3">
          <h2 className="text-white text-sm font-semibold">
            Mensajes ({order.messages.length})
          </h2>
          <div className="flex flex-col gap-2 max-h-80 overflow-y-auto">
            {order.messages.map((msg) => {
              const isAdvertiser = msg.senderId === advertiserProfileId
              const isEditor = msg.senderId === editorProfileId
              const senderLabel = isAdvertiser
                ? order.advertiser.displayName
                : isEditor
                  ? order.medium.user.displayName
                  : 'Sistema'
              return (
                <div key={msg.id} className="flex flex-col gap-0.5 text-sm">
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-medium ${isAdvertiser ? 'text-[#60A5FA]' : isEditor ? 'text-[#10B981]' : 'text-[#64748B]'}`}>
                      {senderLabel}
                    </span>
                    <span className="text-[#475569] text-xs">
                      {msg.createdAt.toLocaleString('es-AR')}
                    </span>
                  </div>
                  <p className="text-[#94A3B8] pl-0">{msg.content}</p>
                </div>
              )
            })}
          </div>
        </section>
      )}

      {/* Footer timestamps */}
      <p className="text-[#475569] text-xs">
        Actualizado: {order.updatedAt.toLocaleString('es-AR')}
      </p>
    </div>
  )
}
