import { prisma } from '@qautiva/db'
import type { AiProvider, UsageSource } from '@qautiva/db'

export interface RegisterAiUsageParams {
  teamId: string | null
  projectId: string
  provider: AiProvider
  model: string
  operation: string
  source: UsageSource
  tokensIn: number
  tokensOut: number
}

/**
 * Calcula los datos de uso (costUsd, feePercentage, feeUsd, totalUsd) consultando
 * AiModelPricing y FeeConfig en paralelo (pricing+billingAccount) y luego feeConfig.
 *
 * @throws Error CRITICAL si no existe AiModelPricing para el provider+model.
 * @throws Error CRITICAL si no existe FeeConfig para el plan+keySource.
 */
async function _computeUsageData(params: RegisterAiUsageParams) {
  const { teamId, provider, model, tokensIn, tokensOut } = params

  const [pricing, billingAccount] = await Promise.all([
    prisma.aiModelPricing.findUnique({
      where: { provider_model: { provider, model } },
      select: { inputPer1M: true, outputPer1M: true },
    }),
    prisma.billingAccount.findUnique({
      where: { teamId: teamId! },
      select: { plan: true, preferredKeySource: true },
    }),
  ])

  if (!pricing) {
    throw new Error(
      `CRITICAL: No existe AiModelPricing para provider=${provider} model=${model}. Registro de consumo fallido.`,
    )
  }

  const costUsd =
    (tokensIn * pricing.inputPer1M.toNumber() + tokensOut * pricing.outputPer1M.toNumber()) / 1_000_000

  let feePercentage = 0

  if (billingAccount) {
    const { plan, preferredKeySource: keySource } = billingAccount
    const feeConfig = await prisma.feeConfig.findFirst({
      where: { plan, keySource, isActive: true },
      select: { feePercentage: true },
    })

    if (feeConfig) {
      feePercentage = feeConfig.feePercentage.toNumber()
    } else if (keySource !== 'BYOK') {
      // BYOK: fee=0 es válido sin FeeConfig (el usuario paga su propia key)
      // Non-BYOK sin FeeConfig: error de configuración
      throw new Error(
        `CRITICAL: FeeConfig no encontrado para plan=${plan} keySource=${keySource}. Billing no configurado.`,
      )
    }
  }

  const feeUsd = (costUsd * feePercentage) / 100
  const totalUsd = costUsd + feeUsd

  return { costUsd, feePercentage, feeUsd, totalUsd }
}

/**
 * Registra el consumo de tokens de una operación de IA de forma atómica.
 *
 * Usa `prisma.$transaction` para insertar `TokenUsage` y actualizar
 * `BillingAccount` en una sola transacción. Si cualquier paso falla,
 * ambas operaciones se revierten.
 *
 * Si `teamId` es null, no registra nada y retorna null.
 * Si los tokens son negativos, lanza error CRITICAL.
 *
 * Nunca propaga errores al caller — el consumo de IA ya ocurrió
 * y no debe cancelarse la respuesta al usuario.
 */
export async function registerAiUsage(params: RegisterAiUsageParams): Promise<void> {
  const { teamId, projectId, provider, model, operation, source, tokensIn, tokensOut } = params

  try {
    if (!teamId) return

    if (tokensIn < 0 || tokensOut < 0) {
      const msg = `CRITICAL: registerAiUsage recibió tokens negativos — valor inválido. tokensIn=${tokensIn} tokensOut=${tokensOut}`
      console.error(msg, { teamId, projectId, operation })
      throw new Error(msg)
    }

    const { costUsd, feePercentage, feeUsd, totalUsd } = await _computeUsageData(params)

    await prisma.$transaction(async (tx) => {
      await tx.tokenUsage.create({
        data: {
          teamId,
          projectId,
          provider,
          model,
          operation,
          source,
          tokensIn,
          tokensOut,
          costUsd,
          feePercentage,
          feeUsd,
          totalUsd,
        },
      })

      if (source === 'TRIAL') {
        await tx.billingAccount.update({
          where: { teamId },
          data: { trialTokensUsed: { increment: tokensIn + tokensOut } },
        })
      } else if (source === 'QAUTIVA_HOSTED') {
        await tx.billingAccount.update({
          where: { teamId },
          data: { balanceUsd: { decrement: totalUsd } },
        })
      }
      // BYOK: solo el create, sin update
    })
  } catch (err) {
    console.error('CRITICAL: registerAiUsage falló — el consumo ocurrió pero no se registró en billing', {
      err,
      teamId: params.teamId,
      projectId: params.projectId,
      provider: params.provider,
      model: params.model,
      operation: params.operation,
    })
  }
}
