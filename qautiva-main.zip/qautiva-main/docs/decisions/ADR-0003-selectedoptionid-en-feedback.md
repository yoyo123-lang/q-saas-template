# ADR-0003: Almacenar la opción seleccionada de marca en el campo `feedback`

> **Fecha**: 2026-03-10
> **Estado**: Aceptada

## Contexto

Cuando el cliente aprueba un entregable de tipo `BRAND_OPTIONS`, elige una de las opciones de marca presentadas (ej. "OPCIÓN A"). El sistema necesita registrar cuál fue la opción elegida para que el equipo de Qautiva pueda ejecutarla.

El modelo `Deliverable` en Prisma tiene los campos:
- `feedback: String?` — descripción semántica: feedback del cliente si pide cambios
- `content: Json` — contenido estructurado del entregable (las opciones de marca, previewUrl, etc.)
- `status: DeliverableStatus` — estado del entregable

No existe un campo dedicado para "opción elegida".

## Opciones consideradas

### Opción A: Migración de schema — agregar campo `selectedOptionId: String?`
- **Pros**: Semánticamente correcto, fácil de consultar y distinguir de feedback textual
- **Contras**: Requiere migración de DB en producción, genera downtime breve en tabla `Deliverable`, overhead de ADR + PR + deploy sincronizado

### Opción B: Guardar en el campo `content` (JSON)
- **Pros**: `content` ya es estructurado por tipo, no requiere migración
- **Contras**: Mezclamos "input del admin" (opciones de marca) con "output del cliente" (su elección) en el mismo campo. Hace más difícil entender el campo. También complica los updates parciales del JSON en Prisma.

### Opción C: Guardar en el campo `feedback` con prefijo `selected:`
- **Pros**: Sin migración, simple de implementar, fácil de parsear (`feedback.startsWith('selected:')`)
- **Contras**: Reutiliza un campo semánticamente definido como "texto de revisión". Requiere documentar la convención. Si el cliente aprueba Y escribe feedback (caso raro), no hay lugar para ambos.

## Decisión

Elegimos **Opción C** (prefijo `selected:` en `feedback`) como solución temporal MVP.

Razones:
1. Velocidad de implementación — zero downtime, zero migración
2. En el MVP, la combinación "aprobar + dejar feedback escrito" no existe en el flujo de `BRAND_OPTIONS` — el cliente elige una opción y aprueba, sin campo de texto adicional
3. La convención `selected:${optionId}` es parseable y distinguible del feedback textual (`REVISION_REQUESTED` siempre tiene texto en lenguaje natural, `CLIENT_APPROVED` puede tener `selected:xxx` o null)

**Formato en DB:**
```
feedback = "selected:option-a"    ← aprobó con opción A
feedback = null                   ← aprobó sin indicar opción (deliverables no BRAND_OPTIONS)
feedback = "necesito más colores" ← pidió cambios (REVISION_REQUESTED)
```

## Consecuencias

### Lo que ganamos
- Implementación en horas sin riesgo de migración
- El admin puede ver la opción elegida consultando el campo `feedback`
- Backwards compatible — los entregables existentes tienen `feedback: null`

### Lo que perdemos o se complica
- Semántica del campo `feedback` queda contaminada con dos propósitos
- El admin necesita saber la convención `selected:` para interpretar el campo correctamente
- Si en el futuro el cliente puede aprobar Y escribir un comentario, necesitamos migrar

### Lo que hay que tener en cuenta a futuro
- Cuando el portal crezca a 50+ clientes activos y el admin empiece a necesitar reportes de "¿qué opción elige cada cliente?", migrar a campo dedicado `selectedOptionId` se vuelve necesario
- Trigger de migración: cuando el admin app muestre estadísticas de selección de opciones o cuando el flujo permita aprobar + comentar simultáneamente

---

*Registrado durante revisión pre-producción de Etapa 3 — ver `docs/reviews/2026-03-10_etapa3-portal.md`*
