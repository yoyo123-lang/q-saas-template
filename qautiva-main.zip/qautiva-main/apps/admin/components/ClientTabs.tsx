'use client'

import Link from 'next/link'
import { usePathname, useSearchParams } from 'next/navigation'

type TabId = 'progreso' | 'entregables' | 'conversaciones' | 'notas' | 'entrevista' | 'campanas'

export interface TabCounts {
  entregables: number
  conversaciones: number
  notas: number
  entrevista: number
  campanas: number
}

interface ClientTabsProps {
  orgId: string
  activeTab: string
  counts: TabCounts
}

export function ClientTabs({ orgId, activeTab, counts }: ClientTabsProps) {
  const pathname = usePathname()
  const searchParams = useSearchParams()

  function buildHref(tabId: TabId) {
    const params = new URLSearchParams(searchParams.toString())
    params.set('tab', tabId)
    return `${pathname}?${params.toString()}`
  }

  const TABS: { id: TabId; label: string; count?: number }[] = [
    { id: 'progreso',       label: 'Progreso' },
    { id: 'entregables',    label: 'Entregables',    count: counts.entregables },
    { id: 'conversaciones', label: 'Conversaciones', count: counts.conversaciones },
    { id: 'notas',          label: 'Notas',          count: counts.notas },
    { id: 'entrevista',     label: 'Entrevista',     count: counts.entrevista },
    { id: 'campanas',       label: 'Campañas',       count: counts.campanas },
  ]

  return (
    <div className="flex gap-1 border-b border-[#1E293B] pb-0">
      {TABS.map((tab) => {
        const isActive = activeTab === tab.id
        return (
          <Link
            key={tab.id}
            href={buildHref(tab.id)}
            className={`
              flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors -mb-px
              ${isActive
                ? 'text-white border border-[#1E293B] border-b-[#0F172A] bg-[#0F172A]'
                : 'text-[#64748B] hover:text-[#94A3B8]'
              }
            `}
          >
            {tab.label}
            {tab.count !== undefined && tab.count > 0 && (
              <span
                className={`
                  inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-semibold
                  ${isActive ? 'bg-[#334155] text-[#94A3B8]' : 'bg-[#1E293B] text-[#475569]'}
                `}
              >
                {tab.count}
              </span>
            )}
          </Link>
        )
      })}
    </div>
  )
}
