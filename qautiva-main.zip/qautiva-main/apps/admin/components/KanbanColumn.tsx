import { ClientCard, type ClientCardData } from '@/components/ClientCard'

type KanbanStage = ClientCardData['stage']

const COLUMN_TOP_BORDER: Record<KanbanStage, string> = {
  Descubrimiento: 'border-t-[#3B82F6]',
  Investigación: 'border-t-[#06B6D4]',
  Marca: 'border-t-[#8B5CF6]',
  Web: 'border-t-[#6366F1]',
  Campañas: 'border-t-[#F59E0B]',
  Medios: 'border-t-[#F97316]',
  Completado: 'border-t-[#10B981]',
}

interface KanbanColumnProps {
  stage: KanbanStage
  cards: ClientCardData[]
}

export function KanbanColumn({ stage, cards }: KanbanColumnProps) {
  const topBorderClass = COLUMN_TOP_BORDER[stage]

  return (
    <div
      className={`
        flex flex-col flex-shrink-0 w-[220px] bg-[#0F172A] rounded-lg
        border border-[#1E293B] border-t-2 ${topBorderClass}
      `}
    >
      {/* Header de columna */}
      <div className="px-3 py-2.5 border-b border-[#1E293B]">
        <div className="flex items-center justify-between">
          <span className="text-[#94A3B8] text-xs font-semibold uppercase tracking-wider">
            {stage}
          </span>
          <span className="text-[#64748B] text-xs font-medium">
            {cards.length}
          </span>
        </div>
      </div>

      {/* Tarjetas */}
      <div className="flex flex-col gap-2 p-2 flex-1">
        {cards.length === 0 && (
          <p className="text-[#64748B] text-xs text-center py-4">Sin clientes</p>
        )}
        {cards.map((card) => (
          <ClientCard key={card.id} data={card} />
        ))}
      </div>
    </div>
  )
}
