'use client'

import Image from 'next/image'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState, useRef, useEffect } from 'react'
import {
  ChevronDown,
  Globe,
  LogOut,
  Menu,
  Package,
  Settings,
  Store,
  TrendingUp,
  User,
} from 'lucide-react'
import { createSupabaseBrowserClient } from '@/lib/supabase-browser'
import { useSidebar } from './SidebarContext'

type TopBarProps = {
  hasMedios: boolean
  showNewProject?: boolean
}

export function TopBar({ hasMedios, showNewProject = true }: TopBarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [profileOpen, setProfileOpen] = useState(false)
  const { open: sidebarOpen, toggle: toggleSidebar } = useSidebar()
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setProfileOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function handleLogout() {
    const supabase = createSupabaseBrowserClient()
    await supabase.auth.signOut()
    router.push('/login')
  }

  const marketplaceItems = [
    { label: 'Comprar Dominio', href: '/dominios/buscar', icon: Globe },
    { label: 'Marketplace', href: '/marketplace', icon: Store },
    { label: 'Mis Medios', href: '/mis-medios', icon: Globe },
    { label: 'Mis Pedidos', href: '/mis-pedidos', icon: Package },
    ...(hasMedios ? [{ label: 'Mis Ventas', href: '/mis-ventas', icon: TrendingUp }] : []),
  ]

  const isActive = (href: string) =>
    pathname === href || pathname.startsWith(`${href}/`)

  return (
    <header className="border-b border-[#1E293B] bg-[#0B0F1A] px-6 py-3 flex-shrink-0">
      <div className="flex items-center justify-between">
        {/* Hamburger + Logo agrupados a la izquierda */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleSidebar}
            aria-label={sidebarOpen ? 'Cerrar menú' : 'Abrir menú'}
            className="md:hidden p-2.5 rounded-lg text-[#94A3B8] hover:text-white hover:bg-[#1E293B] transition-colors duration-200 flex-shrink-0"
          >
            <Menu size={20} aria-hidden="true" />
          </button>

          <Link href="/proyectos">
            <Image src="/logo.png" alt="Qautiva" width={480} height={160} className="h-8 md:h-12 w-auto" priority />
          </Link>
        </div>

        {/* Marketplace nav — horizontal items */}
        <nav className="hidden md:flex items-center gap-1">
          {marketplaceItems.map((item) => {
            const Icon = item.icon
            const active = isActive(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  active
                    ? 'bg-[#8B5CF6] text-white'
                    : 'text-[#94A3B8] hover:text-white hover:bg-[#1E293B]'
                }`}
              >
                <Icon size={16} aria-hidden="true" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Right side: new project + profile dropdown */}
        <div className="flex items-center gap-3">
          {showNewProject && (
            <Link
              href="/proyectos/nuevo"
              className="hidden sm:inline-flex px-4 py-2 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200"
            >
              + Nuevo proyecto
            </Link>
          )}

          {/* Profile dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setProfileOpen(!profileOpen)}
              className="flex items-center gap-1 px-2 py-2 rounded-lg text-[#94A3B8] hover:text-white hover:bg-[#1E293B] transition-colors duration-200"
              aria-expanded={profileOpen}
              aria-haspopup="true"
              aria-label="Menú de perfil"
            >
              <User size={20} aria-hidden="true" />
              <ChevronDown size={14} aria-hidden="true" />
            </button>

            {profileOpen && (
              <div className="absolute right-0 top-full mt-1 w-48 bg-[#0F172A] border border-[#1E293B] rounded-lg shadow-lg py-1 z-50">
                <Link
                  href="/configuracion"
                  onClick={() => setProfileOpen(false)}
                  className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#94A3B8] hover:text-white hover:bg-[#1E293B] transition-colors duration-200"
                >
                  <Settings size={16} aria-hidden="true" />
                  Configuración
                </Link>
                <div className="mx-3 my-1 h-px bg-[#1E293B]" />
                <button
                  type="button"
                  onClick={() => { void handleLogout() }}
                  className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#94A3B8] hover:text-white hover:bg-[#1E293B] transition-colors duration-200"
                >
                  <LogOut size={16} aria-hidden="true" />
                  Cerrar sesión
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
