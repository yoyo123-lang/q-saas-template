# Informe de Revisión — ROL A: Business Logic Reviewer
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol A - Business Logic Reviewer

---

## Resumen ejecutivo

La lógica de negocio de las páginas públicas es correcta en general. Se detectaron dos hallazgos: uno alto sobre la implementación incorrecta del contador de vistas (sin deduplicación por usuario), y uno medio sobre la ausencia de regla para prevenir que un seller consulte su propio activo.

---

## Hallazgos

### [ALTO → CORREGIDO] `viewCount` se incrementaba en cada render SSR, no por visita única

**Archivo:** `src/app/(public)/explorar/[slug]/page.tsx`

**Problema original:** El BUSINESS_MODEL.md especifica: "El viewCount se incrementa por visita única (no por refresh). Implementación mínima: por IP o por sesión." La implementación anterior incrementaba en cada request SSR — un usuario que refresheaba la página 10 veces sumaba 10 vistas.

**Fix aplicado:** Implementación de deduplicación via cookie de sesión con TTL de 1 hora:

```typescript
const cookieStore = await cookies()
const cookieKey = `viewed_${listing.id}`
if (!cookieStore.has(cookieKey)) {
  cookieStore.set(cookieKey, '1', { maxAge: 3600, httpOnly: true, path: '/' })
  await incrementListingViews(listing.id)
}
```

- Si el usuario ya visitó el listing en la última hora, la cookie existe y no se incrementa el contador.
- La cookie es `httpOnly` — no modificable por JavaScript del cliente.
- TTL de 3600 segundos (1 hora) — alineado con la spec.

**Limitación conocida:** La cookie vive en el browser — el mismo usuario en incognito o distinto browser sumará vista. Para deduplicación más robusta (por IP o por userId autenticado), se necesita una tabla de sesiones de vistas. Documentado para implementación futura.

---

### [MEDIO] Seller puede ver "Consultar al vendedor" en su propio activo

**Archivo:** `src/app/(public)/explorar/[slug]/page.tsx`

**Contexto:** El BUSINESS_MODEL.md define: "CUANDO un SELLER intenta consultar su propio activo ENTONCES se muestra error." En las páginas públicas no hay autenticación — no se puede verificar si el viewer es el seller.

**Estado:** Aceptable en MVP. La verificación se implementará cuando exista la capa de autenticación. El endpoint de creación de `Inquiry` debe validar que `buyerId != sellerId` (constraint pendiente de Etapa 3).

---

## Puntos positivos

- El flujo de listados solo muestra activos con `status: 'PUBLISHED'` — activos DRAFT, PAUSED o SOLD no aparecen.
- El slug único garantiza URLs limpias y canónicas por activo.
- `getRelatedListings` excluye correctamente el listing actual.
- La página de detalle redirige a `/login?redirect=...` para las acciones de consultar y favoritar — correcto para el flujo de conversión.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| viewCount incrementa en cada SSR render | ALTO | Corregido (cookie deduplication 1h) |
| Seller puede consultar su propio activo | MEDIO | Pendiente — requiere auth layer (Etapa 3) |
