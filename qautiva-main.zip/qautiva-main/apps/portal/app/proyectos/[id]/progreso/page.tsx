import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import type { StageStatus, DeliverableStatus } from '@qautiva/db'
import { StageProgress } from '@/components/StageProgress'
import { ActionCard } from '@/components/ActionCard'
import { AutoRefresh } from '@/components/AutoRefresh'
import { INTERVIEW_ACTIONABLE_STATUSES } from '@/app/_lib/interview/constants'
import { StageActivationBadge } from './_components/StageActivationBadge'

export const metadata: Metadata = { title: 'Mi progreso — Qautiva' }

const STAGE_LABELS = [
  'Tu negocio',
  'Mercado',
  'Marca',
  'Web',
  'Campañas',
  'Medios',
]

const COMPLETED_STATUSES: DeliverableStatus[] = ['CLIENT_APPROVED']
const NEEDS_ACTION_STATUSES: DeliverableStatus[] = ['SENT_TO_CLIENT']

function toVisualStatus(
  stageStatus: StageStatus,
  index: number,
  activeStageIndex: number,
): 'completed' | 'active' | 'pending' {
  if (stageStatus === 'COMPLETED') return 'completed'
  if (index === activeStageIndex) return 'active'
  return 'pending'
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })
}

type CompletedItem = {
  id: string
  title: string
  approvedDate: string
  viewHref: string
}

function CompletedItemRow({ item }: { item: CompletedItem }) {
  return (
    <div className="flex items-center gap-3 bg-[#0F172A] px-4 py-3 rounded-lg">
      <div className="w-5 h-5 rounded-full bg-[#10B981]/15 flex items-center justify-center flex-shrink-0">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true">
          <path
            d="M1.5 5L4 7.5L8.5 2.5"
            stroke="#10B981"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <span className="text-white text-sm font-medium flex-1">{item.title}</span>
      <span className="text-[#64748B] text-xs">{item.approvedDate}</span>
      <Link
        href={item.viewHref}
        className="text-[#64748B] text-xs hover:text-[#94A3B8] transition-colors duration-200"
      >
        Ver
      </Link>
    </div>
  )
}

export default async function ProjectProgresoPage({
  params,
}: {
  params: { id: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) notFound()

  // Verificar ownership vía team membership
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true, role: true, createdAt: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) notFound()

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const project = await prisma.project.findFirst({
    where: { id: params.id, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, name: true, status: true },
  })

  if (!project) notFound()

  const [stages, deliverables] = await Promise.all([
    prisma.stage.findMany({
      where: { projectId: project.id },
      orderBy: { number: 'asc' },
      select: { id: true, number: true, name: true, status: true, activation: true, teamId: true },
    }),
    prisma.deliverable.findMany({
      where: { projectId: project.id },
      orderBy: { updatedAt: 'desc' },
      take: 50,
      select: { id: true, title: true, status: true, stageId: true, updatedAt: true },
    }),
  ])

  const userRole = await (async () => {
    if (stages.length === 0) return null
    const teamId = stages[0]?.teamId
    if (!teamId) return null
    const member = await prisma.teamMember.findFirst({
      where: { teamId, user: { authUserId: user.id } },
      select: { role: true },
    })
    return member?.role ?? null
  })()
  const canEditActivation = userRole === 'OWNER' || userRole === 'ADMIN'

  const activeIndex = stages.findIndex((s) => s.status !== 'COMPLETED')
  const activeStageIndex = activeIndex === -1 ? stages.length - 1 : activeIndex

  const visualStages = stages.map((s, i) => ({
    number: s.number,
    label: STAGE_LABELS[s.number - 1] ?? s.name,
    status: toVisualStatus(s.status, i, activeStageIndex),
  }))

  const completedItems: CompletedItem[] = deliverables
    .filter((d) => COMPLETED_STATUSES.includes(d.status))
    .map((d) => ({
      id: d.id,
      title: d.title,
      approvedDate: `Aprobado ${formatDate(d.updatedAt)}`,
      viewHref: `/proyectos/${project.id}/entregables/${d.id}`,
    }))

  const pendingDeliverable = deliverables.find((d) =>
    NEEDS_ACTION_STATUSES.includes(d.status),
  )

  const activeStage = stages[activeStageIndex]
  const activeStageLabel = activeStage
    ? `Etapa ${activeStage.number} — ${STAGE_LABELS[activeStage.number - 1] ?? activeStage.name}`
    : null

  // Consultar si la etapa activa tiene una sesión de entrevista accionable
  let interviewCta: { label: string; href: string } | null = null
  let isSessionProcessing = false
  let isSessionError = false

  if (activeStage) {
    try {
      const interviewSession = await prisma.interviewSession.findUnique({
        where: { stageId: activeStage.id },
        select: { status: true },
      })

      // Detectar si la sesión está procesando para activar auto-refresh
      if (interviewSession?.status === 'PROCESSING') {
        isSessionProcessing = true
      }

      // Sin sesión = nunca inició → mostrar "Comenzar" (se crea on-demand al entrar)
      // Con sesión actionable = puede continuar
      // ERROR = algo falló → mostrar CTA para que el usuario vea el error en /interview
      const isActionable = !interviewSession
        || INTERVIEW_ACTIONABLE_STATUSES.includes(interviewSession.status)

      if (isActionable) {
        const isNew = !interviewSession || interviewSession.status === 'NOT_STARTED'
        interviewCta = {
          label: isNew ? 'Comenzar entrevista' : 'Continuar entrevista',
          href: `/proyectos/${project.id}/etapas/${activeStage.id}/interview`,
        }
      } else if (interviewSession?.status === 'ERROR') {
        isSessionError = true
        interviewCta = {
          label: 'Reintentar',
          href: `/proyectos/${project.id}/etapas/${activeStage.id}/interview`,
        }
      }
    } catch (err) {
      console.error('[progreso] Error loading interview session', {
        stageId: activeStage.id,
        error: err instanceof Error ? err.message : String(err),
      })
    }
  }

  // Pantalla de generando — el proyecto todavía está siendo procesado
  const isGenerating = project.status === 'GENERATING' && stages.length === 0

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold text-white mb-6">Mi progreso</h1>

      {isGenerating ? (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <AutoRefresh intervalMs={30_000} />
          <div className="w-12 h-12 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/30 flex items-center justify-center mx-auto mb-4">
            <svg className="animate-spin" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" strokeWidth="2" aria-hidden="true">
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
          </div>
          <p className="text-white font-medium mb-2">La IA está preparando tu proyecto</p>
          <p className="text-[#94A3B8] text-sm">
            Esto puede tardar unos minutos. Te avisamos por email cuando el primer resultado esté listo.
          </p>
        </div>
      ) : visualStages.length > 0 ? (
        <>
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 mb-6">
            <StageProgress stages={visualStages} />
          </div>

          {activeStageLabel && (
            <div className="mb-6">
              {pendingDeliverable ? (
                <ActionCard
                  stageTitle={activeStageLabel}
                  badge={{ label: 'Esperando tu aprobación', variant: 'warning' }}
                  description="Hay un entregable listo para que lo revises y apruebes. Tu opinión es clave para avanzar."
                  actionLabel="Ver entregable"
                  actionHref={`/proyectos/${project.id}/entregables/${pendingDeliverable.id}`}
                />
              ) : interviewCta ? (
                <ActionCard
                  stageTitle={activeStageLabel}
                  badge={isSessionError
                    ? { label: 'Hubo un problema', variant: 'error' }
                    : { label: 'Tu turno', variant: 'warning' }
                  }
                  description={isSessionError
                    ? 'Hubo un problema al procesar tus respuestas. Podés reintentar desde la entrevista.'
                    : `Completá la entrevista de ${activeStage ? (STAGE_LABELS[activeStage.number - 1] ?? activeStage.name) : 'esta etapa'} para avanzar — toma unos minutos.`
                  }
                  actionLabel={interviewCta.label}
                  actionHref={interviewCta.href}
                />
              ) : (
                <>
                  {isSessionProcessing && <AutoRefresh intervalMs={10_000} />}
                  <ActionCard
                    stageTitle={activeStageLabel}
                    badge={{ label: 'En proceso', variant: 'in-progress' }}
                    description={`Estamos trabajando en tu ${activeStage ? (STAGE_LABELS[activeStage.number - 1] ?? activeStage.name) : 'etapa'}. Te avisamos cuando esté listo para revisar.`}
                  />
                </>
              )}
            </div>
          )}

          {completedItems.length > 0 && (
            <div>
              <h2 className="text-[#94A3B8] text-sm font-medium mb-3">Entregables aprobados</h2>
              <div className="flex flex-col gap-2">
                {completedItems.map((item) => (
                  <CompletedItemRow key={item.id} item={item} />
                ))}
              </div>
            </div>
          )}

          {/* Activación de etapas — visible para todos, editable para ADMIN/OWNER */}
          {stages.some((s) => s.activation !== 'ACTIVE') && (
            <div className="mt-4 flex flex-col gap-2">
              <p className="text-[#64748B] text-xs font-medium mb-1">Estado de etapas</p>
              {stages.filter((s) => s.activation !== 'ACTIVE').map((s) => (
                <div key={s.id} className="flex items-center justify-between">
                  <span className="text-[#94A3B8] text-sm">{STAGE_LABELS[s.number - 1] ?? s.name}</span>
                  <StageActivationBadge
                    stageId={s.id}
                    activation={s.activation as 'ACTIVE' | 'SKIP' | 'PROVIDED_BY_CLIENT'}
                    canEdit={canEditActivation}
                  />
                </div>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">
            Tu proceso todavía no arrancó. Pronto vas a ver el progreso acá.
          </p>
        </div>
      )}
    </div>
  )
}
