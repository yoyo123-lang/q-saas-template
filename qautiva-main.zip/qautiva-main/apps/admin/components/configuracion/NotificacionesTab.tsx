'use client'

import { useState } from 'react'
import { saveNotificationTemplate } from '@/app/(protected)/configuracion/actions'
import type { ActionState } from '@/app/(protected)/configuracion/actions'
import type { NotificationTemplate } from '@qautiva/db'
import { SubmitButton } from './shared'

interface Props {
  templates: NotificationTemplate[]
}

const TEMPLATE_LABELS: Record<string, { label: string; desc: string }> = {
  RESULT_READY:      { label: 'Resultado listo',      desc: 'Se envía cuando un entregable está disponible para revisión.' },
  PAUSED_REMINDER:   { label: 'Recordatorio de pausa', desc: 'Se envía cuando una entrevista lleva X días en pausa.' },
  WEEKLY_FEEDBACK:   { label: 'Feedback semanal',      desc: 'Resumen semanal de actividad enviado al cliente.' },
}

const PLACEHOLDERS_NOTE =
  'Placeholders disponibles: {business_name}, {deliverable_name}, {client_name}, {stage_name}'


function TemplateCard({ template }: { template: NotificationTemplate }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)
  const meta = TEMPLATE_LABELS[template.type]

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await saveNotificationTemplate(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <input type="hidden" name="id" value={template.id} />

      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-white font-medium text-sm">{meta?.label ?? template.type}</h3>
          {meta?.desc && <p className="text-[#64748B] text-xs mt-0.5">{meta.desc}</p>}
        </div>
        <label className="flex items-center gap-2 cursor-pointer flex-shrink-0 ml-4">
          <input
            type="checkbox"
            name="isActive"
            defaultChecked={template.isActive}
            className="w-4 h-4 accent-[#8B5CF6]"
          />
          <span className="text-xs text-[#94A3B8]">Activo</span>
        </label>
      </div>

      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium text-[#94A3B8] mb-1">Asunto</label>
          <input
            type="text"
            name="subject"
            defaultValue={template.subject}
            required
            className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-3 py-2 text-white text-sm outline-none transition-colors"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-[#94A3B8] mb-1">Cuerpo HTML</label>
          <textarea
            name="bodyHtml"
            defaultValue={template.bodyHtml}
            rows={6}
            className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-3 py-2 text-white text-sm outline-none transition-colors resize-y font-mono"
          />
          <p className="text-[#475569] text-xs mt-1">{PLACEHOLDERS_NOTE}</p>
        </div>
      </div>

      <div className="flex items-center gap-4 mt-4">
        <SubmitButton pending={isPending} />
        {state && !state.ok && <p className="text-sm text-[#EF4444]">{state.error}</p>}
        {state?.ok && <p className="text-sm text-[#10B981]">Guardado correctamente.</p>}
      </div>
    </form>
  )
}

export function NotificacionesTab({ templates }: Props) {
  return (
    <div className="pt-6 space-y-4">
      {templates.length === 0 ? (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#64748B] text-sm">
            No hay templates configurados. Creá registros desde la DB con los tipos
            RESULT_READY, PAUSED_REMINDER y WEEKLY_FEEDBACK.
          </p>
        </div>
      ) : (
        templates.map(t => <TemplateCard key={t.id} template={t} />)
      )}
    </div>
  )
}
