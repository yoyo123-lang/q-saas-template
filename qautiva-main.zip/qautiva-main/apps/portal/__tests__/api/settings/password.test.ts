import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockGetUser = vi.fn()
const mockSignInWithPassword = vi.fn()
const mockAdminUpdateUserById = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: {
      getUser: mockGetUser,
      signInWithPassword: mockSignInWithPassword,
    },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@qautiva/db', () => ({
  createServiceClient: vi.fn().mockReturnValue({
    auth: {
      admin: { updateUserById: mockAdminUpdateUserById },
    },
  }),
}))

const { POST } = await import('@/app/api/settings/password/route')

const mockEmailUser = {
  id: 'auth-user-1',
  email: 'test@test.com',
  app_metadata: { provider: 'email' },
  identities: [{ provider: 'email' }],
}

const mockGoogleUser = {
  id: 'auth-user-2',
  email: 'google@test.com',
  app_metadata: { provider: 'google' },
  identities: [{ provider: 'google' }],
}

function makeRequest(body: unknown) {
  return new Request('http://localhost/api/settings/password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

describe('POST /api/settings/password', () => {
  beforeEach(() => vi.clearAllMocks())

  it('retorna 401 sin auth', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: null })
    const res = await POST(makeRequest({ currentPassword: 'old', newPassword: 'new12345' }))
    expect(res.status).toBe(401)
  })

  it('retorna 400 para usuario Google OAuth', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockGoogleUser }, error: null })
    const res = await POST(makeRequest({ currentPassword: 'old', newPassword: 'new12345' }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toContain('proveedor externo')
  })

  it('retorna 400 si nueva contraseña tiene menos de 8 chars', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockEmailUser }, error: null })
    const res = await POST(makeRequest({ currentPassword: 'old', newPassword: 'short' }))
    expect(res.status).toBe(400)
  })

  it('retorna 400 si la contraseña actual es incorrecta', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockEmailUser }, error: null })
    mockSignInWithPassword.mockResolvedValue({ error: { message: 'Invalid credentials' } })
    const res = await POST(makeRequest({ currentPassword: 'wrong', newPassword: 'newpassword123' }))
    expect(res.status).toBe(400)
    const body = await res.json()
    expect(body.error).toContain('incorrecta')
  })

  it('cambia la contraseña correctamente', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockEmailUser }, error: null })
    mockSignInWithPassword.mockResolvedValue({ error: null })
    mockAdminUpdateUserById.mockResolvedValue({ error: null })
    const res = await POST(makeRequest({ currentPassword: 'correct', newPassword: 'newpassword123' }))
    expect(res.status).toBe(200)
    const body = await res.json()
    expect(body.ok).toBe(true)
    expect(mockAdminUpdateUserById).toHaveBeenCalledWith('auth-user-1', { password: 'newpassword123' })
  })
})
