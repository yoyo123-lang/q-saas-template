'use client'

import { useState } from 'react'
import { useForm, FormProvider } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { toast } from 'sonner'
import { useRouter } from 'next/navigation'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Modal } from '@/components/ui/modal'
import { StepBasic } from '@/components/listings/listing-form/step-basic'
import { StepMetrics } from '@/components/listings/listing-form/step-metrics'
import { StepImages } from '@/components/listings/listing-form/step-images'
import { updateListing, deleteListing, pauseListing, resumeListing, markAsSold } from '@/lib/actions/listings'
import { createListingSchema, type CreateListingData, type CreateListingInput } from '@/lib/schemas/listing'
import { cn } from '@/lib/utils/cn'
import { statusBadgeVariant, statusLabels } from '@/lib/constants/listing-labels'

const tabs = ['Información', 'Métricas', 'Imágenes', 'Configuración']

interface SerializedListing {
  id: string
  title: string
  type: string
  url: string | null
  description: string
  askingPrice: number
  currency: string
  techStack: string[]
  tags: string[]
  screenshotUrls: string[]
  status: string
  viewCount: number
  publishedAt: string | null
  updatedAt: string
  inquiriesCount: number
  favoritesCount: number
}

interface Props {
  listing: SerializedListing
}

export function EditListadoClient({ listing }: Props) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState(0)
  const [currentStatus, setCurrentStatus] = useState(listing.status)
  const [saving, setSaving] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)

  const methods = useForm<CreateListingInput>({
    resolver: zodResolver(createListingSchema),
    defaultValues: {
      title: listing.title,
      type: listing.type as CreateListingInput['type'],
      url: listing.url ?? '',
      description: listing.description,
      askingPrice: listing.askingPrice,
      currency: listing.currency as 'USD' | 'ARS',
      techStack: listing.techStack,
      tags: listing.tags,
      screenshotUrls: listing.screenshotUrls,
    },
    mode: 'onBlur',
  })

  const handleSave = methods.handleSubmit(async (data) => {
    setSaving(true)
    const result = await updateListing(listing.id, data as CreateListingData)
    setSaving(false)
    if (result.success) {
      toast.success('Cambios guardados')
    } else {
      toast.error(result.error ?? 'Error al guardar')
    }
  })

  const handleDelete = async () => {
    setActionLoading(true)
    const result = await deleteListing(listing.id)
    setActionLoading(false)
    if (result.success) {
      toast.success('Listado eliminado')
      router.push('/mis-activos')
    } else {
      toast.error(result.error ?? 'Error al eliminar')
    }
  }

  const handlePause = async () => {
    setActionLoading(true)
    const result = currentStatus === 'PAUSED'
      ? await resumeListing(listing.id)
      : await pauseListing(listing.id)
    setActionLoading(false)
    if (result.success) {
      const newStatus = currentStatus === 'PAUSED' ? 'PUBLISHED' : 'PAUSED'
      toast.success(currentStatus === 'PAUSED' ? 'Listado reactivado' : 'Listado pausado')
      setCurrentStatus(newStatus)
    } else {
      toast.error(result.error ?? 'Error')
    }
  }

  const handleMarkSold = async () => {
    setActionLoading(true)
    const result = await markAsSold(listing.id)
    setActionLoading(false)
    if (result.success) {
      toast.success('Marcado como vendido')
      setCurrentStatus('SOLD')
    } else {
      toast.error(result.error ?? 'Error')
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-slate-50 line-clamp-1">{listing.title}</h1>
        <p className="text-sm text-slate-400 mt-1">Editando listado</p>
      </div>

      <div className="flex gap-6 items-start">
        {/* Main content */}
        <div className="flex-1 min-w-0">
          {/* Tabs */}
          <div className="flex gap-1 border-b border-slate-800 mb-6">
            {tabs.map((tab, idx) => (
              <button
                key={tab}
                onClick={() => setActiveTab(idx)}
                className={cn(
                  'px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px',
                  activeTab === idx
                    ? 'border-amber-500 text-amber-500'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          <FormProvider {...methods}>
            <div className="bg-navy-900 border border-slate-800 rounded-xl p-6">
              {activeTab === 0 && <StepBasic />}
              {activeTab === 1 && <StepMetrics />}
              {activeTab === 2 && <StepImages />}
              {activeTab === 3 && (
                <div className="space-y-4">
                  <p className="text-sm font-semibold text-slate-300">Configuración del listado</p>
                  <p className="text-sm text-slate-500">
                    Las opciones de configuración avanzada estarán disponibles próximamente.
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-4">
              <Button variant="ghost" onClick={() => router.push('/mis-activos')}>
                Descartar cambios
              </Button>
              <Button variant="solid" onClick={handleSave} loading={saving}>
                Guardar cambios
              </Button>
            </div>
          </FormProvider>
        </div>

        {/* Sidebar */}
        <div className="w-[280px] flex-shrink-0">
          <div className="bg-navy-900 border border-slate-800 rounded-xl p-5 sticky top-6 space-y-4">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Estado del listado
              </p>
              <Badge variant={statusBadgeVariant[currentStatus] ?? 'muted'}>
                {statusLabels[currentStatus] ?? currentStatus}
              </Badge>
              {listing.publishedAt && (
                <p className="text-xs text-slate-500 mt-1">
                  Publicado el{' '}
                  {new Date(listing.publishedAt).toLocaleDateString('es-AR', {
                    day: 'numeric', month: 'short', year: 'numeric',
                  })}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              {currentStatus !== 'SOLD' && (
                <Button variant="outline" size="sm" onClick={handlePause} loading={actionLoading}>
                  {currentStatus === 'PAUSED' ? 'Reanudar publicación' : 'Pausar publicación'}
                </Button>
              )}
              {currentStatus !== 'SOLD' && (
                <Button variant="outline-success" size="sm" onClick={handleMarkSold} loading={actionLoading}>
                  Marcar como vendido
                </Button>
              )}
              <div className="h-px bg-slate-800 my-1" />
              <Button variant="outline-danger" size="sm" onClick={() => setShowDeleteModal(true)}>
                Eliminar listado
              </Button>
            </div>

            <div className="h-px bg-slate-800" />

            <div className="space-y-1.5 text-sm">
              {[
                ['Vistas', listing.viewCount],
                ['Consultas', listing.inquiriesCount],
                ['Favoritos', listing.favoritesCount],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between">
                  <span className="text-slate-500">{label}</span>
                  <span className="text-slate-200">{value}</span>
                </div>
              ))}
            </div>

            <p className="text-xs text-slate-600">
              Última edición:{' '}
              {new Date(listing.updatedAt).toLocaleDateString('es-AR', {
                day: 'numeric', month: 'short',
              })}
            </p>
          </div>
        </div>
      </div>

      {/* Confirm delete */}
      <Modal
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Eliminar listado"
        size="sm"
      >
        <p className="text-sm text-slate-400 mb-6">
          ¿Estás seguro de que querés eliminar este listado? Esta acción no se puede deshacer.
        </p>
        <div className="flex gap-3 justify-end">
          <Button variant="ghost" onClick={() => setShowDeleteModal(false)}>Cancelar</Button>
          <Button variant="outline-danger" onClick={handleDelete} loading={actionLoading}>
            Eliminar
          </Button>
        </div>
      </Modal>
    </div>
  )
}
