/**
 * Tests TDD para registerAiUsage().
 *
 * Estrategia: mock de prisma de @qautiva/db con $transaction interactivo.
 * Verifica que registerAiUsage ejecuta create+update atómicamente y que los
 * errores NO se propagan (no cancelan la respuesta al usuario).
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockAiModelPricingFindUnique = vi.fn()
const mockBillingAccountFindUnique = vi.fn()
const mockFeeConfigFindFirst = vi.fn()
const mockTokenUsageCreate = vi.fn()
const mockBillingAccountUpdate = vi.fn()
const mockTransaction = vi.fn()

vi.mock('@qautiva/db', () => ({
  prisma: {
    aiModelPricing: { findUnique: mockAiModelPricingFindUnique },
    billingAccount: { findUnique: mockBillingAccountFindUnique },
    feeConfig: { findFirst: mockFeeConfigFindFirst },
    tokenUsage: { create: mockTokenUsageCreate },
    $transaction: mockTransaction,
  },
  AiProvider: {
    ANTHROPIC: 'ANTHROPIC',
    OPENAI: 'OPENAI',
    GOOGLE_GEMINI: 'GOOGLE_GEMINI',
  },
  BillingPlan: {
    FREE_TRIAL: 'FREE_TRIAL',
    PREPAID: 'PREPAID',
    MONTHLY: 'MONTHLY',
    YEARLY: 'YEARLY',
  },
  ApiKeySource: {
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
  UsageSource: {
    TRIAL: 'TRIAL',
    BYOK: 'BYOK',
    QAUTIVA_HOSTED: 'QAUTIVA_HOSTED',
  },
}))

// ── Fixtures ──────────────────────────────────────────────────────────────────

const BASE_PARAMS = {
  teamId: 'team-abc',
  projectId: 'proj-xyz',
  provider: 'ANTHROPIC' as const,
  model: 'claude-3-5-sonnet-20241022',
  operation: 'brief_generation',
  source: 'TRIAL' as const,
  tokensIn: 1000,
  tokensOut: 500,
}

const MOCK_PRICING = {
  inputPer1M: { toNumber: () => 3.0 },
  outputPer1M: { toNumber: () => 15.0 },
}

const MOCK_BILLING_ACCOUNT = {
  plan: 'FREE_TRIAL',
  preferredKeySource: 'QAUTIVA_HOSTED',
}

const MOCK_FEE_CONFIG = {
  feePercentage: { toNumber: () => 20.0 },
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Configura $transaction para ejecutar el callback con un tx mockeado */
function setupTransaction() {
  mockTransaction.mockImplementation(async (fn: (tx: unknown) => Promise<unknown>) =>
    fn({
      tokenUsage: { create: mockTokenUsageCreate },
      billingAccount: { update: mockBillingAccountUpdate },
    }),
  )
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('registerAiUsage', () => {
  beforeEach(() => {
    mockAiModelPricingFindUnique.mockReset()
    mockBillingAccountFindUnique.mockReset()
    mockFeeConfigFindFirst.mockReset()
    mockTokenUsageCreate.mockReset()
    mockBillingAccountUpdate.mockReset()
    mockTransaction.mockReset()
  })

  it('happy path TRIAL: ejecuta $transaction con create + update trialTokensUsed', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(MOCK_FEE_CONFIG)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-1' })
    mockBillingAccountUpdate.mockResolvedValueOnce({})
    setupTransaction()

    await registerAiUsage(BASE_PARAMS)

    expect(mockTransaction).toHaveBeenCalledOnce()
    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()

    const createData = mockTokenUsageCreate.mock.calls[0][0].data
    expect(createData.teamId).toBe('team-abc')
    expect(createData.source).toBe('TRIAL')
    // costUsd = 1000*3/1e6 + 500*15/1e6 = 0.0105, fee=20% → totalUsd=0.0126
    expect(Number(createData.totalUsd)).toBeCloseTo(0.0126, 6)

    expect(mockBillingAccountUpdate).toHaveBeenCalledOnce()
    expect(mockBillingAccountUpdate).toHaveBeenCalledWith({
      where: { teamId: 'team-abc' },
      data: { trialTokensUsed: { increment: 1500 } },
    })
  })

  it('happy path QAUTIVA_HOSTED: ejecuta $transaction con create + decrement balanceUsd', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(MOCK_FEE_CONFIG)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-2' })
    mockBillingAccountUpdate.mockResolvedValueOnce({})
    setupTransaction()

    await registerAiUsage({ ...BASE_PARAMS, source: 'QAUTIVA_HOSTED' })

    expect(mockBillingAccountUpdate).toHaveBeenCalledOnce()
    expect(mockBillingAccountUpdate).toHaveBeenCalledWith({
      where: { teamId: 'team-abc' },
      data: { balanceUsd: { decrement: expect.closeTo(0.0126, 6) } },
    })
  })

  it('happy path BYOK: ejecuta $transaction solo con create, sin update de BillingAccount', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    const byokAccount = { plan: 'FREE_TRIAL', preferredKeySource: 'BYOK' }
    const byokFee = { feePercentage: { toNumber: () => 0 } }

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(byokAccount)
    mockFeeConfigFindFirst.mockResolvedValueOnce(byokFee)
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-3' })
    setupTransaction()

    await registerAiUsage({ ...BASE_PARAMS, source: 'BYOK' })

    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    expect(mockBillingAccountUpdate).not.toHaveBeenCalled()
  })

  it('teamId null: no registra nada, no llama $transaction', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    await expect(registerAiUsage({ ...BASE_PARAMS, teamId: null })).resolves.toBeUndefined()

    expect(mockTransaction).not.toHaveBeenCalled()
    expect(mockAiModelPricingFindUnique).not.toHaveBeenCalled()
  })

  it('tokensIn negativo: NO propaga, loguea CRITICAL', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

    await expect(registerAiUsage({ ...BASE_PARAMS, tokensIn: -1 })).resolves.toBeUndefined()
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('CRITICAL:'),
      expect.anything(),
    )
    expect(mockTransaction).not.toHaveBeenCalled()

    consoleSpy.mockRestore()
  })

  it('error en $transaction: NO propaga, loguea CRITICAL', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(MOCK_FEE_CONFIG)
    mockTransaction.mockRejectedValueOnce(new Error('DB transaction failed'))

    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

    await expect(registerAiUsage(BASE_PARAMS)).resolves.toBeUndefined()
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('CRITICAL:'),
      expect.anything(),
    )

    consoleSpy.mockRestore()
  })

  it('FeeConfig faltante: NO propaga, loguea CRITICAL', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce(MOCK_PRICING)
    mockBillingAccountFindUnique.mockResolvedValueOnce(MOCK_BILLING_ACCOUNT)
    mockFeeConfigFindFirst.mockResolvedValueOnce(null)

    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

    await expect(registerAiUsage(BASE_PARAMS)).resolves.toBeUndefined()
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('CRITICAL:'),
      expect.anything(),
    )
    expect(mockTransaction).not.toHaveBeenCalled()

    consoleSpy.mockRestore()
  })
})
