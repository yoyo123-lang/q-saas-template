import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

/**
 * DELETE /api/projects/[id]
 * Soft-delete del proyecto. Solo el dueño del team puede eliminarlo.
 */
export async function DELETE(
  _req: Request,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const { id } = params
  if (!UUID_RE.test(id)) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  // Verificar existencia y ownership antes de modificar
  const project = await prisma.project.findFirst({
    where: { id, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, teamId: true },
  })
  if (!project) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // Guard de permisos: solo OWNER puede eliminar proyectos
  const perm = await checkTeamPermission(user.id, project.teamId, ['OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo el OWNER puede eliminar proyectos.' },
      { status: 403 },
    )
  }

  try {
    await prisma.project.update({
      where: { id },
      data: { deletedAt: new Date() },
    })
  } catch (err) {
    console.error('[projects] delete: error al eliminar proyecto', err)
    return NextResponse.json({ error: 'Error al eliminar el proyecto. Intentá de nuevo.' }, { status: 500 })
  }

  console.info(`[portal:api] proyecto eliminado — projectId=${id} userId=${user.id}`)
  revalidatePath('/proyectos')
  return NextResponse.json({ ok: true })
}
