import type { Metadata } from 'next'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import type { MediumStatus, MediumPlatform } from '@qautiva/db'

export const metadata: Metadata = { title: 'Moderación de medios | Qautiva Admin' }
export const dynamic = 'force-dynamic'

// ── Helpers de presentación ────────────────────────────────────────────────────

const PLATFORM_LABEL: Record<MediumPlatform, string> = {
  WEBSITE:   'Web',
  INSTAGRAM: 'Instagram',
  FACEBOOK:  'Facebook',
  TWITTER:   'X (Twitter)',
  TIKTOK:    'TikTok',
  YOUTUBE:   'YouTube',
}

const STATUS_BADGE: Record<MediumStatus, { label: string; className: string }> = {
  PENDING_REVIEW: { label: 'Pendiente',  className: 'bg-[#F59E0B]/15 text-[#F59E0B]' },
  ACTIVE:         { label: 'Activo',     className: 'bg-[#10B981]/15 text-[#10B981]' },
  PAUSED:         { label: 'Pausado',    className: 'bg-[#64748B]/15 text-[#94A3B8]' },
  REJECTED:       { label: 'Rechazado', className: 'bg-[#EF4444]/15 text-[#F87171]' },
  SUSPENDED:      { label: 'Suspendido', className: 'bg-[#EF4444]/20 text-[#F87171]' },
}

const VALID_STATUSES = ['PENDING_REVIEW', 'ACTIVE', 'REJECTED', 'SUSPENDED', 'ALL'] as const
type StatusFilter = typeof VALID_STATUSES[number]

const PAGE_SIZE = 50

// ── Query ──────────────────────────────────────────────────────────────────────

async function getMedia(statusFilter: StatusFilter, page: number) {
  const where = {
    deletedAt: null,
    ...(statusFilter !== 'ALL' ? { status: statusFilter as MediumStatus } : {}),
  }
  const [media, total] = await Promise.all([
    prisma.medium.findMany({
      where,
      orderBy: { createdAt: 'asc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      select: {
        id: true,
        name: true,
        handle: true,
        platform: true,
        status: true,
        followersCount: true,
        createdAt: true,
        user: { select: { displayName: true } },
      },
    }),
    prisma.medium.count({ where }),
  ])
  return { media, total }
}

// ── Page ───────────────────────────────────────────────────────────────────────

interface PageProps {
  searchParams: { status?: string; page?: string }
}

export default async function MediosPage({ searchParams }: PageProps) {
  const rawStatus = searchParams.status ?? 'PENDING_REVIEW'
  const statusFilter: StatusFilter = (VALID_STATUSES as readonly string[]).includes(rawStatus)
    ? (rawStatus as StatusFilter)
    : 'PENDING_REVIEW'

  const rawPage = parseInt(searchParams.page ?? '1', 10)
  const page = isNaN(rawPage) || rawPage < 1 ? 1 : rawPage

  const { media, total } = await getMedia(statusFilter, page)
  const pages = Math.ceil(total / PAGE_SIZE)

  const tabs: { value: StatusFilter; label: string }[] = [
    { value: 'PENDING_REVIEW', label: 'Pendientes' },
    { value: 'ACTIVE',         label: 'Activos' },
    { value: 'REJECTED',       label: 'Rechazados' },
    { value: 'SUSPENDED',      label: 'Suspendidos' },
    { value: 'ALL',            label: 'Todos' },
  ]

  return (
    <div className="flex flex-col h-full p-6 gap-5">
      {/* Header */}
      <div>
        <h1 className="text-white text-xl font-bold">Moderación de medios</h1>
        <p className="text-[#64748B] text-sm mt-0.5">
          {statusFilter === 'PENDING_REVIEW'
            ? `${total} medio${total !== 1 ? 's' : ''} esperando revisión`
            : `${total} medio${total !== 1 ? 's' : ''}`}
        </p>
      </div>

      {/* Tabs de filtro */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <Link
            key={tab.value}
            href={`/medios?status=${tab.value}`}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              statusFilter === tab.value
                ? 'bg-[#8B5CF6] text-white'
                : 'text-[#64748B] hover:text-white hover:bg-[#1E293B]'
            }`}
          >
            {tab.label}
          </Link>
        ))}
      </div>

      {/* Lista */}
      {media.length === 0 ? (
        <p className="text-[#64748B] text-sm">Sin medios en este estado.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[#1E293B]">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[#64748B] border-b border-[#1E293B] bg-[#0F172A]">
                <th className="px-4 py-3 font-medium">Plataforma</th>
                <th className="px-4 py-3 font-medium">Nombre</th>
                <th className="px-4 py-3 font-medium">Editor</th>
                <th className="px-4 py-3 font-medium">Seguidores</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3 font-medium">Creado</th>
              </tr>
            </thead>
            <tbody>
              {media.map((m) => {
                const badge = STATUS_BADGE[m.status] ?? { label: m.status, className: 'bg-[#64748B]/15 text-[#94A3B8]' }
                return (
                  <tr
                    key={m.id}
                    className="border-b border-[#1E293B] last:border-0 hover:bg-[#0F172A] transition-colors"
                  >
                    <td className="px-4 py-3 text-[#94A3B8]">
                      {PLATFORM_LABEL[m.platform]}
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        href={`/medios/${m.id}`}
                        className="text-white hover:text-[#A78BFA] font-medium"
                      >
                        {m.name}
                      </Link>
                      {m.handle && (
                        <span className="text-[#64748B] text-xs ml-1">@{m.handle}</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[#94A3B8]">{m.user.displayName}</td>
                    <td className="px-4 py-3 text-[#94A3B8]">
                      {m.followersCount != null
                        ? m.followersCount.toLocaleString('es-AR')
                        : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
                        {badge.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs">
                      {m.createdAt.toLocaleDateString('es-AR')}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Paginación */}
      {pages > 1 && (
        <div className="flex items-center gap-2 text-sm">
          {page > 1 && (
            <Link
              href={`/medios?status=${statusFilter}&page=${page - 1}`}
              className="px-3 py-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-[#1E293B] transition-colors"
            >
              ← Anterior
            </Link>
          )}
          <span className="text-[#64748B]">
            Página {page} de {pages}
          </span>
          {page < pages && (
            <Link
              href={`/medios?status=${statusFilter}&page=${page + 1}`}
              className="px-3 py-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-[#1E293B] transition-colors"
            >
              Siguiente →
            </Link>
          )}
        </div>
      )}
    </div>
  )
}
