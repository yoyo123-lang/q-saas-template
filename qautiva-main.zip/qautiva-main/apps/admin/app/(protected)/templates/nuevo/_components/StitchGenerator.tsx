'use client'

import { useState, useRef, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { INDUSTRY_VERTICALS, TEMPLATE_STYLES } from '@qautiva/shared'

const SECTIONS = [
  { key: 'hero', label: 'Hero / Portada' },
  { key: 'about', label: 'Sobre Nosotros' },
  { key: 'services', label: 'Servicios' },
  { key: 'pricing', label: 'Precios' },
  { key: 'contact', label: 'Contacto' },
]

const POLL_INTERVAL_MS = 4_000 // polling cada 4 segundos
const PROGRESS_MESSAGES = [
  'Iniciando proyecto en Stitch...',
  'Generando diseño (esto puede tardar 2-3 minutos)...',
  'Procesando estilos y secciones...',
  'Casi listo, finalizando el template...',
]

interface GenerateResult {
  processedHtml: string
  thumbnailUrl: string | null
  stitchProjectId: string | null
  stitchScreenId: string | null
  detectedSections: Record<string, boolean>
  extractedVariables: Record<string, string>
}

type Step = 'form' | 'loading' | 'preview' | 'save' | 'done'

export function StitchGenerator() {
  const router = useRouter()

  const [step, setStep] = useState<Step>('form')
  const [error, setError] = useState<string | null>(null)
  const [processWarning, setProcessWarning] = useState<string | null>(null)
  const [progressMsgIndex, setProgressMsgIndex] = useState(0)

  // Campos del formulario
  const [industry, setIndustry] = useState<string>(INDUSTRY_VERTICALS[0].industries[0])
  const [selectedSections, setSelectedSections] = useState<string[]>(['hero', 'services', 'contact'])
  const [prompt, setPrompt] = useState('')
  const [selectedStyleId, setSelectedStyleId] = useState<string>(TEMPLATE_STYLES[0].id)

  // Estado de "guardar en cola"
  const [isQueueing, setIsQueueing] = useState(false)
  const [queuedJobId, setQueuedJobId] = useState<string | null>(null)

  // Job en curso
  const [jobTemplateId, setJobTemplateId] = useState<string | null>(null)

  // Resultado de Stitch
  const [generateResult, setGenerateResult] = useState<GenerateResult | null>(null)

  // Formulario de guardado
  const [templateName, setTemplateName] = useState('')
  const [templateDescription, setTemplateDescription] = useState('')
  const [isSaving, setIsSaving] = useState(false)
  const [savedTemplateId, setSavedTemplateId] = useState<string | null>(null)

  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const progressIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  function stopPolling() {
    if (pollIntervalRef.current) {
      clearInterval(pollIntervalRef.current)
      pollIntervalRef.current = null
    }
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current)
      progressIntervalRef.current = null
    }
  }

  // Limpiar intervals al desmontar
  useEffect(() => () => stopPolling(), [])

  function toggleSection(key: string) {
    setSelectedSections((prev) =>
      prev.includes(key) ? prev.filter((s) => s !== key) : [...prev, key],
    )
  }

  function startProgressCycle() {
    setProgressMsgIndex(0)
    progressIntervalRef.current = setInterval(() => {
      setProgressMsgIndex((i) => Math.min(i + 1, PROGRESS_MESSAGES.length - 1))
    }, 30_000) // avanza el mensaje cada 30s
  }

  async function pollStatus(templateId: string) {
    try {
      const res = await fetch(`/api/stitch/generate/status?templateId=${templateId}`)
      if (!res.ok) {
        stopPolling()
        setError('Error al verificar el estado de la generación')
        setStep('form')
        return
      }

      const data = (await res.json()) as
        | { status: 'generating' }
        | { status: 'error'; error: string }
        | ({ status: 'done' } & GenerateResult)

      if (data.status === 'generating') return // seguir esperando

      stopPolling()

      if (data.status === 'error') {
        setError(data.error || 'Error al generar el template')
        setStep('form')
        return
      }

      // done
      const { processedHtml, thumbnailUrl, stitchProjectId, stitchScreenId, detectedSections, extractedVariables } =
        data
      setGenerateResult({ processedHtml, thumbnailUrl, stitchProjectId, stitchScreenId, detectedSections, extractedVariables })

      const allSectionsDetected = Object.values(detectedSections).every(Boolean)
      if (!allSectionsDetected) {
        const missing = Object.entries(detectedSections)
          .filter(([, v]) => !v)
          .map(([k]) => k)
          .join(', ')
        setProcessWarning(
          `Algunas secciones no se detectaron en el HTML generado: ${missing}. El template puede estar incompleto.`,
        )
      }

      setStep('preview')
    } catch {
      stopPolling()
      setError('Error al verificar el estado de la generación')
      setStep('form')
    }
  }

  async function handleGenerate() {
    if (!prompt.trim()) {
      setError('El prompt es requerido')
      return
    }

    setError(null)
    setProcessWarning(null)
    setStep('loading')
    startProgressCycle()

    try {
      const res = await fetch('/api/stitch/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ industry, sections: selectedSections, prompt }),
      })

      if (!res.ok) {
        stopPolling()
        const data = (await res.json()) as { error: string; reason?: string }
        setError(data.reason ? `${data.error} (${data.reason})` : data.error)
        setStep('form')
        return
      }

      const { templateId } = (await res.json()) as { templateId: string; status: string }
      setJobTemplateId(templateId)

      // Iniciar polling
      pollIntervalRef.current = setInterval(() => pollStatus(templateId), POLL_INTERVAL_MS)
    } catch {
      stopPolling()
      setError('Error al conectar con el servidor')
      setStep('form')
    }
  }

  function handleCancel() {
    stopPolling()
    setStep('form')
    setError(null)
  }

  async function handleSave() {
    if (!generateResult || !jobTemplateId) return
    if (!templateName.trim()) {
      setError('El nombre del template es requerido')
      return
    }

    setError(null)
    setIsSaving(true)

    try {
      const res = await fetch('/api/stitch/generate/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          templateId: jobTemplateId,
          name: templateName.trim(),
          description: templateDescription.trim() || undefined,
        }),
      })

      if (!res.ok) {
        const data = (await res.json()) as { error: string }
        setError(data.error)
        return
      }

      const data = (await res.json()) as { id: string }
      setSavedTemplateId(data.id)
      setStep('done')
    } finally {
      setIsSaving(false)
    }
  }

  async function handleQueueSave() {
    if (!prompt.trim()) {
      setError('El prompt es requerido para guardar en cola')
      return
    }

    setError(null)
    setIsQueueing(true)

    try {
      const res = await fetch('/api/stitch/queue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          industry,
          styleId: selectedStyleId,
          sections: selectedSections,
          prompt: prompt.trim(),
        }),
      })

      const data = (await res.json()) as { job?: { id: string }; error?: string; jobId?: string }

      if (!res.ok) {
        setError(data.error ?? 'Error al guardar en cola')
        return
      }

      setQueuedJobId(data.job?.id ?? null)
    } catch {
      setError('Error al conectar con el servidor')
    } finally {
      setIsQueueing(false)
    }
  }

  if (step === 'done' && savedTemplateId) {
    return (
      <div className="border border-green-400/20 bg-green-400/10 rounded-lg p-6 text-green-400 text-sm">
        <p className="font-medium mb-3">Template guardado correctamente.</p>
        <p className="mb-4">
          Podés editarlo o activarlo para clientes desde la vista de detalle.
        </p>
        <div className="flex gap-3">
          <button
            onClick={() => router.push(`/templates/${savedTemplateId}`)}
            className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] transition-colors"
          >
            Ver template
          </button>
          <button
            onClick={() => {
              setStep('form')
              setGenerateResult(null)
              setTemplateName('')
              setTemplateDescription('')
              setPrompt('')
              setSavedTemplateId(null)
              setJobTemplateId(null)
              setProcessWarning(null)
            }}
            className="px-4 py-2 text-sm text-[#64748B] hover:text-[#94A3B8] transition-colors"
          >
            Generar otro
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Formulario de generación */}
      {(step === 'form' || step === 'loading' || step === 'preview' || step === 'save') && (
        <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 flex flex-col gap-5">
          <h2 className="text-sm font-semibold text-[#94A3B8] uppercase tracking-wide">
            Configurar generación
          </h2>

          {/* Industria */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-[#94A3B8]">
              Industria <span className="text-red-400">*</span>
            </label>
            <select
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              disabled={step === 'loading'}
              className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm focus:outline-none focus:border-[#8B5CF6] transition-colors disabled:opacity-50"
            >
              {INDUSTRY_VERTICALS.map(({ vertical, industries }) => (
                <optgroup key={vertical} label={vertical}>
                  {industries.map((ind) => (
                    <option key={ind} value={ind}>
                      {ind}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>

          {/* Secciones */}
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium text-[#94A3B8]">Secciones</span>
            <div className="flex flex-wrap gap-3">
              {SECTIONS.map(({ key, label }) => (
                <label key={key} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedSections.includes(key)}
                    onChange={() => toggleSection(key)}
                    disabled={step === 'loading'}
                    className="accent-[#8B5CF6]"
                  />
                  <span className="text-sm text-[#CBD5E1]">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Prompt */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-[#94A3B8]">
              Prompt <span className="text-red-400">*</span>
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              disabled={step === 'loading'}
              rows={3}
              placeholder="Ej: Un diseño moderno y minimalista para una peluquería urbana, con paleta oscura y tipografía sans-serif."
              className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors resize-none disabled:opacity-50"
            />
          </div>

          {/* Estilo visual */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-[#94A3B8]">Estilo visual</label>
            <select
              value={selectedStyleId}
              onChange={(e) => setSelectedStyleId(e.target.value)}
              disabled={step === 'loading'}
              className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm focus:outline-none focus:border-[#8B5CF6] transition-colors disabled:opacity-50"
            >
              {TEMPLATE_STYLES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          {queuedJobId && (
            <div className="px-4 py-3 border border-green-400/20 bg-green-400/10 rounded-lg text-green-400 text-sm">
              Job guardado en cola.{' '}
              <a href="/templates/cola" className="underline hover:no-underline">
                Ver cola de diseños →
              </a>
            </div>
          )}

          <div className="flex items-center gap-3">
            <button
              onClick={handleGenerate}
              disabled={step === 'loading'}
              className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Generar con Stitch
            </button>
            <button
              onClick={handleQueueSave}
              disabled={step === 'loading' || isQueueing}
              className="px-4 py-2 bg-[#1E293B] text-[#94A3B8] text-sm font-medium rounded-lg hover:bg-[#1E293B]/80 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isQueueing ? 'Encolando...' : 'Guardar en cola'}
            </button>
            {step === 'preview' && (
              <span className="text-xs text-[#64748B]">Template generado — podés ajustar y regenerar</span>
            )}
          </div>
        </div>
      )}

      {/* Estado de carga */}
      {step === 'loading' && (
        <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-8 flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-2 border-[#8B5CF6] border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-[#94A3B8] text-center max-w-xs">
            {PROGRESS_MESSAGES[progressMsgIndex]}
          </p>
          <p className="text-xs text-[#475569]">Stitch puede tardar hasta 3 minutos en generar un diseño único.</p>
          <button
            onClick={handleCancel}
            className="px-3 py-1.5 text-xs text-[#64748B] border border-[#1E293B] rounded hover:text-[#94A3B8] transition-colors"
          >
            Cancelar
          </button>
        </div>
      )}

      {/* Preview */}
      {step === 'preview' && generateResult && (
        <div className="flex flex-col gap-4">
          {processWarning && (
            <div className="px-4 py-3 rounded-lg border bg-yellow-400/10 border-yellow-400/20 text-yellow-400 text-sm">
              {processWarning}
              <p className="mt-1 text-xs opacity-70">No se puede guardar hasta resolver el problema.</p>
            </div>
          )}

          <div className="border border-[#1E293B] rounded-lg overflow-hidden">
            <div className="px-4 py-2 bg-[#0F172A] border-b border-[#1E293B] flex items-center justify-between">
              <span className="text-xs text-[#64748B]">Preview</span>
              {!processWarning && (
                <button
                  onClick={() => setStep('save')}
                  className="px-3 py-1.5 bg-[#8B5CF6] text-white text-xs font-medium rounded hover:bg-[#7C3AED] transition-colors"
                >
                  Guardar como template
                </button>
              )}
            </div>
            <iframe
              srcDoc={generateResult.processedHtml}
              sandbox="allow-scripts"
              className="w-full h-[600px] bg-white"
              title="Preview del template generado"
            />
          </div>
        </div>
      )}

      {/* Formulario de guardado */}
      {step === 'save' && generateResult && (
        <div className="border border-[#1E293B] rounded-lg bg-[#0F172A] p-6 flex flex-col gap-4">
          <h2 className="text-sm font-semibold text-[#94A3B8] uppercase tracking-wide">
            Guardar template
          </h2>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-[#94A3B8]">
              Nombre <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              maxLength={200}
              placeholder="Ej: Peluquería Urbana Dark"
              className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-[#94A3B8]">Descripción</label>
            <textarea
              value={templateDescription}
              onChange={(e) => setTemplateDescription(e.target.value)}
              rows={2}
              placeholder="Descripción opcional del template"
              className="px-3 py-2 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors resize-none"
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <div className="flex items-center gap-3">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isSaving ? 'Guardando...' : 'Confirmar y guardar'}
            </button>
            <button
              onClick={() => setStep('preview')}
              disabled={isSaving}
              className="px-4 py-2 text-sm text-[#64748B] hover:text-[#94A3B8] transition-colors"
            >
              Volver al preview
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
