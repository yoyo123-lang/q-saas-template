/**
 * Para API keys de integraciones externas (IntegrationConfig).
 *
 * Solo server-side. Nunca importar en Client Components ni middleware (Edge Runtime).
 *
 * Formato almacenado: `{iv_base64}:{ciphertext_base64}:{authTag_base64}`
 */
import { createCipheriv, createDecipheriv, randomBytes } from 'crypto'

const ALGORITHM = 'aes-256-gcm'
const IV_LENGTH = 12  // bytes — recomendado por NIST para GCM
const AUTH_TAG_LENGTH = 16  // bytes — default de GCM

function getEncryptionKey(): Buffer {
  const secret = process.env.INTEGRATION_ENCRYPTION_KEY
  if (!secret) {
    throw new Error('INTEGRATION_ENCRYPTION_KEY is not set. Generate with: openssl rand -base64 32')
  }
  // Decodifica el secret en base64 → 32 bytes
  const key = Buffer.from(secret, 'base64')
  if (key.length !== 32) {
    throw new Error(`INTEGRATION_ENCRYPTION_KEY must decode to exactly 32 bytes, got ${key.length}`)
  }
  return key
}

/**
 * Encripta un texto plano (API key) con AES-256-GCM.
 * Genera un IV único por cada llamada — nunca reusar IV con la misma key.
 *
 * @returns string en formato `{iv}:{ciphertext}:{authTag}` (todo base64)
 */
export function encrypt(plaintext: string): string {
  const key = getEncryptionKey()
  const iv = randomBytes(IV_LENGTH)
  const cipher = createCipheriv(ALGORITHM, key, iv, { authTagLength: AUTH_TAG_LENGTH })

  const encrypted = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final(),
  ])
  const authTag = cipher.getAuthTag()

  return [
    iv.toString('base64'),
    encrypted.toString('base64'),
    authTag.toString('base64'),
  ].join(':')
}

/**
 * Desencripta un string encriptado con `encrypt()`.
 * Verifica la integridad del ciphertext via auth tag de GCM.
 *
 * @throws Error si el formato es inválido o si el auth tag no coincide
 */
export function decrypt(encoded: string): string {
  const key = getEncryptionKey()
  const parts = encoded.split(':')
  if (parts.length !== 3) {
    throw new Error('Invalid encrypted format: expected {iv}:{ciphertext}:{authTag}')
  }
  const ivB64 = parts[0]!
  const ciphertextB64 = parts[1]!
  const authTagB64 = parts[2]!
  const iv = Buffer.from(ivB64, 'base64')
  const ciphertext = Buffer.from(ciphertextB64, 'base64')
  const authTag = Buffer.from(authTagB64, 'base64')

  const decipher = createDecipheriv(ALGORITHM, key, iv, { authTagLength: AUTH_TAG_LENGTH })
  decipher.setAuthTag(authTag)

  const decrypted = Buffer.concat([
    decipher.update(ciphertext),
    decipher.final(),
  ])
  return decrypted.toString('utf8')
}

/**
 * Extrae los últimos N caracteres de una API key para mostrar como hint.
 * Nunca almacenar la key completa en texto plano — solo este hint.
 *
 * @example keyHint('sk-ant-abc123xyz', 4) → '...xyz'
 */
export function keyHint(apiKey: string, chars = 4): string {
  return `...${apiKey.slice(-chars)}`
}
