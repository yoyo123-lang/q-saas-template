'use server'

import { getPrisma } from '@/lib/prisma'
import { trackEvent } from '@/lib/analytics/events'
import { getAuthenticatedUser } from '@/lib/supabase/auth-helpers'
import type { ActionResult } from '@/lib/actions/listings'

// ─── Actions ─────────────────────────────────────────────────

/**
 * Toggles a listing's favorite status for the current user.
 *
 * Returns { success: false, redirect: '/login' } if not authenticated.
 * Returns { success: true, data: { isFavorited: boolean } } otherwise.
 *
 * Uses upsert + delete to avoid race conditions from non-atomic findUnique+create.
 */
export async function toggleFavorite(
  listingId: string
): Promise<ActionResult<{ isFavorited: boolean }> & { redirect?: string }> {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { success: false, error: 'No autorizado.', redirect: '/login' }

    const prisma = getPrisma()

    // Verify the listing exists before creating a favorite
    const listing = await prisma.listing.findUnique({
      where: { id: listingId },
      select: { id: true },
    })
    if (!listing) return { success: false, error: 'Activo no encontrado.' }

    // Check current state
    const existing = await prisma.favorite.findUnique({
      where: { userId_listingId: { userId: user.id, listingId } },
      select: { id: true },
    })

    if (existing) {
      await prisma.favorite.delete({
        where: { userId_listingId: { userId: user.id, listingId } },
      })
      void trackEvent('FAVORITE_REMOVED', 'listing', listingId, user.id)
      return { success: true, data: { isFavorited: false } }
    }

    // Use upsert to handle concurrent requests safely (unique constraint prevents duplicates)
    await prisma.favorite.upsert({
      where: { userId_listingId: { userId: user.id, listingId } },
      create: { userId: user.id, listingId },
      update: {}, // noop if already exists
    })
    void trackEvent('FAVORITE_ADDED', 'listing', listingId, user.id)
    return { success: true, data: { isFavorited: true } }
  } catch (e) {
    console.error('[toggleFavorite]', e instanceof Error ? e.message : String(e))
    return { success: false, error: 'Error al actualizar favoritos.' }
  }
}
