'use client'

import { useTransition, useState, useRef, useEffect } from 'react'
import { updateOutputTemplate } from '@/lib/actions'

interface OutputTemplateFormProps {
  agentNumber: number
  outputTemplate: unknown
}

const EMPTY_TEMPLATE = {
  deliverableType: '',
  titleTemplate: '',
  sections: [
    {
      id: 'section-1',
      title: '',
      prompt: '',
    },
  ],
}

/**
 * Editor de JSON para el output template de un agente.
 * Valida que el JSON sea parseable antes de permitir guardar.
 * Usa Server Action `updateOutputTemplate` via useTransition.
 */
export function OutputTemplateForm({ agentNumber, outputTemplate }: OutputTemplateFormProps) {
  const [isPending, startTransition] = useTransition()

  const initialValue =
    outputTemplate != null ? JSON.stringify(outputTemplate, null, 2) : ''

  const [value, setValue] = useState(initialValue)
  const [jsonError, setJsonError] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  function validateJson(raw: string): boolean {
    if (!raw.trim()) {
      setJsonError(null)
      return true
    }
    try {
      JSON.parse(raw)
      setJsonError(null)
      return true
    } catch (err) {
      setJsonError(err instanceof Error ? err.message : 'JSON inválido')
      return false
    }
  }

  function handleChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    const raw = e.target.value
    setValue(raw)
    validateJson(raw)
  }

  function handleInsertTemplate() {
    const pretty = JSON.stringify(EMPTY_TEMPLATE, null, 2)
    setValue(pretty)
    setJsonError(null)
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()

    if (!validateJson(value)) return

    setError(null)
    setSuccess(false)

    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      try {
        await updateOutputTemplate(formData)
        setSuccess(true)
        if (timerRef.current) clearTimeout(timerRef.current)
        timerRef.current = setTimeout(() => setSuccess(false), 5000)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error desconocido')
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <input type="hidden" name="agentNumber" value={agentNumber} />
      <input type="hidden" name="outputTemplate" value={value} />

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <label
            htmlFor={`outputTemplate-${agentNumber}`}
            className="text-[#94A3B8] text-sm font-medium"
          >
            Output template (JSON)
          </label>
          <button
            type="button"
            onClick={handleInsertTemplate}
            className="text-xs text-[#8B5CF6] hover:text-[#A78BFA] transition-colors"
          >
            Insertar template vacío
          </button>
        </div>

        <textarea
          id={`outputTemplate-${agentNumber}`}
          value={value}
          onChange={handleChange}
          rows={16}
          placeholder="{}"
          className={`w-full resize-y bg-[#1E293B] text-[#F8FAFC] font-mono text-sm rounded-lg border focus:outline-none p-4 leading-relaxed placeholder:text-[#64748B] ${
            jsonError
              ? 'border-[#EF4444] focus:border-[#EF4444]'
              : 'border-[#334155] focus:border-[#8B5CF6]'
          }`}
        />

        {jsonError && (
          <p className="text-[#F87171] text-xs font-mono">{jsonError}</p>
        )}

        <p className="text-[#64748B] text-xs">
          Esquema:{' '}
          <code className="text-[#94A3B8]">
            {'{ "deliverableType": string, "titleTemplate": string, "sections": [{ "id": string, "title": string, "prompt": string }] }'}
          </code>
        </p>
      </div>

      {error && (
        <p className="text-[#F87171] text-sm bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-lg px-4 py-2">
          {error}
        </p>
      )}
      {success && (
        <p className="text-[#34D399] text-sm bg-[#10B981]/10 border border-[#10B981]/30 rounded-lg px-4 py-2">
          Output template guardado correctamente
        </p>
      )}

      <button
        type="submit"
        disabled={isPending || jsonError !== null}
        className="self-start px-5 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isPending ? 'Guardando…' : 'Guardar output template'}
      </button>
    </form>
  )
}
