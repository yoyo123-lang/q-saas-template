-- ============================================================
-- ROLLBACK 004 — Listing Metrics
-- ============================================================

DROP TABLE IF EXISTS public.listing_metrics CASCADE;

DROP TYPE IF EXISTS metric_type   CASCADE;
DROP TYPE IF EXISTS metric_source CASCADE;
