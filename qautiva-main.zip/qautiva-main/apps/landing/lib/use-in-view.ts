'use client'

import { useEffect, useRef, useState } from 'react'

/**
 * Detecta cuando un elemento entra en el viewport.
 * Una vez visible, queda visible (triggerOnce = true por defecto).
 */
export function useInView(threshold = 0.15) {
  const ref = useRef<HTMLElement | null>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0]
        if (entry?.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold },
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [threshold])

  return { ref, isVisible }
}
