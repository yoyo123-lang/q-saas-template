import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { OrderStatus } from '@qautiva/db'
import { getProfileOrUnauthorized, getOrderPartiesOrError } from '@/lib/api/marketplace-helpers'

// Estados de orden en los que se permiten mensajes.
// COMPLETED y CANCELLED cierran el hilo de comunicación.
const MESSAGING_ALLOWED_STATUSES: OrderStatus[] = [
  OrderStatus.PENDING,
  OrderStatus.ACCEPTED,
  OrderStatus.DELIVERED,
  OrderStatus.IN_REVIEW,
  OrderStatus.REVISION,
  OrderStatus.DISPUTED,
]

// ── GET /api/marketplace/orders/[id]/messages ─────────────────────────────────
// Lista mensajes de la orden en orden cronológico ascendente con paginación.
// Solo las partes de la orden (anunciante y editor del medio) pueden acceder.

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } },
): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()
  const { id: orderId } = params

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  const sp = request.nextUrl.searchParams
  const cursorParam = sp.get('cursor')
  const takeRaw = parseInt(sp.get('take') ?? '50', 10)
  if (isNaN(takeRaw)) {
    return NextResponse.json({ error: 'take debe ser un número entero' }, { status: 400 })
  }
  const take = Math.min(100, Math.max(1, takeRaw))

  const partiesResult = await getOrderPartiesOrError(orderId, profile.id)
  if (partiesResult.error) return partiesResult.response

  type MessageRow = { id: string; orderId: string; senderId: string; content: string; createdAt: Date }
  type ProfileRow = { id: string; displayName: string | null }

  try {
    const messages: MessageRow[] = await prisma.orderMessage.findMany({
      where: {
        orderId,
        ...(cursorParam ? { createdAt: { gt: new Date(cursorParam) } } : {}),
      },
      select: { id: true, orderId: true, senderId: true, content: true, createdAt: true },
      orderBy: { createdAt: 'asc' },
      take,
    })

    // Resolver displayNames — senderId no tiene @relation en el schema
    const senderIds = [...new Set(messages.map((m: MessageRow) => m.senderId))]
    const senderProfiles: ProfileRow[] = await prisma.userProfile.findMany({
      where: { id: { in: senderIds } },
      select: { id: true, displayName: true },
    })
    const senderMap = Object.fromEntries(senderProfiles.map((p: ProfileRow) => [p.id, p.displayName]))

    const result = messages.map((m: MessageRow) => ({
      ...m,
      senderDisplayName: senderMap[m.senderId] ?? null,
    }))

    // Cursor para la siguiente página: createdAt del último mensaje
    const lastMessage = messages[messages.length - 1]
    const nextCursor = messages.length === take && lastMessage ? lastMessage.createdAt.toISOString() : null

    console.info('[GET /api/marketplace/orders/:id/messages]', {
      reqId,
      orderId,
      userId: profile.id,
      count: messages.length,
    })

    return NextResponse.json({ messages: result, nextCursor })
  } catch (err) {
    console.error('[GET /api/marketplace/orders/:id/messages] Prisma query failed', {
      reqId,
      orderId,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al obtener los mensajes' }, { status: 500 })
  }
}

// ── POST /api/marketplace/orders/[id]/messages ────────────────────────────────
// Envía un mensaje en la orden.
// Solo las partes de la orden pueden escribir, y solo en órdenes activas.

type SendMessageBody = {
  content: string
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } },
): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()
  const { id: orderId } = params

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: SendMessageBody
  try {
    body = (await request.json()) as SendMessageBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { content } = body

  if (!content || typeof content !== 'string' || content.trim().length === 0) {
    return NextResponse.json({ error: 'El contenido del mensaje no puede estar vacío' }, { status: 400 })
  }
  if (content.trim().length > 5000) {
    return NextResponse.json({ error: 'El mensaje no puede superar los 5000 caracteres' }, { status: 400 })
  }

  const partiesResult = await getOrderPartiesOrError(orderId, profile.id)
  if (partiesResult.error) return partiesResult.response
  const { parties } = partiesResult

  // Solo se pueden enviar mensajes en órdenes activas
  if (!MESSAGING_ALLOWED_STATUSES.includes(parties.status)) {
    return NextResponse.json(
      { error: 'No se pueden enviar mensajes en una orden completada o cancelada' },
      { status: 409 },
    )
  }

  try {
    const message = await prisma.orderMessage.create({
      data: { orderId, senderId: profile.id, content: content.trim() },
      select: { id: true, orderId: true, senderId: true, content: true, createdAt: true },
    })

    // Resolver displayName del sender desde el perfil ya cargado en auth
    const senderProfile = await prisma.userProfile.findUnique({
      where: { id: profile.id },
      select: { displayName: true },
    })

    console.info('[POST /api/marketplace/orders/:id/messages]', {
      reqId,
      orderId,
      messageId: message.id,
      senderId: profile.id,
    })

    return NextResponse.json(
      { message: { ...message, senderDisplayName: senderProfile?.displayName ?? null } },
      { status: 201 },
    )
  } catch (err) {
    console.error('[POST /api/marketplace/orders/:id/messages] Prisma create failed', {
      reqId,
      orderId,
      senderId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al enviar el mensaje' }, { status: 500 })
  }
}
