export const metadata = {
  title: 'Política de privacidad — Qapitaliza',
  description: 'Cómo recopilamos, usamos y protegemos tu información en Qapitaliza.',
}

export default function PrivacidadPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-slate-50 mb-2">Política de privacidad</h1>
      <p className="text-sm text-slate-500 mb-10">Última actualización: marzo 2026</p>

      <div className="space-y-8 text-slate-300">
        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">1. Información que recopilamos</h2>
          <p className="leading-relaxed">
            Recopilamos información que nos proporcionás directamente al registrarte (nombre, email, contraseña), información de perfil que cargás, datos de las publicaciones que creás, y mensajes que enviás a través de la plataforma.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">2. Cómo usamos tu información</h2>
          <p className="leading-relaxed">
            Usamos tu información para operar y mejorar la plataforma, procesar tus publicaciones y consultas, enviarte notificaciones relacionadas con tu actividad, y cumplir con obligaciones legales. No vendemos tu información a terceros.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">3. Compartir información</h2>
          <p className="leading-relaxed">
            Compartimos tu información solo cuando es necesario para operar el servicio (por ejemplo, con Supabase como proveedor de base de datos y autenticación), cuando lo requerís vos (como al iniciar una consulta con un vendedor), o cuando la ley lo exige.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">4. Seguridad</h2>
          <p className="leading-relaxed">
            Implementamos medidas técnicas y organizacionales para proteger tu información, incluyendo cifrado en tránsito (HTTPS), acceso restringido a datos sensibles, y revisiones periódicas de seguridad.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">5. Cookies</h2>
          <p className="leading-relaxed">
            Utilizamos cookies esenciales para el funcionamiento de la sesión y cookies analíticas para entender cómo se usa la plataforma. Podés deshabilitar las cookies analíticas desde la configuración de tu navegador.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">6. Tus derechos</h2>
          <p className="leading-relaxed">
            Tenés derecho a acceder, corregir o eliminar tu información personal. Para ejercer estos derechos, contactanos en{' '}
            <span className="text-amber-500">privacidad@qapitaliza.com</span>.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">7. Retención de datos</h2>
          <p className="leading-relaxed">
            Conservamos tu información mientras tu cuenta esté activa. Si eliminás tu cuenta, tus datos personales son eliminados en un plazo de 30 días, salvo que la ley exija conservarlos por más tiempo.
          </p>
        </section>
      </div>
    </div>
  )
}
