'use server'

import { revalidatePath } from 'next/cache'
import { prisma } from '@qautiva/db'
import type { AiProvider } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { encrypt, keyHint } from '@/lib/encryption'

// ── Types ──────────────────────────────────────────────────────────────────────

export type ActionState = { ok: true } | { ok: false; error: string }

const VALID_AI_PROVIDERS: AiProvider[] = ['ANTHROPIC', 'OPENAI', 'GOOGLE_GEMINI']

// ── Helpers ────────────────────────────────────────────────────────────────────

/**
 * Elimina los vectores XSS más peligrosos de un string HTML.
 * Uso interno para templates de email admin-only.
 * Si en el futuro usuarios no-admin pueden editar HTML, migrar a sanitize-html.
 */
function sanitizeEmailHtml(html: string): string {
  return html
    // Eliminar bloques <script>...</script> (con contenido)
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    // Eliminar <iframe>, <object>, <embed>, <link>, <meta>, <base>
    .replace(/<\s*(iframe|object|embed|link|meta|base)\b[^>]*(?:\/>|>.*?<\/\1>|>)/gis, '')
    // Eliminar event handlers inline (onload=, onclick=, etc.)
    .replace(/\s+on\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '')
    // Eliminar javascript: en href/src
    .replace(/\b(href|src|action)\s*=\s*["']?\s*javascript:[^"'\s>]*/gi, '')
}

function parseIntField(value: FormDataEntryValue | null, fieldName: string): number {
  const raw = typeof value === 'string' ? parseInt(value, 10) : NaN
  if (isNaN(raw)) {
    throw new Error(`${fieldName} debe ser un número entero`)
  }
  return raw
}

function parseCheckbox(value: FormDataEntryValue | null): boolean {
  return value === 'on' || value === 'true' || value === '1'
}

function parseDateField(value: FormDataEntryValue | null): Date | null {
  if (typeof value !== 'string' || !value.trim()) return null
  const date = new Date(value)
  if (isNaN(date.getTime())) return null
  return date
}

// ── saveTrialConfig ────────────────────────────────────────────────────────────

/**
 * Guarda la configuración de trial (upsert singleton id=1).
 */
export async function saveTrialConfig(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const isActive = parseCheckbox(formData.get('isActive'))
    const tokenAmount = parseIntField(formData.get('tokenAmount'), 'tokenAmount')
    const maxDurationDays = parseIntField(formData.get('maxDurationDays'), 'maxDurationDays')
    const validFrom = parseDateField(formData.get('validFrom'))
    const validUntil = parseDateField(formData.get('validUntil'))
    const qautivaProvider = formData.get('qautivaProvider')
    const qautivaModel = formData.get('qautivaModel')
    const geminiImageModel = formData.get('geminiImageModel')

    if (tokenAmount <= 0) {
      return { ok: false, error: 'tokenAmount debe ser mayor a 0' }
    }
    if (maxDurationDays <= 0) {
      return { ok: false, error: 'maxDurationDays debe ser mayor a 0' }
    }
    if (
      typeof qautivaProvider !== 'string' ||
      !VALID_AI_PROVIDERS.includes(qautivaProvider as AiProvider)
    ) {
      return { ok: false, error: 'Provider de IA inválido' }
    }
    if (typeof qautivaModel !== 'string' || !qautivaModel.trim()) {
      return { ok: false, error: 'El modelo de IA es requerido' }
    }
    if (typeof geminiImageModel !== 'string' || !geminiImageModel.trim()) {
      return { ok: false, error: 'El modelo de Gemini para imágenes es requerido' }
    }
    if (validFrom && validUntil && validFrom >= validUntil) {
      return { ok: false, error: '"Válido desde" debe ser anterior a "Válido hasta"' }
    }

    await prisma.trialConfig.upsert({
      where: { id: 1 },
      create: {
        id: 1,
        isActive,
        tokenAmount,
        maxDurationDays,
        validFrom,
        validUntil,
        qautivaProvider: qautivaProvider as AiProvider,
        qautivaModel: qautivaModel.trim(),
        geminiImageModel: (geminiImageModel as string).trim(),
      },
      update: {
        isActive,
        tokenAmount,
        maxDurationDays,
        validFrom,
        validUntil,
        qautivaProvider: qautivaProvider as AiProvider,
        qautivaModel: qautivaModel.trim(),
        geminiImageModel: (geminiImageModel as string).trim(),
      },
    })

    console.info('[admin:configuracion] trialConfig actualizado')
  } catch (err) {
    console.error('[admin:configuracion] error en saveTrialConfig:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/configuracion')
  return { ok: true }
}

// ── saveTelegramConfig ─────────────────────────────────────────────────────────

/**
 * Guarda la configuración del bot de Telegram (upsert singleton id=1).
 */
export async function saveTelegramConfig(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const botEnabled = parseCheckbox(formData.get('botEnabled'))
    const llmModel = formData.get('llmModel')
    const rateLimitPerHour = parseIntField(formData.get('rateLimitPerHour'), 'rateLimitPerHour')
    const systemPromptOverrideRaw = formData.get('systemPromptOverride')
    const systemPromptOverride =
      typeof systemPromptOverrideRaw === 'string' && systemPromptOverrideRaw.trim()
        ? systemPromptOverrideRaw.trim()
        : null

    if (typeof llmModel !== 'string' || !llmModel.trim()) {
      return { ok: false, error: 'El modelo LLM es requerido' }
    }
    if (rateLimitPerHour <= 0) {
      return { ok: false, error: 'rateLimitPerHour debe ser mayor a 0' }
    }

    await prisma.telegramConfig.upsert({
      where: { id: 1 },
      create: {
        id: 1,
        botEnabled,
        llmModel: llmModel.trim(),
        rateLimitPerHour,
        systemPromptOverride,
      },
      update: {
        botEnabled,
        llmModel: llmModel.trim(),
        rateLimitPerHour,
        systemPromptOverride,
      },
    })

    console.info('[admin:configuracion] telegramConfig actualizado')
  } catch (err) {
    console.error('[admin:configuracion] error en saveTelegramConfig:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/configuracion')
  return { ok: true }
}

// ── saveIntegrationConfig ──────────────────────────────────────────────────────

/**
 * Guarda la configuración de una integración externa (upsert por service).
 * Si se provee rawKey, la encripta y guarda el keyHint.
 */
export async function saveIntegrationConfig(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const service = formData.get('service')
    const isActive = parseCheckbox(formData.get('isActive'))
    const rawKey = formData.get('rawKey')

    if (typeof service !== 'string' || !service.trim()) {
      return { ok: false, error: 'Servicio requerido' }
    }

    const updateData: {
      isActive: boolean
      encryptedKey?: string
      keyHint?: string
    } = { isActive }

    if (typeof rawKey === 'string' && rawKey.trim()) {
      updateData.encryptedKey = encrypt(rawKey.trim())
      updateData.keyHint = keyHint(rawKey.trim())
    }

    await prisma.integrationConfig.upsert({
      where: { service: service.trim() },
      create: {
        service: service.trim(),
        ...updateData,
      },
      update: updateData,
    })

    console.info(`[admin:configuracion] integrationConfig actualizado — service=${service}`)
  } catch (err) {
    console.error('[admin:configuracion] error en saveIntegrationConfig:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/configuracion')
  return { ok: true }
}

// ── saveFeeConfig ──────────────────────────────────────────────────────────────

/**
 * Actualiza un FeeConfig por id.
 */
export async function saveFeeConfig(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    const feePercentageRaw = formData.get('feePercentage')
    const isActive = parseCheckbox(formData.get('isActive'))

    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }
    if (typeof feePercentageRaw !== 'string') {
      return { ok: false, error: 'feePercentage requerido' }
    }

    const feePercentage = parseFloat(feePercentageRaw)
    if (isNaN(feePercentage) || feePercentage < 0 || feePercentage > 100) {
      return { ok: false, error: 'feePercentage debe estar entre 0 y 100' }
    }

    const existing = await prisma.feeConfig.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'FeeConfig no encontrado' }
    }

    await prisma.feeConfig.update({
      where: { id: id.trim() },
      data: { feePercentage, isActive },
    })

    console.info(`[admin:configuracion] feeConfig actualizado — id=${id}`)
  } catch (err) {
    console.error('[admin:configuracion] error en saveFeeConfig:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/configuracion')
  return { ok: true }
}

// ── saveNotificationTemplate ───────────────────────────────────────────────────

/**
 * Actualiza un NotificationTemplate por id.
 */
export async function saveNotificationTemplate(
  prevState: ActionState | null,
  formData: FormData,
): Promise<ActionState> {
  await requireAdminSession()

  try {
    const id = formData.get('id')
    const subject = formData.get('subject')
    const bodyHtml = formData.get('bodyHtml')
    const isActive = parseCheckbox(formData.get('isActive'))

    if (typeof id !== 'string' || !id.trim()) {
      return { ok: false, error: 'id requerido' }
    }
    if (typeof subject !== 'string' || !subject.trim()) {
      return { ok: false, error: 'El asunto no puede estar vacío' }
    }
    if (typeof bodyHtml !== 'string') {
      return { ok: false, error: 'bodyHtml requerido' }
    }

    const existing = await prisma.notificationTemplate.findUnique({
      where: { id: id.trim() },
      select: { id: true },
    })
    if (!existing) {
      return { ok: false, error: 'Template no encontrado' }
    }

    await prisma.notificationTemplate.update({
      where: { id: id.trim() },
      data: {
        subject: subject.trim(),
        bodyHtml: sanitizeEmailHtml(bodyHtml),
        isActive,
      },
    })

    console.info(`[admin:configuracion] notificationTemplate actualizado — id=${id}`)
  } catch (err) {
    console.error('[admin:configuracion] error en saveNotificationTemplate:', err)
    const message = err instanceof Error ? err.message : 'Error desconocido'
    return { ok: false, error: message }
  }

  revalidatePath('/configuracion')
  return { ok: true }
}
