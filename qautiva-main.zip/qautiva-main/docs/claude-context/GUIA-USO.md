# Guía de uso — Documentos de contexto para Claude

> Estos documentos están diseñados para pegarlos al inicio de una conversación
> con Claude (claude.ai) y darle contexto completo sobre el proyecto Qautiva.

---

## Documentos disponibles

| Archivo | Cuándo usarlo | Tamaño aprox. |
|---------|---------------|---------------|
| `PROYECTO.md` | **Siempre.** Es el contexto base del proyecto. | Corto (~2K tokens) |
| `ARQUITECTURA.md` | Cuando la conversación involucre decisiones técnicas, debugging, diseño de features, o código. | Medio (~4K tokens) |
| `ESTADO-ACTUAL.md` | Cuando necesites hablar sobre qué hay hecho, qué falta, o planificar próximos pasos. | Medio (~3K tokens) |

---

## Combinaciones recomendadas

### Conversación de negocio / producto
> "Quiero discutir pricing", "Revisemos el flujo de onboarding", "Ideas para nuevas features"

Pegá: **PROYECTO.md**

---

### Conversación técnica general
> "Necesito ayuda con un bug", "Cómo implementar X feature", "Revisemos la arquitectura"

Pegá: **PROYECTO.md** + **ARQUITECTURA.md**

---

### Planificación / roadmap
> "Qué debería hacer primero en la Etapa 4", "Priorizar las tareas pendientes"

Pegá: **PROYECTO.md** + **ESTADO-ACTUAL.md**

---

### Revisión técnica profunda
> "Revisá la seguridad del sistema de auth", "Cómo optimizar el bot de Telegram"

Pegá: **PROYECTO.md** + **ARQUITECTURA.md** + **ESTADO-ACTUAL.md**

---

## Cómo pegar los documentos

### Opción 1: Copiar y pegar al inicio del chat

```
[Pegá el contenido de PROYECTO.md]

[Pegá el contenido de ARQUITECTURA.md si aplica]

---

Mi consulta: [tu pregunta o pedido]
```

### Opción 2: Subir como archivos adjuntos

Claude.ai permite subir archivos. Subí los .md que necesites y después escribí tu consulta.

### Opción 3: Proyecto de Claude

Creá un proyecto en Claude.ai con estos archivos como "knowledge base". Así no necesitás pegarlos cada vez.

---

## Tips para mejores respuestas

1. **Sé específico.** En lugar de "revisá la seguridad", decí "revisá la seguridad del endpoint POST /api/onboarding — ¿hay riesgo de IDOR?"

2. **Dá contexto del archivo.** Si estás trabajando en un archivo específico, pegá las partes relevantes del código junto con el contexto.

3. **Pedí formato de salida.** "Respondeme con una tabla de pros/cons", "Dame el código para copiar directo", "Listá los pasos numerados".

4. **Usá ESTADO-ACTUAL.md para continuidad.** Si retomás trabajo después de un tiempo, este doc te pone al día rápido.

5. **Actualizá estos docs.** Cuando avances etapas o cambies decisiones importantes, actualizá ESTADO-ACTUAL.md para que las próximas conversaciones tengan contexto correcto.

---

## Mantenimiento

Estos documentos se actualizan manualmente. Cuando hagas cambios significativos al proyecto:

- **Nuevo feature o etapa completada** → Actualizar `ESTADO-ACTUAL.md`
- **Cambio de stack o arquitectura** → Actualizar `ARQUITECTURA.md`
- **Cambio de modelo de negocio** → Actualizar `PROYECTO.md`

La fuente de verdad técnica sigue siendo `docs/ARCHITECTURE.md` en el repo. Estos documentos son un resumen optimizado para conversaciones con Claude.
