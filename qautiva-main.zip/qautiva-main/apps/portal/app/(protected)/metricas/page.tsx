import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { MetricsCards } from '@/components/MetricsCards'
import dynamic from 'next/dynamic'

const MetricsChart = dynamic(
  () => import('@/components/MetricsChart').then((m) => ({ default: m.MetricsChart })),
  { ssr: false, loading: () => <div className="h-64 bg-[#0F172A] rounded-lg animate-pulse" /> },
)
import { CampaignCard } from '@/components/CampaignCard'

export const metadata: Metadata = { title: 'Métricas — Qautiva' }

function formatChartDate(date: Date): string {
  return date.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })
}

export default async function MetricasPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  const orgId = user?.app_metadata?.org_id as string | undefined

  if (!orgId) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-4">Métricas</h1>
        <p className="text-[#94A3B8]">No hay un proyecto asignado a tu cuenta.</p>
      </div>
    )
  }

  const thirtyDaysAgo = new Date()
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

  const sixtyDaysAgo = new Date()
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60)

  const [currentMetrics, prevMetrics] = await Promise.all([
    prisma.metric.findMany({
      where: { organizationId: orgId, date: { gte: thirtyDaysAgo } },
      orderBy: { date: 'asc' },
      select: {
        date: true,
        webVisits: true,
        consultations: true,
        adSpendGoogle: true,
        adSpendMeta: true,
        mediaReads: true,
      },
    }),
    prisma.metric.findMany({
      where: {
        organizationId: orgId,
        date: { gte: sixtyDaysAgo, lt: thirtyDaysAgo },
      },
      select: { webVisits: true },
    }),
  ])

  if (currentMetrics.length === 0) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-4">Métricas</h1>
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">
            Tus métricas aparecen acá cuando tu negocio esté lanzado y las campañas activas.
          </p>
        </div>
      </div>
    )
  }

  // Totales del período actual
  const webVisitsTotal = currentMetrics.reduce((acc, m) => acc + m.webVisits, 0)
  const consultationsTotal = currentMetrics.reduce((acc, m) => acc + m.consultations, 0)
  const adSpendGoogle = currentMetrics.reduce((acc, m) => acc + m.adSpendGoogle, 0)
  const adSpendMeta = currentMetrics.reduce((acc, m) => acc + m.adSpendMeta, 0)
  const mediaReadsTotal = currentMetrics.reduce((acc, m) => acc + m.mediaReads, 0)

  // Período anterior (para trend de visitas)
  const webVisitsPrevMonth = prevMetrics.reduce((acc, m) => acc + m.webVisits, 0)

  // Datos del gráfico
  const chartData = currentMetrics.map((m) => ({
    date: formatChartDate(m.date),
    visitas: m.webVisits,
    consultas: m.consultations,
  }))

  // Métricas de campañas (últimos valores de adSpend para estimar el gasto mensual)
  const lastGoogleSpend = Math.round(adSpendGoogle)
  const lastMetaSpend = Math.round(adSpendMeta)

  return (
    <div className="p-8 max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Dashboard de métricas</h1>
        <span className="text-[#64748B] text-sm bg-[#0F172A] border border-[#1E293B] px-3 py-1.5 rounded-lg">
          Últimos 30 días
        </span>
      </div>

      {/* Cards de métricas */}
      <div className="mb-6">
        <MetricsCards
          webVisitsTotal={webVisitsTotal}
          webVisitsPrevMonth={webVisitsPrevMonth}
          consultationsTotal={consultationsTotal}
          adSpendGoogle={lastGoogleSpend}
          adSpendMeta={lastMetaSpend}
          mediaReadsTotal={mediaReadsTotal}
        />
      </div>

      {/* Gráfico */}
      <div className="mb-6">
        <MetricsChart data={chartData} />
      </div>

      {/* Campañas activas */}
      {(lastGoogleSpend > 0 || lastMetaSpend > 0) && (
        <div>
          <h2 className="text-white font-semibold mb-3">Campañas activas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {lastGoogleSpend > 0 && (
              <CampaignCard
                platform="google"
                name="Campaña búsqueda"
                monthlySpend={lastGoogleSpend}
                isActive={true}
              />
            )}
            {lastMetaSpend > 0 && (
              <CampaignCard
                platform="meta"
                name="Campaña Instagram"
                monthlySpend={lastMetaSpend}
                isActive={true}
              />
            )}
          </div>
        </div>
      )}
    </div>
  )
}
