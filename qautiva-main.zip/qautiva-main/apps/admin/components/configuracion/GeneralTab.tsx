'use client'

import { useState } from 'react'
import { saveTrialConfig } from '@/app/(protected)/configuracion/actions'
import type { ActionState } from '@/app/(protected)/configuracion/actions'
import type { TrialConfig } from '@qautiva/db'
import { SubmitButton, StatusMessage } from './shared'

interface Props {
  trialConfig: TrialConfig | null
}


export function GeneralTab({ trialConfig }: Props) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  const validFrom = trialConfig?.validFrom?.toISOString().split('T')[0] ?? ''
  const validUntil = trialConfig?.validUntil?.toISOString().split('T')[0] ?? ''

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await saveTrialConfig(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="space-y-6 mt-6">
      {/* Sección Trial */}
      <section className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 space-y-4">
        <h2 className="text-white font-semibold text-base">Trial gratuito</h2>

        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            name="isActive"
            defaultChecked={trialConfig?.isActive ?? false}
            className="w-4 h-4 rounded border-[#1E293B] bg-[#0B0F1A] accent-[#8B5CF6]"
          />
          <span className="text-sm text-[#94A3B8]">Activar trial para nuevos usuarios</span>
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="tokenAmount" className="text-xs text-[#94A3B8] font-medium">
              Tokens por nuevo usuario
            </label>
            <input
              id="tokenAmount"
              type="number"
              name="tokenAmount"
              defaultValue={trialConfig?.tokenAmount ?? 50000}
              min={1}
              required
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="maxDurationDays" className="text-xs text-[#94A3B8] font-medium">
              Duración máxima (días)
            </label>
            <input
              id="maxDurationDays"
              type="number"
              name="maxDurationDays"
              defaultValue={trialConfig?.maxDurationDays ?? 14}
              min={1}
              required
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="validFrom" className="text-xs text-[#94A3B8] font-medium">
              Válido desde (opcional)
            </label>
            <input
              id="validFrom"
              type="date"
              name="validFrom"
              defaultValue={validFrom}
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="validUntil" className="text-xs text-[#94A3B8] font-medium">
              Válido hasta (opcional)
            </label>
            <input
              id="validUntil"
              type="date"
              name="validUntil"
              defaultValue={validUntil}
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>
        </div>
      </section>

      {/* Sección Modelo de IA */}
      <section className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 space-y-4">
        <h2 className="text-white font-semibold text-base">Modelo de IA para trial</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="qautivaProvider" className="text-xs text-[#94A3B8] font-medium">
              Proveedor
            </label>
            <select
              id="qautivaProvider"
              name="qautivaProvider"
              defaultValue={trialConfig?.qautivaProvider ?? 'ANTHROPIC'}
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            >
              <option value="ANTHROPIC">Anthropic</option>
              <option value="OPENAI">OpenAI</option>
              <option value="GOOGLE_GEMINI">Google Gemini</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="qautivaModel" className="text-xs text-[#94A3B8] font-medium">
              Modelo
            </label>
            <input
              id="qautivaModel"
              type="text"
              name="qautivaModel"
              defaultValue={trialConfig?.qautivaModel ?? 'claude-haiku-4-5-20251001'}
              placeholder="claude-haiku-4-5-20251001"
              required
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>
        </div>

        <p className="text-xs text-[#475569]">
          Las API keys se configuran como variables de entorno: <code className="text-[#8B5CF6]">ANTHROPIC_API_KEY</code> y <code className="text-[#8B5CF6]">OPENAI_API_KEY</code>
        </p>
      </section>

      {/* Sección Modelo Gemini para imágenes */}
      <section className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 space-y-4">
        <h2 className="text-white font-semibold text-base">Modelo Gemini para generación de logos</h2>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="geminiImageModel" className="text-xs text-[#94A3B8] font-medium">
            Modelo de imagen
          </label>
          <input
            id="geminiImageModel"
            type="text"
            name="geminiImageModel"
            defaultValue={trialConfig?.geminiImageModel ?? 'gemini-2.5-flash-image'}
            placeholder="gemini-2.5-flash-image"
            required
            className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6] max-w-md"
          />
        </div>

        <p className="text-xs text-[#475569]">
          Modelo de Gemini usado para generar logos en la etapa de Marca. La API key se configura via{' '}
          <code className="text-[#8B5CF6]">GOOGLE_GEMINI_API_KEY</code> (env var)
        </p>
      </section>

      <div className="flex items-center gap-4">
        <SubmitButton pending={isPending} />
        <StatusMessage state={state} />
      </div>
    </form>
  )
}
