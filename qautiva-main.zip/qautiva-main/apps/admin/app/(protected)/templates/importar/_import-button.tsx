'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { importWebTemplate } from '../actions'
import type { CreateActionState } from '../actions'

function ImportSubmitButton({ pending }: { pending: boolean }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="w-full px-3 py-1.5 bg-[#8B5CF6] text-white text-xs font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {pending ? 'Importando...' : 'Importar'}
    </button>
  )
}

interface ImportButtonProps {
  slug: string
}

export function ImportButton({ slug }: ImportButtonProps) {
  const router = useRouter()
  const [state, setState] = useState<CreateActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  useEffect(() => {
    if (state?.ok) {
      router.push(`/templates/${state.id}?imported=1`)
    }
  }, [state, router])

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await importWebTemplate(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <div>
      <form action={handleSubmit}>
        <input type="hidden" name="slug" value={slug} />
        <ImportSubmitButton pending={isPending} />
      </form>
      {state && !state.ok && (
        <p className="text-xs text-red-400 mt-1">{state.error}</p>
      )}
    </div>
  )
}
