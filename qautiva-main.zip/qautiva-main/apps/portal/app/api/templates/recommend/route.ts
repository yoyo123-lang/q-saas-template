import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { getRequiredSections } from '@/app/_lib/interview/section-mapper'

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

/**
 * GET /api/templates/recommend?sessionId=xxx
 *
 * Recomienda los 2 mejores templates para una sesión de entrevista web v2.
 * Scoring determinístico basado en industria, secciones requeridas y recomendación
 * por IndustryTemplate.
 *
 * @see ADR-0018 — Paso 2: Recomendación de templates
 */
export async function GET(request: NextRequest) {
  // 1. Auth
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  // 2. Validar sessionId
  const sessionId = request.nextUrl.searchParams.get('sessionId')
  if (!sessionId || !UUID_RE.test(sessionId)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // 3. Ownership: usuario → team → sesión
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  // 4. Cargar sesión con ownership check + datos del proyecto
  const session = await prisma.interviewSession.findFirst({
    where: {
      id: sessionId,
      teamId: { in: teamIds },
      project: { deletedAt: null },
    },
    select: {
      id: true,
      answers: true,
      project: {
        select: {
          industry: true,
        },
      },
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  const answers = (session.answers ?? {}) as Record<string, string>
  const industry = session.project?.industry ?? ''

  // 5. Obtener secciones requeridas de las respuestas
  const requiredSections = getRequiredSections(answers)

  // 6. Cargar templates activos + recomendación por industria en paralelo
  const [templates, industryTemplate] = await Promise.all([
    prisma.webTemplate.findMany({
      where: { status: 'ACTIVE' },
      select: {
        id: true,
        name: true,
        description: true,
        thumbnail: true,
        sections: true,
        compatibleIndustries: true,
        usageCount: true,
      },
      orderBy: { usageCount: 'desc' },
      take: 100,
    }),
    industry
      ? prisma.industryTemplate.findFirst({
          where: { name: industry },
          select: { webTemplate: true },
        })
      : null,
  ])

  const recommendedId = industryTemplate?.webTemplate ?? null

  // 7. Scoring determinístico
  const scored = templates.map((template) => {
    let score = 0
    const reasons: string[] = []

    // +3 si la industria es compatible
    const compatibleIndustries = (template.compatibleIndustries ?? []) as string[]
    if (
      industry &&
      compatibleIndustries.some(
        (ci) => ci.toLowerCase() === industry.toLowerCase(),
      )
    ) {
      score += 3
      reasons.push('Diseñado para tu rubro')
    }

    // +2 por cada sección requerida que el template tiene activa
    const templateSections = (template.sections ?? {}) as Record<string, boolean>
    let matchedSections = 0
    for (const section of requiredSections) {
      if (templateSections[section]) {
        matchedSections++
        score += 2
      }
    }
    if (matchedSections > 0) {
      reasons.push(
        `Incluye ${matchedSections} de las ${requiredSections.length} secciones que necesitás`,
      )
    }

    // +1 si es el recomendado por IndustryTemplate
    if (recommendedId && template.id === recommendedId) {
      score += 1
      reasons.push('Recomendado para tu industria')
    }

    return {
      id: template.id,
      name: template.name,
      description: template.description,
      thumbnail: template.thumbnail,
      score,
      reason: reasons.length > 0 ? reasons.join('. ') + '.' : 'Diseño versátil que se adapta a tu negocio.',
    }
  })

  // 8. Ordenar por score descendente, tomar top 2
  scored.sort((a, b) => b.score - a.score)
  const top = scored.slice(0, 2)

  return NextResponse.json(
    { ok: true, templates: top },
    {
      headers: {
        'Cache-Control': 'private, s-maxage=300',
      },
    },
  )
}
