import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { ALL_INDUSTRIES, TEMPLATE_STYLES } from '@qautiva/shared'

/**
 * Devuelve el styleId correspondiente para una industria que tiene `currentCount` templates DONE.
 * - 0 templates DONE → clean-professional (ronda 1)
 * - 1 template DONE → warm-organic (ronda 2)
 * - 2 templates DONE → bold-modern (ronda 3)
 */
function getNextStyleId(currentCount: number): string | null {
  const style = TEMPLATE_STYLES[currentCount]
  return style?.id ?? null
}

/**
 * POST /api/stitch/queue/factory
 *
 * Encola automáticamente todos los jobs faltantes para alcanzar targetCount templates
 * por cada industria. Nunca encola si ya existe un job QUEUED/GENERATING para esa
 * industria+estilo, ni si ya hay un template DONE con ese estilo para esa industria.
 *
 * Body: { targetCount: 1 | 2 | 3 }
 * Response: { enqueued: N, skipped: N, industries: [{ industry, reason }] }
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: { targetCount: number }
  try {
    body = (await req.json()) as { targetCount: number }
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { targetCount } = body

  if (!targetCount || ![1, 2, 3].includes(targetCount)) {
    return NextResponse.json({ error: 'targetCount debe ser 1, 2 o 3' }, { status: 400 })
  }

  // Obtener todos los templates con queueStatus en la DB
  // Hacemos una sola query para eficiencia en lugar de N queries por industria
  const existingTemplates = await prisma.webTemplate.findMany({
    where: {
      NOT: { queueStatus: null },
    },
    select: {
      id: true,
      compatibleIndustries: true,
      styleId: true,
      queueStatus: true,
    },
  })

  // Construir mapa: industria → { done: Set<styleId>, pending: Set<styleId> }
  type IndustryState = {
    doneStyles: Set<string>
    pendingStyles: Set<string>
  }

  const industryMap = new Map<string, IndustryState>()
  for (const industry of ALL_INDUSTRIES) {
    industryMap.set(industry, { doneStyles: new Set(), pendingStyles: new Set() })
  }

  for (const template of existingTemplates) {
    const industries = template.compatibleIndustries as string[]
    const styleId = template.styleId ?? ''
    if (!styleId) continue

    for (const industry of industries) {
      const state = industryMap.get(industry)
      if (!state) continue

      if (template.queueStatus === 'DONE') {
        state.doneStyles.add(styleId)
      } else if (template.queueStatus === 'QUEUED' || template.queueStatus === 'GENERATING') {
        state.pendingStyles.add(styleId)
      }
    }
  }

  const results: Array<{ industry: string; action: 'enqueued' | 'skipped'; reason?: string; styleId?: string }> = []
  const toCreate: Array<{ industry: string; styleId: string }> = []

  for (const industry of ALL_INDUSTRIES) {
    const state = industryMap.get(industry)!
    const doneCount = state.doneStyles.size

    if (doneCount >= targetCount) {
      results.push({ industry, action: 'skipped', reason: `Ya tiene ${doneCount} templates DONE` })
      continue
    }

    // Encolar los estilos faltantes hasta llegar a targetCount.
    // Iterar desde round=0 para detectar "huecos" (ej: warm-organic DONE pero clean-professional faltante).
    for (let round = 0; round < targetCount; round++) {
      const nextStyleId = getNextStyleId(round)
      if (!nextStyleId) {
        results.push({ industry, action: 'skipped', reason: `No hay más estilos disponibles (round ${round})` })
        break
      }

      // Saltar si ya hay un job pendiente para este estilo+industria
      if (state.pendingStyles.has(nextStyleId)) {
        results.push({
          industry,
          action: 'skipped',
          reason: `Ya hay un job QUEUED/GENERATING para estilo ${nextStyleId}`,
          styleId: nextStyleId,
        })
        continue
      }

      // Saltar si ya tiene un DONE con este estilo
      if (state.doneStyles.has(nextStyleId)) {
        results.push({
          industry,
          action: 'skipped',
          reason: `Ya tiene template DONE con estilo ${nextStyleId}`,
          styleId: nextStyleId,
        })
        continue
      }

      toCreate.push({ industry, styleId: nextStyleId })
      results.push({ industry, action: 'enqueued', styleId: nextStyleId })
    }
  }

  // Crear todos los jobs en un batch
  if (toCreate.length > 0) {
    const now = new Date()
    await prisma.webTemplate.createMany({
      data: toCreate.map(({ industry, styleId }) => ({
        // Prefijo __queue__ = template generado por la cola Stitch, no ingresado manualmente.
        // Se usa para filtrar en listings y distinguirlos de templates con nombre real.
        name: `__queue__${crypto.randomUUID()}`,
        compatibleIndustries: [industry],
        sections: {},
        queueStatus: 'QUEUED' as const,
        queuedAt: now,
        styleId,
      })),
    })
  }

  const enqueued = results.filter((r) => r.action === 'enqueued').length
  const skipped = results.filter((r) => r.action === 'skipped').length

  return NextResponse.json({
    enqueued,
    skipped,
    targetCount,
    results,
  })
}
