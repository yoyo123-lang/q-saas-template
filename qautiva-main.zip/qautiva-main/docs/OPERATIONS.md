# OPERATIONS — Runbooks y Procedimientos

> Qué hacer cuando algo falla en producción.

---

## Monitoreo

| Servicio | URL | Herramienta | Alerta |
|---------|-----|------------|--------|
| Landing | `https://qautiva.ar/api/health` | UptimeRobot | Email si down >5min |
| Admin | `https://admin.qautiva.ar/api/health` | UptimeRobot | Email si down >5min |
| Portal | `https://app.qautiva.ar/api/health` | UptimeRobot | Email si down >5min |
| Telegram Bot | — | UptimeRobot ping | Cuando implemente /health |

**Setup UptimeRobot (gratis):**
1. Ir a uptimerobot.com → New Monitor
2. Tipo: HTTP(S)
3. URL: `https://qautiva.ar/api/health`
4. Intervalo: 5 minutos
5. Notificación: Email del equipo

---

## Runbooks

### Bot de Telegram caído

**Síntomas:** Bot no responde a mensajes, `/status` sin respuesta.

**Diagnóstico:**
1. Verificar Railway dashboard → revisar logs del container
2. Buscar errores de conexión a BD o API de Telegram
3. Revisar si `TELEGRAM_BOT_TOKEN` sigue válido

**Recovery:**
```bash
# En Railway dashboard → Restart deployment
# O localmente:
cd services/telegram-bot
pnpm start
```

---

### DB connection pool exhausto

**Síntomas:** Errores `Error: too many connections` en logs de Vercel/Railway.

**Diagnóstico:**
1. Ir a Supabase dashboard → Settings → Database → Connection info
2. Ver conexiones activas: Supabase → Reports → Connections

**Recovery:**
```sql
-- Matar conexiones idle (en Supabase SQL editor)
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE state = 'idle'
  AND query_start < NOW() - INTERVAL '5 minutes';
```
Luego reiniciar deployments de Vercel para liberar conexiones de serverless.

---

### Contact form no envía notificaciones a Telegram

**Síntomas:** Formulario muestra éxito pero no llega notificación.

**Diagnóstico:**
1. Verificar logs de Vercel → `/api/contact`
2. Buscar `[contact] Timeout o error de red al notificar Telegram`
3. Verificar que `TELEGRAM_BOT_TOKEN` y `TELEGRAM_CHAT_ID` estén configurados en Vercel

**Recovery:**
1. Verificar variables de entorno en Vercel dashboard
2. Hacer un deploy manual si las vars cambiaron

---

### Cliente no puede ver su proyecto

**Síntomas:** El usuario ve 404 al intentar acceder a `/proyectos/[id]/progreso`.

**Diagnóstico:**
1. Verificar que el usuario tiene un `TeamMember` en la DB: `SELECT * FROM "TeamMember" WHERE "userId" = '<profileId>'`
2. Verificar que el proyecto existe y no está soft-deleted: `SELECT id, name, "deletedAt" FROM "Project" WHERE id = '<projectId>'`
3. Revisar logs de Vercel → buscar `[project-layout]` para ver si hay un error de DB
4. Verificar que `onboarding_complete = true` en `app_metadata` del usuario en Supabase Auth

**Recovery:**
- Si falta TeamMember: insertar la membresía manualmente o re-ejecutar el paso de onboarding
- Si el proyecto está soft-deleted por error: `UPDATE "Project" SET "deletedAt" = NULL WHERE id = '<projectId>'`

---

### Aprobación de entregable no funciona

**Síntomas:** El cliente hace click en "Aprobar" pero el estado no cambia, o recibe un error.

**Diagnóstico:**
1. Revisar logs de Vercel → buscar `[deliverable-action]` para ver el resultado
2. Verificar el status actual del deliverable: `SELECT id, status FROM "Deliverable" WHERE id = '<deliverableId>'`
   - Solo `SENT_TO_CLIENT` puede ser aprobado/rechazado (devuelve 409 si ya fue procesado)
3. Verificar que el usuario tiene team membership del proyecto asociado al deliverable
4. Si hay error de DB, buscar `[deliverable-action] Prisma update failed` en logs

**Recovery:**
- Si el status quedó en un estado intermedio, corregir manualmente: `UPDATE "Deliverable" SET status = 'SENT_TO_CLIENT' WHERE id = '<deliverableId>'`
- Si el problema es de permisos, verificar team membership del usuario

---

### Rollback de deploy (Vercel)

1. Ir a Vercel dashboard → Deployments
2. Identificar el último deployment estable
3. Click → "Promote to Production"

---

## Rotación de Secrets

### TELEGRAM_BOT_TOKEN comprometido

1. Ir a @BotFather en Telegram → `/mybots` → seleccionar bot → API Token → Revoke
2. Actualizar la variable en Railway (settings → variables)
3. Hacer redeploy del bot
4. Verificar que el bot responde

### Supabase Service Role Key comprometida

1. Ir a Supabase dashboard → Settings → API → Regenerate service_role key
2. Actualizar en todos los deployments que la usen (Railway, Vercel)
3. Verificar auth del admin funcional

### RECAPTCHA_SECRET_KEY comprometida

1. Ir a Google reCAPTCHA console → Regenerar secret key
2. Actualizar `RECAPTCHA_SECRET_KEY` en Vercel
3. Actualizar `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` si también cambió la site key
4. Hacer redeploy de landing

---

## Backup de Base de Datos

**Supabase Pro** incluye backups automáticos diarios (retención 30 días).

### Backup manual:
```bash
pg_dump "$DATABASE_URL" > backups/production-$(date +%Y%m%d-%H%M).sql
```

### Restore en staging:
```bash
psql "$STAGING_DATABASE_URL" < backups/production-YYYYMMDD.sql
# Verificar datos antes de restaurar en producción
```

### Verificar RLS después de restore:
```bash
# Ejecutar políticas RLS si se restauró en una BD limpia
psql "$DATABASE_URL" < packages/db/prisma/rls.sql
```

---

## Variables de Entorno por Ambiente

| Variable | Dev | Staging | Producción |
|----------|-----|---------|-----------|
| `NODE_ENV` | development | production | production |
| `NEXT_PUBLIC_SITE_URL` | http://localhost:3000 | https://staging.qautiva.ar | https://qautiva.ar |
| `RECAPTCHA_SECRET_KEY` | (omitir — se saltea en dev) | key de test | key de producción |
| `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` | key de test | key de test | 6Ld4VIYs... |
| `TELEGRAM_BOT_TOKEN` | bot de dev | bot de staging | bot de producción |
| `DATABASE_URL` | local postgres | supabase staging | supabase producción |

---

*Última actualización: 2026-03-10*
