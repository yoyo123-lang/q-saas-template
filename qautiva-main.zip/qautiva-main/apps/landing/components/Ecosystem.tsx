interface QBrand {
  name: string
  descriptor: string
  color: string
  highlight?: boolean
}

const BRANDS: QBrand[] = [
  { name: 'qobra', descriptor: 'CONSTRUCCIÓN', color: 'text-blue-400' },
  { name: 'qontacta', descriptor: 'CRM', color: 'text-emerald-400' },
  { name: 'qautiva', descriptor: 'MARKETING', color: 'text-accent', highlight: true },
  { name: 'qapitaliza', descriptor: 'INVERSIÓN', color: 'text-amber-400' },
]

export function Ecosystem() {
  return (
    <section
      id="ecosistema"
      className="bg-navy-900 py-12 border-t border-navy-800"
    >
      <div className="max-w-6xl mx-auto px-6 text-center">
        <p className="text-slate-400 text-sm mb-8">qautiva es parte de Q Company</p>

        <div className="flex flex-wrap justify-center gap-10">
          {BRANDS.map(({ name, descriptor, color, highlight }) => (
            <div key={name} className="flex flex-col items-center gap-1">
              <span
                className={`font-bold text-lg ${color} ${
                  highlight ? 'underline underline-offset-4 decoration-accent/40' : ''
                }`}
              >
                {name}
              </span>
              <span className="text-[10px] tracking-widest font-semibold text-slate-500">
                {descriptor}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
