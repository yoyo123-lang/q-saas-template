import NegocioClient from './client'

export default function NuevoProyectoPage() {
  return <NegocioClient />
}
