import { ImageResponse } from 'next/og'

export const runtime = 'edge'
export const alt = 'qautiva — Tu negocio online en una semana'
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

export default function OgImage() {
  return new ImageResponse(
    (
      <div
        style={{
          background: '#0B0F1A',
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          justifyContent: 'center',
          padding: '80px',
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        {/* Gradiente decorativo */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background:
              'radial-gradient(ellipse 70% 60% at 80% 50%, rgba(139,92,246,0.18) 0%, transparent 70%)',
          }}
        />

        {/* Wordmark */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
          <span style={{ color: '#ffffff', fontSize: '28px', fontWeight: 700 }}>qautiva</span>
          <span
            style={{
              color: '#64748b',
              fontSize: '14px',
              fontWeight: 600,
              letterSpacing: '4px',
              textTransform: 'uppercase',
            }}
          >
            Marketing
          </span>
        </div>

        {/* Headline */}
        <h1
          style={{
            color: '#ffffff',
            fontSize: '68px',
            fontWeight: 700,
            lineHeight: 1.1,
            margin: 0,
            marginBottom: '24px',
            maxWidth: '800px',
          }}
        >
          Tu negocio online en una semana
        </h1>

        {/* Subheadline */}
        <p
          style={{
            color: '#94a3b8',
            fontSize: '26px',
            margin: 0,
            maxWidth: '680px',
            lineHeight: 1.4,
          }}
        >
          Marca, web, campañas y medios propios. Todo con IA.
        </p>

        {/* Badge */}
        <div
          style={{
            display: 'flex',
            marginTop: '48px',
            background: 'rgba(139,92,246,0.15)',
            border: '1px solid rgba(139,92,246,0.4)',
            borderRadius: '8px',
            padding: '10px 20px',
          }}
        >
          <span style={{ color: '#a78bfa', fontSize: '18px', fontWeight: 600 }}>qautiva.ar</span>
        </div>
      </div>
    ),
    { ...size }
  )
}
