'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

// ── Tipos ─────────────────────────────────────────────────────────────────────

type Platform = {
  value: string
  label: string
  description: string
  urlPlaceholder: string
  urlLabel: string
  handleLabel?: string
  handlePlaceholder?: string
  metricsLabel: string
}

const PLATFORMS: Platform[] = [
  {
    value: 'WEBSITE',
    label: 'Sitio Web / Blog',
    description: 'Diario, revista digital, blog',
    urlPlaceholder: 'https://tusitioweb.com',
    urlLabel: 'URL del sitio',
    metricsLabel: 'Visitas mensuales',
  },
  {
    value: 'INSTAGRAM',
    label: 'Instagram',
    description: 'Posts, Stories, Reels',
    urlPlaceholder: 'https://instagram.com/tuusuario',
    urlLabel: 'URL del perfil',
    handleLabel: 'Handle',
    handlePlaceholder: '@tuusuario',
    metricsLabel: 'Seguidores',
  },
  {
    value: 'TIKTOK',
    label: 'TikTok',
    description: 'Videos cortos',
    urlPlaceholder: 'https://tiktok.com/@tuusuario',
    urlLabel: 'URL del perfil',
    handleLabel: 'Handle',
    handlePlaceholder: '@tuusuario',
    metricsLabel: 'Seguidores',
  },
  {
    value: 'YOUTUBE',
    label: 'YouTube',
    description: 'Videos y Shorts',
    urlPlaceholder: 'https://youtube.com/@tucanal',
    urlLabel: 'URL del canal',
    handleLabel: 'Handle del canal',
    handlePlaceholder: '@tucanal',
    metricsLabel: 'Suscriptores',
  },
  {
    value: 'TWITTER',
    label: 'X (Twitter)',
    description: 'Posts, hilos, menciones',
    urlPlaceholder: 'https://x.com/tuusuario',
    urlLabel: 'URL del perfil',
    handleLabel: 'Handle',
    handlePlaceholder: '@tuusuario',
    metricsLabel: 'Seguidores',
  },
  {
    value: 'FACEBOOK',
    label: 'Facebook',
    description: 'Página o perfil',
    urlPlaceholder: 'https://facebook.com/tupagina',
    urlLabel: 'URL de la página',
    handleLabel: 'Nombre de página',
    handlePlaceholder: 'Tu Página',
    metricsLabel: 'Seguidores',
  },
]

const PRODUCT_TYPES = [
  { value: 'ARTICLE', label: 'Artículo con enlace' },
  { value: 'LINK_INSERTION', label: 'Inserción de enlace' },
  { value: 'POST', label: 'Post en feed' },
  { value: 'STORY', label: 'Historia' },
  { value: 'REEL', label: 'Reel / Short / TikTok' },
  { value: 'MENTION', label: 'Mención de marca' },
  { value: 'THREAD', label: 'Hilo' },
  { value: 'VIDEO', label: 'Video dedicado' },
]

type ProductDraft = {
  type: string
  name: string
  description: string
  price: string
  deliveryDays: string
  includesWriting: boolean
}

function emptyProduct(): ProductDraft {
  return { type: '', name: '', description: '', price: '', deliveryDays: '7', includesWriting: false }
}

// ── Helpers de UI ─────────────────────────────────────────────────────────────

const inputClass =
  'w-full bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-[#334155] placeholder-[#475569] disabled:opacity-50'

const labelClass = 'text-white font-semibold block mb-2 text-sm'
const hintClass = 'text-[#64748B] text-xs mb-2'

function StepIndicator({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center gap-2 mb-8" aria-label={`Paso ${current} de ${total}`}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-colors ${
              i + 1 < current
                ? 'bg-[#34D399] text-[#0B0F1A]'
                : i + 1 === current
                  ? 'bg-[#60A5FA] text-[#0B0F1A]'
                  : 'bg-[#1E293B] text-[#64748B]'
            }`}
          >
            {i + 1 < current ? '✓' : i + 1}
          </div>
          {i < total - 1 && (
            <div className={`h-0.5 w-8 ${i + 1 < current ? 'bg-[#34D399]' : 'bg-[#1E293B]'}`} />
          )}
        </div>
      ))}
    </div>
  )
}

// ── Page / Wizard ─────────────────────────────────────────────────────────────

export default function NuevoMedioPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Paso 1
  const [platform, setPlatform] = useState<Platform | null>(null)

  // Paso 2
  const [url, setUrl] = useState('')
  const [handle, setHandle] = useState('')

  // Paso 3
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [country, setCountry] = useState('AR')
  const [language, setLanguage] = useState('es')
  const [followersCount, setFollowersCount] = useState('')
  const [domainAuthority, setDomainAuthority] = useState('')

  // Paso 4
  const [products, setProducts] = useState<ProductDraft[]>([emptyProduct()])

  // ── Navegación ──────────────────────────────────────────────────────────────

  function nextStep() {
    setError(null)

    if (step === 1 && !platform) {
      setError('Seleccioná una plataforma para continuar.')
      return
    }
    if (step === 2) {
      if (!url.trim()) {
        setError('La URL del medio es requerida.')
        return
      }
      try {
        new URL(url.trim())
      } catch {
        setError('Ingresá una URL válida (ej: https://tusitioweb.com).')
        return
      }
    }
    if (step === 3) {
      if (!name.trim() || name.trim().length < 3) {
        setError('El nombre debe tener al menos 3 caracteres.')
        return
      }
    }

    setStep((s) => s + 1)
  }

  function prevStep() {
    setError(null)
    setStep((s) => s - 1)
  }

  // ── Productos ───────────────────────────────────────────────────────────────

  function updateProduct(index: number, field: keyof ProductDraft, value: string | boolean) {
    setProducts((prev) => prev.map((p, i) => (i === index ? { ...p, [field]: value } : p)))
  }

  function addProduct() {
    setProducts((prev) => [...prev, emptyProduct()])
  }

  function removeProduct(index: number) {
    setProducts((prev) => prev.filter((_, i) => i !== index))
  }

  // ── Submit ──────────────────────────────────────────────────────────────────

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    // Validar al menos un producto válido
    const validProducts = products.filter(
      (p) => p.type && p.name.trim().length >= 3 && parseFloat(p.price) > 0 && parseInt(p.deliveryDays) > 0,
    )
    if (validProducts.length === 0) {
      setError('Agregá al menos un producto con tipo, nombre, precio y días de entrega.')
      return
    }

    setSubmitting(true)
    try {
      // 1. Crear el medio
      const mediumRes = await fetch('/api/marketplace/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: platform!.value,
          name: name.trim(),
          url: url.trim(),
          ...(handle.trim() ? { handle: handle.trim() } : {}),
          description: description.trim() || undefined,
          country: country || undefined,
          language: language || undefined,
          ...(followersCount ? { followersCount: parseInt(followersCount, 10) } : {}),
          ...(domainAuthority ? { domainAuthority: parseInt(domainAuthority, 10) } : {}),
        }),
      })

      const mediumData = (await mediumRes.json()) as { error?: string; medium?: { id: string } }

      if (!mediumRes.ok || !mediumData.medium) {
        setError(mediumData.error ?? 'No se pudo crear el medio.')
        return
      }

      const mediumId = mediumData.medium.id

      // 2. Crear productos en paralelo
      const productResults = await Promise.allSettled(
        validProducts.map((p) =>
          fetch('/api/marketplace/products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              mediumId,
              type: p.type,
              name: p.name.trim(),
              description: p.description.trim() || undefined,
              price: parseFloat(p.price),
              deliveryDays: parseInt(p.deliveryDays, 10),
              includesWriting: p.includesWriting,
            }),
          }),
        ),
      )

      const failedProducts = productResults.filter((r) => r.status === 'rejected').length
      if (failedProducts > 0) {
        setError(
          `Tu medio se creó pero ${failedProducts} producto(s) no pudieron guardarse. Podés agregarlos desde el panel de edición.`,
        )
        // Redirigir igual, el medio existe
      }

      router.push('/mis-medios')
    } catch {
      setError('No se pudo conectar con el servidor. Intentá de nuevo.')
    } finally {
      setSubmitting(false)
    }
  }

  // ── Render ──────────────────────────────────────────────────────────────────

  const STEP_LABELS = ['Plataforma', 'URL', 'Datos del medio', 'Productos']

  return (
    <div className="p-6 max-w-2xl mx-auto">
      {/* Breadcrumb */}
      <nav aria-label="Navegación" className="text-sm text-[#64748B] mb-6 flex items-center gap-2">
        <Link href="/mis-medios" className="hover:text-[#94A3B8] transition-colors">
          Mis Medios
        </Link>
        <span>/</span>
        <span className="text-[#94A3B8]">Nuevo medio</span>
      </nav>

      <h1 className="text-2xl font-bold text-white mb-2">Agregar un medio</h1>
      <p className="text-[#64748B] text-sm mb-6">
        Paso {step} de {STEP_LABELS.length} — {STEP_LABELS[step - 1]}
      </p>

      <StepIndicator current={step} total={STEP_LABELS.length} />

      <form onSubmit={handleSubmit}>
        {/* ── PASO 1: Plataforma ── */}
        {step === 1 && (
          <div>
            <p className={labelClass}>¿Qué tipo de medio querés agregar?</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {PLATFORMS.map((p) => (
                <button
                  key={p.value}
                  type="button"
                  onClick={() => { setPlatform(p); setError(null) }}
                  className={`text-left p-4 rounded-xl border transition-colors ${
                    platform?.value === p.value
                      ? 'border-[#60A5FA] bg-[#1E3A5F]'
                      : 'border-[#1E293B] bg-[#0F172A] hover:border-[#334155]'
                  }`}
                  aria-pressed={platform?.value === p.value}
                >
                  <p className="text-white font-semibold text-sm">{p.label}</p>
                  <p className="text-[#64748B] text-xs mt-0.5">{p.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ── PASO 2: URL y handle ── */}
        {step === 2 && platform && (
          <div className="flex flex-col gap-5">
            <div>
              <label htmlFor="url" className={labelClass}>{platform.urlLabel} <span className="text-red-400">*</span></label>
              <input
                id="url"
                type="url"
                placeholder={platform.urlPlaceholder}
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className={inputClass}
                required
              />
            </div>
            {platform.handleLabel && (
              <div>
                <label htmlFor="handle" className={labelClass}>{platform.handleLabel}</label>
                <input
                  id="handle"
                  type="text"
                  placeholder={platform.handlePlaceholder}
                  value={handle}
                  onChange={(e) => setHandle(e.target.value)}
                  className={inputClass}
                />
              </div>
            )}
          </div>
        )}

        {/* ── PASO 3: Datos del medio ── */}
        {step === 3 && platform && (
          <div className="flex flex-col gap-5">
            <div>
              <label htmlFor="name" className={labelClass}>Nombre del medio <span className="text-red-400">*</span></label>
              <input
                id="name"
                type="text"
                placeholder="Ej: Blog de Marketing Digital"
                maxLength={100}
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={inputClass}
                required
              />
            </div>

            <div>
              <label htmlFor="description" className={labelClass}>Descripción</label>
              <p className={hintClass}>Contale a los anunciantes qué temas tratás, quién es tu audiencia.</p>
              <textarea
                id="description"
                rows={3}
                maxLength={1000}
                placeholder="Ej: Blog sobre marketing digital y growth hacking para startups en Latam..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className={`${inputClass} resize-y`}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="country" className={labelClass}>País principal</label>
                <select
                  id="country"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className={inputClass}
                >
                  <option value="AR">Argentina</option>
                  <option value="MX">México</option>
                  <option value="CO">Colombia</option>
                  <option value="CL">Chile</option>
                  <option value="UY">Uruguay</option>
                  <option value="PE">Perú</option>
                  <option value="ES">España</option>
                  <option value="US">Estados Unidos</option>
                </select>
              </div>
              <div>
                <label htmlFor="language" className={labelClass}>Idioma</label>
                <select
                  id="language"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className={inputClass}
                >
                  <option value="es">Español</option>
                  <option value="en">Inglés</option>
                  <option value="pt">Portugués</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="followersCount" className={labelClass}>
                {platform.metricsLabel} <span className="text-[#64748B] font-normal">(aproximado)</span>
              </label>
              <input
                id="followersCount"
                type="number"
                min="0"
                placeholder="Ej: 25000"
                value={followersCount}
                onChange={(e) => setFollowersCount(e.target.value)}
                className={inputClass}
              />
            </div>

            {platform.value === 'WEBSITE' && (
              <div>
                <label htmlFor="domainAuthority" className={labelClass}>Domain Authority <span className="text-[#64748B] font-normal">(0-100)</span></label>
                <input
                  id="domainAuthority"
                  type="number"
                  min="0"
                  max="100"
                  placeholder="Ej: 35"
                  value={domainAuthority}
                  onChange={(e) => setDomainAuthority(e.target.value)}
                  className={inputClass}
                />
              </div>
            )}
          </div>
        )}

        {/* ── PASO 4: Productos ── */}
        {step === 4 && (
          <div className="flex flex-col gap-4">
            <p className={hintClass}>
              Agregá los productos que ofrecés. Podés agregar más desde el panel de edición después.
            </p>

            {products.map((product, index) => (
              <div key={index} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <p className="text-white font-semibold text-sm">Producto {index + 1}</p>
                  {products.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeProduct(index)}
                      className="text-xs text-red-400 hover:text-red-300 transition-colors"
                      aria-label={`Eliminar producto ${index + 1}`}
                    >
                      Eliminar
                    </button>
                  )}
                </div>

                <div>
                  <label htmlFor={`type-${index}`} className={labelClass}>Tipo <span className="text-red-400">*</span></label>
                  <select
                    id={`type-${index}`}
                    value={product.type}
                    onChange={(e) => updateProduct(index, 'type', e.target.value)}
                    className={inputClass}
                    required
                  >
                    <option value="">Seleccioná el tipo</option>
                    {PRODUCT_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor={`pname-${index}`} className={labelClass}>Nombre <span className="text-red-400">*</span></label>
                  <input
                    id={`pname-${index}`}
                    type="text"
                    placeholder="Ej: Artículo de 600 palabras con 2 enlaces dofollow"
                    maxLength={100}
                    value={product.name}
                    onChange={(e) => updateProduct(index, 'name', e.target.value)}
                    className={inputClass}
                    required
                  />
                </div>

                <div>
                  <label htmlFor={`pdesc-${index}`} className={labelClass}>Descripción <span className="text-[#64748B] font-normal">(opcional)</span></label>
                  <textarea
                    id={`pdesc-${index}`}
                    rows={2}
                    maxLength={1000}
                    placeholder="Qué incluye, condiciones, restricciones..."
                    value={product.description}
                    onChange={(e) => updateProduct(index, 'description', e.target.value)}
                    className={`${inputClass} resize-none`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor={`price-${index}`} className={labelClass}>Precio (ARS) <span className="text-red-400">*</span></label>
                    <input
                      id={`price-${index}`}
                      type="number"
                      min="1"
                      step="1"
                      placeholder="Ej: 15000"
                      value={product.price}
                      onChange={(e) => updateProduct(index, 'price', e.target.value)}
                      className={inputClass}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor={`days-${index}`} className={labelClass}>Días de entrega <span className="text-red-400">*</span></label>
                    <input
                      id={`days-${index}`}
                      type="number"
                      min="1"
                      max="90"
                      placeholder="Ej: 7"
                      value={product.deliveryDays}
                      onChange={(e) => updateProduct(index, 'deliveryDays', e.target.value)}
                      className={inputClass}
                      required
                    />
                  </div>
                </div>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={product.includesWriting}
                    onChange={(e) => updateProduct(index, 'includesWriting', e.target.checked)}
                    className="w-4 h-4 accent-[#60A5FA]"
                  />
                  <span className="text-[#94A3B8] text-sm">Incluye redacción del contenido</span>
                </label>
              </div>
            ))}

            <button
              type="button"
              onClick={addProduct}
              className="border border-dashed border-[#334155] text-[#64748B] hover:text-[#94A3B8] hover:border-[#475569] rounded-xl py-3 text-sm transition-colors"
            >
              + Agregar otro producto
            </button>
          </div>
        )}

        {/* Error */}
        {error && (
          <div role="alert" className="mt-4 bg-red-900/30 border border-red-700 rounded-xl px-4 py-3">
            <p className="text-red-300 text-sm">{error}</p>
          </div>
        )}

        {/* Navegación entre pasos */}
        <div className="flex justify-between mt-8 gap-3">
          {step > 1 ? (
            <button
              type="button"
              onClick={prevStep}
              disabled={submitting}
              className="px-5 py-2 rounded-xl text-sm font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] disabled:opacity-50 transition-colors"
            >
              ← Atrás
            </button>
          ) : (
            <Link
              href="/mis-medios"
              className="px-5 py-2 rounded-xl text-sm font-medium bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] transition-colors"
            >
              Cancelar
            </Link>
          )}

          {step < STEP_LABELS.length ? (
            <button
              type="button"
              onClick={nextStep}
              className="px-5 py-2 rounded-xl text-sm font-medium bg-[#1E3A5F] text-[#60A5FA] hover:bg-[#1E4D8C] transition-colors"
            >
              Continuar →
            </button>
          ) : (
            <button
              type="submit"
              disabled={submitting}
              aria-busy={submitting}
              className="px-5 py-2 rounded-xl text-sm font-medium bg-[#1E3A5F] text-[#60A5FA] hover:bg-[#1E4D8C] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {submitting ? 'Enviando…' : 'Enviar a revisión'}
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
