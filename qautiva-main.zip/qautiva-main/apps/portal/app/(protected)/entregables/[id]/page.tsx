import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { BrandApproval } from '@/components/BrandApproval'
import { WebPreview } from '@/components/WebPreview'
import Link from 'next/link'
import { ChevronLeft } from 'lucide-react'

// Tipos esperados en el campo JSON `content` de cada tipo de entregable
type BrandOptionContent = {
  id: string
  label: string
  logoUrl?: string
  colors: { hex: string; name: string }[]
  headingFont: string
  bodyFont: string
  brandPersonality: string[]
}

type BrandOptionsContent = {
  options: BrandOptionContent[]
  disclaimer?: string
}

type WebsiteContent = {
  previewUrl?: string
}

function isWebsiteContent(content: unknown): content is WebsiteContent {
  return typeof content === 'object' && content !== null
}

function isBrandOptionsContent(content: unknown): content is BrandOptionsContent {
  return (
    typeof content === 'object' &&
    content !== null &&
    'options' in content &&
    Array.isArray((content as BrandOptionsContent).options)
  )
}

// Render genérico para tipos que no tienen componente especializado
function GenericDeliverable({
  title,
  content,
  status,
}: {
  title: string
  content: unknown
  status: string
}) {
  const isApproved = status === 'CLIENT_APPROVED'

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold text-white mb-2">{title}</h1>
      {isApproved && (
        <span className="inline-block bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 text-xs font-medium px-2.5 py-1 rounded-full mb-6">
          Aprobado
        </span>
      )}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
        <pre className="text-[#94A3B8] text-sm whitespace-pre-wrap font-mono overflow-auto">
          {JSON.stringify(content, null, 2)}
        </pre>
      </div>
    </div>
  )
}

export default async function EntregableDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  const orgId = user?.app_metadata?.org_id as string | undefined
  if (!orgId) notFound()

  const deliverable = await prisma.deliverable.findFirst({
    where: { id: params.id, organizationId: orgId },
    select: {
      id: true,
      title: true,
      type: true,
      status: true,
      content: true,
      feedback: true,
      projectId: true,
    },
  })

  if (!deliverable) notFound()

  const canApprove = deliverable.status === 'SENT_TO_CLIENT'

  return (
    <div className="flex flex-col min-h-full">
      {/* Breadcrumb */}
      <div className="px-8 pt-6 pb-2">
        <Link
          href="/entregables"
          className="inline-flex items-center gap-1.5 text-[#64748B] text-sm hover:text-[#94A3B8] transition-colors duration-200"
        >
          <ChevronLeft size={14} aria-hidden="true" />
          Entregables
        </Link>
      </div>

      {/* Feedback previo si lo hay */}
      {deliverable.feedback && (
        <div className="mx-8 mb-2 bg-[#F59E0B]/10 border border-[#F59E0B]/30 rounded-lg px-4 py-3">
          <p className="text-[#F59E0B] text-xs font-medium mb-1">Tu feedback anterior:</p>
          <p className="text-[#94A3B8] text-sm">{deliverable.feedback}</p>
        </div>
      )}

      {/* Contenido principal según tipo */}
      {deliverable.type === 'BRAND_OPTIONS' && isBrandOptionsContent(deliverable.content) ? (
        <BrandApproval
          deliverableId={deliverable.id}
          projectId={deliverable.projectId ?? ''}
          title={deliverable.title}
          options={deliverable.content.options}
          disclaimer={deliverable.content.disclaimer}
          canApprove={canApprove}
        />
      ) : deliverable.type === 'WEBSITE_PREVIEW' && isWebsiteContent(deliverable.content) ? (
        <WebPreview
          deliverableId={deliverable.id}
          projectId={deliverable.projectId ?? ''}
          title={deliverable.title}
          previewUrl={deliverable.content.previewUrl}
          canApprove={canApprove}
        />
      ) : (
        <GenericDeliverable
          title={deliverable.title}
          content={deliverable.content}
          status={deliverable.status}
        />
      )}
    </div>
  )
}
