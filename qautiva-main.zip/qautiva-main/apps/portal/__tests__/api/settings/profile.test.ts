import { describe, it, expect, vi, beforeEach } from 'vitest'
vi.mock('next/cache', () => ({ revalidatePath: vi.fn(), revalidateTag: vi.fn() }))

const mockGetUser = vi.fn()
const mockUserProfileFindUnique = vi.fn()
const mockUserProfileUpdate = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: {
      findUnique: mockUserProfileFindUnique,
      update: mockUserProfileUpdate,
    },
  },
}))

const { PATCH } = await import('@/app/api/settings/profile/route')

const mockUser = { id: 'auth-user-1', email: 'test@test.com' }
const mockProfile = { id: 'profile-1' }

function makeRequest(body: unknown) {
  return new Request('http://localhost/api/settings/profile', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

describe('PATCH /api/settings/profile', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('retorna 401 sin autenticación', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: null })
    const res = await PATCH(makeRequest({ displayName: 'Juan' }))
    expect(res.status).toBe(401)
  })

  it('retorna 400 si no hay campos para actualizar', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    const res = await PATCH(makeRequest({}))
    expect(res.status).toBe(400)
  })

  it('retorna 400 si displayName es string vacío', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    const res = await PATCH(makeRequest({ displayName: '   ' }))
    expect(res.status).toBe(400)
  })

  it('retorna 404 si no encuentra el perfil', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockUserProfileFindUnique.mockResolvedValue(null)
    const res = await PATCH(makeRequest({ displayName: 'Juan' }))
    expect(res.status).toBe(404)
  })

  it('actualiza displayName y retorna ok', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockUserProfileFindUnique.mockResolvedValue(mockProfile)
    mockUserProfileUpdate.mockResolvedValue({ displayName: 'Juan', avatarUrl: null, email: 'test@test.com' })

    const res = await PATCH(makeRequest({ displayName: 'Juan' }))
    const body = await res.json()

    expect(res.status).toBe(200)
    expect(body.ok).toBe(true)
    expect(mockUserProfileUpdate).toHaveBeenCalledWith({
      where: { id: 'profile-1' },
      data: { displayName: 'Juan' },
      select: expect.any(Object),
    })
  })
})
