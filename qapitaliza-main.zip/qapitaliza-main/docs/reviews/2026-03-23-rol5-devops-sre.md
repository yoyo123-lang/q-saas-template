# Informe de Revisión — ROL 5: DevOps / SRE
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol 5 - DevOps / SRE

---

## Resumen ejecutivo

La configuración de SEO técnico y observabilidad es correcta. Se detectaron un hallazgo alto (robots.txt faltante) y un medio (catch sin logging) — ambos corregidos.

---

## Hallazgos

### [ALTO → CORREGIDO] Falta `robots.txt`

**Problema original:** No existía `src/app/robots.ts` ni `public/robots.txt`. Sin robots.txt, los crawlers de buscadores indexan todas las rutas incluyendo `/api/`, `/dashboard/`, y `/admin/`.

**Fix aplicado:** Creado `src/app/robots.ts` usando la API de Next.js `MetadataRoute.Robots`:

```typescript
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/', '/dashboard/', '/admin/'],
      },
    ],
    sitemap: `${BASE_URL}/sitemap.xml`,
  }
}
```

Bloquea `/api/`, `/dashboard/` y `/admin/` para todos los crawlers, y apunta al sitemap.

---

### [MEDIO → CORREGIDO] Catch blocks sin logging dificultaban debugging en producción

**Archivos:**
- `src/app/page.tsx` — catch original era `catch {}` sin logging
- `src/app/sitemap.ts` — mismo problema

**Fix aplicado:** Reemplazados con `catch (e) { console.error('[contexto]', e) }` para trazabilidad en logs de producción.

---

## Puntos positivos

- `sitemap.ts` con `revalidate = 3600` — no genera sitemap por request.
- `robots.ts` ahora bloquea rutas sensibles correctamente.
- `next.config.ts` con security headers (X-Frame-Options, nosniff, Referrer-Policy).
- Imágenes con `next/image` — optimización automática.
- Sin secrets hardcodeados en el código revisado.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| robots.txt faltante | ALTO | Corregido |
| Catch blocks sin logging | MEDIO | Corregido |
