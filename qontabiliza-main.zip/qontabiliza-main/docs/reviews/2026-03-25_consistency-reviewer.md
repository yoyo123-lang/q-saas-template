# Consistency Review
**Fecha:** 2026-03-25
**Archivos revisados:**
- `src/lib/tenant.ts`
- `prisma/schema.prisma`
- `supabase/migrations/20260325000000_add_domain_models.sql`
- `tests/unit/tenant.test.ts`

---

## Metodología
1. Cruzar `TENANT_SCOPED_MODELS` (tenant.ts) con modelos que tienen `organizationId` en schema.prisma
2. Cruzar campos en schema.prisma con tablas/columnas en la migración SQL
3. Verificar que los tests cubren la misma lista de modelos que el Set

---

## Hallazgos

### CRÍTICO

#### CON-01 — `TENANT_SCOPED_MODELS` incluye `"organization"` pero Organization NO tiene `organizationId`
**Archivo:** `src/lib/tenant.ts:8` vs `prisma/schema.prisma:106-131`
**Descripción:** Inconsistencia directa entre el Set y el schema:
- `tenant.ts:8`: `"organization"` está en el Set
- `schema.prisma:106-131`: `Organization` tiene campos `id`, `name`, `slug`, `fiscalData`, `settings`, `createdAt`, `updatedAt` — sin `organizationId`

El withTenant intentará inyectar `WHERE organizationId = '...'` en un modelo que no tiene ese campo → error de runtime.
**Fix sugerido:** Remover `"organization"` de `TENANT_SCOPED_MODELS`.

---

### ALTO

#### CON-02 — Dos definiciones del schema de BD — Prisma y SQL manual pueden divergir
**Archivo:** `prisma/schema.prisma` vs `supabase/migrations/20260325000000_add_domain_models.sql`
**Descripción:** El schema del dominio está definido dos veces. No hay un mecanismo de sincronización. Ejemplos de posibles divergencias:
- Un campo agregado en schema.prisma sin añadir al SQL (la BD no lo tiene → error en runtime)
- Un campo en el SQL que no está en schema.prisma (el ORM no lo conoce → dato inaccesible)
- Tipos diferentes para el mismo campo (ej: `Decimal` en Prisma vs `FLOAT` en SQL)

**Fix sugerido:** Eliminar la migración SQL manual y usar solo Prisma Migrate para gestionar el schema.

#### CON-03 — `TENANT_SCOPED_MODELS` tiene 16 modelos; tests hardcodean 17 incluyendo `"organization"`
**Archivo:** `tests/unit/tenant.test.ts:43-61` vs `src/lib/tenant.ts:7-25`
**Descripción:** El test en `tenant.test.ts` lista los mismos 16 modelos que están en el Set (incluyendo `"organization"`). Ambos están sincronizados entre sí, pero ambos están equivocados respecto al schema (Organization no tiene organizationId). Es una consistencia interna correcta basada en una premisa incorrecta.
**Fix sugerido:** Corregir tanto el Set como el test después de remover `"organization"`.

---

### MEDIO

#### CON-04 — `Sale` sin `subtotal`, `Invoice` con `subtotal` — inconsistencia en modelo de totales
**Archivo:** `prisma/schema.prisma:429-455` vs `prisma/schema.prisma:369-397`
**Descripción:** Las dos entidades principales de transacciones tienen estructura diferente:
- `Invoice`: `subtotal`, `taxAmount`, `total`
- `Sale`: `total`, `discountAmount` (sin `subtotal`, sin `taxAmount`)
- `InvoiceItem`: `subtotal`, `total`
- `SaleItem`: `total` (sin `subtotal`)

Esto hace imposible calcular el `subtotal` de una venta sin sumar todos sus items, mientras que en facturas está precalculado.
**Fix sugerido:** Unificar la estructura de totales entre `Sale` e `Invoice`. Agregar `subtotal` y `taxAmount` a `Sale`.

#### CON-05 — `CashRegister.openedById/closedById` sin relación → inconsistente con el patrón del resto del schema
**Archivo:** `prisma/schema.prisma:549-550`
**Descripción:** Todos los modelos que referencian `User` en el proyecto usan `@relation` explícita (Membership, Account, Session). CashRegister usa campos string sin relación. Es el único modelo que no sigue este patrón.
**Fix sugerido:** Agregar las relaciones `openedBy User @relation("openedBy", ...)` y `closedBy User? @relation("closedBy", ...)`.

#### CON-06 — `Product.sku` nullable con unique constraint — comportamiento diferente según DB
**Archivo:** `prisma/schema.prisma:225, 244`
**Descripción:** `sku String?` con `@@unique([organizationId, sku])`. En PostgreSQL, `NULL` no viola UNIQUE (múltiples NULLs son permitidos). En otras DBs el comportamiento varía. El Prisma schema refleja PostgreSQL semántics pero esto no está documentado y puede sorprender si se cambia de DB.
**Fix sugerido:** Agregar comentario explicando el comportamiento de NULL en el unique constraint.

---

### BAJO

#### CON-07 — `withTenant` intercepta `updateMany`/`deleteMany` pero no `update`/`delete` — inconsistencia de cobertura
**Archivo:** `src/lib/tenant.ts:75-86`
**Descripción:** Se interceptan las versiones "Many" pero no las individuales. No hay una razón documentada para esta asimetría. Alguien manteniendo el código podría asumir que `update` también está protegido.
**Fix sugerido:** O documentar explícitamente por qué `update`/`delete` individuales no están interceptados, o implementarlos para consistencia.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 1        |
| ALTO      | 2        |
| MEDIO     | 3        |
| BAJO      | 1        |
| **Total** | **7**    |
