'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'

type Preview = {
  id: string
  content: unknown
  status: string
}

type Props = {
  sessionId: string
  projectId: string
}

/**
 * Carga y renderiza el preview del sitio web generado por la IA.
 * Se muestra en la pantalla de COMPLETED de la etapa WEBSITE.
 */
export function WebsitePreviewView({ sessionId, projectId }: Props) {
  const [preview, setPreview] = useState<Preview | null | undefined>(undefined)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/interview/sessions/${sessionId}/website-preview`)
      if (!res.ok) {
        const err = await res.json().catch(() => null)
        setError(err?.error ?? 'No se pudo cargar el preview')
        return
      }
      const data = await res.json()
      setPreview(data.preview as Preview | null)
    } catch {
      setError('No se pudo cargar el preview')
    } finally {
      setLoading(false)
    }
  }, [sessionId])

  useEffect(() => {
    load()
  }, [load])

  if (loading) {
    return (
      <div className="mt-6 flex items-center gap-2 text-[#64748B] text-sm">
        <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M21 12a9 9 0 1 1-6.219-8.56" />
        </svg>
        Cargando preview...
      </div>
    )
  }

  if (error) {
    return (
      <div className="mt-6">
        <p className="text-[#64748B] text-sm mb-3">{error}</p>
        <button
          onClick={load}
          className="px-4 py-1.5 text-sm bg-[#1E293B] text-white rounded-lg hover:bg-[#334155] transition-colors"
        >
          Reintentar
        </button>
      </div>
    )
  }

  if (!preview) {
    return (
      <div className="mt-6 text-[#64748B] text-sm">
        El preview está siendo generado. Actualizá la página en unos segundos.
      </div>
    )
  }

  return (
    <div className="mt-6 bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
      <h3 className="text-white font-semibold mb-2">Tu sitio web está listo</h3>
      <p className="text-[#94A3B8] text-sm mb-4">
        La IA generó el contenido de tu sitio. Podés previsualizarlo y aprobarlo.
      </p>
      <Link
        href={`/proyectos/${projectId}/entregables/${preview.id}`}
        className="inline-block px-4 py-2 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#7C3AED] transition-colors"
      >
        Ver preview del sitio →
      </Link>
    </div>
  )
}
