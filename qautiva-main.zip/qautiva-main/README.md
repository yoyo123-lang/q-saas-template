# Sistema de Reglas para Vibecoding con Claude Code

> Plantilla de documentación para operar proyectos con estandar senior usando Claude Code como herramienta principal de desarrollo.

## Que incluye

### Nucleo

- `CLAUDE.md` — Reglas que Claude Code carga automaticamente al iniciar sesion
- `docs/REGLAS_PREVENTIVAS.md` — Reglas preventivas destiladas de los 6 roles de auditoria
- `docs/COMO_PEDIR.md` — Guia personal para formular pedidos a Claude Code

### Skills (comandos de proyecto)

| Comando | Que hace |
|---|---|
| `/project:sesion` | Mini-onboarding al arrancar sesion |
| `/project:cierre` | Cierre ordenado de sesion |
| `/project:diseño` | Contexto visual para crear/mejorar pantallas |

### Sub-agentes

| Agente | Modelo | Permisos | Uso |
|---|---|---|---|
| `explorador` | Sonnet | Solo lectura | Investigar el codebase |
| `implementador` | Sonnet | Edicion + bash | Escribir codigo siguiendo reglas preventivas |
| `revisor` | Opus | Solo lectura | Revision rapida post-implementacion |

### Documentacion del proyecto

- `docs/ARCHITECTURE.md` — Arquitectura y stack tecnologico
- `docs/CONVENTIONS.md` — Convenciones de codigo
- `docs/DEBUGGING.md` — Prevencion de errores silenciosos
- `docs/TESTING.md` — Estrategia de testing por capas
- `docs/SECURITY.md` — Reglas minimas de seguridad
- `docs/PLANNING.md` — Metodologia de planificacion
- `docs/GIT-WORKFLOW.md` — Branching, commits, PRs
- `docs/HOOKS.md` — Verificacion automatica con hooks
- `docs/MULTI-AGENT.md` — Trabajo paralelo, sesiones, sub-agentes custom
- `docs/DEPLOYMENT.md` — Ambientes y proceso de deploy
- `docs/OPERATIONS.md` — Monitoreo, alertas, incidentes
- `docs/MAINTENANCE.md` — Salud del codigo y deuda tecnica
- `docs/PERFORMANCE.md` — Optimizacion y umbrales
- `docs/KNOWN_ISSUES.md` — Errores conocidos y aprendizajes
- `docs/PRE_DEPLOY_AND_QA.md` — Build obligatorio y QA funcional
- `docs/API_STANDARDS.md` — Contratos REST y webhooks
- `docs/DATABASE.md` — Modelo, migraciones, backups
- `docs/I18N.md` — Internacionalizacion y localizacion
- `docs/FRONTEND_GUIDELINES.md` — Accesibilidad, responsive, estados de UI
- `docs/PR_TEMPLATE.md` — Template para pull requests
- `docs/AI_CODE_REVIEW.md` — Auditoria de codigo con IA
- `docs/ADOPCION_PROYECTOS_EXISTENTES.md` — Adopcion de proyectos con deuda tecnica
- `docs/CHECKLIST_SENIOR_AUDIT.md` — Scorecard de auditoria del template

### Roles de auditoria

- `docs/roles/REVIEW_ROLES.md` — Framework de revision multi-rol
- `docs/roles/tech/code-reviewer.md` — Calidad y mantenibilidad
- `docs/roles/tech/qa-engineer.md` — Robustez y casos borde
- `docs/roles/tech/security-auditor.md` — Vulnerabilidades y acceso
- `docs/roles/tech/security-audit-post-sprint.md` — Auditoria profunda post-sprint con IA
- `docs/roles/tech/security-scan-quick.md` — Scan rapido pre-deploy
- `docs/roles/tech/performance-engineer.md` — Bottlenecks y escalabilidad
- `docs/roles/tech/devops-sre.md` — Operabilidad y recuperacion
- `docs/roles/business/product-reviewer.md` — UX, SEO, producto
- `docs/roles/business/business-logic-reviewer.md` — Reglas de negocio, billing, permisos
- `docs/roles/business/data-analytics-reviewer.md` — Tracking, metricas, funnel

### Onboarding y playbooks

- `docs/onboarding/guia_onboarding.md` — Brainstorming de proyecto nuevo con Claude
- `docs/onboarding/playbook-micrositios-utilidad.md` — Redes de micrositios de utilidad
- `docs/onboarding/playbook-negocios-digitales-exterior.md` — Negocios digitales probados afuera

### Decisiones de arquitectura

- `docs/decisions/ADR-TEMPLATE.md` — Template para ADRs
- `docs/decisions/ADR-0001-sistema-documentacion-modular.md` — Por que la documentacion es modular

### Referencia

- `docs/referencia/security-rules-claudemd.md` — Razonamiento detras de las reglas de seguridad (OWASP, OpenSSF)

## Flujo recomendado de uso

### Si arrancas desde cero

```
ANTES DE ARRANCAR:
→ Mirar docs/COMO_PEDIR.md (machete de templates para prompts)
→ Si la idea no esta clara → charlarla en Claude.ai primero

AL ARRANCAR SESION:
→ /project:sesion (mini-onboarding)

DURANTE EL DESARROLLO:
→ Claude usa sub-agentes automaticamente:
  - explorador para investigar
  - implementador para codear (con REGLAS_PREVENTIVAS cargadas)
  - revisor para chequear antes de commit
→ Si necesitas una pantalla → /project:diseño

AL TERMINAR:
→ /project:cierre (actualiza SESSION_LOG, evalua KNOWN_ISSUES, verifica build)

ANTES DE DEPLOY:
→ Auditorias formales de docs/roles/
```

### Si el proyecto ya existe

1. Ejecutar `docs/ADOPCION_PROYECTOS_EXISTENTES.md` para crear linea base y brechas
2. Normalizar documentacion critica (arquitectura, testing, seguridad, operacion)
3. Avanzar con normalizacion de codigo en orden de riesgo

## Estado de la plantilla

Esta base cubre los dominios del checklist senior, pero sigue siendo una **plantilla**: cada proyecto debe completar valores concretos (versiones, URLs, owners, umbrales, comandos reales).
