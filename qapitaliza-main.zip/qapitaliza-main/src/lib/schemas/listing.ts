import { z } from 'zod'

// ─── Enums ───────────────────────────────────────────────────

export const listingTypeValues = ['WEBSITE', 'DOMAIN', 'SAAS', 'ECOMMERCE', 'PROJECT', 'OTHER'] as const
export const currencyValues = ['USD', 'ARS'] as const
export const metricSourceValues = ['SELF_REPORTED', 'SCREENSHOT', 'ANALYTICS_CONNECTED'] as const

// ─── Paso 1: Información básica ──────────────────────────────

export const stepBasicSchema = z.object({
  title: z.string().min(5, 'El título debe tener al menos 5 caracteres').max(120, 'Máximo 120 caracteres'),
  type: z.enum(listingTypeValues, { error: 'Seleccioná un tipo de activo' }),
  url: z.string().url('Ingresá una URL válida').optional().or(z.literal('')),
  description: z.string().min(50, 'La descripción debe tener al menos 50 caracteres').max(2000, 'Máximo 2000 caracteres'),
  askingPrice: z.number({ error: 'Ingresá un precio válido' }).positive('El precio debe ser mayor a 0'),
  currency: z.enum(currencyValues).default('USD'),
  techStack: z.array(z.string().max(30)).max(10, 'Máximo 10 tecnologías').default([]),
  tags: z.array(z.string().max(30)).max(8, 'Máximo 8 tags').default([]),
})

// ─── Paso 2: Métricas ────────────────────────────────────────

const metricEntrySchema = z.object({
  value: z.number().nonnegative().optional(),
  source: z.enum(metricSourceValues).default('SELF_REPORTED'),
  evidenceUrl: z.string().url('URL inválida').optional().or(z.literal('')),
})

export const stepMetricsSchema = z.object({
  // WEBSITE
  monthlyTraffic: metricEntrySchema.optional(),
  domainAuthority: metricEntrySchema.optional(),
  domainAge: metricEntrySchema.optional(),
  // DOMAIN
  registrationYear: metricEntrySchema.optional(),
  // SAAS / MVP
  mrr: metricEntrySchema.optional(),
  activeUsers: metricEntrySchema.optional(),
  churnRate: metricEntrySchema.optional(),
  // ECOMMERCE
  monthlyOrders: metricEntrySchema.optional(),
  monthlyRevenue: metricEntrySchema.optional(),
})

// ─── Paso 3: Imágenes ────────────────────────────────────────

const screenshotUrlSchema = z
  .string()
  .url('URL de imagen inválida')
  .refine((url) => url.startsWith('https://'), 'Las URLs de imagen deben usar HTTPS')

export const stepImagesSchema = z.object({
  screenshotUrls: z.array(screenshotUrlSchema).max(5, 'Máximo 5 imágenes').default([]),
})

// ─── Schema completo ─────────────────────────────────────────

export const createListingSchema = stepBasicSchema
  .merge(stepMetricsSchema)
  .merge(stepImagesSchema)

export const updateListingSchema = createListingSchema.partial()

// ─── Types ───────────────────────────────────────────────────

// Output types (after parse/transform — used in server actions)
export type StepBasicData = z.infer<typeof stepBasicSchema>
export type StepMetricsData = z.infer<typeof stepMetricsSchema>
export type StepImagesData = z.infer<typeof stepImagesSchema>
export type CreateListingData = z.infer<typeof createListingSchema>
export type UpdateListingData = z.infer<typeof updateListingSchema>

// Input types (before parse — used in react-hook-form so defaults can be undefined)
export type CreateListingInput = z.input<typeof createListingSchema>
export type UpdateListingInput = z.input<typeof updateListingSchema>
