import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'

/** Health check del portal. Verifica conectividad con la DB y con Supabase Auth. */
export async function GET() {
  const checks: Record<string, boolean> = {}

  // Check DB
  try {
    await prisma.$queryRaw`SELECT 1`
    checks.db = true
  } catch {
    checks.db = false
  }

  // Check Supabase Auth (verifica que el servicio responde, no que haya sesión válida)
  try {
    const cookieStore = cookies()
    const supabase = createServerClient(cookieStore)
    // getUser() sin sesión válida devuelve error "Auth session missing!" — el servicio responde
    const { error } = await supabase.auth.getUser()
    checks.auth = error === null || error.message === 'Auth session missing!'
  } catch {
    checks.auth = false
  }

  // Check Anthropic API key configurada (no hace llamada externa — solo verifica que exista)
  checks.anthropic = Boolean(process.env.ANTHROPIC_API_KEY)

  const allOk = Object.values(checks).every(Boolean)

  return NextResponse.json(
    { ok: allOk, service: 'portal', checks, timestamp: new Date().toISOString() },
    { status: allOk ? 200 : 503 },
  )
}
