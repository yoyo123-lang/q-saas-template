import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { createStitchInstance } from '@qautiva/stitch'

export const maxDuration = 120

type StepResult = { step: string; ok: boolean; durationMs: number; detail?: string; error?: string }

interface ToolClient {
  callTool: (tool: string, params: Record<string, unknown>) => Promise<unknown>
}

/**
 * GET /api/stitch/diagnostics
 *
 * Endpoint de diagnóstico síncrono: prueba la conexión al SDK de Stitch
 * paso a paso y devuelve el resultado completo como JSON.
 * NO usa waitUntil — espera la respuesta para poder devolver el error real.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  // Acepta auth de admin session O Bearer CRON_SECRET (para diagnóstico remoto)
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env['CRON_SECRET']
  const hasCronAuth = cronSecret && authHeader === `Bearer ${cronSecret}`

  if (!hasCronAuth) {
    try {
      await requireAdminSession()
    } catch {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }
  }

  const steps: StepResult[] = []
  let apiKey = ''

  // Paso 1: obtener una cuenta activa
  const stepStart1 = Date.now()
  try {
    const account = await prisma.stitchAccount.findFirst({
      where: { active: true },
      select: { id: true, apiKey: true, label: true, usedToday: true, dailyLimit: true },
      orderBy: { usedToday: 'asc' },
    })
    if (!account) {
      steps.push({ step: 'get_account', ok: false, durationMs: Date.now() - stepStart1, error: 'No hay cuentas activas' })
      return NextResponse.json({ steps, summary: 'FAIL: sin cuentas activas' })
    }
    apiKey = account.apiKey
    steps.push({
      step: 'get_account',
      ok: true,
      durationMs: Date.now() - stepStart1,
      detail: `id=${account.id} label=${account.label} used=${account.usedToday}/${account.dailyLimit} keyLen=${apiKey.length}`,
    })
  } catch (err) {
    steps.push({ step: 'get_account', ok: false, durationMs: Date.now() - stepStart1, error: serializeError(err) })
    return NextResponse.json({ steps, summary: 'FAIL: error obteniendo cuenta' })
  }

  // Paso 2: crear instancia del SDK
  const stepStart2 = Date.now()
  let client: ReturnType<typeof createStitchInstance> | null = null
  try {
    client = createStitchInstance(apiKey)
    steps.push({ step: 'create_instance', ok: true, durationMs: Date.now() - stepStart2, detail: 'StitchToolClient + Stitch creados' })
  } catch (err) {
    steps.push({ step: 'create_instance', ok: false, durationMs: Date.now() - stepStart2, error: serializeError(err) })
    return NextResponse.json({ steps, summary: 'FAIL: error creando instancia SDK' })
  }

  // Paso 3: crear proyecto en Stitch
  const stepStart3 = Date.now()
  let project: Awaited<ReturnType<typeof client.createProject>> | null = null
  try {
    project = await client.createProject(`diag-${Date.now()}`)
    steps.push({ step: 'create_project', ok: true, durationMs: Date.now() - stepStart3, detail: `projectId=${project.id}` })
  } catch (err) {
    steps.push({ step: 'create_project', ok: false, durationMs: Date.now() - stepStart3, error: serializeError(err) })
    return NextResponse.json({ steps, summary: 'FAIL: error creando proyecto en Stitch' })
  }

  // Paso 4: llamar generate_screen_from_text DIRECTAMENTE via callTool
  // (bypass de project.generate() que tiene bug de parsing en SDK 0.0.3)
  const stepStart4 = Date.now()
  let rawResponse: unknown = null
  try {
    // Acceder al StitchToolClient subyacente para hacer callTool directo
    const toolClient = (client as unknown as { client: ToolClient }).client
    rawResponse = await toolClient.callTool('generate_screen_from_text', {
      projectId: project.id,
      prompt: 'Simple landing page with a hero section. Dark background #0B0F1A.',
      deviceType: 'DESKTOP',
    })
    const keys = rawResponse !== null && typeof rawResponse === 'object' ? Object.keys(rawResponse as object) : []
    steps.push({
      step: 'generate_screen_raw',
      ok: true,
      durationMs: Date.now() - stepStart4,
      detail: `keys=${JSON.stringify(keys)}`,
    })
  } catch (err) {
    steps.push({ step: 'generate_screen_raw', ok: false, durationMs: Date.now() - stepStart4, error: serializeError(err) })
  }

  // Inspeccionar estructura profunda del rawResponse
  let responseStructure: unknown = null
  if (rawResponse) {
    try {
      responseStructure = inspectStructure(rawResponse, 3)
    } catch {
      responseStructure = 'Error inspeccionando estructura'
    }
  }

  const allOk = steps.every((s) => s.ok)
  return NextResponse.json({
    steps,
    summary: allOk ? 'OK: todos los pasos exitosos' : `FAIL: falló en ${steps.find((s) => !s.ok)?.step}`,
    rawResponse: rawResponse ?? null,
    responseStructure,
  })
}

/**
 * Inspecciona recursivamente un objeto hasta `depth` niveles,
 * reemplazando strings largos con su longitud para no explotar el JSON.
 */
function inspectStructure(obj: unknown, depth: number): unknown {
  if (depth <= 0) return typeof obj
  if (obj === null || obj === undefined) return obj
  if (typeof obj === 'string') return obj.length > 200 ? `[string ${obj.length} chars]: ${obj.slice(0, 100)}...` : obj
  if (typeof obj !== 'object') return obj
  if (Array.isArray(obj)) {
    return obj.map((item) => inspectStructure(item, depth - 1))
  }
  const result: Record<string, unknown> = {}
  for (const key of Object.keys(obj as object)) {
    result[key] = inspectStructure((obj as Record<string, unknown>)[key], depth - 1)
  }
  return result
}

function serializeError(err: unknown): string {
  if (err instanceof Error) {
    const parts = [err.message]
    if (err.name && err.name !== 'Error') parts.unshift(`[${err.name}]`)
    if (err.cause) parts.push(`cause=${JSON.stringify(err.cause)}`)
    if (err.stack) {
      const stackLines = err.stack.split('\n').slice(1, 5).map((l) => l.trim())
      parts.push(`stack: ${stackLines.join(' | ')}`)
    }
    return parts.join(' — ')
  }
  return JSON.stringify(err)
}
