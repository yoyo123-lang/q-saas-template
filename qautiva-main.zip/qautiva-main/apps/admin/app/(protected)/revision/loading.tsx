function SkeletonBlock({ className }: { className?: string }) {
  return <div className={`bg-[#1E293B] rounded-lg animate-pulse ${className ?? ''}`} />
}

export default function RevisionLoading() {
  return (
    <div className="flex flex-col h-full p-6 gap-5">
      {/* Header */}
      <div className="flex flex-col gap-1.5">
        <SkeletonBlock className="h-7 w-48" />
        <SkeletonBlock className="h-4 w-64" />
      </div>

      {/* Cards */}
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="flex items-start gap-4 p-4 rounded-xl bg-[#0F172A] border border-[#1E293B]">
          <SkeletonBlock className="h-10 w-10 rounded-full flex-shrink-0" />
          <div className="flex flex-col gap-2 flex-1">
            <SkeletonBlock className="h-5 w-40" />
            <SkeletonBlock className="h-4 w-64" />
            <div className="flex gap-2 mt-1">
              <SkeletonBlock className="h-5 w-20 rounded-full" />
              <SkeletonBlock className="h-5 w-16 rounded-full" />
            </div>
          </div>
          <SkeletonBlock className="h-8 w-20 rounded-lg" />
        </div>
      ))}
    </div>
  )
}
