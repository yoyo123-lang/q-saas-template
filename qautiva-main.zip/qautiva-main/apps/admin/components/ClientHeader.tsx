import Link from 'next/link'
import type { OrgStatus, Plan, SubStatus, StageStatus } from '@qautiva/db'
import type { OrgWithDetails } from '@/lib/types'

// ── Badges ─────────────────────────────────────────────────────────────────────

const ORG_STATUS_BADGE: Record<OrgStatus, { label: string; className: string }> = {
  DISCOVERY:  { label: 'Descubrimiento', className: 'bg-[#6366F1]/15 text-[#818CF8] border border-[#6366F1]/30' },
  RESEARCH:   { label: 'Investigación',  className: 'bg-[#06B6D4]/15 text-[#22D3EE] border border-[#06B6D4]/30' },
  BRAND:      { label: 'Marca',          className: 'bg-[#EC4899]/15 text-[#F472B6] border border-[#EC4899]/30' },
  WEBSITE:    { label: 'Web',            className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  CAMPAIGNS:  { label: 'Campañas',       className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  MEDIA:      { label: 'Medios',         className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  LAUNCHED:   { label: 'Lanzado',        className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  PAUSED:     { label: 'Pausado',        className: 'bg-[#1E293B] text-[#64748B] border border-[#334155]' },
}

const PLAN_BADGE: Record<Plan, { label: string; className: string }> = {
  BASE:     { label: 'Base',     className: 'bg-[#1E293B] text-[#64748B] border border-[#334155]' },
  COMPLETO: { label: 'Completo', className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  PREMIUM:  { label: 'Premium',  className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
}

const SUB_STATUS_BADGE: Record<SubStatus, { label: string; className: string }> = {
  ACTIVE:    { label: 'Activa',    className: 'text-[#34D399]' },
  PAUSED:    { label: 'Pausada',   className: 'text-[#FBBF24]' },
  CANCELLED: { label: 'Cancelada', className: 'text-[#F87171]' },
}

// ── Sub-componente de suscripción ─────────────────────────────────────────────

function SubscriptionInfo({ sub }: { sub: NonNullable<OrgWithDetails['subscription']> }) {
  const badge = SUB_STATUS_BADGE[sub.status]
  return (
    <div className="flex items-center gap-2 text-[11px]">
      <span className="text-[#94A3B8]">
        ARS ${sub.planAmount.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}/mes
      </span>
      <span className={badge.className}>{badge.label}</span>
      {sub.nextBillingAt && (
        <span className="text-[#64748B]">
          · próximo {new Date(sub.nextBillingAt).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })}
        </span>
      )}
    </div>
  )
}

// ── Componente ─────────────────────────────────────────────────────────────────

interface ClientHeaderProps {
  org: OrgWithDetails
  /** Si hay al menos una etapa en ADMIN_REVIEW, muestra el botón de revisión */
  hasAdminReview: boolean
}

export function ClientHeader({ org, hasAdminReview }: ClientHeaderProps) {
  const initial = org.name.charAt(0).toUpperCase()
  const statusBadge = ORG_STATUS_BADGE[org.status]
  const planBadge = PLAN_BADGE[org.plan]
  const createdAt = new Date(org.createdAt).toLocaleDateString('es-AR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })

  return (
    <div className="flex items-center gap-4 p-4 rounded-xl bg-[#0F172A] border border-[#1E293B] flex-wrap">
      {/* Avatar */}
      <div className="flex-shrink-0 w-14 h-14 rounded-full bg-[#1E293B] flex items-center justify-center">
        <span className="text-white text-xl font-bold">{initial}</span>
      </div>

      {/* Nombre + badges */}
      <div className="flex flex-col gap-1.5 min-w-0 flex-1">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h1 className="text-white text-xl font-bold leading-tight truncate">{org.name}</h1>
          <span className="text-[#475569] text-xs flex-shrink-0">cliente desde {createdAt}</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${statusBadge.className}`}>
            {statusBadge.label}
          </span>
          <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${planBadge.className}`}>
            {planBadge.label}
          </span>
          <span className="text-[#64748B] text-[11px]">{org.industry}</span>
          {org.websiteUrl && (
            <a
              href={org.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#60A5FA] text-[11px] hover:underline truncate max-w-[200px]"
            >
              {org.websiteUrl}
            </a>
          )}
        </div>

        {org.subscription && <SubscriptionInfo sub={org.subscription} />}
      </div>

      {/* Botón revisión — solo si hay items pendientes */}
      {hasAdminReview && (
        <Link
          href={`/revision?org=${org.id}`}
          className="px-3 py-2 rounded-lg bg-[#F59E0B]/15 text-[#FBBF24] text-sm font-medium border border-[#F59E0B]/30 hover:bg-[#F59E0B]/25 transition-colors flex-shrink-0"
        >
          Revisar pendiente
        </Link>
      )}
    </div>
  )
}
