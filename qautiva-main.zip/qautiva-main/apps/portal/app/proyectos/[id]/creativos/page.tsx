import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import type { AdVisuals, BrandOptions, CampaignPlan } from '@/app/_lib/interview/types'
import { MAX_DAILY_AD_VISUALS } from '@/app/api/projects/[id]/generate-creatives/_lib/constants'
import { CreativosClient } from './client'

export const metadata: Metadata = {
  title: 'Creativos para Meta Ads — Qautiva',
  description: 'Generá 6 piezas publicitarias para Meta Ads (Feed 1:1, Feed 4:5, Story 9:16) a partir del contexto de tu marca y campaña.',
}

export default async function CreativosPage({
  params,
}: {
  params: { id: string }
}) {
  // Auth
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) notFound()

  // Verificar ownership del proyecto
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) notFound()

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const project = await prisma.project.findFirst({
    where: { id: params.id, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, name: true, industry: true },
  })

  if (!project) notFound()

  // Cargar deliverables existentes para el panel de contexto (un solo query con include)
  const deliverables = await prisma.deliverable.findMany({
    where: {
      projectId: project.id,
      type: { in: ['BRIEF', 'BRAND_OPTIONS', 'CAMPAIGN_PLAN', 'AD_VISUALS'] },
      isActive: true,
    },
    select: { type: true, content: true, status: true, createdAt: true },
    orderBy: { createdAt: 'desc' },
  })

  const hasBrief = deliverables.some((d) => d.type === 'BRIEF')
  const hasBrandOptions = deliverables.some((d) => d.type === 'BRAND_OPTIONS')
  const hasCampaignPlan = deliverables.some((d) => d.type === 'CAMPAIGN_PLAN')

  // Última generación de AD_VISUALS (solo la más reciente)
  const lastAdVisuals = deliverables.find((d) => d.type === 'AD_VISUALS')
  const previousVisuals = lastAdVisuals ? (lastAdVisuals.content as AdVisuals) : null

  // Contar generaciones de hoy para mostrar el contador en el UI
  const startOfDay = new Date()
  startOfDay.setUTCHours(0, 0, 0, 0)
  const todayCount = await prisma.deliverable.count({
    where: { projectId: project.id, type: 'AD_VISUALS', createdAt: { gte: startOfDay } },
  })

  // Determinar si hay datos de marca disponibles para mostrar chips de contexto
  const brandOptions = deliverables.find((d) => d.type === 'BRAND_OPTIONS')?.content as BrandOptions | null ?? null
  const campaignPlan = deliverables.find((d) => d.type === 'CAMPAIGN_PLAN')?.content as CampaignPlan | null ?? null

  const brandColors = brandOptions?.options?.[0]?.colors?.slice(0, 3).map((c) => c.hex) ?? []
  const brandPersonality = brandOptions?.options?.[0]?.brandPersonality ?? []
  const campaignMessage = campaignPlan?.oferta?.mensajePrincipal ?? null

  return (
    <CreativosClient
      projectId={project.id}
      context={{
        hasBrief,
        hasBrandOptions,
        hasCampaignPlan,
        brandColors,
        brandPersonality,
        campaignMessage,
      }}
      previousVisuals={previousVisuals}
      todayCount={todayCount}
      dailyLimit={MAX_DAILY_AD_VISUALS}
    />
  )
}
