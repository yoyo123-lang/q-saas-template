// Tests for listing schemas and IDOR/validation logic.
// Server Actions themselves require server env (cookies, auth) so we test
// the schemas and business rules in isolation.

import { describe, it, expect } from 'vitest'
import { stepBasicSchema, createListingSchema } from '@/lib/schemas/listing'

// ─── stepBasicSchema ─────────────────────────────────────────────────────────

describe('stepBasicSchema', () => {
  const valid = {
    title: 'Mi SaaS con 200 usuarios activos',
    type: 'SAAS',
    description: 'Descripción larga de al menos cincuenta caracteres para que sea válida y pase la validación de Zod correctamente.',
    askingPrice: 15000,
    currency: 'USD',
    techStack: [],
    tags: [],
  }

  it('acepta datos válidos', () => {
    const result = stepBasicSchema.safeParse(valid)
    expect(result.success).toBe(true)
  })

  it('rechaza título menor a 5 caracteres', () => {
    const result = stepBasicSchema.safeParse({ ...valid, title: 'abc' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].path).toContain('title')
    }
  })

  it('rechaza título mayor a 120 caracteres', () => {
    const result = stepBasicSchema.safeParse({ ...valid, title: 'a'.repeat(121) })
    expect(result.success).toBe(false)
  })

  it('rechaza descripción menor a 50 caracteres', () => {
    const result = stepBasicSchema.safeParse({ ...valid, description: 'Corta' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].path).toContain('description')
    }
  })

  it('rechaza precio negativo', () => {
    const result = stepBasicSchema.safeParse({ ...valid, askingPrice: -100 })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].path).toContain('askingPrice')
    }
  })

  it('rechaza precio 0', () => {
    const result = stepBasicSchema.safeParse({ ...valid, askingPrice: 0 })
    expect(result.success).toBe(false)
  })

  it('rechaza tipo de activo inválido', () => {
    const result = stepBasicSchema.safeParse({ ...valid, type: 'INVALID_TYPE' })
    expect(result.success).toBe(false)
  })

  it('acepta todos los tipos válidos', () => {
    const types = ['WEBSITE', 'DOMAIN', 'SAAS', 'ECOMMERCE', 'PROJECT', 'OTHER']
    for (const type of types) {
      const result = stepBasicSchema.safeParse({ ...valid, type })
      expect(result.success).toBe(true)
    }
  })

  it('acepta monedas USD y ARS', () => {
    expect(stepBasicSchema.safeParse({ ...valid, currency: 'USD' }).success).toBe(true)
    expect(stepBasicSchema.safeParse({ ...valid, currency: 'ARS' }).success).toBe(true)
  })

  it('rechaza moneda inválida', () => {
    const result = stepBasicSchema.safeParse({ ...valid, currency: 'EUR' })
    expect(result.success).toBe(false)
  })

  it('rechaza más de 10 tags en techStack', () => {
    const result = stepBasicSchema.safeParse({
      ...valid,
      techStack: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k'],
    })
    expect(result.success).toBe(false)
  })

  it('rechaza más de 8 tags', () => {
    const result = stepBasicSchema.safeParse({
      ...valid,
      tags: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'],
    })
    expect(result.success).toBe(false)
  })

  it('acepta URL opcional vacía', () => {
    const result = stepBasicSchema.safeParse({ ...valid, url: '' })
    expect(result.success).toBe(true)
  })
})

// ─── createListingSchema (IDOR logic simulation) ─────────────────────────────

describe('createListingSchema', () => {
  const valid = {
    title: 'Mi SaaS con 200 usuarios activos',
    type: 'SAAS' as const,
    description: 'Descripción larga de al menos cincuenta caracteres para que sea válida y pase la validación.',
    askingPrice: 15000,
    currency: 'USD' as const,
    techStack: ['React', 'Next.js'],
    tags: ['rentable'],
    screenshotUrls: [],
  }

  it('acepta listado completo válido', () => {
    expect(createListingSchema.safeParse(valid).success).toBe(true)
  })

  it('acepta listado sin imágenes (borrador)', () => {
    const result = createListingSchema.safeParse({ ...valid, screenshotUrls: [] })
    expect(result.success).toBe(true)
  })

  it('rechaza más de 5 imágenes', () => {
    const result = createListingSchema.safeParse({
      ...valid,
      screenshotUrls: [
        'https://example.com/1.jpg',
        'https://example.com/2.jpg',
        'https://example.com/3.jpg',
        'https://example.com/4.jpg',
        'https://example.com/5.jpg',
        'https://example.com/6.jpg',
      ],
    })
    expect(result.success).toBe(false)
  })
})

// ─── IDOR protection logic ────────────────────────────────────────────────────

describe('IDOR protection (unit simulation)', () => {
  // Simulate the ownership check logic from the actions
  function verifyOwnership(sellerId: string, currentUserId: string): boolean {
    return sellerId === currentUserId
  }

  it('permite editar al vendedor propietario', () => {
    expect(verifyOwnership('user-123', 'user-123')).toBe(true)
  })

  it('bloquea edición por otro usuario', () => {
    expect(verifyOwnership('user-123', 'user-456')).toBe(false)
  })

  it('bloquea edición con userId vacío', () => {
    expect(verifyOwnership('user-123', '')).toBe(false)
  })
})

// ─── Límite de listados activos ───────────────────────────────────────────────

describe('límite de listados activos', () => {
  function canCreateListing(activeCount: number, limit = 50): boolean {
    return activeCount < limit
  }

  it('permite crear cuando está por debajo del límite', () => {
    expect(canCreateListing(49)).toBe(true)
    expect(canCreateListing(0)).toBe(true)
  })

  it('bloquea crear cuando alcanza el límite de 50', () => {
    expect(canCreateListing(50)).toBe(false)
    expect(canCreateListing(51)).toBe(false)
  })
})

// ─── publishListing validations ───────────────────────────────────────────────

describe('validación antes de publicar', () => {
  interface ListingPublishable {
    title: string
    description: string
    askingPrice: number
    screenshotUrls: string[]
  }

  function canPublish(listing: ListingPublishable): { ok: boolean; reason?: string } {
    if (!listing.title || !listing.description || !listing.askingPrice) {
      return { ok: false, reason: 'falta título, descripción o precio' }
    }
    if (!listing.screenshotUrls || listing.screenshotUrls.length === 0) {
      return { ok: false, reason: 'necesita al menos una imagen' }
    }
    return { ok: true }
  }

  const valid: ListingPublishable = {
    title: 'Título válido',
    description: 'Descripción válida',
    askingPrice: 5000,
    screenshotUrls: ['https://example.com/img.jpg'],
  }

  it('permite publicar con todos los campos requeridos', () => {
    expect(canPublish(valid).ok).toBe(true)
  })

  it('bloquea publicar sin imágenes', () => {
    const result = canPublish({ ...valid, screenshotUrls: [] })
    expect(result.ok).toBe(false)
    expect(result.reason).toContain('imagen')
  })

  it('bloquea publicar sin título', () => {
    const result = canPublish({ ...valid, title: '' })
    expect(result.ok).toBe(false)
  })

  it('bloquea publicar sin precio', () => {
    const result = canPublish({ ...valid, askingPrice: 0 })
    expect(result.ok).toBe(false)
  })
})
