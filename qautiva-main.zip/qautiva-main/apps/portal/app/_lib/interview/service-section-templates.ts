/**
 * Bloques HTML estándar para secciones de servicios Q y blog.
 *
 * Se insertan en el template cuando el usuario activó una sección
 * que el template no tiene nativamente en su htmlBase.
 *
 * SEGURIDAD: Estos bloques son generados por el sistema, nunca por el usuario
 * ni por el LLM. El reemplazo futuro de placeholders por widgets reales debe
 * operar solo sobre este HTML, no sobre contenido editado por el usuario.
 *
 * @see ADR-0018 — Integración futura con servicios Q
 */

export const SERVICE_SECTION_TEMPLATES: Record<string, string> = {
  booking: `<section id="booking" class="py-16 px-4 text-center">
  <h2 class="text-3xl font-bold mb-4">Reservá tu turno</h2>
  <p class="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">Elegí el día y horario que te quede mejor. Reservá online en segundos.</p>
  <a href="#" class="inline-block bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">Reservar turno</a>
  <!-- Qontacta widget placeholder -->
</section>`,

  payments: `<section id="payments" class="py-16 px-4 text-center">
  <h2 class="text-3xl font-bold mb-4">Pagá online</h2>
  <p class="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">Aceptamos tarjeta de crédito, débito, transferencia y MercadoPago.</p>
  <a href="#" class="inline-block bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">Realizar pago</a>
  <!-- Qobra checkout placeholder -->
</section>`,

  careers: `<section id="careers" class="py-16 px-4 text-center">
  <h2 class="text-3xl font-bold mb-4">Trabajá con nosotros</h2>
  <p class="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">Sumate a nuestro equipo. Conocé las búsquedas abiertas y postulate.</p>
  <a href="#" class="inline-block bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">Ver búsquedas</a>
  <!-- Qontrata job board placeholder -->
</section>`,

  blog: `<section id="blog" class="py-16 px-4 text-center">
  <h2 class="text-3xl font-bold mb-4">Nuestro blog</h2>
  <p class="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">Artículos, novedades y consejos para vos.</p>
  <a href="#" class="inline-block bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">Ver artículos</a>
  <!-- Blog placeholder -->
</section>`,
} as const;

/**
 * Secciones de servicios Q disponibles. El orden determina en qué posición
 * se insertan en el HTML (antes del footer/cierre del body).
 */
export const SERVICE_SECTION_ORDER = ['booking', 'payments', 'careers', 'blog'] as const;

export type ServiceSectionKey = (typeof SERVICE_SECTION_ORDER)[number];
