import { redirect } from 'next/navigation'
import Link from 'next/link'
import { MessageCircle } from 'lucide-react'
import { createClient } from '@/lib/supabase/server'
import { getInquiries } from '@/lib/data/inquiries'
import { InquiryCard } from '@/components/listings/inquiry-card'
import { EmptyState } from '@/components/shared/empty-state'
import { cn } from '@/lib/utils/cn'

const tabs = [
  { label: 'Todas', status: undefined },
  { label: 'Abiertas', status: 'OPEN' as const },
  { label: 'Respondidas', status: 'REPLIED' as const },
  { label: 'Cerradas', status: 'CLOSED' as const },
]

export const metadata = {
  title: 'Mis consultas',
}

interface ConsultasPageProps {
  searchParams: Promise<{ status?: string; page?: string }>
}

export default async function ConsultasPage({ searchParams }: ConsultasPageProps) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const params = await searchParams
  const status = (['OPEN', 'REPLIED', 'CLOSED', 'CONVERTED'] as const).find(
    (s) => s === params.status
  )
  const page = Math.max(1, parseInt(params.page ?? '1', 10) || 1)

  const { items, total, pageSize } = await getInquiries(user.id, { status, page })
  const totalPages = Math.ceil(total / pageSize)

  function buildHref(p: number): string {
    const base = status ? `/consultas?status=${status}` : '/consultas'
    return p === 1 ? base : `${base}${status ? '&' : '?'}page=${p}`
  }

  function getPaginationPages(current: number, total: number): (number | '...')[] {
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1)
    const pages: (number | '...')[] = [1]
    if (current > 3) pages.push('...')
    for (let p = Math.max(2, current - 1); p <= Math.min(total - 1, current + 1); p++) {
      pages.push(p)
    }
    if (current < total - 2) pages.push('...')
    pages.push(total)
    return pages
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-50">Mis consultas</h1>
        <p className="text-slate-400 mt-1 text-sm">
          Conversaciones con compradores y vendedores.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 border-b border-slate-800">
        {tabs.map((tab) => {
          const isActive = tab.status === status
          const href = tab.status ? `/consultas?status=${tab.status}` : '/consultas'
          return (
            <Link
              key={tab.label}
              href={href}
              className={[
                'px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px',
                isActive
                  ? 'border-amber-500 text-amber-500'
                  : 'border-transparent text-slate-400 hover:text-slate-50',
              ].join(' ')}
            >
              {tab.label}
              {isActive && total > 0 && (
                <span className="ml-1.5 text-xs bg-amber-500/20 text-amber-500 px-1.5 py-0.5 rounded-full">
                  {total}
                </span>
              )}
            </Link>
          )
        })}
      </div>

      {/* Inquiry list */}
      {items.length === 0 ? (
        <EmptyState
          icon={<MessageCircle className="size-6" />}
          title="No hay consultas"
          description={
            status
              ? 'No hay consultas con este estado.'
              : 'Cuando inicies o recibas consultas aparecerán acá.'
          }
        />
      ) : (
        <>
          <div className="flex flex-col gap-3">
            {items.map((inquiry) => (
              <InquiryCard
                key={inquiry.id}
                inquiry={inquiry}
                currentUserId={user.id}
              />
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <nav aria-label="Paginación" className="flex justify-center gap-1 mt-8">
              {getPaginationPages(page, totalPages).map((p, i) =>
                p === '...' ? (
                  <span key={`ellipsis-${i}`} className="min-w-[36px] h-9 flex items-center justify-center text-slate-500 text-sm">
                    …
                  </span>
                ) : (
                  <Link
                    key={p}
                    href={buildHref(p)}
                    aria-label={`Página ${p}`}
                    aria-current={p === page ? 'page' : undefined}
                    className={cn(
                      'min-w-[36px] h-9 rounded-lg text-sm font-medium transition-colors flex items-center justify-center',
                      p === page
                        ? 'bg-amber-500 text-navy-950 font-semibold'
                        : 'text-slate-400 hover:text-slate-50 hover:bg-slate-800'
                    )}
                  >
                    {p}
                  </Link>
                )
              )}
            </nav>
          )}
        </>
      )}
    </div>
  )
}
