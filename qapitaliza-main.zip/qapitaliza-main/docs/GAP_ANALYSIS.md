# GAP Analysis — Qapitaliza vs Template

> **Fecha**: 2026-03-24
> **Actualizado**: 2026-03-24
> **Estado**: Fases 1 y 2 completadas
> **Referencia**: `docs/ADOPCION_PROYECTOS_EXISTENTES.md`

---

## Resumen ejecutivo

Qapitaliza adoptó la estructura del template (docs/, .claude/agents, .claude/commands, roles, ADRs, sessions). Quedan brechas en documentación clave, automatización de CI, infraestructura de testing E2E, y hooks protectores.

---

## Matriz de brechas

| # | Estándar esperado | Estado actual | Riesgo | Esfuerzo | Fase |
|---|---|---|---|---|---|
| 1 | `ARCHITECTURE.md` completo con datos reales | Tiene todos los `[completar]` del template — sin datos del proyecto | Alto | Medio | 1 |
| 2 | Smoke tests E2E (nivel 0: health, landing, redirect) | No existen. Los 5 tests actuales empiezan en nivel 2 (flujos de negocio) | Alto | Bajo | 1 |
| 3 | Fixture de auth para E2E (sesión sintética en DB) | No existe. Tests usan credenciales hardcodeadas (`E2E_TEST_EMAIL`) | Alto | Medio | 1 |
| 4 | CI/CD con GitHub Actions (test + lint + build en PRs) | No hay `.github/workflows/`. Nada corre automáticamente | Alto | Medio | 1 |
| 5 | Hooks en `.claude/settings.json` (proteger migrations, .env, .lock) | No existe `settings.json`. Hooks documentados en `docs/HOOKS.md` pero no activados | Medio | Bajo | 1 |
| 6 | Scripts `test:e2e` en package.json | No existen. Hay que correr `npx playwright test` a mano | Bajo | Mínimo | 1 |
| 7 | `webServer` habilitado en `playwright.config.ts` | Comentado. No arranca dev server automáticamente al testear | Medio | Mínimo | 1 |
| 8 | `GAP_ANALYSIS.md` | No existía (este archivo lo resuelve) | Medio | — | 1 |
| 9 | Limpiar `q-saas-template-main.zip` de la raíz | ZIP del template en el repo sin necesidad | Bajo | Mínimo | 1 |
| 10 | Playbook E2E (`docs/playbooks/e2e.md`) con patrones generativos | No existe. Sin documentación de cómo generar tests para entidades nuevas | Medio | Medio | 2 |
| 11 | Comando `/project:e2e` para generar tests automáticamente | No existe en `.claude/commands/` | Medio | Medio | 2 |
| 12 | Workflow E2E en CI (`.github/workflows/e2e.yml`) | No existe. Depende de brecha #4 | Medio | Medio | 2 |
| 13 | `SESSION_LOG.md` centralizado | No existe. Sessions están en archivos separados en `docs/sessions/` | Bajo | Bajo | 2 |
| 14 | `docs/board/` con archivos del Board (BOARD_CONTEXT.md, METRICS_MAP.md) | Directorio existe pero vacío (solo `.gitkeep`) | Bajo | N/A | — |

---

## Plan de adopción

### FASE 1 — Inmediato (esta sesión)

Objetivo: cerrar las brechas de mayor riesgo con menor esfuerzo.

- [x] **#1** Completar `docs/ARCHITECTURE.md` con datos reales del proyecto ✓
- [x] **#2** Crear smoke tests E2E (`e2e/00-smoke.spec.ts`) ✓
- [x] **#3** Crear fixture de auth E2E (`e2e/fixtures/auth.ts`, Admin API Supabase) ✓
- [x] **#5** Configurar hooks en `.claude/settings.json` ✓
- [x] **#6** Scripts `test:e2e`, `test:e2e:ui`, `test:e2e:headed` en package.json ✓
- [x] **#7** `webServer` habilitado en `playwright.config.ts` ✓
- [x] **#8** Crear `docs/GAP_ANALYSIS.md` ← este archivo ✓
- [x] **#9** Eliminar `q-saas-template-main.zip` de la raíz del repo ✓

### FASE 2 — Próximas 2-3 sesiones

Objetivo: completar infraestructura de CI y herramientas generativas.

- [x] **#4** Crear `.github/workflows/ci.yml` (lint + vitest + build, sin Supabase real) ✓
- [x] **#10** Crear `docs/playbooks/e2e.md` con 5 patrones generativos ✓
- [x] **#11** Crear `.claude/commands/e2e.md` (comando `/project:e2e`) ✓
- [x] **#12** Crear `.github/workflows/e2e.yml` (smoke job + full job condicional) ✓
- [x] **#13** `SESSION_LOG.md` creado en raíz. Decisión: el log centralizado convive con `docs/sessions/` (prompts planificados) ✓

### NO TOCAR AHORA

- **#14** `docs/board/` — los archivos vienen de q-company via PR automático. No es acción nuestra.
- **Refactors de código** — el objetivo es documentar y estabilizar, no reescribir.
- **Mover tests de `e2e/` a `tests/e2e/`** — cambio de convención sin valor funcional inmediato.
- **Normalización de código por dominio** — corresponde a Fase 4 del template, muy prematuro.

---

## Notas técnicas

### Fixture de auth (brecha #3)

El template usa sesión sintética en DB con Prisma. Qapitaliza usa Supabase Auth (no NextAuth), así que la fixture necesita adaptación:
- Crear usuario en `auth.users` de Supabase (o usar el Admin API)
- Crear sesión y setear cookie `sb-*-auth-token`
- Cleanup al terminar el test

Esto requiere investigar cómo Supabase maneja sesiones en el contexto de Playwright antes de implementar.

### CI/CD (brechas #4, #12)

El template asume NextAuth + Prisma + PostgreSQL service en GitHub Actions. Qapitaliza usa Supabase, por lo que:
- El workflow de CI básico (lint + build + vitest) no necesita Supabase
- El workflow de E2E sí necesita una instancia de Supabase (local con `supabase start` o DB de test)
- Alternativa: correr E2E contra Vercel preview URL

---

*Última actualización: 2026-03-24*
