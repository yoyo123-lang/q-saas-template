import { describe, it, expect, vi, beforeEach } from 'vitest'
vi.mock('next/cache', () => ({ revalidatePath: vi.fn(), revalidateTag: vi.fn() }))

const mockGetUser = vi.fn()
const mockApiKeyCount = vi.fn()
const mockBillingFindUnique = vi.fn()
const mockBillingUpdate = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    apiKey: { count: mockApiKeyCount },
    billingAccount: {
      findUnique: mockBillingFindUnique,
      update: mockBillingUpdate,
    },
  },
}))

vi.mock('@/app/_lib/get-team-for-user', () => ({
  getTeamForUser: vi.fn().mockImplementation(async (authUserId: string) => {
    if (authUserId === 'legacy-user') return null
    return { teamId: 'team-1', teamRole: 'OWNER' }
  }),
}))

const { PATCH } = await import('@/app/api/settings/ai-mode/route')

const mockUser = { id: 'auth-user-1' }

function makeRequest(body: unknown) {
  return new Request('http://localhost/api/settings/ai-mode', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

describe('PATCH /api/settings/ai-mode', () => {
  beforeEach(() => vi.clearAllMocks())

  it('retorna 401 sin auth', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: null })
    const res = await PATCH(makeRequest({ preferredKeySource: 'BYOK' }))
    expect(res.status).toBe(401)
  })

  it('retorna 404 para usuario sin team', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'legacy-user' } }, error: null })
    const res = await PATCH(makeRequest({ preferredKeySource: 'BYOK' }))
    expect(res.status).toBe(404)
  })

  it('retorna 400 con source inválido', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    const res = await PATCH(makeRequest({ preferredKeySource: 'INVALID' }))
    expect(res.status).toBe(400)
  })

  it('retorna 400 al cambiar a BYOK sin keys válidas', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyCount.mockResolvedValue(0)
    const res = await PATCH(makeRequest({ preferredKeySource: 'BYOK' }))
    expect(res.status).toBe(400)
  })

  it('cambia a BYOK con keys válidas', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyCount.mockResolvedValue(1)
    mockBillingFindUnique.mockResolvedValue({ id: 'billing-1', plan: 'PREPAID' })
    mockBillingUpdate.mockResolvedValue({})
    const res = await PATCH(makeRequest({ preferredKeySource: 'BYOK' }))
    const body = await res.json()
    expect(res.status).toBe(200)
    expect(body.ok).toBe(true)
    expect(body.preferredKeySource).toBe('BYOK')
  })

  it('cambia a QAUTIVA_HOSTED sin verificar keys', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockBillingFindUnique.mockResolvedValue({ id: 'billing-1', plan: 'PREPAID' })
    mockBillingUpdate.mockResolvedValue({})
    const res = await PATCH(makeRequest({ preferredKeySource: 'QAUTIVA_HOSTED' }))
    expect(res.status).toBe(200)
    expect(mockApiKeyCount).not.toHaveBeenCalled()
  })

  it('retorna 403 si el plan es FREE_TRIAL al intentar cambiar a BYOK', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyCount.mockResolvedValue(1)
    mockBillingFindUnique.mockResolvedValue({ id: 'ba-1', plan: 'FREE_TRIAL' })
    const res = await PATCH(makeRequest({ preferredKeySource: 'BYOK' }))
    expect(res.status).toBe(403)
  })

  it('permite cambio a BYOK si el plan NO es FREE_TRIAL', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyCount.mockResolvedValue(1)
    mockBillingFindUnique.mockResolvedValue({ id: 'ba-1', plan: 'PREPAID' })
    mockBillingUpdate.mockResolvedValue({})
    const res = await PATCH(makeRequest({ preferredKeySource: 'BYOK' }))
    expect(res.status).toBe(200)
  })
})
