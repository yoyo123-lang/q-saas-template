import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Plus, Package, Search } from 'lucide-react'
import { createClient } from '@/lib/supabase/server'
import { getSellerListings } from '@/lib/data/listings'
import { ListingsTable } from '@/components/listings/listings-table'
import { EmptyState } from '@/components/shared/empty-state'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils/cn'

interface Props {
  searchParams: Promise<{
    status?: string
    q?: string
    page?: string
  }>
}

const tabs = [
  { label: 'Todos', status: 'all' },
  { label: 'Publicados', status: 'published' },
  { label: 'Borradores', status: 'draft' },
  { label: 'En revisión', status: 'pending' },
  { label: 'Vendidos', status: 'sold' },
]

type StatusParam = 'all' | 'published' | 'draft' | 'pending' | 'sold'

function getPaginationPages(current: number, total: number): (number | '...')[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1)
  const pages: (number | '...')[] = [1]
  if (current > 3) pages.push('...')
  for (let p = Math.max(2, current - 1); p <= Math.min(total - 1, current + 1); p++) {
    pages.push(p)
  }
  if (current < total - 2) pages.push('...')
  pages.push(total)
  return pages
}

function tabCount(status: string, data: { total: number; publishedCount: number; draftCount: number; pendingCount: number; soldCount: number }): number {
  switch (status) {
    case 'published': return data.publishedCount
    case 'draft': return data.draftCount
    case 'pending': return data.pendingCount
    case 'sold': return data.soldCount
    default: return data.total
  }
}

export default async function MisActivosPage({ searchParams }: Props) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const params = await searchParams
  const activeStatus = (params.status as StatusParam) || 'all'
  const q = params.q
  const page = Math.max(1, Number(params.page) || 1)

  const data = await getSellerListings(user.id, {
    status: activeStatus,
    q,
    page,
    limit: 20,
  })

  const totalPages = Math.ceil(data.total / 20)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-50">Mis activos</h1>
          <p className="text-sm text-slate-400 mt-1">{data.total} activos en total</p>
        </div>
        <Link href="/mis-activos/nuevo">
          <Button variant="solid" icon={<Plus size={16} />}>
            Nuevo listado
          </Button>
        </Link>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-800">
        {tabs.map(({ label, status }) => {
          const count = tabCount(status, data)
          const isActive = activeStatus === status
          return (
            <Link
              key={status}
              href={`/mis-activos?status=${status}${q ? `&q=${q}` : ''}`}
              className={cn(
                'flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px',
                isActive
                  ? 'border-amber-500 text-amber-500'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              )}
            >
              {label}
              <span
                className={cn(
                  'text-xs px-1.5 py-0.5 rounded-full font-semibold',
                  isActive ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-500'
                )}
              >
                {count}
              </span>
            </Link>
          )
        })}
      </div>

      {/* Search bar */}
      <form method="GET" action="/mis-activos" className="flex gap-2">
        <input type="hidden" name="status" value={activeStatus} />
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-500 pointer-events-none" />
          <input
            type="text"
            name="q"
            defaultValue={q}
            placeholder="Buscar activos..."
            className="w-full bg-slate-800 border border-slate-800 rounded-lg pl-9 pr-3 py-2.5 text-sm text-slate-50 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm rounded-lg transition-colors"
        >
          Buscar
        </button>
      </form>

      {/* Table */}
      <div className="bg-navy-900 border border-slate-800 rounded-xl overflow-hidden">
        {data.items.length === 0 ? (
          <EmptyState
            icon={<Package size={24} />}
            title="Todavía no publicaste ningún activo"
            description="Publicá tu primer activo digital para empezar a recibir consultas"
            cta={
              <Link href="/mis-activos/nuevo">
                <Button variant="solid" icon={<Plus size={16} />}>
                  Publicar mi primer activo
                </Button>
              </Link>
            }
          />
        ) : (
          <ListingsTable listings={data.items} />
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <nav aria-label="Paginación" className="flex justify-center gap-1">
          {getPaginationPages(page, totalPages).map((p, i) =>
            p === '...' ? (
              <span key={`ellipsis-${i}`} className="min-w-[36px] h-9 flex items-center justify-center text-slate-500 text-sm">
                …
              </span>
            ) : (
              <Link
                key={p}
                href={`/mis-activos?status=${activeStatus}&page=${p}${q ? `&q=${q}` : ''}`}
                aria-label={`Página ${p}`}
                aria-current={p === page ? 'page' : undefined}
                className={cn(
                  'min-w-[36px] h-9 rounded-lg text-sm font-medium transition-colors flex items-center justify-center',
                  p === page
                    ? 'bg-amber-500 text-navy-950 font-semibold'
                    : 'text-slate-400 hover:text-slate-50 hover:bg-slate-800'
                )}
              >
                {p}
              </Link>
            )
          )}
        </nav>
      )}
    </div>
  )
}
