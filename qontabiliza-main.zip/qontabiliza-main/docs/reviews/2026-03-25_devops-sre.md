# DevOps / SRE Review
**Fecha:** 2026-03-25
**Archivos revisados:**
- `prisma/schema.prisma`
- `prisma/seed.ts`
- `supabase/migrations/20260325000000_add_domain_models.sql`

---

## Hallazgos

### CRÍTICO

#### SRE-01 — Doble sistema de migraciones: Prisma Migrate vs SQL manual — dos fuentes de verdad
**Archivo:** `prisma/schema.prisma` + `supabase/migrations/20260325000000_add_domain_models.sql`
**Descripción:** El proyecto tiene dos sistemas de migración en paralelo:
1. `prisma/schema.prisma` gestionado por Prisma Migrate (genera `prisma/migrations/`)
2. `supabase/migrations/*.sql` gestionado manualmente

Cualquier cambio en el schema requiere actualizar ambos manualmente. No hay ningún mecanismo que detecte drift entre ellos. En la práctica uno va a quedar desactualizado. Esto es una bomba de tiempo operacional.

**Riesgos:**
- Deploy falla porque el schema Prisma no coincide con la DB real de Supabase
- `prisma migrate status` reporta pending migrations que ya fueron aplicadas manualmente
- El team pierde confianza en cuál archivo es la fuente de verdad

**Fix sugerido:** Elegir una estrategia y eliminar la otra:
- Opción A (recomendada): usar solo Prisma Migrate (`prisma migrate dev` / `prisma migrate deploy`) y eliminar los archivos SQL manuales de Supabase.
- Opción B: usar solo SQL manual para Supabase y eliminar `prisma/migrations/` (perder las ventajas de Prisma Migrate).

---

### ALTO

#### SRE-02 — Migración SQL no tiene rollback (DOWN migration)
**Archivo:** `supabase/migrations/20260325000000_add_domain_models.sql`
**Descripción:** El archivo solo tiene sentencias `CREATE`. No hay ningún `DROP TABLE` o reversión documentada. Si el deploy falla o hay que rollback urgente, no hay forma automatizada de revertir la migración.
**Fix sugerido:** Agregar un bloque comentado con las sentencias de rollback, o crear un archivo `20260325000000_add_domain_models.down.sql` explícito.

#### SRE-03 — `ADMIN_EMAIL` faltante en env mata el proceso de seed con `process.exit(1)`
**Archivo:** `prisma/seed.ts:6-11`
**Descripción:** El seed falla hard con `process.exit(1)` si `ADMIN_EMAIL` no está definido. En un pipeline CI/CD que no tenga esa env var configurada, el seed falla y el deploy podría bloquearse o el estado de la DB quedar inconsistente.
**Fix sugerido:** Documentar `ADMIN_EMAIL` en `.env.example`. Agregar validación en el CI/CD que verifique que las vars requeridas están presentes antes de correr el deploy.

#### SRE-04 — `CashRegister.openedById` / `closedById` sin integridad referencial
**Archivo:** `prisma/schema.prisma:549-550`
**Descripción:** Estos campos son `String` sin FK a User. Si un usuario es eliminado, sus referencias en `CashRegister` quedan como IDs huérfanos. No hay `onDelete` behavior definido.
**Fix sugerido:** Agregar relación con `onDelete: Restrict` o cambiar a `onDelete: SetNull` con `closedById String?`.

---

### MEDIO

#### SRE-05 — Seed no está envuelto en transacción — fallo parcial deja BD inconsistente
**Archivo:** `prisma/seed.ts:5-240`
**Descripción:** El seed ejecuta ~10 operaciones secuencialmente sin `prisma.$transaction`. Si falla en el paso 7 (ej: al crear el producto), los pasos 1-6 ya se ejecutaron. La BD queda en estado parcial sin forma sencilla de rollback.
**Fix sugerido:** Envolver toda la lógica en `prisma.$transaction(async (tx) => { ... })` usando el cliente transaccional `tx` en lugar de `prisma`.

#### SRE-06 — No hay health check de la conexión a BD en el schema/seed
**Archivo:** `prisma/seed.ts`
**Descripción:** El seed no verifica que la conexión a la BD esté activa antes de intentar operaciones. Un timeout de conexión en CI resulta en un error críptico de Prisma en vez de un mensaje claro.
**Fix sugerido:** Agregar `await prisma.$queryRaw\`SELECT 1\`` al inicio del seed para verificar conectividad.

---

### BAJO

#### SRE-07 — `isActive` en Plan sin índice — queries de planes activos hacen full scan
**Archivo:** `prisma/schema.prisma:166`
**Descripción:** La query más común sobre planes es `WHERE isActive = true`. No hay índice en `isActive`. Con pocos planes (4 actualmente) no es un problema, pero si el catálogo de planes crece, será necesario.
**Fix sugerido:** `@@index([isActive])` en el modelo Plan, o dejar como está dado el volumen bajo (4 registros).

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 1        |
| ALTO      | 3        |
| MEDIO     | 2        |
| BAJO      | 1        |
| **Total** | **7**    |
