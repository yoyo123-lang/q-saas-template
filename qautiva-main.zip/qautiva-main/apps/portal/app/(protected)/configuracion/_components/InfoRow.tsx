/** Fila label/valor reutilizada en los tabs de configuración. */
export function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-[#1E293B] last:border-0">
      <span className="text-[#94A3B8] text-sm">{label}</span>
      <span className="text-white text-sm font-medium">{value}</span>
    </div>
  )
}
