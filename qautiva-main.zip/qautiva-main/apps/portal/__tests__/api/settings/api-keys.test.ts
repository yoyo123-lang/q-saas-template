import { describe, it, expect, vi, beforeEach } from 'vitest'
vi.mock('next/cache', () => ({ revalidatePath: vi.fn(), revalidateTag: vi.fn() }))

const mockGetUser = vi.fn()
const mockTeamMemberFindFirst = vi.fn()
const mockApiKeyFindMany = vi.fn()
const mockApiKeyFindUnique = vi.fn()
const mockApiKeyCreate = vi.fn()
const mockApiKeyDelete = vi.fn()
const mockApiKeyCount = vi.fn()
const mockBillingFindUnique = vi.fn()
const mockValidateApiKey = vi.fn()
const mockEncrypt = vi.fn().mockReturnValue('encrypted:key:value')

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    teamMember: { findFirst: mockTeamMemberFindFirst },
    apiKey: {
      findMany: mockApiKeyFindMany,
      findUnique: mockApiKeyFindUnique,
      create: mockApiKeyCreate,
      delete: mockApiKeyDelete,
      count: mockApiKeyCount,
    },
    billingAccount: { findUnique: mockBillingFindUnique },
  },
}))

vi.mock('@/app/_lib/validate-api-key', () => ({
  validateApiKey: mockValidateApiKey,
}))

vi.mock('@/lib/encryption', () => ({
  encrypt: mockEncrypt,
  keyHint: vi.fn().mockReturnValue('...abc1'),
}))

vi.mock('@/app/_lib/get-team-for-user', () => ({
  getTeamForUser: vi.fn().mockImplementation(async (authUserId: string) => {
    if (authUserId === 'legacy-user') return null
    return { teamId: 'team-1', teamRole: 'OWNER' }
  }),
}))

const { GET, POST } = await import('@/app/api/settings/api-keys/route')
const { DELETE } = await import('@/app/api/settings/api-keys/[id]/route')

const mockUser = { id: 'auth-user-1' }
const mockKeys = [
  { id: 'key-1', provider: 'ANTHROPIC', keyHint: '...abc1', label: null, isValid: true, lastUsedAt: null, lastError: null, createdAt: new Date() },
]

function makeRequest(method: string, body?: unknown) {
  return new Request('http://localhost', {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  })
}

describe('GET /api/settings/api-keys', () => {
  beforeEach(() => vi.clearAllMocks())

  it('retorna 401 sin auth', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: null })
    const res = await GET()
    expect(res.status).toBe(401)
  })

  it('retorna 404 para usuario sin team', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'legacy-user' } }, error: null })
    const res = await GET()
    expect(res.status).toBe(404)
  })

  it('retorna lista de keys sin encryptedKey', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyFindMany.mockResolvedValue(mockKeys)
    const res = await GET()
    const body = await res.json()
    expect(res.status).toBe(200)
    expect(body.keys).toHaveLength(1)
    expect(body.keys[0]).not.toHaveProperty('encryptedKey')
  })
})

describe('POST /api/settings/api-keys', () => {
  beforeEach(() => vi.clearAllMocks())

  it('retorna 401 sin auth', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: null })
    const res = await POST(makeRequest('POST', { provider: 'ANTHROPIC', key: 'sk-ant-test' }))
    expect(res.status).toBe(401)
  })

  it('retorna 400 con provider inválido', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    const res = await POST(makeRequest('POST', { provider: 'INVALID', key: 'sk-test' }))
    expect(res.status).toBe(400)
  })

  it('retorna 400 si la key es inválida', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockValidateApiKey.mockResolvedValue(false)
    const res = await POST(makeRequest('POST', { provider: 'ANTHROPIC', key: 'sk-invalid' }))
    expect(res.status).toBe(400)
  })

  it('crea key válida y retorna sin encryptedKey', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockValidateApiKey.mockResolvedValue(true)
    mockApiKeyCreate.mockResolvedValue(mockKeys[0])
    const res = await POST(makeRequest('POST', { provider: 'ANTHROPIC', key: 'sk-ant-validkey' }))
    const body = await res.json()
    expect(res.status).toBe(201)
    expect(body.ok).toBe(true)
    expect(body.key).not.toHaveProperty('encryptedKey')
  })
})

describe('DELETE /api/settings/api-keys/[id]', () => {
  beforeEach(() => vi.clearAllMocks())

  it('retorna 401 sin auth', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null }, error: null })
    const res = await DELETE(makeRequest('DELETE'), { params: { id: 'key-1' } })
    expect(res.status).toBe(401)
  })

  it('retorna 403 si la key pertenece a otro team', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyFindUnique.mockResolvedValue({ id: 'key-1', teamId: 'other-team' })
    const res = await DELETE(makeRequest('DELETE'), { params: { id: 'key-1' } })
    expect(res.status).toBe(403)
  })

  it('retorna 409 si intenta revocar la última key en modo BYOK', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyFindUnique.mockResolvedValue({ id: 'key-1', teamId: 'team-1' })
    mockBillingFindUnique.mockResolvedValue({ preferredKeySource: 'BYOK' })
    mockApiKeyCount.mockResolvedValue(1)
    const res = await DELETE(makeRequest('DELETE'), { params: { id: 'key-1' } })
    expect(res.status).toBe(409)
  })

  it('elimina la key y retorna ok', async () => {
    mockGetUser.mockResolvedValue({ data: { user: mockUser }, error: null })
    mockApiKeyFindUnique.mockResolvedValue({ id: 'key-1', teamId: 'team-1' })
    mockBillingFindUnique.mockResolvedValue({ preferredKeySource: 'QAUTIVA_HOSTED' })
    mockApiKeyDelete.mockResolvedValue({})
    const res = await DELETE(makeRequest('DELETE'), { params: { id: 'key-1' } })
    expect(res.status).toBe(200)
    expect(mockApiKeyDelete).toHaveBeenCalledWith({ where: { id: 'key-1' } })
  })
})
