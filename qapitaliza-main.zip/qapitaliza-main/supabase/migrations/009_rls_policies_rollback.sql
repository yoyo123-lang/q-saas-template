-- ============================================================
-- ROLLBACK 009 — RLS Policies
-- Borra todas las políticas y deshabilita RLS.
-- ADVERTENCIA: sin RLS las tablas quedan expuestas.
-- ============================================================

-- profiles
DROP POLICY IF EXISTS "profiles_select_public"    ON public.profiles;
DROP POLICY IF EXISTS "profiles_update_own"        ON public.profiles;
DROP POLICY IF EXISTS "profiles_insert_own"        ON public.profiles;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;

-- categories
DROP POLICY IF EXISTS "categories_select_public"   ON public.categories;
DROP POLICY IF EXISTS "categories_write_admin"     ON public.categories;
ALTER TABLE public.categories DISABLE ROW LEVEL SECURITY;

-- listings
DROP POLICY IF EXISTS "listings_select_published"       ON public.listings;
DROP POLICY IF EXISTS "listings_select_own_seller"      ON public.listings;
DROP POLICY IF EXISTS "listings_select_admin"           ON public.listings;
DROP POLICY IF EXISTS "listings_insert_seller"          ON public.listings;
DROP POLICY IF EXISTS "listings_update_own_seller"      ON public.listings;
DROP POLICY IF EXISTS "listings_update_admin"           ON public.listings;
DROP POLICY IF EXISTS "listings_delete_own_draft"       ON public.listings;
DROP POLICY IF EXISTS "listings_delete_admin"           ON public.listings;
ALTER TABLE public.listings DISABLE ROW LEVEL SECURITY;

-- listing_metrics
DROP POLICY IF EXISTS "listing_metrics_select_published" ON public.listing_metrics;
DROP POLICY IF EXISTS "listing_metrics_select_own"       ON public.listing_metrics;
DROP POLICY IF EXISTS "listing_metrics_select_admin"     ON public.listing_metrics;
DROP POLICY IF EXISTS "listing_metrics_write_own"        ON public.listing_metrics;
ALTER TABLE public.listing_metrics DISABLE ROW LEVEL SECURITY;

-- inquiries
DROP POLICY IF EXISTS "inquiries_select_participants"  ON public.inquiries;
DROP POLICY IF EXISTS "inquiries_select_admin"         ON public.inquiries;
DROP POLICY IF EXISTS "inquiries_insert_buyer"         ON public.inquiries;
DROP POLICY IF EXISTS "inquiries_update_buyer"         ON public.inquiries;
ALTER TABLE public.inquiries DISABLE ROW LEVEL SECURITY;

-- inquiry_messages
DROP POLICY IF EXISTS "inquiry_messages_select_participants" ON public.inquiry_messages;
DROP POLICY IF EXISTS "inquiry_messages_insert_participants" ON public.inquiry_messages;
ALTER TABLE public.inquiry_messages DISABLE ROW LEVEL SECURITY;

-- favorites
DROP POLICY IF EXISTS "favorites_select_own"   ON public.favorites;
DROP POLICY IF EXISTS "favorites_insert_own"   ON public.favorites;
DROP POLICY IF EXISTS "favorites_delete_own"   ON public.favorites;
ALTER TABLE public.favorites DISABLE ROW LEVEL SECURITY;

-- audit_log
DROP POLICY IF EXISTS "audit_log_select_admin" ON public.audit_log;
ALTER TABLE public.audit_log DISABLE ROW LEVEL SECURITY;
