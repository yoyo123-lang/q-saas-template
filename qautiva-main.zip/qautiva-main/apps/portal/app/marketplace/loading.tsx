export default function MarketplaceLoading() {
  return (
    <div className="p-6 max-w-7xl mx-auto animate-pulse">
      {/* Encabezado skeleton */}
      <div className="mb-6">
        <div className="h-8 w-48 bg-[#1E293B] rounded-lg mb-2" />
        <div className="h-4 w-72 bg-[#1E293B] rounded" />
      </div>

      <div className="flex gap-6 flex-col lg:flex-row">
        {/* Filtros skeleton */}
        <aside className="w-full lg:w-56 shrink-0 flex flex-col gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i}>
              <div className="h-3 w-24 bg-[#1E293B] rounded mb-1" />
              <div className="h-9 w-full bg-[#1E293B] rounded-lg" />
            </div>
          ))}
        </aside>

        {/* Grid skeleton */}
        <div className="flex-1 min-w-0">
          <div className="h-4 w-32 bg-[#1E293B] rounded mb-4" />
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4">
                <div className="flex justify-between">
                  <div className="flex-1">
                    <div className="h-5 w-20 bg-[#1E293B] rounded-full mb-2" />
                    <div className="h-4 w-40 bg-[#1E293B] rounded mb-1" />
                    <div className="h-3 w-28 bg-[#1E293B] rounded" />
                  </div>
                  <div className="text-right">
                    <div className="h-3 w-12 bg-[#1E293B] rounded mb-1" />
                    <div className="h-4 w-20 bg-[#1E293B] rounded" />
                  </div>
                </div>
                <div className="h-8 w-full bg-[#1E293B] rounded" />
                <div className="flex gap-3">
                  <div className="h-8 w-16 bg-[#1E293B] rounded" />
                  <div className="h-8 w-16 bg-[#1E293B] rounded" />
                </div>
                <div className="h-8 w-full bg-[#1E293B] rounded-lg" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
