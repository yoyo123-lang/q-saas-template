import OpenAI from 'openai'

let _openaiClient: OpenAI | null = null

/**
 * Singleton del cliente OpenAI.
 * Sólo configura el transporte (API key, timeout). Toda lógica de negocio
 * vive en brand-generator.ts — ver ADR-0017.
 *
 * Timeout: 90s — margen para gpt-4o con respuestas largas.
 * El endpoint usa waitUntil con maxDuration: 300s.
 */
export function getOpenAIClient(): OpenAI {
  if (!_openaiClient) {
    const apiKey = process.env['OPENAI_API_KEY']
    if (!apiKey) {
      throw new Error('[openai-client] OPENAI_API_KEY no está configurada')
    }
    _openaiClient = new OpenAI({ apiKey, timeout: 90_000 })
  }
  return _openaiClient
}
