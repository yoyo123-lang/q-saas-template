import type { Metadata } from 'next'
import { prisma } from '@qautiva/db'
import { AGENT_DEFAULTS } from '@/lib/agent-defaults'
import { AgentCard, type AgentCardProps } from '@/components/AgentCard'

export const metadata: Metadata = {
  title: 'Agentes IA | Qautiva Admin',
}

export const dynamic = 'force-dynamic'

// ── Query ──────────────────────────────────────────────────────────────────────

async function getAgents(): Promise<AgentCardProps[]> {
  let configs: AgentCardProps[] = []

  try {
    configs = await prisma.agentConfig.findMany({
      orderBy: { agentNumber: 'asc' },
      take: 6,
      select: {
        id: true,
        agentNumber: true,
        name: true,
        description: true,
        automationLevel: true,
        approvalRate: true,
        avgTime: true,
      },
    })
  } catch (err) {
    console.error('[admin:agentes] error cargando configuraciones:', err)
    // Fallback: usar todos los defaults si la DB no responde
  }

  // Merge DB sobre defaults; si DB falló, devuelve todos los defaults
  const configMap = new Map(configs.map((c) => [c.agentNumber, c]))

  return AGENT_DEFAULTS.map((defaults) => {
    const fromDb = configMap.get(defaults.agentNumber)
    if (!fromDb) {
      return {
        id: `agent-${defaults.agentNumber}`,
        agentNumber: defaults.agentNumber,
        name: defaults.name,
        description: defaults.description,
        automationLevel: defaults.automationLevel,
        approvalRate: defaults.approvalRate,
        avgTime: defaults.avgTime,
      }
    }
    return fromDb
  })
}

// ── Página ─────────────────────────────────────────────────────────────────────

export default async function AgentesPage() {
  const agents = await getAgents()

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-white text-xl font-bold">Agentes IA</h1>
        <p className="text-[#64748B] text-sm mt-0.5">
          Configurá el comportamiento de cada agente del sistema.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent) => (
          <AgentCard key={agent.agentNumber} {...agent} />
        ))}
      </div>
    </div>
  )
}
