import { executeToolCall, type BillingContext, type ToolDefinition } from './ai-tool-call'
import type { BrandOptions, CampaignPlan, MarketStudy, QuestionBlock, StrategicBrief } from './types'
import { buildInterviewSummary } from './brief-generator'

// ── Types ────────────────────────────────────────────────────────────────────

export type PreviousDeliverable =
  | { type: 'BRIEF'; content: StrategicBrief }
  | { type: 'MARKET_STUDY'; content: MarketStudy }
  | { type: 'BRAND_OPTIONS'; content: BrandOptions }
  | { type: string; content: unknown }

export type GenerateCampaignPlanInput = {
  flowDefinition: QuestionBlock[]
  answers: Record<string, unknown>
  project: { name: string; industry: string | null; country: string | null }
  previousDeliverables: PreviousDeliverable[]
  billingContext?: BillingContext
}

// ── Tool definition ───────────────────────────────────────────────────────────

const GENERATE_CAMPAIGN_PLAN_TOOL: ToolDefinition = {
  name: 'generate_campaign_plan',
  description:
    'Genera el Plan de Campaña Publicitaria completo a partir del brief, estudio de mercado, marca y respuestas del cliente.',
  input_schema: {
    type: 'object' as const,
    additionalProperties: false,
    properties: {
      resumen: {
        type: 'object',
        additionalProperties: false,
        properties: {
          objetivos: { type: 'string' },
          duracionEstimada: { type: 'string' },
          presupuestoRecomendado: {
            type: 'object',
            additionalProperties: false,
            properties: {
              min: { type: 'number' },
              max: { type: 'number' },
              justificacion: { type: 'string' },
            },
            required: ['min', 'max', 'justificacion'],
          },
        },
        required: ['objetivos', 'duracionEstimada', 'presupuestoRecomendado'],
      },
      plataformas: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            nombre: { type: 'string', enum: ['GOOGLE_ADS', 'META'] },
            razon: { type: 'string' },
            formatos: {
              type: 'array',
              items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  tipo: { type: 'string' },
                  descripcion: { type: 'string' },
                  presupuestoSugerido: { type: 'number' },
                },
                required: ['tipo', 'descripcion', 'presupuestoSugerido'],
              },
            },
          },
          required: ['nombre', 'razon', 'formatos'],
        },
      },
      audiencias: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            nombre: { type: 'string' },
            descripcion: { type: 'string' },
            tamanioEstimado: { type: 'string' },
            criterios: { type: 'array', items: { type: 'string' } },
          },
          required: ['nombre', 'descripcion', 'tamanioEstimado', 'criterios'],
        },
      },
      oferta: {
        type: 'object',
        additionalProperties: false,
        properties: {
          mensajePrincipal: { type: 'string' },
          variantesCreativas: { type: 'array', items: { type: 'string' } },
          callToAction: { type: 'string' },
        },
        required: ['mensajePrincipal', 'variantesCreativas', 'callToAction'],
      },
      calendario: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            fase: { type: 'string' },
            duracion: { type: 'string' },
            actividades: { type: 'array', items: { type: 'string' } },
            presupuesto: { type: 'number' },
          },
          required: ['fase', 'duracion', 'actividades', 'presupuesto'],
        },
      },
      metricas: {
        type: 'object',
        additionalProperties: false,
        properties: {
          kpisObjetivo: {
            type: 'array',
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                nombre: { type: 'string' },
                meta: { type: 'string' },
                razon: { type: 'string' },
              },
              required: ['nombre', 'meta', 'razon'],
            },
          },
          reportingFrecuencia: { type: 'string' },
        },
        required: ['kpisObjetivo', 'reportingFrecuencia'],
      },
      riesgos: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            riesgo: { type: 'string' },
            probabilidad: { type: 'string', enum: ['alta', 'media', 'baja'] },
            mitigacion: { type: 'string' },
          },
          required: ['riesgo', 'probabilidad', 'mitigacion'],
        },
      },
      disclaimer: { type: 'string' },
    },
    required: [
      'resumen',
      'plataformas',
      'audiencias',
      'oferta',
      'calendario',
      'metricas',
      'riesgos',
      'disclaimer',
    ],
  },
}

// ── Prompt ───────────────────────────────────────────────────────────────────

const SYNTHESIS_SYSTEM_PROMPT = `Sos el Estratega de Campañas de Qautiva. Tu trabajo es diseñar planes de campaña publicitaria en Google Ads y Meta Ads para pequeñas y medianas empresas en Argentina.

Instrucciones:
1. Usá toda la información disponible (brief estratégico, estudio de mercado, identidad de marca) para fundamentar cada decisión
2. Las plataformas deben justificarse según el negocio: no recomendés Google Ads para un producto de descubrimiento, ni Meta si el cliente busca intención de compra directa
3. Los presupuestos deben ser realistas para PyMEs en Argentina (en pesos ARS). No inflés los números
4. El mensaje principal debe derivarse directamente del mensajeCentral del Brief — no inventés uno nuevo
5. Los KPIs deben ser medibles y específicos. Evitá métricas de vanidad
6. Identificá al menos 2 riesgos reales (no genéricos)
7. El disclaimer DEBE incluir: (a) que es un plan generado por IA, (b) que los presupuestos son estimativos, (c) que se recomienda validar con un especialista antes de invertir. Mínimo 2 oraciones.

Acción: Llamá a generate_campaign_plan con el plan completo.`

// Disclaimer mínimo garantizado por código — se antepone al disclaimer generado por IA.
// Esto protege legalmente a Qautiva independientemente de lo que genere el modelo.
const MIN_DISCLAIMER_PREFIX = 'Este plan fue generado por inteligencia artificial como propuesta inicial. ' +
  'Las proyecciones de presupuesto, audiencias y métricas son estimativas y no garantizan resultados. ' +
  'Se recomienda validar con un especialista en publicidad digital antes de invertir. '

// ── Función principal ─────────────────────────────────────────────────────────

/**
 * Genera el CampaignPlan a partir de deliverables anteriores y respuestas del cliente.
 *
 * @param input - Datos del proyecto, deliverables anteriores y respuestas
 * @returns CampaignPlan estructurado
 * @throws Error si el modelo falla o devuelve output inválido
 */
export async function generateCampaignPlan(input: GenerateCampaignPlanInput): Promise<CampaignPlan> {
  const context = buildContextSummary(input)
  const interviewContent = buildInterviewSummary(input.flowDefinition, input.answers)

  const userMessage = [
    `CONTEXTO DEL NEGOCIO:\n${context}`,
    interviewContent.length > 0 && input.flowDefinition.length > 0
      ? `PREFERENCIAS DEL CLIENTE (entrevista):\n${interviewContent}`
      : null,
    'Generá el Plan de Campaña Publicitaria.',
  ]
    .filter(Boolean)
    .join('\n\n---\n\n')

  const result = await executeToolCall({
    system: SYNTHESIS_SYSTEM_PROMPT,
    userMessage,
    tool: GENERATE_CAMPAIGN_PLAN_TOOL,
    maxTokens: 16384,
    logPrefix: 'campaign-strategy-generator',
    billingContext: input.billingContext ? { ...input.billingContext, operation: 'campaign_strategy' } : undefined,
  })

  const plan = validateCampaignPlan(result.input)

  // Garantizar disclaimer mínimo — el modelo puede generar uno complementario
  plan.disclaimer = MIN_DISCLAIMER_PREFIX + plan.disclaimer

  return plan
}

// ── Validación runtime ────────────────────────────────────────────────────────

/**
 * Valida que el output del modelo tenga la estructura esperada de CampaignPlan.
 * Lanza Error descriptivo si falta algún campo estructural.
 */
function validateCampaignPlan(raw: unknown): CampaignPlan {
  if (typeof raw !== 'object' || raw === null) {
    throw new Error('[campaign-strategy-generator] Output no es un objeto')
  }
  const obj = raw as Record<string, unknown>

  // ── resumen ──
  if (typeof obj['resumen'] !== 'object' || obj['resumen'] === null) {
    throw new Error('[campaign-strategy-generator] Falta resumen')
  }
  const resumen = obj['resumen'] as Record<string, unknown>
  if (typeof resumen['objetivos'] !== 'string') {
    throw new Error('[campaign-strategy-generator] resumen.objetivos debe ser string')
  }
  if (typeof resumen['duracionEstimada'] !== 'string') {
    throw new Error('[campaign-strategy-generator] resumen.duracionEstimada debe ser string')
  }
  if (typeof resumen['presupuestoRecomendado'] !== 'object' || resumen['presupuestoRecomendado'] === null) {
    throw new Error('[campaign-strategy-generator] Falta resumen.presupuestoRecomendado')
  }
  const presupuesto = resumen['presupuestoRecomendado'] as Record<string, unknown>
  if (typeof presupuesto['min'] !== 'number' || typeof presupuesto['max'] !== 'number') {
    throw new Error('[campaign-strategy-generator] presupuestoRecomendado.min/max deben ser número')
  }

  // ── plataformas ──
  if (!Array.isArray(obj['plataformas'])) {
    throw new Error('[campaign-strategy-generator] plataformas debe ser array')
  }
  for (const p of obj['plataformas'] as unknown[]) {
    if (typeof p !== 'object' || p === null) {
      throw new Error('[campaign-strategy-generator] plataformas[*] debe ser objeto')
    }
    const plat = p as Record<string, unknown>
    if (plat['nombre'] !== 'GOOGLE_ADS' && plat['nombre'] !== 'META') {
      throw new Error('[campaign-strategy-generator] plataformas[*].nombre debe ser GOOGLE_ADS o META')
    }
    if (!Array.isArray(plat['formatos'])) {
      throw new Error('[campaign-strategy-generator] plataformas[*].formatos debe ser array')
    }
  }

  // ── audiencias ──
  if (!Array.isArray(obj['audiencias'])) {
    throw new Error('[campaign-strategy-generator] audiencias debe ser array')
  }
  for (const a of obj['audiencias'] as unknown[]) {
    if (typeof a !== 'object' || a === null) {
      throw new Error('[campaign-strategy-generator] audiencias[*] debe ser objeto')
    }
    const aud = a as Record<string, unknown>
    if (typeof aud['nombre'] !== 'string') {
      throw new Error('[campaign-strategy-generator] audiencias[*].nombre debe ser string')
    }
    if (!Array.isArray(aud['criterios'])) {
      throw new Error('[campaign-strategy-generator] audiencias[*].criterios debe ser array')
    }
  }

  // ── oferta ──
  if (typeof obj['oferta'] !== 'object' || obj['oferta'] === null) {
    throw new Error('[campaign-strategy-generator] Falta oferta')
  }
  const oferta = obj['oferta'] as Record<string, unknown>
  if (typeof oferta['mensajePrincipal'] !== 'string') {
    throw new Error('[campaign-strategy-generator] oferta.mensajePrincipal debe ser string')
  }
  if (!Array.isArray(oferta['variantesCreativas'])) {
    throw new Error('[campaign-strategy-generator] oferta.variantesCreativas debe ser array')
  }
  if (typeof oferta['callToAction'] !== 'string') {
    throw new Error('[campaign-strategy-generator] oferta.callToAction debe ser string')
  }

  // ── calendario ──
  if (!Array.isArray(obj['calendario'])) {
    throw new Error('[campaign-strategy-generator] calendario debe ser array')
  }
  for (const c of obj['calendario'] as unknown[]) {
    if (typeof c !== 'object' || c === null) {
      throw new Error('[campaign-strategy-generator] calendario[*] debe ser objeto')
    }
    const cal = c as Record<string, unknown>
    if (typeof cal['fase'] !== 'string') {
      throw new Error('[campaign-strategy-generator] calendario[*].fase debe ser string')
    }
    if (typeof cal['presupuesto'] !== 'number') {
      throw new Error('[campaign-strategy-generator] calendario[*].presupuesto debe ser número')
    }
    if (!Array.isArray(cal['actividades'])) {
      throw new Error('[campaign-strategy-generator] calendario[*].actividades debe ser array')
    }
  }

  // ── metricas ──
  if (typeof obj['metricas'] !== 'object' || obj['metricas'] === null) {
    throw new Error('[campaign-strategy-generator] Falta metricas')
  }
  const metricas = obj['metricas'] as Record<string, unknown>
  if (!Array.isArray(metricas['kpisObjetivo'])) {
    throw new Error('[campaign-strategy-generator] metricas.kpisObjetivo debe ser array')
  }
  if (typeof metricas['reportingFrecuencia'] !== 'string') {
    throw new Error('[campaign-strategy-generator] metricas.reportingFrecuencia debe ser string')
  }

  // ── riesgos ──
  if (!Array.isArray(obj['riesgos'])) {
    throw new Error('[campaign-strategy-generator] riesgos debe ser array')
  }
  for (const r of obj['riesgos'] as unknown[]) {
    if (typeof r !== 'object' || r === null) {
      throw new Error('[campaign-strategy-generator] riesgos[*] debe ser objeto')
    }
    const risk = r as Record<string, unknown>
    if (typeof risk['riesgo'] !== 'string') {
      throw new Error('[campaign-strategy-generator] riesgos[*].riesgo debe ser string')
    }
    const prob = risk['probabilidad']
    if (prob !== 'alta' && prob !== 'media' && prob !== 'baja') {
      throw new Error('[campaign-strategy-generator] riesgos[*].probabilidad debe ser alta/media/baja')
    }
  }

  // ── disclaimer ──
  if (typeof obj['disclaimer'] !== 'string') {
    throw new Error('[campaign-strategy-generator] disclaimer debe ser string')
  }

  return raw as CampaignPlan
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Construye un resumen de contexto a partir de los deliverables anteriores.
 * Extrae los datos más relevantes de cada etapa para el prompt del generador.
 */
function buildContextSummary(input: GenerateCampaignPlanInput): string {
  const sections: string[] = []

  sections.push(`Negocio: ${input.project.name}`)
  if (input.project.industry) sections.push(`Industria: ${input.project.industry}`)
  if (input.project.country) sections.push(`País: ${input.project.country}`)

  for (const d of input.previousDeliverables) {
    if (d.type === 'BRIEF' && d.content) {
      const brief = d.content as StrategicBrief
      sections.push(
        `\n## Brief Estratégico\n` +
        `- Descripción: ${brief.negocio?.descripcion ?? 'N/A'}\n` +
        `- Posicionamiento: ${brief.posicionamiento?.estrategia ?? 'N/A'} — ${brief.posicionamiento?.nichoEspecifico ?? 'N/A'}\n` +
        `- Mensaje central: ${brief.direccionComunicacional?.mensajeCentral ?? 'N/A'}\n` +
        `- Tono: ${brief.direccionComunicacional?.tonoSugerido ?? 'N/A'}\n` +
        `- Perfil de cliente: ${brief.audiencia?.perfilCliente ?? 'N/A'}\n` +
        `- Ventaja competitiva: ${brief.posicionamiento?.ventajaCompetitiva ?? 'N/A'}`
      )
    }

    if (d.type === 'MARKET_STUDY' && d.content) {
      const study = d.content as MarketStudy
      const oportunidades = study.oportunidades
        ?.slice(0, 3)
        .map((o) => `  * ${o.descripcion}`)
        .join('\n') ?? 'N/A'
      const keywords = study.presenciaDigital?.keywordsOportunidad?.slice(0, 5).join(', ') ?? 'N/A'
      sections.push(
        `\n## Estudio de Mercado\n` +
        `- Nivel de competencia: ${study.resumenEjecutivo?.nivelCompetencia ?? 'N/A'}\n` +
        `- Oportunidad principal: ${study.resumenEjecutivo?.oportunidadPrincipal ?? 'N/A'}\n` +
        `- Keywords con oportunidad: ${keywords}\n` +
        `- Top oportunidades:\n${oportunidades}`
      )
    }

    if (d.type === 'BRAND_OPTIONS' && d.content) {
      const brand = d.content as BrandOptions
      const firstOption = brand.options?.[0]
      if (firstOption) {
        sections.push(
          `\n## Identidad de Marca\n` +
          `- Concepto: ${firstOption.label}\n` +
          `- Personalidad: ${firstOption.brandPersonality?.join(', ') ?? 'N/A'}`
        )
      }
    }
  }

  return sections.join('\n')
}
