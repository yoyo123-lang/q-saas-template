'use client'

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts'

type DataPoint = {
  date: string   // "1 mar", "5 mar", etc.
  visitas: number
  consultas: number
}

type MetricsChartProps = {
  data: DataPoint[]
}

type CustomTooltipProps = {
  active?: boolean
  payload?: Array<{ name: string; value: number; color: string }>
  label?: string
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null

  return (
    <div className="bg-[#1E293B] border border-[#1E293B] rounded-lg px-3 py-2 shadow-lg">
      <p className="text-[#64748B] text-xs mb-1">{label}</p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-sm font-medium" style={{ color: entry.color }}>
          {entry.name}: {entry.value.toLocaleString('es-AR')}
        </p>
      ))}
    </div>
  )
}

/**
 * Gráfico de líneas (Recharts) con visitas y consultas de los últimos 30 días.
 * Client Component — Recharts no soporta SSR.
 * Tooltip y leyenda con estilos dark (bg-[#1E293B]).
 */
export function MetricsChart({ data }: MetricsChartProps) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <h2 className="text-white font-semibold mb-1">Visitas y consultas</h2>
      <p className="text-[#64748B] text-xs mb-5">Últimos 30 días</p>

      <ResponsiveContainer width="100%" height={240}>
        <LineChart data={data} margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fill: '#64748B', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: '#64748B', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            width={40}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            wrapperStyle={{ paddingTop: '12px' }}
            formatter={(value) => (
              <span style={{ color: '#94A3B8', fontSize: '12px' }}>{value}</span>
            )}
          />
          <Line
            type="monotone"
            dataKey="visitas"
            stroke="#8B5CF6"
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4, fill: '#8B5CF6' }}
          />
          <Line
            type="monotone"
            dataKey="consultas"
            stroke="#10B981"
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4, fill: '#10B981' }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
