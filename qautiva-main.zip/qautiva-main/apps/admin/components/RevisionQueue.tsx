import Link from 'next/link'
import { DELIVERABLE_STATUS_BADGE, DELIVERABLE_TYPE_LABEL, PLAN_BADGE } from '@/lib/badges'
import type { StageForReview } from '@/app/(protected)/revision/page'

// ── Helpers ────────────────────────────────────────────────────────────────────

function timeAgo(date: Date): string {
  const diff = Date.now() - new Date(date).getTime()
  const hours = Math.floor(diff / 3_600_000)
  if (hours < 1) return 'hace menos de 1h'
  if (hours < 24) return `hace ${hours}h`
  const days = Math.floor(hours / 24)
  return `hace ${days}d`
}

// ── Sub-componentes ────────────────────────────────────────────────────────────

function QueueCard({ item }: { item: StageForReview }) {
  const planBadge = PLAN_BADGE[item.organization.plan]
  const initial = item.organization.name.charAt(0).toUpperCase()

  return (
    <div className="flex items-start gap-4 p-4 rounded-xl bg-[#0F172A] border border-[#F59E0B]/30 hover:border-[#F59E0B]/60 transition-colors">
      {/* Avatar org */}
      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#F59E0B]/15 flex items-center justify-center">
        <span className="text-[#FBBF24] font-bold text-sm">{initial}</span>
      </div>

      {/* Info */}
      <div className="flex flex-col gap-1.5 flex-1 min-w-0">
        <div className="flex items-baseline gap-2 flex-wrap">
          <p className="text-white font-semibold text-sm">{item.organization.name}</p>
          <span className="text-[#64748B] text-xs">·</span>
          <p className="text-[#94A3B8] text-xs">
            Etapa {item.number} — {item.name}
          </p>
        </div>

        {/* Badges */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${planBadge.className}`}>
            {planBadge.label}
          </span>
          <span className="text-[#64748B] text-[11px]">{item.organization.industry}</span>
          <span className="text-[#475569] text-[11px]">{timeAgo(item.updatedAt)}</span>
        </div>

        {/* Entregables */}
        {item.deliverables.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-1">
            {item.deliverables.map((d) => {
              const badge = DELIVERABLE_STATUS_BADGE[d.status]
              return (
                <span
                  key={d.id}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium ${badge.className}`}
                  title={DELIVERABLE_TYPE_LABEL[d.type]}
                >
                  {d.title}
                </span>
              )
            })}
          </div>
        )}
      </div>

      {/* Acción */}
      <Link
        href={`/revision?stage=${item.id}&org=${item.organization.id}`}
        className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-[#F59E0B]/15 text-[#FBBF24] text-xs font-medium border border-[#F59E0B]/30 hover:bg-[#F59E0B]/25 transition-colors whitespace-nowrap"
      >
        Revisar
      </Link>
    </div>
  )
}

// ── Componente principal ────────────────────────────────────────────────────────

interface RevisionQueueProps {
  items: StageForReview[]
}

export function RevisionQueue({ items }: RevisionQueueProps) {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center flex-1 gap-3">
        <p className="text-[#34D399] text-2xl">✓</p>
        <p className="text-white font-semibold">Todo al día</p>
        <p className="text-[#64748B] text-sm">No hay etapas esperando revisión.</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-3 overflow-y-auto flex-1 pb-4">
      {items.map((item) => (
        <QueueCard key={item.id} item={item} />
      ))}
    </div>
  )
}
