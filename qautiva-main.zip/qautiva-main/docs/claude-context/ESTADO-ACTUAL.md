# Qautiva — Estado Actual del Proyecto

> Documento para conversaciones con Claude donde necesites contexto sobre
> qué está hecho, qué falta, y qué decisiones se tomaron.
> Última actualización: 2026-03-11

---

## Estado por etapas

| Etapa | Nombre | Estado |
|-------|--------|--------|
| 1 | Foundation | ✅ Completa |
| 2 | Landing completa | ✅ Completa |
| 3 | Portal del cliente (self-service) | ✅ Completa y revisada |
| 4 | Backoffice admin + Telegram Bot | ⏳ En progreso (4.1-4.3 hechos) |
| 5 | Integración y pulido | 🔒 Bloqueada hasta Etapa 4 |

---

## Etapa 1 — Foundation (completada)

**Lo que incluye:**
- Monorepo pnpm con workspaces (`packages/*`, `apps/*`, `services/*`)
- `packages/db`: Schema Prisma completo con RLS, seed con datos argentinos realistas
- `packages/ui`: Design system (Button, Card, Badge, Input, ProgressBar, Sidebar) + tokens
- `apps/landing`: Estructura base + reCAPTCHA v3 + API de contacto
- `apps/portal`: Layout + Auth (Google OAuth + email/password) + middleware + dashboard mock
- `apps/admin`: Layout + Auth admin + middleware + health check
- `services/telegram-bot`: Estructura base + comandos (`/start`, `/status`, `/help`) + message-bridge
- Vitest configurado con tests base
- TypeScript strict, sin `any`, sin `console.log`

---

## Etapa 2 — Landing completa (completada)

**Lo que incluye:**
- Todas las secciones implementadas: Hero, HowItWorks, Deliverables, WhyDifferent, Pricing, Ecosystem, FinalCta, Footer
- Animaciones de scroll
- Diseño responsive completo
- SEO con metadata
- Formulario de contacto con reCAPTCHA v3
- Listo para deploy en Vercel

---

## Etapa 3 — Portal del cliente (completada y revisada)

**Lo que incluye:**
- Wizard de onboarding self-service (4 pasos: sign up → negocio → servicios → modo IA)
- Dashboard por proyecto (`/proyectos/[id]/progreso`)
- Aprobación de entregables (BrandApproval, WebPreview, GenericDeliverable)
- Chat multicanal con Supabase Realtime (deduplicación por ID)
- Encriptación AES-256-GCM para API keys BYOK
- AutoRefresh en pantalla GENERATING
- `unstable_cache` en layouts (TTL 60s)
- Revisión pre-producción completa (6 roles de auditoría, todos los CRÍTICO/ALTO/MEDIO corregidos)

**Pendientes menores (no bloqueantes):**
- Reemplazar `window.location.href` por `router.push()` en api-key/client.tsx
- Extraer `BaseSidebar` compartido
- Mover tipos `BrandOptionContent` / `WebsiteContent` a módulo compartido
- Verificar trigger Supabase para `BillingAccount`

---

## Etapa 4 — Backoffice admin + Telegram Bot (en progreso)

### Hecho (4.1 - 4.3)

**4.1 Dashboard Kanban (`/`):**
- KanbanBoard con 7 columnas por status de organización
- Filtros server-side: plan, industry, status, texto libre
- ClientCard con badge de plan/status, borde pulsante si espera revisión
- MetricsRow con 5 KPIs

**4.2 Ficha del cliente (`/clientes/[id]`):**
- Query única con includes, 4 tabs URL-based (Progreso | Entregables | Conversaciones | Notas)
- ClientHeader con avatar, nombre, badges, suscripción ARS
- Tabs con contadores
- Loading skeleton con animate-pulse
- Error boundary con digest

**4.3 Cola de revisión (`/revision`):**
- Dual-mode: cola (sin params) o detalle (?stage=X&org=Y)
- RevisionQueue con timeAgo, badge urgente si >12hs
- RevisionPanel con breadcrumb, deliverables, ApproveStageForm + RejectStageForm
- Server Actions con `requireAdminSession()` + ownership checks
- Badges centralizados en `lib/badges.ts`

**Server Actions implementados:**
- `createAdminNote` — con ownership check
- `sendAdminMessage` — intervención en conversación
- `approveStage` — con confirm() en UI
- `rejectStage` — con campo de razón + transaction atómica

### Pendiente

**4.4 Configuración de agentes (`/agentes`):**
- Grid de 6 AgentCards con toggle 3 estados (Manual | Semi-auto | Auto)
- Detalle con prompt editor + historial
- Los 6 agentes: Estratega, Investigador, Director Creativo, Arquitecto Web, Media Planner, Periodista

**4.5 Bot de Telegram con LLM:**
- Integrar Anthropic SDK (Haiku para FAQ, Sonnet para complejas)
- Escalado de modelo automático
- Rate limiting por `TelegramConfig.rate_limit_per_hour`
- Vincular `/start` a Projects (self-service) además de Organizations (legacy)

**4.6 Admin del bot (`/telegram`):**
- Config: habilitar/deshabilitar, modelo LLM, rate limit, system prompt
- CRUD de TelegramConfig

**4.7 Route Handlers:**
- PATCH deliverables review (approve/reject/regenerate)
- POST messages (intervención admin)
- PATCH agents config
- PATCH telegram config

**4.8 Tests:**
- API de review (auth + estados)
- API de messages (auth + rol)
- LLM service (mock Anthropic, escalado de modelo)

---

## Etapa 5 — Integración y pulido (bloqueada)

- Integración end-to-end de todos los flujos
- Pulido de UX y performance
- Deploy final a producción

---

## Costos estimados (producción)

| Fase | Costo mensual |
|------|---------------|
| MVP (0-50 clientes) | ~$55-70/mo |
| Growth (50-500) | ~$105-255/mo |
| Scale (500-5000) | ~$265-2085/mo |

Principales costos: Supabase Pro ($25), Vercel Pro ($20), Railway (~$5-40), Anthropic API ($5-2000 según volumen).
