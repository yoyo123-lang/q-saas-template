'use client'

import { FileText, BarChart3, Palette, Monitor, Megaphone, Newspaper } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { RefObject } from 'react'
import { useInView } from '@/lib/use-in-view'

interface DeliverableItem {
  Icon: LucideIcon
  title: string
  description: string
  accentBorder?: boolean
}

const ITEMS: DeliverableItem[] = [
  {
    Icon: FileText,
    title: 'Brief estratégico',
    description: 'Un análisis claro de tu negocio, tu público y tu oportunidad.',
  },
  {
    Icon: BarChart3,
    title: 'Estudio de mercado',
    description: 'Datos reales sobre competencia, búsquedas y precios del sector.',
  },
  {
    Icon: Palette,
    title: 'Manual de marca',
    description: 'Logo, colores, tipografía y guía de uso profesional.',
  },
  {
    Icon: Monitor,
    title: 'Sitio web publicado',
    description: 'Página profesional, rápida y lista para recibir clientes.',
    accentBorder: true,
  },
  {
    Icon: Megaphone,
    title: 'Campañas activas',
    description: 'Google Ads y Meta Ads con textos y creatividades.',
  },
  {
    Icon: Newspaper,
    title: 'Presencia en medios',
    description: 'Notas sobre tu negocio en portales de noticias.',
  },
]

export function Deliverables() {
  const { ref, isVisible } = useInView()

  return (
    <section
      id="que-recibis"
      ref={ref as RefObject<HTMLElement>}
      className="bg-navy-950 py-20 md:py-24"
    >
      <div className="max-w-6xl mx-auto px-6">
        <h2 className={`text-3xl md:text-4xl font-bold text-white text-center mb-16 reveal ${isVisible ? 'visible' : ''}`}>
          Todo esto es tuyo
        </h2>

        <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 reveal-stagger ${isVisible ? 'visible' : ''}`}>
          {ITEMS.map(({ Icon, title, description, accentBorder }) => (
            <div
              key={title}
              className={`bg-navy-900 rounded-card p-6 border transition-colors duration-200 hover:border-accent ${
                accentBorder ? 'border-accent' : 'border-navy-800'
              }`}
            >
              <Icon className="text-accent mb-4" size={28} />
              <h3 className="text-white font-semibold mb-2">{title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
