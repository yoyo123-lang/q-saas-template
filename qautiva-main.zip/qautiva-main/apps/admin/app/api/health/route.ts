import { NextResponse } from 'next/server'

interface HealthStatus {
  status: 'ok' | 'degraded' | 'down'
  timestamp: string
  checks: {
    database: 'ok' | 'error' | 'not_checked'
    supabase: 'ok' | 'error' | 'not_checked'
    stitch: 'ok' | 'error' | 'not_configured' | 'not_checked'
  }
}

export async function GET(): Promise<NextResponse<HealthStatus>> {
  const timestamp = new Date().toISOString()

  // Verificación de Stitch: confirmar que la API key está configurada.
  // Un check de red real requeriría una llamada al SDK que puede tardar 1-5s.
  // Dada la latencia del health check, solo verificamos presencia de la key.
  const stitchStatus: HealthStatus['checks']['stitch'] = process.env['STITCH_API_KEY']
    ? 'ok'
    : 'not_configured'

  const allOk = stitchStatus === 'ok'
  const status: HealthStatus = {
    status: allOk ? 'ok' : 'degraded',
    timestamp,
    checks: {
      database: 'not_checked', // se implementa en Etapa 3
      supabase: 'not_checked', // se implementa en Etapa 3
      stitch: stitchStatus,
    },
  }
  return NextResponse.json(status)
}
