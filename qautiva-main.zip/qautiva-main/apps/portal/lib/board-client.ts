const BOARD_URL = process.env.BOARD_URL!
const BOARD_API_KEY = process.env.BOARD_API_KEY!
const BOARD_BU_ID = process.env.BOARD_BU_ID!

async function boardFetch(path: string, options: RequestInit = {}) {
  const url = `${BOARD_URL}/api/v1/bu/${BOARD_BU_ID}${path}`

  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': BOARD_API_KEY,
      ...options.headers,
    },
  })

  if (!response.ok) {
    const body = await response.text()
    throw new Error(`Board API error ${response.status}: ${body}`)
  }

  return response.json()
}

/** Enviar heartbeat — llamar cada 5 minutos */
export async function sendHeartbeat(checks: Record<string, string>) {
  return boardFetch('/heartbeat', {
    method: 'POST',
    body: JSON.stringify({
      version: process.env.npm_package_version ?? '0.0.1',
      uptime_seconds: Math.floor(process.uptime()),
      checks,
    }),
  })
}

/** Enviar métricas — máximo 100 por request */
export async function sendMetrics(
  metrics: Array<{ key: string; value: number; period: string; metadata?: Record<string, unknown> }>
) {
  return boardFetch('/metrics', {
    method: 'POST',
    body: JSON.stringify({ metrics }),
  })
}

/** Enviar eventos — máximo 100 por request, occurred_at en UTC */
export async function sendEvents(
  events: Array<{ type: string; payload: Record<string, unknown>; occurred_at: string }>
) {
  return boardFetch('/events', {
    method: 'POST',
    body: JSON.stringify({ events }),
  })
}

/** Actualizar estado de una directiva recibida */
export async function updateDirectiveStatus(
  directiveId: string,
  status: 'in_progress' | 'completed' | 'failed' | 'rejected',
  notes?: string,
  result?: Record<string, unknown>
) {
  return boardFetch(`/directives/${directiveId}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status, notes, result }),
  })
}
