import { NextResponse, type NextRequest } from 'next/server'
import { sendHeartbeat } from '@/lib/board-client'

export const runtime = 'nodejs'

/**
 * GET /api/cron/board-heartbeat
 *
 * Envía heartbeat al Q Company Board cada 5 minutos.
 * Si no llega en 15 min, el Board genera una alerta automática.
 * Invocado por Vercel Cron.
 *
 * Autenticación: CRON_SECRET en el header Authorization.
 */
export async function GET(request: NextRequest) {
  const cronSecret = process.env.CRON_SECRET
  const authHeader = request.headers.get('authorization')
  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const checks: Record<string, string> = { api: 'ok' }

  await sendHeartbeat(checks)
  return NextResponse.json({ success: true })
}
