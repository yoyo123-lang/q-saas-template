import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { TabNav } from './_components/TabNav'
import { AccountTab } from './_components/AccountTab'
import { AiTab } from './_components/AiTab'
import { PlanTab } from './_components/PlanTab'

export const metadata: Metadata = { title: 'Configuración — Qautiva' }

const VALID_TABS = ['cuenta', 'ia', 'plan'] as const
const VALID_TABS_LEGACY = ['cuenta', 'publicidad'] as const
type TabId = (typeof VALID_TABS)[number]
type LegacyTabId = (typeof VALID_TABS_LEGACY)[number]
type AnyTabId = TabId | LegacyTabId

type SearchParams = { tab?: string }

export default async function ConfiguracionPage({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-4">Configuración</h1>
        <p className="text-[#94A3B8]">No autenticado.</p>
      </div>
    )
  }

  const meta = user.app_metadata ?? {}
  const isLegacy = Boolean(meta.org_id)
  const rawTab = searchParams.tab

  const authProvider =
    (user.app_metadata?.provider as string | undefined) ??
    (user.identities?.[0]?.provider as string | undefined) ??
    'email'

  // Cargar perfil + datos secundarios en paralelo
  const membershipQuery = !isLegacy
    ? prisma.teamMember.findFirst({
        where: { user: { authUserId: user.id } },
        include: {
          team: {
            include: {
              apiKeys: {
                select: { id: true, provider: true, keyHint: true, label: true, isValid: true, lastUsedAt: true, lastError: true, createdAt: true },
                orderBy: { createdAt: 'asc' },
              },
              billing: {
                select: {
                  plan: true, preferredKeySource: true,
                  trialTokensTotal: true, trialTokensUsed: true, trialExpiresAt: true,
                  tokenQuota: true, tokensUsed: true,
                  currentPeriodStart: true, currentPeriodEnd: true, balanceUsd: true,
                },
              },
            },
          },
        },
      })
    : Promise.resolve(null)

  const orgQuery = isLegacy && meta.org_id
    ? prisma.organization.findUnique({
        where: { id: meta.org_id as string },
        select: { name: true, industry: true, plan: true, status: true, createdAt: true, websiteUrl: true },
      })
    : Promise.resolve(null)

  const [profile, orgData, membership] = await Promise.all([
    prisma.userProfile.findUnique({
      where: { authUserId: user.id },
      select: { displayName: true, email: true, avatarUrl: true },
    }),
    orgQuery,
    membershipQuery,
  ])

  const orgStatus = orgData?.status ?? ''
  const showPublicidad = isLegacy && (orgStatus === 'CAMPAIGNS' || orgStatus === 'LAUNCHED')

  const activeTab: AnyTabId = (() => {
    if (!isLegacy && VALID_TABS.includes(rawTab as TabId)) return rawTab as TabId
    if (isLegacy && showPublicidad && VALID_TABS_LEGACY.includes(rawTab as LegacyTabId)) return rawTab as LegacyTabId
    return 'cuenta'
  })()

  const teamData = membership
    ? {
        apiKeys: membership.team.apiKeys.map((k) => ({ ...k, provider: k.provider as string })),
        billing: membership.team.billing
          ? { ...membership.team.billing, balanceUsd: membership.team.billing.balanceUsd.toString() }
          : null,
      }
    : null

  return (
    <div className="p-8 max-w-2xl">
      <h1 className="text-2xl font-bold text-white mb-6">Configuración</h1>

      <TabNav activeTab={activeTab} isLegacy={isLegacy} showPublicidad={showPublicidad} />

      {activeTab === 'cuenta' && (
        <AccountTab
          displayName={profile?.displayName ?? ''}
          email={profile?.email ?? user.email ?? ''}
          avatarUrl={profile?.avatarUrl ?? null}
          authProvider={authProvider}
          isLegacy={isLegacy}
          orgData={orgData}
        />
      )}

      {activeTab === 'ia' && !isLegacy && teamData && (
        <AiTab
          apiKeys={teamData.apiKeys}
          preferredKeySource={teamData.billing?.preferredKeySource ?? 'QAUTIVA_HOSTED'}
          billingPlan={teamData.billing?.plan ?? 'FREE_TRIAL'}
        />
      )}

      {activeTab === 'ia' && !isLegacy && !teamData && (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6">
          <p className="text-[#94A3B8] text-sm">No se encontraron datos del equipo.</p>
        </div>
      )}

      {activeTab === 'plan' && !isLegacy && (
        <PlanTab
          billing={teamData?.billing ?? null}
          orgData={orgData}
          isLegacy={isLegacy}
        />
      )}

      {activeTab === 'publicidad' && isLegacy && (
        <div className="space-y-4">
          <div className="p-5 rounded-xl border border-[#1E293B] bg-[#0F172A]">
            <h2 className="text-sm font-semibold text-white mb-1">Campañas publicitarias</h2>
            <p className="text-sm text-[#94A3B8] mb-4">
              Tu plan de campaña y las piezas publicitarias están disponibles en la sección Campañas.
            </p>
            <a
              href="/campanas"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-sm font-medium transition-colors"
            >
              Ver campañas →
            </a>
          </div>
          <div className="p-5 rounded-xl border border-[#1E293B] bg-[#0F172A]">
            <h2 className="text-sm font-semibold text-white mb-1">Cuentas de Google Ads y Meta Ads</h2>
            <p className="text-sm text-[#94A3B8]">
              Para conectar o gestionar tus cuentas publicitarias, contactá a nuestro equipo a través del chat.
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
