'use client'

import { Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'solid' | 'outline' | 'outline-danger' | 'outline-success' | 'ghost' | 'link'
  size?: 'sm' | 'md' | 'lg' | 'full'
  loading?: boolean
  icon?: React.ReactNode
  iconRight?: React.ReactNode
  children: React.ReactNode
}

const variantClasses: Record<NonNullable<ButtonProps['variant']>, string> = {
  solid:
    'bg-amber-500 text-navy-950 hover:bg-amber-400 border border-amber-500 hover:border-amber-400',
  outline:
    'border border-amber-500 text-amber-500 bg-transparent hover:bg-amber-500/10',
  'outline-danger':
    'border border-red-500 text-red-500 bg-transparent hover:bg-red-500/10',
  'outline-success':
    'border border-emerald-500 text-emerald-500 bg-transparent hover:bg-emerald-500/10',
  ghost:
    'border border-transparent text-slate-400 bg-transparent hover:text-slate-50',
  link:
    'border-0 bg-transparent text-amber-500 hover:underline p-0',
}

const sizeClasses: Record<NonNullable<ButtonProps['size']>, string> = {
  sm:   'px-3 py-1.5 text-sm',
  md:   'px-4 py-2 text-sm',
  lg:   'px-6 py-3 text-base',
  full: 'w-full px-4 py-3 text-base',
}

export function Button({
  variant = 'solid',
  size = 'md',
  loading = false,
  disabled,
  icon,
  iconRight,
  children,
  className,
  ...props
}: ButtonProps) {
  const isDisabled = disabled || loading

  return (
    <button
      disabled={isDisabled}
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium',
        'transition-colors duration-150',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2 focus-visible:ring-offset-navy-950',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        variantClasses[variant],
        variant !== 'link' && sizeClasses[size],
        className
      )}
      {...props}
    >
      {loading ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        icon && <span className="size-4 flex items-center">{icon}</span>
      )}
      {children}
      {!loading && iconRight && (
        <span className="size-4 flex items-center">{iconRight}</span>
      )}
    </button>
  )
}
