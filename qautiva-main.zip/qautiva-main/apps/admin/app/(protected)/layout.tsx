import { AdminSidebar } from '@/components/AdminSidebar'
import { prisma } from '@qautiva/db'

export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const reviewQueueCount = await prisma.stage.count({
    where: { status: 'ADMIN_REVIEW' },
  })

  return (
    <div className="flex min-h-screen bg-[#0B0F1A]">
      <AdminSidebar reviewQueueCount={reviewQueueCount} />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  )
}
