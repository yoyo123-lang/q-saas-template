# Sesión 03 — Auth y Perfiles

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 02 — Landing, catálogo, detalle y "cómo funciona" construidos. Catálogo navegable con datos reales.

Esta sesión implementa el sistema completo de autenticación: login, registro con Google OAuth, recuperación de contraseña, y página de perfil.

Leer antes de empezar:
- `PLAN.md` — Etapa 4
- `docs/frontend/06-auth-y-formularios.md` — especificación completa de auth y formularios
- `docs/frontend/02-componentes-base.md` — componentes existentes a reutilizar

## Estado actual

Ya existe:
- Middleware de auth en `src/middleware.ts`
- Supabase clients en `src/lib/supabase/`
- Componentes UI: Button, Card, Badge, Input, Textarea, Select, Modal, Divider, Avatar

## Tarea de esta sesión

### 1. Instalar dependencias nuevas

```bash
npm install react-hook-form zod @hookform/resolvers
```

Sonner ya fue instalado en Sesión 01.

### 2. Schemas Zod en `src/lib/schemas/auth.ts`

```ts
// loginSchema: email + password (min 8)
// registerSchema: nombre, email, password (min 8 + mayúscula + número), confirmPassword, rol (BUYER|SELLER), acceptTerms z.literal(true)
// recuperarSchema: email
// nuevaContrasenaSchema: password + confirmPassword con .refine()
```

Ver `docs/frontend/06-auth-y-formularios.md` §validación para los regex exactos.

### 3. Componentes nuevos de auth

#### `src/components/ui/password-strength.tsx`
Barra de 3 segmentos que se colorean según el score (débil=rojo, media=amber, fuerte=verde). Score calculado por: longitud ≥8, mayúscula, número, carácter especial. Ver `docs/frontend/06-auth-y-formularios.md` §PasswordStrength.

#### `src/components/auth/role-card.tsx`
Card seleccionable para elegir rol en registro. Props: `value`, `selected`, `onClick`, `icon`, `title`, `description`. Seleccionada: `border-amber-500 bg-amber-500/[0.08] shadow-[0_0_0_1px_rgba(245,158,11,0.3)]`.

### 4. Layout auth `src/app/(auth)/layout.tsx`

2 columnas 50/50, 100vh. Columna izquierda: decorativa con `mesh-gradient-amber`, LogoQ grande, contenido dinámico por página. Columna derecha: fondo navy-900, formulario centrado. En mobile (< 768px): solo columna del formulario.

Columna decorativa usa un slot `AuthDecorativeContent` — cada página pasa su propio contenido (stats en login, features list en registro).

### 5. Página de Login `src/app/(auth)/login/page.tsx`

Ver `docs/frontend/06-auth-y-formularios.md` §1. Implementar con `react-hook-form` + `zodResolver`:

- Botón Google OAuth: llama a `supabase.auth.signInWithOAuth({ provider: 'google' })`
- Divider "o"
- Campo email + campo contraseña con toggle show/hide (ícono Eye/EyeOff de Lucide)
- Link "¿Olvidaste tu contraseña?" → `/recuperar`
- Botón "Iniciar sesión" con loading state durante el submit
- Texto "¿No tenés cuenta?" + link "Registrate" → `/registro`

**Post-login redirect:**
```ts
if (user.role === 'ADMIN') router.push('/admin')
else router.push(searchParams.get('next') ?? '/dashboard')
```

**Manejo del error 429:** Si el servidor devuelve rate limit, mostrar mensaje con countdown y deshabilitar el botón durante el período de espera.

**Manejo de errores de Supabase:** Mapear códigos de error a mensajes en español ("Email o contraseña incorrectos", "Cuenta no verificada", etc.).

### 6. Página de Registro `src/app/(auth)/registro/page.tsx`

Ver `docs/frontend/06-auth-y-formularios.md` §2:

- Botón Google OAuth
- Campos: nombre completo, email, contraseña + `<PasswordStrength />` debajo, confirmar contraseña
- `<RoleCard />` selector: "Quiero comprar" (ShoppingBag) y "Quiero vender" (Upload). Nota "(Podés hacer ambas cosas después)"
- Checkbox términos con links amber a `/terminos` y `/privacidad`
- Botón "Crear cuenta"

**Post-registro:**
1. Supabase Auth crea el usuario
2. El trigger de DB (`010_triggers.sql`) crea el perfil automáticamente
3. Si el usuario eligió rol SELLER, actualizar `profiles.role = 'SELLER'` via Server Action
4. Redirigir a `/dashboard` con un banner de alerta: "Verificá tu email para activar todas las funciones"

**Rate limiting:** La API de Supabase limita registros. Si falla, mostrar mensaje claro.

### 7. OAuth callback `src/app/(auth)/callback/route.ts`

Route handler que intercambia el code por sesión. Redirige a `/dashboard` o al `next` param si existe.

### 8. Recuperar contraseña `src/app/(auth)/recuperar/page.tsx`

Formulario solo con email. Al submit: `supabase.auth.resetPasswordForEmail(email, { redirectTo })`. Mostrar siempre el mensaje genérico de éxito (no revelar si el email existe): "Si existe una cuenta con ese email, recibirás las instrucciones en los próximos minutos."

### 9. Nueva contraseña `src/app/(auth)/nueva-contrasena/page.tsx`

Supabase envía el token via URL. Leer la sesión de recovery del hash. Si no hay sesión válida → redirigir a `/recuperar` con toast de error. Si válida: mostrar formulario con nueva contraseña + confirmar + `<PasswordStrength />`. Al submit: `supabase.auth.updateUser({ password: newPassword })`.

### 10. Rate limiting para auth

En `src/lib/rate-limit/index.ts`: configurar con Upstash Redis.
- Login: 5 intentos por IP por minuto
- Registro: 3 intentos por IP por hora

Aplicar en las Server Actions de auth.

### 11. Server Actions de auth `src/lib/actions/auth.ts`

```ts
export async function signIn(data: LoginData): Promise<ActionResult>
export async function signUp(data: RegisterData): Promise<ActionResult>
export async function signOut(): Promise<void>
export async function updateProfile(data: ProfileData): Promise<ActionResult>
```

Cada action: verificar sesión, validar con Zod, ejecutar, retornar `{ success, error? }`.

### 12. Página de Perfil `src/app/(dashboard)/perfil/page.tsx`

Ver `docs/frontend/04-dashboards.md` §8. 4 cards en stack vertical:

**Card Avatar**: avatar 80px con iniciales + nombre + email + "Miembro desde..." + botón "Cambiar foto" (abre file picker, sube a Supabase Storage bucket `avatars`).

**Card Información personal**: form con 4 campos (nombre, email disabled con "Verificado ✓", empresa, sitio web) + bio textarea. Botón "Guardar cambios" → `updateProfile()`.

**Card Seguridad**: "Última actualización de contraseña: hace X" + botón "Cambiar contraseña" → abre Modal con formulario de cambio (contraseña actual + nueva + confirmar). Botón "Cerrar todas las sesiones" → `supabase.auth.signOut({ scope: 'global' })`.

**Card Notificaciones**: 4 toggles (switch) para preferencias de email. Guardar en `profiles` con columna `notification_preferences jsonb`.

### 13. Tests

En `src/lib/actions/__tests__/auth.test.ts`:
- Schemas Zod: casos válidos e inválidos para login y registro
- Middleware: rutas protegidas redirigen a login, rutas admin redirigen si no es ADMIN
- Redirect post-login según rol

## Reglas

- Nunca loggear credenciales ni tokens en console
- Los mensajes de error de auth deben ser genéricos para no revelar si un email existe o no (excepto errores de validación de formulario)
- Usar `useTransition` para todos los submits de Server Actions — ver `docs/frontend/06-auth-y-formularios.md` §submit

## Checkpoint

La sesión está completa cuando:
- [ ] Login funciona con email/password y Google OAuth
- [ ] Registro funciona con selector de rol y PasswordStrength visible
- [ ] Recuperar contraseña envía email y muestra mensaje genérico
- [ ] Nueva contraseña funciona con el token de Supabase
- [ ] Perfil editable con las 4 cards (incluyendo upload de avatar)
- [ ] Rate limiting activo (verificar que el 6to intento de login es rechazado)
- [ ] Tests pasan
- [ ] `npm run build` sin errores
