import { notFound, redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getInquiry } from '@/lib/data/inquiries'
import { ChatView } from './chat-view'

interface ConsultaPageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: ConsultaPageProps) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return {}
  const inquiry = await getInquiry(id, user.id)
  if (!inquiry) return {}
  return { title: `Consulta — ${inquiry.listing.title}` }
}

export default async function ConsultaPage({ params }: ConsultaPageProps) {
  const { id } = await params

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const inquiry = await getInquiry(id, user.id)
  if (!inquiry) notFound()

  return (
    <div>
      <ChatView inquiry={inquiry} currentUserId={user.id} />
    </div>
  )
}
