'use client'

import { useState } from 'react'
import { X, ExternalLink } from 'lucide-react'
import { cn } from '@/lib/utils/cn'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import type { AdminListingItem } from '@/lib/data/admin'

const STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Borrador',
  PENDING_REVIEW: 'En revisión',
  PUBLISHED: 'Publicado',
  PAUSED: 'Pausado',
  SOLD: 'Vendido',
  REJECTED: 'Rechazado',
}

const STATUS_VARIANTS: Record<string, 'success' | 'amber' | 'info' | 'muted' | 'danger'> = {
  DRAFT: 'muted',
  PENDING_REVIEW: 'amber',
  PUBLISHED: 'success',
  PAUSED: 'muted',
  SOLD: 'info',
  REJECTED: 'danger',
}

const TYPE_LABELS: Record<string, string> = {
  WEBSITE: 'Sitio web',
  DOMAIN: 'Dominio',
  SAAS: 'SaaS',
  ECOMMERCE: 'E-commerce',
  PROJECT: 'Proyecto',
  OTHER: 'Otro',
}

function formatPrice(price: unknown, currency: string): string {
  const num = Number(price)
  return `${currency} ${new Intl.NumberFormat('es-AR').format(num)}`
}

interface ListingPreviewPanelProps {
  listing: AdminListingItem | null
  isOpen: boolean
  onClose: () => void
  onApprove: (id: string) => void
  onReject: (id: string, reason: string) => void
}

export function ListingPreviewPanel({
  listing,
  isOpen,
  onClose,
  onApprove,
  onReject,
}: ListingPreviewPanelProps) {
  const [showRejectField, setShowRejectField] = useState(false)
  const [rejectReason, setRejectReason] = useState('')
  const [loading, setLoading] = useState<'approve' | 'reject' | null>(null)

  async function handleApprove() {
    if (!listing) return
    setLoading('approve')
    await onApprove(listing.id)
    setLoading(null)
    onClose()
  }

  async function handleRejectConfirm() {
    if (!listing || rejectReason.trim().length < 20) return
    setLoading('reject')
    await onReject(listing.id, rejectReason.trim())
    setLoading(null)
    setRejectReason('')
    setShowRejectField(false)
    onClose()
  }

  function handleClose() {
    setShowRejectField(false)
    setRejectReason('')
    onClose()
  }

  const isRejectDisabled = rejectReason.trim().length < 20

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40"
          onClick={handleClose}
          aria-hidden="true"
        />
      )}

      {/* Panel */}
      <div
        className={cn(
          'fixed right-0 top-0 h-screen w-[420px] bg-navy-900 border-l border-slate-800',
          'transform transition-transform duration-300 z-50 flex flex-col',
          isOpen ? 'translate-x-0' : 'translate-x-full'
        )}
        role="dialog"
        aria-modal="true"
        aria-label="Preview del listado"
      >
        {listing ? (
          <>
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-slate-800 flex-shrink-0">
              <h2 className="text-sm font-semibold text-slate-50 truncate pr-4">{listing.title}</h2>
              <button
                onClick={handleClose}
                className="text-slate-400 hover:text-slate-50 transition-colors p-1 rounded-lg hover:bg-slate-800 flex-shrink-0"
                aria-label="Cerrar panel"
              >
                <X className="size-4" />
              </button>
            </div>

            {/* Scrollable content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* Screenshot */}
              {listing.screenshotUrls?.[0] ? (
                <img
                  src={listing.screenshotUrls[0]}
                  alt={listing.title}
                  className="w-full h-48 object-cover rounded-xl"
                />
              ) : (
                <div className="w-full h-48 bg-slate-800 rounded-xl flex items-center justify-center text-slate-500 text-sm">
                  Sin imagen
                </div>
              )}

              {/* Status + type + price */}
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={STATUS_VARIANTS[listing.status] ?? 'muted'}>
                  {STATUS_LABELS[listing.status] ?? listing.status}
                </Badge>
                <Badge variant="muted">{TYPE_LABELS[listing.type] ?? listing.type}</Badge>
                <span className="text-amber-500 font-semibold text-sm ml-auto">
                  {formatPrice(listing.askingPrice, listing.currency)}
                </span>
              </div>

              {/* Description */}
              <div>
                <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-1">
                  Descripción
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed">{listing.description}</p>
              </div>

              {/* Metrics */}
              {(listing.monthlyRevenue || listing.monthlyTraffic || listing.domainAge) && (
                <div>
                  <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-2">
                    Métricas declaradas
                  </h3>
                  <div className="grid grid-cols-2 gap-2">
                    {listing.monthlyRevenue != null && (
                      <div className="bg-slate-800/50 rounded-lg p-2">
                        <p className="text-xs text-slate-400">Ingresos / mes</p>
                        <p className="text-sm font-medium text-slate-50">
                          ${Number(listing.monthlyRevenue).toLocaleString()}
                        </p>
                      </div>
                    )}
                    {listing.monthlyTraffic != null && (
                      <div className="bg-slate-800/50 rounded-lg p-2">
                        <p className="text-xs text-slate-400">Tráfico / mes</p>
                        <p className="text-sm font-medium text-slate-50">
                          {listing.monthlyTraffic.toLocaleString()}
                        </p>
                      </div>
                    )}
                    {listing.domainAge != null && (
                      <div className="bg-slate-800/50 rounded-lg p-2">
                        <p className="text-xs text-slate-400">Antigüedad dominio</p>
                        <p className="text-sm font-medium text-slate-50">
                          {listing.domainAge} años
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Tech stack */}
              {listing.techStack && listing.techStack.length > 0 && (
                <div>
                  <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-2">
                    Tech stack
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {listing.techStack.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-0.5 bg-slate-800 text-slate-300 text-xs rounded-md"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Seller */}
              <div>
                <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-2">
                  Vendedor
                </h3>
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-full bg-amber-500 flex items-center justify-center text-xs font-bold text-navy-950">
                    {(listing.seller.fullName ?? listing.seller.email ?? 'U')[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-200 truncate">
                      {listing.seller.fullName ?? listing.seller.email}
                    </p>
                    <p className="text-xs text-slate-500">{listing.seller.email}</p>
                  </div>
                  <a
                    href={`/admin/usuarios/${listing.seller.id}`}
                    className="text-xs text-amber-500 hover:underline flex items-center gap-1"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Ver perfil
                    <ExternalLink className="size-3" />
                  </a>
                </div>
              </div>

              {/* Prior rejection */}
              {listing.rejectionReason && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
                  <p className="text-xs font-medium text-amber-500 mb-1">Rechazado anteriormente</p>
                  <p className="text-xs text-amber-400">{listing.rejectionReason}</p>
                </div>
              )}
            </div>

            {/* Footer actions */}
            <div className="sticky bottom-0 border-t border-slate-800 bg-navy-900 p-4 space-y-2 flex-shrink-0">
              <Button
                variant="solid"
                size="full"
                className="bg-emerald-500 hover:bg-emerald-400 text-white border-emerald-500 hover:border-emerald-400"
                onClick={handleApprove}
                loading={loading === 'approve'}
                disabled={loading !== null}
              >
                Aprobar y publicar
              </Button>

              {!showRejectField ? (
                <Button
                  variant="outline-danger"
                  size="full"
                  onClick={() => setShowRejectField(true)}
                  disabled={loading !== null}
                >
                  Rechazar
                </Button>
              ) : (
                <>
                  <textarea
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-500 resize-none focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    placeholder="Motivo del rechazo (requerido)..."
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    rows={3}
                    maxLength={500}
                    autoFocus
                  />
                  <p className="text-xs text-slate-500 text-right">
                    {isRejectDisabled && rejectReason.length < 20
                      ? `Mínimo 20 caracteres · ${rejectReason.length} / 500`
                      : `${rejectReason.length} / 500`}
                  </p>
                  <Button
                    variant="outline-danger"
                    size="full"
                    onClick={handleRejectConfirm}
                    disabled={isRejectDisabled || loading !== null}
                    loading={loading === 'reject'}
                  >
                    Confirmar rechazo
                  </Button>
                  <Button
                    variant="ghost"
                    size="full"
                    onClick={() => {
                      setShowRejectField(false)
                      setRejectReason('')
                    }}
                    disabled={loading !== null}
                  >
                    Cancelar
                  </Button>
                </>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500 text-sm">
            Seleccioná un listado para previsualizar.
          </div>
        )}
      </div>
    </>
  )
}
