import { NextResponse, type NextRequest } from 'next/server'
import { prisma, DomainStatus } from '@qautiva/db'
import { getProfileOrUnauthorized } from '@/lib/api/marketplace-helpers'

const PAGE_SIZE = 20

async function getTeamId(profileId: string): Promise<string | null> {
  const userProfile = await prisma.userProfile.findUnique({
    where: { id: profileId },
    select: {
      teamMemberships: {
        select: { teamId: true },
        orderBy: { createdAt: 'asc' },
      },
    },
  })
  return userProfile?.teamMemberships[0]?.teamId ?? null
}

/**
 * GET /api/domains
 *
 * Lista los dominios del team autenticado, con paginación opcional.
 * Query params: ?status=ACTIVE&page=1
 */
export async function GET(request: NextRequest) {
  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  const teamId = await getTeamId(profile.id)
  if (!teamId) {
    return NextResponse.json({ error: 'No se encontró el team del usuario' }, { status: 404 })
  }

  const { searchParams } = new URL(request.url)
  const statusParam = searchParams.get('status')
  const pageParam = searchParams.get('page')
  const page = pageParam ? Math.max(1, parseInt(pageParam, 10) || 1) : 1

  if (statusParam && !Object.values(DomainStatus).includes(statusParam as DomainStatus)) {
    return NextResponse.json(
      { error: `Status inválido. Valores permitidos: ${Object.values(DomainStatus).join(', ')}` },
      { status: 400 },
    )
  }

  const where = {
    teamId,
    deletedAt: null,
    ...(statusParam ? { status: statusParam as DomainStatus } : {}),
  }

  const [domains, total] = await Promise.all([
    prisma.domain.findMany({
      where,
      select: {
        id: true,
        domainName: true,
        tld: true,
        status: true,
        period: true,
        paidAmountArs: true,
        registeredAt: true,
        expiresAt: true,
        autoRenew: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.domain.count({ where }),
  ])

  const serialized = domains.map((d) => ({
    ...d,
    paidAmountArs: d.paidAmountArs?.toString() ?? null,
  }))

  return NextResponse.json({
    domains: serialized,
    pagination: {
      page,
      pageSize: PAGE_SIZE,
      total,
      totalPages: Math.ceil(total / PAGE_SIZE),
    },
  })
}
