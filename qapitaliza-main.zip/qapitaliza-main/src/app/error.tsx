'use client'

import { useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { LogoQ } from '@/components/shared/logo-q'

interface ErrorPageProps {
  error: Error & { digest?: string }
  reset: () => void
}

export default function GlobalError({ error, reset }: ErrorPageProps) {
  useEffect(() => {
    console.error('[GlobalError]', error)
  }, [error])

  return (
    <div className="min-h-screen bg-navy-950 flex flex-col items-center justify-center px-6 text-center">
      <LogoQ size="lg" />

      <div className="mt-10 space-y-3">
        <p className="text-5xl font-bold text-red-500">Error</p>
        <h1 className="text-2xl font-semibold text-slate-50">Algo salió mal</h1>
        <p className="text-slate-400 max-w-sm mx-auto">
          Ocurrió un error inesperado. Por favor intentá de nuevo.
        </p>
      </div>

      <div className="mt-8">
        <Button variant="solid" size="md" onClick={reset}>
          Reintentar
        </Button>
      </div>
    </div>
  )
}
