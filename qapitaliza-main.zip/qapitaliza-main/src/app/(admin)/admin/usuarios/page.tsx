import { cn } from '@/lib/utils/cn'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { AdminUsersTable } from './users-table-client'
import { getAllUsers } from '@/lib/data/admin'

const ROLE_TABS = [
  { label: 'Todos', value: 'all' },
  { label: 'Vendedores', value: 'SELLER' },
  { label: 'Compradores', value: 'BUYER' },
  { label: 'Admins', value: 'ADMIN' },
  { label: 'Suspendidos', value: 'suspended' },
] as const

const PAGE_SIZE = 20

interface PageProps {
  searchParams: Promise<{
    role?: string
    q?: string
    page?: string
    status?: string
  }>
}

export default async function AdminUsuariosPage({ searchParams }: PageProps) {
  const params = await searchParams
  const roleParam = params.role ?? 'all'
  const q = params.q ?? ''
  const page = Math.max(1, parseInt(params.page ?? '1', 10))

  // "Suspendidos" tab maps to status filter, not role filter
  const isSuspendedTab = roleParam === 'suspended'
  const role = isSuspendedTab ? 'all' : roleParam
  const status = isSuspendedTab ? 'suspended' : 'all'

  const users = await getAllUsers({
    role: role as 'all' | 'SELLER' | 'BUYER' | 'ADMIN',
    q,
    page,
    status: status as 'all' | 'active' | 'suspended',
    limit: PAGE_SIZE,
  })

  const totalPages = Math.ceil(users.total / PAGE_SIZE)

  const statCards = [
    { label: 'Total', value: users.stats.total + users.stats.sellers + users.stats.buyers + users.stats.admins, highlight: false },
    { label: 'Vendedores', value: users.stats.sellers, highlight: false },
    { label: 'Compradores', value: users.stats.buyers, highlight: false },
    { label: 'Suspendidos', value: users.stats.suspended, highlight: true },
  ]

  // Recompute total from all users for stats cards
  const totalAllUsers = users.stats.sellers + users.stats.buyers + users.stats.admins

  function buildHref(overrides: Record<string, string>) {
    const p = new URLSearchParams({ role: roleParam, q, page: String(page), ...overrides })
    Array.from(p.entries()).forEach(([k, v]) => { if (!v || v === 'all') p.delete(k) })
    return `/admin/usuarios?${p.toString()}`
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-50">Gestión de usuarios</h1>
        <p className="text-slate-400 text-sm mt-0.5">Administrá roles, suspensiones y accesos.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: totalAllUsers },
          { label: 'Vendedores', value: users.stats.sellers },
          { label: 'Compradores', value: users.stats.buyers },
          { label: 'Suspendidos', value: users.stats.suspended, danger: true },
        ].map((card) => (
          <div
            key={card.label}
            className={cn(
              'p-4 rounded-xl border',
              card.danger
                ? 'bg-red-500/5 border-red-500/20'
                : 'bg-navy-900 border-slate-800'
            )}
          >
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-1">
              {card.label}
            </p>
            <p className={cn('text-xl font-bold', card.danger ? 'text-red-400' : 'text-slate-50')}>
              {card.value.toLocaleString()}
            </p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-800">
        {ROLE_TABS.map((tab) => {
          const isActive = roleParam === tab.value || (tab.value === 'suspended' && isSuspendedTab)
          return (
            <Link
              key={tab.value}
              href={buildHref({ role: tab.value, page: '1' })}
              className={cn(
                'px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px',
                isActive
                  ? 'border-amber-500 text-amber-500'
                  : 'border-transparent text-slate-400 hover:text-slate-50'
              )}
            >
              {tab.label}
            </Link>
          )
        })}
      </div>

      {/* Search */}
      <form method="GET" action="/admin/usuarios" className="flex items-center gap-3">
        <input type="hidden" name="role" value={roleParam} />
        <input
          type="search"
          name="q"
          defaultValue={q}
          placeholder="Buscar por nombre o email..."
          className="flex-1 max-w-sm bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-amber-500 text-navy-950 text-sm font-medium rounded-lg hover:bg-amber-400 transition-colors"
        >
          Buscar
        </button>
      </form>

      {/* Results */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">
          {users.total} usuario{users.total !== 1 ? 's' : ''}
        </p>
        {users.stats.suspended > 0 && (
          <Badge variant="danger">{users.stats.suspended} suspendido{users.stats.suspended !== 1 ? 's' : ''}</Badge>
        )}
      </div>

      {/* Table (client component for dropdowns + modals) */}
      <AdminUsersTable users={users.items} />

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center pt-4">
          <nav className="flex items-center gap-1">
            {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => i + 1).map((p) => (
              <Link
                key={p}
                href={buildHref({ page: String(p) })}
                className={cn(
                  'min-w-[36px] h-9 rounded-lg text-sm font-medium flex items-center justify-center transition-colors',
                  p === page
                    ? 'bg-amber-500 text-navy-950'
                    : 'text-slate-400 hover:text-slate-50 hover:bg-slate-800'
                )}
              >
                {p}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </div>
  )
}
