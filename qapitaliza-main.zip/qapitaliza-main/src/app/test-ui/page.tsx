'use client'

/**
 * Página temporal de prueba del design system.
 * Solo para verificación visual — no se usa en producción.
 */

import { useState } from 'react'
import { Package, Search, Heart } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Divider } from '@/components/ui/divider'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select } from '@/components/ui/select'
import { Modal } from '@/components/ui/modal'
import { Accordion } from '@/components/ui/accordion'
import { Avatar } from '@/components/ui/avatar'
import { Pagination } from '@/components/ui/pagination'
import { SkeletonCard } from '@/components/ui/skeleton-card'
import { LogoQ } from '@/components/shared/logo-q'
import { EmptyState } from '@/components/shared/empty-state'
import { ErrorState } from '@/components/shared/error-state'

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-4">
      <h2 className="text-xs uppercase tracking-wider text-slate-500 font-medium border-b border-slate-800 pb-2">
        {title}
      </h2>
      {children}
    </section>
  )
}

export default function TestUIPage() {
  const [modalOpen, setModalOpen] = useState(false)
  const [page, setPage] = useState(3)
  const [inputValue, setInputValue] = useState('')
  const [textareaValue, setTextareaValue] = useState('')

  return (
    <div className="min-h-screen bg-navy-950 px-8 py-12">
      <div className="max-w-4xl mx-auto flex flex-col gap-12">

        {/* Header */}
        <div className="flex flex-col gap-2">
          <LogoQ size="lg" showText adminBadge />
          <p className="text-slate-400 text-sm mt-2">
            Página de verificación del design system — <span className="text-amber-500">solo desarrollo</span>
          </p>
        </div>

        <Divider />

        {/* ── Buttons ── */}
        <Section title="Button — variantes">
          <div className="flex flex-wrap gap-3 items-center">
            <Button variant="solid">Solid</Button>
            <Button variant="outline">Outline</Button>
            <Button variant="outline-danger">Outline Danger</Button>
            <Button variant="outline-success">Outline Success</Button>
            <Button variant="ghost">Ghost</Button>
            <Button variant="link">Link →</Button>
          </div>
        </Section>

        <Section title="Button — tamaños">
          <div className="flex flex-wrap gap-3 items-center">
            <Button size="sm">Pequeño</Button>
            <Button size="md">Mediano</Button>
            <Button size="lg">Grande</Button>
          </div>
          <Button size="full">Full width</Button>
        </Section>

        <Section title="Button — estados">
          <div className="flex flex-wrap gap-3 items-center">
            <Button loading>Guardando...</Button>
            <Button disabled>Deshabilitado</Button>
            <Button icon={<Search className="size-4" />}>Con ícono</Button>
            <Button variant="outline" iconRight={<Package className="size-4" />}>
              Ícono derecha
            </Button>
          </div>
        </Section>

        <Divider label="Componentes de datos" />

        {/* ── Badges ── */}
        <Section title="Badge — variantes">
          <div className="flex flex-wrap gap-2 items-center">
            <Badge variant="success">Publicado</Badge>
            <Badge variant="success" dot>Verificado</Badge>
            <Badge variant="amber">En revisión</Badge>
            <Badge variant="amber" dot>Destacado</Badge>
            <Badge variant="info">SaaS</Badge>
            <Badge variant="info" dot>Respondida</Badge>
            <Badge variant="muted">Borrador</Badge>
            <Badge variant="danger">Rechazado</Badge>
            <Badge variant="danger" dot>Suspendido</Badge>
          </div>
        </Section>

        {/* ── Cards ── */}
        <Section title="Card — variantes">
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <p className="text-sm text-slate-400">Card default (padding md)</p>
            </Card>
            <Card hover>
              <p className="text-sm text-slate-400">Card con hover amber</p>
              <p className="text-xs text-slate-500 mt-1">Hover para ver efecto</p>
            </Card>
            <Card border="amber" padding="sm">
              <p className="text-sm text-slate-400">Card borde amber (padding sm)</p>
            </Card>
          </div>
          <Card padding="lg">
            <p className="text-sm text-slate-400">Card con padding lg (formularios)</p>
          </Card>
        </Section>

        <Divider />

        {/* ── Avatars ── */}
        <Section title="Avatar — roles">
          <div className="flex gap-4 items-center">
            <div className="flex flex-col items-center gap-2">
              <Avatar initials="VE" role="SELLER" size="lg" />
              <span className="text-xs text-slate-500">Vendedor</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar initials="CO" role="BUYER" size="lg" />
              <span className="text-xs text-slate-500">Comprador</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar initials="AD" role="ADMIN" size="lg" />
              <span className="text-xs text-slate-500">Admin</span>
            </div>
            <Avatar initials="SM" size="sm" />
            <Avatar initials="MD" size="md" />
          </div>
        </Section>

        <Divider />

        {/* ── Inputs ── */}
        <Section title="Input — variantes">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Nombre del activo"
              placeholder="Ej. CryptoAlerts.io"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              counter={{ current: inputValue.length, max: 80 }}
            />
            <Input
              label="URL del sitio"
              placeholder="https://ejemplo.com"
              prefix="https://"
            />
            <Input
              label="Búsqueda"
              placeholder="Buscar activos..."
              suffix={<Search className="size-4" />}
            />
            <Input
              label="Con error"
              placeholder="Escribe algo..."
              error="Este campo es requerido."
              helper="Texto de ayuda"
            />
          </div>
        </Section>

        <Section title="Textarea">
          <Textarea
            label="Descripción del activo"
            placeholder="Describí en detalle tu activo digital..."
            rows={4}
            maxLength={2000}
            value={textareaValue}
            onChange={(e) => setTextareaValue(e.target.value)}
          />
        </Section>

        <Section title="Select">
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Tipo de activo"
              placeholder="Seleccioná un tipo"
              options={[
                { value: 'WEBSITE', label: 'Sitio Web' },
                { value: 'DOMAIN', label: 'Dominio' },
                { value: 'SAAS', label: 'SaaS / MVP' },
                { value: 'ECOMMERCE', label: 'E-commerce' },
              ]}
            />
            <Select
              label="Con error"
              placeholder="Seleccioná..."
              options={[{ value: 'a', label: 'Opción A' }]}
              error="Este campo es requerido."
            />
          </div>
        </Section>

        <Divider />

        {/* ── Accordion ── */}
        <Section title="Accordion">
          <Accordion
            items={[
              {
                id: '1',
                title: '¿Cómo se verifica un activo?',
                content:
                  'El equipo de Qapitaliza revisa capturas de pantalla, analytics y datos financieros declarados por el vendedor antes de publicar el listado.',
              },
              {
                id: '2',
                title: '¿Cuánto tarda la revisión?',
                content:
                  'La revisión estándar toma entre 24 y 48 horas hábiles. Los listados premium tienen revisión prioritaria en menos de 12 horas.',
              },
              {
                id: '3',
                title: '¿Qué comisión cobra Qapitaliza?',
                content:
                  'Cobramos un 5% sobre el precio de venta final, descontado del pago al vendedor en el momento del cierre de la transacción.',
              },
            ]}
          />
        </Section>

        <Divider />

        {/* ── Pagination ── */}
        <Section title="Pagination">
          <Pagination currentPage={page} totalPages={12} onPageChange={setPage} />
          <p className="text-xs text-slate-500">Página activa: {page}</p>
        </Section>

        <Divider />

        {/* ── Modal ── */}
        <Section title="Modal">
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setModalOpen(true)}>
              Abrir modal
            </Button>
          </div>
          <Modal
            open={modalOpen}
            onClose={() => setModalOpen(false)}
            title="Confirmar acción"
            size="sm"
          >
            <p className="text-sm text-slate-400 mb-4">
              ¿Estás seguro que querés realizar esta acción? Esta operación no se puede deshacer.
            </p>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button variant="outline-danger" onClick={() => setModalOpen(false)}>
                Eliminar
              </Button>
            </div>
          </Modal>
        </Section>

        <Divider />

        {/* ── Skeleton ── */}
        <Section title="SkeletonCard — loading state">
          <div className="grid grid-cols-3 gap-4">
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div>
        </Section>

        <Divider />

        {/* ── Empty / Error states ── */}
        <Section title="EmptyState">
          <Card>
            <EmptyState
              icon={<Heart className="size-5" />}
              title="No tenés activos guardados"
              description="Explorá el catálogo y guardá los activos que te interesen para verlos después."
              cta={<Button variant="solid" size="sm">Explorar activos</Button>}
            />
          </Card>
        </Section>

        <Section title="ErrorState">
          <Card>
            <ErrorState
              message="No pudimos cargar el catálogo. Verificá tu conexión e intentá de nuevo."
              retry={() => alert('Reintentando...')}
            />
          </Card>
        </Section>

        <Divider />

        {/* ── Typography ── */}
        <Section title="Tipografía">
          <div className="flex flex-col gap-3">
            <p className="text-5xl font-bold text-slate-50">Hero — DM Sans 48px 700</p>
            <p className="text-3xl font-semibold text-slate-50">Page title — 32px 600</p>
            <p className="text-2xl font-semibold text-slate-50">Dashboard title — 28px 600</p>
            <p className="text-lg font-semibold text-slate-50">Card title — 18px 600</p>
            <p className="text-base font-semibold text-slate-50">Section heading — 16px 600</p>
            <p className="text-sm font-medium text-slate-400">Label — 14px 500</p>
            <p className="text-sm text-slate-400">Body — 14px 400</p>
            <p className="text-xs text-slate-500">Helper / timestamp — 12px 400</p>
            <p className="text-3xl font-bold text-amber-500">$18,000 USD — precio</p>
            <p className="font-mono text-xs text-slate-400 bg-slate-800 px-2 py-1 rounded inline-block">
              Next.js · Stripe · Supabase — JetBrains Mono
            </p>
          </div>
        </Section>

        {/* ── Colors ── */}
        <Section title="Paleta de colores">
          <div className="grid grid-cols-6 gap-3">
            {[
              { label: 'navy-950', cls: 'bg-navy-950 border border-slate-800' },
              { label: 'navy-900', cls: 'bg-navy-900' },
              { label: 'slate-800', cls: 'bg-slate-800' },
              { label: 'amber-500', cls: 'bg-amber-500' },
              { label: 'amber-400', cls: 'bg-amber-400' },
              { label: 'emerald-500', cls: 'bg-emerald-500' },
              { label: 'red-500', cls: 'bg-red-500' },
              { label: 'blue-500', cls: 'bg-blue-500' },
              { label: 'slate-50', cls: 'bg-slate-50' },
              { label: 'slate-400', cls: 'bg-slate-400' },
              { label: 'slate-500', cls: 'bg-slate-500' },
            ].map(({ label, cls }) => (
              <div key={label} className="flex flex-col gap-1.5">
                <div className={`h-10 rounded-lg ${cls}`} />
                <span className="text-xs text-slate-500">{label}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* ── Mesh gradient ── */}
        <Section title="Efectos — mesh-gradient-amber">
          <div className="mesh-gradient-amber rounded-xl border border-slate-800 p-12 text-center">
            <p className="text-slate-400 text-sm">Gradiente radial amber (hero, banners)</p>
          </div>
        </Section>

        <div className="pb-12" />
      </div>
    </div>
  )
}
