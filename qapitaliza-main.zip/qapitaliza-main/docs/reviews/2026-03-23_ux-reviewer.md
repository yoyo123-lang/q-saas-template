# Revisión: UX Reviewer
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de UX Reviewer

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 2 altos, 3 medios, 2 bajos

## Hallazgos

### [ALTO → CORREGIDO] Botón de favorito sin feedback ni destino útil en sesión anónima
- Dónde: `src/components/listings/listing-card.tsx`
- Problema: Click en favorito sin sesión → silencio total. El usuario no sabe qué pasó.
- Fix aplicado: Sin handler → `<Link href="/login">` con el mismo estilo visual.

### [ALTO → CORREGIDO] Price filter navegaba en cada keystroke
- Dónde: `src/components/listings/filter-sidebar.tsx`
- Problema: Teclear "1000" generaba 4 navegaciones (`1`, `10`, `100`, `1000`). Cada una reseteaba el scroll y parpadeaba el grid. Experiencia muy frustrante.
- Fix aplicado: `onChange` → actualiza estado local. `onBlur` → dispara la navegación.

### [MEDIO] Toggle de "Solo verificados" sin label `htmlFor` asociado
- Dónde: `src/components/listings/filter-sidebar.tsx`
- Problema: El toggle es un `<div>` clickeable dentro de un `<label>`, pero el `<label>` no tiene un `htmlFor` vinculado a un input. Los lectores de pantalla no lo identifican como control.
- Recomendación: Reemplazar con un `<input type="checkbox">` oculto y el div como visual, o agregar `role="switch"` y `aria-checked`.

### [MEDIO] Galería sin indicador de cantidad total de imágenes
- Dónde: `src/components/listings/gallery-client.tsx`
- Problema: Si hay 4 screenshots, el usuario no sabe cuántas hay hasta hacer scroll en los thumbnails.
- Recomendación: Agregar contador "1 / 4" sobre la imagen principal.

### [MEDIO] Breadcrumb en `/explorar/[slug]` usa `listing.type.toLowerCase()` para la URL de categoría
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx:63`
- Problema: `SAAS.toLowerCase()` = `saas`, pero los slugs reales de categoría son distintos (el seed usa `saas` pero no está garantizado). Si el slug real es diferente, el link del breadcrumb lleva a catálogo filtrado por un valor incorrecto.
- Recomendación: Usar `listing.category?.slug ?? listing.type.toLowerCase()`.

### [BAJO] Animación del menú mobile usa `max-h` con valor fijo (64)
- Dónde: `src/components/layout/navbar.tsx:57`
- Problema: `max-h-64` (256px) podría no ser suficiente si se agregan más links al menú. La animación se corta visualmente.
- Recomendación: Calcular dinámicamente o usar un valor más generoso (`max-h-96`).

### [BAJO] Foco visible en el toggle del FilterSidebar no es suficiente
- Dónde: `src/components/listings/filter-sidebar.tsx:120`
- Problema: El `<div>` del toggle no recibe foco por teclado — no es operable con Tab.
- Recomendación: Mismo fix que el hallazgo MEDIO de accesibilidad.

## Lo que está bien
- `Navbar` con hamburguesa mobile funcional y `aria-label` que cambia entre "Abrir" y "Cerrar" ✓
- `Breadcrumb` accesible con `<nav aria-label="Breadcrumb">` y `<ol>` semántico ✓
- `Accordion` (FAQ) usa `aria-expanded`, `aria-controls`, y `role="region"` correctamente ✓
- `Pagination` con `aria-label="Paginación"` y `aria-current="page"` ✓
- Estados vacíos implementados en `ResultsGrid` con `EmptyState` ✓
- `SkeletonCard` como loading placeholder ✓
- Placeholder de imagen en `ListingCard` y `GalleryClient` cuando no hay screenshot ✓
- Inputs de tipo `number` en el filtro de precio — teclado numérico en mobile ✓
- Transiciones CSS con `duration-150/200` — no más de 200ms en micro-interacciones ✓

## Recomendaciones generales
- Reemplazar el toggle de "Solo verificados" por un `<input type="checkbox">` accesible.
- Usar `listing.category?.slug` en el breadcrumb para URLs correctas.
- Agregar contador de imágenes en la galería.
