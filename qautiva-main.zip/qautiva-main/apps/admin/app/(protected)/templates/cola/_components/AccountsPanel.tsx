'use client'

import { useState } from 'react'

interface StitchAccountData {
  id: string
  label: string
  usedToday: number
  dailyLimit: number
  lastResetAt: string
  active: boolean
}

interface AccountsPanelProps {
  accounts: StitchAccountData[]
  pendingCount: number
  generatingCount: number
  doneCount: number
  isPaused: boolean
  onFactory: (targetCount: 1 | 2 | 3) => Promise<string>
  onRefresh: () => void
  onTogglePause: () => Promise<void>
}

const DEFAULT_DAILY_LIMIT = 150

export function AccountsPanel({
  accounts,
  pendingCount,
  generatingCount,
  doneCount,
  isPaused,
  onFactory,
  onRefresh,
  onTogglePause,
}: AccountsPanelProps) {
  const [loadingPause, setLoadingPause] = useState(false)
  const [loadingFactory, setLoadingFactory] = useState<1 | 2 | 3 | null>(null)
  const [factoryResult, setFactoryResult] = useState<{ message: string; isError: boolean } | null>(null)

  const [showForm, setShowForm] = useState(false)
  const [formLabel, setFormLabel] = useState('')
  const [formApiKey, setFormApiKey] = useState('')
  const [formDailyLimit, setFormDailyLimit] = useState<string>(String(DEFAULT_DAILY_LIMIT))
  const [formLoading, setFormLoading] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)
  const [formSuccess, setFormSuccess] = useState<string | null>(null)

  async function handleAddAccount(e: React.FormEvent) {
    e.preventDefault()
    setFormError(null)
    setFormSuccess(null)
    setFormLoading(true)

    const dailyLimit = formDailyLimit ? Number(formDailyLimit) : DEFAULT_DAILY_LIMIT

    try {
      const res = await fetch('/api/stitch/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          label: formLabel.trim(),
          apiKey: formApiKey.trim(),
          dailyLimit,
        }),
      })

      const data = (await res.json()) as { error?: string; account?: { label: string } }

      if (!res.ok) {
        setFormError(data.error ?? 'Error al registrar la cuenta')
        return
      }

      setFormSuccess(`Cuenta "${data.account?.label}" registrada correctamente`)
      setFormLabel('')
      setFormApiKey('')
      setFormDailyLimit(String(DEFAULT_DAILY_LIMIT))
      setShowForm(false)
      onRefresh()
    } catch {
      setFormError('Error de red al registrar la cuenta')
    } finally {
      setFormLoading(false)
    }
  }

  const totalAvailable = accounts
    .filter((a) => a.active)
    .reduce((sum, a) => sum + Math.max(0, a.dailyLimit - a.usedToday), 0)

  async function handleFactory(targetCount: 1 | 2 | 3) {
    if (!confirm(`¿Encolar Ronda ${targetCount}? Se crearán jobs para todas las industrias sin templates de este estilo.`)) return
    setLoadingFactory(targetCount)
    setFactoryResult(null)
    try {
      await onFactory(targetCount)
      setFactoryResult({ message: `Ronda ${targetCount} encolada correctamente`, isError: false })
    } catch (err) {
      setFactoryResult({ message: err instanceof Error ? err.message : 'Error al encolar', isError: true })
    } finally {
      setLoadingFactory(null)
    }
  }

  return (
    <div className={`border rounded-lg bg-[#0F172A] p-5 flex flex-col gap-5 ${isPaused ? 'border-yellow-500/30' : 'border-[#1E293B]'}`}>
      {isPaused && (
        <div className="flex items-center gap-2 px-3 py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <span className="text-yellow-400 text-xs font-medium">⏸ Cron pausado — el procesamiento automático está detenido. Los créditos no se consumirán hasta que reanudes.</span>
        </div>
      )}
      {/* Resumen de estado */}
      <div className="flex items-center gap-6 flex-wrap">
        <div className="flex flex-col">
          <span className="text-xs text-[#64748B]">Pendientes</span>
          <span className="text-xl font-bold text-white">{pendingCount}</span>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-[#64748B]">Generando</span>
          <span className="text-xl font-bold text-yellow-400">{generatingCount}</span>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-[#64748B]">Listos</span>
          <span className="text-xl font-bold text-green-400">{doneCount}</span>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-[#64748B]">Créditos disponibles</span>
          <span className="text-xl font-bold text-[#8B5CF6]">{totalAvailable}</span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => {
              setLoadingPause(true)
              void onTogglePause().finally(() => setLoadingPause(false))
            }}
            disabled={loadingPause}
            className={`text-xs font-medium px-3 py-1.5 rounded border transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
              isPaused
                ? 'border-green-500/40 text-green-400 hover:bg-green-500/10'
                : 'border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10'
            }`}
          >
            {loadingPause ? '...' : isPaused ? 'Reanudar cron' : 'Pausar cron'}
          </button>
          <button
            onClick={onRefresh}
            className="text-xs text-[#64748B] hover:text-[#94A3B8] transition-colors border border-[#1E293B] px-3 py-1.5 rounded"
          >
            Actualizar
          </button>
        </div>
      </div>

      {/* Cuentas Stitch */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-[#64748B] uppercase tracking-wide">Cuentas Stitch</span>
          <button
            onClick={() => { setShowForm((v) => !v); setFormError(null); setFormSuccess(null) }}
            className="text-xs text-[#8B5CF6] hover:text-[#7C3AED] transition-colors"
          >
            {showForm ? 'Cancelar' : '+ Agregar cuenta'}
          </button>
        </div>

        {/* Formulario de alta */}
        {showForm && (
          <form onSubmit={(e) => void handleAddAccount(e)} className="flex flex-col gap-3 border border-[#1E293B] rounded-lg p-4 bg-[#0B1120]">
            <div className="flex flex-col gap-1">
              <label className="text-xs text-[#64748B]">Nombre / etiqueta</label>
              <input
                type="text"
                value={formLabel}
                onChange={(e) => setFormLabel(e.target.value)}
                placeholder="ej: Cuenta principal"
                required
                className="bg-[#1E293B] text-white text-sm rounded-lg px-3 py-2 outline-none focus:ring-1 focus:ring-[#8B5CF6] placeholder:text-[#475569]"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs text-[#64748B]">API Key de Stitch</label>
              <input
                type="password"
                value={formApiKey}
                onChange={(e) => setFormApiKey(e.target.value)}
                placeholder="sk-..."
                required
                className="bg-[#1E293B] text-white text-sm rounded-lg px-3 py-2 outline-none focus:ring-1 focus:ring-[#8B5CF6] placeholder:text-[#475569] font-mono"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs text-[#64748B]">Límite diario <span className="text-[#475569]">(default {DEFAULT_DAILY_LIMIT})</span></label>
              <input
                type="number"
                min={1}
                value={formDailyLimit}
                onChange={(e) => setFormDailyLimit(e.target.value)}
                className="bg-[#1E293B] text-white text-sm rounded-lg px-3 py-2 outline-none focus:ring-1 focus:ring-[#8B5CF6] w-32"
              />
            </div>
            {formError && <p className="text-xs text-red-400">{formError}</p>}
            <button
              type="submit"
              disabled={formLoading}
              className="self-start px-4 py-2 bg-[#8B5CF6] text-white text-sm font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {formLoading ? 'Registrando...' : 'Registrar cuenta'}
            </button>
          </form>
        )}

        {/* Lista de cuentas */}
        {accounts.length > 0 ? (
          <div className="flex flex-col gap-2">
            {accounts.map((account) => {
              const available = Math.max(0, account.dailyLimit - account.usedToday)
              const pct = account.dailyLimit > 0 ? (account.usedToday / account.dailyLimit) * 100 : 0

              return (
                <div key={account.id} className="flex items-center gap-3">
                  <span className="text-sm text-[#94A3B8] w-48 truncate">{account.label}</span>
                  <div className="flex-1 h-2 bg-[#1E293B] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-xs text-[#64748B] w-20 text-right">
                    {account.usedToday}/{account.dailyLimit}
                  </span>
                  <span className="text-xs text-[#94A3B8] w-16 text-right">
                    {available} libre{available !== 1 ? 's' : ''}
                  </span>
                  {!account.active && (
                    <span className="text-xs text-red-400">inactiva</span>
                  )}
                </div>
              )
            })}
          </div>
        ) : (
          !showForm && (
            <p className="text-sm text-[#475569]">
              No hay cuentas Stitch registradas. Usá <span className="text-[#8B5CF6]">+ Agregar cuenta</span> para registrar una.
            </p>
          )
        )}

        {formSuccess && !showForm && (
          <p className="text-xs text-green-400">{formSuccess}</p>
        )}
      </div>

      {/* Botones Factory */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-medium text-[#64748B] uppercase tracking-wide">Factory</span>
        <div className="flex items-center gap-2 flex-wrap">
          {([1, 2, 3] as const).map((round) => (
            <button
              key={round}
              onClick={() => void handleFactory(round)}
              disabled={loadingFactory !== null}
              className="px-4 py-2 bg-[#1E293B] text-[#94A3B8] text-sm rounded-lg hover:bg-[#8B5CF6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loadingFactory === round ? 'Encolando...' : `Ronda ${round}`}
            </button>
          ))}
        </div>
        <p className="text-xs text-[#475569]">
          Ronda 1: 1 template por industria (limpio y profesional) ·
          Ronda 2: +1 (cálido y orgánico) ·
          Ronda 3: +1 (audaz y moderno)
        </p>
        {factoryResult && (
          <p className={`text-xs ${factoryResult.isError ? 'text-red-400' : 'text-green-400'}`}>
            {factoryResult.message}
          </p>
        )}
      </div>
    </div>
  )
}
