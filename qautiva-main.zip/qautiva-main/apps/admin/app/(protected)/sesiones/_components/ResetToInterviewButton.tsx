'use client'

import { useState, useTransition } from 'react'
import { resetSessionToInterview } from '@/app/actions/interview'

interface ResetToInterviewButtonProps {
  sessionId: string
  orgId: string
}

/**
 * Botón para devolver una sesión en PROCESSING/ERROR a IN_PROGRESS.
 * El usuario vuelve a ver la entrevista y puede rehacer/continuar sus respuestas.
 */
export function ResetToInterviewButton({ sessionId, orgId }: ResetToInterviewButtonProps) {
  const [isPending, startTransition] = useTransition()
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null)

  function handleReset() {
    if (!confirm('¿Volver a entrevista? El usuario podrá rehacer sus respuestas. Las respuestas actuales se conservan.')) {
      return
    }
    setResult(null)
    startTransition(async () => {
      const res = await resetSessionToInterview(sessionId, orgId)
      setResult(res)
    })
  }

  return (
    <div className="flex-shrink-0 flex flex-col items-end gap-1.5">
      <button
        onClick={handleReset}
        disabled={isPending}
        className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#F59E0B]/20 hover:bg-[#F59E0B]/30 text-[#FBBF24] border border-[#F59E0B]/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
      >
        {isPending ? 'Reseteando...' : 'Volver a entrevista'}
      </button>
      {result && (
        <p className={`text-[10px] text-right max-w-[140px] ${result.ok ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
          {result.message}
        </p>
      )}
    </div>
  )
}
