import { cn } from '@/lib/utils/cn'

interface BadgeProps {
  variant: 'success' | 'amber' | 'info' | 'muted' | 'danger'
  children: React.ReactNode
  dot?: boolean
  icon?: React.ReactNode
  className?: string
}

const variantClasses = {
  success: 'bg-emerald-500/15 text-emerald-500',
  amber:   'bg-amber-500/15 text-amber-500',
  info:    'bg-blue-500/15 text-blue-500',
  muted:   'bg-slate-800 text-slate-400',
  danger:  'bg-red-500/15 text-red-500',
}

const dotColors = {
  success: 'bg-emerald-500',
  amber:   'bg-amber-500',
  info:    'bg-blue-500',
  muted:   'bg-slate-400',
  danger:  'bg-red-500',
}

export function Badge({ variant, children, dot, icon, className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium',
        variantClasses[variant],
        className
      )}
    >
      {dot && (
        <span
          className={cn('size-1.5 rounded-full flex-shrink-0', dotColors[variant])}
        />
      )}
      {icon && <span className="size-3 flex items-center">{icon}</span>}
      {children}
    </span>
  )
}
