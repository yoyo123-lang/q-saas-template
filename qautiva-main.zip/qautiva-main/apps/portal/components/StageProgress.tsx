type StageStatus = 'completed' | 'active' | 'pending'

type Stage = {
  number: number
  label: string
  status: StageStatus
}

type StageProgressProps = {
  stages: Stage[]
}

function StageNode({ stage, isLast }: { stage: Stage; isLast: boolean }) {
  const { number, label, status } = stage

  const nodeStyles: Record<StageStatus, string> = {
    completed: 'bg-[#10B981] border-[#10B981] text-white',
    active: 'bg-[#8B5CF6] border-[#8B5CF6] text-white',
    pending: 'bg-[#0B0F1A] border-[#1E293B] text-[#64748B]',
  }

  const lineStyles: Record<StageStatus, string> = {
    completed: 'bg-[#10B981]',
    active: 'bg-[#8B5CF6]',
    pending: 'bg-[#1E293B]',
  }

  return (
    <div className="flex items-center flex-1">
      <div className="flex flex-col items-center">
        <div
          className={`
            w-8 h-8 rounded-full border-2 flex items-center justify-center
            flex-shrink-0 transition-colors duration-200
            ${nodeStyles[status]}
          `}
          aria-label={`Etapa ${number}: ${label} — ${statusLabel(status)}`}
        >
          {status === 'completed' ? (
            <CheckIcon />
          ) : (
            <span className="text-xs font-bold">{number}</span>
          )}
        </div>
        <span
          className={`
            mt-2 text-xs text-center max-w-[64px]
            ${status === 'active' ? 'text-white font-bold' : 'text-[#94A3B8]'}
          `}
        >
          {label}
        </span>
      </div>

      {!isLast && (
        <div
          className={`h-0.5 flex-1 mx-1 mb-5 ${lineStyles[status]}`}
          aria-hidden="true"
        />
      )}
    </div>
  )
}

function CheckIcon() {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M2.5 7L5.5 10L11.5 4"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function statusLabel(status: StageStatus): string {
  const labels: Record<StageStatus, string> = {
    completed: 'completada',
    active: 'activa',
    pending: 'pendiente',
  }
  return labels[status]
}

export function StageProgress({ stages }: StageProgressProps) {
  return (
    <div className="flex items-start w-full" role="list" aria-label="Progreso por etapas">
      {stages.map((stage, index) => (
        <StageNode
          key={stage.number}
          stage={stage}
          isLast={index === stages.length - 1}
        />
      ))}
    </div>
  )
}
