import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { ConnectAccountsStep } from '@/components/ads/ConnectAccountsStep'

export const metadata: Metadata = { title: 'Publicidad — Qautiva' }

export default async function PublicidadPage({
  params,
  searchParams,
}: {
  params: { id: string }
  searchParams: { ads_error?: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) notFound()

  // Verificar ownership del proyecto
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    include: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) notFound()

  const teamIds = profile.teamMemberships.map((m) => m.teamId)
  const project = await prisma.project.findFirst({
    where: { id: params.id, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true },
  })

  if (!project) notFound()

  return (
    <main className="flex-1 overflow-y-auto px-6 py-8 md:px-10 lg:px-16">
      <div className="max-w-2xl">
        <ConnectAccountsStep
          projectId={project.id}
          errorMessage={searchParams.ads_error}
        />
      </div>
    </main>
  )
}
