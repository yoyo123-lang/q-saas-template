import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'

type MessageBody = {
  content: string
  projectId?: string  // Self-service: para asociar el mensaje al proyecto
}

export async function POST(request: NextRequest) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: MessageBody
  try {
    body = await request.json() as MessageBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const content = body.content?.trim()
  if (!content || content.length === 0) {
    return NextResponse.json({ error: 'El mensaje no puede estar vacío' }, { status: 400 })
  }

  if (content.length > 2000) {
    return NextResponse.json({ error: 'El mensaje es demasiado largo (máx 2000 caracteres)' }, { status: 400 })
  }

  const orgId = user.app_metadata?.org_id as string | undefined

  if (orgId) {
    // Usuarios legados: mensaje asociado a la org
    let message
    try {
      message = await prisma.message.create({
        data: { organizationId: orgId, sender: 'CLIENT', channel: 'WEB', content },
        select: { id: true, content: true, sender: true, channel: true, createdAt: true },
      })
    } catch (err) {
      console.error('[messages] Prisma create failed (org)', {
        orgId,
        error: err instanceof Error ? err.message : String(err),
      })
      return NextResponse.json({ error: 'Error interno al enviar el mensaje' }, { status: 500 })
    }
    return NextResponse.json({ ok: true, message })
  }

  // Self-service: el projectId debe venir en el body
  const projectId = (body.projectId as string | undefined)?.trim()
  if (!projectId) {
    return NextResponse.json({ error: 'Sin organización ni proyecto asignado' }, { status: 403 })
  }

  // Verificar que el usuario pertenece al team del proyecto
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    include: { teamMemberships: { select: { teamId: true } } },
  })
  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)
  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, teamId: true },
  })
  if (!project) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  let message
  try {
    message = await prisma.message.create({
      data: { projectId: project.id, teamId: project.teamId, sender: 'CLIENT', channel: 'WEB', content },
      select: { id: true, content: true, sender: true, channel: true, createdAt: true },
    })
  } catch (err) {
    console.error('[messages] Prisma create failed (self-service)', {
      projectId: project.id,
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error interno al enviar el mensaje' }, { status: 500 })
  }
  return NextResponse.json({ ok: true, message })
}
