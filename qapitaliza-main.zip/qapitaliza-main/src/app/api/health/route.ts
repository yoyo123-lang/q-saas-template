import { NextResponse } from 'next/server'
import { getPrisma } from '@/lib/prisma'

export async function GET() {
  const checks: Record<string, string> = {
    status: 'ok',
    timestamp: new Date().toISOString(),
  }

  if (process.env.DATABASE_URL) {
    try {
      const prisma = getPrisma()
      await prisma.$queryRaw`SELECT 1`
      checks.db = 'ok'
    } catch {
      // No exponer mensajes de error internos de Prisma/PostgreSQL al cliente.
      // Los detalles de conexión (host, usuario, etc.) son información sensible.
      checks.db = 'error'
      return NextResponse.json({ ...checks, status: 'degraded' }, { status: 503 })
    }
  } else {
    checks.db = 'not_configured'
  }

  return NextResponse.json(checks)
}
