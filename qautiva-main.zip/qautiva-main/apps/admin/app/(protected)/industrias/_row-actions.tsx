'use client'

import Link from 'next/link'
import { useState } from 'react'
import { deleteIndustry, duplicateIndustry } from './actions'
import type { ActionState } from './actions'

interface IndustriaRowActionsProps {
  id: string
  name: string
  clientCount: number
}

function DeleteButton({ id, clientCount }: { id: string; clientCount: number }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)
  const disabled = clientCount > 0 || isPending

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await deleteIndustry(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="inline">
      <input type="hidden" name="id" value={id} />
      {state && !state.ok && (
        <span className="text-xs text-red-400 mr-2">{state.error}</span>
      )}
      <button
        type="submit"
        disabled={disabled}
        title={disabled ? `Tiene ${clientCount} cliente(s) asociado(s)` : 'Eliminar industria'}
        className="px-2 py-1 text-xs text-red-400 border border-red-400/30 rounded hover:bg-red-400/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
      >
        Eliminar
      </button>
    </form>
  )
}

function DuplicateButton({ id }: { id: string }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await duplicateIndustry(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="inline">
      <input type="hidden" name="id" value={id} />
      {state && !state.ok && (
        <span className="text-xs text-red-400 mr-2">{state.error}</span>
      )}
      <button
        type="submit"
        disabled={isPending}
        className="px-2 py-1 text-xs text-[#94A3B8] border border-[#1E293B] rounded hover:text-white hover:border-[#334155] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {isPending ? '...' : 'Duplicar'}
      </button>
    </form>
  )
}

export function IndustriaRowActions({ id, name, clientCount }: IndustriaRowActionsProps) {
  return (
    <div className="flex items-center justify-end gap-2">
      <Link
        href={`/industrias/${id}`}
        className="px-2 py-1 text-xs text-[#8B5CF6] border border-[#8B5CF6]/30 rounded hover:bg-[#8B5CF6]/10 transition-colors"
      >
        Editar
      </Link>
      <DuplicateButton id={id} />
      <DeleteButton id={id} clientCount={clientCount} />
    </div>
  )
}
