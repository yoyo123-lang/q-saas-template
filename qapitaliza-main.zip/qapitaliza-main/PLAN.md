# Plan de Implementación — Qapitaliza MVP

> **Fecha**: 2026-03-22 (actualizado 2026-03-23)
> **Estado**: Borrador (iteración 3 — con especificación frontend completa)
> **Decisión de stack**: ver `docs/decisions/ADR-0003-stack-tecnico-qapitaliza.md`
> **Reglas de negocio**: ver `docs/BUSINESS_MODEL.md`
> **Especificación frontend**: ver `docs/frontend/` (6 documentos)
> - `docs/frontend/01-design-tokens.md` — paleta, tipografía, tokens, iconografía
> - `docs/frontend/02-componentes-base.md` — catálogo de primitivos UI
> - `docs/frontend/03-paginas-publicas.md` — landing, catálogo, detalle, cómo funciona
> - `docs/frontend/04-dashboards.md` — dashboard vendedor/comprador, wizard, chat
> - `docs/frontend/05-admin.md` — panel admin, moderación, gestión de usuarios
> - `docs/frontend/06-auth-y-formularios.md` — auth, formularios, responsive

---

## Alcance del MVP (Fase 1)

### Incluido
- Landing pública con propuesta de valor
- Catálogo público de activos digitales (browseable, filtrable, con SEO)
- Páginas de detalle de cada activo
- Sistema de listado de activos (vendedor puede publicar)
- Auth: registro, login, Google OAuth
- Dashboard vendedor (mis listados, estado)
- Dashboard comprador (favoritos, historial de consultas)
- Sistema de consulta/contacto entre comprador y vendedor (mediado por plataforma)
- Panel admin para moderación de listados
- Seed del catálogo inicial (~50 activos de Federico)

### Excluido del MVP
- Crowdfunding (Fase 1.5)
- Pasarela de pago integrada (las transacciones se coordinan offline en el MVP)
- Fondos de comercio tradicionales
- Validación automática de métricas con Qobra/Qontacta
- Smart contracts
- API pública

---

## Modelo de datos (entidades principales)

```
User (via Supabase Auth + tabla profiles)
  ├── id, email, fullName, avatarUrl, role (BUYER | SELLER | ADMIN)
  ├── bio, companyName, website
  └── createdAt, updatedAt

Listing (activo listado)
  ├── id, sellerId → User
  ├── title, slug (unique), description (rich text)
  ├── type: WEBSITE | DOMAIN | MVP | PROJECT | OTHER
  ├── status: DRAFT | PENDING_REVIEW | PUBLISHED | SOLD | PAUSED | REJECTED
  ├── askingPrice (Decimal), currency (ARS | USD)
  ├── monthlyRevenue (Decimal, nullable), monthlyTraffic (Int, nullable)
  ├── domainAge (Int, nullable — meses)
  ├── techStack (String[]), tags (String[])
  ├── url (nullable), screenshotUrls (String[])
  ├── verificationStatus: UNVERIFIED | PENDING | VERIFIED
  ├── featuredUntil (DateTime, nullable)
  ├── viewCount (Int)
  └── createdAt, updatedAt, publishedAt

ListingMetric (métricas verificables del activo)
  ├── id, listingId → Listing
  ├── metricType: MONTHLY_REVENUE | MONTHLY_TRAFFIC | DOMAIN_AUTHORITY | EMAIL_SUBSCRIBERS | SOCIAL_FOLLOWERS
  ├── value (Decimal), period (String — "2026-02")
  ├── source: SELF_REPORTED | SCREENSHOT | ANALYTICS_CONNECTED | QOBRA_VERIFIED
  └── evidenceUrl (nullable)

Inquiry (consulta comprador → vendedor, mediada)
  ├── id, listingId → Listing, buyerId → User
  ├── status: OPEN | REPLIED | CLOSED | CONVERTED
  ├── messages → InquiryMessage[]
  └── createdAt, updatedAt

InquiryMessage
  ├── id, inquiryId → Inquiry, senderId → User
  ├── content (text)
  └── createdAt

Favorite
  ├── userId → User, listingId → Listing
  └── createdAt

Category
  ├── id, name, slug, description, icon
  └── parentId → Category (nullable, para subcategorías)

AuditLog
  ├── id, actorId → User, action, entityType, entityId
  ├── metadata (JSON)
  └── createdAt
```

---

## Estructura de carpetas

```
/
├── CLAUDE.md
├── PLAN.md
├── docs/                          # Documentación del proyecto
├── supabase/
│   └── migrations/                # SQL para copiar/pegar en Supabase SQL Editor
│       ├── README.md              # Instrucciones de orden de ejecución
│       ├── 001_profiles.sql       # + 001_profiles_rollback.sql
│       ├── 002_categories.sql     # + rollback (incluye seed de 5 categorías)
│       ├── 003_listings.sql       # + rollback (ENUMs: tipo, status, verificación, moneda)
│       ├── 004_listing_metrics.sql # + rollback
│       ├── 005_inquiries.sql      # + rollback (inquiries + inquiry_messages)
│       ├── 006_favorites.sql      # + rollback
│       ├── 007_audit_log.sql      # + rollback (ENUM con todos los eventos de funnel)
│       ├── 008_indexes.sql        # + rollback (índices, FTS, GIN para arrays)
│       ├── 009_rls_policies.sql   # + rollback (Row Level Security todas las tablas)
│       └── 010_triggers.sql       # + rollback (updated_at, auto-perfil, published_at, RPC views)
├── prisma/
│   └── schema.prisma              # Modelo de datos (debe mantenerse en sync con supabase/migrations/)
├── public/
│   ├── fonts/                     # DM Sans (self-hosted)
│   └── images/                    # Assets estáticos
├── src/
│   ├── app/
│   │   ├── globals.css            # Tokens de diseño, reset, animaciones
│   │   ├── layout.tsx             # Root layout (fuente, metadata, providers)
│   │   ├── page.tsx               # Landing pública
│   │   ├── sitemap.ts             # Sitemap dinámico (Next.js built-in)
│   │   ├── (auth)/
│   │   │   ├── layout.tsx         # Layout 2 columnas: decorativa + formulario
│   │   │   ├── login/page.tsx
│   │   │   ├── registro/page.tsx  # (no "register" — español)
│   │   │   ├── recuperar/page.tsx # Solicitar reset de contraseña
│   │   │   ├── nueva-contrasena/page.tsx # Confirmar nueva contraseña (con token)
│   │   │   └── callback/route.ts  # Supabase OAuth callback
│   │   ├── (public)/
│   │   │   ├── layout.tsx         # Incluye Navbar + Footer
│   │   │   ├── explorar/          # Catálogo público
│   │   │   │   ├── page.tsx       # Lista con filtros y paginación
│   │   │   │   └── [slug]/page.tsx # Detalle del activo
│   │   │   └── como-funciona/page.tsx
│   │   ├── (dashboard)/           # Era "(protected)" — renombrado
│   │   │   ├── layout.tsx         # Sidebar + auth guard
│   │   │   ├── dashboard/page.tsx # Dashboard general
│   │   │   ├── mis-activos/       # Vendedor: mis listados
│   │   │   │   ├── page.tsx
│   │   │   │   ├── nuevo/page.tsx # Wizard multi-step (4 pasos)
│   │   │   │   └── [id]/editar/page.tsx # Tabs: Info, Métricas, Imágenes, Config
│   │   │   ├── favoritos/page.tsx # Comprador: favoritos
│   │   │   ├── consultas/         # Mensajes
│   │   │   │   ├── page.tsx       # Lista con tabs (Todas/Abiertas/Respondidas/Cerradas)
│   │   │   │   └── [id]/page.tsx  # Chat 2 columnas (thread + info activo)
│   │   │   └── perfil/page.tsx
│   │   ├── (admin)/
│   │   │   ├── layout.tsx         # Sidebar admin + guard rol ADMIN
│   │   │   ├── admin/
│   │   │   │   ├── page.tsx           # Dashboard admin
│   │   │   │   ├── listados/
│   │   │   │   │   ├── page.tsx       # Moderación con selección masiva
│   │   │   │   │   └── [id]/page.tsx  # Revisión individual de un listado
│   │   │   │   └── usuarios/
│   │   │   │       ├── page.tsx       # Gestión de usuarios
│   │   │   │       └── [id]/page.tsx  # Perfil detallado de usuario
│   │   └── api/
│   │       ├── health/route.ts    # Health check (monitoreo + deploy)
│   │       └── v1/
│   │           └── webhooks/      # Webhooks de Supabase, etc.
│   ├── components/
│   │   ├── layout/
│   │   │   ├── sidebar.tsx        # variant: dashboard | admin
│   │   │   ├── navbar.tsx         # Nav público (fijo, blur)
│   │   │   └── footer.tsx
│   │   ├── ui/                    # Primitivos — ver docs/frontend/02-componentes-base.md
│   │   │   ├── button.tsx         # 6 variants: solid, outline, outline-danger, outline-success, ghost, link
│   │   │   ├── card.tsx           # hover, padding, border variants
│   │   │   ├── badge.tsx          # 5 variants: success, amber, info, muted, danger
│   │   │   ├── input.tsx          # label, helper, error, prefix, suffix, counter
│   │   │   ├── textarea.tsx       # rows, maxLength, counter automático
│   │   │   ├── select.tsx
│   │   │   ├── modal.tsx          # size: sm | md | lg
│   │   │   ├── stat-card.tsx      # trend, pulse, highlight variants
│   │   │   ├── tag-input.tsx      # chips con autocomplete, max tags, drag-remove
│   │   │   ├── image-uploader.tsx # drop zone, max 5, 2MB, JPG/PNG/WebP, reorden drag&drop
│   │   │   ├── password-strength.tsx  # barra 3 segmentos: débil/media/fuerte
│   │   │   ├── avatar.tsx         # iniciales, color por rol
│   │   │   ├── pagination.tsx
│   │   │   ├── divider.tsx        # con label opcional
│   │   │   ├── dropdown-menu.tsx  # menú ⋯ para acciones en tablas
│   │   │   ├── skeleton-card.tsx  # loading state de ListingCard
│   │   │   └── accordion.tsx      # expand/collapse, una abierta a la vez
│   │   ├── listings/              # Componentes de listados
│   │   │   ├── listing-card.tsx   # con todas las métricas, badges, isFavorited
│   │   │   ├── filter-sidebar.tsx # 5 secciones de filtro con searchParams
│   │   │   ├── results-grid.tsx   # barra de ordenamiento + grid + paginación
│   │   │   ├── tech-pill.tsx      # font-mono, rounded-full
│   │   │   └── listing-form/      # Wizard multi-step (4 pasos)
│   │   │       ├── stepper.tsx
│   │   │       ├── step-basic.tsx
│   │   │       ├── step-metrics.tsx
│   │   │       └── step-images.tsx
│   │   ├── admin/
│   │   │   ├── listing-preview-panel.tsx  # slide-in desde derecha, 420px
│   │   │   └── admin-listings-table.tsx   # con selección masiva + bulk actions
│   │   └── shared/
│   │       ├── empty-state.tsx    # icon, title, description, cta
│   │       ├── error-state.tsx    # message, retry
│   │       ├── logo-q.tsx         # size, showText, adminBadge
│   │       ├── breadcrumb.tsx
│   │       ├── timeline.tsx       # para "cómo funciona"
│   │       └── activity-item.tsx  # dot de color + texto + timestamp
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts          # Browser client
│   │   │   ├── server.ts          # Server client
│   │   │   └── middleware.ts      # Auth middleware
│   │   ├── data/                  # Queries Prisma (data access layer)
│   │   │   ├── listings.ts
│   │   │   ├── inquiries.ts
│   │   │   └── users.ts
│   │   ├── actions/               # Server Actions (con validación IDOR)
│   │   │   ├── listings.ts        # CRUD + aprobar/pausar/marcar vendido
│   │   │   ├── inquiries.ts       # crear, responder, cerrar
│   │   │   ├── favorites.ts
│   │   │   ├── admin.ts           # approveListing, rejectListing, featureListing, suspendUser, etc.
│   │   │   └── auth.ts
│   │   ├── analytics/             # Tracking centralizado de eventos
│   │   │   └── events.ts          # trackEvent() — escribe a AuditLog en MVP
│   │   ├── rate-limit/            # Rate limiting por IP/usuario
│   │   │   └── index.ts           # Middleware/helper de rate limiting
│   │   ├── schemas/               # Zod schemas — ver docs/frontend/06-auth-y-formularios.md
│   │   │   ├── listing.ts         # Paso 1-4 del wizard con validaciones por tipo
│   │   │   ├── inquiry.ts
│   │   │   └── auth.ts            # loginSchema, registerSchema (password con regex)
│   │   └── utils/
│   │       ├── cn.ts              # classnames/tailwind-merge
│   │       ├── format.ts          # formatNumber(), formatDate(), formatPrice()
│   │       └── constants.ts
│   └── types/
│       └── index.ts               # Types compartidos
├── tailwind.config.ts
├── next.config.ts                 # Incluye headers de seguridad y CORS
├── tsconfig.json
├── package.json
├── .env.example                   # Todas las variables documentadas, sin valores reales
└── vercel.json
```

---

## Sistema de diseño (alineado con ecosistema Q)

### Paleta de colores

```
// Fondos (compartido con todo el ecosistema Q)
navy-950: #0B0F1A    // Fondo principal
navy-900: #0F172A    // Cards, sidebar
navy-800: #1E293B    // Hover, inputs, borders

// Acento Qapitaliza (registrado en Q-Company)
amber-500: #F59E0B   // CTA principal, nav activo, badges
amber-400: #FBBF24   // Hover del acento
amber-glow: rgba(245, 158, 11, 0.15)  // Glow sutil

// Texto
text-primary: #F8FAFC
text-secondary: #94A3B8
text-muted: #64748B

// Estados (compartido con ecosistema)
success: #10B981
warning: #F59E0B
error: #EF4444
info: #3B82F6
```

### Tipografía
- Display/body: DM Sans (Google Fonts)
- Mono: JetBrains Mono (para código/tech stack)
- Pesos: 400 (body), 500 (emphasis), 600 (headings), 700 (display)

### Componentes clave
- Dark theme hardcodeado (consistente con Qautiva/Qontrata)
- Cards: `bg-[#0F172A] border border-[#1E293B] rounded-xl`
- Botón primario: `bg-amber-500 hover:bg-amber-400 text-navy-950 font-medium rounded-lg`
- Sidebar: `bg-[#0B0F1A] border-r border-[#1E293B]`, activo con barra izquierda amber
- Hero: radial gradient animado (meshMove) con amber al 8% opacity
- Animaciones: fadeUp escalonadas, consistentes con Qautiva/Qontrata

---

## Dependencias npm a instalar

| Paquete | Versión | Uso | Etapa |
|---|---|---|---|
| `lucide-react` | latest | Iconografía (único proveedor de íconos) | 1 |
| `tailwind-merge` | latest | `cn()` utility para clases condicionales | 1 |
| `clsx` | latest | Companion de tailwind-merge | 1 |
| `react-hook-form` | latest | Manejo de estado de formularios | 4 |
| `zod` | latest | Validación de schemas (client + server) | 4 |
| `@hookform/resolvers` | latest | Integración react-hook-form + zod | 4 |
| `sonner` | latest | Toast notifications | 4 |
| `recharts` | latest | Gráficos (BarChart, AreaChart, ResponsiveContainer) | 5 |
| `@dnd-kit/core` | latest | Drag & drop para reordenar imágenes en ImageUploader | 5 |

> No agregar dependencias no listadas sin consultarlo primero. Ver CLAUDE.md.

---

## Etapas de implementación

### Etapa 0: Documentación de producto (pre-desarrollo)

1. Completar `docs/BUSINESS_MODEL.md` con reglas de negocio, roles, límites operativos y eventos de funnel
2. Validar con Federico: monetización, política de baja, límites de listados/consultas
3. Crear `.env.example` con todas las variables necesarias documentadas (Supabase URL, anon key, DB URL, Google OAuth client ID/secret, etc.)

**Checkpoint de etapa:** `BUSINESS_MODEL.md` completo y validado. `.env.example` creado.

### Etapa 1: Scaffold y fundaciones (sesión 1-2)

1. Inicializar Next.js 15 + TypeScript + Tailwind CSS 4
2. Ejecutar migraciones SQL en Supabase SQL Editor **en orden**: 001 → 002 → ... → 010 — ver `supabase/migrations/README.md`
3. Configurar Prisma + PostgreSQL (Supabase) — `schema.prisma` debe reflejar las tablas creadas por las migraciones
3. Configurar Supabase Auth (email + Google OAuth)
4. Sistema de diseño base en `globals.css`: CSS vars de color, `.mesh-gradient-amber`, `.card-hover`, `.nav-active` — ver `docs/frontend/01-design-tokens.md`
5. Extender `tailwind.config.ts`: colores navy-950/900, amber-500/400, fuentes DM Sans + JetBrains Mono — ver `docs/frontend/01-design-tokens.md` §6
6. Instalar y configurar `lucide-react` (iconografía), `tailwind-merge` + `clsx` (cn utility)
7. Crear componentes UI primitivos base: `Button` (6 variants), `Card`, `Badge` (5 variants), `Input`, `Textarea`, `Select`, `Modal`, `Divider` — ver `docs/frontend/02-componentes-base.md`
8. Crear `LogoQ.tsx`, `EmptyState.tsx`, `ErrorState.tsx`, `SkeletonCard.tsx`
9. Configurar `<Toaster>` de Sonner en root layout con tema oscuro
10. Root layout con metadata global, `<DM Sans>` font, providers
11. Middleware de auth (proteger rutas `/dashboard/*`, `/admin/*`)
12. Headers de seguridad en `next.config.ts` (CSP, X-Frame-Options, HSTS, X-Content-Type-Options, Referrer-Policy)
13. Configuración de CORS en `next.config.ts`
14. Endpoint `/api/health`
15. Rate limiting: middleware base (login: 5/min, registro: 3/hora, catálogo: 60/min por IP)

**Checkpoint de etapa:** Proyecto levanta, design tokens visibles, componentes UI renderizables en Storybook o página de prueba, auth funciona, health check 200.

### Etapa 2: Landing y navegación pública (sesión 2-3)

1. `app/(public)/layout.tsx` con `<Navbar />` + `<Footer />` compartidos
2. `Navbar.tsx`: logo, links de navegación, botones "Iniciar sesión" (outline) + "Registrate" (solid) — ver `docs/frontend/02-componentes-base.md` §10
3. `Footer.tsx`: columnas Producto/Empresa/Legal + copyright
4. Landing page (`/`): hero con `mesh-gradient-amber`, `<HeroSearch>` que navega a `/explorar?q=`, stats row hardcodeados, `<CategoryRow>` con 5 `<CategoryPill>`, grilla de 6 `<ListingCard>` destacados (fetch SSR), `<HowItWorks>` 3 pasos, CTA final — ver `docs/frontend/03-paginas-publicas.md` §1
5. `CategoryPill.tsx`: click navega a `/explorar?category={slug}`
6. Metadata global en `app/layout.tsx`: `metadataBase`, title template, description, openGraph — ver `docs/frontend/03-paginas-publicas.md` §5
7. Página "Cómo funciona" (`/como-funciona`): `<Timeline>` para vendedores (4 pasos) y compradores (3 pasos), `<VerificationBanner>`, `<AccordionFAQ>` (6 items, expand/collapse), CTA final — ver `docs/frontend/03-paginas-publicas.md` §4
8. `Timeline.tsx` + `AccordionFAQ.tsx` como componentes reutilizables

**Checkpoint de etapa:** Landing completa sin placeholders, todas las secciones renderizadas con datos reales, links funcionales, FAQ expandible.

### Etapa 3: Modelo de datos y catálogo público (sesión 3-4)

1. Schema Prisma: User/Profile, Listing, Category, ListingMetric, Favorite — las tablas ya existen en Supabase (creadas en Etapa 1 con las migraciones SQL); Prisma solo necesita conectarse y mapear
2. Verificar que los índices de `008_indexes.sql` estén activos (no recrear con Prisma — ya están)
3. Seed del catálogo inicial (~50 activos de Federico)
4. Data access layer (`lib/data/listings.ts`): queries paginadas (20 items default, max 100) con filtros. Soportar todos los searchParams: `q`, `category`, `priceMin`, `priceMax`, `revenueMin`, `verified`, `tech[]`, `sort`, `page` — ver `docs/frontend/03-paginas-publicas.md` §2
5. `FilterSidebar.tsx`: 5 secciones (categoría checkboxes, rango precio, revenue mensual dropdown, solo verificados toggle, tech stack pills). Cambio de filtro → `router.push` con searchParams sin reload — ver `docs/frontend/02-componentes-base.md` §—
6. `ResultsGrid.tsx`: barra "N resultados" + dropdown ordenar + grid + `<Pagination>`
7. `Pagination.tsx`: botones ← → con página activa en amber
8. `ListingCard.tsx` completo: screenshot, badges, precio, 2 métricas (MRR/visitas/usuarios según tipo), tech stack pills, botones "♡ Guardar" + "Consultar" — ver `docs/frontend/02-componentes-base.md` §7
9. `TechPill.tsx`: `font-mono text-xs bg-slate-800 rounded-full`
10. `Breadcrumb.tsx`: reutilizable para detalle y dashboards
11. Página de detalle (`/explorar/[slug]`): layout 65%/35%, galería con thumbnails clickables, métricas en grid 2x3, card de acción sticky con "Consultar al vendedor" + "♡ Guardar en favoritos", card de seguridad con borde amber/20, sección "Activos relacionados" (3 cards del mismo tipo), metadata Open Graph dinámica — ver `docs/frontend/03-paginas-publicas.md` §3
12. Sitemap dinámico (`app/sitemap.ts`) con `revalidate: 3600`
13. Tests del DAL (queries, filtros, paginación, edge cases)

**Checkpoint de etapa:** Catálogo navegable, filtros funcionales, detalle con todos los elementos sin placeholders, SEO y sitemap activos. Tests pasan.

### Etapa 4: Auth y perfiles (sesión 4-5)

1. Instalar `react-hook-form`, `zod`, `@hookform/resolvers`, `sonner`
2. `app/(auth)/layout.tsx`: layout 2 columnas 50/50 (decorativa + formulario). La columna decorativa cambia contenido por página (`AuthDecorativeContent` slot) — ver `docs/frontend/06-auth-y-formularios.md` §layout
3. Login (`/login`): botón Google OAuth, divider, email + contraseña con toggle show/hide, link "¿Olvidaste tu contraseña?", botón submit. Post-login: redirigir a `/admin` si ADMIN, `/dashboard` si no. Si recibe 429: mostrar countdown y deshabilitar botón — ver `docs/frontend/06-auth-y-formularios.md` §1
4. Registro (`/registro`): botón Google OAuth, 4 campos, `<PasswordStrength>` (barra 3 segmentos rojo/amber/verde), `<RoleCard>` selector visual (Comprador/Vendedor), checkbox términos. Post-registro: banner "Verificá tu email" en dashboard — ver `docs/frontend/06-auth-y-formularios.md` §2
5. `PasswordStrength.tsx`: score basado en longitud, mayúscula, número, especial
6. `RoleCard.tsx`: card seleccionable con borde amber + glow cuando activa
7. Recuperar contraseña (`/recuperar`): formulario solo email, respuesta genérica por seguridad — ver `docs/frontend/06-auth-y-formularios.md` §3
8. Nueva contraseña (`/nueva-contrasena`): leer token de searchParam, redirigir a `/recuperar` si inválido — ver `docs/frontend/06-auth-y-formularios.md` §4
9. Schemas Zod en `lib/schemas/auth.ts`: `loginSchema` + `registerSchema` (email, password con regex: mín 8, mayúscula, número, confirm match, acceptTerms `z.literal(true)`)
10. OAuth callback route
11. Página de perfil (`/perfil`): 4 cards (avatar, info personal, seguridad, notificaciones con toggles). Email siempre disabled con "Verificado ✓". Server Action `updateProfile()` — ver `docs/frontend/04-dashboards.md` §8
12. Middleware: proteger rutas, redirigir según rol
13. Rate limiting en login (5/min) y registro (3/hora)
14. Tests: middleware de auth, redirecciones por rol, schemas Zod

**Checkpoint de etapa:** Registro/login/OAuth/recuperar-contraseña funcionan. PasswordStrength y RoleCard operativos. Perfil editable. Rate limiting activo. Tests pasan.

### Etapa 5: Dashboard vendedor (sesión 5-6)

1. Instalar `recharts`, `@dnd-kit/core` (drag & drop para imágenes)
2. `app/(dashboard)/layout.tsx`: `<Sidebar variant="dashboard">` + main con `ml-[280px]`
3. `Sidebar.tsx` completo: nav items con estado activo (barra izquierda 3px amber + bg amber/8%), badge en "Consultas", botón "Nuevo listado" outline, avatar + nombre + rol + logout — ver `docs/frontend/02-componentes-base.md` §9
4. `StatCard.tsx`: con trend, pulse (dot pulsante), highlight variants
5. `ActivityItem.tsx`: dot de color (azul/amber/verde/gris) + texto + timestamp
6. Dashboard general (`/dashboard`): 4 `<StatCard>`, `<AreaChart>` de vistas (Recharts), `<ActivityItem>` lista reciente, preview tabla de 4 activos — ver `docs/frontend/04-dashboards.md` §1
7. `ListingsTable.tsx`: columnas thumbnail+nombre | tipo | precio | estado badge | vistas | consultas | menú ⋯. `DropdownMenu.tsx` con opciones Editar/Ver página/Pausar/Eliminar (Eliminar abre Modal de confirmación)
8. Mis activos (`/mis-activos`): tabs (Todos/Publicados/Borradores/En revisión/Vendidos) + búsqueda + `<ListingsTable>` + paginación — ver `docs/frontend/04-dashboards.md` §2
9. Wizard de creación (`/mis-activos/nuevo`) — ver `docs/frontend/04-dashboards.md` §3:
   - `Stepper.tsx`: 4 pasos con línea conector (amber=completado, slate=pendiente)
   - Paso 1 "Información básica": título, tipo (select), URL (prefix "https://"), descripción (textarea con counter), precio+moneda (2 cols), `<TagInput>` para tech stack, `<TagInput>` para tags
   - Paso 2 "Métricas": campos dinámicos según tipo (WEBSITE/DOMAIN/SAAS/ECOMMERCE/PROJECT), cada campo con source/evidencia — ver `docs/frontend/04-dashboards.md` tabla de métricas por tipo
   - Paso 3 "Imágenes": `<ImageUploader>` drag & drop, max 5 imágenes, 2MB, JPG/PNG/WebP, preview con ×, reorden con @dnd-kit
   - Paso 4 "Revisión": read-only de todo. Botones: "Guardar borrador" + "Enviar a revisión" (→ status PENDING_REVIEW)
   - Persistencia en `sessionStorage` con key `new-listing-draft`; al volver preguntar si retomar
10. `TagInput.tsx`: Enter/coma agregan chip, Backspace con input vacío borra último, max tags, max longitud por tag, suggestions autocomplete — ver `docs/frontend/06-auth-y-formularios.md` §6
11. `ImageUploader.tsx`: drop zone con dashed border, drag-active en amber, validación MIME + tamaño, thumbnail preview con botón ×, reorden
12. Edición (`/mis-activos/[id]/editar`): tabs (Información/Métricas/Imágenes/Configuración), formulario pre-populado, sidebar sticky con estado/acciones/stats — ver `docs/frontend/04-dashboards.md` §4
13. Server Actions en `lib/actions/listings.ts`: create, update, delete (con Modal confirm), publish (→ PENDING_REVIEW), pause, markAsSold. Todos con `listing.sellerId === currentUser.id`
14. Límite de 50 listados activos por vendedor en Server Action
15. Schema Zod del listing en `lib/schemas/listing.ts`: validaciones por cada paso
16. Tests: CRUD, IDOR, límite de listados, upload de imágenes

**Checkpoint de etapa:** Wizard completo sin placeholders, todos los pasos funcionales, edición con tabs, upload real a Supabase Storage, IDOR bloqueado. Tests pasan.

### Etapa 6: Interacción comprador-vendedor (sesión 6-7)

1. Schema Prisma: Inquiry, InquiryMessage (si no se crearon en Etapa 3)
2. Sistema de favoritos: Server Action `toggleFavorite(listingId)` con optimistic update. Botón "♡ Guardar" en `ListingCard` y detalle de activo. Si no logueado → redirigir a `/login?next={ruta}` — ver `docs/frontend/04-dashboards.md` §5
3. Página Favoritos (`/favoritos`): grid 2 columnas de `<ListingCard>`. Click ♥ → `removeFavorite()` con animación de salida. `<EmptyState>` si vacío
4. `Avatar.tsx`: círculo con iniciales, colores por rol (amber=vendedor, blue=comprador, purple=admin)
5. Botón "Consultar al vendedor" en detalle del activo: si logueado → Server Action `createInquiry(listingId)`; si no logueado → redirect login. Validación: no consultar propio activo (vendedor === buyer → error)
6. `InquiryCard.tsx`: card de consulta con borde-left amber si no leída, avatar, nombre vendedor, nombre activo (link), preview mensaje, timestamp, badge de estado
7. Lista de consultas (`/consultas`): tabs Todas/Abiertas/Respondidas/Cerradas, stack de `<InquiryCard>`, click navega a `/consultas/{id}` — ver `docs/frontend/04-dashboards.md` §6
8. Chat (`/consultas/[id]`): layout 65%/35%. Thread con mensajes propios (burbuja amber/15 derecha) y ajenos (bg-navy-900 izquierda con avatar + nombre). Input sticky abajo con Enter-sin-Shift para enviar. Optimistic update en envío. Columna derecha sticky con info del activo (screenshot, precio, métricas, seller, link "Ver listado completo →") — ver `docs/frontend/04-dashboards.md` §7
9. Botón "Cerrar consulta" en header del chat → Modal confirm → Server Action `closeInquiry()`
10. Server Actions en `lib/actions/inquiries.ts`: createInquiry, sendMessage, closeInquiry. Validaciones: no auto-consulta, solo participantes pueden escribir, solo comprador puede cerrar
11. Rate limiting: máx 10 consultas nuevas por día por usuario
12. Notificaciones básicas por email (Supabase o Resend): nueva consulta, nueva respuesta
13. Tests: permisos (auto-consulta, no participante), rate limiting, transiciones de estado

**Checkpoint de etapa:** Favoritos, lista de consultas y chat completos sin placeholders. Permisos y rate limits verificados. Tests pasan.

### Etapa 7: Panel admin y analytics (sesión 7-8)

1. `app/(admin)/layout.tsx`: `<Sidebar variant="admin">` con badge "Admin" en logo, badge rojo con conteo de pendientes en nav item "Listados" — ver `docs/frontend/05-admin.md` §layout
2. Dashboard admin (`/admin`): selector de período (searchParam `?period=`), 4 `<StatCard>`, `<BarChart>` de listados por semana + `<AreaChart>` de usuarios (Recharts), tabla de pendientes con botón "Revisar", lista de actividad reciente, barras de distribución por categoría (HTML + CSS, no chart) — ver `docs/frontend/05-admin.md` §1
3. Polling cada 5 minutos para `pendingCount` con `useInterval`: actualiza badge en sidebar cuando > 0 — ver `docs/frontend/05-admin.md` §6
4. `AdminListingsTable.tsx`: checkbox por fila, selección masiva con barra flotante "N seleccionados — [Aprobar todos] [Rechazar todos] [Cancelar]", botones inline Aprobar (outline-success) / Rechazar (outline-danger) / Ver (ghost) — ver `docs/frontend/05-admin.md` §2
5. `ListingPreviewPanel.tsx`: slide-in desde derecha 420px (transform transition), sin navegación. Muestra screenshot grande, info completa, botón "Aprobar y publicar" (emerald sólido), botón "Rechazar" que expande `<Textarea>` para motivo. Validación: motivo requerido, mínimo 20 caracteres. Confirmar rechazo deshabilitado si textarea vacío — ver `docs/frontend/05-admin.md` §2
6. Revisión individual (`/admin/listados/[id]`): vista full-page similar a detalle público pero con panel de moderación en sidebar. Si fue rechazado antes, mostrar razón anterior. Link "Ver perfil del vendedor" → `/admin/usuarios/{sellerId}`
7. Gestión de usuarios (`/admin/usuarios`): 4 stat cards mini, tabla con avatar (color por rol), menú ⋯ (Ver perfil, Cambiar rol, Suspender, Eliminar). Suspender: Modal con campo motivo. Eliminar: Modal con advertencia de soft-delete 90 días — ver `docs/frontend/05-admin.md` §4
8. Perfil de usuario (`/admin/usuarios/[id]`): info del usuario, listados, historial de audit
9. Server Actions en `lib/actions/admin.ts`: `approveListing`, `rejectListing(id, reason)`, `featureListing`, `unfeatureListing`, `markAsSold`, `suspendUser(id, reason)`, `changeUserRole(id, role)`, `deleteUser(id)`. Cada una: verifica `role === 'ADMIN'`, escribe en `AuditLog` — ver `docs/frontend/05-admin.md` §5
10. AuditLog tipos: `LISTING_APPROVED`, `LISTING_REJECTED`, `LISTING_FEATURED`, `LISTING_UNFEATURED`, `LISTING_SOLD`, `USER_SUSPENDED`, `USER_ROLE_CHANGED`, `USER_DELETED`
11. `lib/analytics/events.ts`: `trackEvent(name, metadata)` escribe a AuditLog
12. Instrumentar eventos de funnel: `signup_completed`, `listing_created`, `listing_submitted`, `listing_published`, `listing_viewed`, `inquiry_sent`, `inquiry_replied`, `inquiry_converted`, `favorite_added`
13. Tests: moderación, permisos (solo ADMIN), AuditLog generado, motivo de rechazo validado

**Checkpoint de etapa:** Admin puede moderar listados con panel slide-in, acciones masivas, gestión de usuarios. Todos los botones funcionales. Eventos de funnel registrados. Tests pasan.

### Etapa 8: Polish y lanzamiento (sesión 8-9)

1. Auditar todos los botones, links y acciones de la app: ninguno puede quedar como placeholder, disabled sin reason, o sin onClick funcional
2. `<SkeletonCard>` en lugar de spinner para catálogo y dashboards: mostrar mientras se carga
3. `<EmptyState>` en: favoritos vacíos, mis-activos sin listados, consultas vacías, resultados de búsqueda sin matches, admin sin pendientes
4. `<ErrorState>` en: fetch fallido de catálogo, detalle de activo no encontrado (404), error de red en chat
5. Toast de éxito (Sonner) en: guardar perfil, enviar consulta, enviar mensaje, publicar listado, aprobar/rechazar
6. Responsive completo — ver `docs/frontend/06-auth-y-formularios.md` §7:
   - `md` (768px): auth layout pasa a 1 columna, sidebar pasa a drawer con overlay
   - `lg` (1024px): catálogo pasa de 3 a 2 columnas
   - `xl` (1280px): 3 columnas y sidebar 280px
   - Grids: `grid-cols-1 md:grid-cols-2 xl:grid-cols-3` para ListingCards, `grid-cols-2 xl:grid-cols-4` para StatCards
7. Optimización de imágenes: `next/image` en todos los screenshots, blur placeholder, sizes correcto
8. SEO: verificar metadata dinámica en todas las páginas de detalle
9. Testing E2E de flujos críticos: registro → crear listado → enviar a revisión → aprobar (admin) → consultar (buyer) → responder (seller) → cerrar consulta
10. Seed de datos de producción
11. Verificar headers de seguridad, rate limiting y CORS en producción
12. Deploy a Vercel

**Checkpoint de etapa:** Ningún placeholder en la app. Todos los flujos E2E pasan. Deploy exitoso.

---

## Fase 1.5: Crowdfunding (post-MVP)

Después de validar el marketplace base:
1. Modelo `Campaign` (objetivo, plazo, tipo de contraprestación)
2. Modelo `Contribution` (backer, monto, estado)
3. Página pública de campaña (barra de progreso, lista de backers)
4. Dashboard de campaña para el emprendedor
5. Integración con pasarela de pago (MercadoPago probablemente)
6. Lógica todo-o-nada vs flexible
7. Reportes de avance post-campaña

---

## Integración con ecosistema Q (futuro)

| Integración | Qué implica | Prioridad |
|---|---|---|
| Q-Company Board | Reportar métricas de Qapitaliza como BU vía API | Alta (post-MVP) |
| Qobra | Validar ingresos de activos listados | Media |
| Qontacta | Validar base de clientes/contactos | Media |
| Qontrata | No aplica directamente | Baja |
| Qautiva | Pipeline: MVPs creados en Qautiva se listan en Qapitaliza | Media |

---

## Riesgos y mitigaciones

| Riesgo | Impacto | Mitigación |
|---|---|---|
| Marketplace vacío (cold start) | Alto | Catálogo semilla de ~50 activos propios de Federico |
| Transacciones sin pasarela | Medio | MVP coordina offline; pasarela en Fase 1.5 |
| SEO lento para marketplace nuevo | Medio | SSR + metadata + sitemap desde Etapa 3 + dominios con historia del catálogo semilla |
| Supabase Auth limitaciones | Bajo | Se puede migrar a auth custom si es necesario |
| Crowdfunding regulatorio | Bajo (Fase 1 no regulada) | Arrancar con modelo recompensa/preventa, no equity |
| IDOR en Server Actions | Alto | Validación de ownership obligatoria en toda mutación (ver reglas en BUSINESS_MODEL.md) |
| Rollback de migraciones | Medio | Cada migración tiene su `_rollback.sql` en `supabase/migrations/`. Ejecutar en orden inverso en el SQL Editor. Hacer backup de DB antes de cualquier migración en producción |
| Upload de archivos maliciosos | Medio | Whitelist de MIME (JPG/PNG/WebP), límite de 2MB, almacenamiento en Supabase Storage (fuera del web root) |
| Abuso de rate en catálogo/consultas | Medio | Rate limiting desde Etapa 1 con límites definidos en BUSINESS_MODEL.md |

---

## Notas sobre testing

El CLAUDE.md exige TDD para lógica de negocio, servicios y endpoints. En este plan, los tests NO están concentrados en una etapa final sino distribuidos:

| Etapa | Qué se testea |
|-------|---------------|
| Etapa 3 | Data access layer (queries, filtros, paginación) |
| Etapa 4 | Middleware de auth, protección de rutas |
| Etapa 5 | Server Actions de listings (CRUD, IDOR, límites) |
| Etapa 6 | Consultas (permisos, rate limiting, transiciones) |
| Etapa 7 | Acciones admin (moderación, AuditLog) |
| Etapa 8 | E2E de flujos completos |

Cada etapa incluye sus tests como parte de las tareas. No se considera completa una etapa si los tests no pasan.
