/**
 * GET /api/projects/[id]/generate-creatives/[jobId]
 *
 * Polling del estado de un job de generación de creativos.
 * Retorna { status, result? } donde:
 *   - status: 'pending' | 'running' | 'done' | 'failed'
 *   - result: AdVisuals (solo si status === 'done')
 *   - error: string (solo si status === 'failed')
 *
 * El jobId pertenece a este proyecto — se verifica que el job.projectId coincida
 * para evitar que un usuario acceda a jobs de otro proyecto.
 */

import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { getJob } from '../_lib/job-store'

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string; jobId: string } },
) {
  // 1. Auth
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  const projectId = params.id
  const jobId = params.jobId

  if (!UUID_RE.test(projectId) || !UUID_RE.test(jobId)) {
    return NextResponse.json({ error: 'No encontrado' }, { status: 404 })
  }

  // 2. Verificar que el usuario tiene acceso al proyecto
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)
  const projectExists = await prisma.project.count({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
  })

  if (!projectExists) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // 3. Leer estado del job
  const job = getJob(jobId)

  if (job) {
    // Verificar que el job pertenece a este proyecto (evitar acceso cruzado)
    if (job.projectId !== projectId) {
      return NextResponse.json({ error: 'No encontrado' }, { status: 404 })
    }

    if (job.status === 'done') {
      return NextResponse.json({ status: job.status, result: job.result })
    }

    if (job.status === 'failed') {
      return NextResponse.json({ status: job.status, error: job.error })
    }

    return NextResponse.json({ status: job.status })
  }

  // C1 — Fallback a DB: el job no está en memoria (deploy, cold start, multi-instancia).
  // Si hay un AD_VISUALS READY creado en los últimos 10 min para este proyecto, lo devolvemos.
  const FALLBACK_WINDOW_MS = 10 * 60 * 1000
  const since = new Date(Date.now() - FALLBACK_WINDOW_MS)

  const recentDeliverable = await prisma.deliverable.findFirst({
    where: {
      projectId,
      type: 'AD_VISUALS',
      status: 'READY',
      isActive: true,
      createdAt: { gte: since },
    },
    select: { content: true },
    orderBy: { createdAt: 'desc' },
  })

  if (recentDeliverable) {
    return NextResponse.json({ status: 'done', result: recentDeliverable.content })
  }

  return NextResponse.json({ error: 'Job no encontrado. Puede haber expirado.' }, { status: 404 })
}
