'use client'

import type { QuestionBlock } from '@/app/_lib/interview/types'

export function DateInput({
  value,
  onChange,
  disabled,
  validation,
}: {
  value: string
  onChange: (v: unknown) => void
  disabled: boolean
  validation?: QuestionBlock['validation']
}) {
  return (
    <input
      type="date"
      value={value}
      min={validation?.min !== undefined ? String(validation.min) : undefined}
      max={validation?.max !== undefined ? String(validation.max) : undefined}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-4 py-3 text-white text-base outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed [color-scheme:dark]"
    />
  )
}
