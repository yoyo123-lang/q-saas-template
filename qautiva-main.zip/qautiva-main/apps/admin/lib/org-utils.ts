import { StageStatus } from '@qautiva/db'

type ClientStatus = 'En proceso' | 'Espera cliente' | 'Espera revisión'

/** Tiempo relativo legible a partir de una fecha pasada. */
export function relativeTime(date: Date | string): string {
  const diffMs = Date.now() - new Date(date).getTime()
  const hours = Math.floor(diffMs / 3_600_000)
  if (hours < 1) return 'Hace menos de 1 hora'
  if (hours < 24) return `Hace ${hours} hora${hours !== 1 ? 's' : ''}`
  const days = Math.floor(hours / 24)
  if (days < 7) return `Hace ${days} día${days !== 1 ? 's' : ''}`
  const weeks = Math.floor(days / 7)
  if (weeks < 5) return `Hace ${weeks} semana${weeks !== 1 ? 's' : ''}`
  const months = Math.floor(days / 30)
  return `Hace ${months} mes${months !== 1 ? 'es' : ''}`
}

/** Deriva el estado del cliente según los estados de sus etapas. */
export function deriveClientStatus(stageStatuses: StageStatus[]): ClientStatus {
  if (stageStatuses.includes(StageStatus.ADMIN_REVIEW)) return 'Espera revisión'
  if (stageStatuses.some((s) => s === StageStatus.CLIENT_REVIEW || s === StageStatus.REVISION)) return 'Espera cliente'
  return 'En proceso'
}
