import { cn } from '@/lib/utils/cn'

interface EmptyStateProps {
  icon?: React.ReactNode
  title: string
  description?: string
  cta?: React.ReactNode
  className?: string
}

export function EmptyState({ icon, title, description, cta, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-4 py-16 text-center',
        className
      )}
    >
      {icon && (
        <div className="size-12 rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
          {icon}
        </div>
      )}
      <div className="flex flex-col gap-1.5">
        <p className="text-base font-semibold text-slate-50">{title}</p>
        {description && (
          <p className="text-sm text-slate-400 max-w-sm">{description}</p>
        )}
      </div>
      {cta && <div>{cta}</div>}
    </div>
  )
}
