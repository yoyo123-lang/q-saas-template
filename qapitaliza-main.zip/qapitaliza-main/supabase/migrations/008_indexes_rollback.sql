-- ============================================================
-- ROLLBACK 008 — Indexes
-- ============================================================

-- profiles
DROP INDEX IF EXISTS idx_profiles_role;

-- categories
DROP INDEX IF EXISTS idx_categories_slug;
DROP INDEX IF EXISTS idx_categories_parent;

-- listings
DROP INDEX IF EXISTS idx_listings_status;
DROP INDEX IF EXISTS idx_listings_type;
DROP INDEX IF EXISTS idx_listings_seller;
DROP INDEX IF EXISTS idx_listings_category;
DROP INDEX IF EXISTS idx_listings_published_at;
DROP INDEX IF EXISTS idx_listings_asking_price;
DROP INDEX IF EXISTS idx_listings_view_count;
DROP INDEX IF EXISTS idx_listings_featured;
DROP INDEX IF EXISTS idx_listings_status_type;
DROP INDEX IF EXISTS idx_listings_status_published;
DROP INDEX IF EXISTS idx_listings_fts;
DROP INDEX IF EXISTS idx_listings_tech_stack;
DROP INDEX IF EXISTS idx_listings_tags;

-- listing_metrics
DROP INDEX IF EXISTS idx_listing_metrics_listing;
DROP INDEX IF EXISTS idx_listing_metrics_type;

-- inquiries
DROP INDEX IF EXISTS idx_inquiries_listing;
DROP INDEX IF EXISTS idx_inquiries_buyer;
DROP INDEX IF EXISTS idx_inquiries_status;
DROP INDEX IF EXISTS idx_inquiries_updated;

-- inquiry_messages
DROP INDEX IF EXISTS idx_inquiry_messages_inquiry;
DROP INDEX IF EXISTS idx_inquiry_messages_sender;
DROP INDEX IF EXISTS idx_inquiry_messages_created;

-- favorites
DROP INDEX IF EXISTS idx_favorites_user;
DROP INDEX IF EXISTS idx_favorites_listing;

-- audit_log
DROP INDEX IF EXISTS idx_audit_log_actor;
DROP INDEX IF EXISTS idx_audit_log_action;
DROP INDEX IF EXISTS idx_audit_log_entity;
DROP INDEX IF EXISTS idx_audit_log_created;
