'use client'

/**
 * Formulario de edición de una StageWelcome.
 * Notifica al padre cuando hay cambios en los campos (para el preview live).
 */

import { useEffect, useState } from 'react'
import type { StageWelcome } from '@qautiva/db'
import { upsertStageWelcome } from '@/lib/actions'

type Props = {
  welcome: Partial<StageWelcome> & { stageKey: string }
  onChange?: (fields: PreviewFields) => void
}

export type PreviewFields = {
  title: string
  description: string
  estimatedTime: string
  whatYouGet: string
  icon: string
  fastTrackText: string
}

type State = { error: string | null; success: boolean }
const INITIAL: State = { error: null, success: false }

export function StageWelcomeForm({ welcome, onChange }: Props) {
  const [showSuccess, setShowSuccess] = useState(false)
  const [isPending, setIsPending] = useState(false)
  const [state, setState] = useState<State>(INITIAL)

  async function action(formData: FormData) {
    setIsPending(true)
    try {
      await upsertStageWelcome(formData)
      setState({ error: null, success: true })
    } catch (err) {
      setState({ error: err instanceof Error ? err.message : 'Error desconocido', success: false })
    } finally {
      setIsPending(false)
    }
  }

  // Mostrar feedback de éxito por 3 segundos y luego ocultar
  useEffect(() => {
    if (!state.success) return
    setShowSuccess(true)
    const t = setTimeout(() => setShowSuccess(false), 3000)
    return () => clearTimeout(t)
  }, [state.success, state])

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    if (!onChange) return
    const form = e.currentTarget.closest('form') as HTMLFormElement | null
    if (!form) return
    const data = new FormData(form)
    onChange({
      title: String(data.get('title') ?? ''),
      description: String(data.get('description') ?? ''),
      estimatedTime: String(data.get('estimatedTime') ?? ''),
      whatYouGet: String(data.get('whatYouGet') ?? ''),
      icon: String(data.get('icon') ?? ''),
      fastTrackText: String(data.get('fastTrackText') ?? ''),
    })
  }

  // sync initial values to preview
  useEffect(() => {
    if (!onChange) return
    onChange({
      title: welcome.title ?? '',
      description: welcome.description ?? '',
      estimatedTime: welcome.estimatedTime ?? '',
      whatYouGet: welcome.whatYouGet ?? '',
      icon: welcome.icon ?? '',
      fastTrackText: welcome.fastTrackText ?? '',
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [welcome.stageKey])

  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="stageKey" value={welcome.stageKey} />

      <Field
        label="Título"
        name="title"
        defaultValue={welcome.title ?? ''}
        required
        onChange={handleChange}
      />
      <Field
        label="Descripción"
        name="description"
        defaultValue={welcome.description ?? ''}
        multiline
        required
        onChange={handleChange}
      />
      <div className="grid grid-cols-2 gap-4">
        <Field
          label="Tiempo estimado"
          name="estimatedTime"
          defaultValue={welcome.estimatedTime ?? ''}
          placeholder="~15 minutos"
          required
          onChange={handleChange}
        />
        <Field
          label="Ícono (emoji)"
          name="icon"
          defaultValue={welcome.icon ?? ''}
          placeholder="🏢"
          onChange={handleChange}
        />
      </div>
      <Field
        label="¿Qué obtenés?"
        name="whatYouGet"
        defaultValue={welcome.whatYouGet ?? ''}
        placeholder="Un resumen completo de tu estrategia..."
        required
        onChange={handleChange}
      />
      <Field
        label="Texto Fast-Track (opcional)"
        name="fastTrackText"
        defaultValue={welcome.fastTrackText ?? ''}
        placeholder="¿Ya tenés un documento con esta info?"
        onChange={handleChange}
      />

      {state.error && (
        <p className="text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">
          {state.error}
        </p>
      )}
      {showSuccess && (
        <p className="text-sm text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 rounded-lg px-3 py-2">
          Guardado correctamente.
        </p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="px-4 py-2 bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-60 disabled:cursor-not-allowed text-white text-sm font-medium rounded-lg transition-colors"
      >
        {isPending ? 'Guardando...' : 'Guardar'}
      </button>
    </form>
  )
}

// ── Helper ──────────────────────────────────────────────────────────────────────

function Field({
  label,
  name,
  defaultValue,
  placeholder,
  required,
  multiline,
  onChange,
}: {
  label: string
  name: string
  defaultValue: string
  placeholder?: string
  required?: boolean
  multiline?: boolean
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void
}) {
  const cls =
    'w-full bg-[#0F172A] border border-[#1E293B] text-[#F8FAFC] text-sm rounded-lg px-3 py-2 placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] transition-colors'

  return (
    <div>
      <label className="block text-xs text-[#94A3B8] mb-1">
        {label}
        {required && <span className="text-red-400 ml-0.5">*</span>}
      </label>
      {multiline ? (
        <textarea
          name={name}
          defaultValue={defaultValue}
          placeholder={placeholder}
          required={required}
          rows={3}
          className={cls}
          onChange={onChange}
        />
      ) : (
        <input
          type="text"
          name={name}
          defaultValue={defaultValue}
          placeholder={placeholder}
          required={required}
          className={cls}
          onChange={onChange}
        />
      )}
    </div>
  )
}
