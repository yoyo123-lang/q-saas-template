'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { formatARS } from '@/lib/format'

type SearchResult = {
  domain: string
  tld: string
  available: boolean
  priceArs: number
}

type Status = 'idle' | 'loading' | 'error'

function ResultRow({ result }: { result: SearchResult }) {
  const router = useRouter()

  function handleRegister() {
    router.push('/dominios/registrar?domain=' + encodeURIComponent(result.domain))
  }

  return (
    <div className="flex items-center justify-between bg-[#0F172A] border border-[#1E293B] rounded-lg px-4 py-3">
      <div className="flex items-center gap-3">
        <span className="text-[#F8FAFC] font-semibold">{result.domain}</span>
        {result.available ? (
          <span className="px-2 py-0.5 rounded text-xs font-medium bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40">
            Disponible
          </span>
        ) : (
          <span className="px-2 py-0.5 rounded text-xs font-medium bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40">
            No disponible
          </span>
        )}
      </div>
      <div className="flex items-center gap-4">
        {result.available && (
          <>
            <span className="text-[#94A3B8] text-sm">{formatARS(result.priceArs)}/año</span>
            <button
              type="button"
              onClick={handleRegister}
              className="px-3 py-1.5 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200"
            >
              Registrar
            </button>
          </>
        )}
      </div>
    </div>
  )
}

export function DomainSearch() {
  const [query, setQuery] = useState('')
  const [debouncedQuery, setDebouncedQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [status, setStatus] = useState<Status>('idle')
  const [searched, setSearched] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Debounce: actualiza debouncedQuery 300ms después del último cambio
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setDebouncedQuery(query.trim())
    }, 300)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [query])

  // Fetch con AbortController para evitar race conditions
  useEffect(() => {
    if (!debouncedQuery) {
      setResults([])
      setStatus('idle')
      setSearched(false)
      return
    }
    const controller = new AbortController()
    setStatus('loading')
    setSearched(true)

    fetch(`/api/domains/search?q=${encodeURIComponent(debouncedQuery)}`, { signal: controller.signal })
      .then(res => res.ok ? res.json() : Promise.reject(res))
      .then((data: { results: SearchResult[] }) => {
        setResults(data.results)
        setStatus('idle')
      })
      .catch(err => {
        if (err.name === 'AbortError') return
        setStatus('error')
        setResults([])
      })

    return () => controller.abort()
  }, [debouncedQuery])

  return (
    <div>
      <div className="relative mb-6">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ejemplo, minegocio, marca..."
          className="w-full bg-[#0F172A] border border-[#1E293B] rounded-lg px-4 py-3 text-[#F8FAFC] placeholder-[#64748B] focus:outline-none focus:border-[#8B5CF6] transition-colors duration-200"
          aria-label="Nombre de dominio a buscar"
          maxLength={253}
        />
      </div>

      {status === 'loading' && (
        <p className="text-[#94A3B8] text-sm text-center py-4">Buscando...</p>
      )}

      {status === 'error' && (
        <p role="alert" className="text-[#EF4444] text-sm text-center py-4">
          Error al buscar. Intentá de nuevo.
        </p>
      )}

      {status === 'idle' && searched && results.length === 0 && (
        <p className="text-[#94A3B8] text-sm text-center py-4">
          No se encontraron resultados para esta búsqueda.
        </p>
      )}

      {status === 'idle' && results.length > 0 && (
        <div className="flex flex-col gap-2">
          {results.map((r) => (
            <ResultRow key={r.domain} result={r} />
          ))}
        </div>
      )}
    </div>
  )
}
