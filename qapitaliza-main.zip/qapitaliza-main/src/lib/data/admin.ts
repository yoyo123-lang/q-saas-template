import { getPrisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'

const PAGE_SIZE = 20
const MAX_PAGE_SIZE = 100

// ─── Types ─────────────────────────────────────────────────

export interface MarketplaceStats {
  totalListings: number
  listingsTrend: number  // new listings this month
  totalUsers: number
  usersTrend: number     // new users this month
  activeInquiries: number
  totalVolume: number    // sum of asking prices of published listings
}

export interface ChartData {
  name: string
  count: number
}

export interface CategoryDist {
  slug: string
  label: string
  count: number
  percentage: number
}

export interface AdminListingParams {
  status?: 'all' | 'pending' | 'published' | 'featured' | 'rejected' | 'sold'
  type?: string
  sort?: 'newest' | 'oldest' | 'price_asc' | 'price_desc'
  q?: string
  page?: number
  limit?: number
}

export interface AdminUserParams {
  role?: 'all' | 'SELLER' | 'BUYER' | 'ADMIN'
  q?: string
  page?: number
  status?: 'all' | 'active' | 'suspended'
  limit?: number
}

export type AdminListingItem = Prisma.ListingGetPayload<{
  include: {
    seller: true
    metrics: true
    category: true
    _count: { select: { inquiries: true } }
  }
}>

export interface PaginatedAdminListings {
  items: AdminListingItem[]
  total: number
  pendingCount: number
  publishedCount: number
  featuredCount: number
  rejectedCount: number
  soldCount: number
}

export type AdminUserItem = Prisma.ProfileGetPayload<{
  include: {
    _count: { select: { listings: true } }
  }
}>

export interface AdminUserStats {
  total: number
  sellers: number
  buyers: number
  admins: number
  suspended: number
}

export interface PaginatedAdminUsers {
  items: AdminUserItem[]
  total: number
  stats: AdminUserStats
}

export type UserDetail = Prisma.ProfileGetPayload<{
  include: {
    listings: {
      include: { category: true }
      orderBy: { createdAt: 'desc' }
      take: 20
    }
    auditLogs: {
      orderBy: { createdAt: 'desc' }
      take: 20
    }
  }
}>

// ─── Helpers ────────────────────────────────────────────────

function startOfMonth(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1)
}

function subDays(date: Date, days: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() - days)
  return d
}

function formatDay(date: Date): string {
  const mm = String(date.getMonth() + 1).padStart(2, '0')
  const dd = String(date.getDate()).padStart(2, '0')
  return `${mm}/${dd}`
}

function isoDay(date: Date): string {
  return date.toISOString().slice(0, 10)
}

// ─── Functions ──────────────────────────────────────────────

/**
 * Returns aggregated marketplace stats for the admin dashboard.
 */
export async function getMarketplaceStats(): Promise<MarketplaceStats> {
  const prisma = getPrisma()
  const now = new Date()
  const monthStart = startOfMonth(now)
  const lastMonthStart = startOfMonth(new Date(now.getFullYear(), now.getMonth() - 1, 1))

  const [
    totalListings,
    listingsTrend,
    totalUsers,
    usersTrend,
    activeInquiries,
    volumeAgg,
  ] = await Promise.all([
    prisma.listing.count(),
    prisma.listing.count({ where: { createdAt: { gte: monthStart } } }),
    prisma.profile.count({ where: { deletedAt: null } }),
    prisma.profile.count({ where: { createdAt: { gte: monthStart }, deletedAt: null } }),
    prisma.inquiry.count({ where: { status: { in: ['OPEN', 'REPLIED'] } } }),
    prisma.listing.aggregate({
      where: { status: 'PUBLISHED' },
      _sum: { askingPrice: true },
    }),
  ])

  // Listings created last month for trend label
  void lastMonthStart

  return {
    totalListings,
    listingsTrend,
    totalUsers,
    usersTrend,
    activeInquiries,
    totalVolume: Number(volumeAgg._sum.askingPrice ?? 0),
  }
}

/**
 * Returns weekly listing creation counts for the bar chart.
 * @param weeks - number of weeks to look back (default 12)
 */
export async function getWeeklyListingsChart(weeks = 12): Promise<ChartData[]> {
  const prisma = getPrisma()
  const startDate = subDays(new Date(), weeks * 7)

  const listings = await prisma.listing.findMany({
    where: { createdAt: { gte: startDate } },
    select: { createdAt: true },
  })

  const result: ChartData[] = []
  for (let i = weeks - 1; i >= 0; i--) {
    const weekEnd = subDays(new Date(), i * 7)
    const weekStart = subDays(weekEnd, 6)
    const count = listings.filter(
      (l) => l.createdAt >= weekStart && l.createdAt <= weekEnd
    ).length
    result.push({ name: `S${weeks - i}`, count })
  }
  return result
}

/**
 * Returns daily user registration counts for the area chart.
 * @param days - number of days to look back (default 30)
 */
export async function getDailyRegistrationsChart(days = 30): Promise<ChartData[]> {
  const prisma = getPrisma()
  const startDate = subDays(new Date(), days)

  const profiles = await prisma.profile.findMany({
    where: { createdAt: { gte: startDate }, deletedAt: null },
    select: { createdAt: true },
  })

  const result: ChartData[] = []
  for (let i = days - 1; i >= 0; i--) {
    const d = subDays(new Date(), i)
    const dayStr = isoDay(d)
    const count = profiles.filter((p) => isoDay(p.createdAt) === dayStr).length
    result.push({ name: formatDay(d), count })
  }
  return result
}

/**
 * Returns listing distribution by category.
 */
export async function getCategoryDistribution(): Promise<CategoryDist[]> {
  const prisma = getPrisma()

  const [groups, total] = await Promise.all([
    prisma.listing.groupBy({
      by: ['categoryId'],
      _count: { id: true },
      where: { status: { in: ['PUBLISHED', 'PENDING_REVIEW', 'SOLD'] } },
    }),
    prisma.listing.count({
      where: { status: { in: ['PUBLISHED', 'PENDING_REVIEW', 'SOLD'] } },
    }),
  ])

  const categoryIds = groups.map((g) => g.categoryId).filter(Boolean) as string[]
  const categories = categoryIds.length
    ? await prisma.category.findMany({
        where: { id: { in: categoryIds } },
        select: { id: true, name: true, slug: true },
      })
    : []

  return groups
    .map((g) => {
      const cat = categories.find((c) => c.id === g.categoryId)
      return {
        slug: cat?.slug ?? 'sin-categoria',
        label: cat?.name ?? 'Sin categoría',
        count: g._count.id,
        percentage: total > 0 ? Math.round((g._count.id / total) * 100) : 0,
      }
    })
    .sort((a, b) => b.count - a.count)
}

/**
 * Returns the count of listings awaiting moderation.
 */
export async function getPendingListingsCount(): Promise<number> {
  return getPrisma().listing.count({ where: { status: 'PENDING_REVIEW' } })
}

/**
 * Returns paginated listings for admin moderation.
 * No status filter by default — admins see everything.
 */
export async function getAllListings(
  params: AdminListingParams = {}
): Promise<PaginatedAdminListings> {
  const prisma = getPrisma()
  const { status = 'all', type, sort = 'newest', q, page = 1, limit = PAGE_SIZE } = params

  const pageSize = Math.min(limit, MAX_PAGE_SIZE)
  const skip = (Math.max(page, 1) - 1) * pageSize

  const where: Prisma.ListingWhereInput = {}

  if (status === 'featured') {
    where.featuredUntil = { gt: new Date() }
  } else if (status === 'pending') {
    where.status = 'PENDING_REVIEW'
  } else if (status === 'published') {
    where.status = 'PUBLISHED'
  } else if (status === 'rejected') {
    where.status = 'REJECTED'
  } else if (status === 'sold') {
    where.status = 'SOLD'
  }

  if (type) {
    where.type = type as Prisma.EnumListingTypeFilter['equals']
  }

  if (q?.trim()) {
    where.OR = [
      { title: { contains: q.trim(), mode: 'insensitive' } },
      { seller: { fullName: { contains: q.trim(), mode: 'insensitive' } } },
    ]
  }

  const orderBy: Prisma.ListingOrderByWithRelationInput =
    sort === 'oldest'
      ? { createdAt: 'asc' }
      : sort === 'price_asc'
        ? { askingPrice: 'asc' }
        : sort === 'price_desc'
          ? { askingPrice: 'desc' }
          : { createdAt: 'desc' }

  const [items, total, pendingCount, publishedCount, featuredCount, rejectedCount, soldCount] =
    await Promise.all([
      prisma.listing.findMany({
        where,
        include: {
          seller: true,
          metrics: true,
          category: true,
          _count: { select: { inquiries: true } },
        },
        orderBy,
        skip,
        take: pageSize,
      }),
      prisma.listing.count({ where }),
      prisma.listing.count({ where: { status: 'PENDING_REVIEW' } }),
      prisma.listing.count({ where: { status: 'PUBLISHED' } }),
      prisma.listing.count({ where: { featuredUntil: { gt: new Date() } } }),
      prisma.listing.count({ where: { status: 'REJECTED' } }),
      prisma.listing.count({ where: { status: 'SOLD' } }),
    ])

  return { items, total, pendingCount, publishedCount, featuredCount, rejectedCount, soldCount }
}

/**
 * Fetches a single listing by ID without any status filter (admin access).
 */
export async function getAdminListing(id: string): Promise<AdminListingItem | null> {
  return getPrisma().listing.findUnique({
    where: { id },
    include: {
      seller: true,
      metrics: true,
      category: true,
      _count: { select: { inquiries: true } },
    },
  })
}

/**
 * Returns paginated user list for admin management.
 */
export async function getAllUsers(
  params: AdminUserParams = {}
): Promise<PaginatedAdminUsers> {
  const prisma = getPrisma()
  const { role = 'all', q, page = 1, status = 'all', limit = PAGE_SIZE } = params

  const pageSize = Math.min(limit, MAX_PAGE_SIZE)
  const skip = (Math.max(page, 1) - 1) * pageSize

  const where: Prisma.ProfileWhereInput = { deletedAt: null }

  if (role !== 'all') {
    where.role = role as Prisma.EnumUserRoleFilter['equals']
  }

  if (q?.trim()) {
    where.OR = [
      { fullName: { contains: q.trim(), mode: 'insensitive' } },
      { email: { contains: q.trim(), mode: 'insensitive' } },
    ]
  }

  if (status === 'suspended') {
    where.suspendedAt = { not: null }
  } else if (status === 'active') {
    where.suspendedAt = null
  }

  const [items, total, sellers, buyers, admins, suspended] = await Promise.all([
    prisma.profile.findMany({
      where,
      include: { _count: { select: { listings: true } } },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize,
    }),
    prisma.profile.count({ where }),
    prisma.profile.count({ where: { role: 'SELLER', deletedAt: null } }),
    prisma.profile.count({ where: { role: 'BUYER', deletedAt: null } }),
    prisma.profile.count({ where: { role: 'ADMIN', deletedAt: null } }),
    prisma.profile.count({ where: { suspendedAt: { not: null }, deletedAt: null } }),
  ])

  return {
    items,
    total,
    stats: { total, sellers, buyers, admins, suspended },
  }
}

/**
 * Returns full user detail with listings and audit history.
 */
export async function getUserDetail(id: string): Promise<UserDetail | null> {
  return getPrisma().profile.findUnique({
    where: { id },
    include: {
      listings: {
        include: { category: true },
        orderBy: { createdAt: 'desc' },
        take: 20,
      },
      auditLogs: {
        orderBy: { createdAt: 'desc' },
        take: 20,
      },
    },
  })
}

/**
 * Returns recent admin activity from the audit log (admin-triggered actions).
 */
export async function getRecentAdminActivity(
  limit = 5
): Promise<Array<{ id: string; action: string; entityId: string | null; createdAt: Date }>> {
  const logs = await getPrisma().auditLog.findMany({
    where: {
      action: {
        in: [
          'LISTING_APPROVED',
          'LISTING_REJECTED',
          'LISTING_FEATURED',
          'LISTING_UNFEATURED',
          'LISTING_SOLD',
          'USER_SUSPENDED',
          'USER_ROLE_CHANGED',
          'USER_DELETED',
        ],
      },
    },
    orderBy: { createdAt: 'desc' },
    take: limit,
    select: { id: true, action: true, entityId: true, createdAt: true },
  })
  return logs
}
