# Arquitectura del Proyecto

> Fuente de verdad de arquitectura. Actualizar cuando cambie la estructura.

## 1) Visión del proyecto

- **Proyecto en una oración:** Marketplace de activos digitales en español para LATAM (sitios web, dominios, MVPs, proyectos digitales).
- **Problema que resuelve / para quién:** No existe un marketplace regional hispanohablante para comprar/vender activos digitales. Las plataformas existentes (Flippa, Empire Flippers) son en inglés, con precios en USD y pensadas para otro contexto.
- **Objetivos de negocio:** Ser el punto de encuentro de vendedores de proyectos digitales y compradores/inversores hispanohablantes. Mediano plazo: agregar crowdfunding de proyectos en etapa temprana.
- **Alcance MVP:** Landing pública + catálogo + detalle de activos + auth (email/Google) + dashboard vendedor/comprador + sistema de consultas + panel admin de moderación. **Excluido del MVP:** pagos integrados, crowdfunding, fondos de comercio, validación automática de métricas.
- **Estado actual:** MVP en desarrollo
- **Roadmap:** ver `PLAN.md` y `docs/BUSINESS_MODEL.md`

---

## 2) Arquitectura del sistema

### 2.1 Diagrama general

```text
[Browser]
    │
    ▼
[Vercel Edge / Next.js 16 App Router]
    │
    ├── [Route Groups]
    │     ├── (public)  → landing, catálogo, detalle, cómo funciona
    │     ├── (auth)    → login, registro, recuperar, callback OAuth
    │     ├── (dashboard) → mis activos, favoritos, consultas, perfil
    │     └── (admin)   → moderación, gestión de usuarios
    │
    ├── [API Routes]
    │     ├── /api/health           → health check + DB ping
    │     ├── /api/v1/directives/receive → directivas del Q Company Board
    │     └── /api/cron/board-heartbeat → heartbeat periódico al Board
    │
    └── [Server Actions] → lógica de negocio en src/lib/actions/
          │
          ├── [Supabase Auth] → email/password + Google OAuth
          ├── [Prisma ORM] → queries de negocio sobre PostgreSQL (Supabase)
          ├── [Upstash Redis] → rate limiting
          └── [Resend] → email transaccional
```

### 2.2 Estilo arquitectónico

- **Tipo:** Monolito modular (Next.js fullstack con App Router)
- **Justificación:** Equipo unipersonal, velocidad de desarrollo, sin necesidad de microservicios en MVP. Todo en un solo repo y deploy.

### 2.3 Módulos

| Módulo | Responsabilidad | Datos que maneja |
|---|---|---|
| auth | Login/registro/sesión con Supabase Auth | usuarios, sesiones, OAuth tokens |
| listings | CRUD de activos digitales en venta | listings, categorías, métricas |
| inquiries | Sistema de consultas comprador→vendedor | inquiries, mensajes |
| favorites | Guardado de activos por compradores | favorites |
| admin | Moderación de listados y usuarios | todos los modelos (read + write admin) |
| board | Integración con Q Company Board central | directivas, heartbeat |
| notifications | Emails transaccionales via Resend | — |
| rate-limit | Protección de endpoints con Upstash Redis | — |

### 2.4 Comunicación interna

| Origen | Destino | Mecanismo |
|---|---|---|
| Server Actions | Prisma | Direct function call |
| Server Actions | Supabase Auth | SDK server-side (`@supabase/ssr`) |
| API routes | Upstash Redis | HTTP REST (rate limiting) |
| Cron | Q Company Board | HTTP POST (heartbeat) |
| API route | Prisma | Direct function call (health check) |

### 2.5 Dependencias externas

| Servicio | Uso | Riesgo | Fallback |
|---|---|---|---|
| Supabase | Auth + PostgreSQL | Crítico | Sin fallback en MVP |
| Vercel | Hosting + Edge functions + Cron | Crítico | Sin fallback en MVP |
| Upstash Redis | Rate limiting | Medio | Degraded mode (sin rate limit) |
| Resend | Email transaccional | Medio | Sin fallback (no envía email) |
| Google OAuth | Login social | Bajo | Email/password sigue funcionando |
| Q Company Board | Reportes y directivas | Bajo | App funciona sin Board |

### 2.6 ADRs activos

- `docs/decisions/ADR-0001-sistema-documentacion-modular.md`
- `docs/decisions/ADR-0002-mejoras-inspiradas-en-superpowers.md`
- `docs/decisions/ADR-0003-stack-tecnico-qapitaliza.md`

---

## 3) Stack tecnológico

| Componente | Tecnología | Versión | Motivo |
|---|---|---|---|
| Lenguaje | TypeScript | 5.x | Type safety, estándar del stack |
| Framework | Next.js (App Router) | 16.2.1 | Fullstack en un repo, SSR, SEO |
| Estilos | Tailwind CSS | 4.x | Velocidad, consistencia |
| UI components | lucide-react, sonner, recharts, dnd-kit | latest | Ecosistema React estándar |
| Auth | Supabase Auth | 2.99.x | Email + Google OAuth out of the box |
| ORM | Prisma | 7.5.0 | Type-safe queries, migraciones |
| Base de datos | PostgreSQL (via Supabase) | 16 | Relacional, RLS nativo en Supabase |
| Rate limiting | Upstash Redis | — | Serverless-compatible |
| Email | Resend | 6.9.x | API simple, confiable |
| Forms | react-hook-form + zod | 7.x / 4.x | Validación type-safe |
| Tests unitarios | Vitest | 4.1.1 | Rápido, compatible con ESM |
| Tests E2E | Playwright | 1.58.2 | Browser real, fixture de auth |
| Deploy | Vercel | — | Zero-config para Next.js |

### 3.1 Tecnologías prohibidas/deprecadas

- No usar `pages/` router (solo App Router)
- No usar `getServerSideProps` ni `getStaticProps`
- No exponer `SUPABASE_SERVICE_ROLE_KEY` al cliente
- No instalar dependencias sin consultar

---

## 4) Estructura de carpetas

```text
/ (raíz)
├── src/
│   ├── app/                    ← Next.js App Router
│   │   ├── (auth)/             ← login, registro, recuperar, callback
│   │   ├── (public)/           ← landing, explorar, detalle, cómo funciona
│   │   ├── (dashboard)/        ← mis-activos, favoritos, consultas, perfil
│   │   ├── (admin)/            ← moderación, gestión
│   │   ├── api/
│   │   │   ├── health/         ← GET /api/health
│   │   │   ├── v1/directives/  ← recepción de directivas del Board
│   │   │   └── cron/           ← heartbeat al Board
│   │   ├── layout.tsx
│   │   └── page.tsx            ← landing
│   ├── components/             ← componentes reutilizables
│   ├── lib/
│   │   ├── actions/            ← Server Actions (lógica de negocio)
│   │   │   └── __tests__/      ← unit tests de actions
│   │   ├── data/               ← queries de lectura
│   │   │   └── __tests__/      ← unit tests de data
│   │   ├── supabase/           ← client, server, auth-helpers
│   │   ├── schemas/            ← schemas zod compartidos
│   │   ├── prisma.ts           ← singleton PrismaClient
│   │   ├── config.ts           ← constantes de configuración
│   │   ├── rate-limit/         ← Upstash Redis rate limiting
│   │   └── utils/              ← helpers genéricos
│   └── types/                  ← tipos TypeScript globales
├── e2e/                        ← tests end-to-end (Playwright)
├── supabase/
│   └── migrations/             ← 12 migraciones SQL + rollbacks
├── prisma/
│   ├── schema.prisma           ← schema del ORM
│   └── seed.ts                 ← seed inicial
├── docs/                       ← documentación del proyecto
│   ├── decisions/              ← ADRs
│   ├── roles/                  ← roles de revisión IA
│   ├── sessions/               ← logs de sesiones de trabajo
│   ├── frontend/               ← especificación de diseño UI
│   └── board/                  ← sincronizado con q-company (no editar acá)
└── .claude/
    ├── agents/                 ← agentes IA (explorador, implementador, etc.)
    └── commands/               ← comandos de proyecto (/sesion, /cierre, etc.)
```

---

## 5) Variables de entorno

Ver `.env.example` para la lista completa con comentarios. Resumen:

| Variable | Dónde obtener | Entorno |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase Dashboard → Settings → API | Todos |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase Dashboard → Settings → API | Todos |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase Dashboard → Settings → API | Server only |
| `DATABASE_URL` | Supabase → Settings → Database (pooler) | Todos |
| `DIRECT_URL` | Supabase → Settings → Database (directo) | Migrations |
| `UPSTASH_REDIS_REST_URL` | console.upstash.com | Server only |
| `UPSTASH_REDIS_REST_TOKEN` | console.upstash.com | Server only |
| `RESEND_API_KEY` | resend.com → API Keys | Server only |
| `RESEND_FROM_EMAIL` | Dominio verificado en Resend | Server only |
| `NEXT_PUBLIC_APP_URL` | URL de la app (localhost / producción) | Todos |
| `BOARD_API_KEY` | Admin de q-company | Server only |

---

## 6) Cómo levantar el proyecto

```bash
# 1. Instalar dependencias
npm install

# 2. Copiar env y completar valores
cp .env.example .env.local

# 3. Generar cliente Prisma
npx prisma generate

# 4. Aplicar migraciones (requiere DB configurada)
npx prisma db push

# 5. Seed inicial (opcional)
npx prisma db seed

# 6. Levantar en desarrollo
npm run dev
```

---

## 7) Restricciones conocidas

- **No hay pagos integrados en MVP.** Las transacciones se coordinan fuera de la plataforma.
- **Supabase en free tier** tiene límites de 500 MB DB y 50.000 MAU. Revisar antes de escalar.
- **Vercel hobby plan** limita funciones serverless a 10 segundos. Operaciones largas deben ser async.
- **Rate limiting con Upstash** requiere conectividad externa. En desarrollo local puede no estar activo.
- **Doble ORM:** Supabase Auth maneja sus propias tablas (`auth.*`), Prisma maneja las tablas de negocio (`public.*`). No mezclar.

---

*Última actualización: 2026-03-24*
