'use client'

export const dynamic = 'force-dynamic'

import { useState } from 'react'
import { createSupabaseBrowserClient } from '@/lib/supabase-browser'
import Image from 'next/image'
import { getRecaptchaToken } from '@/lib/recaptcha'

type LoginState = 'idle' | 'loading-google' | 'loading-email' | 'error'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [state, setState] = useState<LoginState>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  const supabase = createSupabaseBrowserClient()

  function clearError() {
    if (state === 'error') {
      setState('idle')
      setErrorMessage('')
    }
  }

  async function handleGoogleLogin() {
    setState('loading-google')
    setErrorMessage('')

    const origin = window.location.origin
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${origin}/auth/callback`,
      },
    })

    if (error) {
      setState('error')
      setErrorMessage('No se pudo iniciar el login con Google. Intentá de nuevo.')
    }
  }

  async function handleEmailLogin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!email.trim() || !password.trim()) {
      setState('error')
      setErrorMessage('Completá todos los campos.')
      return
    }

    setState('loading-email')
    setErrorMessage('')

    try {
      await getRecaptchaToken('login')
    } catch {
      // En dev se continúa. En prod si falla es bloqueante.
      if (process.env.NODE_ENV === 'production') {
        setState('error')
        setErrorMessage('Error de verificación de seguridad. Intentá de nuevo.')
        return
      }
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    })

    if (error) {
      setState('error')
      setErrorMessage('Email o contraseña incorrectos.')
      return
    }

    window.location.href = '/'
  }

  const isLoadingGoogle = state === 'loading-google'
  const isLoadingEmail = state === 'loading-email'
  const isLoading = isLoadingGoogle || isLoadingEmail

  return (
    <div className="min-h-screen bg-[#0B0F1A] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <Image src="/logo.png" alt="Qautiva" width={80} height={80} priority />
        </div>

        {/* Card */}
        <div
          className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6"
        >
          <h1 className="text-xl font-bold text-white mb-1">Ingresá a tu portal</h1>
          <p className="text-[#94A3B8] text-sm mb-6">
            Seguí el progreso de tu negocio digital.
          </p>

          {/* Error global */}
          {state === 'error' && errorMessage && (
            <div className="mb-4 p-3 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm">
              {errorMessage}
            </div>
          )}

          {/* Google OAuth */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-3 px-4 py-2.5 rounded-lg border border-[#1E293B] bg-[#1E293B] text-white text-sm font-medium hover:border-[#8B5CF6]/50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoadingGoogle ? (
              <LoadingSpinner />
            ) : (
              <GoogleIcon />
            )}
            {isLoadingGoogle ? 'Redirigiendo...' : 'Continuar con Google'}
          </button>

          {/* Separador */}
          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-[#1E293B]" />
            <span className="text-[#64748B] text-xs">o</span>
            <div className="flex-1 h-px bg-[#1E293B]" />
          </div>

          {/* Formulario email */}
          <form onSubmit={handleEmailLogin} noValidate>
            <div className="space-y-4">
              <div>
                <label
                  htmlFor="email"
                  className="block text-sm text-[#94A3B8] mb-1.5"
                >
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); clearError() }}
                  placeholder="tu@email.com"
                  className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200"
                  disabled={isLoading}
                  maxLength={254}
                />
              </div>

              <div>
                <label
                  htmlFor="password"
                  className="block text-sm text-[#94A3B8] mb-1.5"
                >
                  Contraseña
                </label>
                <input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); clearError() }}
                  placeholder="Tu contraseña"
                  className="w-full px-3 py-2.5 rounded-lg bg-[#1E293B] border border-[#1E293B] text-white placeholder-[#64748B] text-sm focus:outline-none focus:border-[#A78BFA] transition-colors duration-200"
                  disabled={isLoading}
                  maxLength={128}
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoadingEmail ? (
                  <>
                    <LoadingSpinner />
                    Ingresando...
                  </>
                ) : (
                  'Ingresar'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

function LoadingSpinner() {
  return (
    <svg
      className="animate-spin h-4 w-4"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
      />
    </svg>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z"
      />
      <path
        fill="#34A853"
        d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18Z"
      />
      <path
        fill="#FBBC05"
        d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332Z"
      />
      <path
        fill="#EA4335"
        d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58Z"
      />
    </svg>
  )
}
