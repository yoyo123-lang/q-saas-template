/**
 * Valida una API key contra el proveedor correspondiente haciendo un test call mínimo.
 * Retorna true si la clave es válida, false si es inválida, null si no se pudo determinar.
 * Sin timeout propio — el caller aplica timeout via Promise.race.
 */
export async function validateApiKey(
  provider: 'ANTHROPIC' | 'OPENAI' | 'GOOGLE_GEMINI',
  apiKey: string,
): Promise<boolean | null> {
  if (provider === 'ANTHROPIC') return validateAnthropic(apiKey)
  if (provider === 'OPENAI') return validateOpenai(apiKey)
  if (provider === 'GOOGLE_GEMINI') return validateGemini(apiKey)
  return false
}

async function validateAnthropic(apiKey: string): Promise<boolean | null> {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 1,
      messages: [{ role: 'user', content: 'hi' }],
    }),
  })
  if (res.status === 401 || res.status === 403) return false
  if (res.status === 429) return null // rate-limited: clave válida pero indeterminada
  return res.ok
}

async function validateOpenai(apiKey: string): Promise<boolean | null> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      max_tokens: 1,
      messages: [{ role: 'user', content: 'hi' }],
    }),
  })
  if (res.status === 401 || res.status === 403) return false
  if (res.status === 429) return null // rate-limited: clave válida pero indeterminada
  return res.ok
}

async function validateGemini(apiKey: string): Promise<boolean> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: 'hi' }] }] }),
    },
  )
  if (res.status === 400 || res.status === 401 || res.status === 403) return false
  return res.ok
}
