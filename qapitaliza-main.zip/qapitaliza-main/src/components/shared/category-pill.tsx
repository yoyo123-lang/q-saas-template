import Link from 'next/link'

interface CategoryPillProps {
  icon: string
  label: string
  count?: number
  slug: string
}

export function CategoryPill({ icon, label, count, slug }: CategoryPillProps) {
  return (
    <Link
      href={`/explorar?category=${slug}`}
      className="flex flex-col items-center gap-2 bg-navy-900 border border-slate-800 rounded-xl p-4 hover:border-amber-500/30 transition-all duration-200 hover:shadow-lg hover:shadow-amber-500/5 group"
    >
      <span className="text-2xl" role="img" aria-label={label}>{icon}</span>
      <span className="text-sm font-medium text-slate-50 group-hover:text-amber-500 transition-colors">
        {label}
      </span>
      {count != null && (
        <span className="text-xs text-slate-500">{count} activos</span>
      )}
    </Link>
  )
}
