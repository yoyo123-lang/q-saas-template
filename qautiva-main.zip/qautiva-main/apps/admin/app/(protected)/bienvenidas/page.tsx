/**
 * /bienvenidas — Editor de pantallas de bienvenida por etapa.
 * Permite configurar título, descripción, ícono y tiempo estimado
 * para cada StageWelcome. Incluye preview live en mobile y desktop.
 */

import { getStageWelcomes } from '@/lib/actions'
import { BienvenidaClient } from './_client'

export const metadata = {
  title: 'Bienvenidas | Admin',
  description: 'Configurá los textos, íconos y descripciones de las pantallas de bienvenida que ven los clientes antes de iniciar cada entrevista de etapa.',
}

export default async function BienvenidaPage() {
  const welcomes = await getStageWelcomes()

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Bienvenidas</h1>
        <p className="text-sm text-[#64748B] mt-1">
          Pantallas de bienvenida que los clientes ven antes de iniciar cada entrevista. El punto
          verde indica que la etapa ya tiene configuración guardada en DB.
        </p>
      </div>

      <BienvenidaClient welcomes={welcomes} />
    </div>
  )
}
