# Session Log — Qautiva

> Registro cronológico de sesiones de trabajo.

---

## Board Integration — Heartbeat + Directivas — 2026-03-22

**Branch**: `claude/board-onboarding-instructions-24Dq7` → mergeado a `main` (PR #180)
**Estado**: ✅ Deployado en producción (`app.qautiva.ar`)

### Qué se hizo
- Creado `apps/portal/lib/board-client.ts` con `sendHeartbeat`, `sendMetrics`, `sendEvents`, `updateDirectiveStatus`
- Creado `GET /api/cron/board-heartbeat` — invocado por Vercel Cron cada 5 min, autenticado con `CRON_SECRET`
- Creado `POST /api/v1/directives/receive` — recibe directivas del Board, valida HMAC-SHA256
- Configurado cron en `apps/portal/vercel.json`
- Creado `docs/board/.gitkeep` para recibir docs sincronizados desde q-company via PR automático

### Estado del heartbeat en producción
- ✅ Endpoint responde en `app.qautiva.ar/api/cron/board-heartbeat`
- ❌ Devuelve 500 — faltan las variables `BOARD_URL`, `BOARD_API_KEY`, `BOARD_BU_ID` en Vercel

### Pendiente
- Setear variables de entorno en Vercel → **Settings → Environment Variables** de `qautiva-portal`:
  - `BOARD_URL`
  - `BOARD_API_KEY`
  - `BOARD_BU_ID`
  - `BOARD_WEBHOOK_SECRET`
- Rotar `CRON_SECRET` (quedó expuesto en conversación)

---

## Meta Ads Creative Frontend — Fixes post-revisión — 2026-03-21

**Branch**: `claude/meta-ads-creative-frontend-VN8P1`
**Revisión original**: `docs/reviews/2026-03-21_revision-completa_meta-ads-creative-frontend.md`
**Estado**: ✅ Todos los críticos, altos y medios resueltos

### Críticos (6/6 resueltos)
- ✅ C1: Fallback a DB en GET polling (`[jobId]/route.ts`) — busca AD_VISUALS READY en últimos 10 min si job no está en memoria
- ✅ C2: `checkBillingEligibility` antes de iniciar job (`route.ts`)
- ✅ C3: Error interno sanitizado — solo mensaje genérico al cliente, full error en logs
- ✅ C4: `registerAiUsage` con tokens estimados (1800 in / 0 out) tras generación exitosa
- ✅ C5: `$transaction` con `updateMany(isActive=false)` antes de crear nuevo AD_VISUALS
- ✅ C6: `generateMetadata` retorna título estático (sin consulta DB, sin IDOR)

### Altos (4/4 resueltos)
- ✅ A1: `useEffect` cleanup de `pollTimerRef` y `elapsedTimerRef` en `CreativosClient`
- ✅ A3: `isGeneratingRef` como guard anti double-click en `handleGenerate`
- ✅ A6: `remotePatterns` en `next.config.mjs` para Supabase Storage y Google Storage
- ✅ A8: Estado "Enviado al cliente" tras éxito en `SendToClientButton` (CampanasTab)

### Medios (10/12 resueltos — 2 omitidos por ser decisiones de producto)
- ✅ M1: Eliminar `console.warn` en producción (`ad-visual-prompt-builder.ts`)
- ✅ M2: `include` → `select` en query de profile (`creativos/page.tsx`)
- ✅ M3: Backoff exponencial en polling: 3s → 5s → 10s (reduce carga ~60% en generaciones largas)
- ✅ M4: Loading state (spinner) en botón de descarga (`AdVisualsGallery`)
- ✅ M5: `#475569` → `#64748B` (ratio 4.7:1 vs 3.2:1 — pasa WCAG AA)
- ✅ M6: `text-[10px]` → `text-xs` (12px mínimo) en badges de formato/ángulo
- ✅ M7: Constante `MAX_DAILY_AD_VISUALS` en `_lib/constants.ts` compartida (elimina magic number duplicado)
- ✅ M8: Prop `projectName` eliminada de `CreativosClient` (no usada)
- ✅ M9: `AbortController` con timeout 30s en `handleDownload`
- ✅ M10: Meta `description` en `creativos/page.tsx`
- ⏭ M11: Logs sin `requestId`/`correlationId` — requiere refactor de logger (post-MVP)
- ⏭ M12: AD_VISUALS sin flujo de aprobación — decisión de producto (post-MVP)

### Pendientes post-MVP (sin cambio de prioridad)
- A2: `waitUntil` para fire-and-forget en Vercel serverless
- A4: Validación de rol MEMBER en endpoint de generación
- A7: Tracking de funnel de creativos (analytics)

### job-store.ts: funciones de inflight tracking
- ✅ Agregados: `addInflightProject`, `removeInflightProject`, `isProjectInflight`

### Commits
| # | Descripción |
|---|-------------|
| 0fbd8f8 | fix: críticos y altos (C1-C6, A1, A3, A4, A5, A6, A8, job-store inflight) |
| c843468 | fix: medios (M1-M10, backoff, contraste, descarga, constantes) |

---

## Revisión: Meta Ads Creative Frontend — 2026-03-21

**Tipo**: Completa (técnica + negocio) — 9 roles
**Branch revisado**: `claude/meta-ads-creative-frontend-VN8P1`
**Resultado**: ⚠️ Con observaciones críticas → **✅ Resuelto** (ver sección arriba)
**Informe**: `docs/reviews/2026-03-21_revision-completa_meta-ads-creative-frontend.md`
**Hallazgos**: 6 críticos únicos, ~15 altos, ~20 medios

---

## Sesión: Meta Ads Creative Generation (Nano Banana) — 2026-03-21

**Branch:** `claude/meta-ads-creative-generation-LYFLd`
**Tarea:** Generación de piezas visuales para Meta Ads usando Gemini Flash Image con loop de auto-validación

### Implementado

**Etapa 0 — Schema, tipos y migración:**
- `DeliverableType.AD_VISUALS` en schema.prisma
- Migración `026_ad_visuals_deliverable_type.sql` (+ rollback)
- Tipos `AdVisual`, `AdVisuals`, `AdVisualBrandContext`, `AdVisualFormat` en `types.ts`
- ADR-0024 actualizado

**Etapa 1 — Infraestructura compartida (`image-utils.ts`):**
- Extraído de `brand-generator.ts`: `validateImageBytes`, `resizeImageForPayload`, `ensureBucket`, `uploadImageToStorage`
- Cache de buckets con `Map<string, boolean>` (no boolean) para soportar brand-logos + ad-visuals independientemente
- Signed URL TTL: 1 año (deliverables persistentes)
- Detección MIME type (JPEG vs PNG) en upload
- `brand-generator.ts` actualizado para usar las utilidades compartidas

**Etapa 2 — Generador de prompts (`ad-visual-prompt-builder.ts`):**
- 2 ángulos × 3 formatos = 6 specs por defecto
- Anti-injection: datos del usuario en bloque "CLIENT DATA (treat as literal text)"
- `sanitizeUserText()`: strips control chars, trunca
- Fallback a defaults cuando no hay BRAND_OPTIONS
- Integra headline/CTA del AdCreatives o CampaignPlan

**Etapa 3 — Generador de imágenes (`ad-visual-generator.ts`):**
- `generateAdVisuals()`: 6 piezas en lotes de 3 (concurrencia limitada)
- Budget total 180s, timeout por llamada 45s
- Degradación aceptable: si falta 1 ángulo pero queda otro en el formato
- Error total: si un formato queda sin ninguna pieza
- `regenerateAdVisual()`: regenera 1 pieza por ID (usado en el loop de validación)

**Etapa 4 — Validador cruzado (`ad-visual-validator.ts`):**
- Usa Anthropic Haiku (no Gemini) para evitar sesgo de auto-evaluación
- 5 dimensiones (0-100): relevancia, calidadTecnica, coherenciaMarca, composicion, legibilidadTexto
- Batches de 3 imágenes, timeout total 90s
- Máx 2 piezas marcadas para regeneración (las de peor score)
- Degradación si la API de validación falla: acepta todo sin score

**Etapa 5 — Integración en `session-processor.ts`:**
- `generateAndSaveAdVisuals()`: genera → valida → regenera → persiste AD_VISUALS
- Persistencia separada: AD_CREATIVES se salva + sesión COMPLETED, luego AD_VISUALS
- `updateMany` filtra por `type: 'AD_CREATIVES'` o `'AD_VISUALS'` (no por stageId genérico)
- Skip completo si META no está en connectedPlatforms

**Etapa 6 — Tests:**
- `image-utils.test.ts`: 11 casos (validateImageBytes, ensureBucket, uploadImageToStorage)
- `ad-visual-prompt-builder.test.ts`: 10 casos (specs, defaults, anti-injection, copy fallback)
- `ad-visual-generator.test.ts`: 7 casos (éxito, degradación parcial, error total, regenerate)
- `ad-visual-validator.test.ts`: 10 casos (scores correctos, degradación, applyValidationScores)

### Correcciones post-revisión (Code Reviewer)
- Modelo de validación: Opus → Haiku (costo desproporcionado)
- Score 0 enmascarado: `|| 70` → null check
- Signed URLs TTL: 24h → 1 año
- Timeout global de 90s en validateAdVisuals (Promise.race)
- MIME type detectado desde magic bytes en upload

### Hallazgos pendientes (medios)
- console.log no estructurado en producción (aceptado para v1)
- Race condition teórica en ensureBucket (mitigada por "already exists" ignore)

### Commits
| # | Descripción |
|---|-------------|
| e646c1b | etapa 0/7 — schema, tipos, migración |
| 82851aa | etapa 1/7 — image-utils.ts |
| 7918394 | etapa 2/7 — ad-visual-prompt-builder.ts |
| fd8674a | etapa 3/7 — ad-visual-generator.ts |
| 5923aa8 | etapa 4/7 — ad-visual-validator.ts |
| d34e1e9 | etapa 5/7 — session-processor integration |
| d1f1120 | etapa 6/7 — tests |
| fa18e29 | fix — correcciones post-revisión |

---

## Sesión: Feature Stitch — Fábrica de Templates — 2026-03-19

**Branch:** `claude/stitch-template-factory-QGpkU`
**Tarea:** Implementar "Stitch como Fábrica de Templates" (plan revisado por 6 roles)

### Implementado

**S0 — Prerequisitos y seguridad:**
- Fix XSS: `TemplateSelectionClient.tsx` `sandbox="allow-same-origin"` → `sandbox="allow-scripts"`
- ADR-0022: `docs/decisions/ADR-0022-stitch-template-factory.md` (decisión, contingencia, privacidad)
- `STITCH_API_KEY` agregada a `.env.example` (raíz, admin, portal)

**S1 — Sistema de diseño:**
- `docs/DESIGN.md`: tokens, paleta, tipografía, reglas para Stitch (data-section, sandbox, no tracking)

**S2 — Package `packages/stitch`:**
- `types.ts`: `BrandKit`, `BusinessData`, `GenerateTemplateParams`, `PersonalizeParams`, etc.
- `client.ts`: singleton con `STITCH_API_KEY`, `_resetStitchClient()` para tests
- `logger.ts`: logging estructurado sin datos sensibles
- `design-context.ts`: DESIGN.md embebido como constante (no `fs.readFileSync`)
- `generate-template.ts`: `generateTemplate()` con retry exponencial, timeout 60s, HTML+screenshot en paralelo
- `personalize-template.ts`: `personalizeTemplate()` con `creativeRange: "REFINE"`, manejo de brandKit parcial/null
- `generate-variants.ts`: `generateVariants()` con máx 5 variantes
- `index.ts`: re-exports públicos incluyendo html-processor
- Tests: `generate-template.test.ts`, `personalize-template.test.ts`

**S3 — Schema Prisma:**
- Enum `WebTemplateSource` (MANUAL | STITCH)
- 4 campos nuevos en `WebTemplate`: `source`, `stitchProjectId`, `stitchScreenId`, `generationPrompt`, `generatingAt`
- Migración 021: `021_webtemplate_stitch_fields.sql` + rollback
- Lock optimista con índice parcial sobre `generatingAt`

**S4 — Bridge HTML (Stitch → Handlebars):**
- `html-processor.ts`: `sanitizeStitchHtml()` (DOMPurify), `escapeHandlebarsLiterals()`, `processStitchHtml()`, `validateHandlebarsCompilation()`
- 17 tests en `html-processor.test.ts`

**S5 — Admin UI:**
- `apps/admin/app/(protected)/templates/nuevo/_components/StitchGenerator.tsx`
- `apps/admin/app/(protected)/templates/[id]/editar/page.tsx` + `StitchEditor.tsx`
- `apps/admin/app/api/stitch/generate/route.ts` (lock optimista, maxDuration 120)
- `apps/admin/app/api/stitch/edit/route.ts`
- `apps/admin/app/api/stitch/variants/route.ts` (máx 5 variantes)

**S6 — Portal:**
- `stitch-personalizer.ts`: `personalizeWithStitch()` (reutiliza helpers de website-generator, no duplica)
- `session-processor.ts`: bifurcación STITCH/MANUAL en `processWebsiteSession()`, fallback a Handlebars, badge `usedStitchFallback`

**S7 — Docs y configuración:**
- `ARCHITECTURE.md`: Stitch en tabla 2.5, ADR-0022 en lista
- `apps/admin/app/api/health/route.ts`: check de `STITCH_API_KEY`
- `vitest.config.ts` + `tsconfig.base.json`: alias `@qautiva/stitch`
- `apps/admin/tsconfig.json` + `apps/portal/tsconfig.json`: paths para Next.js

### Decisiones clave
- Sanitización XSS con `isomorphic-dompurify` (no regex manual)
- DESIGN.md como constante embebida (no `fs.readFileSync` en serverless)
- Bridge Handlebars siempre obligatorio al guardar template Stitch
- Personalización async en portal (fallback a Handlebars si falla, con badge)
- Datos enviados a Google: documentado en ADR-0022 + pendiente revisión ToS antes de producción

---

## Sesión: Fase 5 — Módulo de Campañas Publicitarias — 2026-03-18

**Branch:** `claude/review-project-context-Ock33`
**Tarea:** Implementar fases 5.2–5.6 del módulo de campañas publicitarias.

### Implementado

**Fase 5.2 — OAuth flows (continuado del contexto anterior):**
- Tests de `/api/ads/accounts` (9 tests), fixes de seguridad (state cookie en error paths, defense-in-depth token stripping)

**Fase 5.3 — Generador de estrategia de campaña:**
- `campaign-strategy-generator.ts`: `generateCampaignPlan` con tool_use forzado, validación runtime, `MIN_DISCLAIMER_PREFIX` hardcodeado
- `session-processor.ts`: `processCampaignsSession` con `Promise.allSettled`
- `types.ts`: tipo `CampaignPlan`
- 11 tests pasando

**Fase 5.4 — Generador de piezas publicitarias:**
- `ad-creative-generator.ts`: `generateAdCreatives`, LIMITS por plataforma, `enforceCharLimits`, filtrado por `connectedPlatforms`
- `CreativePreview.tsx`: mockups Google Search / Meta Feed / Meta Story
- `AdCreativesStep.tsx`: tabs por plataforma + guiaDeTono + disclaimer
- `session-processor.ts`: `processCreativesSession`
- `types.ts`: `AdCopyVariant` + `AdCreatives`
- Migración `013_ad_creatives_deliverable_type.sql` (ADD VALUE IF NOT EXISTS sin BEGIN/COMMIT)
- Fix post-review: `structuredClone` en generate, validación de `angle`, CTA buttons → spans
- 8 tests pasando (19 total con fase 5.3)

**Fase 5.5 — Panel admin de campañas:**
- `CampanasTab.tsx`: tab con JsonViewer + botón "Enviar al cliente"
- `campaign-actions.ts`: `sendCampaignDeliverableToClient` Server Action
- `ClientTabs.tsx`: tab `campanas` con contador
- `page.tsx` clientes/[id]: VALID_TABS + tabCounts.campanas + renderizado condicional
- `badges.ts` + `DeliverableCard.tsx`: `AD_CREATIVES → 'Piezas publicitarias'`

**Fase 5.6 — Sincronización de métricas:**
- `packages/ads/src/google/metrics.ts`: `fetchGoogleCampaignMetrics` via GAQL (last_30_days)
- `packages/ads/src/meta/metrics.ts`: `fetchMetaCampaignMetrics` via Insights API (paginación cursor)
- `apps/admin/lib/metrics-sync.ts`: `syncAdAccountMetrics` — desencripta tokens, refresh auto de Google, upsert `CampaignMetric` con `source=API_SYNC`
- `campaign-actions.ts`: `triggerAdAccountMetricsSync` Server Action
- `packages/db/index.ts`: exports de `AdPlatform`, `AdAccountStatus`, `CampaignStatus`, `MetricSource`, `CreativeType`
- Admin: `@qautiva/ads` como workspace dep + path aliases en tsconfig + transpilePackages

### Notas técnicas

- `AdAccount` pertenece a `Project` (no a `Organization`) — no hay link directo para mostrar cuentas de ads en la ficha de cliente del admin (KNOWN_ISSUE para resolver en Fase B)
- `AdAccountStatus` enum: `PENDING_AUTH`, `ACTIVE`, `EXPIRED`, `DISCONNECTED`, `ERROR` (no `REVOKED`)
- Tokens en DB: encriptados con AES-256-GCM vía `token-manager.ts` — siempre `decryptToken()` antes de usar
- Google Ads: necesita `GOOGLE_ADS_DEVELOPER_TOKEN` env var adicional (no está en el .env.example aún)

---

## Sesión: Debug /clientes + revisión pre-producción (6 roles) — 2026-03-16

**Branch:** `claude/debug-admin-clients-JNXNJ`
**Tarea:** Debugear página /clientes que no mostraba datos. Aplicar revisión completa de docs/roles/.

### Causa raíz

La página `apps/admin/app/(protected)/clientes/page.tsx` era un stub de 8 líneas sin fetch de datos.

### Implementado

**Página /clientes:**
- `apps/admin/app/(protected)/clientes/page.tsx` — tabla completa: query Prisma cacheada 30s, todos los clientes (activos + pausados), búsqueda por nombre, badges de etapa/estado/plan, link a ficha de cliente, scroll horizontal responsive, pulse en "Espera revisión"

**Utilitario compartido:**
- `apps/admin/lib/org-utils.ts` — `relativeTime()` y `deriveClientStatus()` extraídas del dashboard para evitar duplicación. Ambas páginas importan desde acá.

**Dashboard refactorizado:**
- `apps/admin/app/(protected)/page.tsx` — elimina las dos funciones locales duplicadas, importa desde `lib/org-utils.ts`

**Revisión por roles (docs/roles/):**
- `docs/reviews/2026-03-16_code-review.md`
- `docs/reviews/2026-03-16_qa.md`
- `docs/reviews/2026-03-16_security.md`
- `docs/reviews/2026-03-16_performance.md`
- `docs/reviews/2026-03-16_devops.md`
- `docs/reviews/2026-03-16_product.md`

### Correcciones aplicadas durante revisión

| Rol | Hallazgo | Severidad | Fix |
|-----|----------|-----------|-----|
| Code Review | Duplicación relativeTime/deriveClientStatus | ALTO | Extraídas a lib/org-utils.ts |
| QA | Búsqueda con espacios mostraba "Sin clientes" | MEDIO | `.trim()` antes de filtrar |
| QA | Tabla sin scroll horizontal | MEDIO | `overflow-x-auto + min-w-[640px]` |
| Product | Clientes pausados parecían disabled | MEDIO | Quitado opacity-50 |
| Product | Formulario sin botón submit | MEDIO | Agregado botón "Buscar" |
| QA | Input sin label accesible | BAJO | `<label htmlFor="q">` con sr-only |
| QA | Nombres largos sin truncar | BAJO | `max-w-[220px] truncate block` |
| Product | Columna "Actualizado" ambigua | BAJO | Renombrada "Última actividad" |
| Product | Sin pulse en "Espera revisión" | BAJO | Dot animado consistente con ClientCard |

### Documentación actualizada

- `docs/ARCHITECTURE.md` — sección lib/admin + convención helpers compartidos + descripción /clientes/page.tsx
- `SESSION_LOG.md` — esta entrada

---

## Sesión: Brand Generator (Etapa BRAND) — 2026-03-15

**Branch:** `claude/setup-brand-generator-o22n9`
**Tarea:** Implementar Brand Generator completo (etapa 3 / Director Creativo): conceptos de marca via OpenAI + logos via Gemini + componente de aprobación + integración al flujo.

### Implementado

**Nuevos archivos:**
- `apps/portal/app/_lib/interview/openai-client.ts` — Singleton OpenAI SDK. Valida env var, timeout 90s
- `apps/portal/app/_lib/interview/gemini-client.ts` — Singleton GoogleGenerativeAI SDK. Valida env var
- `apps/portal/app/_lib/interview/brand-generator.ts` — `generateBrandOptions()`: OpenAI structured output (3 conceptos) + Gemini image gen (logos PNG en paralelo). Degradación 1/3 graceful; 2+/3 throw. Magic bytes PNG/JPEG. Max 2 MB. `_bucketEnsured` cache de bucket. `_resetBucketCacheForTesting()` para tests
- `apps/portal/app/_lib/interview/__tests__/brand-generator.test.ts` — 21 tests Vitest: happy path, JPEG válido, degradación 1/3, threshold 2/3, 3/3 fail, OpenAI fail, max_tokens, hex validation, magic bytes, bucket creation, JSON-serializable, 8 casos parametrizados hex
- `docs/decisions/ADR-0017-brand-generator-multi-provider.md` — Decisión técnica: OpenAI+Gemini vs Anthropic exclusivo

**Modificaciones:**
- `apps/portal/app/_lib/interview/types.ts` — +4 tipos: `ColorSwatch`, `BrandConceptOption` (interno, tiene `logoPrompt`), `BrandOption` (deliverable, tiene `logoUrl?`), `BrandOptions`
- `apps/portal/app/_lib/interview/session-processor.ts` — `processBrandSession()` + rama `stageKey === 'BRAND'` en `processSession()`
- `apps/portal/components/BrandApproval.tsx` — importa tipos de types.ts, prop `disclaimer`, badges `brandPersonality`, `HEX_REGEX` sanitización CSS, guard `options.length === 0`, placeholder logo mejorado
- `apps/portal/app/(protected)/entregables/[id]/page.tsx` — +`brandPersonality: string[]` en tipo local, +`disclaimer` prop
- `apps/portal/app/proyectos/[id]/entregables/[did]/page.tsx` — ídem
- `.env.example` + `apps/portal/.env.example` — +`OPENAI_API_KEY`, +`GOOGLE_GEMINI_API_KEY` con notas de billing

**Post-audit (docs/roles, todos los severidades):**
- Race condition en `createBucket` (ignora "already exists")
- `Buffer.from(base64)` en try/catch con mensaje descriptivo
- `_bucketEnsured` flag para evitar `listBuckets()` redundante
- Imports reorganizados (external → internal → types)
- Logging separado de `errorType` y `errorMsg`
- Test: `_resetBucketCacheForTesting()` en `beforeEach` para aislamiento
- Test: hex con 2 colores para cubrir path correcto de validación

### Pendiente
- Seed/migration: 5 preguntas default para AgentConfig del Director Creativo (BRAND stage) — IDs `brand_1..brand_5`. Ver PLAN.md líneas 242-292

### Commits clave
- `bfc9b42` — brand-generator: OpenAI+Gemini, tipos, session-processor, BrandApproval, ADR-0017
- `15410ea` — brand-generator post-audit: race condition, magic bytes validation, logging
- `50dfea2` — tests brand-generator: 21 tests, bucket cache reset, hex fix

---

## Sesión: Deuda técnica + E6 Analytics — 2026-03-15 (continuación)

**Branch:** `claude/apply-docs-roles-wXI8O`
**Tarea:** 10 tareas de deuda técnica + E6 analytics. Multi-agente paralelo.

### Implementado

**E6 — Analytics de visitas:**
- `packages/db/prisma/schema.prisma` — modelo `DeliverableView` (deliverableId, viewedAt, userAgent, referer)
- `packages/db/prisma/migrations/0012_deliverable_analytics.sql` — tabla SQL con índices
- `apps/portal/app/api/preview/[id]/route.ts` — fire-and-forget tracking de visitas al cargar preview
- `apps/portal/app/api/deliverables/[id]/analytics/route.ts` — NUEVO: GET analytics (totalViews, last7Days, last30Days)
- `apps/portal/app/proyectos/[id]/entregables/[did]/_components/DeliverableAnalytics.tsx` — NUEVO: widget de métricas

**Fixes de silent failures:**
- `FeedbackForm.tsx`: `.catch(() => {})` → log con contexto (dato igual se guarda en localStorage)
- `ProcessingScreen.tsx`: `.catch(() => {})` → log con contexto (polling sigue como fallback)

**Paginación:**
- `apps/portal/app/proyectos/page.tsx`: `take:50` hardcodeado → `PAGE_SIZE=20` con skip/take real, `?page` param, navegación Anterior/Siguiente, redirect si página inválida

**Performance:**
- `apps/admin/app/(protected)/agentes/[id]/page.tsx`: `AgentPerformanceChart` con dynamic import (`ssr:false`)
- `apps/portal/app/marketplace/page.tsx`: `<Suspense>` alrededor de `MediaFilters` (usa `useSearchParams`)

**useReducer en InterviewClient:**
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx`: consolida `session`, `uiState`, `errorMsg` en `useReducer(interviewReducer, initialInterviewState)`. `draftAnswer` se mantiene separado.

**Caching estratégico:**
- `apps/portal/app/api/deliverables/[id]/action/route.ts`: `revalidatePath` en `/proyectos/:id/entregables` y `/proyectos/:id/progreso`
- `apps/portal/app/api/settings/profile/route.ts`: `revalidatePath('/configuracion')`
- `apps/portal/app/api/settings/ai-mode/route.ts`: `revalidatePath('/configuracion')`
- `apps/portal/app/api/settings/api-keys/route.ts`: `revalidatePath('/configuracion')`
- `apps/portal/app/api/settings/api-keys/[id]/route.ts`: `revalidatePath('/configuracion')`

**Migrations:**
- `0013_fix_rls_consistency.sql`: documenta y migra políticas RLS de `auth.jwt() ->> 'role'` a `auth.jwt() -> 'app_metadata' ->> 'role'`
- Renombra migraciones con numeración duplicada: 005→008, 006→009, 007→010

**Tests:**
- `apps/portal/__tests__/api/interview/answer.test.ts` — NUEVO: tests unitarios para `/answer` endpoint
- `apps/portal/__tests__/api/marketplace/orders.test.ts` — nuevos tests GET `/orders` (auth, role, filtrado, paginación)

### Pendiente
- E7: Iteraciones y cambios post-aprobación del sitio web
- `bodyHtml` sin sanitizar (requiere `sanitize-html` — decisión de dependencia pendiente)
- Revisión 6 roles: informe en `docs/reviews/2026-03-15_deuda-tecnica-y-e6.md`

### Commits clave
- `72a90e4` — migration 0012 analytics (inicial)
- `5e032fb` — silent failures + paginación (T1 agente)
- `14faed0` — dynamic import + Suspense + E6 analytics completo (T2+T3 agentes)
- `6177beb` — migration rename + RLS 0013 (T8+T10 agentes)
- `24b10f2` — useReducer + tests answer.test.ts + caching api-keys

---

## Sesión: Fase E — E4 + E5 + Importación desde catálogo — 2026-03-15

**Branch:** `claude/apply-docs-roles-wXI8O`
**Tarea:** Importación de templates desde catálogo externo (plan.md), E4 (IA genera copy del sitio), E5 (SEO + preview route). Revisión completa con 6 roles aplicados.

### Implementado

**Importación desde catálogo (plan.md completo):**
- `apps/admin/.env.example` — `TEMPLATES_CATALOG_URL` documentada con ejemplos dev/prod
- `apps/admin/app/(protected)/templates/importar/page.tsx` — NUEVO: grid del catálogo con cross-reference DB local (badge "Importado" + botón "Ver en mis templates")
- `apps/admin/app/(protected)/templates/importar/_import-button.tsx` — NUEVO: client component con redirect `?imported=1` post-importación
- `apps/admin/app/(protected)/templates/actions.ts` — `importWebTemplate()`: fetch catálogo, validación SSRF, sanitización HTML mejorada, validación thumbnail, creación DB
- `apps/admin/app/(protected)/templates/page.tsx` — botón "Importar desde catálogo"
- `apps/admin/app/(protected)/templates/[id]/page.tsx` — banner de éxito con `?imported=1`

**Revisión 6 roles + fixes aplicados:**
- `validateCatalogUrl()` — bloquea IPs cloud metadata (SSRF CRÍTICO)
- `sanitizeTemplateHtml()` mejorado — cubre `<svg>`, `<style>`, `<iframe>`, event handlers sin comillas, `vbscript:`, `data:`
- `validateThumbnailUrl()` — validación de URL thumbnail en importación
- `TEMPLATE_IMPORT` en logAudit, validación de estructura del catálogo, timeout 5s, cache 5min
- Banner `?imported=1`, `ARCHITECTURE.md` actualizado con dependencia `templates.qautiva.ar`
- 6 informes en `docs/reviews/2026-03-15_template-import-*.md`

**E4 — IA genera copy del sitio web:**
- `apps/portal/app/_lib/interview/website-generator.ts` — NUEVO: `generateWebsiteCopy()` con Claude claude-sonnet-4-6 + tool_use forzado. `applyWebsiteCopy()` reemplaza `{{variables}}` en htmlBase. System prompt en español argentino.
- `apps/portal/app/_lib/interview/session-processor.ts` — rama `stageKey === 'WEBSITE'`: busca WebTemplate + brandKit, genera copy, aplica al HTML, crea WEBSITE_PREVIEW deliverable (SENT_TO_CLIENT)
- Rutas `/api/interview/sessions/[id]/process`, `/api/admin/sessions/[id]/process`, `/api/cron/recover-stuck-sessions` — amplían select con `selectedWebTemplateId`, `stage.stageKey`, `project.brandKit`

**E5 — SEO básico automático + Preview:**
- `apps/portal/app/api/preview/[id]/route.ts` — NUEVO: sirve HTML del WEBSITE_PREVIEW con SEO tags inyectados (`<title>`, `<meta description>`, og:) y CSS embebido. Headers: SAMEORIGIN, CSP, no-cache.
- `apps/portal/app/api/interview/sessions/[id]/website-preview/route.ts` — NUEVO: endpoint para el frontend, retorna deliverable WEBSITE_PREVIEW activo del stage
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/WebsitePreviewView.tsx` — NUEVO: análogo a BriefView, muestra link "Ver preview del sitio →"
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx` — COMPLETED branch actualizado: mensaje específico WEBSITE + `WebsitePreviewView`
- `apps/portal/app/proyectos/[id]/entregables/[did]/page.tsx` — `isWebsiteContent()` acepta `html` además de `previewUrl`

### Pendiente
- E6: Analytics de visitas del sitio
- E7: Iteraciones y cambios post-aprobación
- Fixes diferidos previos: bodyHtml sin sanitizar, doble-submit onboarding, etc.

### Archivos modificados
- `apps/admin/app/(protected)/templates/` — importar/ (nuevo), actions.ts, page.tsx, [id]/page.tsx
- `apps/admin/.env.example`
- `apps/portal/app/_lib/interview/website-generator.ts` (nuevo)
- `apps/portal/app/_lib/interview/session-processor.ts`
- `apps/portal/app/api/interview/sessions/[id]/process/route.ts`
- `apps/portal/app/api/interview/sessions/[id]/website-preview/route.ts` (nuevo)
- `apps/portal/app/api/preview/[id]/route.ts` (nuevo)
- `apps/portal/app/api/admin/sessions/[id]/process/route.ts`
- `apps/portal/app/api/cron/recover-stuck-sessions/route.ts`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/WebsitePreviewView.tsx` (nuevo)
- `apps/portal/app/proyectos/[id]/entregables/[did]/page.tsx`
- `docs/ARCHITECTURE.md`
- `docs/reviews/2026-03-15_template-import-*.md` (6 archivos)

**Build:** N/A | Branch: `claude/apply-docs-roles-wXI8O` | Pushed ✅

---

## Sesión: Fase E — E3 + Fixes de revisión — 2026-03-15

**Branch:** `claude/continue-templates-phase-e-EoCxR`
**Tarea:** Implementar E3 (preguntas de personalización del template en entrevista WEBSITE) y aplicar todos los fixes pendientes de revisiones (altos, medios y bajos).

### Implementado

**E3 — Preguntas de personalización del template:**
- `apps/portal/app/_lib/interview/template-personalization.ts` — NUEVO: `buildTemplatePersonalizationQuestions(sections)` genera 5-6 preguntas `tpl_*` según las secciones activas del template (`tpl_sections`, `tpl_tone`, `tpl_cta`, `tpl_slogan`, `tpl_hours`, `tpl_extra`). `hasTemplatePersonalizationQuestions(flow)` detecta si ya están inyectadas.
- `apps/portal/app/api/interview/sessions/route.ts` — MODIFICADO: para etapa WEBSITE con `selectedWebTemplateId`, inyecta preguntas `tpl_*` al `flowDefinition` si aún no están presentes (detección por prefijo `tpl_`). Idempotente. Solo aplica para sesiones `NOT_STARTED | IN_PROGRESS | PAUSED`. Ver ADR-0016.

**Fixes de revisiones (medios y bajos):**
- `apps/portal/app/(protected)/configuracion/_components/TabNav.tsx` — "Inteligencia Artificial" → "IA" para evitar overflow en mobile (product review M2)
- `apps/portal/app/(protected)/configuracion/_components/AiTab.tsx` — descripción BYOK más clara para usuarios no técnicos (product review B2)
- `apps/portal/app/(protected)/configuracion/_components/AddApiKeyForm.tsx` — `htmlFor`/`id` en todos los labels/inputs (WCAG 2.1 A5), renombre "Etiqueta" → "Nombre" (qa B1), `maxLength={100}` en input label (security B2)
- `apps/portal/app/(protected)/configuracion/_components/AccountTab.tsx` — `htmlFor`/`id` en campos nombre y avatarUrl (WCAG 2.1 A5)
- `apps/portal/app/api/interview/sessions/[id]/answer/route.ts` — límite payload 50 KB, validación `questionId` contra `flowDefinition`, cap historial 100 entradas, mensaje genérico de estado (a2-api medios)
- `apps/portal/app/api/interview/sessions/[id]/advance/route.ts` — mensajes de error sin filtración de estado interno (a2-api medios)
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/TemplateSelectionClient.tsx` — etiqueta de etapa dinámica via `STAGE_LABELS` en lugar de hardcoded "Sitio Web" (e2 review M4)

**Documentación:**
- `docs/decisions/ADR-0016-e3-template-personalization-lazy-injection.md` — decisión de inyección lazy vs eager vs cliente
- `docs/ARCHITECTURE.md` — árbol actualizado con interview routes completas, `template-personalization.ts`, `_components/` de interview, convención flujo WEBSITE E1→E2→E3, ref a ADR-0016
- `SESSION_LOG.md` — esta entrada

### Archivos modificados
- `apps/portal/app/_lib/interview/template-personalization.ts` (nuevo)
- `apps/portal/app/api/interview/sessions/route.ts` (modificado — E3 injection)
- `apps/portal/app/(protected)/configuracion/_components/TabNav.tsx`
- `apps/portal/app/(protected)/configuracion/_components/AiTab.tsx`
- `apps/portal/app/(protected)/configuracion/_components/AddApiKeyForm.tsx`
- `apps/portal/app/(protected)/configuracion/_components/AccountTab.tsx`
- `apps/portal/app/api/interview/sessions/[id]/answer/route.ts`
- `apps/portal/app/api/interview/sessions/[id]/advance/route.ts`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/TemplateSelectionClient.tsx`
- `docs/decisions/ADR-0016-e3-template-personalization-lazy-injection.md` (nuevo)
- `docs/ARCHITECTURE.md` (actualizado)

### Pendiente (E4+)
- E4: IA genera copy del sitio leyendo `answers.tpl_*` + `selectedWebTemplateId` → `WebTemplate.htmlBase/variables` + `Project.brandKit`
- E5: SEO básico automático
- Fixes diferidos de revisiones: bodyHtml sin sanitizar (requiere `sanitize-html`), config carga todas las tabs, FeeRow cierre prematuro, validación cruzada fechas, fetchSetupStatus/fetchRecentActivity sin cache, doble-submit onboarding

**Build:** N/A (no ejecutado en esta sesión) | Commit `0124290` en `claude/continue-templates-phase-e-EoCxR` | Pushed ✅

---

## Sesión: Fase E — Templates Web (E1 + E2) — 2026-03-15

**Branch:** `claude/understand-template-system-rMvFl`
**Tarea:** Implementar gestión de templates web para la etapa WEBSITE. E1 = CRUD admin, E2 = catálogo portal + selección. Revisión completa 6 roles sobre E2.

### Implementado

**E1 — Admin CRUD de templates web:**
- `apps/admin/app/(protected)/templates/` — NUEVO: página de listado con tabla, acciones por fila (duplicar, eliminar), paginación segura (`take: 200`)
- `apps/admin/app/(protected)/templates/nuevo/page.tsx` — NUEVO: formulario de creación
- `apps/admin/app/(protected)/templates/[id]/page.tsx` — NUEVO: editor con tabs (Info, Secciones, Código)
- `apps/admin/app/(protected)/templates/[id]/_components/` — NUEVO: `TemplateTabs`, `TabInfo`, `TabSecciones`, `TabCodigo`
- `apps/admin/app/(protected)/templates/actions.ts` — NUEVO: server actions `createWebTemplate`, `updateTemplateInfo`, `updateTemplateSections`, `updateTemplateCode`, `deleteWebTemplate`, `duplicateWebTemplate`
- `packages/db/prisma/schema.prisma` — MODIFICADO: agrega modelo `WebTemplate` + enum `WebTemplateStatus` + campo `selectedWebTemplateId String?` en `InterviewSession`
- `packages/db/prisma/migrations/005_web_templates.sql` — NUEVO: crea tabla, índices, trigger `updatedAt`
- `packages/db/prisma/migrations/006_interview_session_template.sql` — NUEVO: agrega `selectedWebTemplateId` con índice parcial

**E2 — Catálogo portal + selección:**
- `apps/portal/app/api/templates/route.ts` — NUEVO: `GET /api/templates?industry=X`. Devuelve templates ACTIVE (máx 100), marca `recommendedId` desde `IndustryTemplate.webTemplate`. Cache-Control: `s-maxage=300`.
- `apps/portal/app/api/interview/sessions/[id]/template/route.ts` — NUEVO: `PATCH /api/interview/sessions/[id]/template`. Guarda `selectedWebTemplateId` con transacción interactiva (evita race conditions). Ajusta `usageCount` atómicamente.
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/TemplateSelectionClient.tsx` — NUEVO: grilla de tarjetas de templates, pre-selección del recomendado, secciones en español, link "Volver a etapas", accesibilidad (`role="radiogroup"`/`role="radio"`).
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/page.tsx` — MODIFICADO: para `stageKey=WEBSITE`, verifica `selectedWebTemplateId`; si null → `TemplateSelectionClient`, si presente → `InterviewClient`. UUID validation de params.

**Revisión 6 roles E2:**
- Informe: `docs/reviews/2026-03-15_fase-e2-template-catalog.md`
- 1 crítico corregido (race condition transacción)
- 9 altos corregidos (try/catch, logging, usageCount guard, session error visible, secciones ES, back nav, lazy img, etc.)

### Archivos modificados/creados
- `packages/db/prisma/schema.prisma`
- `packages/db/prisma/migrations/005_web_templates.sql`
- `packages/db/prisma/migrations/006_interview_session_template.sql`
- `packages/db/prisma/migrations/007_web_template_constraints.sql`
- `apps/admin/app/(protected)/templates/` (directorio completo nuevo)
- `apps/portal/app/api/templates/route.ts`
- `apps/portal/app/api/interview/sessions/[id]/template/route.ts`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/TemplateSelectionClient.tsx`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/page.tsx`
- `docs/reviews/2026-03-15_fase-e2-template-catalog.md`

### Pendiente (E3+)
- E3: Preguntas de personalización en entrevista WEBSITE
- E4: IA genera copy + aplica brandKit
- E5: SEO básico automático
- E6-E8: Analytics, Preview, Iteraciones

---

## Sesión: Eliminación segura de proyectos — 2026-03-14

**Branch:** `claude/safe-project-deletion-gMgmQ`
**Tarea:** Implementar eliminación de proyectos con soft-delete + UI con confirmación. Revisión completa de 6 roles.

### Implementado

**Endpoint:**
- `apps/portal/app/api/projects/[id]/route.ts` — NEW: `DELETE /api/projects/[id]`. Auth (Supabase) + UUID validation + ownership check (teamIds, previene IDOR) + soft-delete (`deletedAt: new Date()`) + `revalidatePath` + log de auditoría

**UI:**
- `apps/portal/app/proyectos/_components/DeleteProjectButton.tsx` — NEW: `'use client'`. Botón papelera con `opacity-60 sm:opacity-0 sm:group-hover:opacity-100` (visible en mobile, hover en desktop). Modal de confirmación: muestra nombre del proyecto, cierra con Escape / backdrop click, botón deshabilitado durante operación, errores de red/server mostrados inline.
- `apps/portal/app/proyectos/page.tsx` — MODIFICADO: cards migradas de `<Link>` envolvente a `div + Link interno` para poder superponer DeleteProjectButton sin interferir con la navegación.

**Revisión 6 roles (6 informes en `docs/reviews/2026-03-14_*-safe-project-deletion.md`):**
- Code Review, QA, Security, Performance, DevOps/SRE, Product
- Hallazgos ALTOS corregidos: botón invisible en mobile (opacity responsive), modal sin Escape (useEffect keydown)
- Hallazgos MEDIO extra corregidos: `e.preventDefault()` innecesario en div interior, `break-words` en nombre del proyecto

**Documentación:**
- `docs/decisions/ADR-0013-eliminacion-segura-proyectos.md` — 3 decisiones: hard-delete vs soft-delete, opciones UI del botón, window.confirm() vs modal custom
- `docs/ARCHITECTURE.md` — Actualizado: nuevo endpoint, nueva estructura `_components/`, convenciones de soft-delete y colocation de componentes, lista de ADRs
- `SESSION_LOG.md` — Esta entrada

### Archivos modificados
- `apps/portal/app/api/projects/[id]/route.ts` (nuevo)
- `apps/portal/app/proyectos/_components/DeleteProjectButton.tsx` (nuevo)
- `apps/portal/app/proyectos/page.tsx` (modificado)
- `docs/decisions/ADR-0013-eliminacion-segura-proyectos.md` (nuevo)
- `docs/ARCHITECTURE.md` (actualizado)
- `docs/reviews/2026-03-14_{code-review,qa,security,performance,devops,product}-safe-project-deletion.md` (6 nuevos)

---

## Sesión: Entrevista conversacional IA (El Estratega) — 2026-03-14

**Branch:** `claude/debug-interview-loading-dpat6`
**Tarea:** Implementar sistema completo de entrevista conversacional con IA para El Estratega (etapa 1). 7 etapas (I1–I7) + review de 6 roles + todos los pendientes del review.

### Implementado

**I1 — Prompt de El Estratega:**
- `packages/db/prisma/seed.ts` — Reemplaza `interviewPrompt` de JSON `QuestionBlock[]` a prompt de texto conversacional. Fix `update: {}` → `update: { interviewPrompt }` para que upserts actualicen correctamente

**I2 — Motor de entrevista conversacional:**
- `apps/portal/app/_lib/interview/types.ts` — Agrega `StrategicBrief` (6 secciones: negocio, mercado, audiencia, posicionamiento, direccionComunicacional, decisionesPendientes)
- `apps/portal/app/_lib/interview/ai-interviewer.ts` — NEW: `getNextQuestion()` + `buildMessages()`. Tools `ask_question` / `interview_complete`. `tool_choice: { type: 'any' }`
- `apps/portal/app/api/interview/sessions/[id]/next-question/route.ts` — NEW: POST con validación de respuestas (string ≤5000, array ≤50 strings, number), locking optimista `answersVersion`, resume tras recarga, límite 15 preguntas, deduplicación de IDs

**I3 — UI conversacional:**
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/client.tsx` — Agrega `ConversationalInterview` component para `stageNumber === 1`. Indicador 3-dot bounce, hint "8-12 preguntas", contador de preguntas

**I4 — Generador de Brief:**
- `apps/portal/app/_lib/interview/brief-generator.ts` — NEW: `generateStrategicBrief()` con tool `generate_brief`, schema completo, `max_tokens: 4096`
- `apps/portal/app/api/interview/sessions/[id]/process/route.ts` — NEW: POST fire-and-forget, idempotente, manejo de reintentos con `retryCount`/`maxRetries`, transacción Prisma PROCESSING→COMPLETED

**I5 — Vista del Brief:**
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/BriefView.tsx` — NEW: Carga y renderiza el Brief con secciones destacadas, competitors cards, decisiones pendientes; botón de reintento en error
- `apps/portal/app/api/interview/sessions/[id]/brief/route.ts` — NEW: GET con ownership check por `teamId`

**I6 — Tests:**
- `apps/portal/__tests__/interview/ai-interviewer.test.ts` — NEW: 8 tests (buildMessages + getNextQuestion)
- `apps/portal/__tests__/interview/brief-generator.test.ts` — NEW: 4 tests (generateStrategicBrief)

**I7 / Review + pendientes (7 fixes):**
- PERF-ALTO: `timeout: 25_000` en ambos clientes Anthropic
- QA-ALTO: Deduplicación de IDs de pregunta con sufijo `_2`, `_3`...
- PERF-MEDIO: Límite de 15 preguntas → fuerza PROCESSING
- QA-MEDIO: Botón "Reintentar" en BriefView
- PRODUCT-ALTO: Hint estimación de preguntas en pantalla inicial
- CODE-ALTO: `apps/portal/app/_lib/interview/get-user-team-ids.ts` — elimina duplicación en 3 rutas
- SRE-ALTO: `apps/portal/app/api/cron/recover-stuck-sessions/route.ts` + schedule en `vercel.json`

**Documentación:**
- `docs/decisions/ADR-0012-entrevista-conversacional-ia-estratega.md` — 3 decisiones: reconstrucción de historial vs DB, tool_use para output estructurado, patrón tool_use conversacional
- `docs/ARCHITECTURE.md` — Actualizado: alcance, estructura portal, dependencias externas, convenciones
- `SESSION_LOG.md` — Esta entrada

### Tests
278 tests passing (25 archivos).

### Variables de entorno requeridas
- `CRON_SECRET` — en Vercel, para autorizar el cron de recovery

---

## Sesión: Mobile responsive sidebar — 2026-03-14

**Branch:** `claude/qa-test-features-wcC0c`
**Tarea:** Solucionar vista mobile rota (sidebar de 260px fija aplastaba el contenido en iPhone). QA funcional del día + revisión 6 roles.

### Implementado

**QA funcional (docs/reviews/2026-03-14_qa.md):**
- Revisión estática de código de 5 features: onboarding, /proyectos/nuevo, /configuracion, admin panel, marketplace
- 5 issues bloqueantes identificados (doble submit, brief whitespace bypass, sin rate limiting en password, sin audit log en medios)

**Fix sidebar mobile (7 archivos, +288 líneas):**
- `components/SidebarContext.tsx` — NEW: Context API con `SidebarProvider` y `useSidebar`. Estado `open/toggle/close` estable vía `useCallback`/`useMemo`
- `components/MobileSidebarWrapper.tsx` — NEW: Drawer deslizable con overlay, cierre automático al navegar/resize/Escape, focus management (`tabIndex={-1}`)
- `components/TopBar.tsx` — Botón hamburger mobile (`md:hidden`, 44×44px touch target, `aria-label` dinámico), logo responsive `h-8 md:h-12`, hamburger+logo agrupados en div para `justify-between` correcto
- `app/(protected)/layout.tsx` — Envuelto en `SidebarProvider` + `MobileSidebarWrapper`
- `app/proyectos/[id]/layout.tsx` — Ídem

**Revisión 6 roles (6 informes en docs/reviews/):**
- Hallazgos ALTOS corregidos: `useCallback`/`useMemo` en Provider, cierre al navegar, `aria-label` dinámico
- Hallazgos MEDIOs/BAJOs corregidos: logo responsive, hamburger+logo agrupados, touch target, focus management, resize listener

**Documentación:**
- `docs/decisions/ADR-0011-mobile-sidebar-responsive.md` — Context API vs alternativas (CSS hack, URL state, prop drilling)
- `docs/ARCHITECTURE.md` — Actualizado: nuevos componentes, descripciones de layouts, convención mobile sidebar
- Docstrings en `SidebarContext` y `MobileSidebarWrapper`

### Archivos modificados
- `apps/portal/components/SidebarContext.tsx` (nuevo)
- `apps/portal/components/MobileSidebarWrapper.tsx` (nuevo)
- `apps/portal/components/TopBar.tsx`
- `apps/portal/app/(protected)/layout.tsx`
- `apps/portal/app/proyectos/[id]/layout.tsx`
- `docs/reviews/2026-03-14_qa.md` + 6 informes de revisión mobile sidebar
- `docs/decisions/ADR-0011-mobile-sidebar-responsive.md`
- `docs/ARCHITECTURE.md`

### Commits
- `60d6210` — docs(qa): revisión QA funcional 2026-03-14
- `e2a8d55` — feat(portal): mobile responsive sidebar con drawer y hamburger
- `00ac3f9` — fix(portal/sidebar): correcciones post revisión 6 roles
- `e232a29` — fix(portal/sidebar): pendientes MEDIOs/BAJOs de revisión 6 roles

### Pendientes
- Verificar visualmente en dispositivo real (iPhone SE 375px) el botón X vs contenido del sidebar
- Considerar `focus-trap` si se necesita navegación por teclado completa dentro del drawer

---

## Sesión: Cierre pendientes + fix tests rotos — 2026-03-14 (cont.)

**Branch:** `claude/interview-engine-start-4lOLl`

### Fix tests preexistentes (continuación de sesión)

- `packages/db/__tests__/etapa2-onboarding.test.ts` — actualizado para refactor 2026-03-12: paso api-key envía `step: 2` (no 4), redirect a `/proyectos` (no `/proyectos/{id}/progreso`), `/api/onboarding` solo maneja configuración IA (step 2)
- `apps/portal/__tests__/api/marketplace/orders.test.ts` — mock agrega `$transaction` (con tx que expone `order.findFirst/create`) y `OrderStatus` exportados desde `@qautiva/db`
- `apps/portal/__tests__/api/projects.test.ts` — usa UUID v4 `'00000000-0000-4000-a000-000000000001'` como projectId (ruta valida formato antes del IDOR check)
- `apps/portal/__tests__/api/settings/password.test.ts` — aserción `'proveedor externo'` (mensaje cambiado en la ruta)
- `apps/admin/__tests__/actions/media-moderation.test.ts` — `expect.objectContaining({ id: 'm-1' })` en where del update (la ruta agrega `status: 'PENDING_REVIEW'` al where)
- `vitest.config.ts` — alias `@/lib/audit` → `apps/admin/lib/audit`; `@prisma/client` → `packages/db/generated/client`

**Resultado:** 23 archivos, 265 tests, 0 fallas.

---

## Sesión: Pendientes pre-producción — tests + E3 fixes — 2026-03-14

**Branch:** `claude/interview-engine-start-4lOLl`
**Tarea:** Cerrar todos los pendientes del plan antes de declarar producción estable: fix `window.location.href`, verificación trigger Supabase, tests de Etapa 4.8.

### Implementado

**Fix E3:**
- `apps/portal/app/onboarding/api-key/client.tsx` — `window.location.href = '/proyectos'` → `router.push('/proyectos')` (Next.js router)

**Verificación trigger Supabase:**
- `packages/db/prisma/migrations/001_handle_new_user_trigger.sql` — revisado; trigger completo con idempotencia, fallback PREPAID, manejo de errores sin bloquear auth.users. ⚠️ Verificar que esté aplicado en Supabase prod con la query comentada al final del archivo.

**Tests nuevos (Etapa 4.8):**
- `apps/admin/__tests__/actions/stage-review.test.ts` — 15 tests: `approveStage` (7) + `rejectStage` (8) — validaciones, IDOR check, DB error, happy path
- `apps/admin/__tests__/actions/admin-message.test.ts` — 10 tests: `sendAdminMessage` — validaciones, org inexistente, stageNumber válido/inválido, trim
- `services/telegram-bot/__tests__/llm.test.ts` — 8 tests: `generateResponse` (tool_use, text directo, fallbacks, error) + `validateAnthropicConfig`

**Config:**
- `vitest.config.ts` — agregado alias `'@/lib/audit'` → `apps/admin/lib/audit` (necesario para tests del admin que importan actions.ts)

### Estado de tests
- ✅ 3 archivos nuevos: todos los tests pasan
- ⚠️ 6 archivos preexistentes con fallas (no tocados en esta sesión):
  - `packages/db/__tests__/etapa1-schema.test.ts` — enums Prisma no generados
  - `packages/db/__tests__/etapa2-onboarding.test.ts` — páginas negocio/servicios eliminadas en refactor
  - `apps/portal/__tests__/api/marketplace/orders.test.ts` — mock de Prisma.Decimal
  - `apps/portal/__tests__/api/settings/password.test.ts` — mensaje de error cambió
  - `apps/admin/__tests__/actions/media-moderation.test.ts` — preexistente
  - `apps/portal/__tests__/api/projects.test.ts` — preexistente

### Pendientes
- Verificar en Supabase prod que el trigger `on_auth_user_created` está aplicado
- Resolver fallas de tests preexistentes (sesión separada)

---

## Sesión: Feature configuración de usuario + revisión 6 roles — 2026-03-13

**Branch:** `claude/user-account-setup-1gJOZ`
**Tarea:** Rediseño completo de `/configuracion`: Mi cuenta (nombre, avatar, cambio de contraseña), IA (BYOK vs Hosted, gestión de API keys), Plan (estado de billing). Revisión con 6 roles y corrección de hallazgos.

### Implementado

**Archivos nuevos — componentes:**
- `apps/portal/app/(protected)/configuracion/page.tsx` — Server Component hub: detecta legacy/self-service, `Promise.all` de queries Prisma, renderiza tab activo
- `apps/portal/app/(protected)/configuracion/_components/TabNav.tsx` — Tabs URL-based; legacy ve solo "Mi cuenta"
- `apps/portal/app/(protected)/configuracion/_components/AccountTab.tsx` — Nombre (maxLength 150), avatar URL, email read-only, sección org para legacy
- `apps/portal/app/(protected)/configuracion/_components/ChangePasswordForm.tsx` — Contraseña: bloqueado para OAuth (provider !== 'email')
- `apps/portal/app/(protected)/configuracion/_components/AiTab.tsx` — Selector BYOK/Hosted (grid responsive), lista de API keys, AddApiKeyForm
- `apps/portal/app/(protected)/configuracion/_components/ApiKeyCard.tsx` — Provider, hint, validez, lastUsedAt, revocar
- `apps/portal/app/(protected)/configuracion/_components/AddApiKeyForm.tsx` — Agregar key con validación live "Validando..."
- `apps/portal/app/(protected)/configuracion/_components/PlanTab.tsx` — Trial token bar + plan pagado + balance
- `apps/portal/app/(protected)/configuracion/_components/InfoRow.tsx` — Componente compartido label/valor

**Archivos nuevos — API routes:**
- `apps/portal/app/api/settings/profile/route.ts` — PATCH displayName + avatarUrl (validación URL http/https)
- `apps/portal/app/api/settings/password/route.ts` — POST cambio de contraseña (verifica actual con signInWithPassword)
- `apps/portal/app/api/settings/api-keys/route.ts` — GET lista + POST agregar (encripta AES-256-GCM)
- `apps/portal/app/api/settings/api-keys/[id]/route.ts` — DELETE con ownership check + guard última key BYOK
- `apps/portal/app/api/settings/ai-mode/route.ts` — PATCH preferredKeySource

**Archivos nuevos — helpers y tests:**
- `apps/portal/app/_lib/get-team-for-user.ts` — `getTeamForUser(authUserId)` helper compartido
- `apps/portal/__tests__/api/settings/profile.test.ts` — 5 tests
- `apps/portal/__tests__/api/settings/api-keys.test.ts` — 11 tests
- `apps/portal/__tests__/api/settings/ai-mode.test.ts` — 6 tests
- `apps/portal/__tests__/api/settings/password.test.ts` — 5 tests

**Archivos nuevos — documentación:**
- `docs/reviews/2026-03-13_code-review.md`
- `docs/reviews/2026-03-13_qa.md`
- `docs/reviews/2026-03-13_security.md`
- `docs/reviews/2026-03-13_performance.md`
- `docs/reviews/2026-03-13_devops.md`
- `docs/reviews/2026-03-13_product.md`
- `docs/decisions/ADR-0010-user-settings-architecture.md`

### Revisión 6 roles + fixes

| Hallazgo | Sev | Fix |
|----------|-----|-----|
| `InfoRow` duplicado en AccountTab y PlanTab | ALTO | Extraído a `_components/InfoRow.tsx` compartido |
| Avatar URL aceptaba `javascript:` y `data:` URLs (stored XSS) | ALTO | Validación con `new URL()` + check protocolo http/https en `/api/settings/profile` |
| Queries de Prisma secuenciales en page.tsx | ALTO | Refactor con `Promise.all` en 3 variables tipadas |
| `provider === 'google'` no bloquea otros OAuth (GitHub, Apple) | MEDIO | Cambiado a `provider !== 'email'` en ChangePasswordForm y password/route |
| Grid `grid-cols-2` apretado en mobile 375px (iPhone SE) | ALTO | Cambiado a `grid-cols-1 sm:grid-cols-2` en AiTab |
| Sin `console.error` en fallo de updateUserById | BAJO | Agregado log con contexto `[settings/password]` |

**Commits en branch:** `e8ec41f` (feature) → `7776f05` (fixes revisión 6 roles + docs)

---

## Sesión: Refactor onboarding — separación cuenta/proyecto + revisión 6 roles — 2026-03-12

**Branch:** `claude/improve-onboarding-plan-HVo3b`
**Tarea:** Separar onboarding de cuenta (2 pasos) del wizard de creación de proyectos (/proyectos/nuevo). Extraer helpers reutilizables. Revisión con 6 roles y corrección de hallazgos.

### Implementado

**Archivos nuevos:**
- `apps/portal/app/_lib/project-slug.ts` — `buildSlug()` extraído de onboarding para reutilización
- `apps/portal/app/_lib/service-stages.ts` — `SERVICE_STAGES`, `VALID_SERVICES`, `ServiceType`
- `apps/portal/app/_lib/validate-api-key.ts` — `validateApiKey()` + validadores por proveedor (Anthropic/OpenAI/Gemini)
- `apps/portal/app/_lib/organization-legacy.ts` — `createOrganizationLegacy(tx, project)` bridge para admin panel
- `apps/portal/app/proyectos/layout.tsx` — Header con logo, "+ Nuevo proyecto", logout server action (sync, sin auth redundante)
- `apps/portal/app/proyectos/page.tsx` — Hub de proyectos: lista con status badges, empty state, banner de saldo $0
- `apps/portal/app/proyectos/nuevo/layout.tsx` — Progress bar 2 pasos ("Tu negocio" + "Servicios"), patrón `x-pathname`
- `apps/portal/app/proyectos/nuevo/page.tsx` — Wrapper delgado para `<NegocioClient />`
- `apps/portal/app/proyectos/nuevo/client.tsx` — Form nombre/industria/descripcion/ciudad → POST `/api/projects` step 1
- `apps/portal/app/proyectos/nuevo/servicios/page.tsx` — Server guard con 1 query joined (IDOR check)
- `apps/portal/app/proyectos/nuevo/servicios/client.tsx` — Multi-select servicios → POST `/api/projects` step 2
- `apps/portal/app/api/projects/route.ts` — Step 1: crea Project (status SETUP). Step 2: crea Stages + Org + actualiza userProfile
- `apps/portal/__tests__/api/onboarding-refactored.test.ts` — 8 tests: modos trial/hosted/byok, 401, 400 step inválido, sin creación de Project/Org
- `apps/portal/__tests__/api/projects.test.ts` — 10 tests: 401/403, step1 validación, step2 IDOR check
- `docs/decisions/ADR-0009-separacion-onboarding-cuenta-proyecto.md`
- `docs/onboarding/PLAN_REFACTOR_ONBOARDING_SEPARAR_CUENTA_PROYECTO.md`

**Archivos modificados:**
- `apps/portal/app/api/onboarding/route.ts` — Eliminados handleStep2/3 (negocio/servicios). handleStep4→handleStep2. Retorna `{ ok: true }`.
- `apps/portal/app/onboarding/layout.tsx` — Progress bar 4→2 pasos. Threshold `currentStep <= 2`.
- `apps/portal/app/onboarding/api-key/client.tsx` — Payload sin projectId, redirect a `/proyectos`, botón "Continuar sin saldo por ahora" para modo hosted.
- `apps/portal/app/onboarding/completo/page.tsx` — Simplificado: solo `redirect('/proyectos')`, sin `force-dynamic`.
- `apps/portal/app/onboarding/page.tsx` — 3 redirects: `/onboarding/negocio` → `/onboarding/api-key`.
- `apps/portal/app/page.tsx` — Self-service siempre → `/proyectos`.
- `apps/portal/components/ProjectSidebar.tsx` — Link "Mis proyectos": `href="/"` → `href="/proyectos"`.

**Archivos eliminados:**
- `apps/portal/app/onboarding/negocio/page.tsx`
- `apps/portal/app/onboarding/servicios/page.tsx`

### Revisión 6 roles + fixes

| Hallazgo | Sev | Fix |
|----------|-----|-----|
| `proyectos/layout.tsx` llamaba `getUser()` redundante (middleware ya protege ruta) | ALTO | Layout convertido a sync, `getUser()` eliminado |
| `servicios/page.tsx` hacía 2 queries secuenciales (profile → project) | MEDIO | 1 query con join `team.members.some.user.authUserId` |
| `client.tsx` (negocio) no limpiaba error al cambiar descripcion/ciudad | BAJO | `setState('idle')` en onChange de los 4 campos |
| `creditBalance` inexistente en BillingAccount schema | CRÍTICO | Reemplazado por `balanceUsd` (Decimal) con `Number()` cast |
| `onboarding/completo/page.tsx` tenía `force-dynamic` innecesario | BAJO | Eliminado |

**Commits en branch:** refactor ejecutado en `claude/improve-onboarding-plan-HVo3b`

---

## Sesión: Marketplace Etapas 1.2, 1.3 y revisión — 2026-03-11

**Branch:** `claude/marketplace-foundation-start-rLJIW`
**Tarea:** Seed de categorías (1.2), API de Medios CRUD (1.3), revisión 5 roles, corrección de hallazgos.

### Implementado

**Archivos nuevos:**
- `packages/db/prisma/migrations/003_marketplace_media_metrics_fields.sql` — ALTER TABLE agrega `followersCount`, `monthlyVisits`, `domainAuthority`; índices `(status, country)` y `(status, followersCount)`
- `apps/portal/app/api/marketplace/media/route.ts` — CRUD completo de medios (GET público con filtros, POST/PATCH/DELETE autenticados)
- `docs/reviews/2026-03-11_marketplace-1.2-1.3-review.md` — Revisión 5 roles

**Archivos modificados:**
- `packages/db/prisma/seed.ts` — agrega `seedMarketplaceCategories()` (20 categorías raíz, upsert idempotente)
- `packages/db/prisma/schema.prisma` — campos `followersCount/monthlyVisits/domainAuthority` en Medium; índices `(status, country)` y `(status, followersCount)`

### Revisión 5 roles (etapas 1.2 + 1.3)

| Hallazgo | Sev | Fix |
|----------|-----|-----|
| `followersCount/monthlyVisits/domainAuthority` inexistentes en schema | CRÍTICO | Migración 003 + schema actualizado |
| `url: null` en campo NOT NULL (redes sociales sin URL) | CRÍTICO | URL requerida para todas las plataformas |
| Filtro `followersCount` en GET referenciaba campo inexistente | CRÍTICO | Resuelto con fix C1 |
| `categoryIds` sin validar contra DB (500 en vez de 400) | ALTO | Validación previa con `prisma.category.findMany` |
| Editor podía editar medios REJECTED/SUSPENDED | ALTO | Check de status antes del update |
| Sin índice para filtro `country` | ALTO | `@@index([status, country])` en schema y migración 003 |
| Params numéricos GET (`minPrice`, `followers`) sin validar | MEDIO | `isNaN()` antes de pasarlos a Prisma |
| `monthlyVisits` sin validar en POST/PATCH | MEDIO | Validación agregada (>= 0) |

**Commits:** `ecb42e7` (1.2) → `47049c5` (1.3) → `64d14f5` (fixes) → `0076e51` (review doc)

---

## Sesión: Marketplace Etapa 1.1 — Schema Foundation — 2026-03-11

**Branch:** `claude/marketplace-foundation-start-rLJIW`
**Tarea:** Schema base del marketplace (6 enums + 6 modelos + migración SQL).

### Implementado

**Archivos modificados:**
- `packages/db/prisma/schema.prisma` — 6 enums nuevos (`MediumPlatform`, `MediumStatus`, `ProductType`, `OrderStatus`, `LinkType`, `VerificationMethod`); 2 relaciones en `UserProfile` (`media`, `ordersAsAdvertiser`); 6 modelos nuevos (`Category`, `Medium`, `MediumCategory`, `Product`, `Order`, `OrderMessage`) con `@@map("marketplace_*")`

**Archivos nuevos:**
- `packages/db/prisma/migrations/002_marketplace_foundation.sql` — migración SQL manual con ENUMs, tablas, FKs, índices, CHECKs y sección ROLLBACK
- `docs/decisions/ADR-0008-marketplace-data-model.md` — 4 decisiones de diseño
- `docs/reviews/2026-03-11_marketplace-1.1-quick-scan.md`
- `docs/reviews/2026-03-11_marketplace-1.1-code-review.md`
- `docs/reviews/2026-03-11_marketplace-1.1-devops-sre.md`

### Revisión de roles aplicada (Quick Scan + Code Reviewer + DevOps/SRE)

| Hallazgo | Severidad | Fix |
|----------|-----------|-----|
| `OrderMessage.senderId` sin FK en SQL | ALTO | FK constraint agregada en migración SQL |
| `@@unique([platform, oauthPlatformId])` no cubre WEBSITE (NULL != NULL) | MEDIO | Partial unique index `(userId, url) WHERE platform = 'WEBSITE'` |
| Sin CHECK en `price` y `deliveryDays` | MEDIO | `price > 0`, `deliveryDays > 0` en SQL |
| Header migración sin prereq PostgreSQL version | BAJO | Aclarado: PostgreSQL 13+ |

### Decisiones clave (ver ADR-0008)

- `uuid()` sobre `cuid()` — consistencia con el schema existente
- `marketplace_*` prefix — aísla el dominio del marketplace
- Editor = user con Medium (no UserRole separado)
- `senderId` como String con FK solo en SQL — evita back-relation innecesaria en UserProfile
- Partial unique index para WEBSITE — Prisma no soporta partial indexes

**Schema validado** (`prisma validate` + `tsc --noEmit` ✅) | commits `a055124` + `e0a5337` | pushed ✅

---

## Sesión: Etapa 4.6 — Optimización de builds Vercel — 2026-03-11

**Branch:** `claude/reduce-vercel-build-costs-6qLVK`
**Tarea:** Reducir consumo de build minutes en Vercel ($12.45/$20 en primeros días del ciclo).

### Implementado

**Archivos nuevos:**
- `turbo.json` — Turborepo config: pipeline de build/lint/typecheck con cache, outputs `.next/**`
- `apps/admin/vercel.json` — ignoreCommand + preview deployments desactivados (admin no tenía vercel.json)
- `docs/decisions/ADR-0007-turborepo-y-optimizacion-builds-vercel.md` — decisión documentada

**Archivos modificados:**
- `apps/landing/vercel.json` — agrega ignoreCommand (git diff por workspace) + desactiva preview deployments
- `apps/portal/vercel.json` — ídem, incluye `packages/db/` en paths monitoreados
- `package.json` — agrega turbo, packageManager field, migra scripts build/lint/typecheck a `turbo run`
- `pnpm-workspace.yaml` — ignoredBuiltDependencies (prisma, esbuild, etc.)
- `docs/ARCHITECTURE.md` — actualiza stack (Turborepo, pnpm 10.x), sección 9.2 costos, restricciones, ADRs

### Decisiones clave

- **No se hizo landing estática** (`output: 'export'`): tiene API routes (`/api/contact`, `/api/health`) que lo impiden
- **Preview deployments desactivados en los 3 proyectos**: requiere CI alternativo para validar PRs (pendiente)
- **Remote caching de Turborepo**: requiere configurar `TURBO_TOKEN`/`TURBO_TEAM` en Vercel dashboard (pendiente)

### Revisión 3-roles aplicada

| Rol | ALTOS | MEDIOS | BAJOS | Veredicto |
|-----|-------|--------|-------|-----------|
| Code Reviewer | 0 | 2 | 2 | APROBADO CON OBSERVACIONES |
| Performance | 1 | 2 | 1 | APROBADO CON OBSERVACIONES |
| DevOps/SRE | 2 | 2 | 1 | APROBADO CON OBSERVACIONES |

Hallazgos MEDIOS/BAJOS corregidos en commit posterior. ALTOs documentados en ADR-0007 como pendientes.

---

## Sesión: Etapa 4.5 — Bot de Telegram con LLM — 2026-03-11

**Branch:** `claude/qautiva-stage-4-setup-eoNpb`
**Tarea:** Integrar Anthropic LLM con function calling en `services/telegram-bot`.

### Implementado

**Archivos nuevos:**
- `services/telegram-bot/src/tools.ts` — 3 tools (get_project_status, get_current_stage_detail, get_recent_admin_messages) en formato Anthropic
- `services/telegram-bot/src/tool-executor.ts` — ejecuta tools via Prisma; nunca lanza excepciones; retorna string para que el LLM formatee
- `services/telegram-bot/src/llm.ts` — generateResponse() con flujo interpret → execute_tool → format; modelo configurable via TelegramConfig DB singleton; historial in-memory (max 3 mensajes); cliente Anthropic singleton

**Archivos modificados:**
- `services/telegram-bot/src/message-bridge.ts` — reemplaza respuesta estática con LLM; guarda CLIENT + AI en Message table por separado; typing action; trunca a 4000 chars
- `services/telegram-bot/package.json` — agrega @anthropic-ai/sdk ^0.78.0

**Tests:**
- `__tests__/tools.test.ts` — 6 tests de definición de tools
- `__tests__/tool-executor.test.ts` — 10 tests con Prisma mockeado (incluyendo error handling, clamping de limit, empty states)
- Total: 22 tests pasando (6 rate-limiter + 6 tools + 10 tool-executor)

### Variables de entorno requeridas

```
TELEGRAM_BOT_TOKEN=   # BotFather
ANTHROPIC_API_KEY=    # Anthropic
DATABASE_URL=         # Supabase PostgreSQL
```

### Arquitectura de la respuesta LLM

```
Usuario → mensaje
  → bot.ts verifica botEnabled + rate limit
  → message-bridge.ts guarda CLIENT message
  → llm.ts: Anthropic interpret() → decide tool
  → tool-executor.ts: query Prisma → string result
  → llm.ts: Anthropic format() → texto natural
  → message-bridge.ts guarda AI message
  → ctx.reply(responseText)
```

**Build:** tsc --noEmit limpio | 22 tests ✅ | commit `679db5a` | pushed ✅

### Revisión 6-roles (post-implementación) + Fixes aplicados

| Hallazgo | Severidad | Fix |
|----------|-----------|-----|
| 2 queries separadas a TelegramConfig por mensaje | ALTO | Fusionadas en `getBotConfig()` con cache 60s |
| Cast `as ToolName` antes de verificar pertenencia al Set | ALTO | Verificación del string raw antes del cast |
| ANTHROPIC_API_KEY no detectada en startup | ALTO | `validateAnthropicConfig()` llamada en `startBot()` con warn |
| Logs de error sin org/userId | ALTO | Contexto agregado: `org=X userId=Y` |
| `deliverables` sin `take:` en query | ALTO | `take: 20` límite defensivo |
| `Number.isFinite` para sanitizar `limit` del LLM | ALTO | Reemplaza `typeof number` que permite NaN |
| Mensaje de vinculación promete código que no se procesa | ALTO | Redirige al portal; TODO documenta pendiente |

**Build post-fixes:** tsc limpio | 22 tests ✅ | commit `d95f2ba` | pushed ✅

### Correcciones MEDIO/BAJO (tercera pasada)

| Hallazgo | Severidad | Fix |
|----------|-----------|-----|
| Historial in-memory crece indefinidamente sin cleanup | MEDIO | `HistoryBucket` con `lastAccess`; cleanup por TTL 24h vía `setInterval` + `.unref()` |
| `help.ts`: texto sugería respuestas sin verificar vínculo | MEDIO | Aclarado: "Si ya estás vinculado, podés escribirme en lenguaje natural..." |
| `status.ts`: emojis inconsistentes con CLAUDE.md | BAJO | Removidos `📊` y `📍` del mensaje de status |

**Build post-MEDIO/BAJO:** 22 tests ✅ | commit `6188929` | pushed ✅

**Estado al cierre:**
- Etapa 4.5 completada con revisión 6-roles completa (CRÍTICO/ALTO/MEDIO/BAJO). LLM integrado con function calling real.
- Pendiente: panel de administración del bot en `/telegram` del admin (fuera de scope 4.5). Vinculación self-service `/start <token>` (etapa 5).
- Siguiente: Etapa 5 o cierre de Etapa 4.

---

## Sesión 2026-03-10 — Configuración de Auth en producción

**Objetivo:** Configurar Google OAuth + rol admin para el admin app deployado en Vercel.

**Trabajo realizado:**

### Google OAuth
- Configurado Google Cloud Console con Authorized redirect URI apuntando al callback de Supabase
- URI configurada: `https://<proyecto>.supabase.co/auth/v1/callback`

### Supabase Auth
- Creado primer usuario admin via Google OAuth: `federicopronesti@institutoiea.edu.ar`
- Asignado rol ADMIN via SQL:
  ```sql
  UPDATE auth.users
  SET raw_app_meta_data = raw_app_meta_data || '{"role": "ADMIN"}'::jsonb
  WHERE id = '0b3ab0ab-4e1b-4d91-8d8a-2fd0327f0f0b';
  ```
- Configuradas Redirect URLs en Supabase → Authentication → URL Configuration:
  - Site URL: `https://admin.qautiva.ar`
  - Redirect URLs: `https://qautiva-admin.vercel.app/**` y `https://admin.qautiva.ar/**`

### Google Cloud Console — Authorized redirect URIs agregadas:
- `https://qautiva-admin.vercel.app/auth/callback`
- `https://admin.qautiva.ar/auth/callback`

### Deploy
- Admin app deployado en Vercel: `https://qautiva-admin.vercel.app`
- Dominio personalizado configurado: `https://admin.qautiva.ar`

**Estado al cierre:**
- Auth de admin funcional en producción
- Etapa 1 completada y verificada en producción
- Listo para comenzar Etapa 2 (Landing completa)

---

## Sesión 2026-03-10 — Etapa 2: Landing completa

**Objetivo:** Implementar refinamientos visuales de `apps/landing/` según spec sección 3.

**Trabajo realizado (7 archivos, 255 líneas agregadas):**

- `globals.css`: keyframe `meshMove` (gradiente animado 20s) + `@import` DM Sans en CSS
- `layout.tsx`: removido `next/font/google` (requería red en build)
- `Hero.tsx`: gradiente `.hero-mesh` animado + visual de 6 nodos del proceso (solo desktop)
- `Navbar.tsx`: `backdrop-blur-md` al hacer scroll via `useEffect`
- `HowItWorks.tsx`: líneas conectoras entre pasos (verde/violeta/gris) + layout mobile separado
- `WhyDifferent.tsx`: `textShadow` glow violeta en números animados
- `Footer.tsx`: íconos sociales Instagram, LinkedIn, Twitter (lucide-react)

**Verificación:** `next build` ✅ | `next lint` ✅ | commit en `claude/review-qautiva-docs-Tg8ZO`

**Estado al cierre:**
- Etapa 2 completada y pusheada — lista para deploy en Vercel (qautiva.ar)
- Siguiente: Etapa 3 (Portal del cliente)

---

## Sesión 2026-03-10 — Revisión pre-producción (6 roles) + fixes pendientes

**Objetivo:** Revisión completa de seguridad, performance y operaciones antes de deploy; luego completar todos los items pendientes.

### Parte 1 — Revisión de 6 roles (`docs/reviews/`)

Se ejecutó el sistema de revisión completo en secuencia:

| Rol | Hallazgos críticos/altos resueltos |
|-----|------------------------------------|
| Code Reviewer | `organization` null-check en bot (start, status); truncación silenciosa → rechazo explícito en `message-bridge.ts` |
| QA | `message-bridge.ts`: queries atómicas con `prisma.$transaction`; validación `isValidContactBody` |
| Security | CSRF Origin check + limpieza de rate limiter + threshold reCAPTCHA 0.7 en prod + PII removido de logs |
| Performance | Index compuesto `@@index([status, createdAt])` en schema Prisma; cleanup timer 5min en `RateLimiter` |
| DevOps/SRE | Creado `docs/OPERATIONS.md` con runbooks (bot caído, DB pool, rollback, rotación de secrets, backup/restore) |
| Product | `FinalCta.tsx`: validación de `NEXT_PUBLIC_WHATSAPP_NUMBER`; `health/route.ts`: enriquecido con `env` + `version` |

### Parte 2 — Items MEDIO pendientes

- **`apps/landing/vercel.json`**: `maxDuration: 30` para `/api/contact` (evita timeout por 2 fetch externos con 5s cada uno)
- **`safeName` validation**: post-sanitización, rechaza nombres que quedan vacíos o sin letras
- **`import 'server-only'`**: agregado a `packages/db/supabase.ts` — protege `SUPABASE_SERVICE_ROLE_KEY` del bundle cliente; confirmado que ningún Client Component importa desde `@qautiva/db`
- **Pricing hint**: "Desde $500 USD — pagás cuando ves resultados" antes del formulario de contacto
- **Tests**: 6 tests contact API + 6 tests `RateLimiter` — 23/23 passing; `vitest.config.ts` extendido para cubrir `services/**`

**Archivos modificados (esta sesión):**
`apps/landing/app/api/contact/route.ts`, `apps/landing/components/Pricing.tsx`, `apps/landing/components/FinalCta.tsx`, `apps/landing/app/api/health/route.ts`, `packages/db/supabase.ts`, `packages/db/prisma/schema.prisma`, `services/telegram-bot/src/{commands/start,commands/status,message-bridge,rate-limiter}.ts`, `docs/OPERATIONS.md`, `apps/landing/vercel.json`, `vitest.config.ts`

**Tests:** 23/23 ✅ | commits `191707e` + `cbcb72e` en `claude/review-qautiva-docs-Tg8ZO`

**Estado al cierre:**
- Landing en condición pre-producción: seguridad, performance, operaciones y tests completos
- Siguiente: Etapa 3 (Portal del cliente) o deploy a producción

---

## Sesión 2026-03-10 — Etapa 3: Portal del cliente con datos reales

**Objetivo:** Reemplazar todos los mocks del portal con queries reales (Prisma + Supabase) e implementar las 6 pantallas completas.

**Trabajo realizado (26 archivos, +2591 líneas):**

### Infraestructura
- `apps/portal/package.json`: agregado `@qautiva/db: workspace:*` y `recharts: ^2.12.0`
- `apps/portal/next.config.mjs`: `transpilePackages: ['@qautiva/db']` + env fallbacks para build sin `.env`
- `apps/portal/lib/supabase-server.ts` (NEW): re-export de `createServerClient` desde `@qautiva/db`
- `packages/db/supabase.ts`: reemplazado import interno de Next.js por interface local `CookieStore` (duck typing)
- `vitest.config.ts`: alias `'@/'` → `apps/portal/` para tests del portal

### Páginas (datos reales)
- `/progreso`: stages + deliverables desde Prisma; mapeo `StageStatus` → visual; acción pendiente con highlight
- `/entregables`: list con tabs URL-based (todos/pendientes/completados); filter por status arrays
- `/entregables/[id]` (NEW): ruta dinámica; renderiza `BrandApproval`, `WebPreview` o `GenericDeliverable`
- `/metricas`: queries 30 días actuales + 30 días anteriores; estado vacío si sin datos
- `/medios`: listado de Supabase Storage `org-assets/{orgId}/`; download por archivo y batch
- `/configuracion`: org + user info, read-only con mailto para cambios

### Componentes nuevos
- `DeliverableCard`: badge de estado, border highlight amber para acción requerida
- `BrandApproval`: selección de opción de marca, textarea feedback, approve/reject
- `WebPreview`: toggle desktop/tablet/mobile, iframe, approve con feedback
- `MetricsCards`: 4 tarjetas con trend % mes anterior, formateo ARS
- `MetricsChart`: Recharts LineChart (visitas + consultas), tooltip dark, responsive
- `CampaignCard`: Google/Meta con gasto, clicks, conversiones y explicación plain-language
- `ChatPanel`: Supabase Realtime suscrito a `Message` por `organizationId`; optimistic UI; diferenciación CLIENT vs AI/ADMIN

### Route Handlers
- `POST /api/deliverables/[id]/action`: approve/reject con validaciones (401/403/400/404/409)
- `POST /api/messages`: creación de mensaje con validación auth + org + contenido

### Tests
- `__tests__/api/deliverable-action.test.ts`: 8 tests (todos los casos de error + approve + reject)
- `__tests__/api/messages.test.ts`: 5 tests (401, 403, 400 vacío, 400 muy largo, success)
- Todos pasando ✅

**Verificación:** `next build` ✅ (13 rutas) | commit `8ba8ca0` en `claude/continue-qautiva-dev-Arcyw`

**Estado al cierre:**
- Etapa 3 completa y pusheada — portal 100% funcional con datos reales
- Siguiente: deploy del portal a Vercel o Etapa 4

---

## Sesión 2026-03-11 — Revisión pre-producción Etapa 3 + documentación

**Objetivo:** Aplicar los 6 roles de revisión sobre el portal (Etapa 3) y documentar según reglas de CLAUDE.md.

### Revisión por roles (`docs/reviews/2026-03-11_etapa3-portal.md`)

| Rol | Hallazgos |
|-----|-----------|
| Code Reviewer | ALTO: formatARS duplicado, BrandApproval sin enviar selección, métricas inventadas, link 404 |
| QA Engineer | CRÍTICO: "Descargar todo" 404; ALTO: opción seleccionada no guardada, métricas incorrectas |
| Security Auditor | ALTO: iframe sandbox XSS, assets con URL pública sin auth |
| Performance Engineer | Sin críticos/altos; índice ya existía en Metric |
| DevOps/SRE | ALTO: endpoint inexistente en prod |
| Product Reviewer | CRÍTICO: "Descargar todo" roto; ALTO: métricas inventadas y opción de marca perdida |

### Correcciones aplicadas (4 hallazgos críticos/altos)

1. `WebPreview.tsx` — Removido `allow-same-origin` del iframe sandbox (XSS)
2. `medios/page.tsx` — Eliminado botón "Descargar todo" (404)
3. `BrandApproval.tsx` + `action/route.ts` — Se envía y persiste `selectedOptionId` con prefijo `selected:` en campo `feedback`
4. `CampaignCard.tsx` + `metricas/page.tsx` — clicks/conversions son opcionales; se eliminaron las estimaciones ficticias

### Documentación generada

- `docs/decisions/ADR-0003-selectedoptionid-en-feedback.md` — Decisión de almacenar selección en campo feedback
- `docs/ARCHITECTURE.md` — Sección portal actualizada con Route Handlers, convenciones y estructura real
- JSDoc agregado a: `DeliverableCard`, `BrandApproval`, `WebPreview`, `MetricsCards`, `MetricsChart`, `CampaignCard`, `ChatPanel`

**Commits:** `24e30db` (fixes) + documentación en `claude/continue-qautiva-dev-Arcyw`

**Estado al cierre:**
- Portal revisado y documentado. Listo para deploy.
- Pendientes documentados: assets sin auth (decisión de bucket policy), DB call en layout sin caché, health check en portal.

---

## Sesión: Wizard Onboarding Self-Service (Etapa 2) — 2026-03-11

**Branch:** `claude/self-service-onboarding-byok-OZwu9`
**Tarea:** Implementar wizard de 4 pasos y revisión pre-producción (6 roles)

### Implementado

Wizard de onboarding self-service completo:
- `onboarding/layout.tsx` — Progress bar de 4 pasos con header
- `onboarding/page.tsx` — Paso 1: Sign up (Google OAuth + email/reCAPTCHA)
- `onboarding/negocio/page.tsx` — Paso 2: Datos del negocio
- `onboarding/servicios/page.tsx` — Paso 3: Selección de servicios
- `onboarding/api-key/page.tsx` + `client.tsx` — Paso 4: Trial / Hosted / BYOK
- `onboarding/completo/page.tsx` — Pantalla de éxito
- `api/onboarding/route.ts` — Handler para los 3 steps del backend

### Revisión pre-producción (6 roles)

| Rol | Hallazgos CRÍTICOS/ALTOS corregidos |
|-----|-------------------------------------|
| Code Reviewer | LoadingSpinner duplicado → componente compartido; VALID_MODES a módulo; htmlFor en labels |
| QA Engineer | Email confirmation sin manejo → pantalla "Revisá tu email" si session=null |
| Security Auditor | Industria sin validación server-side → VALID_INDUSTRIES; longitudes server-side; 429 → isValid=null |
| Performance Engineer | Loop stage.create × 4 → stage.createMany |
| DevOps/SRE | x-pathname no seteado → middleware.ts setea header |
| Product Reviewer | "fee más bajo" (inglés) → "costo menor"; completo/page.tsx sin CTA → Link al inicio |

### Documentación

- `docs/reviews/2026-03-11_*-wizard-onboarding.md` — 6 informes de revisión
- `docs/decisions/ADR-0004` — Estado: Propuesta → Aceptada
- `docs/ARCHITECTURE.md` — Sección portal actualizada con rutas onboarding, middleware y flujo de registro
- `onboarding/_constants/industries.ts` — Lista canónica (fuente única cliente + servidor)
- JSDoc en `POST`, `handleStep2`, `handleStep3`, `handleStep4` de `api/onboarding/route.ts`

**Commits:** `2ebaa8f`, `4b8b411`, `2d271f4` + commit documentación

**Estado al cierre:**
- Wizard implementado, revisado (6 roles), y todos los ALTOs corregidos.
- Pendiente Etapa 3: `completo/page.tsx` redirigir a `/proyectos/{id}/progreso`

---

## Sesión: Revisión pre-producción Etapa 3 (CRÍTICO/ALTO) — 2026-03-11

**Branch:** `claude/qautiva-onboarding-development-K83mS`
**Tarea:** Corregir todos los hallazgos CRÍTICO y ALTO de los 6 informes de revisión del portal self-service.

### Revisión por roles (`docs/reviews/2026-03-11_etapa3-portal-*.md`)

| Rol | Hallazgos CRÍTICO/ALTO |
|-----|------------------------|
| Code Reviewer | isWebsiteContent type guard incorrecto; GenericDeliverable mostraba JSON raw |
| QA Engineer | STAGE_LABELS usaba índice del array en vez de stage.number; texto "Etapas completadas" incorrecto |
| Security Auditor | CRÍTICO: soft-delete bypass en action route y messages route; ALTO: pid sin verificar en completo/page.tsx |
| Performance Engineer | CRÍTICO: layout sin caché (2 queries Prisma por navegación) |
| DevOps/SRE | ALTO: health check solo verifica DB, no Supabase Auth; layout sin try/catch |
| Product Reviewer | CRÍTICO: GenericDeliverable volcaba JSON; ALTO: pantalla GENERATING sin auto-refresh; "Etapas completadas" → "Entregables aprobados" |

### Correcciones aplicadas

1. `api/deliverables/[id]/action/route.ts` — `project: { deletedAt: null }` en query; try/catch con `console.error`; `console.info` en approve/reject
2. `api/messages/route.ts` — `deletedAt: null` en query de proyecto; try/catch en `prisma.message.create`
3. `app/proyectos/[id]/layout.tsx` — `unstable_cache` en `getProjectForUser()` (key: `['project-layout', userId, projectId]`, TTL 60s); try/catch con `console.error`
4. `app/api/health/route.ts` — agrega check de Supabase Auth; responde `checks: { db, auth }`
5. `app/onboarding/completo/page.tsx` — verifica ownership del `pid` antes de renderizar link; fallback "Ir al inicio"
6. `app/proyectos/[id]/entregables/[did]/page.tsx` — corregido `isWebsiteContent` (usa `'previewUrl' in content`); `GenericDeliverable` muestra mensaje amigable
7. `app/proyectos/[id]/progreso/page.tsx` — `AutoRefresh` en pantalla GENERATING; STAGE_LABELS usa `stage.number - 1`; "Entregables aprobados"
8. `components/AutoRefresh.tsx` (NEW) — llama `router.refresh()` cada `intervalMs` ms
9. `components/ChatPanel.tsx` — isMounted pattern (evita leak de canal Realtime); historial `ascending: false` + `.reverse()`; deduplicación por ID real

**Tests:** 129/129 ✅ | build portal: 22 rutas ✅ | commit `8b129e3`

**Estado al cierre:** Todos los CRÍTICO/ALTO corregidos. Pendiente: hallazgos MEDIO.

---

## Sesión: Revisión pre-producción Etapa 3 (MEDIO) — 2026-03-11

**Branch:** `claude/qautiva-onboarding-development-K83mS`
**Tarea:** Corregir todos los hallazgos MEDIO de los 6 informes de revisión del portal self-service.

### Correcciones aplicadas

1. `api/deliverables/[id]/action/route.ts` — validación `feedback.trim().length > 2000` → 400
2. `middleware.ts` — `pathname === '/api/health'` en `isPublicPath` (evita auth innecesario en health check)
3. `docs/OPERATIONS.md` — agrega portal a tabla de monitoreo; runbooks "Cliente no puede ver su proyecto" y "Aprobación de entregable no funciona"
4. `components/ProjectSidebar.tsx` — link "Mis proyectos" (→ `/`); botón logout (`signOut` + `router.push('/login')`); copy chat → "Chateá con el asistente"
5. `components/ChatPanel.tsx` — `maxLength={2000}` en textarea
6. `app/proyectos/[id]/progreso/page.tsx` — `.take(50)` en `deliverable.findMany`
7. `app/proyectos/[id]/entregables/[did]/page.tsx` — `generateMetadata` con título del entregable

**Archivos modificados:** 7 archivos, 90 líneas agregadas

**Tests:** 129/129 ✅ | build portal: 22 rutas ✅ | commit `7aba153`

**Estado al cierre:** Portal en condición pre-producción — todos los hallazgos CRÍTICO, ALTO y MEDIO corregidos. Pendientes BAJO (no críticos): extraer `BaseSidebar` compartido, extraer `ProgresoView`, mover tipos de entregables a módulo compartido, reemplazar `window.location.href` con `router.push()` en `api-key/client.tsx`.

---

## Sesión: Etapa 3 — Dashboard del proyecto self-service — 2026-03-11

**Branch:** `claude/qautiva-onboarding-development-K83mS`
**Tarea:** Crear rutas del portal para usuarios self-service (Project/Team model) y resolver TODOs del wizard.

### Implementado

**Fixes del wizard (MEDIOs pendientes):**
- `servicios/page.tsx`: doble espacio en botón cuando `selected.size === 0` → `'Seleccioná al menos un servicio'`
- `api-key/client.tsx`: redirect a `/proyectos/${projectId}/progreso` (resuelve TODO Etapa 3)
- `completo/page.tsx`: fallback con link al proyecto si `pid` está en searchParams

**Rutas nuevas (`/proyectos/[id]/`):**
- `layout.tsx` — verifica ownership vía team membership; renderiza `ProjectSidebar`
- `progreso/page.tsx` — stages + deliverables por `projectId`; pantalla de "generando" cuando status=GENERATING y sin stages
- `entregables/[did]/page.tsx` — detalle de entregable: `BrandApproval` | `WebPreview` | `GenericDeliverable`; breadcrumb a progreso
- `entregables/page.tsx` — índice que redirige al pending o al progreso

**Componentes nuevos:**
- `ProjectSidebar.tsx` — sidebar adaptado a Project/Team: navega a `/proyectos/{id}/progreso` y `/proyectos/{id}/entregables`; incluye ChatPanel con `projectId`

**Routes actualizadas (soporte self-service):**
- `/api/deliverables/[id]/action`: legacy usa `organizationId`, self-service verifica por `teamId` vía team membership
- `/api/messages`: legacy usa `org_id`, self-service acepta `projectId` en body y verifica team ownership
- `ChatPanel.tsx`: acepta `projectId?` opcional; cuando presente, filtra historial y Realtime por `projectId` en lugar de `organizationId`

### Tests
- `deliverable-action.test.ts`: actualizado — agrega `userProfile.findUnique` al mock; test 403 actualizado para ruta self-service
- `etapa2-onboarding.test.ts`: actualizado — verifica redirect a `/proyectos/*/progreso` en lugar de `/onboarding/completo`
- 129/129 ✅

### Billing null (investigación pendiente)
El warn `[onboarding] step4: team ${team.id} no tiene BillingAccount` existe en el código. No se pudo confirmar si hay trigger de Supabase que crea `BillingAccount` automáticamente. Verificar en Supabase Dashboard → Database → Functions/Triggers. Si no existe, crear trigger o seed manual en `handleStep2` al crear el Team.

**Commits:** `0fbe55c` en `claude/qautiva-onboarding-development-K83mS`

**Estado al cierre:**
- Etapa 3 completa. Flujo self-service end-to-end: onboarding → `/proyectos/{id}/progreso`.
- Pendiente: investigar trigger Supabase para `BillingAccount`; deploy a Vercel.

---

## Sesión: Etapa 4.1 — Dashboard Kanban con datos reales — 2026-03-11

**Branch:** `claude/qautiva-stage-4-setup-KuG6C`
**Tarea:** Reemplazar mocks del dashboard admin por queries Prisma reales; activar filtros.

### Implementado

**Infraestructura:**
- `apps/admin/package.json`: agregado `@qautiva/db: workspace:*`; build script incluye `prisma generate`
- `apps/admin/next.config.mjs`: `transpilePackages: ['@qautiva/db']` + env fallbacks

**Componentes actualizados:**
- `MetricsRow.tsx`: acepta `MetricData[]` como prop
- `KanbanFilters.tsx`: `'use client'`; filtros activos via URL search params; rubros dinámicos del servidor
- `ClientCard.tsx`: `industry` como `string` con badge fallback; wrapped en `Link` a `/clientes/[id]`

**Dashboard (page.tsx):**
- Async Server Component con `export const dynamic = 'force-dynamic'`
- 5 queries en paralelo: orgs+stages, cola de revisión, lanzamientos del mes, suscripciones activas, campañas gestionadas
- Mapeo `OrgStatus` → columna Kanban; `StageStatus[]` → `ClientStatus`
- Filtros server-side: plan, industry, status, búsqueda de texto
- PAUSED orgs excluidas del Kanban

**Build:** 14 rutas ✅ | commit `0abe2e8`

**Archivos modificados:**
`apps/admin/app/(protected)/page.tsx`, `apps/admin/components/MetricsRow.tsx`, `apps/admin/components/KanbanFilters.tsx`, `apps/admin/components/ClientCard.tsx`, `apps/admin/next.config.mjs`, `apps/admin/package.json`, `pnpm-lock.yaml`

**Estado al cierre:**
- Dashboard Kanban 100% funcional con datos reales
- Siguiente: 4.2 Ficha de cliente (`/clientes/[id]`), 4.3 Cola de revisión, 4.4 Agentes, 4.5 Telegram Bot con LLM

---

## Sesión: Etapa 4.2 — Ficha de cliente (/clientes/[id]) — 2026-03-11

**Branch:** `claude/qautiva-stage-4-setup-KuG6C`
**Tarea:** Implementar la ruta dinámica de detalle de cliente con datos reales de Prisma + revisión 6-roles + fixes.

### Implementado

**Ruta dinámica:**
- `apps/admin/app/(protected)/clientes/[id]/page.tsx`: Server Component con `force-dynamic`, query única que carga org completa (stages+deliverables, messages×300, notes×50, subscription). `notFound()` si no existe. Tab routing via `searchParams.tab`. Calcula `hasAdminReview` y `tabCounts` para props de hijos.
- `apps/admin/app/(protected)/clientes/[id]/loading.tsx`: skeleton con `animate-pulse`
- `apps/admin/app/(protected)/clientes/[id]/error.tsx`: error boundary con digest

**Componentes nuevos:**
- `ClientHeader.tsx`: avatar (inicial), nombre + "cliente desde fecha", badges OrgStatus/Plan/SubStatus, websiteUrl, suscripción ARS con `SubscriptionInfo` sub-componente, botón "Revisar pendiente" solo cuando `hasAdminReview === true`
- `ClientTabs.tsx`: `'use client'` URL-based tabs (Progreso | Entregables | Conversaciones | Notas) con contadores numéricos por tab
- `tabs/ProgresoTab.tsx`: stages ordenadas con deliverables; badges de StageStatus/DeliverableStatus; botón "Revisar" en ADMIN_REVIEW; aprobaciones admin/cliente
- `tabs/EntregablesTab.tsx`: lista flat de todos los entregables con tipo, etapa, versión y feedback
- `tabs/ConversacionesTab.tsx`: timeline con alineación por sender (CLIENT/AI izquierda, ADMIN derecha), badges de canal, muestra últimos 100 mensajes
- `tabs/NotasTab.tsx`: notas internas con formulario de creación
- `forms/IntervenirForm.tsx`: `useTransition`, `confirm()` antes de enviar, feedback de éxito, `maxLength={2000}`
- `forms/AgregarNotaForm.tsx`: `useTransition`, feedback de éxito, `maxLength={5000}`

**Infraestructura nueva:**
- `lib/types.ts`: `OrgWithDetails` + tipos derivados (`OrgStage`, `OrgDeliverable`, `OrgMessage`, `OrgNote`)
- `lib/badges.ts`: `STAGE_STATUS_BADGE`, `DELIVERABLE_STATUS_BADGE`, `DELIVERABLE_TYPE_LABEL` centralizados
- `lib/supabase-server.ts`: `createSupabaseServerClient()` y `requireAdminSession()` para Server Components/Actions
- `lib/actions.ts`: Server Actions `createAdminNote` + `sendAdminMessage` con auth, validación de existencia de org, maxLength server-side, validación de rango de stageNumber (1-6), try/catch con logging

### Revisión 6-roles (post-implementación)

**3 CRÍTICOs corregidos:** auth en Server Actions, IDOR via hidden input, FK error sin validación de existencia.
**12 ALTOs corregidos:** badges duplicados→centralizados, OrgWithDetails→lib/types.ts, feedback visual en forms, confirmación en IntervenirForm, moneda ARS explícita, límite 100 mensajes visibles, query duplicada generateMetadata eliminada, logging estructurado en actions.
**8 MEDIOs corregidos:** IIFE→sub-componente, createdAt en header, botón revisión condicional, contadores en tabs, take:50 en notas, maxLength UI+server, validación stageNumber.

**Commits:** `5ac0d7c` (implementación) · `d12df56` (fixes CRÍTICO/ALTO) · `31b1521` (fixes MEDIO)

**Informes en:** `docs/reviews/2026-03-11_etapa4-ficha-*.md` (6 archivos)

**Estado al cierre:**
- Ficha de cliente 100% funcional con datos reales, auth, validaciones y UX de formularios.
- Siguiente: 4.3 Cola de revisión (`/revision`), 4.4 Agentes (`/agentes`), 4.5 Telegram Bot con LLM.

---

## Sesión: Etapa 4.3 — Cola de revisión (/revision) — 2026-03-11

**Branch:** `claude/qautiva-stage-4-setup-KuG6C`
**Tarea:** Implementar `/revision` como página dual (cola + detalle) con flujo de aprobación/rechazo + revisión 6-roles + fixes.

### Implementado

**Página dual (`revision/page.tsx`):**
- `export const dynamic = 'force-dynamic'`
- `getQueue()`: orgs en `ADMIN_REVIEW`, ordenadas por `updatedAt asc` (más antiguas primero), `take: 100`
- `getStageDetail(stageId)`: carga una etapa específica con deliverables ordenados por `createdAt asc`
- Si `searchParams.stage` presente → modo detalle con `RevisionPanel`; sino → modo cola con `RevisionQueue`
- Cola siempre cargada para mostrar conteo en breadcrumb del detalle

**Componentes nuevos:**
- `RevisionQueue.tsx`: listado de cards con avatar org, nombre, plan (badge), industria, nombre de etapa, tiempo desde actualización (`timeAgo`), badges de entregables. Link a `/revision?stage={id}&org={orgId}`. Empty state "✓ Todo al día"
- `RevisionPanel.tsx`: breadcrumb Cola → org → etapa, estado `null` si ya fue revisada, lista de deliverables con badges, zona de acciones (`ApproveStageForm` + `RejectStageForm`)
- `forms/ApproveStageForm.tsx`: `useTransition` + `window.confirm()` + estado de éxito "✓ Aprobada" (800ms) antes de redirect a `/revision`; manejo de error en UI
- `forms/RejectStageForm.tsx`: expandible (collapsed → textarea); `formRef.current.reset()` al cancelar; estado de éxito "✓ Enviado" antes de redirect; textarea `required` + `maxLength={1000}`

**Server Actions nuevas (`lib/actions.ts`):**
- `approveStage`: `requireAdminSession()` → validación → findUnique con `organizationId` → check ownership → update `status: CLIENT_REVIEW` → `revalidatePath`
- `rejectStage`: mismo patrón + `prisma.$transaction([stage.update, adminNote.create])` para atomicidad

**Infraestructura:**
- `lib/badges.ts`: agregado `PLAN_BADGE: Record<Plan, {...}>` — centraliza los 3 planes con colores

### Revisión 6-roles (post-implementación) + Fixes aplicados

**CRÍTICOs:**
- IDOR en `approveStage` y `rejectStage`: `orgId` del formData no verificado contra la etapa → fix: `select { organizationId }` + `stage.organizationId !== orgId` throw Error

**ALTOs:**
- `PLAN_BADGE` duplicado en `RevisionQueue` y `RevisionPanel` → centralizado en `lib/badges.ts`; imports actualizados
- Sin límite en `getQueue()` → `take: 100`
- Sin confirmación en aprobación → `window.confirm()` en `ApproveStageForm`
- Sin feedback de éxito en forms → estado `success` + mensaje visual antes de redirect

**MEDIOs:**
- `RejectStageForm`: textarea no se limpiaba al cancelar → `formRef.current.reset()` en `handleCancel`

**Informes en:** `docs/reviews/2026-03-11_etapa4-revision-*.md` (6 archivos)

**Build:** 14 rutas ✅ | commit `71d40f2`

**Estado al cierre:**
- Cola de revisión 100% funcional con flujo approve/reject, ownership checks, atomicidad, y UX de confirmación.
- Siguiente: 4.4 Configuración de agentes (`/agentes`), 4.5 Telegram Bot con LLM.

---

## Sesión: Etapa 4.4 — Configuración de agentes (/agentes) — 2026-03-11

**Branch:** `claude/qautiva-stage-4-setup-eoNpb`
**Tarea:** Implementar la sección de configuración de agentes IA + revisión 6-roles + fixes.

### Implementado

**Archivos nuevos (10 archivos, +776 líneas):**
- `lib/agent-defaults.ts` — Única fuente de verdad para los 6 agentes (nombre, descripción, automationLevel, prompt default, stats)
- `components/AutomationToggle.tsx` — Toggle 3 estados (Manual/Semi-auto/Auto) con pill de color; fallback explícito para valores inválidos de DB
- `components/AgentCard.tsx` — Tarjeta de agente con stats, toggle read-only y link a `/agentes/[id]`
- `components/AgentPerformanceChart.tsx` — Recharts BarChart (aprobados vs rechazados por mes), `'use client'`
- `components/forms/UpdateAgentForm.tsx` — Textarea controlada con contador 0/10000, toggle interactivo, feedback éxito/error, cleanup de timer
- `apps/admin/app/(protected)/agentes/page.tsx` — Grid 3×2 con merge DB + defaults, `force-dynamic`
- `apps/admin/app/(protected)/agentes/[id]/page.tsx` — Detalle: form + BarChart + tabla últimos 10 entregables; generateMetadata sin doble fetch
- `lib/actions.ts` — `updateAgentConfig` Server Action: upsert por agentNumber, validación post-trim, revalidatePath con pattern 'page'
- `package.json` — `recharts: ^2.12.0` agregado al admin

### Revisión 6-roles (post-implementación) + Fixes aplicados

| Hallazgo | Severidad | Fix |
|----------|-----------|-----|
| name/description aceptados del FormData sin validar | CRÍTICO | Removidos del FormData; hardcoded desde `lib/agent-defaults.ts` en el servidor |
| Double fetch de agente en generateMetadata + page | CRÍTICO | generateMetadata usa datos estáticos para defaults, select minimal para UUID |
| AGENT_DEFAULTS duplicado en 2 archivos | ALTO | Extraído a `lib/agent-defaults.ts` (fuente única) |
| revalidatePath usaba número en lugar de pattern de ruta | ALTO | Cambiado a `revalidatePath('/agentes/[id]', 'page')` |
| Textarea con `defaultValue` no refleja estado actual | ALTO | Cambiado a textarea controlada con `useState` + contador |
| Validación de longitud antes del trim | ALTO | Validación ahora sobre `prompt.trim()` |
| Non-null assertion en AutomationToggle readOnly | MEDIO | Fallback explícito con badge gris |

**Build:** 14 rutas ✅ | commit `9e5fc08` en `claude/qautiva-stage-4-setup-eoNpb`

**Estado al cierre (sesión inicial):**
- Configuración de agentes 100% funcional con datos reales, upsert, validaciones, chart y tabla de entregables.
- Pendiente: hallazgos MEDIO de la revisión (locale fechas, tabla sin link, avgTime label) — no críticos.
- Siguiente: 4.5 Bot de Telegram con LLM (`services/telegram-bot/`).

### Revisión 6-roles formal (continuación de sesión) + Fix de tipo TS

Sesión continuada para cerrar la revisión formal completa con `docs/roles/`.

**Fixes adicionales aplicados:**
- `agentes/page.tsx`: fix tipo `configs` de `Awaited<ReturnType<findMany>>` → `AgentCardProps[]` (error de build TypeScript)
- `agentes/error.tsx` y `agentes/[id]/error.tsx`: creados (error boundaries por segmento)
- 6 reportes de revisión escritos en `docs/reviews/`
- `KNOWN_ISSUES.md`: entrada sobre prompt injection (riesgo aceptado por diseño)
- `schema.prisma`: `@@index([stageId, createdAt])` en Deliverable

**Build:** 14 rutas ✅ | commit `5b0a91e` en `claude/qautiva-stage-4-setup-eoNpb` | pushed ✅

**Estado al cierre:**
- Etapa 4.4 cerrada y pusheada. Revisión 6-roles 100% completada.
- Siguiente: 4.5 Bot de Telegram con LLM (`services/telegram-bot/`).

---

## Sesión: Marketplace Etapas 1.14–1.19 — 2026-03-12

**Branch:** `claude/marketplace-foundation-start-rLJIW`
**Tarea:** Sidebar marketplace, admin moderación/órdenes, RLS policies, tests, merge de main, revisión 6 roles.

### Implementado

**1.14 — Sidebar:**
- `apps/portal/components/ClientSidebar.tsx` — agrega items marketplace + SectionLabel + Configuración al final
- `apps/portal/components/ProjectSidebar.tsx` — ídem
- `apps/portal/app/(protected)/layout.tsx` — `getUserHasMedios()` con unstable_cache, pasa `hasMedios` al sidebar
- `apps/portal/app/proyectos/[id]/layout.tsx` — ídem para ProjectSidebar

**1.15 — Admin moderación de medios:**
- `apps/admin/app/(protected)/medios/page.tsx` — lista con 5 tabs de estado
- `apps/admin/app/(protected)/medios/[id]/page.tsx` — detalle completo con acciones
- `apps/admin/app/api/marketplace/media/[id]/route.ts` — PATCH approve/reject
- `apps/admin/lib/actions.ts` — `approveMedia()` y `rejectMedia()` Server Actions
- `apps/admin/components/forms/ApproveMediaForm.tsx` y `RejectMediaForm.tsx`

**1.16 — Admin órdenes:**
- `apps/admin/app/(protected)/ordenes/page.tsx` — lista con 7 tabs de estado
- `apps/admin/components/AdminSidebar.tsx` — ítem "Órdenes" agregado

**1.17 — RLS policies:**
- `packages/db/prisma/rls.sql` — políticas para 6 tablas marketplace, helper `get_user_profile_id()`

**1.18 — Tests:**
- `apps/admin/__tests__/api/marketplace/media-route.test.ts` — 9 casos PATCH handler
- `apps/admin/__tests__/actions/media-moderation.test.ts` — 14 casos Server Actions
- `apps/portal/__tests__/api/marketplace/orders.test.ts` — 19 casos POST + comisión
- `apps/portal/__tests__/api/marketplace/marketplace-helpers.test.ts` — 15 casos utils
- `vitest.config.ts` — alias `@prisma/client` y `@/lib/agent-defaults`

**1.19 — Revisión 6 roles:**
- `docs/reviews/2026-03-12_marketplace-etapa1-pre-deploy.md`
- **Resultado:** 0 críticos, 8 altos, 8 medios, 3 bajos

**Merge de main:**
- Integrado cambio `@prisma/client` → `./generated/client` en `packages/db/index.ts`
- Integrado `handleLogout` en `ClientSidebar.tsx`

### Archivos modificados
- `packages/db/index.ts`, `packages/db/prisma/rls.sql`
- `apps/portal/components/ClientSidebar.tsx`, `ProjectSidebar.tsx`
- `apps/portal/app/(protected)/layout.tsx`, `app/proyectos/[id]/layout.tsx`
- `apps/admin/lib/actions.ts`, `components/AdminSidebar.tsx`
- `vitest.config.ts`

### Pendiente (próxima sesión — fixes pre-deploy)

**ALTOs a corregir:**
1. Race condition doble-submit órdenes — unique constraint o $transaction
2. Race condition approve/reject medios — WHERE status en el update
3. RLS `mkt_media_update` — agregar WITH CHECK
4. Exposición de `commission`/`editorPayout` al anunciante
5. Paginación en admin medios y órdenes (take: 200)
6. Anunciante no puede cancelar orden PENDING
7. Cron para expirar órdenes vencidas
8. `expiresAt` faltante en listado de órdenes del admin

**Tests:** 203 ✅ | Build: pendiente verificar con generated/client

---

## Sesión 1.20 — Debug interview system + revisión 6 roles (2026-03-15)

**Branch:** `claude/debug-interview-system-XoTEe`
**Tarea:** Resolver sesiones de entrevista stuck/con error, agregar panel admin de sesiones, y revisión completa de 6 roles pre-deploy.

### Problema inicial

Sesión de entrevista quedó bloqueada en estado PROCESSING con Brief truncado (max_tokens). Sin visibilidad desde el admin ni forma de destrabarla. Cliente veía "En proceso" indefinidamente.

### Implementado

**1.20.1 — Correcciones base:**
- `apps/portal/app/_lib/interview/session-processor.ts` (**nuevo**) — lógica de processSession extraída como shared lib. Incluye transición a ERROR cuando se agotan reintentos.
- `apps/portal/app/_lib/interview/brief-generator.ts` — `max_tokens` subido de 1500 → 2048
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/BriefView.tsx` — optional chaining en todos los accesos anidados para soportar Brief truncado/parcial
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/ProcessingScreen.tsx` — fix stale closure `timedOut` con `useRef`; optimistic lock 2 min evita doble llamada a Anthropic

**1.20.2 — Admin endpoint de reprocesamiento:**
- `apps/portal/app/api/admin/sessions/[id]/process/route.ts` (**nuevo**) — POST autenticado con Supabase JWT (rol ADMIN). Acepta sesiones en PROCESSING o ERROR; resetea retryCount=0 para admin bypass.
- `apps/admin/app/actions/interview.ts` (**nuevo**) — Server Action `retryInterviewSession()` con UUID validation + Bearer token del admin hacia el portal

**1.20.3 — Panel admin de sesiones:**
- `apps/admin/app/(protected)/sesiones/page.tsx` (**nuevo**) — lista global de sesiones PROCESSING/ERROR con tiempo stuck, client info, lastError, retry inline
- `apps/admin/app/(protected)/sesiones/_components/RetrySessionButton.tsx` (**nuevo**) — botón con useTransition + confirmación antes de reprocesar
- `apps/admin/components/AdminSidebar.tsx` — ítem "Sesiones" con ícono AlertTriangle
- `apps/admin/components/tabs/EntrevistaTab.tsx` — banner amarillo para sesiones demoradas + retryButton
- `apps/portal/app/api/interview/sessions/[id]/route.ts` — `Cache-Control: no-store` header para evitar caché durante polling

**1.20.4 — Revisión 6 roles:**
- `docs/reviews/2026-03-15_code-review.md`
- `docs/reviews/2026-03-15_qa.md`
- `docs/reviews/2026-03-15_security.md`
- `docs/reviews/2026-03-15_performance.md`
- `docs/reviews/2026-03-15_devops.md`
- `docs/reviews/2026-03-15_product.md`

**Resultado de revisiones:**

| Rol | CRÍTICO | ALTO | MEDIO | BAJO |
|-----|---------|------|-------|------|
| Code Reviewer | 2 | 3 | 2 | 2 |
| QA Engineer | 1 | 2 | 2 | 1 |
| Security Auditor | 1 | 2 | 3 | 2 |
| Performance Engineer | 0 | 4 | 4 | 2 |
| DevOps / SRE | 3 | 4 | 4 | 3 |
| Product Reviewer | 2 | 5 | 5 | 4 |

Todos los CRÍTICO y ALTO corregidos.

**Fixes de revisiones aplicados:**
- Middleware: `isBearerAuthRoute` restringido a `/api/admin/` y `/api/cron/` — antes era bypass para cualquier ruta de API
- Cron: guard `!cronSecret ||` para prevenir `Bearer undefined` como token válido; serial loop de 3 sesiones (antes `Promise.allSettled(10)`)
- Schema: `@@index([status, processingStartedAt])` + migración 005
- Schema: campo `feedback Json?` en InterviewSession + migración 006
- Polling: `Cache-Control: no-store`
- `/process`: optimistic lock 2 min antes de llamar a Anthropic
- `apps/portal/.env.example`: `ANTHROPIC_API_KEY` y `CRON_SECRET` documentados
- `apps/admin/.env.example`: `PORTAL_URL` documentado
- `PORTAL_URL` sin fallback a producción — falla explícito si no configurado
- Health check: verifica `ANTHROPIC_API_KEY` presente
- FeedbackForm: conectado a `POST /api/interview/sessions/[id]/feedback` (DB) + localStorage backup
- `apps/portal/app/api/interview/sessions/[id]/feedback/route.ts` (**nuevo**)
- BriefView: `BriefRow` retorna null si el valor está vacío
- Sesiones admin: `STATUS_LABELS` map (enum inglés → español)
- ProcessingScreen: copy "1 a 3 minutos" → "hasta 5 minutos"

### Archivos modificados (resumen)

**Nuevos:**
- `apps/portal/app/_lib/interview/session-processor.ts`
- `apps/portal/app/api/admin/sessions/[id]/process/route.ts`
- `apps/portal/app/api/interview/sessions/[id]/feedback/route.ts`
- `apps/admin/app/(protected)/sesiones/page.tsx`
- `apps/admin/app/(protected)/sesiones/_components/RetrySessionButton.tsx`
- `apps/admin/app/actions/interview.ts`
- `packages/db/prisma/migrations/005_interview_session_status_index.sql`
- `packages/db/prisma/migrations/006_interview_session_feedback.sql`
- `docs/reviews/2026-03-15_*.md` (6 reportes)

**Modificados:**
- `apps/portal/app/_lib/interview/brief-generator.ts`
- `apps/portal/app/api/interview/sessions/[id]/route.ts`
- `apps/portal/app/api/interview/sessions/[id]/process/route.ts`
- `apps/portal/app/api/cron/recover-stuck-sessions/route.ts`
- `apps/portal/middleware.ts`
- `apps/portal/.env.example`
- `apps/portal/app/api/health/route.ts`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/BriefView.tsx`
- `apps/portal/app/proyectos/[id]/etapas/[stageId]/interview/_components/ProcessingScreen.tsx`
- `apps/admin/components/tabs/EntrevistaTab.tsx`
- `apps/admin/components/AdminSidebar.tsx`
- `apps/admin/.env.example`
- `apps/admin/lib/types.ts`
- `packages/db/prisma/schema.prisma`

### Pendiente

- ~~Ejecutar migración 005 y 006 en producción~~ ✅ Aplicadas
- Configurar `PORTAL_URL` en Vercel del admin (ya no tiene fallback a prod)
- `CRON_SECRET` en Vercel del portal (requerido para que el cron funcione)
- ~~Merge `claude/debug-interview-system-XoTEe` → main~~ ✅ PRs 69-74 mergeados

---

## Post-deploy: fixes de flujo self-service (2026-03-15, continuación sesión 1.20)

**Branch:** `claude/debug-interview-system-XoTEe`

### Contexto

Al testear en producción se detectaron dos bugs de diseño de flujo:
1. El Brief generado quedaba en `READY` — el cliente no lo veía porque la página de progreso solo muestra `SENT_TO_CLIENT`
2. El badge "Cola de revisión" en el sidebar admin era hardcodeado (constante `3`)

### Implementado

**1.20.A — Brief directo a SENT_TO_CLIENT:**
- `apps/portal/app/_lib/interview/session-processor.ts` — `status: 'READY'` → `status: 'SENT_TO_CLIENT'`
  — La plataforma es self-service: el cliente aprueba directamente sin intermediación admin.
  — La "Cola de revisión" del admin es para QA opcional, no para gate obligatorio.

**1.20.B — Badge dinámico en sidebar:**
- `apps/admin/components/AdminSidebar.tsx` — elimina `REVIEW_QUEUE_COUNT = 3` hardcodeado.
  Acepta `reviewQueueCount` como prop; oculta el badge cuando count es 0.
- `apps/admin/app/(protected)/layout.tsx` — convertido a `async`, hace `prisma.stage.count({ status: 'ADMIN_REVIEW' })` y pasa el resultado al sidebar.

### Fix manual en producción (Peluqueria Verde)

Para la sesión que ya tenía el Brief en `READY` antes del deploy, correr en Supabase:
```sql
UPDATE "Deliverable"
SET status = 'SENT_TO_CLIENT'
WHERE "stageId" = (SELECT id FROM "Stage" WHERE "projectId" = 'de731be8-9715-41e5-a2ec-fbeafd13d4cd' AND number = 1)
AND type = 'BRIEF' AND "isActive" = true;
```

---

## Sesión 1.21 — Cola de Diseños Stitch (2026-03-20)

**Branch:** `claude/stitch-design-queue-IXxiT`
**Plan:** `docs/plans/stitch-design-queue/PLAN.md`
**ADR:** `docs/decisions/ADR-0023-stitch-design-queue.md`

### Contexto

Implementación del sistema de cola para generación asíncrona de templates HTML con Google Stitch. Continuación de ADR-0022 (sesión 1.19, Stitch como fábrica de templates).

### Implementado

**Schema DB (migración 022):**
- Enum `TemplateQueueStatus` (QUEUED / GENERATING / DONE / ERROR)
- Enum `WebTemplateSource` (MANUAL / STITCH)
- Modelo `StitchAccount` — multi-cuenta con rastreo de cuota diaria
- Extensión de `WebTemplate` con campos de cola (todos nullable, compat. hacia atrás)

**Endpoints API (`apps/admin`):**
- `GET/POST /api/stitch/accounts` — gestión de cuentas con reset inline de cuota
- `GET/POST /api/stitch/queue` — listado y encolado de templates
- `POST /api/stitch/queue/factory` — encolado masivo por industrias × estilos
- `POST /api/stitch/queue/[id]/run` — ejecución manual de un job
- `POST /api/cron/reset-stitch-quota` — reset nocturno de cuotas

**UI admin (`apps/admin`):**
- Página `/templates/cola` — panel de cuentas + lista de jobs + factory
- Link en `AdminSidebar` para acceso directo

**Datos:**
- ~60 industrias en `packages/shared/src/industries.ts`
- 3 estilos predefinidos en `packages/shared/src/template-styles.ts`

### Decisiones (ver ADR-0023)
1. Sin Redis/BullMQ — cola sobre DB con cron existente
2. `queueStatus` nullable (compat. hacia atrás con templates manuales)
3. Multi-cuenta en tabla DB (no env vars)
4. Reset de cuotas inline + cron de respaldo

### Revisiones de calidad
- `docs/reviews/2026-03-20_code-review.md` ✅
- `docs/reviews/2026-03-20_security.md` ✅
- `docs/reviews/2026-03-20_devops.md` ✅ (señala migración faltante como bloqueante)
- `docs/reviews/2026-03-20_performance.md` ✅
- `docs/reviews/2026-03-20_qa.md` ✅
- `docs/reviews/2026-03-20_ux.md` ✅

### Known issues
- `selectBestAccount` no es atómica bajo concurrencia — documentado en `docs/KNOWN_ISSUES.md`
