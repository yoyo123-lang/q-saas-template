'use client'

import { useRef, useState, useEffect } from 'react'
import type { QuestionBlock } from '@/app/_lib/interview/types'
import { TextInput } from './inputs/TextInput'
import { TextareaInput } from './inputs/TextareaInput'
import { MultipleChoiceInput } from './inputs/MultipleChoiceInput'
import { MultiSelectInput } from './inputs/MultiSelectInput'
import { RatingInput } from './inputs/RatingInput'
import { FileUploadInput } from './inputs/FileUploadInput'
import { ColorPickerInput } from './inputs/ColorPickerInput'
import { BudgetRangeInput } from './inputs/BudgetRangeInput'
import { DateInput } from './inputs/DateInput'
import type { FileAnswer, BudgetAnswer } from './inputs/types'

// Re-exportados para backwards compat con otros módulos que los importen desde aquí
export type { FileAnswer, BudgetAnswer }

type Props = {
  question: QuestionBlock
  value: unknown
  onChange: (value: unknown) => void
  isSaving: boolean
}

/**
 * Renderiza una pregunta del interview con su input correspondiente.
 * Los inputs individuales están en ./inputs/ para facilitar el mantenimiento.
 */
export function QuestionCard({ question, value, onChange, isSaving }: Props) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 mb-6">
      {question.category && (
        <p className="text-[#8B5CF6] text-xs font-medium uppercase tracking-wide mb-3">
          {question.category}
        </p>
      )}

      <div className="flex items-start gap-3 mb-2">
        <h2 className="text-white text-lg font-medium flex-1 leading-snug">
          {question.question}
          {question.validation?.required !== false && !question.skippable && (
            <span className="text-[#EF4444] ml-1" aria-label="Obligatorio">*</span>
          )}
        </h2>
        {(question.helpText || question.context) && (
          <InlineHelpButton helpText={question.helpText} context={question.context} />
        )}
      </div>

      {question.context && (
        <p className="text-[#64748B] text-sm mb-4 leading-relaxed">{question.context}</p>
      )}

      <div className="mt-4">
        <InputRenderer question={question} value={value} onChange={onChange} disabled={isSaving} />
      </div>

      {isSaving && (
        <div className="flex items-center gap-1.5 mt-3 text-[#64748B] text-xs">
          <svg className="animate-spin" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="M21 12a9 9 0 1 1-6.219-8.56" />
          </svg>
          Guardando...
        </div>
      )}
    </div>
  )
}

// ── Botón de ayuda inline ─────────────────────────────────────────────────────

function InlineHelpButton({ helpText, context }: { helpText?: string; context?: string }) {
  const [open, setOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const text = helpText ?? context ?? ''

  useEffect(() => {
    if (!open) return
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setOpen(false)
    }
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    document.addEventListener('keydown', handleKeyDown)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleKeyDown)
    }
  }, [open])

  return (
    <div className="relative" ref={containerRef}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-6 h-6 rounded-full bg-[#1E293B] border border-[#334155] text-[#64748B] hover:text-[#94A3B8] hover:border-[#475569] transition-colors flex items-center justify-center flex-shrink-0 mt-0.5"
        aria-label={open ? 'Ocultar ayuda' : 'Ver ayuda'}
        aria-expanded={open}
      >
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
          <circle cx="12" cy="12" r="10" />
          <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" strokeLinecap="round" />
          <path d="M12 17h.01" strokeLinecap="round" />
        </svg>
      </button>
      {open && (
        <div className="absolute right-0 top-8 z-10 w-64 bg-[#1E293B] border border-[#334155] rounded-lg p-3 shadow-xl">
          <p className="text-[#94A3B8] text-sm leading-relaxed">{text}</p>
        </div>
      )}
    </div>
  )
}

// ── Dispatcher de inputs ──────────────────────────────────────────────────────

function InputRenderer({
  question,
  value,
  onChange,
  disabled,
}: {
  question: QuestionBlock
  value: unknown
  onChange: (v: unknown) => void
  disabled: boolean
}) {
  switch (question.inputType) {
    case 'text':
    case 'url_input':
      return (
        <TextInput
          value={typeof value === 'string' ? value : ''}
          onChange={onChange}
          placeholder={question.placeholder ?? ''}
          disabled={disabled}
          validation={question.validation}
          inputType={question.inputType === 'url_input' ? 'url' : 'text'}
        />
      )
    case 'textarea':
      return (
        <TextareaInput
          value={typeof value === 'string' ? value : ''}
          onChange={onChange}
          placeholder={question.placeholder ?? ''}
          disabled={disabled}
          validation={question.validation}
        />
      )
    case 'multiple_choice':
      return (
        <MultipleChoiceInput
          options={question.options ?? []}
          value={typeof value === 'string' ? value : ''}
          onChange={onChange}
          disabled={disabled}
        />
      )
    case 'multi_select':
      return (
        <MultiSelectInput
          options={question.options ?? []}
          value={Array.isArray(value) ? (value as string[]) : []}
          onChange={onChange}
          disabled={disabled}
        />
      )
    case 'rating':
      return (
        <RatingInput
          value={typeof value === 'number' ? value : null}
          onChange={onChange}
          min={question.validation?.min ?? 1}
          max={question.validation?.max ?? 5}
          options={question.options}
          disabled={disabled}
        />
      )
    case 'file_upload':
      return (
        <FileUploadInput
          value={value as FileAnswer | null}
          onChange={onChange}
          disabled={disabled}
          placeholder={question.placeholder}
        />
      )
    case 'color_picker':
      return (
        <ColorPickerInput
          value={typeof value === 'string' ? value : ''}
          onChange={onChange}
          disabled={disabled}
        />
      )
    case 'budget_range':
      return (
        <BudgetRangeInput
          value={value as BudgetAnswer | null}
          onChange={onChange}
          disabled={disabled}
          placeholder={question.placeholder}
        />
      )
    case 'date':
      return (
        <DateInput
          value={typeof value === 'string' ? value : ''}
          onChange={onChange}
          disabled={disabled}
          validation={question.validation}
        />
      )
    default:
      return (
        <div className="rounded-lg border border-[#334155] border-dashed px-4 py-3">
          <p className="text-[#64748B] text-sm">
            Tipo de input <code className="text-[#94A3B8]">{question.inputType}</code> no reconocido.
          </p>
        </div>
      )
  }
}
