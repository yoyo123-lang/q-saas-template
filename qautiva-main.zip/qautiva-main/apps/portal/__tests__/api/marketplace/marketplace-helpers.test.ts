import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── isValidHttpUrl y serializeOrder son funciones puras — se importan directamente ──

// getOrderPartiesOrError usa prisma y supabase — se mockean
const mockOrderFindUnique = vi.fn()

vi.mock('@qautiva/db', () => ({
  prisma: {
    order: { findUnique: mockOrderFindUnique },
    userProfile: { findUnique: vi.fn() },
  },
}))

vi.mock('@/lib/supabase-server', () => ({
  createServerClient: vi.fn(),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

// ── isValidHttpUrl ─────────────────────────────────────────────────────────────

describe('isValidHttpUrl', () => {
  it('acepta URL con protocolo http', async () => {
    const { isValidHttpUrl } = await import('../../../lib/api/marketplace-helpers')
    expect(isValidHttpUrl('http://ejemplo.com')).toBe(true)
  })

  it('acepta URL con protocolo https', async () => {
    const { isValidHttpUrl } = await import('../../../lib/api/marketplace-helpers')
    expect(isValidHttpUrl('https://ejemplo.com/path?q=1')).toBe(true)
  })

  it('rechaza URL con protocolo ftp', async () => {
    const { isValidHttpUrl } = await import('../../../lib/api/marketplace-helpers')
    expect(isValidHttpUrl('ftp://ejemplo.com')).toBe(false)
  })

  it('rechaza string que no es URL', async () => {
    const { isValidHttpUrl } = await import('../../../lib/api/marketplace-helpers')
    expect(isValidHttpUrl('no soy una url')).toBe(false)
  })

  it('rechaza string vacío', async () => {
    const { isValidHttpUrl } = await import('../../../lib/api/marketplace-helpers')
    expect(isValidHttpUrl('')).toBe(false)
  })

  it('rechaza URL sin protocolo', async () => {
    const { isValidHttpUrl } = await import('../../../lib/api/marketplace-helpers')
    expect(isValidHttpUrl('ejemplo.com')).toBe(false)
  })
})

// ── serializeOrder ─────────────────────────────────────────────────────────────

describe('serializeOrder', () => {
  function makeDecimal(value: number) {
    return { toNumber: () => value }
  }

  it('convierte los 3 campos Decimal a number', async () => {
    const { serializeOrder } = await import('../../../lib/api/marketplace-helpers')

    const order = {
      id: 'order-1',
      price: makeDecimal(100) as never,
      commission: makeDecimal(10) as never,
      editorPayout: makeDecimal(90) as never,
      status: 'PENDING',
    }

    const result = serializeOrder(order)

    expect(result.price).toBe(100)
    expect(result.commission).toBe(10)
    expect(result.editorPayout).toBe(90)
  })

  it('preserva el resto de los campos', async () => {
    const { serializeOrder } = await import('../../../lib/api/marketplace-helpers')

    const order = {
      id: 'order-42',
      status: 'ACCEPTED',
      brief: 'Mi brief',
      price: makeDecimal(200) as never,
      commission: makeDecimal(20) as never,
      editorPayout: makeDecimal(180) as never,
    }

    const result = serializeOrder(order)

    expect(result.id).toBe('order-42')
    expect(result.status).toBe('ACCEPTED')
    expect(result.brief).toBe('Mi brief')
  })

  it('calcula correctamente valores fraccionarios', async () => {
    const { serializeOrder } = await import('../../../lib/api/marketplace-helpers')

    const order = {
      price: makeDecimal(33) as never,
      commission: makeDecimal(3.3) as never,
      editorPayout: makeDecimal(29.7) as never,
    }

    const result = serializeOrder(order)

    expect(result.price).toBe(33)
    expect(result.commission).toBeCloseTo(3.3, 5)
    expect(result.editorPayout).toBeCloseTo(29.7, 5)
  })
})

// ── getOrderPartiesOrError ─────────────────────────────────────────────────────

describe('getOrderPartiesOrError', () => {
  beforeEach(() => {
    vi.resetModules()
    mockOrderFindUnique.mockReset()
  })

  it('devuelve error 404 si la orden no existe', async () => {
    mockOrderFindUnique.mockResolvedValueOnce(null)

    const { getOrderPartiesOrError } = await import('../../../lib/api/marketplace-helpers')
    const result = await getOrderPartiesOrError('order-1', 'profile-1')

    expect(result.error).toBe(true)
    if (result.error) {
      expect(result.response.status).toBe(404)
    }
  })

  it('devuelve error 403 si el perfil no es parte de la orden', async () => {
    mockOrderFindUnique.mockResolvedValueOnce({
      advertiserId: 'adv-1',
      status: 'PENDING',
      medium: { userId: 'editor-1' },
    })

    const { getOrderPartiesOrError } = await import('../../../lib/api/marketplace-helpers')
    const result = await getOrderPartiesOrError('order-1', 'stranger-profile')

    expect(result.error).toBe(true)
    if (result.error) {
      expect(result.response.status).toBe(403)
    }
  })

  it('devuelve parties si el perfil es el anunciante', async () => {
    mockOrderFindUnique.mockResolvedValueOnce({
      advertiserId: 'adv-1',
      status: 'PENDING',
      medium: { userId: 'editor-1' },
    })

    const { getOrderPartiesOrError } = await import('../../../lib/api/marketplace-helpers')
    const result = await getOrderPartiesOrError('order-1', 'adv-1')

    expect(result.error).toBe(false)
    if (!result.error) {
      expect(result.parties.advertiserId).toBe('adv-1')
      expect(result.parties.mediumUserId).toBe('editor-1')
      expect(result.parties.status).toBe('PENDING')
    }
  })

  it('devuelve parties si el perfil es el editor del medio', async () => {
    mockOrderFindUnique.mockResolvedValueOnce({
      advertiserId: 'adv-1',
      status: 'ACCEPTED',
      medium: { userId: 'editor-1' },
    })

    const { getOrderPartiesOrError } = await import('../../../lib/api/marketplace-helpers')
    const result = await getOrderPartiesOrError('order-1', 'editor-1')

    expect(result.error).toBe(false)
    if (!result.error) {
      expect(result.parties.mediumUserId).toBe('editor-1')
      expect(result.parties.status).toBe('ACCEPTED')
    }
  })
})
