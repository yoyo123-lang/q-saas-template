import { cn } from '@/lib/utils/cn'

interface CardProps {
  children: React.ReactNode
  className?: string
  hover?: boolean
  padding?: 'sm' | 'md' | 'lg'
  border?: 'default' | 'amber'
}

const paddingClasses = {
  sm: 'p-4',
  md: 'p-5',
  lg: 'p-8',
}

export function Card({
  children,
  className,
  hover = false,
  padding = 'md',
  border = 'default',
}: CardProps) {
  return (
    <div
      className={cn(
        'bg-navy-900 border rounded-xl',
        border === 'default' ? 'border-slate-800' : 'border-amber-500/20',
        paddingClasses[padding],
        hover &&
          'transition-all duration-200 hover:border-amber-500/30 hover:shadow-lg hover:shadow-amber-500/5',
        className
      )}
    >
      {children}
    </div>
  )
}
