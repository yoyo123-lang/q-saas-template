import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import type { DeliverableStatus } from '@qautiva/db'
import { DeliverableCard } from '@/components/DeliverableCard'

export const metadata: Metadata = { title: 'Entregables — Qautiva' }

type FilterTab = 'todos' | 'pendientes' | 'completados'

const VALID_FILTERS: FilterTab[] = ['todos', 'pendientes', 'completados']

const TABS: { id: FilterTab; label: string }[] = [
  { id: 'todos', label: 'Todos' },
  { id: 'pendientes', label: 'Pendientes' },
  { id: 'completados', label: 'Completados' },
]

const PENDING_STATUSES: DeliverableStatus[] = ['SENT_TO_CLIENT', 'REVISION_REQUESTED']
const COMPLETED_STATUSES: DeliverableStatus[] = ['CLIENT_APPROVED']

type SearchParams = { filtro?: string }

export default async function EntregablesPage({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const activeFilter: FilterTab =
    VALID_FILTERS.includes(searchParams.filtro as FilterTab)
      ? (searchParams.filtro as FilterTab)
      : 'todos'

  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  const orgId = user?.app_metadata?.org_id as string | undefined

  if (!orgId) {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white mb-4">Entregables</h1>
        <p className="text-[#94A3B8]">No hay un proyecto asignado a tu cuenta.</p>
      </div>
    )
  }

  const whereStatus =
    activeFilter === 'pendientes'
      ? { status: { in: PENDING_STATUSES } }
      : activeFilter === 'completados'
        ? { status: { in: COMPLETED_STATUSES } }
        : {}

  const deliverables = await prisma.deliverable.findMany({
    where: { organizationId: orgId, ...whereStatus },
    orderBy: { updatedAt: 'desc' },
    select: {
      id: true,
      title: true,
      type: true,
      status: true,
      updatedAt: true,
    },
  })

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold text-white mb-6">Entregables</h1>

      {/* Filtros */}
      <div className="flex gap-1 bg-[#0F172A] border border-[#1E293B] rounded-lg p-1 mb-6 w-fit">
        {TABS.map((tab) => (
          <a
            key={tab.id}
            href={tab.id === 'todos' ? '/entregables' : `/entregables?filtro=${tab.id}`}
            className={`
              px-4 py-1.5 rounded-md text-sm font-medium transition-colors duration-200
              ${activeFilter === tab.id
                ? 'bg-[#8B5CF6] text-white'
                : 'text-[#94A3B8] hover:text-white'
              }
            `}
          >
            {tab.label}
          </a>
        ))}
      </div>

      {/* Lista */}
      {deliverables.length > 0 ? (
        <div className="flex flex-col gap-3">
          {deliverables.map((d) => (
            <DeliverableCard
              key={d.id}
              id={d.id}
              title={d.title}
              type={d.type}
              status={d.status}
              updatedAt={d.updatedAt}
            />
          ))}
        </div>
      ) : (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#94A3B8]">
            {activeFilter === 'pendientes'
              ? 'No tenés entregables pendientes de revisión.'
              : activeFilter === 'completados'
                ? 'Todavía no aprobaste ningún entregable.'
                : 'Tus entregables aparecen acá cuando estén listos.'}
          </p>
        </div>
      )}
    </div>
  )
}
