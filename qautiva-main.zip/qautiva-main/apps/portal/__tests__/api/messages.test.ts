import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

const mockGetUser = vi.fn()
const mockCreate = vi.fn()

vi.mock('@supabase/ssr', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
}))

vi.mock('next/headers', () => ({
  cookies: vi.fn().mockReturnValue({ getAll: () => [] }),
}))

vi.mock('@qautiva/db', () => ({
  createServerClient: vi.fn().mockReturnValue({
    auth: { getUser: mockGetUser },
  }),
  prisma: {
    message: { create: mockCreate },
  },
}))

function makeRequest(body: unknown): NextRequest {
  return new NextRequest('http://localhost:3001/api/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

describe('POST /api/messages', () => {
  beforeEach(() => {
    vi.resetModules()
    mockGetUser.mockReset()
    mockCreate.mockReset()
  })

  it('devuelve 401 si no hay usuario autenticado', async () => {
    mockGetUser.mockResolvedValueOnce({ data: { user: null } })

    const { POST } = await import('../../app/api/messages/route')
    const res = await POST(makeRequest({ content: 'Hola' }))

    expect(res.status).toBe(401)
  })

  it('devuelve 403 si el usuario no tiene org', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: {} } },
    })

    const { POST } = await import('../../app/api/messages/route')
    const res = await POST(makeRequest({ content: 'Hola' }))

    expect(res.status).toBe(403)
  })

  it('devuelve 400 si el mensaje está vacío', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })

    const { POST } = await import('../../app/api/messages/route')
    const res = await POST(makeRequest({ content: '   ' }))

    expect(res.status).toBe(400)
  })

  it('devuelve 400 si el mensaje es demasiado largo', async () => {
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })

    const { POST } = await import('../../app/api/messages/route')
    const res = await POST(makeRequest({ content: 'a'.repeat(2001) }))

    expect(res.status).toBe(400)
  })

  it('guarda el mensaje correctamente', async () => {
    const mockMessage = {
      id: 'msg-1',
      content: 'Hola',
      sender: 'CLIENT',
      channel: 'WEB',
      createdAt: new Date(),
    }
    mockGetUser.mockResolvedValueOnce({
      data: { user: { id: 'user-1', app_metadata: { org_id: 'org-1' } } },
    })
    mockCreate.mockResolvedValueOnce(mockMessage)

    const { POST } = await import('../../app/api/messages/route')
    const res = await POST(makeRequest({ content: 'Hola' }))
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          organizationId: 'org-1',
          sender: 'CLIENT',
          channel: 'WEB',
          content: 'Hola',
        }),
      }),
    )
  })
})
