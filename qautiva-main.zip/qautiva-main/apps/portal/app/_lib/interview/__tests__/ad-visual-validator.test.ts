/**
 * Tests de ad-visual-validator.ts
 *
 * Cubre: validación exitosa con scores, degradación si la API de validación falla,
 * máximo MAX_REGENERATIONS piezas para regenerar, applyValidationScores.
 * Mocks: Anthropic, fetch (descarga de imágenes), ai-config, registerAiUsage.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { AdVisuals, AdVisual } from '../types'

// ── Fixtures ──────────────────────────────────────────────────────────────────

const VALID_PNG_BYTES = new Uint8Array([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
])

function makeVisual(format: string, angle: string): AdVisual {
  return {
    format: format as AdVisual['format'],
    aspectRatio: '1:1',
    resolution: '1080x1080',
    imageUrl: `https://supabase.io/signed/${format}-${angle}.png`,
    angle,
    generatedAt: new Date().toISOString(),
    attempt: 1,
  }
}

const SAMPLE_VISUALS: AdVisuals = {
  visuals: [
    makeVisual('feed_square', 'hero shot'),
    makeVisual('feed_square', 'lifestyle'),
    makeVisual('feed_portrait', 'hero shot'),
    makeVisual('feed_portrait', 'lifestyle'),
    makeVisual('story', 'hero shot'),
    makeVisual('story', 'lifestyle'),
  ],
  brandContext: {
    dominantColors: ['#1a1a2e', '#16213e'],
    style: 'profesional y directo',
    logoUsed: false,
  },
  disclaimer: 'Piezas generadas por IA.',
}

const HIGH_SCORES_RESPONSE = JSON.stringify({
  scores: [
    { visualId: 'feed_square-hero shot', relevancia: 80, calidadTecnica: 85, coherenciaMarca: 78, composicion: 82, legibilidadTexto: 90, observaciones: 'Muy buena composición.' },
    { visualId: 'feed_square-lifestyle', relevancia: 75, calidadTecnica: 80, coherenciaMarca: 72, composicion: 78, legibilidadTexto: 88, observaciones: 'Estilo adecuado.' },
    { visualId: 'feed_portrait-hero shot', relevancia: 70, calidadTecnica: 75, coherenciaMarca: 68, composicion: 73, legibilidadTexto: 85, observaciones: 'Aceptable.' },
  ],
})

const LOW_SCORES_RESPONSE = JSON.stringify({
  scores: [
    { visualId: 'feed_square-hero shot', relevancia: 40, calidadTecnica: 45, coherenciaMarca: 38, composicion: 42, legibilidadTexto: 50, observaciones: 'Baja calidad visual.' },
    { visualId: 'feed_square-lifestyle', relevancia: 35, calidadTecnica: 40, coherenciaMarca: 33, composicion: 38, legibilidadTexto: 45, observaciones: 'Muy mejorable.' },
    { visualId: 'feed_portrait-hero shot', relevancia: 72, calidadTecnica: 80, coherenciaMarca: 70, composicion: 75, legibilidadTexto: 88, observaciones: 'Correcta.' },
  ],
})

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockAnthropicCreate = vi.fn()
const mockFetch = vi.fn()

vi.mock('@anthropic-ai/sdk', () => ({
  default: class MockAnthropic {
    messages = { create: mockAnthropicCreate }
  },
}))

vi.mock('../ai-config', () => ({
  getAiConfig: async () => ({ provider: 'ANTHROPIC' }),
}))

vi.mock('../billing/register-ai-usage', () => ({
  registerAiUsage: vi.fn(),
}))

// Mock global fetch para descarga de imágenes
vi.stubGlobal('fetch', mockFetch)

// ── Helpers ───────────────────────────────────────────────────────────────────

function setupFetchSuccess() {
  mockFetch.mockResolvedValue({
    ok: true,
    arrayBuffer: async () => VALID_PNG_BYTES.buffer,
  })
}

function setupAnthropicSuccess(responseText: string) {
  mockAnthropicCreate.mockResolvedValue({
    content: [{ type: 'text', text: responseText }],
    usage: { input_tokens: 500, output_tokens: 200 },
  })
}

// ── Tests: validateAdVisuals ──────────────────────────────────────────────────

describe('validateAdVisuals', () => {
  beforeEach(() => vi.clearAllMocks())

  it('devuelve validationFailed=false con scores cuando todo funciona', async () => {
    setupFetchSuccess()
    setupAnthropicSuccess(HIGH_SCORES_RESPONSE)
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    expect(result.validationFailed).toBe(false)
    expect(result.scores.length).toBeGreaterThan(0)
  })

  it('marca piezas como aprobadas si score promedio >= 60', async () => {
    setupFetchSuccess()
    setupAnthropicSuccess(HIGH_SCORES_RESPONSE)
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    const allApproved = result.scores.every((s) => s.aprobada)
    expect(allApproved).toBe(true)
    expect(result.toRegenerate).toHaveLength(0)
  })

  it('marca piezas para regenerar si score promedio < 60', async () => {
    setupFetchSuccess()
    // Batch 1: 2 piezas con score bajo, 1 con score alto
    setupAnthropicSuccess(LOW_SCORES_RESPONSE)
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    expect(result.toRegenerate.length).toBeGreaterThan(0)
    // Las dos piezas con score < 60 deben ser marcadas
    expect(result.toRegenerate).toContain('feed_square-hero shot')
    expect(result.toRegenerate).toContain('feed_square-lifestyle')
  })

  it('no marca más de MAX_REGENERATIONS piezas (máx 2)', async () => {
    setupFetchSuccess()
    // Todas con score bajo — pero solo 2 deben marcarse
    const allLowResponse = JSON.stringify({
      scores: [
        { relevancia: 30, calidadTecnica: 30, coherenciaMarca: 30, composicion: 30, legibilidadTexto: 30, observaciones: 'Muy mal.' },
        { relevancia: 25, calidadTecnica: 25, coherenciaMarca: 25, composicion: 25, legibilidadTexto: 25, observaciones: 'Pésimo.' },
        { relevancia: 35, calidadTecnica: 35, coherenciaMarca: 35, composicion: 35, legibilidadTexto: 35, observaciones: 'Malo.' },
      ],
    })
    setupAnthropicSuccess(allLowResponse)
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    expect(result.toRegenerate.length).toBeLessThanOrEqual(2)
  })

  it('devuelve validationFailed=true si la llamada a Anthropic falla', async () => {
    setupFetchSuccess()
    mockAnthropicCreate.mockRejectedValue(new Error('Anthropic API down'))
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    expect(result.validationFailed).toBe(true)
    expect(result.toRegenerate).toHaveLength(0)
  })

  it('devuelve validationFailed=true si no se puede descargar ninguna imagen', async () => {
    mockFetch.mockResolvedValue({ ok: false, status: 404 })
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    expect(result.validationFailed).toBe(true)
  })

  it('retorna scores neutrales para imágenes que no se pudieron descargar', async () => {
    // Primera imagen falla, el resto tiene éxito
    let callCount = 0
    mockFetch.mockImplementation(async () => {
      callCount++
      if (callCount === 1) return { ok: false, status: 500 }
      return { ok: true, arrayBuffer: async () => VALID_PNG_BYTES.buffer }
    })
    setupAnthropicSuccess(HIGH_SCORES_RESPONSE)
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(SAMPLE_VISUALS)
    // La pieza que falló al descargar debe tener score neutral
    const neutralScore = result.scores.find((s) => s.scorePromedio === 70 && s.observaciones.includes('neutral'))
    expect(neutralScore).toBeDefined()
  })

  it('devuelve vacío si no hay visuals', async () => {
    const emptyVisuals: AdVisuals = { ...SAMPLE_VISUALS, visuals: [] }
    const { validateAdVisuals } = await import('../ad-visual-validator')
    const result = await validateAdVisuals(emptyVisuals)
    expect(result.scores).toHaveLength(0)
    expect(result.validationFailed).toBe(false)
  })
})

// ── Tests: applyValidationScores ──────────────────────────────────────────────

describe('applyValidationScores', () => {
  it('agrega validationScore a cada visual que tiene score', async () => {
    const { applyValidationScores } = await import('../ad-visual-validator')
    const result = applyValidationScores(SAMPLE_VISUALS.visuals, {
      scores: [
        {
          visualId: 'feed_square-hero shot',
          scores: { relevancia: 80, calidadTecnica: 80, coherenciaMarca: 80, composicion: 80, legibilidadTexto: 80 },
          scorePromedio: 80,
          observaciones: 'Excelente.',
          aprobada: true,
        },
      ],
      toRegenerate: [],
      validationFailed: false,
    })
    const scored = result.find((v) => v.format === 'feed_square' && v.angle === 'hero shot')
    expect(scored?.validationScore).toBe(80)
  })

  it('no modifica visuals si validationFailed=true', async () => {
    const { applyValidationScores } = await import('../ad-visual-validator')
    const result = applyValidationScores(SAMPLE_VISUALS.visuals, {
      scores: [],
      toRegenerate: [],
      validationFailed: true,
    })
    expect(result).toBe(SAMPLE_VISUALS.visuals) // misma referencia
  })

  it('no asigna score a visuals sin matching score', async () => {
    const { applyValidationScores } = await import('../ad-visual-validator')
    const result = applyValidationScores(SAMPLE_VISUALS.visuals, {
      scores: [],
      toRegenerate: [],
      validationFailed: false,
    })
    expect(result.every((v) => v.validationScore === undefined)).toBe(true)
  })
})
