/**
 * Genera leads comerciales cuando un usuario responde "me_interesa"
 * a preguntas de servicios Q (Qontacta, Qobra) en la entrevista web v2.
 *
 * Responsabilidades:
 * 1. Detectar si una respuesta genera un lead comercial
 * 2. Deduplicar: no generar el mismo lead dos veces por sesión
 * 3. Notificar al equipo comercial vía Telegram (fire-and-forget)
 * 4. Almacenar el lead en la sesión para seguimiento desde admin
 *
 * @see ADR-0018 — Leads comerciales
 */

/** Mapeo de questionId → servicio Q para leads */
const LEAD_QUESTION_MAP: Record<string, { service: string; label: string }> = {
  web_agenda: { service: 'qontacta', label: 'Qontacta (agenda/CRM)' },
  web_pagos: { service: 'qobra', label: 'Qobra (pagos online)' },
}

/**
 * Determina si una respuesta a una pregunta genera un lead comercial.
 * Solo "me_interesa" genera lead — "si" activa la sección, "no" no hace nada.
 */
export function isCommercialLeadAnswer(questionId: string, answer: unknown): boolean {
  return questionId in LEAD_QUESTION_MAP && answer === 'me_interesa'
}

/**
 * Extrae el service key de un lead comercial a partir de la pregunta.
 * Retorna null si la pregunta no genera lead.
 */
export function getLeadServiceKey(questionId: string): string | null {
  return LEAD_QUESTION_MAP[questionId]?.service ?? null
}

export type CommercialLead = {
  service: string
  label: string
  questionId: string
  createdAt: string
}

/**
 * Construye un lead comercial y lo agrega al array existente.
 * Es idempotente: si el lead ya existe para este servicio, retorna null (sin cambios).
 *
 * @param questionId - ID de la pregunta respondida con "me_interesa"
 * @param existingLeads - Leads ya registrados en la sesión (para deduplicación)
 * @returns Array actualizado de leads, o null si el lead ya existía
 */
export function buildCommercialLead(
  questionId: string,
  existingLeads: CommercialLead[],
): CommercialLead[] | null {
  const mapping = LEAD_QUESTION_MAP[questionId]
  if (!mapping) return null

  // Deduplicación: si ya existe un lead para este servicio, no crear otro
  if (existingLeads.some((l) => l.service === mapping.service)) return null

  const newLead: CommercialLead = {
    service: mapping.service,
    label: mapping.label,
    questionId,
    createdAt: new Date().toISOString(),
  }

  return [...existingLeads, newLead]
}

/**
 * Envía notificación al equipo comercial vía Telegram.
 * Fire-and-forget: no bloquea la respuesta al usuario.
 *
 * @param lead - Datos del lead
 * @param projectName - Nombre del proyecto (para contexto)
 * @param sessionId - ID de la sesión (para referencia)
 */
export async function notifyCommercialLeadTelegram(params: {
  service: string
  label: string
  projectId: string
  sessionId: string
}): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN
  const chatId = process.env.TELEGRAM_LEADS_CHAT_ID ?? process.env.TELEGRAM_CHAT_ID

  if (!token || !chatId) {
    console.warn('[commercial-leads] TELEGRAM_BOT_TOKEN o TELEGRAM_LEADS_CHAT_ID no configurados — lead no notificado')
    return
  }

  const text = [
    '🔔 *Nuevo lead comercial — Entrevista Web*',
    '',
    `🛒 Servicio: ${params.label}`,
    `📋 Proyecto: \`${params.projectId}\``,
    `🆔 Sesión: \`${params.sessionId}\``,
    '',
    'El cliente respondió "Me interesa saber más" durante la entrevista web.',
  ].join('\n')

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'Markdown' }),
      signal: AbortSignal.timeout(5000),
    })
    if (!res.ok) {
      console.error('[commercial-leads] Error al notificar Telegram', { status: res.status })
    }
  } catch (err) {
    // No bloquear la respuesta al usuario si Telegram falla
    console.error('[commercial-leads] Timeout o error de red al notificar Telegram', err)
  }
}
