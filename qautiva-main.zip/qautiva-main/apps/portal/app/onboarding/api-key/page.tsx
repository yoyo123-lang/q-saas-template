import { prisma } from '@qautiva/db'
import ApiKeyClient from './client'

export const dynamic = 'force-dynamic'

export default async function ApiKeyPage() {
  // Leer TrialConfig (singleton id=1)
  const trialConfig = await prisma.trialConfig.findUnique({ where: { id: 1 } })

  const isTrialActive = Boolean(
    trialConfig?.isActive &&
    (!trialConfig.validFrom || trialConfig.validFrom <= new Date()) &&
    (!trialConfig.validUntil || trialConfig.validUntil >= new Date()),
  )
  const trialTokenAmount = trialConfig?.tokenAmount ?? 50000

  return <ApiKeyClient isTrialActive={isTrialActive} trialTokenAmount={trialTokenAmount} />
}
