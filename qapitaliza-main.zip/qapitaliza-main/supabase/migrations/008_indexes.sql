-- ============================================================
-- 008 — Indexes
-- Índices de performance para las queries más frecuentes.
-- Rollback: 008_indexes_rollback.sql
-- ============================================================

-- profiles
CREATE INDEX idx_profiles_role        ON public.profiles(role);

-- categories
CREATE INDEX idx_categories_slug      ON public.categories(slug);
CREATE INDEX idx_categories_parent    ON public.categories(parent_id);

-- listings — queries del catálogo público
CREATE INDEX idx_listings_status           ON public.listings(status);
CREATE INDEX idx_listings_type             ON public.listings(type);
CREATE INDEX idx_listings_seller           ON public.listings(seller_id);
CREATE INDEX idx_listings_category         ON public.listings(category_id);
CREATE INDEX idx_listings_published_at     ON public.listings(published_at DESC);
CREATE INDEX idx_listings_asking_price     ON public.listings(asking_price);
CREATE INDEX idx_listings_view_count       ON public.listings(view_count DESC);
CREATE INDEX idx_listings_featured         ON public.listings(featured_until) WHERE featured_until IS NOT NULL;

-- Índice compuesto: el más usado (catálogo público filtrado)
CREATE INDEX idx_listings_status_type      ON public.listings(status, type);
CREATE INDEX idx_listings_status_published ON public.listings(status, published_at DESC)
  WHERE status = 'PUBLISHED';

-- Búsqueda de texto en título y descripción
CREATE INDEX idx_listings_fts ON public.listings
  USING GIN (to_tsvector('spanish', coalesce(title, '') || ' ' || coalesce(description, '')));

-- Tech stack array search
CREATE INDEX idx_listings_tech_stack ON public.listings USING GIN(tech_stack);
CREATE INDEX idx_listings_tags       ON public.listings USING GIN(tags);

-- listing_metrics
CREATE INDEX idx_listing_metrics_listing  ON public.listing_metrics(listing_id);
CREATE INDEX idx_listing_metrics_type     ON public.listing_metrics(listing_id, metric_type);

-- inquiries
CREATE INDEX idx_inquiries_listing    ON public.inquiries(listing_id);
CREATE INDEX idx_inquiries_buyer      ON public.inquiries(buyer_id);
CREATE INDEX idx_inquiries_status     ON public.inquiries(status);
CREATE INDEX idx_inquiries_updated    ON public.inquiries(updated_at DESC);

-- inquiry_messages
CREATE INDEX idx_inquiry_messages_inquiry   ON public.inquiry_messages(inquiry_id);
CREATE INDEX idx_inquiry_messages_sender    ON public.inquiry_messages(sender_id);
CREATE INDEX idx_inquiry_messages_created   ON public.inquiry_messages(inquiry_id, created_at ASC);

-- favorites
CREATE INDEX idx_favorites_user     ON public.favorites(user_id);
CREATE INDEX idx_favorites_listing  ON public.favorites(listing_id);

-- audit_log
CREATE INDEX idx_audit_log_actor      ON public.audit_log(actor_id);
CREATE INDEX idx_audit_log_action     ON public.audit_log(action);
CREATE INDEX idx_audit_log_entity     ON public.audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_log_created    ON public.audit_log(created_at DESC);
