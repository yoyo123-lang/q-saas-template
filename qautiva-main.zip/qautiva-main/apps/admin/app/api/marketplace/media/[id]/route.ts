import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import type { MediumStatus } from '@qautiva/db'

interface PatchBody {
  action: 'approve' | 'reject'
  reason?: string
}

const TRANSITION: Record<string, MediumStatus> = {
  approve: 'ACTIVE',
  reject:  'REJECTED',
}

/**
 * PATCH /api/marketplace/media/[id]
 * Body: { action: 'approve' | 'reject', reason?: string }
 * Requiere sesión de admin.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } },
): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: PatchBody
  try {
    body = (await req.json()) as PatchBody
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { action, reason } = body
  if (action !== 'approve' && action !== 'reject') {
    return NextResponse.json({ error: 'action debe ser "approve" o "reject"' }, { status: 400 })
  }
  if (action === 'reject' && (!reason || !reason.trim())) {
    return NextResponse.json({ error: 'reason requerido para reject' }, { status: 400 })
  }
  if (action === 'reject' && reason && reason.trim().length > 1000) {
    return NextResponse.json({ error: 'reason no puede superar los 1000 caracteres' }, { status: 400 })
  }

  const medium = await prisma.medium.findUnique({
    where: { id: params.id, deletedAt: null },
    select: { id: true, status: true, name: true },
  })
  if (!medium) {
    return NextResponse.json({ error: 'Medio no encontrado' }, { status: 404 })
  }
  if (medium.status !== 'PENDING_REVIEW') {
    return NextResponse.json(
      { error: 'El medio ya no está pendiente de revisión' },
      { status: 409 },
    )
  }

  const newStatus = TRANSITION[action]
  try {
    // Optimistic lock: incluir status=PENDING_REVIEW en el WHERE previene que dos admins
    // procesen el mismo medio simultáneamente (el segundo recibirá P2025 → 409).
    await prisma.medium.update({
      where: { id: medium.id, status: 'PENDING_REVIEW' },
      data: {
        status: newStatus,
        ...(action === 'reject' ? { rejectionReason: reason!.trim() } : {}),
      },
    })
  } catch (err) {
    if (
      err instanceof Error &&
      'code' in err &&
      (err as { code: string }).code === 'P2025'
    ) {
      return NextResponse.json(
        { error: 'El medio ya fue procesado por otro admin' },
        { status: 409 },
      )
    }
    throw err
  }

  console.info(`[admin:api] medio ${action}d — mediumId=${medium.id} name="${medium.name}"`)
  return NextResponse.json({ ok: true, status: newStatus })
}
