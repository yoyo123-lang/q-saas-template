'use client'

import Link from 'next/link'
import { useState } from 'react'
import { deleteWebTemplate, duplicateWebTemplate, publishWebTemplate } from './actions'
import type { ActionState } from './actions'

interface TemplateRowActionsProps {
  id: string
  name: string
  status: 'DRAFT' | 'ACTIVE'
  usageCount: number
}

function DeleteButton({ id, name, usageCount }: { id: string; name: string; usageCount: number }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)
  const disabled = usageCount > 0 || isPending

  async function handleSubmit(formData: FormData) {
    if (!confirm(`¿Eliminar el template "${name}"? Esta acción no se puede deshacer.`)) return
    setIsPending(true)
    try {
      const result = await deleteWebTemplate(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="inline">
      <input type="hidden" name="id" value={id} />
      {state && !state.ok && (
        <span className="text-xs text-red-400 mr-2">{state.error}</span>
      )}
      <button
        type="submit"
        disabled={disabled}
        title={
          usageCount > 0
            ? `Tiene ${usageCount} uso(s) activo(s)`
            : isPending
            ? 'Eliminando...'
            : 'Eliminar template'
        }
        className="px-2 py-1 text-xs text-red-400 border border-red-400/30 rounded hover:bg-red-400/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
      >
        {isPending ? '...' : 'Eliminar'}
      </button>
    </form>
  )
}

function DuplicateButton({ id }: { id: string }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await duplicateWebTemplate(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="inline">
      <input type="hidden" name="id" value={id} />
      {state && !state.ok && (
        <span className="text-xs text-red-400 mr-2">{state.error}</span>
      )}
      {state?.ok && (
        <span className="text-xs text-green-400 mr-2">Duplicado</span>
      )}
      <button
        type="submit"
        disabled={isPending}
        className="px-2 py-1 text-xs text-[#94A3B8] border border-[#1E293B] rounded hover:text-white hover:border-[#334155] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {isPending ? '...' : 'Duplicar'}
      </button>
    </form>
  )
}

function PublishButton({ id }: { id: string }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await publishWebTemplate(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <form action={handleSubmit} className="inline">
      <input type="hidden" name="id" value={id} />
      {state && !state.ok && (
        <span className="text-xs text-red-400 mr-2">{state.error}</span>
      )}
      <button
        type="submit"
        disabled={isPending}
        className="px-2 py-1 text-xs text-green-400 border border-green-400/30 rounded hover:bg-green-400/10 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {isPending ? '...' : 'Publicar'}
      </button>
    </form>
  )
}

export function TemplateRowActions({ id, name, status, usageCount }: TemplateRowActionsProps) {
  return (
    <div className="flex items-center justify-end gap-2">
      <Link
        href={`/api/templates/${id}/preview`}
        target="_blank"
        rel="noopener noreferrer"
        className="px-2 py-1 text-xs text-[#64748B] border border-[#1E293B] rounded hover:text-white hover:border-[#334155] transition-colors"
      >
        Preview
      </Link>
      <Link
        href={`/templates/${id}`}
        className="px-2 py-1 text-xs text-[#8B5CF6] border border-[#8B5CF6]/30 rounded hover:bg-[#8B5CF6]/10 transition-colors"
      >
        Editar
      </Link>
      {status === 'DRAFT' && <PublishButton id={id} />}
      <DuplicateButton id={id} />
      <DeleteButton id={id} name={name} usageCount={usageCount} />
    </div>
  )
}
