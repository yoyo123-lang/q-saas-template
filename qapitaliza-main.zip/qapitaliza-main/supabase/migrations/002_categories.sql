-- ============================================================
-- 002 — Categories
-- Categorías de activos. Soporta jerarquía (parentId nullable).
-- Rollback: 002_categories_rollback.sql
-- ============================================================

CREATE TABLE public.categories (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT        NOT NULL,
  slug        TEXT        NOT NULL UNIQUE,
  description TEXT,
  icon        TEXT,                                      -- emoji o nombre de ícono Lucide
  parent_id   UUID        REFERENCES public.categories(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  public.categories             IS 'Categorías de activos. Árbol de 2 niveles máximo en MVP.';
COMMENT ON COLUMN public.categories.slug        IS 'URL-friendly, único. Ej: website, domain, saas';
COMMENT ON COLUMN public.categories.icon        IS 'Emoji o nombre de ícono. Ej: 🌐 o Globe';
COMMENT ON COLUMN public.categories.parent_id   IS 'NULL = categoría raíz. Non-null = subcategoría.';

-- Seed de categorías raíz del MVP
INSERT INTO public.categories (name, slug, description, icon) VALUES
  ('Sitios Web',  'website',   'Sitios web con tráfico y contenido establecido', '🌐'),
  ('Dominios',    'domain',    'Dominios premium con historial y autoridad',     '🔗'),
  ('SaaS / MVPs', 'saas',      'Proyectos SaaS, MVPs y aplicaciones web',        '💻'),
  ('E-commerce',  'ecommerce', 'Tiendas online con productos y ventas activas',  '🛒'),
  ('Proyectos',   'project',   'Proyectos digitales en etapa temprana',          '📁');
