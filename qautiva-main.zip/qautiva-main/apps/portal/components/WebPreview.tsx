'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { Monitor, Tablet, Smartphone } from 'lucide-react'

type Device = 'desktop' | 'tablet' | 'mobile'

const DEVICE_CONFIG: Record<Device, { label: string; width: string; icon: React.ElementType }> = {
  desktop: { label: 'Desktop', width: '100%', icon: Monitor },
  tablet: { label: 'Tablet', width: '768px', icon: Tablet },
  mobile: { label: 'Mobile', width: '390px', icon: Smartphone },
}

type WebPreviewProps = {
  deliverableId: string
  projectId: string
  title: string
  previewUrl?: string
  canApprove: boolean
}

/**
 * Preview del sitio web dentro de un browser chrome simulado.
 * Permite cambiar entre desktop (100%), tablet (768px) y mobile (390px).
 * El iframe usa sandbox="allow-scripts" sin allow-same-origin para prevenir XSS.
 * El cliente puede aprobar o pedir cambios con feedback textual.
 */
export function WebPreview({
  deliverableId,
  projectId,
  title,
  previewUrl,
  canApprove,
}: WebPreviewProps) {
  const router = useRouter()
  const [device, setDevice] = useState<Device>('desktop')
  const [feedback, setFeedback] = useState('')
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)
  const [done, setDone] = useState(false)

  const { width } = DEVICE_CONFIG[device]

  async function handleAction(action: 'approve' | 'reject') {
    if (action === 'reject' && feedback.trim().length === 0) {
      setError('Describí qué cambios necesitás.')
      return
    }
    setError(null)

    startTransition(async () => {
      const res = await fetch(`/api/deliverables/${deliverableId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, feedback: feedback.trim() }),
      })

      if (!res.ok) {
        const data = await res.json() as { error?: string }
        setError(data.error ?? 'Ocurrió un error. Intentalo de nuevo.')
        return
      }

      setDone(true)
      router.push(`/proyectos/${projectId}/progreso`)
      router.refresh()
    })
  }

  if (done) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <p className="text-[#94A3B8]">Procesando tu respuesta...</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header bar */}
      <div className="flex items-center justify-between gap-4 px-8 py-4 border-b border-[#1E293B] bg-[#0F172A]">
        <div>
          <p className="text-[#64748B] text-xs">Mi progreso › Entregables</p>
          <h1 className="text-white font-bold text-lg">{title}</h1>
        </div>

        {/* Toggle de dispositivo */}
        <div className="flex gap-1 bg-[#0B0F1A] border border-[#1E293B] rounded-lg p-1">
          {(Object.entries(DEVICE_CONFIG) as [Device, typeof DEVICE_CONFIG[Device]][]).map(([id, cfg]) => {
            const Icon = cfg.icon
            return (
              <button
                key={id}
                type="button"
                onClick={() => setDevice(id)}
                title={cfg.label}
                className={`
                  p-2 rounded-md transition-colors duration-200
                  ${device === id ? 'bg-[#8B5CF6] text-white' : 'text-[#64748B] hover:text-white'}
                `}
              >
                <Icon size={16} aria-hidden="true" />
              </button>
            )
          })}
        </div>

        {/* Botones de acción */}
        {canApprove && (
          <div className="flex gap-2">
            <button
              type="button"
              disabled={isPending}
              onClick={() => { setShowFeedback(true) }}
              className="px-4 py-2 rounded-lg border border-[#1E293B] text-[#94A3B8] hover:text-white hover:border-[#8B5CF6]/50 text-sm font-medium transition-colors duration-200 disabled:opacity-50"
            >
              Pedir cambios
            </button>
            <button
              type="button"
              disabled={isPending}
              onClick={() => handleAction('approve')}
              className="px-4 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#A78BFA] text-white text-sm font-medium transition-colors duration-200 disabled:opacity-50"
            >
              {isPending ? 'Enviando...' : 'Aprobar'}
            </button>
          </div>
        )}
      </div>

      {/* Panel de feedback */}
      {showFeedback && (
        <div className="px-8 py-4 bg-[#0F172A] border-b border-[#1E293B]">
          <label htmlFor="web-feedback" className="text-[#94A3B8] text-sm mb-2 block">
            Describí qué cambios necesitás
          </label>
          <div className="flex gap-2">
            <textarea
              id="web-feedback"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Ej: Cambiar el color del header, mover el botón de contacto..."
              rows={2}
              className="flex-1 bg-[#1E293B] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-3 py-2 text-white text-sm placeholder-[#64748B] resize-none outline-none transition-colors duration-200"
            />
            <button
              type="button"
              disabled={isPending}
              onClick={() => handleAction('reject')}
              className="px-4 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#A78BFA] text-white text-sm font-medium self-end transition-colors duration-200 disabled:opacity-50"
            >
              Enviar
            </button>
          </div>
          <p className="text-[#F59E0B]/80 text-xs mt-2">
            Los cambios serán revisados y aplicados manualmente por nuestro equipo. Este proceso no es automático y puede demorar.
          </p>
          {error && <p className="text-[#EF4444] text-xs mt-1">{error}</p>}
        </div>
      )}

      {/* Browser frame + Preview */}
      <div className="flex-1 overflow-auto bg-[#0B0F1A] p-6">
        <div
          className="mx-auto transition-all duration-300"
          style={{ maxWidth: width }}
        >
          {/* Browser chrome */}
          <div className="bg-[#1E293B] rounded-t-lg px-4 py-2.5 flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-[#EF4444]/60" />
              <div className="w-3 h-3 rounded-full bg-[#F59E0B]/60" />
              <div className="w-3 h-3 rounded-full bg-[#10B981]/60" />
            </div>
            <div className="flex-1 bg-[#0F172A] rounded px-3 py-1 text-[#64748B] text-xs truncate">
              {previewUrl ?? 'tu-sitio.com.ar'}
            </div>
          </div>

          {/* Iframe o placeholder */}
          <div className="bg-white rounded-b-lg overflow-hidden" style={{ minHeight: '500px' }}>
            {previewUrl ? (
              <iframe
                src={previewUrl}
                title="Preview del sitio web"
                className="w-full border-0"
                style={{ height: '600px' }}
                sandbox="allow-scripts"
              />
            ) : (
              <div className="flex flex-col items-center justify-center h-[500px] bg-[#0F172A]">
                <p className="text-[#64748B] text-sm">El preview del sitio estará disponible pronto.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
