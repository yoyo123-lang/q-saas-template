import type { Metadata } from 'next'
import { DomainRegisterForm } from './DomainRegisterForm'

export const metadata: Metadata = { title: 'Registrar dominio — Qautiva' }

export default function RegistrarDominioPage({
  searchParams,
}: {
  searchParams?: { domain?: string }
}) {
  const domain = searchParams?.domain ?? ''

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold text-[#F8FAFC] mb-2">Registrar dominio</h1>
      <DomainRegisterForm domain={domain} />
    </div>
  )
}
