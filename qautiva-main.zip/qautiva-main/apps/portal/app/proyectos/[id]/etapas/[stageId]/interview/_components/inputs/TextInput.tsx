'use client'

import type { QuestionBlock } from '@/app/_lib/interview/types'

export function TextInput({
  value,
  onChange,
  placeholder,
  disabled,
  validation,
  inputType = 'text',
}: {
  value: string
  onChange: (v: unknown) => void
  placeholder: string
  disabled: boolean
  validation?: QuestionBlock['validation']
  inputType?: 'text' | 'url'
}) {
  return (
    <input
      type={inputType}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder || (inputType === 'url' ? 'https://...' : 'Escribí tu respuesta...')}
      disabled={disabled}
      maxLength={validation?.maxLength}
      className="w-full bg-[#0B0F1A] border border-[#1E293B] focus:border-[#8B5CF6] rounded-lg px-4 py-3 text-white placeholder-[#334155] text-base outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
    />
  )
}
