'use client'

import { useTransition, useState, useRef, useEffect } from 'react'
import type { AutomationLevel } from '@qautiva/db'
import { AutomationToggle } from '@/components/AutomationToggle'
import { updateAgentConfig } from '@/lib/actions'

interface UpdateAgentFormProps {
  agentNumber: number
  automationLevel: AutomationLevel
  prompt: string
}

/**
 * Formulario de edición de prompt y nivel de automatización del agente.
 * Usa Server Action `updateAgentConfig` via useTransition.
 * name y description los gestiona el servidor directamente — no se envían desde el cliente.
 */
export function UpdateAgentForm({
  agentNumber,
  automationLevel: initialLevel,
  prompt: initialPrompt,
}: UpdateAgentFormProps) {
  const [isPending, startTransition] = useTransition()
  const [level, setLevel] = useState<AutomationLevel>(initialLevel)
  const [prompt, setPrompt] = useState(initialPrompt)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Limpia el timer al desmontar el componente para evitar setState en componente desmontado
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()

    // Validación client-side: prompt no puede ser solo whitespace
    if (!prompt.trim()) {
      setError('El prompt no puede estar vacío.')
      return
    }

    setError(null)
    setSuccess(false)

    const formData = new FormData(e.currentTarget)
    formData.set('automationLevel', level)

    startTransition(async () => {
      try {
        await updateAgentConfig(formData)
        setSuccess(true)
        if (timerRef.current) clearTimeout(timerRef.current)
        timerRef.current = setTimeout(() => setSuccess(false), 5000)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error desconocido')
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <input type="hidden" name="agentNumber" value={agentNumber} />

      {/* Nivel de automatización */}
      <div className="flex flex-col gap-2">
        <label className="text-[#94A3B8] text-sm font-medium">Nivel de automatización</label>
        <AutomationToggle value={level} onChange={setLevel} />
        <p className="text-[#64748B] text-xs">
          Manual: el admin revisa todo · Semi-auto: avisa, sigue si no responde en 12hs · Auto:
          directo al cliente
        </p>
      </div>

      {/* Prompt */}
      <div className="flex flex-col gap-2">
        <label htmlFor={`prompt-${agentNumber}`} className="text-[#94A3B8] text-sm font-medium">
          Instrucciones del agente (system prompt)
        </label>
        <textarea
          id={`prompt-${agentNumber}`}
          name="prompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={14}
          maxLength={10000}
          required
          placeholder="Instrucciones del sistema para este agente..."
          className="w-full resize-y bg-[#1E293B] text-[#F8FAFC] font-mono text-sm rounded-lg border border-[#334155] focus:border-[#8B5CF6] focus:outline-none p-4 leading-relaxed placeholder:text-[#64748B]"
        />
        <p className="text-[#64748B] text-xs text-right">{prompt.length} / 10000</p>
      </div>

      {/* Feedback */}
      {error && (
        <p className="text-[#F87171] text-sm bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-lg px-4 py-2">
          {error}
        </p>
      )}
      {success && (
        <p className="text-[#34D399] text-sm bg-[#10B981]/10 border border-[#10B981]/30 rounded-lg px-4 py-2">
          ✓ Configuración guardada correctamente
        </p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="self-start px-5 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isPending ? 'Guardando…' : 'Guardar configuración'}
      </button>
    </form>
  )
}
