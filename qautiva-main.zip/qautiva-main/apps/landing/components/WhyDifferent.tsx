'use client'

import { useEffect, useRef, useState } from 'react'
import type { RefObject } from 'react'
import { useInView } from '@/lib/use-in-view'

function useCounter(target: number, duration = 800, active: boolean) {
  const [count, setCount] = useState(0)
  const started = useRef(false)
  const rafId = useRef(0)

  useEffect(() => {
    if (!active || started.current) return
    started.current = true

    const startTime = performance.now()
    function tick(now: number) {
      const elapsed = now - startTime
      const progress = Math.min(elapsed / duration, 1)
      setCount(Math.round(progress * target))
      if (progress < 1) {
        rafId.current = requestAnimationFrame(tick)
      }
    }
    rafId.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafId.current)
  }, [active, target, duration])

  return count
}

export function WhyDifferent() {
  const { ref, isVisible } = useInView()
  const days = useCounter(7, 600, isVisible)
  const portals = useCounter(10, 800, isVisible)

  return (
    <section
      id="por-que"
      ref={ref as RefObject<HTMLElement>}
      className="bg-navy-950 py-20 md:py-24"
    >
      <div className="max-w-6xl mx-auto px-6">
        <h2 className={`text-3xl md:text-4xl font-bold text-white text-center mb-16 reveal ${isVisible ? 'visible' : ''}`}>
          No somos una agencia. Somos una fábrica.
        </h2>

        <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 reveal-stagger ${isVisible ? 'visible' : ''}`}>
          {/* Bloque 1 */}
          <div className="bg-navy-900 rounded-card p-8 border border-navy-800 hover:border-accent/40 transition-colors duration-300">
            <p
              className="text-accent font-bold text-6xl mb-2"
              style={{ textShadow: '0 0 40px rgba(139,92,246,0.5)' }}
            >
              {days} días
            </p>
            <h3 className="text-white font-bold text-lg mb-3">Velocidad de IA</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Lo que una agencia tarda meses, nuestra IA lo hace en una semana.
            </p>
          </div>

          {/* Bloque 2 */}
          <div className="bg-navy-900 rounded-card p-8 border border-navy-800 hover:border-accent/40 transition-colors duration-300">
            <p
              className="text-accent font-bold text-6xl mb-2"
              style={{ textShadow: '0 0 40px rgba(139,92,246,0.5)' }}
            >
              {portals}+ <span className="text-3xl">portales</span>
            </p>
            <h3 className="text-white font-bold text-lg mb-3">Medios propios</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Tu negocio aparece en portales de noticias que nosotros operamos.
            </p>
          </div>

          {/* Bloque 3 */}
          <div className="bg-navy-900 rounded-card p-8 border border-navy-800 hover:border-accent/40 transition-colors duration-300">
            <div className="flex gap-3 mb-4">
              <span className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white text-xs font-bold">
                qo
              </span>
              <span className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-white text-xs font-bold">
                qn
              </span>
              <span className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-white text-xs font-bold">
                qa
              </span>
            </div>
            <h3 className="text-white font-bold text-lg mb-3">Ecosistema completo</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Cobro, CRM e inversión integradas. Todo en un mismo lugar.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
