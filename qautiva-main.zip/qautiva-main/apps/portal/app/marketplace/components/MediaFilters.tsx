'use client'

import { useRouter, usePathname, useSearchParams } from 'next/navigation'
import { useCallback, useTransition } from 'react'
import { PLATFORM_OPTIONS, SORT_OPTIONS } from '../lib/constants'

type Category = { id: string; name: string; slug: string }

type MediaFiltersProps = {
  categories: Category[]
  currentPlatform: string
  currentCategoryId: string
  currentSort: string
  currentMinPrice: string
  currentMaxPrice: string
  minMaxError?: boolean
}

export function MediaFilters({
  categories,
  currentPlatform,
  currentCategoryId,
  currentSort,
  currentMinPrice,
  currentMaxPrice,
  minMaxError,
}: MediaFiltersProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const [isPending, startTransition] = useTransition()

  const updateFilter = useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams(searchParams.toString())
      if (value) {
        params.set(key, value)
      } else {
        params.delete(key)
      }
      params.delete('page')
      startTransition(() => {
        router.push(`${pathname}?${params.toString()}`)
      })
    },
    [router, pathname, searchParams],
  )

  const selectClass =
    'w-full bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#334155] appearance-none'

  const inputClass =
    'w-full bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#334155] placeholder-[#475569]'

  function handlePriceKey(key: string) {
    return (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter') {
        updateFilter(key, e.currentTarget.value)
      }
    }
  }

  return (
    <aside
      className={`w-full lg:w-56 shrink-0 flex flex-col gap-4 transition-opacity ${isPending ? 'opacity-50 pointer-events-none' : ''}`}
      aria-label="Filtros del marketplace"
    >
      {/* Plataforma */}
      <div>
        <label htmlFor="filter-platform" className="text-xs text-[#64748B] mb-1 block">
          Plataforma
        </label>
        <select
          id="filter-platform"
          className={selectClass}
          value={currentPlatform}
          onChange={(e) => updateFilter('platform', e.target.value)}
        >
          {PLATFORM_OPTIONS.map((p) => (
            <option key={p.value} value={p.value}>{p.label}</option>
          ))}
        </select>
      </div>

      {/* Categoría */}
      {categories.length > 0 && (
        <div>
          <label htmlFor="filter-category" className="text-xs text-[#64748B] mb-1 block">
            Categoría
          </label>
          <select
            id="filter-category"
            className={selectClass}
            value={currentCategoryId}
            onChange={(e) => updateFilter('categoryId', e.target.value)}
          >
            <option value="">Todas las categorías</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
      )}

      {/* Ordenar */}
      <div>
        <label htmlFor="filter-sort" className="text-xs text-[#64748B] mb-1 block">
          Ordenar por
        </label>
        <select
          id="filter-sort"
          className={selectClass}
          value={currentSort}
          onChange={(e) => updateFilter('sort', e.target.value)}
        >
          {SORT_OPTIONS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
      </div>

      {/* Precio */}
      <div>
        <label className="text-xs text-[#64748B] mb-1 block">Precio (ARS)</label>
        {minMaxError && (
          <p className="text-xs text-red-400 mb-1">El precio mínimo no puede superar el máximo.</p>
        )}
        <div className="flex gap-2">
          <input
            type="number"
            id="filter-min-price"
            aria-label="Precio mínimo en ARS"
            placeholder="Mín"
            min="0"
            className={inputClass}
            defaultValue={currentMinPrice}
            onBlur={(e) => updateFilter('minPrice', e.target.value)}
            onKeyDown={handlePriceKey('minPrice')}
          />
          <input
            type="number"
            id="filter-max-price"
            aria-label="Precio máximo en ARS"
            placeholder="Máx"
            min="0"
            className={inputClass}
            defaultValue={currentMaxPrice}
            onBlur={(e) => updateFilter('maxPrice', e.target.value)}
            onKeyDown={handlePriceKey('maxPrice')}
          />
        </div>
      </div>

      {/* Limpiar filtros */}
      <a
        href="/marketplace"
        className="text-xs text-[#64748B] hover:text-[#94A3B8] text-center transition-colors"
      >
        Limpiar filtros
      </a>
    </aside>
  )
}
