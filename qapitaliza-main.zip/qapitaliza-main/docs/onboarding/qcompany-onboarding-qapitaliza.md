# Onboarding de Qapitaliza para Q-Company Central

> Información para registrar Qapitaliza como BU en el Board de Q-Company.
> Fecha: 2026-03-22

---

## Datos de la BU

| Campo | Valor |
|---|---|
| **Nombre** | Qapitaliza |
| **Slug** | qapitaliza |
| **Color** | #F59E0B (amber) |
| **Estado** | ONBOARDING |
| **Descripción** | Marketplace de activos digitales y comerciales + plataforma de crowdfunding |

## Stack técnico

| Componente | Tecnología |
|---|---|
| Framework | Next.js 15 (App Router, TypeScript) |
| DB | PostgreSQL 16 (Supabase) |
| ORM | Prisma 5 |
| Auth | Supabase Auth |
| CSS | Tailwind CSS 4 |
| Deploy | Vercel |
| Testing | Vitest + Testing Library |

## Métricas a reportar al Board (cuando estén disponibles)

| Métrica | Tipo | Descripción |
|---|---|---|
| listings_total | COUNT | Total de activos listados |
| listings_published | COUNT | Listados activos/publicados |
| listings_sold | COUNT | Activos vendidos (acumulado) |
| gmv_monthly | CURRENCY | Volumen bruto de transacciones mensual |
| users_total | COUNT | Usuarios registrados |
| users_sellers | COUNT | Vendedores activos |
| users_buyers | COUNT | Compradores activos |
| inquiries_monthly | COUNT | Consultas mensuales |
| conversion_rate | PERCENTAGE | Consultas que se convierten en venta |
| campaigns_active | COUNT | Campañas de crowdfunding activas (Fase 1.5) |
| campaigns_funded | CURRENCY | Total recaudado en crowdfunding (Fase 1.5) |

## Integraciones con el ecosistema

| Producto | Tipo de integración | Estado |
|---|---|---|
| Q-Company Board | Reportar métricas como BU | Pendiente (post-MVP) |
| Qobra | Validar ingresos de activos listados vía API | Futuro (Fase 2) |
| Qontacta | Validar base de clientes/contactos de activos | Futuro (Fase 2) |
| Qautiva | Recibir MVPs generados para listar en marketplace | Futuro |
| Qontrata | Sin integración directa prevista | N/A |

## Endpoints que Qapitaliza expondría al Board

```
POST   /api/v1/bu/metrics      — Recibir solicitud de métricas
POST   /api/v1/bu/directives   — Recibir directivas del Board
GET    /api/v1/bu/health       — Health check
```

Estos endpoints seguirán el mismo patrón que las otras BUs: auth vía `x-api-key` header, respuesta en formato estándar del ecosistema.

## Modelo de negocio (resumen para el Board)

- **Tipo**: Marketplace (compraventa de activos digitales) + Crowdfunding
- **Monetización**: Comisión por transacción + fee de listado destacado (modelo a definir)
- **Mercado**: Hispanohablante, foco inicial Argentina
- **Diferenciador**: MVPs vibecodeados como categoría, validación de métricas integrada con ecosistema Q
- **Catálogo semilla**: ~50 sitios/dominios/proyectos propios de Federico

## Roadmap simplificado

1. **MVP** (en desarrollo): Marketplace funcional con catálogo, auth, consultas
2. **Fase 1.5**: Crowdfunding no regulado (modelo recompensa/preventa)
3. **Fase 2**: Integración con Qobra/Qontacta para validación automática de métricas
4. **Fase 2+**: Fondos de comercio tradicionales
5. **Fase 3**: Smart contracts para certificación de métricas (largo plazo)

## Estética

- Color de marca: **#F59E0B** (amber/dorado)
- Mismo sistema de diseño del ecosistema Q: dark theme, navy backgrounds, DM Sans
- Acento amber en lugar de violet (Qautiva) o rose (Qontrata) o blue (Q-Company)
