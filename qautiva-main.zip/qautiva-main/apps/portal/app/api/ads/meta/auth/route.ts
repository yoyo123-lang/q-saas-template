/**
 * GET /api/ads/meta/auth?projectId=xxx
 *
 * Inicia el flujo OAuth de Meta Ads.
 * Genera un state token para prevenir CSRF y redirige a Facebook Login.
 */
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { randomUUID } from 'crypto'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { getMetaAuthUrl } from '@qautiva/ads/meta'

const STATE_COOKIE = 'ads_meta_oauth_state'
const STATE_TTL_SECONDS = 600 // 10 minutos

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const projectId = searchParams.get('projectId')

  if (!projectId) {
    return NextResponse.json({ error: 'Falta projectId' }, { status: 400 })
  }

  // 1. Verificar autenticación
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  // 2. Verificar ownership del proyecto
  const profile = await prisma.userProfile.findFirst({
    where: { authUserId: user.id },
    select: {
      teamMemberships: {
        select: { teamId: true },
      },
    },
  })

  if (!profile) {
    return NextResponse.json({ error: 'Perfil no encontrado' }, { status: 404 })
  }

  const teamIds = profile.teamMemberships.map(m => m.teamId)

  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true },
  })

  if (!project) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // 3. Generar state con projectId + nonce (previene CSRF)
  const nonce = randomUUID()
  const state = `${projectId}|${nonce}`

  // 4. Guardar state en cookie segura
  const response = NextResponse.redirect(getMetaAuthUrl(state))
  response.cookies.set(STATE_COOKIE, state, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: STATE_TTL_SECONDS,
    path: '/',
  })

  return response
}
