# Migraciones SQL — Qapitaliza

> Archivos SQL para ejecutar manualmente en el **SQL Editor de Supabase**.
> Correr **en orden numérico**. Cada migración tiene su rollback correspondiente.

---

## Cómo usarlas

1. Ir a **Supabase Dashboard → SQL Editor**
2. Copiar el contenido del archivo `.sql` correspondiente
3. Pegar en el editor y ejecutar
4. Verificar que no hay errores antes de seguir con el siguiente número

Para revertir: ejecutar el archivo `_rollback.sql` correspondiente **en orden inverso**.

---

## Orden de ejecución

| # | Archivo | Qué crea | Rollback |
|---|---------|----------|---------|
| 001 | `001_profiles.sql` | Tabla `profiles` + ENUMs de rol + trigger auto-create | `001_profiles_rollback.sql` |
| 002 | `002_categories.sql` | Tabla `categories` con jerarquía | `002_categories_rollback.sql` |
| 003 | `003_listings.sql` | Tabla `listings` + ENUMs de tipo/status/verificación | `003_listings_rollback.sql` |
| 004 | `004_listing_metrics.sql` | Tabla `listing_metrics` + ENUMs de métrica/fuente | `004_listing_metrics_rollback.sql` |
| 005 | `005_inquiries.sql` | Tablas `inquiries` + `inquiry_messages` + ENUM status | `005_inquiries_rollback.sql` |
| 006 | `006_favorites.sql` | Tabla `favorites` (unique user+listing) | `006_favorites_rollback.sql` |
| 007 | `007_audit_log.sql` | Tabla `audit_log` | `007_audit_log_rollback.sql` |
| 008 | `008_indexes.sql` | Todos los índices de performance | `008_indexes_rollback.sql` |
| 009 | `009_rls_policies.sql` | Row Level Security en todas las tablas | `009_rls_policies_rollback.sql` |
| 010 | `010_triggers.sql` | Triggers `updated_at` + auto-create de perfil al registrarse | `010_triggers_rollback.sql` |

---

## Notas importantes

- **Supabase Auth** gestiona `auth.users` automáticamente — no tocar esa tabla
- `profiles` referencia `auth.users(id)` con `ON DELETE CASCADE`
- Los ENUMs de PostgreSQL no se pueden renombrar ni modificar fácilmente — crear uno nuevo si cambia
- RLS está habilitado en todas las tablas públicas — sin políticas, nadie lee ni escribe
- El trigger de `010` crea el perfil automáticamente cuando Supabase Auth registra un usuario nuevo
- Prisma usa estas mismas tablas vía `DATABASE_URL` — mantener `prisma/schema.prisma` en sync

---

## Rollback total (emergencia)

Para borrar TODO en orden inverso:

```sql
-- Ejecutar en Supabase SQL Editor en este orden exacto:
-- 1. 010_triggers_rollback.sql
-- 2. 009_rls_policies_rollback.sql
-- 3. 008_indexes_rollback.sql
-- 4. 007_audit_log_rollback.sql
-- 5. 006_favorites_rollback.sql
-- 6. 005_inquiries_rollback.sql
-- 7. 004_listing_metrics_rollback.sql
-- 8. 003_listings_rollback.sql
-- 9. 002_categories_rollback.sql
-- 10. 001_profiles_rollback.sql
```
