import { PrismaClient, PlanSlug, IvaCondition, ContactType } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = process.env.ADMIN_EMAIL;

  if (!adminEmail) {
    console.error("ERROR: ADMIN_EMAIL no está definido en las variables de entorno.");
    process.exit(1);
  }

  // Health check de conexión antes de iniciar
  await prisma.$queryRaw`SELECT 1`;
  console.log("Conexión a la base de datos: OK");

  await prisma.$transaction(async (tx) => {
    // --- Auth: allowlist y admin ---

    await tx.allowedEmail.upsert({
      where: { email: adminEmail },
      update: {},
      create: { email: adminEmail },
    });
    console.log(`Email ${adminEmail} en allowlist.`);

    const existingUser = await tx.user.findUnique({
      where: { email: adminEmail },
      select: { id: true, role: true },
    });

    if (existingUser) {
      if (existingUser.role !== "ADMIN") {
        await tx.user.update({
          where: { email: adminEmail },
          data: { role: "ADMIN" },
        });
        console.log(`Usuario ${adminEmail} promovido a ADMIN.`);
      } else {
        console.log(`Usuario ${adminEmail} ya es ADMIN.`);
      }
    } else {
      console.log(`Usuario ${adminEmail} recibirá rol ADMIN en su primer login.`);
    }

    // --- Planes de suscripción ---
    // update: {} para no sobreescribir precios/límites en producción si el plan ya existe

    const planes = [
      {
        slug: PlanSlug.MICRO,
        name: "Micro",
        maxUsers: 1,
        maxMonthlyComprobantes: 50,
        priceMonthly: "0.00",
        features: JSON.stringify(["Facturación básica", "1 usuario", "50 comprobantes/mes"]),
      },
      {
        slug: PlanSlug.STARTER,
        name: "Starter",
        maxUsers: 3,
        maxMonthlyComprobantes: 200,
        priceMonthly: "4999.00",
        features: JSON.stringify(["Todo Micro", "3 usuarios", "200 comprobantes/mes", "Reportes básicos"]),
      },
      {
        slug: PlanSlug.PRO,
        name: "Pro",
        maxUsers: 10,
        maxMonthlyComprobantes: 1000,
        priceMonthly: "9999.00",
        features: JSON.stringify([
          "Todo Starter",
          "10 usuarios",
          "1000 comprobantes/mes",
          "Reportes avanzados",
          "Soporte prioritario",
        ]),
      },
      {
        slug: PlanSlug.MAX,
        name: "Max",
        // null = ilimitado (reemplaza el magic number 9999)
        maxUsers: null,
        maxMonthlyComprobantes: null,
        priceMonthly: "19999.00",
        features: JSON.stringify(["Todo Pro", "Usuarios ilimitados", "Comprobantes ilimitados", "API access"]),
      },
    ];

    for (const plan of planes) {
      await tx.plan.upsert({
        where: { slug: plan.slug },
        update: {}, // No sobreescribir precio ni límites en ejecuciones subsiguientes
        create: plan,
      });
    }
    console.log(`Planes creados: ${planes.map((p) => p.name).join(", ")}.`);

    // --- Organización demo ---

    const demoOrg = await tx.organization.upsert({
      where: { slug: "demo-comercio" },
      update: {},
      create: {
        name: "Demo Comercio SRL",
        slug: "demo-comercio",
        fiscalData: {
          cuit: "30-71234567-0",
          razonSocial: "Demo Comercio SRL",
          ivaCondition: "RESPONSABLE_INSCRIPTO",
          domicilioFiscal: {
            calle: "Av. Corrientes",
            numero: "1234",
            ciudad: "Buenos Aires",
            provincia: "Buenos Aires",
            cp: "C1043",
          },
          puntoVenta: 1,
        },
        settings: {
          currency: "ARS",
          timezone: "America/Argentina/Buenos_Aires",
        },
      },
    });
    console.log(`Organización demo: ${demoOrg.name} (${demoOrg.id})`);

    // --- Depósito por defecto ---
    // Usa campo natural (organizationId, name) gracias al unique constraint en Warehouse

    await tx.warehouse.upsert({
      where: { organizationId_name: { organizationId: demoOrg.id, name: "Depósito Central" } },
      update: {},
      create: {
        organizationId: demoOrg.id,
        name: "Depósito Central",
        description: "Depósito principal de la organización",
        isDefault: true,
      },
    });
    console.log(`Depósito: Depósito Central`);

    // --- Lista de precios por defecto ---

    const priceListId = `pricelist-default-${demoOrg.id}`;
    await tx.priceList.upsert({
      where: { id: priceListId },
      update: {},
      create: {
        id: priceListId,
        organizationId: demoOrg.id,
        name: "Lista de precios general",
        description: "Lista de precios base para todos los clientes",
        isDefault: true,
      },
    });
    console.log(`Lista de precios por defecto creada.`);

    // --- Categoría de muestra ---

    const category = await tx.category.upsert({
      where: { organizationId_slug: { organizationId: demoOrg.id, slug: "electronica" } },
      update: {},
      create: {
        organizationId: demoOrg.id,
        name: "Electrónica",
        slug: "electronica",
        description: "Productos electrónicos",
      },
    });
    console.log(`Categoría: ${category.name}`);

    // --- Producto de muestra ---

    await tx.product.upsert({
      where: { organizationId_sku: { organizationId: demoOrg.id, sku: "PROD-001" } },
      update: {},
      create: {
        organizationId: demoOrg.id,
        categoryId: category.id,
        name: "Auriculares Inalámbricos",
        sku: "PROD-001",
        description: "Auriculares Bluetooth con cancelación de ruido",
        barcode: "7798000000001",
        unit: "unidad",
        basePrice: "15000.00",
        minStock: "5",
      },
    });
    console.log(`Producto demo creado: Auriculares Inalámbricos`);

    // --- Cliente de muestra ---

    const clienteId = `contact-cliente-demo-${demoOrg.id}`;
    await tx.contact.upsert({
      where: { id: clienteId },
      update: {},
      create: {
        id: clienteId,
        organizationId: demoOrg.id,
        type: ContactType.CUSTOMER,
        name: "Juan Pérez",
        email: "juan.perez@ejemplo.com",
        phone: "+54 11 1234-5678",
        cuit: "20-12345678-9",
        ivaCondition: IvaCondition.CONSUMIDOR_FINAL,
        fiscalAddress: {
          calle: "Av. Santa Fe",
          numero: "567",
          ciudad: "Buenos Aires",
          provincia: "Buenos Aires",
          cp: "C1059",
        },
      },
    });
    console.log(`Cliente demo creado: Juan Pérez`);

    // --- Proveedor de muestra ---

    const proveedorId = `contact-proveedor-demo-${demoOrg.id}`;
    await tx.contact.upsert({
      where: { id: proveedorId },
      update: {},
      create: {
        id: proveedorId,
        organizationId: demoOrg.id,
        type: ContactType.SUPPLIER,
        name: "Distribuidora Tech SA",
        email: "ventas@distribuidoratech.com",
        phone: "+54 11 4444-5555",
        cuit: "30-98765432-1",
        ivaCondition: IvaCondition.RESPONSABLE_INSCRIPTO,
        fiscalAddress: {
          calle: "Av. Belgrano",
          numero: "1500",
          ciudad: "Buenos Aires",
          provincia: "Buenos Aires",
          cp: "C1093",
        },
      },
    });
    console.log(`Proveedor demo creado: Distribuidora Tech SA`);
  });

  console.log("\n✅ Seed completado.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
