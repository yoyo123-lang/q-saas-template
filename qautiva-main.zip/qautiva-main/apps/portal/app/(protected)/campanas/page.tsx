import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import type { CampaignPlan, AdCreatives } from '@/app/_lib/interview/types'
import { CampaignPlanSection } from './_components/CampaignPlanSection'
import { AdCreativesSection } from './_components/AdCreativesSection'

export const metadata: Metadata = { title: 'Campañas — Qautiva' }

export default async function CampanasPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user?.app_metadata?.org_id) {
    return (
      <div className="p-8">
        <p className="text-[#94A3B8]">No autenticado.</p>
      </div>
    )
  }

  const orgId = user.app_metadata.org_id as string

  // Una query: etapa CAMPAIGNS con sus deliverables activos
  const campaignStage = await prisma.stage.findFirst({
    where: { organizationId: orgId, stageKey: 'CAMPAIGNS' },
    select: {
      deliverables: {
        where: {
          type: { in: ['CAMPAIGN_PLAN', 'AD_CREATIVES'] },
          isActive: true,
        },
        select: { id: true, type: true, title: true, status: true, content: true, version: true },
        orderBy: { createdAt: 'desc' },
      },
    },
  })

  const deliverables = campaignStage?.deliverables ?? []

  const planDeliverable = deliverables.find((d) => d.type === 'CAMPAIGN_PLAN') ?? null
  const creativesDeliverable = deliverables.find((d) => d.type === 'AD_CREATIVES') ?? null

  const plan = planDeliverable?.content as CampaignPlan | null
  const creatives = creativesDeliverable?.content as AdCreatives | null

  return (
    <div className="p-8 max-w-4xl">
      <h1 className="text-2xl font-bold text-white mb-8">Campañas publicitarias</h1>

      {/* Sección plan de campaña */}
      {plan ? (
        <CampaignPlanSection
          plan={plan}
          status={planDeliverable!.status}
          version={planDeliverable!.version}
        />
      ) : (
        <div className="mb-8 p-6 rounded-xl border border-[#1E293B] bg-[#0F172A]">
          <h2 className="text-sm font-semibold text-[#64748B] uppercase tracking-wider mb-2">
            Plan de campaña
          </h2>
          <p className="text-[#94A3B8] text-sm">
            {campaignStage
              ? 'Tu plan de campaña se está preparando. Te avisamos cuando esté listo.'
              : 'Todavía no tenés una campaña activa. Cuando el equipo la configure, la vas a ver acá.'}
          </p>
        </div>
      )}

      {/* Sección piezas publicitarias */}
      {creatives ? (
        <AdCreativesSection
          creatives={creatives}
          status={creativesDeliverable!.status}
          version={creativesDeliverable!.version}
        />
      ) : (
        <div className="p-6 rounded-xl border border-[#1E293B] bg-[#0F172A]">
          <h2 className="text-sm font-semibold text-[#64748B] uppercase tracking-wider mb-2">
            Piezas publicitarias
          </h2>
          <p className="text-[#94A3B8] text-sm">
            {plan
              ? 'Las piezas publicitarias se están generando en base a tu plan.'
              : 'Las piezas publicitarias van a aparecer acá cuando tu campaña esté activa.'}
          </p>
        </div>
      )}
    </div>
  )
}
