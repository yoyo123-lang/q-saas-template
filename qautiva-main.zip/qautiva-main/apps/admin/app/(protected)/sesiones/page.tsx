import type { Metadata } from 'next'
import { requireAdminSession } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import Link from 'next/link'
import { RetrySessionButton } from './_components/RetrySessionButton'
import { ResetToInterviewButton } from './_components/ResetToInterviewButton'

export const metadata: Metadata = { title: 'Sesiones — Qautiva Admin' }
export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  PROCESSING: 'Procesando',
  ERROR: 'Error',
  COMPLETED: 'Completada',
  NOT_STARTED: 'No iniciada',
  IN_PROGRESS: 'En progreso',
}

export default async function SesionesPage() {
  await requireAdminSession()

  const sessions = await prisma.interviewSession.findMany({
    where: {
      status: { in: ['PROCESSING', 'ERROR'] },
    },
    orderBy: { processingStartedAt: 'desc' },
    take: 50,
    select: {
      id: true,
      status: true,
      lastError: true,
      retryCount: true,
      processingStartedAt: true,
      createdAt: true,
      stage: {
        select: {
          name: true,
          organization: {
            select: { id: true, name: true },
          },
        },
      },
    },
  })

  return (
    <div className="p-6 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Sesiones con errores</h1>
        <p className="text-[#64748B] text-sm mt-1">
          Sesiones en estado PROCESSING o ERROR que pueden necesitar intervención.
        </p>
      </div>

      {sessions.length === 0 ? (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
          <p className="text-[#10B981] font-medium mb-1">Todo en orden</p>
          <p className="text-[#64748B] text-sm">No hay sesiones con errores en este momento.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sessions.map((s) => {
            const org = s.stage?.organization
            const orgId = org?.id
            const stuckMin = s.processingStartedAt
              ? Math.floor((Date.now() - new Date(s.processingStartedAt).getTime()) / 60_000)
              : null

            return (
              <div key={s.id} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 flex items-start gap-4">
                {/* Status badge */}
                <div className={`flex-shrink-0 mt-0.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  s.status === 'ERROR'
                    ? 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30'
                    : 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30'
                }`}>
                  {STATUS_LABELS[s.status] ?? s.status}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    {orgId ? (
                      <Link
                        href={`/clientes/${orgId}?tab=entrevista`}
                        className="text-white text-sm font-medium hover:text-[#A78BFA] transition-colors"
                      >
                        {org?.name ?? 'Cliente desconocido'}
                      </Link>
                    ) : (
                      <span className="text-white text-sm font-medium">Cliente desconocido</span>
                    )}
                    <span className="text-[#475569] text-xs">·</span>
                    <span className="text-[#64748B] text-xs">{s.stage?.name ?? 'Etapa desconocida'}</span>
                  </div>
                  {s.lastError && (
                    <p className="text-[#F87171] text-xs mt-1 truncate">{s.lastError}</p>
                  )}
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-[#475569] text-xs">Reintentos: {s.retryCount}</span>
                    {stuckMin !== null && (
                      <span className={`text-xs ${stuckMin > 10 ? 'text-[#F59E0B]' : 'text-[#475569]'}`}>
                        Demorado hace {stuckMin} min
                      </span>
                    )}
                  </div>
                </div>

                {/* Action buttons */}
                {orgId && (
                  <div className="flex-shrink-0 flex gap-2">
                    <ResetToInterviewButton sessionId={s.id} orgId={orgId} />
                    <RetrySessionButton sessionId={s.id} orgId={orgId} />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
