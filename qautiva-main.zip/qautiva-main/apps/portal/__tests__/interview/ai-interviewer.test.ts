import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { QuestionBlock } from '../../app/_lib/interview/types'

// ── Mock de @anthropic-ai/sdk ─────────────────────────────────────────────────

const mockCreate = vi.fn()

vi.mock('@anthropic-ai/sdk', () => ({
  default: vi.fn().mockImplementation(() => ({
    messages: { create: mockCreate },
  })),
}))

// ── buildMessages ─────────────────────────────────────────────────────────────

describe('buildMessages', () => {
  it('retorna solo el mensaje inicial cuando flowDefinition está vacío', async () => {
    const { buildMessages } = await import('../../app/_lib/interview/ai-interviewer')
    const messages = buildMessages([], {})

    expect(messages).toHaveLength(1)
    expect(messages[0]).toEqual({ role: 'user', content: 'Iniciá la entrevista.' })
  })

  it('construye pares assistant/user por cada pregunta respondida', async () => {
    const { buildMessages } = await import('../../app/_lib/interview/ai-interviewer')

    const flow: QuestionBlock[] = [
      { id: 'q1', question: '¿Qué hacés?', inputType: 'textarea' },
      { id: 'q2', question: '¿Quiénes son tus clientes?', inputType: 'text' },
    ]
    const answers = { q1: 'Vendemos software', q2: 'PYMEs' }

    const messages = buildMessages(flow, answers)

    // inicial + (assistant+user) × 2 = 5
    expect(messages).toHaveLength(5)
    expect(messages[0]).toEqual({ role: 'user', content: 'Iniciá la entrevista.' })

    // Primera pregunta — Claude la hizo
    const msg1 = messages[1]!
    expect(msg1.role).toBe('assistant')
    const assistantContent1 = msg1.content as unknown[]
    expect(Array.isArray(assistantContent1)).toBe(true)
    const toolUse1 = assistantContent1[0] as Record<string, unknown>
    expect(toolUse1.type).toBe('tool_use')
    expect(toolUse1.id).toBe('q1')
    expect(toolUse1.name).toBe('ask_question')

    // Respuesta del usuario a q1
    const msg2 = messages[2]!
    expect(msg2.role).toBe('user')
    const userContent1 = msg2.content as unknown[]
    expect(Array.isArray(userContent1)).toBe(true)
    const toolResult1 = userContent1[0] as Record<string, unknown>
    expect(toolResult1.type).toBe('tool_result')
    expect(toolResult1.tool_use_id).toBe('q1')
    expect(toolResult1.content).toBe('<respuesta_usuario>Vendemos software</respuesta_usuario>')
  })

  it('no incluye tool_result para preguntas sin respuesta', async () => {
    const { buildMessages } = await import('../../app/_lib/interview/ai-interviewer')

    const flow: QuestionBlock[] = [
      { id: 'q1', question: '¿Qué hacés?', inputType: 'textarea' },
    ]
    // Sin respuesta para q1
    const messages = buildMessages(flow, {})

    // inicial + assistant = 2 (sin tool_result porque no hay respuesta)
    expect(messages).toHaveLength(2)
    expect(messages[1]!.role).toBe('assistant')
  })

  it('serializa respuestas no-string como JSON', async () => {
    const { buildMessages } = await import('../../app/_lib/interview/ai-interviewer')

    const flow: QuestionBlock[] = [
      { id: 'q1', question: '¿Cuánto presupuesto?', inputType: 'budget_range' },
    ]
    const answers = { q1: { min: 1000, max: 5000 } }

    const messages = buildMessages(flow, answers)
    const toolResult = (messages[2]!.content as unknown[])[0] as Record<string, unknown>
    expect(toolResult.content).toBe(
      `<respuesta_usuario>${JSON.stringify({ min: 1000, max: 5000 })}</respuesta_usuario>`,
    )
  })
})

// ── getNextQuestion ───────────────────────────────────────────────────────────

describe('getNextQuestion', () => {
  beforeEach(() => {
    mockCreate.mockReset()
  })

  it('retorna { type: question } cuando Claude llama ask_question', async () => {
    const { getNextQuestion } = await import('../../app/_lib/interview/ai-interviewer')

    mockCreate.mockResolvedValueOnce({
      content: [
        {
          type: 'tool_use',
          id: 'q_neg_1',
          name: 'ask_question',
          input: {
            id: 'neg_descripcion',
            question: '¿Qué hace tu negocio?',
            inputType: 'textarea',
          },
        },
      ],
      stop_reason: 'tool_use',
    })

    const result = await getNextQuestion('system prompt', [], {})

    expect(result.type).toBe('question')
    if (result.type === 'question') {
      expect(result.block.id).toBe('neg_descripcion')
      expect(result.block.question).toBe('¿Qué hace tu negocio?')
      expect(result.block.inputType).toBe('textarea')
      expect(result.block.validation).toEqual({ required: true })
    }
  })

  it('retorna { type: complete } cuando Claude llama interview_complete', async () => {
    const { getNextQuestion } = await import('../../app/_lib/interview/ai-interviewer')

    mockCreate.mockResolvedValueOnce({
      content: [
        {
          type: 'tool_use',
          id: 'done_1',
          name: 'interview_complete',
          input: { summary: 'Negocio de software para PYMEs en CABA.' },
        },
      ],
      stop_reason: 'tool_use',
    })

    const result = await getNextQuestion('prompt', [], {})
    expect(result.type).toBe('complete')
  })

  it('lanza si Claude no llama ninguna tool', async () => {
    const { getNextQuestion } = await import('../../app/_lib/interview/ai-interviewer')

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'text', text: 'Hola, ¿en qué puedo ayudarte?' }],
      stop_reason: 'end_turn',
    })

    await expect(getNextQuestion('prompt', [], {})).rejects.toThrow(
      '[ai-interviewer]',
    )
  })

  it('lanza si Claude llama una tool desconocida', async () => {
    const { getNextQuestion } = await import('../../app/_lib/interview/ai-interviewer')

    mockCreate.mockResolvedValueOnce({
      content: [
        {
          type: 'tool_use',
          id: 'x',
          name: 'herramienta_inventada',
          input: {},
        },
      ],
      stop_reason: 'tool_use',
    })

    await expect(getNextQuestion('prompt', [], {})).rejects.toThrow(
      'Tool desconocida',
    )
  })

  it('pasa tool_choice: any a la API de Anthropic', async () => {
    const { getNextQuestion } = await import('../../app/_lib/interview/ai-interviewer')

    mockCreate.mockResolvedValueOnce({
      content: [
        {
          type: 'tool_use',
          id: 'q1',
          name: 'ask_question',
          input: { id: 'test', question: '¿Test?', inputType: 'text' },
        },
      ],
      stop_reason: 'tool_use',
    })

    await getNextQuestion('prompt', [], {})

    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({ tool_choice: { type: 'any' } }),
    )
  })
})
