# Sesión 7: Stock básico

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 7
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Control de stock con un depósito, movimientos de entrada/salida, vista de stock actual con alertas.

## Pre-requisitos

Sesión 3 completada (productos).

## Etapas

### Etapa 1: Validaciones y API routes
- Schema Zod para Warehouse y StockMovement
- API routes para Warehouse CRUD (un depósito por defecto por tenant)
- API routes para StockMovement (registrar entrada, salida, ajuste)
- Scoped por tenant

### Etapa 2: Servicio de stock
- Calcular stock actual por producto/variante (suma de movimientos)
- Registrar movimiento (entrada, salida, ajuste, transferencia futura)
- Validar stock suficiente antes de permitir salida
- Transacción atómica para movimientos

### Etapa 3: Página de stock actual
- Vista por producto con stock actual, stock mínimo, indicador de estado
- Indicador visual de stock bajo (rojo si está por debajo del mínimo)
- Filtros por categoría, estado de stock
- Exportar a CSV

### Etapa 4: Movimientos de stock
- Historial de movimientos con filtros (tipo, fecha, producto)
- Formulario de ajuste manual de stock (con motivo obligatorio)
- Vista de movimientos por producto individual

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
