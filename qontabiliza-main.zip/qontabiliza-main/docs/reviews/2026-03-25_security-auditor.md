# Security Audit
**Fecha:** 2026-03-25
**Archivos revisados:**
- `src/lib/tenant.ts`
- `prisma/schema.prisma`
- `supabase/migrations/20260325000000_add_domain_models.sql`
- `prisma/seed.ts`

---

## Hallazgos

### CRÍTICO

#### SEC-01 — IDOR: `findUnique` y `findUniqueOrThrow` no interceptados por `withTenant`
**Archivo:** `src/lib/tenant.ts:53-89`
**Descripción:** Las operaciones `findUnique` y `findUniqueOrThrow` no están incluidas en los interceptores de `withTenant`. Un atacante (o código incorrecto) que llame `db.invoice.findUnique({ where: { id: someId } })` puede acceder a cualquier factura de cualquier tenant conociendo solo el ID. Este es un IDOR clásico (Insecure Direct Object Reference), OWASP A01:2021.

**Escenario de ataque:**
1. Usuario autenticado en tenant A conoce el formato de los IDs (CUID).
2. Llama a un endpoint que internamente usa `findUnique` con el ID del objeto.
3. Puede enumerar o acceder a facturas/ventas/contactos de tenant B.

**Fix sugerido:** Interceptar `findUnique` y `findUniqueOrThrow` en `withTenant`, e inyectar `organizationId` en el `where`. En Prisma, `findUnique` requiere que el `where` contenga el campo de unique constraint; agregar `organizationId` en el `where` cuando el modelo está scoped.

#### SEC-02 — Sin Row Level Security (RLS) en Supabase
**Archivo:** `supabase/migrations/20260325000000_add_domain_models.sql`
**Descripción:** La migración crea todas las tablas sin ninguna política de RLS (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY` + `CREATE POLICY`). Supabase expone una API REST (PostgREST) que es accesible para usuarios autenticados. Sin RLS, cualquier usuario autenticado en Supabase puede hacer `GET /rest/v1/invoices` y recibir todas las facturas de todos los tenants, bypasseando completamente la lógica de tenant del backend.
**Fix sugerido:** Agregar RLS en cada tabla de dominio. Política base:
```sql
ALTER TABLE "Invoice" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation" ON "Invoice"
  USING (organization_id = (current_setting('app.current_tenant'))::text);
```
O deshabilitar el acceso directo a la API de Supabase para las tablas de dominio y usar solo el backend Next.js.

---

### ALTO

#### SEC-03 — `withTenant` no intercepta `update` y `delete` individuales
**Archivo:** `src/lib/tenant.ts:75-86`
**Descripción:** Solo `updateMany` y `deleteMany` son interceptados. Las operaciones `update` y `delete` (single record) no lo son. Si el código de la aplicación usa `db.invoice.update({ where: { id }, data })`, un atacante que conozca el ID de una factura de otro tenant puede modificarla. Similar a IDOR pero para escritura.
**Fix sugerido:** Interceptar `update` y `delete` e inyectar `organizationId` en el `where` para modelos scoped.

#### SEC-04 — `withTenant` no intercepta `create` — organizationId no se inyecta automáticamente en escrituras
**Archivo:** `src/lib/tenant.ts:53-89`
**Descripción:** Un developer que use `db.invoice.create({ data: { ... } })` sin incluir `organizationId` crea una factura sin tenant. El campo `organizationId` es `String` (no nullable) en el schema, entonces Prisma tirará error... pero solo en runtime. Si se usa como FK a Organization, el error es de FK violation. El problema real es que el sistema no provee una capa de defensa en profundidad para escrituras.
**Fix sugerido:** Interceptar `create` y `createMany` e inyectar `organizationId` en `data` automáticamente para modelos scoped.

#### SEC-05 — `Organization` en `TENANT_SCOPED_MODELS` — impacto en seguridad
**Archivo:** `src/lib/tenant.ts:8`
**Descripción:** Incluir `"organization"` en el Set y que Organization no tenga `organizationId` significa que el filtro de tenant para Organization falla silenciosamente o tira error. Si el error es swallowed, `withTenant(id).organization.findMany()` podría retornar TODAS las organizaciones. Esto es una fuga de información crítica.
**Fix sugerido:** Remover `"organization"` del Set (ver CR-01). Para buscar la propia org, usar `prisma.organization.findUnique({ where: { id: organizationId } })`.

---

### MEDIO

#### SEC-06 — `count`, `aggregate`, `groupBy` no interceptados — estadísticas cross-tenant posibles
**Archivo:** `src/lib/tenant.ts:53-89`
**Descripción:** Si se llama `db.invoice.count()` usando el cliente extendido, no hay filtro de tenant aplicado. Un endpoint que retorne estadísticas (total de facturas, suma de ventas) podría retornar datos del sistema completo en vez del tenant activo.
**Fix sugerido:** Interceptar `count`, `aggregate`, `groupBy` e inyectar `organizationId` en el `where`.

#### SEC-07 — `Organization.fiscalData` como Json — sin validación de CUIT
**Archivo:** `prisma/schema.prisma:110` + `prisma/seed.ts:101-113`
**Descripción:** El CUIT se guarda como parte del Json `fiscalData`. No hay validación de formato en la capa de datos. Un CUIT inválido puede ser guardado y luego enviado a AFIP/ARCA, causando rechazos.
**Fix sugerido:** Validar formato CUIT (XX-XXXXXXXX-X) en la capa de API antes de persistir. Considerar extraer CUIT como campo tipado separado con validación.

---

### BAJO

#### SEC-08 — Tokens de AFIP/ARCA (arcaData) almacenados como Json sin cifrado
**Archivo:** `prisma/schema.prisma:380`
**Descripción:** `Invoice.arcaData Json?` almacena datos relacionados con el sistema de facturación electrónica ARCA (ex-AFIP). Si `arcaData` incluye tokens de acceso o certificados, guardarlos en texto plano en la DB es un riesgo.
**Fix sugerido:** Determinar qué datos contiene `arcaData`. Si incluye credenciales o tokens, cifrarlos antes de persistir con una clave de aplicación.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 2        |
| ALTO      | 3        |
| MEDIO     | 2        |
| BAJO      | 1        |
| **Total** | **8**    |
