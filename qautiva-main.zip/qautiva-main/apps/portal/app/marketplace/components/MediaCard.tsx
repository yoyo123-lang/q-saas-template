import Link from 'next/link'
import { MediumPlatform } from '@qautiva/db/types'
import { PLATFORM_LABEL, PLATFORM_COLOR } from '../lib/constants'
import { formatARS, formatNumber } from '@/lib/format'

type Product = {
  id: string
  type: string
  name: string
  price: number
  deliveryDays: number
}

type Category = {
  category: { id: string; name: string; slug: string }
}

export type MediaCardData = {
  id: string
  name: string
  platform: MediumPlatform
  description: string | null
  country: string | null
  followersCount: number | null
  monthlyVisits: number | null
  domainAuthority: number | null
  products: Product[]
  categories: Category[]
  user: { displayName: string | null; avatarUrl: string | null }
}

export function MediaCard({ medium }: { medium: MediaCardData }) {
  const minPrice = medium.products.length > 0 ? (medium.products[0]?.price ?? null) : null
  const platformLabel = PLATFORM_LABEL[medium.platform]
  const platformColor = PLATFORM_COLOR[medium.platform]

  return (
    <article className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4 hover:border-[#334155] transition-colors">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${platformColor}`}>
              {platformLabel}
            </span>
            {medium.country && (
              <span className="text-xs text-[#64748B]">{medium.country.toUpperCase()}</span>
            )}
          </div>
          <h3 className="text-white font-semibold text-sm leading-snug truncate">{medium.name}</h3>
          {medium.user.displayName && (
            <p className="text-[#64748B] text-xs mt-0.5">por {medium.user.displayName}</p>
          )}
        </div>
        {minPrice !== null && (
          <div className="text-right shrink-0">
            <p className="text-xs text-[#64748B]">desde</p>
            <p className="text-white font-bold text-sm">{formatARS(minPrice)}</p>
          </div>
        )}
      </div>

      {/* Descripción */}
      {medium.description && (
        <p className="text-[#94A3B8] text-xs leading-relaxed line-clamp-2">{medium.description}</p>
      )}

      {/* Métricas */}
      <div className="flex gap-4 flex-wrap">
        {medium.followersCount !== null && (
          <div>
            <p className="text-white text-sm font-semibold">{formatNumber(medium.followersCount)}</p>
            <p className="text-[#64748B] text-xs">seguidores</p>
          </div>
        )}
        {medium.monthlyVisits !== null && (
          <div>
            <p className="text-white text-sm font-semibold">{formatNumber(medium.monthlyVisits)}</p>
            <p className="text-[#64748B] text-xs">visitas/mes</p>
          </div>
        )}
        {medium.domainAuthority !== null && (
          <div>
            <p className="text-white text-sm font-semibold">DA {medium.domainAuthority}</p>
            <p className="text-[#64748B] text-xs">autoridad</p>
          </div>
        )}
      </div>

      {/* Categorías */}
      {medium.categories.length > 0 && (
        <div className="flex gap-1 flex-wrap">
          {medium.categories.slice(0, 3).map(({ category }) => (
            <span key={category.id} className="text-xs bg-[#1E293B] text-[#94A3B8] px-2 py-0.5 rounded-full">
              {category.name}
            </span>
          ))}
          {medium.categories.length > 3 && (
            <span className="text-xs text-[#64748B]">+{medium.categories.length - 3}</span>
          )}
        </div>
      )}

      {/* CTA */}
      <Link
        href={`/marketplace/${medium.id}`}
        aria-label={`Ver detalle de ${medium.name}`}
        className="mt-auto block text-center bg-[#1E3A5F] hover:bg-[#1E4D8C] text-[#60A5FA] text-sm font-medium py-2 rounded-lg transition-colors"
      >
        Ver detalle
      </Link>
    </article>
  )
}
