'use client'

import { Suspense, useEffect, useState, useTransition } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import { createClient } from '@/lib/supabase/client'
import { loginSchema, type LoginData } from '@/lib/schemas/auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Divider } from '@/components/ui/divider'

function LoginForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [showPassword, setShowPassword] = useState(false)
  const [isPending, startTransition] = useTransition()
  const [rateLimitCountdown, setRateLimitCountdown] = useState(0)

  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields },
  } = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    mode: 'onBlur',
  })

  useEffect(() => {
    if (rateLimitCountdown <= 0) return
    const timer = setTimeout(() => setRateLimitCountdown((c) => c - 1), 1000)
    return () => clearTimeout(timer)
  }, [rateLimitCountdown])

  const handleGoogleLogin = () => {
    const rawNext = searchParams.get('next')
    const next =
      rawNext && rawNext.startsWith('/') && !rawNext.startsWith('//') ? rawNext : '/dashboard'
    window.location.href = `/api/auth/google?next=${encodeURIComponent(next)}`
  }

  const onSubmit = (data: LoginData) => {
    startTransition(async () => {
      const supabase = createClient()
      const { data: authData, error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      })

      if (error) {
        const code = (error as { code?: string }).code
        if (error.status === 429 || code === 'over_request_rate_limit') {
          setRateLimitCountdown(60)
          toast.error('Demasiados intentos. Esperá 1 minuto antes de reintentar.')
          return
        }
        const messages: Record<string, string> = {
          invalid_credentials: 'Email o contraseña incorrectos.',
          email_not_confirmed: 'Tu cuenta no está verificada. Revisá tu casilla de email.',
          user_not_found: 'Email o contraseña incorrectos.',
        }
        toast.error(messages[code ?? ''] ?? 'Error al iniciar sesión. Intentá de nuevo.')
        return
      }

      const role = authData.user?.user_metadata?.role
      const next = searchParams.get('next')
      // Sanitize next to block protocol-relative URLs like //evil.com
      const safeNext = next && next.startsWith('/') && !next.startsWith('//') ? next : null
      if (safeNext) {
        router.push(safeNext)
      } else if (role === 'ADMIN') {
        router.push('/admin')
      } else {
        router.push('/dashboard')
      }
    })
  }

  const isDisabled = isPending || rateLimitCountdown > 0

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-sm space-y-4">
      <div>
        <h1 className="text-2xl font-semibold text-slate-50">Iniciá sesión</h1>
        <p className="text-sm text-slate-400 mt-1">
          Ingresá a tu cuenta para comprar o vender activos
        </p>
      </div>

      <Button
        type="button"
        variant="ghost"
        size="full"
        className="border border-slate-700 bg-slate-800 hover:border-amber-500/30 hover:bg-slate-800"
        onClick={handleGoogleLogin}
        disabled={isDisabled}
      >
        <GoogleIcon />
        Continuar con Google
      </Button>

      <Divider label="o" />

      <Input
        label="Email"
        type="email"
        placeholder="tu@email.com"
        autoComplete="email"
        {...register('email')}
        error={touchedFields.email ? errors.email?.message : undefined}
      />

      <div className="space-y-1">
        <Input
          label="Contraseña"
          type={showPassword ? 'text' : 'password'}
          autoComplete="current-password"
          suffix={
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="text-slate-400 hover:text-slate-200 transition-colors"
              aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          {...register('password')}
          error={touchedFields.password ? errors.password?.message : undefined}
        />
        <div className="text-right">
          <Link href="/recuperar" className="text-xs text-amber-500 hover:text-amber-400">
            ¿Olvidaste tu contraseña?
          </Link>
        </div>
      </div>

      <Button type="submit" variant="solid" size="full" loading={isPending} disabled={isDisabled}>
        {rateLimitCountdown > 0 ? `Esperá ${rateLimitCountdown}s...` : 'Iniciar sesión'}
      </Button>

      <p className="text-sm text-center text-slate-400">
        ¿No tenés cuenta?{' '}
        <Link href="/registro" className="text-amber-500 hover:text-amber-400">
          Registrate
        </Link>
      </p>
    </form>
  )
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
      <path
        d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"
        fill="#4285F4"
      />
      <path
        d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.836.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z"
        fill="#34A853"
      />
      <path
        d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"
        fill="#FBBC05"
      />
      <path
        d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"
        fill="#EA4335"
      />
    </svg>
  )
}
