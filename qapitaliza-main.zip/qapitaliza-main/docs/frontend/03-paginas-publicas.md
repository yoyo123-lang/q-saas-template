# Páginas Públicas — Especificación Frontend

> Cubre las rutas accesibles sin autenticación: landing, catálogo, detalle de activo, cómo funciona.
> Todas estas rutas son SSR (Server Components en Next.js 15) para SEO.

---

## Rutas cubiertas

| Ruta | Componente page | Renderizado |
|---|---|---|
| `/` | `app/(public)/page.tsx` | SSR |
| `/explorar` | `app/(public)/explorar/page.tsx` | SSR + params de filtro en searchParams |
| `/explorar/[slug]` | `app/(public)/explorar/[slug]/page.tsx` | SSR, genera metadata Open Graph |
| `/como-funciona` | `app/(public)/como-funciona/page.tsx` | SSR estático |

Layout compartido: `app/(public)/layout.tsx` — incluye `<Navbar />` y `<Footer />`.

---

## 1. Landing Page (`/`)

**Archivo:** `app/(public)/page.tsx`

### Secciones (orden vertical)

#### 1.1 Hero

```
Altura: ~70vh mínimo
Fondo: bg-navy-950 + .mesh-gradient-amber (ver design tokens)
```

- `<h1>` → "Comprá, vendé e invertí en activos digitales" — `text-5xl font-bold text-slate-50 text-center max-w-3xl mx-auto`
- Subtítulo → `text-lg text-slate-400 text-center max-w-xl mx-auto mt-4`
- Barra de búsqueda → componente `<HeroSearch />` — input `bg-navy-900 border-slate-800 rounded-xl` con botón "Explorar" amber a la derecha. Al submit: navega a `/explorar?q={query}`
- Stats row → 3 items inline: `text-sm text-slate-500` separados por `·`

**Datos de stats:** hardcodeados en el componente hasta que exista API de métricas.

#### 1.2 Categorías

Componente `<CategoryRow />` — fila horizontal de 5 `<CategoryPill />`.

```ts
const categories = [
  { icon: '🌐', label: 'Sitios Web', count: 42, slug: 'website' },
  { icon: '🔗', label: 'Dominios', count: 28, slug: 'domain' },
  { icon: '💻', label: 'SaaS / MVPs', count: 31, slug: 'saas' },
  { icon: '🛒', label: 'E-commerce', count: 18, slug: 'ecommerce' },
  { icon: '📁', label: 'Proyectos', count: 8, slug: 'project' },
]
```

Click en categoría → `/explorar?category={slug}`

Cada `<CategoryPill>`: `bg-navy-900 border border-slate-800 rounded-xl p-4 hover:border-amber-500/30`

#### 1.3 Activos Destacados

- Heading: "Activos destacados" + `<Link href="/explorar">Ver todos →</Link>`
- Grid: `grid grid-cols-3 gap-6`
- 6 `<ListingCard />` con `badges={['featured']}` o `badges={['verified']}`
- Datos: fetch SSR de `listings` con `featured: true`, limit 6

#### 1.4 Cómo Funciona (resumen)

Componente `<HowItWorks />` — 3 columnas:

```ts
const steps = [
  { number: '01', title: 'Publicá tu activo', description: '...' },
  { number: '02', title: 'Recibí consultas', description: '...' },
  { number: '03', title: 'Cerrá la venta', description: '...' },
]
```

Número grande en `text-amber-500 text-4xl font-bold`.

#### 1.5 CTA Final

Banner con `bg-gradient-to-r from-amber-500/5 to-transparent` + texto + botón "Publicá gratis" → `/registro?rol=seller`

#### 1.6 Footer

Componente `<Footer />` en `src/components/layout/Footer.tsx`.

---

## 2. Catálogo (`/explorar`)

**Archivo:** `app/(public)/explorar/page.tsx`

### searchParams aceptados

| Param | Tipo | Ejemplo |
|---|---|---|
| `q` | string | `?q=saas` |
| `category` | string | `?category=website` |
| `priceMin` | number | `?priceMin=1000` |
| `priceMax` | number | `?priceMax=50000` |
| `revenueMin` | number | `?revenueMin=500` |
| `verified` | boolean | `?verified=true` |
| `tech` | string[] | `?tech=react&tech=nextjs` |
| `sort` | string | `?sort=price_asc` \| `price_desc` \| `newest` \| `views` |
| `page` | number | `?page=2` |

Tamaño de página: 20 items. Máximo: 100.

### Layout

```
<div class="flex gap-8">
  <aside class="w-[280px] shrink-0">   ← FilterSidebar
  <main class="flex-1">                ← ResultsGrid
```

### FilterSidebar

**Archivo:** `src/components/catalog/FilterSidebar.tsx`

Secciones:
1. **Categoría** — checkboxes, cada uno muestra count actualizado
2. **Rango de precio** — 2 inputs numéricos (Mínimo / Máximo en USD)
3. **Revenue mensual** — `<Select>` con opciones fijas
4. **Solo verificados** — toggle switch
5. **Tech Stack** — pills seleccionables (click toggle)
6. Botón "Limpiar filtros" — `variant="ghost" size="sm"`

Comportamiento: al cambiar cualquier filtro → `router.push` con los nuevos searchParams (sin reload).

Opciones de "Revenue mensual":
```ts
[
  { value: '', label: 'Cualquiera' },
  { value: '500', label: '> $500 USD/mes' },
  { value: '1000', label: '> $1,000 USD/mes' },
  { value: '5000', label: '> $5,000 USD/mes' },
]
```

### ResultsGrid

- Barra superior: `"{n} resultados"` + dropdown "Ordenar por"
- Grid: `grid grid-cols-3 gap-6`
- Paginación: `<Pagination currentPage total pageSize />` abajo

**Estado vacío:** `<EmptyState icon={Search} title="Sin resultados" description="Probá con otros filtros" cta="Limpiar filtros" />`

---

## 3. Detalle de activo (`/explorar/[slug]`)

**Archivo:** `app/(public)/explorar/[slug]/page.tsx`

### Metadata dinámica

```ts
export async function generateMetadata({ params }) {
  const listing = await getListing(params.slug)
  return {
    title: `${listing.title} — Qapitaliza`,
    description: listing.description.slice(0, 160),
    openGraph: {
      title: listing.title,
      description: ...,
      images: [listing.screenshots[0]],
    }
  }
}
```

### Layout principal

```
grid grid-cols-[1fr_380px] gap-8
```

#### Columna izquierda (contenido)

1. **Breadcrumb** → `Explorar > {tipo} > {título}` — `text-sm text-slate-500`, links en `text-slate-400`

2. **Header del activo**
   - Título `text-3xl font-semibold text-slate-50`
   - Row de badges: tipo + verificado + destacado (según datos)
   - "Publicado hace X días por {vendedor}" — `text-sm text-slate-500`
   - Precio `text-2xl font-bold text-amber-500`

3. **Galería de screenshots**
   - Imagen principal: `w-full h-64 object-cover rounded-xl bg-slate-800`
   - Thumbnails: row de 4, `h-16 w-24 object-cover rounded-lg cursor-pointer`
   - Click thumbnail → cambia imagen principal

4. **Descripción** — `text-sm text-slate-400 leading-relaxed`

5. **Tech Stack** — pills `<TechPill>`: `bg-slate-800 font-mono text-xs text-slate-50 px-3 py-1 rounded-full`

6. **Métricas** — grid `grid grid-cols-3 gap-4`

   Cada stat card de métrica:
   ```
   bg-navy-900 border border-slate-800 rounded-xl p-4
   ```
   - Ícono + label (`text-xs text-slate-500 uppercase tracking-wider`)
   - Valor (`text-xl font-bold text-slate-50`)
   - Trend opcional (`text-xs text-emerald-500`)

   Nota "Métricas verificadas por Qapitaliza ✓" → `text-sm text-emerald-500 mt-2`

#### Columna derecha (sidebar sticky)

`sticky top-24` — se queda fija al hacer scroll.

**Card de acción:**
```
bg-navy-900 border border-slate-800 rounded-xl p-6
```
- Precio grande: `text-2xl font-bold text-amber-500`
- `<Button variant="solid" size="full">Consultar al vendedor</Button>` → abre modal o navega a `/consultas/nueva?listing={id}`
- `<Button variant="outline" size="full">♡ Guardar en favoritos</Button>` — si logueado: toggle favorite; si no: redirige a `/login`
- Divider
- Info vendedor: avatar iniciales + nombre + "Vendedor verificado ✓" en `text-emerald-500` + "X activos · Miembro desde {año}"
- `<Link href="/perfil/{sellerId}">Ver perfil →</Link>`

**Card de seguridad:**
```
bg-navy-900 border border-amber-500/20 rounded-xl p-4
```
- "🔒 Transacción segura"
- Lista con `<Check size={14} className="text-emerald-500" />` por cada item

### Activos relacionados

Full-width debajo del grid. `grid grid-cols-3 gap-6` con 3 `<ListingCard />` del mismo tipo/precio similar.

---

## 4. Cómo funciona (`/como-funciona`)

**Archivo:** `app/(public)/como-funciona/page.tsx`

Página estática. Sin fetch de datos.

### Secciones

1. **Hero** — título + subtítulo centrado + mesh gradient amber

2. **Timeline Vendedores** — componente `<Timeline steps={sellerSteps} />`

   Estructura de timeline:
   ```
   Línea vertical: border-l-2 border-slate-800 ml-6
   Dot activo: w-3 h-3 bg-amber-500 rounded-full -ml-[7px]
   ```

   ```ts
   const sellerSteps = [
     { icon: UserPlus, title: 'Registrate gratis', description: '...' },
     { icon: Upload, title: 'Publicá tu activo', description: '...' },
     { icon: MessageCircle, title: 'Recibí consultas', description: '...' },
     { icon: Handshake, title: 'Cerrá la venta', description: '...' },
   ]
   ```

3. **Timeline Compradores** — mismo componente, `buyerSteps`

4. **Verificación** — `<VerificationBanner />`: card centrada con borde amber/20, 3 columnas con check verde

5. **FAQ** — `<AccordionFAQ items={faqItems} />`

   Comportamiento: click en pregunta → expand/collapse con animación CSS. Solo una abierta a la vez.

   ```ts
   const faqItems = [
     { q: '¿Cuánto cuesta publicar un activo?', a: '...' },
     { q: '¿Qué tipos de activos puedo vender?', a: '...' },
     // 6 items total
   ]
   ```

6. **CTA Final** — 2 botones: "Publicá tu activo" (solid) + "Explorá el catálogo" (outline)

---

## 5. Metadata SEO global

**Archivo:** `app/layout.tsx`

```ts
export const metadata: Metadata = {
  metadataBase: new URL('https://qapitaliza.com'),
  title: {
    default: 'Qapitaliza — Marketplace de activos digitales',
    template: '%s — Qapitaliza',
  },
  description: 'Comprá, vendé e invertí en sitios web, dominios, MVPs y proyectos digitales.',
  openGraph: {
    siteName: 'Qapitaliza',
    locale: 'es_AR',
    type: 'website',
  },
}
```

### Sitemap

**Archivo:** `app/sitemap.ts`

Generar dinámicamente:
- Rutas estáticas: `/`, `/explorar`, `/como-funciona`, `/login`, `/registro`
- Rutas de activos publicados: `/explorar/{slug}` para cada listing con status `PUBLISHED`
- Actualización: `revalidate: 3600` (1 hora)
