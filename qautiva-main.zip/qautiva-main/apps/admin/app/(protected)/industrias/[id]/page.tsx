import { Suspense } from 'react'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import { IndustriaTabs } from './_components/IndustriaTabs'
import { TabPreguntas } from './_components/TabPreguntas'
import { TabKeywords } from './_components/TabKeywords'
import { TabPaletas } from './_components/TabPaletas'
import { TabCampanas } from './_components/TabCampanas'

const VALID_TABS = ['preguntas', 'keywords', 'paletas', 'campanas'] as const
type TabId = typeof VALID_TABS[number]

export default async function IndustriaDetailPage({
  params,
  searchParams,
}: {
  params: { id: string }
  searchParams: { tab?: string }
}) {
  const industry = await prisma.industryTemplate.findUnique({
    where: { id: params.id },
  })

  if (!industry) {
    notFound()
  }

  const rawTab = searchParams.tab ?? 'preguntas'
  const activeTab: TabId = (VALID_TABS as readonly string[]).includes(rawTab)
    ? (rawTab as TabId)
    : 'preguntas'

  const questions = industry.questions as Record<string, unknown>
  const keywords = (industry.keywords as string[]) ?? []
  const colorPalettes = (industry.colorPalettes as { name: string; colors: string[] }[]) ?? []
  const campaignBase = industry.campaignBase as {
    presupuestoMin: number
    presupuestoMax: number
    presupuestoTipico: number
    plataformas: string[]
    keywords: string[]
  } | null

  return (
    <div className="p-8 max-w-4xl">
      {/* Breadcrumb */}
      <Link
        href="/industrias"
        className="inline-flex items-center gap-1 text-sm text-[#64748B] hover:text-[#94A3B8] mb-6 transition-colors"
      >
        ← Industrias
      </Link>

      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">{industry.name}</h1>
        <p className="text-[#64748B] text-sm mt-1">
          {industry.clientCount} cliente(s) · Tasa de éxito: {(industry.successRate * 100).toFixed(1)}%
        </p>
      </div>

      {/* Tabs — Suspense porque IndustriaTabs usa useSearchParams */}
      <Suspense fallback={<div className="h-10 border-b border-[#1E293B]" />}>
        <IndustriaTabs activeTab={activeTab} industryId={params.id} />
      </Suspense>

      {/* Contenido del tab activo */}
      <div className="mt-6">
        {activeTab === 'preguntas' && (
          <TabPreguntas industryId={params.id} questions={questions} />
        )}
        {activeTab === 'keywords' && (
          <TabKeywords industryId={params.id} keywords={keywords} />
        )}
        {activeTab === 'paletas' && (
          <TabPaletas industryId={params.id} colorPalettes={colorPalettes} />
        )}
        {activeTab === 'campanas' && (
          <TabCampanas
            industryId={params.id}
            campaignBase={campaignBase}
            webTemplate={industry.webTemplate ?? ''}
          />
        )}
      </div>
    </div>
  )
}
