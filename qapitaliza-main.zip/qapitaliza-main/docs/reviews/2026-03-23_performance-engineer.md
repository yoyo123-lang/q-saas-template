# Revisión: Performance Engineer
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de Performance Engineer

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 2 altos, 2 medios, 1 bajo

## Hallazgos

### [ALTO → CORREGIDO] `incrementListingViews` bloqueaba el renderizado SSR
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Problema: Un `await` síncrono de un DB write en cada page view bloqueaba el renderizado completo hasta que la query terminara.
- Fix aplicado: Fire-and-forget con `void (async () => {...})()` — el renderizado no espera.

### [ALTO → CORREGIDO] Sitemap sin límite podía fetchear 10k+ listings de golpe
- Dónde: `src/app/sitemap.ts`
- Problema: `findMany` sin `take` cargaba todos los listings publicados en memoria.
- Fix aplicado: `take: 1000` — límite razonable para un sitemap bien indexado.

### [MEDIO] `getListings` y `getListing` incluyen todas las columnas de relaciones
- Dónde: `src/lib/data/listings.ts:100–108`
- Problema: `include: { seller: true, metrics: true, category: true }` trae TODOS los campos de cada relación. Para el listado del catálogo, se necesitan solo algunos campos del seller (nombre, avatarUrl).
- Recomendación: Usar `select` dentro del `include` para proyectar solo los campos necesarios. Implementar en Sesión 03.

### [MEDIO] Landing page usa SSR con `featuredUntil > now` — no cacheable estáticamente
- Dónde: `src/app/page.tsx`
- Problema: La landing es SSR puro. Para una landing de marketplace, sería más eficiente ISR (Incremental Static Regeneration) con revalidación cada 15-30 minutos.
- Recomendación: Agregar `export const revalidate = 900` en la landing. Las stats de activos destacados no cambian por minuto.

### [BAJO] `getRelatedListings` no tiene índice óptimo para el filtro combinado `status + type`
- Dónde: `src/lib/data/listings.ts:128–142`
- Aclaración: El schema SÍ tiene `@@index([status, type])` — este hallazgo no aplica. ✓

## Lo que está bien
- Paginación implementada correctamente en `getListings` (20 por página, máx 100).
- `next/image` usado en todas las imágenes — optimización automática de formato y tamaño.
- Índices en `publishedAt`, `status`, `type`, `sellerId`, `categoryId` — queries del catálogo están cubiertos.
- `Promise.all` en `incrementListingViews` para escribir el update y el audit log en paralelo.
- Filtro de tech stack usa `has` por cada elemento — eficiente para arrays pequeños.

## Recomendaciones generales
- Agregar `revalidate` a la landing page (ISR).
- Proyectar solo campos necesarios en `include` del DAL.
- Monitorear tiempos de respuesta del catálogo cuando haya 1k+ listings.
