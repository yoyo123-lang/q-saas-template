-- Rollback migration 012
DROP INDEX IF EXISTS idx_profiles_suspended_at;
ALTER TABLE profiles DROP COLUMN IF EXISTS suspended_at;
