'use client'

import { useEffect } from 'react'

interface ErrorBoundaryProps {
  error: Error & { digest?: string }
  reset: () => void
}

export default function ClienteError({ error, reset }: ErrorBoundaryProps) {
  useEffect(() => {
    console.error('[admin:cliente-error]', error)
  }, [error])

  return (
    <div className="flex flex-col items-center justify-center flex-1 gap-4 p-6">
      <p className="text-[#EF4444] font-semibold text-lg">No se pudo cargar el cliente</p>
      <p className="text-[#64748B] text-sm">Ocurrió un error al cargar los datos.</p>
      {error.digest && (
        <p className="text-[#475569] text-xs font-mono">Ref: {error.digest}</p>
      )}
      <button
        onClick={reset}
        className="px-4 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
      >
        Reintentar
      </button>
    </div>
  )
}
