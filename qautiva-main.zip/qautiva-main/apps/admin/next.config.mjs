import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = fileURLToPath(new URL('.', import.meta.url))

/** @type {import('next').NextConfig} */
const config = {
  outputFileTracingRoot: path.join(__dirname, '../../'),
  experimental: {
    outputFileTracingIncludes: {
      '/**': ['../../packages/db/generated/client/**'],
    },
    // Next.js 14: las external packages van dentro de experimental
    serverComponentsExternalPackages: [
      'handlebars',
      'google-ads-api',
      'google-ads-node',
      '@grpc/grpc-js',
      '@grpc/proto-loader',
    ],
  },
  transpilePackages: ['@qautiva/db', '@qautiva/ads', '@qautiva/stitch'],
  webpack(config, { isServer }) {
    if (isServer) {
      // canvas es un addon nativo — no se puede bundlear
      config.externals.push('canvas', 'sharp')
    }
    return config
  },
  env: {
    NEXT_PUBLIC_SUPABASE_URL:
      process.env.NEXT_PUBLIC_SUPABASE_URL ?? 'https://placeholder.supabase.co',
    NEXT_PUBLIC_SUPABASE_ANON_KEY:
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? 'placeholder-anon-key',
  },
  images: {
    formats: ['image/avif', 'image/webp'],
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
    ]
  },
}

export default config
