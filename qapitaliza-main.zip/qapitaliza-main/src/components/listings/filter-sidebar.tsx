'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import { useCallback, useState } from 'react'
import { SlidersHorizontal, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils/cn'

const categories = [
  { slug: 'website', label: 'Sitios Web' },
  { slug: 'domain', label: 'Dominios' },
  { slug: 'saas', label: 'SaaS / MVPs' },
  { slug: 'ecommerce', label: 'E-commerce' },
  { slug: 'project', label: 'Proyectos' },
]

const revenueOptions = [
  { value: '', label: 'Cualquiera' },
  { value: '500', label: '> $500 USD/mes' },
  { value: '1000', label: '> $1,000 USD/mes' },
  { value: '5000', label: '> $5,000 USD/mes' },
]

const popularTech = [
  'Next.js', 'React', 'Node.js', 'Laravel', 'WordPress',
  'Stripe', 'Shopify', 'Python', 'Vue.js', 'Django',
]

export function FilterSidebar() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const push = useCallback(
    (updates: Record<string, string | string[] | null>) => {
      const params = new URLSearchParams(searchParams.toString())
      // Reset to page 1 on filter change
      params.delete('page')

      for (const [key, value] of Object.entries(updates)) {
        if (value === null || value === '') {
          params.delete(key)
        } else if (Array.isArray(value)) {
          params.delete(key)
          value.forEach((v) => params.append(key, v))
        } else {
          params.set(key, value)
        }
      }
      router.push(`/explorar?${params.toString()}`)
    },
    [router, searchParams]
  )

  const activeCategory = searchParams.get('category') ?? ''
  const priceMinParam = searchParams.get('priceMin') ?? ''
  const priceMaxParam = searchParams.get('priceMax') ?? ''
  const revenueMin = searchParams.get('revenueMin') ?? ''
  const verified = searchParams.get('verified') === 'true'
  const activeTech = searchParams.getAll('tech')

  // Local state for price inputs to avoid navigating on every keystroke
  const [localPriceMin, setLocalPriceMin] = useState(priceMinParam)
  const [localPriceMax, setLocalPriceMax] = useState(priceMaxParam)
  const [mobileOpen, setMobileOpen] = useState(false)

  function toggleTech(tech: string) {
    const next = activeTech.includes(tech)
      ? activeTech.filter((t) => t !== tech)
      : [...activeTech, tech]
    push({ tech: next.length > 0 ? next : null })
  }

  function clearFilters() {
    setLocalPriceMin('')
    setLocalPriceMax('')
    router.push('/explorar')
  }

  const inputClass =
    'w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-50 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all'

  const filterContent = (
    <div className="space-y-6">
      {/* Categoría */}
      <div>
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Categoría
        </h3>
        <div className="space-y-2">
          {categories.map((cat) => (
            <label key={cat.slug} className="flex items-center gap-2.5 cursor-pointer group">
              <input
                type="checkbox"
                checked={activeCategory === cat.slug}
                onChange={() =>
                  push({ category: activeCategory === cat.slug ? null : cat.slug })
                }
                className="size-4 rounded border-slate-700 bg-slate-800 accent-amber-500 cursor-pointer"
              />
              <span className="text-sm text-slate-400 group-hover:text-slate-200 transition-colors">
                {cat.label}
              </span>
            </label>
          ))}
        </div>
      </div>

      <div className="h-px bg-slate-800" />

      {/* Rango de precio */}
      <div>
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Precio (USD)
        </h3>
        <div className="flex gap-2">
          <input
            type="number"
            placeholder="Mínimo"
            value={localPriceMin}
            onChange={(e) => setLocalPriceMin(e.target.value)}
            onBlur={(e) => push({ priceMin: e.target.value || null })}
            className={inputClass}
          />
          <input
            type="number"
            placeholder="Máximo"
            value={localPriceMax}
            onChange={(e) => setLocalPriceMax(e.target.value)}
            onBlur={(e) => push({ priceMax: e.target.value || null })}
            className={inputClass}
          />
        </div>
      </div>

      <div className="h-px bg-slate-800" />

      {/* Revenue mensual */}
      <div>
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Revenue mensual
        </h3>
        <select
          value={revenueMin}
          onChange={(e) => push({ revenueMin: e.target.value || null })}
          className={inputClass}
        >
          {revenueOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      <div className="h-px bg-slate-800" />

      {/* Solo verificados */}
      <div>
        <label htmlFor="filter-verified" className="flex items-center gap-3 cursor-pointer">
          {/* Visually hidden checkbox — accesible por teclado y lector de pantalla */}
          <input
            id="filter-verified"
            type="checkbox"
            checked={verified}
            onChange={() => push({ verified: verified ? null : 'true' })}
            className="sr-only"
          />
          {/* Presentación visual del toggle */}
          <div
            aria-hidden="true"
            className={`relative w-10 h-5 rounded-full transition-colors ${
              verified ? 'bg-amber-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-0.5 left-0.5 size-4 rounded-full bg-white shadow transition-transform ${
                verified ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </div>
          <span className="text-sm text-slate-400">Solo verificados</span>
        </label>
      </div>

      <div className="h-px bg-slate-800" />

      {/* Tech Stack */}
      <div>
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Tech Stack
        </h3>
        <div className="flex flex-wrap gap-2">
          {popularTech.map((tech) => (
            <button
              key={tech}
              onClick={() => toggleTech(tech)}
              className={`font-mono text-xs px-3 py-1 rounded-full border transition-colors ${
                activeTech.includes(tech)
                  ? 'bg-amber-500/15 border-amber-500/50 text-amber-500'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600 hover:text-slate-200'
              }`}
            >
              {tech}
            </button>
          ))}
        </div>
      </div>

      <div className="h-px bg-slate-800" />

      <Button variant="ghost" size="sm" onClick={clearFilters} className="w-full justify-center">
        Limpiar filtros
      </Button>
    </div>
  )

  return (
    <>
      {/* Mobile filter toggle button */}
      <div className="lg:hidden mb-4">
        <button
          onClick={() => setMobileOpen((v) => !v)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-700 text-sm text-slate-300 hover:border-slate-500 hover:text-slate-50 transition-colors"
        >
          <SlidersHorizontal className="size-4" />
          Filtros
        </button>

        {/* Mobile inline drawer */}
        {mobileOpen && (
          <div className="mt-3 bg-navy-900 border border-slate-800 rounded-xl p-5 relative">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-50 transition-colors"
              aria-label="Cerrar filtros"
            >
              <X className="size-4" />
            </button>
            {filterContent}
          </div>
        )}
      </div>

      {/* Desktop sidebar — always visible */}
      <aside className={cn('hidden lg:block w-[280px] shrink-0')}>
        {filterContent}
      </aside>
    </>
  )
}
