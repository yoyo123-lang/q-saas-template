'use client'

import { useState } from 'react'
import {
  saveIntegrationConfig,
  saveTelegramConfig,
} from '@/app/(protected)/configuracion/actions'
import type { ActionState } from '@/app/(protected)/configuracion/actions'
import type { IntegrationConfig, TelegramConfig } from '@qautiva/db'
import { SubmitButton, StatusMessage } from './shared'

interface Props {
  integrations: IntegrationConfig[]
  telegramConfig: TelegramConfig | null
}

const SERVICE_LABELS: Record<string, string> = {
  SERPER: 'Serper (búsqueda web)',
  RESEND: 'Resend (emails)',
  OPENAI_IMAGES: 'OpenAI Images',
  GA4: 'Google Analytics 4',
  META_PIXEL: 'Meta Pixel',
}

const ALL_SERVICES = ['SERPER', 'RESEND', 'OPENAI_IMAGES', 'GA4', 'META_PIXEL']


function IntegrationCard({ service, integration }: {
  service: string
  integration: IntegrationConfig | undefined
}) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await saveIntegrationConfig(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-white font-medium text-sm">
          {SERVICE_LABELS[service] ?? service}
        </h3>
        {integration?.lastTestedAt && (
          <span className="text-xs text-[#475569]">
            Último test: {new Date(integration.lastTestedAt).toLocaleDateString('es-AR')}
          </span>
        )}
      </div>

      {integration?.lastError && (
        <p className="text-xs text-red-400 bg-red-900/20 border border-red-900/30 rounded px-3 py-2">
          {integration.lastError}
        </p>
      )}

      <form action={handleSubmit} className="space-y-3">
        <input type="hidden" name="service" value={service} />

        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            name="isActive"
            defaultChecked={integration?.isActive ?? false}
            className="w-4 h-4 rounded border-[#1E293B] bg-[#0B0F1A] accent-[#8B5CF6]"
          />
          <span className="text-sm text-[#94A3B8]">Activo</span>
        </label>

        <div className="flex flex-col gap-1.5">
          <label htmlFor={`rawKey-${service}`} className="text-xs text-[#94A3B8] font-medium">API Key</label>
          <input
            id={`rawKey-${service}`}
            type="password"
            name="rawKey"
            placeholder={integration?.keyHint ? `Actual: ${integration.keyHint}` : 'Ingresá la API key'}
            className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6] placeholder-[#475569]"
          />
          {integration?.keyHint && (
            <p className="text-xs text-[#475569]">
              Dejá vacío para mantener la key actual ({integration.keyHint})
            </p>
          )}
        </div>

        <div className="flex items-center gap-3">
          <SubmitButton pending={isPending} />
          <StatusMessage state={state} />
        </div>
      </form>
    </div>
  )
}

function TelegramCard({ telegramConfig }: { telegramConfig: TelegramConfig | null }) {
  const [state, setState] = useState<ActionState | null>(null)
  const [isPending, setIsPending] = useState(false)

  async function handleSubmit(formData: FormData) {
    setIsPending(true)
    try {
      const result = await saveTelegramConfig(null, formData)
      setState(result)
    } finally {
      setIsPending(false)
    }
  }

  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 space-y-4">
      <h3 className="text-white font-medium text-sm">Bot de Telegram</h3>

      <form action={handleSubmit} className="space-y-4">
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            name="botEnabled"
            defaultChecked={telegramConfig?.botEnabled ?? true}
            className="w-4 h-4 rounded border-[#1E293B] bg-[#0B0F1A] accent-[#8B5CF6]"
          />
          <span className="text-sm text-[#94A3B8]">Bot habilitado</span>
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="llmModel" className="text-xs text-[#94A3B8] font-medium">Modelo LLM</label>
            <input
              id="llmModel"
              type="text"
              name="llmModel"
              defaultValue={telegramConfig?.llmModel ?? 'claude-haiku-4-5-20251001'}
              required
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="rateLimitPerHour" className="text-xs text-[#94A3B8] font-medium">Límite por hora</label>
            <input
              id="rateLimitPerHour"
              type="number"
              name="rateLimitPerHour"
              defaultValue={telegramConfig?.rateLimitPerHour ?? 20}
              min={1}
              required
              className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="systemPromptOverride" className="text-xs text-[#94A3B8] font-medium">
            Override de system prompt (opcional)
          </label>
          <textarea
            id="systemPromptOverride"
            name="systemPromptOverride"
            defaultValue={telegramConfig?.systemPromptOverride ?? ''}
            rows={4}
            placeholder="Dejá vacío para usar el prompt por defecto"
            className="bg-[#0B0F1A] border border-[#1E293B] text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#8B5CF6] placeholder-[#475569] resize-y"
          />
        </div>

        <div className="flex items-center gap-3">
          <SubmitButton label="Guardar configuración de Telegram" pending={isPending} />
          <StatusMessage state={state} />
        </div>
      </form>
    </div>
  )
}

export function IntegracionesTab({ integrations, telegramConfig }: Props) {
  const integrationMap = new Map(integrations.map((i) => [i.service, i]))

  return (
    <div className="space-y-8 mt-6">
      <section className="space-y-4">
        <h2 className="text-white font-semibold text-base">Servicios externos</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {ALL_SERVICES.map((service) => (
            <IntegrationCard
              key={service}
              service={service}
              integration={integrationMap.get(service)}
            />
          ))}
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-white font-semibold text-base">Telegram</h2>
        <TelegramCard telegramConfig={telegramConfig} />
      </section>
    </div>
  )
}
