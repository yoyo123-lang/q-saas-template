'use client'

/**
 * Visor legible de un deliverable tipo CAMPAIGN_PLAN.
 * Reemplaza el JSON crudo con secciones estructuradas.
 * Mantiene un toggle "Ver JSON" para debugging.
 */

import { useState } from 'react'

type CampaignPlan = {
  resumen?: {
    objetivos?: string
    duracionEstimada?: string
    presupuestoRecomendado?: { min?: number; max?: number; justificacion?: string }
  }
  plataformas?: Array<{
    nombre?: string
    razon?: string
    formatos?: Array<{ tipo?: string; presupuestoSugerido?: number }>
  }>
  audiencias?: Array<{ nombre?: string; descripcion?: string; tamanioEstimado?: string; criterios?: string[] }>
  oferta?: { mensajePrincipal?: string; callToAction?: string; variantesCreativas?: string[] }
  calendario?: Array<{ fase?: string; duracion?: string; actividades?: string[]; presupuesto?: number }>
  metricas?: { kpisObjetivo?: Array<{ nombre?: string; meta?: string }> }
  disclaimer?: string
}

const PLATFORM_LABEL: Record<string, string> = {
  GOOGLE_ADS: 'Google Ads',
  META: 'Meta Ads',
}

function formatARS(n?: number): string {
  if (n === undefined || n === null) return '—'
  return '$' + n.toLocaleString('es-AR')
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  if (!value) return null
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[10px] text-[#64748B] uppercase tracking-wider">{label}</span>
      <span className="text-sm text-[#94A3B8]">{value}</span>
    </div>
  )
}

type Props = { data: unknown }

export function CampaignPlanViewer({ data }: Props) {
  const [showJson, setShowJson] = useState(false)

  let plan: CampaignPlan
  try {
    plan = (typeof data === 'string' ? JSON.parse(data) : data) as CampaignPlan
  } catch {
    return <pre className="text-xs text-[#94A3B8] whitespace-pre-wrap">{String(data)}</pre>
  }

  if (!plan || typeof plan !== 'object') {
    return <pre className="text-xs text-[#94A3B8] whitespace-pre-wrap">{JSON.stringify(data, null, 2)}</pre>
  }

  return (
    <div className="space-y-4 mt-2">
      {plan.disclaimer && (
        <p className="text-[10px] text-[#475569] italic">{plan.disclaimer}</p>
      )}

      {/* Resumen */}
      {plan.resumen && (
        <div className="space-y-2">
          <Row label="Objetivo" value={plan.resumen.objetivos} />
          <Row label="Duración" value={plan.resumen.duracionEstimada} />
          {plan.resumen.presupuestoRecomendado && (
            <Row
              label="Presupuesto mensual"
              value={`${formatARS(plan.resumen.presupuestoRecomendado.min)} – ${formatARS(plan.resumen.presupuestoRecomendado.max)}`}
            />
          )}
        </div>
      )}

      {/* Plataformas */}
      {(plan.plataformas ?? []).length > 0 && (
        <div>
          <p className="text-[10px] text-[#64748B] uppercase tracking-wider mb-1.5">Plataformas</p>
          <div className="flex flex-wrap gap-1.5">
            {plan.plataformas!.map((p, i) => (
              <span key={i} className="px-2 py-0.5 rounded-md bg-[#1E293B] text-xs text-[#94A3B8]">
                {PLATFORM_LABEL[p.nombre ?? ''] ?? p.nombre}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Audiencias */}
      {(plan.audiencias ?? []).length > 0 && (
        <div>
          <p className="text-[10px] text-[#64748B] uppercase tracking-wider mb-1.5">Audiencias</p>
          <div className="space-y-1.5">
            {plan.audiencias!.map((a, i) => (
              <div key={i} className="text-xs text-[#94A3B8]">
                <span className="font-medium text-white">{a.nombre}</span>
                {a.tamanioEstimado && <span className="text-[#475569]"> · {a.tamanioEstimado}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Oferta */}
      {plan.oferta?.mensajePrincipal && (
        <Row label="Mensaje principal" value={plan.oferta.mensajePrincipal} />
      )}

      {/* KPIs */}
      {(plan.metricas?.kpisObjetivo ?? []).length > 0 && (
        <div>
          <p className="text-[10px] text-[#64748B] uppercase tracking-wider mb-1.5">KPIs objetivo</p>
          <div className="flex flex-wrap gap-2">
            {plan.metricas!.kpisObjetivo!.map((kpi, i) => (
              <div key={i} className="px-2 py-1 rounded-md bg-[#0B0F1A] border border-[#1E293B]">
                <p className="text-[10px] text-[#64748B]">{kpi.nombre}</p>
                <p className="text-xs font-medium text-white">{kpi.meta}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Toggle JSON */}
      <button
        type="button"
        onClick={() => setShowJson((v) => !v)}
        className="flex items-center gap-1.5 text-[10px] text-[#475569] hover:text-[#64748B] transition-colors mt-1"
      >
        <span className="font-mono">{showJson ? '▾' : '▸'}</span>
        Ver JSON crudo
      </button>
      {showJson && (
        <pre className="p-3 rounded-lg bg-[#0B0F1A] border border-[#1E293B] text-[#94A3B8] text-xs font-mono overflow-x-auto max-h-64 overflow-y-auto whitespace-pre-wrap break-words">
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  )
}
