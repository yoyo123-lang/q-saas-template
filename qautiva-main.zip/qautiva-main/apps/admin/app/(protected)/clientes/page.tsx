import type { Metadata } from 'next'
import { prisma, OrgStatus, Plan } from '@qautiva/db'
import { unstable_cache } from 'next/cache'
import Link from 'next/link'
import { relativeTime, deriveClientStatus } from '@/lib/org-utils'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'Clientes | Qautiva Admin',
  description: 'Listado completo de clientes',
}

// ── Tipos ─────────────────────────────────────────────────────────────────────

type ClientStatus = 'En proceso' | 'Espera cliente' | 'Espera revisión'
type ClientPlan = 'Base' | 'Completo' | 'Premium'
type ClientStage =
  | 'Descubrimiento'
  | 'Investigación'
  | 'Marca'
  | 'Web'
  | 'Campañas'
  | 'Medios'
  | 'Completado'
  | 'Pausado'

interface ClientRow {
  id: string
  businessName: string
  industry: string
  plan: ClientPlan
  status: ClientStatus | 'Pausado'
  stage: ClientStage
  updatedLabel: string
  isPaused: boolean
}

// ── Constantes ────────────────────────────────────────────────────────────────

const ORG_STATUS_TO_STAGE: Record<OrgStatus, ClientStage> = {
  [OrgStatus.DISCOVERY]:  'Descubrimiento',
  [OrgStatus.RESEARCH]:   'Investigación',
  [OrgStatus.BRAND]:      'Marca',
  [OrgStatus.WEBSITE]:    'Web',
  [OrgStatus.CAMPAIGNS]:  'Campañas',
  [OrgStatus.MEDIA]:      'Medios',
  [OrgStatus.LAUNCHED]:   'Completado',
  [OrgStatus.PAUSED]:     'Pausado',
}

const PLAN_LABEL: Record<Plan, ClientPlan> = {
  [Plan.BASE]:     'Base',
  [Plan.COMPLETO]: 'Completo',
  [Plan.PREMIUM]:  'Premium',
}

const STAGE_BADGE: Record<ClientStage, string> = {
  'Descubrimiento': 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30',
  'Investigación':  'bg-[#06B6D4]/15 text-[#22D3EE] border border-[#06B6D4]/30',
  'Marca':          'bg-[#EC4899]/15 text-[#F472B6] border border-[#EC4899]/30',
  'Web':            'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30',
  'Campañas':       'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30',
  'Medios':         'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30',
  'Completado':     'bg-[#10B981]/20 text-[#34D399] border border-[#10B981]/40',
  'Pausado':        'bg-[#1E293B] text-[#475569] border border-[#334155]',
}

const STATUS_BADGE: Record<string, string> = {
  'En proceso':      'bg-[#1E293B] text-[#94A3B8]',
  'Espera cliente':  'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30',
  'Espera revisión': 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30',
  'Pausado':         'bg-[#1E293B] text-[#475569] border border-[#334155]',
}

const PLAN_BADGE: Record<ClientPlan, string> = {
  Base:     'bg-[#1E293B] text-[#64748B]',
  Completo: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30',
  Premium:  'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30',
}

// ── Helpers ───────────────────────────────────────────────────────────────────
// relativeTime y deriveClientStatus importados desde @/lib/org-utils

// ── Carga de datos ────────────────────────────────────────────────────────────

const fetchAllClients = unstable_cache(
  async (): Promise<ClientRow[]> => {
    const orgs = await prisma.organization.findMany({
      select: {
        id: true,
        name: true,
        industry: true,
        plan: true,
        status: true,
        updatedAt: true,
        stages: { select: { status: true } },
      },
      orderBy: { updatedAt: 'desc' },
      take: 500,
    })

    return orgs.map((org) => {
      const isPaused = org.status === OrgStatus.PAUSED
      const stage = ORG_STATUS_TO_STAGE[org.status]
      const status: ClientRow['status'] = isPaused
        ? 'Pausado'
        : deriveClientStatus(org.stages.map((s) => s.status))

      return {
        id: org.id,
        businessName: org.name,
        industry: org.industry,
        plan: PLAN_LABEL[org.plan] ?? 'Base',
        status,
        stage,
        updatedLabel: relativeTime(org.updatedAt),
        isPaused,
      }
    })
  },
  ['admin-all-clients'],
  { revalidate: 30 },
)

// ── Filtrado ──────────────────────────────────────────────────────────────────

function applyFilters(clients: ClientRow[], q?: string): ClientRow[] {
  const trimmed = q?.trim()
  if (!trimmed) return clients
  const lower = trimmed.toLowerCase()
  return clients.filter((c) => c.businessName.toLowerCase().includes(lower))
}

// ── Página ────────────────────────────────────────────────────────────────────

interface PageProps {
  searchParams: { q?: string }
}

export default async function ClientesPage({ searchParams }: PageProps) {
  let clients: ClientRow[]
  try {
    clients = await fetchAllClients()
  } catch (err) {
    console.error('[admin:clientes] error cargando clientes:', err)
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold text-white">Clientes</h1>
        <p className="text-[#EF4444] mt-4">Error al cargar los clientes. Verificá la conexión con la base de datos.</p>
      </div>
    )
  }

  const filtered = applyFilters(clients, searchParams.q)
  const activeCount = clients.filter((c) => !c.isPaused).length
  const pausedCount = clients.filter((c) => c.isPaused).length

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Clientes</h1>
          <p className="text-[#94A3B8] mt-1 text-sm">
            {activeCount} activos · {pausedCount} pausados
          </p>
        </div>
      </div>

      {/* Búsqueda */}
      <form method="GET" className="flex gap-2 items-center">
        <label htmlFor="q" className="sr-only">Buscar cliente por nombre</label>
        <input
          id="q"
          type="text"
          name="q"
          defaultValue={searchParams.q ?? ''}
          placeholder="Buscar por nombre..."
          className="px-3 py-2 rounded-lg bg-[#0B0F1A] border border-[#1E293B] text-white placeholder:text-[#475569] text-sm focus:outline-none focus:border-[#8B5CF6] w-64"
        />
        <button
          type="submit"
          className="px-3 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
        >
          Buscar
        </button>
        {searchParams.q && (
          <Link
            href="/clientes"
            className="px-3 py-2 rounded-lg bg-[#1E293B] text-[#94A3B8] text-sm hover:bg-[#334155] transition-colors"
          >
            Limpiar
          </Link>
        )}
      </form>

      {/* Tabla */}
      {filtered.length === 0 ? (
        <p className="text-[#475569] text-sm">Sin clientes para mostrar.</p>
      ) : (
        <div className="rounded-xl border border-[#1E293B] bg-[#0B0F1A] overflow-hidden overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="border-b border-[#1E293B]">
                <th className="text-left px-4 py-3 text-xs font-semibold text-[#64748B] uppercase tracking-wider">Cliente</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-[#64748B] uppercase tracking-wider">Industria</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-[#64748B] uppercase tracking-wider">Etapa</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-[#64748B] uppercase tracking-wider">Estado</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-[#64748B] uppercase tracking-wider">Plan</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-[#64748B] uppercase tracking-wider">Última actividad</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]">
              {filtered.map((client) => (
                <tr
                  key={client.id}
                  className="hover:bg-[#0F172A] transition-colors"
                >
                  <td className="px-4 py-3 max-w-[220px]">
                    <Link
                      href={`/clientes/${client.id}`}
                      className="text-white font-medium hover:text-[#8B5CF6] transition-colors truncate block"
                      title={client.businessName}
                    >
                      {client.businessName}
                    </Link>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-[#94A3B8] text-xs">{client.industry}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${STAGE_BADGE[client.stage]}`}>
                      {client.stage}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${STATUS_BADGE[client.status]}`}>
                      {client.status === 'Espera revisión' && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] animate-pulse flex-shrink-0" aria-hidden="true" />
                      )}
                      {client.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${PLAN_BADGE[client.plan]}`}>
                      {client.plan}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-[#64748B] text-xs">{client.updatedLabel}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
