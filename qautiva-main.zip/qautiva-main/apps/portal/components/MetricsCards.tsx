type MetricCardProps = {
  label: string
  value: string
  detail: string
  trend?: { value: string; positive: boolean }
}

function MetricCard({ label, value, detail, trend }: MetricCardProps) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <p className="text-[#94A3B8] text-sm mb-2">{label}</p>
      <p className="text-white text-3xl font-bold mb-1">{value}</p>
      <div className="flex items-center gap-2">
        {trend && (
          <span className={`text-xs font-medium ${trend.positive ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
            {trend.positive ? '↑' : '↓'} {trend.value}
          </span>
        )}
        <span className="text-[#64748B] text-xs">{detail}</span>
      </div>
    </div>
  )
}

import { formatARS } from '@/lib/format'

type MetricsCardsProps = {
  webVisitsTotal: number
  webVisitsPrevMonth: number
  consultationsTotal: number
  adSpendGoogle: number
  adSpendMeta: number
  mediaReadsTotal: number
}

function calcTrend(current: number, prev: number): { value: string; positive: boolean } | undefined {
  if (prev === 0) return undefined
  const pct = Math.round(((current - prev) / prev) * 100)
  return { value: `${Math.abs(pct)}% vs mes anterior`, positive: pct >= 0 }
}

/**
 * Grid de 4 KPI cards: visitas web (con trend vs. mes anterior), consultas,
 * inversión en publicidad (Google + Meta) y notas publicadas.
 * Todos los montos en ARS con formato es-AR.
 */
export function MetricsCards({
  webVisitsTotal,
  webVisitsPrevMonth,
  consultationsTotal,
  adSpendGoogle,
  adSpendMeta,
  mediaReadsTotal,
}: MetricsCardsProps) {
  const visitTrend = calcTrend(webVisitsTotal, webVisitsPrevMonth)

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <MetricCard
        label="Visitas a tu web"
        value={webVisitsTotal.toLocaleString('es-AR')}
        detail="últimos 30 días"
        trend={visitTrend}
      />
      <MetricCard
        label="Consultas recibidas"
        value={consultationsTotal.toLocaleString('es-AR')}
        detail="este mes"
      />
      <MetricCard
        label="Inversión en publicidad"
        value={formatARS(adSpendGoogle + adSpendMeta)}
        detail={`Google: ${formatARS(adSpendGoogle)} · Meta: ${formatARS(adSpendMeta)}`}
      />
      <MetricCard
        label="Lecturas en medios"
        value={mediaReadsTotal.toLocaleString('es-AR')}
        detail="últimos 30 días"
      />
    </div>
  )
}
