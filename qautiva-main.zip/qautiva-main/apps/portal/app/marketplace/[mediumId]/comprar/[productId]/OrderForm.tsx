'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { MediumPlatform } from '@qautiva/db/types'
import { formatARS } from '@/lib/format'

export type OrderFormProduct = {
  id: string
  name: string
  price: number
  deliveryDays: number
  includesWriting: boolean
}

export type OrderFormMedium = {
  id: string
  name: string
  platform: MediumPlatform
}

const COMMISSION_RATE = 0.1

export function OrderForm({
  product,
  medium,
}: {
  product: OrderFormProduct
  medium: OrderFormMedium
}) {
  const router = useRouter()
  const isWebsite =
    medium.platform === MediumPlatform.WEBSITE

  const commission = Math.round(product.price * COMMISSION_RATE)
  const total = product.price + commission

  const [brief, setBrief] = useState('')
  const [targetUrl, setTargetUrl] = useState('')
  const [anchorText, setAnchorText] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (brief.trim().length < 10) {
      setError('El brief debe tener al menos 10 caracteres.')
      return
    }

    setSubmitting(true)
    try {
      const res = await fetch('/api/marketplace/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          brief: brief.trim(),
          ...(isWebsite && targetUrl.trim() ? { targetUrl: targetUrl.trim() } : {}),
          ...(isWebsite && anchorText.trim() ? { anchorText: anchorText.trim() } : {}),
        }),
      })

      const data = (await res.json()) as { error?: string; orderId?: string }

      if (!res.ok) {
        setError(data.error ?? 'Ocurrió un error al crear el pedido.')
        return
      }

      router.push('/mis-pedidos')
    } catch {
      setError('No se pudo conectar con el servidor. Intentá de nuevo.')
    } finally {
      setSubmitting(false)
    }
  }

  const briefLeft = 5000 - brief.length

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6" noValidate>
      {/* Resumen del pedido */}
      <section
        aria-label="Resumen del pedido"
        className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5"
      >
        <h2 className="text-white font-semibold mb-3">Resumen</h2>
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Medio</span>
            <span className="text-white font-medium">{medium.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Producto</span>
            <span className="text-white font-medium">{product.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Entrega estimada</span>
            <span className="text-white">
              {product.deliveryDays} {product.deliveryDays === 1 ? 'día' : 'días'}
            </span>
          </div>
          {product.includesWriting && (
            <div className="flex justify-between">
              <span className="text-[#94A3B8]">Redacción</span>
              <span className="text-[#34D399]">Incluida</span>
            </div>
          )}
          <hr className="border-[#1E293B] my-1" />
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Precio del producto</span>
            <span className="text-white">{formatARS(product.price)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Comisión Qautiva (10%)</span>
            <span className="text-white">{formatARS(commission)}</span>
          </div>
          <div className="flex justify-between font-semibold text-base pt-1">
            <span className="text-white">Total a pagar</span>
            <span className="text-white">{formatARS(total)}</span>
          </div>
        </div>
      </section>

      {/* Brief */}
      <div>
        <label htmlFor="brief" className="text-white font-semibold block mb-2">
          Brief <span className="text-red-400">*</span>
        </label>
        <p className="text-[#64748B] text-xs mb-2">
          Describí qué querés que el editor haga: tema, tono, referencias, palabras clave, etc.
        </p>
        <textarea
          id="brief"
          name="brief"
          rows={6}
          required
          minLength={10}
          maxLength={5000}
          placeholder="Ej: Necesito un artículo sobre beneficios del ayuno intermitente, tono informativo, que mencione mi marca NutriApp al menos 2 veces y enlace a https://nutriapp.com..."
          value={brief}
          onChange={(e) => setBrief(e.target.value)}
          disabled={submitting}
          className="w-full bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-[#334155] placeholder-[#475569] resize-y disabled:opacity-50"
        />
        <p className={`text-xs mt-1 text-right ${briefLeft < 200 ? 'text-yellow-400' : 'text-[#475569]'}`}>
          {briefLeft} caracteres restantes
        </p>
      </div>

      {/* Campos específicos de WEBSITE */}
      {isWebsite && (
        <>
          <div>
            <label htmlFor="targetUrl" className="text-white font-semibold block mb-2">
              URL de destino
            </label>
            <p className="text-[#64748B] text-xs mb-2">
              URL a la que apuntará el enlace en el artículo.
            </p>
            <input
              id="targetUrl"
              name="targetUrl"
              type="url"
              placeholder="https://tuempresa.com/landing"
              value={targetUrl}
              onChange={(e) => setTargetUrl(e.target.value)}
              disabled={submitting}
              className="w-full bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-[#334155] placeholder-[#475569] disabled:opacity-50"
            />
          </div>

          <div>
            <label htmlFor="anchorText" className="text-white font-semibold block mb-2">
              Texto ancla deseado
            </label>
            <p className="text-[#64748B] text-xs mb-2">
              Texto que se usará como enlace. Si no lo especificás, el editor decide.
            </p>
            <input
              id="anchorText"
              name="anchorText"
              type="text"
              maxLength={200}
              placeholder="Ej: mejores suplementos naturales"
              value={anchorText}
              onChange={(e) => setAnchorText(e.target.value)}
              disabled={submitting}
              className="w-full bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-[#334155] placeholder-[#475569] disabled:opacity-50"
            />
          </div>
        </>
      )}

      {/* Error */}
      {error && (
        <div role="alert" className="bg-red-900/30 border border-red-700 rounded-xl px-4 py-3">
          <p className="text-red-300 text-sm">{error}</p>
        </div>
      )}

      {/* Submit */}
      <button
        type="submit"
        disabled={submitting || brief.trim().length < 10}
        className="w-full bg-[#1E3A5F] hover:bg-[#1E4D8C] disabled:opacity-50 disabled:cursor-not-allowed text-[#60A5FA] font-semibold py-3 rounded-xl transition-colors text-sm"
        aria-busy={submitting}
      >
        {submitting ? 'Enviando pedido…' : `Confirmar pedido — ${formatARS(total)}`}
      </button>

      <p className="text-[#475569] text-xs text-center">
        Al confirmar aceptás los{' '}
        <a href="/terminos" className="text-[#60A5FA] hover:underline">
          términos y condiciones
        </a>
        . El editor tiene 3 días para aceptar tu pedido.
      </p>
    </form>
  )
}
