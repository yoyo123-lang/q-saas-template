import { test, expect } from '@playwright/test'

/**
 * Smoke tests (Nivel 0) — gate mínimo de CI.
 * Validan que la app arranca, el health endpoint responde,
 * y las rutas básicas cargan sin errores.
 * No requieren auth ni datos en DB.
 */
test.describe('Smoke tests', () => {
  test('health endpoint responde OK', async ({ request }) => {
    const response = await request.get('/api/health')
    // 200 cuando DB está ok o no configurada; 503 cuando DATABASE_URL está
    // configurado pero la conexión falla (degraded). Ambos son válidos en CI.
    expect([200, 503]).toContain(response.status())
    const body = await response.json()
    expect(['ok', 'degraded']).toContain(body.status)
    expect(body.timestamp).toBeTruthy()
  })

  test('landing page carga sin errores', async ({ page }) => {
    await page.goto('/')
    await expect(page).not.toHaveTitle(/error/i)
    // La página no debe tener un 500 error
    await expect(page.locator('body')).not.toContainText('Internal Server Error')
  })

  test('página de login carga', async ({ page }) => {
    await page.goto('/login')
    await expect(page).not.toHaveTitle(/error/i)
    // Debe tener un formulario de login
    await expect(page.locator('input[type="email"]')).toBeVisible()
  })

  test('ruta protegida redirige a login sin sesión', async ({ page }) => {
    await page.goto('/dashboard')
    // Debe redirigir a login si no hay sesión
    await expect(page).toHaveURL(/\/login/)
  })

  test('panel admin redirige a login sin sesión', async ({ page }) => {
    await page.goto('/admin')
    await expect(page).toHaveURL(/\/login/)
  })

  test('página de explorar carga', async ({ page }) => {
    await page.goto('/explorar')
    await expect(page).not.toHaveTitle(/error/i)
    await expect(page.locator('body')).not.toContainText('Internal Server Error')
  })
})
