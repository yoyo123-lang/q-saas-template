import type { Metadata } from 'next'
import Script from 'next/script'
import './globals.css'

// La fuente se carga via globals.css con @import de Google Fonts (en producción)
// o cae a system-ui como fallback. Evita el fetch de next/font/google en build.

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://qautiva.ar'

export const metadata: Metadata = {
  metadataBase: new URL(BASE_URL),
  title: {
    default: 'qautiva — Tu negocio online en una semana',
    template: '%s | qautiva',
  },
  description:
    'La IA hace todo: marca, web, campañas y presencia en medios. Lanzá tu negocio digital sin reuniones, sin esperas.',
  keywords: [
    'marketing digital',
    'presencia online',
    'marca digital',
    'agencia IA',
    'sitio web',
    'Google Ads',
    'Meta Ads',
    'lanzamiento negocio',
    'Argentina',
  ],
  authors: [{ name: 'qautiva', url: BASE_URL }],
  creator: 'qautiva',
  openGraph: {
    title: 'qautiva — Tu negocio online en una semana',
    description: 'Marca, web, campañas y presencia en medios. Todo con IA, en 7 días.',
    url: BASE_URL,
    siteName: 'qautiva',
    locale: 'es_AR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'qautiva — Tu negocio online en una semana',
    description: 'Marca, web, campañas y presencia en medios. Todo con IA, en 7 días.',
  },
  alternates: { canonical: BASE_URL },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
}

// Site key pública — puede configurarse en env var o usar el fallback del proyecto
const RECAPTCHA_SITE_KEY =
  process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY ?? '6Ld4VIYsAAAAAL8SARzMiYqZl9YtfGPjyeGvSchT'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className="dark">
      <body>
        {children}
        {RECAPTCHA_SITE_KEY && (
          <Script
            src={`https://www.google.com/recaptcha/api.js?render=${RECAPTCHA_SITE_KEY}`}
            strategy="lazyOnload"
          />
        )}
      </body>
    </html>
  )
}
