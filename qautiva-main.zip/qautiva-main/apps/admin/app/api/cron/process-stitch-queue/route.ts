import { NextRequest, NextResponse } from 'next/server'
import { waitUntil } from '@vercel/functions'
import { prisma } from '@qautiva/db'
import { generateTemplate, processStitchHtml, validateHandlebarsCompilation } from '@qautiva/stitch'
import { TEMPLATE_STYLES } from '@qautiva/shared'

export const maxDuration = 300

const LOCK_TIMEOUT_MS = 5 * 60 * 1000

/**
 * GET /api/cron/process-stitch-queue
 *
 * Cron periódico: toma el siguiente job QUEUED y lo ejecuta.
 * Solo procesa UN job por invocación para respetar el timeout de 300s de Stitch.
 * Vercel lo llama cada 5 minutos.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env['CRON_SECRET']

  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  try {
    // Loguear estado de la cola y cuentas para visibilidad
    const [queueCounts, accounts] = await Promise.all([
      prisma.webTemplate.groupBy({
        by: ['queueStatus'],
        where: { queueStatus: { not: null } },
        _count: { _all: true },
      }),
      prisma.stitchAccount.findMany({
        where: { active: true },
        select: { label: true, usedToday: true, dailyLimit: true },
      }),
    ])
    const counts = Object.fromEntries(queueCounts.map((r) => [r.queueStatus, r._count._all]))
    console.info(`[cron:process-stitch-queue] queue=${JSON.stringify(counts)} accounts=${JSON.stringify(accounts.map((a) => `${a.label}:${a.usedToday}/${a.dailyLimit}`))}`)

    // Verificar si la cola está pausada manualmente
    const queueConfig = await prisma.stitchQueueConfig.findUnique({ where: { id: 1 } })
    if (queueConfig?.paused) {
      console.info('[cron:process-stitch-queue] skipped: cola pausada')
      return NextResponse.json({ skipped: true, reason: 'Cola pausada' })
    }

    // Verificar que no haya un job ya en GENERATING activo (evitar paralelismo)
    const generating = await prisma.webTemplate.findFirst({
      where: {
        queueStatus: 'GENERATING',
        generatingAt: { gt: new Date(Date.now() - LOCK_TIMEOUT_MS) },
      },
      select: { id: true },
    })

    if (generating) {
      console.info(`[cron:process-stitch-queue] skipped: job ${generating.id} en GENERATING`)
      return NextResponse.json({
        skipped: true,
        reason: 'Ya hay un job en GENERATING',
        jobId: generating.id,
      })
    }

    // Seleccionar cuenta con créditos
    const account = await selectBestAccount()
    if (!account) {
      console.info('[cron:process-stitch-queue] skipped: sin créditos disponibles')
      return NextResponse.json({ skipped: true, reason: 'Sin créditos disponibles' })
    }

    // Tomar el siguiente job QUEUED (el más antiguo)
    const job = await prisma.webTemplate.findFirst({
      where: { queueStatus: 'QUEUED' },
      orderBy: { queuedAt: 'asc' },
      select: {
        id: true,
        compatibleIndustries: true,
        sections: true,
        generationPrompt: true,
        styleId: true,
      },
    })

    if (!job) {
      console.info('[cron:process-stitch-queue] skipped: no hay jobs en cola')
      return NextResponse.json({ skipped: true, reason: 'No hay jobs en cola' })
    }

    // Preparar parámetros
    const styleId = job.styleId ?? 'clean-professional'
    const style = TEMPLATE_STYLES.find((s) => s.id === styleId) ?? TEMPLATE_STYLES[0]
    const industries = job.compatibleIndustries as string[]
    const industry = industries[0] ?? ''
    const sectionsObj = (job.sections ?? {}) as Record<string, boolean>
    const sections = Object.entries(sectionsObj)
      .filter(([, v]) => v)
      .map(([k]) => k)
    const prompt = job.generationPrompt ?? `Template para ${industry}.`

    // Marcar como GENERATING con lock (limpiar queueError de intentos anteriores)
    await prisma.webTemplate.update({
      where: { id: job.id },
      data: { queueStatus: 'GENERATING', generatingAt: new Date(), queueError: null },
    })

    console.info(`[cron:process-stitch-queue] Procesando job ${job.id} (${industry}) con cuenta ${account.id}`)

    // Lanzar generación en background
    waitUntil(
      runGeneration(job.id, { industry, sections, prompt, stylePrompt: style.prompt, styleLabel: style.label }, account),
    )

    return NextResponse.json({
      processed: true,
      jobId: job.id,
      industry,
      accountId: account.id,
    })
  } catch (err) {
    console.error('[cron:process-stitch-queue] Error:', err)
    return NextResponse.json({ error: 'Error procesando cola' }, { status: 500 })
  }
}

/**
 * Selecciona la cuenta Stitch con menor uso hoy (round-robin).
 * Incrementa usedToday inmediatamente al seleccionar para que la próxima
 * invocación tome otra cuenta — no espera a que el job complete.
 */
async function selectBestAccount(): Promise<{ id: string; apiKey: string } | null> {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  await prisma.stitchAccount.updateMany({
    where: { active: true, lastResetAt: { lt: today } },
    data: { usedToday: 0, lastResetAt: new Date() },
  })

  const accounts = await prisma.stitchAccount.findMany({
    where: { active: true },
    select: { id: true, apiKey: true, usedToday: true, dailyLimit: true },
    orderBy: { usedToday: 'asc' },
  })

  const account = accounts.find((a) => a.usedToday < a.dailyLimit) ?? null
  if (!account) return null

  // Reservar el crédito inmediatamente → round-robin real entre cuentas
  await prisma.stitchAccount.update({
    where: { id: account.id },
    data: { usedToday: { increment: 1 } },
  })

  return { id: account.id, apiKey: account.apiKey }
}

async function runGeneration(
  templateId: string,
  params: { industry: string; sections: string[]; prompt: string; stylePrompt: string; styleLabel: string },
  account: { id: string; apiKey: string },
): Promise<void> {
  const { industry, sections, prompt, stylePrompt, styleLabel } = params
  const fullPrompt = `${prompt}\n\nEstilo visual: ${stylePrompt}`
  const startMs = Date.now()

  try {
    const result = await generateTemplate({ industry, sections, prompt: fullPrompt, apiKey: account.apiKey })
    const { html, css, thumbnailUrl, stitchProjectId, stitchScreenId } = result

    const processResult = processStitchHtml(html, sections)
    if (!processResult.success) {
      await prisma.webTemplate.update({
        where: { id: templateId },
        data: { queueStatus: 'ERROR', generatingAt: null, queueError: `processStitchHtml:${processResult.reason}` },
      })
      console.error(`[cron:process-stitch-queue] processStitchHtml failed (${templateId}): ${processResult.reason}`)
      console.error(`[cron:process-stitch-queue] HTML snippet (${templateId}): ${html.slice(0, 500)}`)
      return
    }

    const validationResult = validateHandlebarsCompilation(processResult.processedHtml)
    if (!validationResult.valid) {
      await prisma.webTemplate.update({
        where: { id: templateId },
        data: { queueStatus: 'ERROR', generatingAt: null, queueError: `handlebars:${validationResult.error?.slice(0, 500) ?? 'unknown'}` },
      })
      console.error(`[cron:process-stitch-queue] Handlebars failed (${templateId}): ${validationResult.error}`)
      return
    }

    // usedToday ya se incrementó en selectBestAccount (reserva anticipada)
    // Nombre descriptivo: "Calzado — Limpio y profesional" en vez de "__queue__uuid"
    const displayName = `${industry} — ${styleLabel}`
    await prisma.webTemplate.update({
      where: { id: templateId },
      data: {
        name: displayName,
        source: 'STITCH',
        stitchProjectId,
        stitchScreenId,
        htmlBase: processResult.processedHtml,
        css,
        thumbnail: thumbnailUrl,
        generationPrompt: fullPrompt,
        variables: processResult.extractedVariables,
        sections: processResult.detectedSections,
        generatingAt: null,
        queueStatus: 'DONE',
        status: 'DRAFT',
        stitchAccountId: account.id,
      },
    })
    console.info(`[cron:process-stitch-queue] Completado ${templateId} en ${Date.now() - startMs}ms`)
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err)

    if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit') || errMsg.toLowerCase().includes('quota')) {
      await Promise.all([
        prisma.stitchAccount.update({
          where: { id: account.id },
          data: { usedToday: { increment: 9999 } },
        }),
        prisma.webTemplate.update({
          where: { id: templateId },
          data: { queueStatus: 'QUEUED', generatingAt: null, stitchAccountId: null, queueError: '429:rate_limit' },
        }),
      ]).catch(() => {})
      console.error(`[cron:process-stitch-queue] 429 cuenta ${account.id} — job ${templateId} vuelve a QUEUED`)
      return
    }

    await prisma.webTemplate
      .update({
        where: { id: templateId },
        data: { queueStatus: 'ERROR', generatingAt: null, queueError: errMsg.slice(0, 500) },
      })
      .catch(() => {})
    // Log en líneas separadas para que Vercel no trunque
    console.error(`[cron] FATAL templateId=${templateId}`)
    console.error(`[cron] FATAL accountId=${account.id}`)
    console.error(`[cron] FATAL errName=${err instanceof Error ? err.name : 'unknown'}`)
    console.error(`[cron] FATAL errMsg=${errMsg.slice(0, 200)}`)
    if (errMsg.length > 200) console.error(`[cron] FATAL errMsg2=${errMsg.slice(200, 400)}`)
    if (err instanceof Error && err.stack) {
      const stackLines = err.stack.split('\n').slice(1, 4)
      stackLines.forEach((l, i) => console.error(`[cron] FATAL stack${i}=${l.trim()}`))
    }
    if (err instanceof Error && err.cause) {
      console.error(`[cron] FATAL cause=${JSON.stringify(err.cause).slice(0, 200)}`)
    }
  }
}
