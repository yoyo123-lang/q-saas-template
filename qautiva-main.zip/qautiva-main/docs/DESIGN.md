# Qautiva — Sistema de Diseño para Stitch

> Este archivo define los tokens y reglas de diseño de Qautiva.
> Se usa como contexto de diseño en cada prompt enviado a Google Stitch para garantizar consistencia visual en los templates generados.
>
> ⚠️ Si se actualiza este archivo, actualizar también la constante `DESIGN_CONTEXT`
> en `packages/stitch/src/design-context.ts`.

---

## Identidad visual

**Nombre**: Qautiva
**Tono visual**: Dark, profesional, tech-forward. Minimalista pero con carácter.
**Público**: Pequeñas y medianas empresas argentinas. Deben transmitir confianza y modernidad.

---

## Paleta de colores

### Fondos
- **Fondo principal**: `#0B0F1A` — negro azulado profundo
- **Fondo secundario** (cards, paneles): `#0F172A` — slate-900
- **Fondo terciario** (hover, inputs): `#1E293B` — slate-800

### Textos
- **Texto principal**: `#F8FAFC` — blanco cálido
- **Texto secundario**: `#94A3B8` — slate-400
- **Texto apagado** (placeholders, metadatos): `#64748B` — slate-500

### Acento y marca
- **Color de acento / interactivo**: `#8B5CF6` — violet-500
- **Acento claro** (hover de acento): `#A78BFA` — violet-400
- **Glow de acento** (sombras sutiles): `rgba(139, 92, 246, 0.15)`

### Bordes
- **Borde default**: `#1E293B`
- **Borde acento**: `rgba(139, 92, 246, 0.3)`

### Estados
- **Éxito**: `#10B981` — emerald-500
- **Advertencia**: `#F59E0B` — amber-400
- **Error**: `#EF4444` — red-500
- **Info**: `#3B82F6` — blue-500

---

## Tipografía

### Familias
- **Display y body**: `"Satoshi", "DM Sans", system-ui, sans-serif`
- **Monoespaciada** (código, datos técnicos): `"JetBrains Mono", "Fira Code", monospace`

### Tamaños
| Uso | Tamaño |
|-----|--------|
| Hero / headline principal | `3rem` (48px) |
| H1 | `2rem` (32px) |
| H2 | `1.5rem` (24px) |
| Body | `1rem` (16px) |
| Label / caption | `0.875rem` (14px) |
| Small | `0.8125rem` (13px) |
| Descriptor | `0.75rem` (12px) |

### Pesos
- **Display / hero**: `700` (bold)
- **Headings**: `600` (semibold)
- **Body**: `400` (regular)
- **Emphasis**: `500` (medium)

---

## Espaciado

Sistema basado en múltiplos de 8px:

| Token | Valor |
|-------|-------|
| xs | `4px` |
| sm | `8px` |
| md | `16px` |
| lg | `24px` |
| xl | `32px` |
| 2xl | `48px` |
| 3xl | `64px` |
| 4xl | `80px` |
| 5xl | `120px` |

---

## Border radius

| Token | Valor |
|-------|-------|
| sm | `6px` |
| default | `8px` |
| lg | `12px` |
| xl | `16px` |
| full | `9999px` |

---

## Layout y responsive

### Breakpoints (Tailwind CSS)
- **sm**: 640px
- **md**: 768px
- **lg**: 1024px
- **xl**: 1280px
- **2xl**: 1536px

### Anchos máximos
- Contenido de texto: `max-w-3xl` (48rem)
- Layout principal: `max-w-6xl` (72rem)
- Hero full-width: `max-w-none` con padding

### Grid
- Mobile: columna única
- Tablet (md): 2 columnas para cards
- Desktop (lg): 3 columnas para cards de servicios

---

## Componentes y patrones

### Cards
- Fondo: `bg-slate-900` (`#0F172A`)
- Borde: `border border-slate-800` con hover `border-violet-500/30`
- Padding: `p-6` (24px)
- Border-radius: `rounded-xl` (12px)
- Sombra sutil en hover: `shadow-lg shadow-violet-500/5`

### Botones primarios
- Fondo: `bg-violet-500` → hover `bg-violet-600`
- Texto: `text-white font-semibold`
- Padding: `px-6 py-3`
- Border-radius: `rounded-lg`

### Botones secundarios / outline
- Fondo: `transparent`
- Borde: `border border-slate-700` → hover `border-violet-500`
- Texto: `text-slate-300` → hover `text-white`

### Inputs
- Fondo: `bg-slate-800`
- Borde: `border border-slate-700` → focus `border-violet-500`
- Texto: `text-white`
- Placeholder: `text-slate-500`

### Badges / pills
- Default: `bg-slate-800 text-slate-400`
- Acento: `bg-violet-500/10 text-violet-400 border border-violet-500/20`
- Éxito: `bg-emerald-500/10 text-emerald-400`

---

## Reglas para Stitch — OBLIGATORIAS

Al generar un template web para Qautiva, seguir estas reglas:

### Tecnología
1. **Usar Tailwind CSS** — clases utilitarias, no CSS personalizado en `<style>`
2. **Dark mode obligatorio** — el fondo SIEMPRE es oscuro (`#0B0F1A` o similar)
3. **Sin JavaScript inline** — no `onclick`, no `<script>` con lógica
4. **Fuentes via Google Fonts** — cargar Satoshi o DM Sans desde CDN

### Estructura HTML
5. **`data-section` en cada sección** — OBLIGATORIO para el bridge HTML:
   ```html
   <section data-section="hero">...</section>
   <section data-section="about">...</section>
   <section data-section="services">...</section>
   <section data-section="pricing">...</section>
   <section data-section="contact">...</section>
   ```
6. **Secciones con `id` correspondiente** — además del `data-section`, agregar `id` igual al key
7. **Navegación** — usar `<nav>` semántico con links a `#id-de-seccion`

### Contenido y copy
8. **No usar texto en inglés** — todo el contenido placeholder en español
9. **Placeholders realistas** — usar nombres y datos de ejemplo argentinos (no "Lorem ipsum")
10. **Slogan, título y CTA en el hero** — siempre visible above the fold

### Accesibilidad
11. **Alt text en imágenes** — siempre descriptivo
12. **Contraste suficiente** — texto claro sobre fondo oscuro (ratio mínimo 4.5:1)
13. **Links semánticos** — no `<div onclick>`, usar `<a>` o `<button>`

### Lo que NO hacer
- ❌ No usar `allow-same-origin` ni ejecutar scripts que accedan al DOM padre
- ❌ No incluir tracking pixels, Google Analytics, ni scripts de terceros
- ❌ No usar colores claros como fondo principal (el diseño es dark-first)
- ❌ No usar CSS Grid complejo sin fallback flexbox
- ❌ No incrustar fuentes como base64

---

## Ejemplo de estructura HTML esperada

```html
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{seo_title}}</title>
  <meta name="description" content="{{seo_description}}">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#0B0F1A] text-[#F8FAFC] font-sans">

  <nav><!-- navegación --></nav>

  <section data-section="hero" id="hero">
    <h1>{{hero_heading}}</h1>
    <p>{{hero_subheading}}</p>
    <a href="#contact">{{hero_cta}}</a>
  </section>

  <section data-section="about" id="about">
    <h2>{{about_heading}}</h2>
    <p>{{about_body}}</p>
  </section>

  <section data-section="services" id="services">
    <h2>{{services_heading}}</h2>
    <!-- items de servicios -->
  </section>

  <section data-section="contact" id="contact">
    <h2>{{contact_heading}}</h2>
    <!-- datos de contacto -->
  </section>

</body>
</html>
```
