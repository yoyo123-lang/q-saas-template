import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { LogoQ } from '@/components/shared/logo-q'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-navy-950 flex flex-col items-center justify-center px-6 text-center">
      <LogoQ size="lg" />

      <div className="mt-10 space-y-3">
        <p className="text-7xl font-bold text-amber-500">404</p>
        <h1 className="text-2xl font-semibold text-slate-50">Página no encontrada</h1>
        <p className="text-slate-400 max-w-sm mx-auto">
          La página que buscás no existe o fue movida.
        </p>
      </div>

      <div className="mt-8">
        <Link href="/">
          <Button variant="solid" size="md">Volver al inicio</Button>
        </Link>
      </div>
    </div>
  )
}
