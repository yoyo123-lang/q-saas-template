'use client'

import { useState, useTransition, useEffect } from 'react'

type Props = {
  authProvider: string
}

export function ChangePasswordForm({ authProvider }: Props) {
  const [isPending, startTransition] = useTransition()
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    if (!success) return
    const timer = setTimeout(() => setSuccess(false), 3000)
    return () => clearTimeout(timer)
  }, [success])

  // Bloquear todos los proveedores OAuth (Google, GitHub, etc.)
  if (authProvider !== 'email') {
    return (
      <p className="text-[#94A3B8] text-sm">
        Tu cuenta usa un proveedor externo para iniciar sesión. No necesitás contraseña.
      </p>
    )
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (newPassword.length < 8) {
      setError('La nueva contraseña debe tener al menos 8 caracteres')
      return
    }
    if (newPassword !== confirmPassword) {
      setError('Las contraseñas no coinciden')
      return
    }

    startTransition(async () => {
      const res = await fetch('/api/settings/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error ?? 'Error al cambiar la contraseña')
        return
      }
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
      setSuccess(true)
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <div className="flex flex-col gap-1">
        <label className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
          Contraseña actual
        </label>
        <input
          type="password"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          required
          disabled={isPending}
          className="bg-[#0F172A] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
          Nueva contraseña
        </label>
        <input
          type="password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          required
          minLength={8}
          disabled={isPending}
          className="bg-[#0F172A] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
          Confirmar nueva contraseña
        </label>
        <input
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          disabled={isPending}
          className="bg-[#0F172A] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
        />
      </div>

      {error && (
        <div className="bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm rounded-lg px-4 py-2">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-[#10B981]/10 border border-[#10B981]/30 text-[#34D399] text-sm rounded-lg px-4 py-2">
          Contraseña actualizada correctamente.
        </div>
      )}

      <div>
        <button
          type="submit"
          disabled={isPending}
          className="bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
        >
          {isPending ? 'Actualizando…' : 'Cambiar contraseña'}
        </button>
      </div>
    </form>
  )
}
