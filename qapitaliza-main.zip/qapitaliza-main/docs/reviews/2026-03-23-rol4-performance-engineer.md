# Informe de Revisión — ROL 4: Performance Engineer
**Fecha:** 2026-03-23
**Sesión:** 02 — Landing y páginas públicas
**Revisor:** Rol 4 - Performance Engineer

---

## Resumen ejecutivo

Las páginas de listado tienen paginación correcta (PAGE_SIZE=20, MAX_PAGE_SIZE=100). Se detectaron dos issues altos — uno de bloqueo de renderizado por write sincrónico y otro de fetch ilimitado en sitemap — ambos corregidos.

---

## Hallazgos

### [ALTO → CORREGIDO] `incrementListingViews` era un DB write sincrónico bloqueando SSR

**Archivo:** `src/app/(public)/explorar/[slug]/page.tsx`

**Problema original:** La llamada a `incrementListingViews` bloqueaba el renderizado de la página esperando que completara un `UPDATE` a la DB. En alta carga, esto podía aumentar TTFB significativamente.

**Fix aplicado:** La llamada se convirtió en fire-and-forget con `void (async () => { ... })()`. El renderizado de la página no espera a que complete el UPDATE — la página se sirve inmediatamente y el contador se actualiza en background.

---

### [ALTO → CORREGIDO] Sitemap sin límite podía fetchear 10k+ listings

**Archivo:** `src/app/sitemap.ts`

**Problema original:** El `findMany` en sitemap no tenía `take` limit — en un catálogo con miles de listings, esto generaba una query enorme que podía agotar memoria y tiempo de respuesta.

**Fix aplicado:** Se agregó `take: 1000` al `findMany`. El sitemap cubre los 1000 listings más relevantes (configurable si se necesita paginación de sitemaps en el futuro).

---

### [MEDIO] `getListings` incluye todas las relaciones aunque no siempre se necesiten

**Archivo:** `src/lib/data/listings.ts`

**Contexto:** `include: { seller: true, metrics: true, category: true }` trae todos los campos del seller y métricas. Para el catálogo de listados, muchos campos del seller no se usan en la tarjeta.

**Estado:** Documentado como mejora futura. Implementar `select` granular en lugar de `include` full reduciría el payload de DB y memoria. No implementado en esta sesión — requiere refactor de tipos y cambios en múltiples componentes.

---

## Puntos positivos

- Paginación correcta en `getListings` con PAGE_SIZE y MAX_PAGE_SIZE.
- `revalidate = 3600` en sitemap evita rebuild en cada request.
- `getRelatedListings` siempre tiene `take: limit` (default 3).
- Imágenes con `next/image` con `sizes` correcto para responsive.
- Sin queries en loops — todos los fetches son paralelos o únicos.

---

## Estado final

| Hallazgo | Severidad | Estado |
|---|---|---|
| incrementListingViews bloqueaba SSR | ALTO | Corregido |
| Sitemap sin límite de registros | ALTO | Corregido |
| getListings incluye relaciones completas | MEDIO | Pendiente — mejora futura |
