# Dashboards — Especificación Frontend

> Cubre las rutas autenticadas: dashboard vendedor, dashboard comprador, y panel admin.
> Todas estas rutas son Client Components con fetch del lado del servidor donde aplica.

---

## Estructura de rutas

```
app/
  (dashboard)/
    layout.tsx          ← Sidebar + auth guard
    dashboard/
      page.tsx          ← /dashboard (vista general vendedor)
    mis-activos/
      page.tsx          ← /mis-activos (tabla de listados)
      nuevo/
        page.tsx        ← /mis-activos/nuevo (wizard multi-step)
      [id]/
        editar/
          page.tsx      ← /mis-activos/[id]/editar (tabs)
    consultas/
      page.tsx          ← /consultas (lista)
      [id]/
        page.tsx        ← /consultas/[id] (chat)
    favoritos/
      page.tsx          ← /favoritos (grid)
    perfil/
      page.tsx          ← /perfil
  (admin)/
    layout.tsx          ← Sidebar admin + guard rol ADMIN
    admin/
      page.tsx          ← /admin
      listados/
        page.tsx        ← /admin/listados
      usuarios/
        page.tsx        ← /admin/usuarios
```

**Auth guard:** en cada `layout.tsx` verificar sesión con Supabase. Si no hay sesión → redirect `/login`. Si rol incorrecto → redirect `/dashboard`.

---

## Layout de Dashboard

**Archivo:** `app/(dashboard)/layout.tsx`

```tsx
<div className="flex h-screen bg-navy-950">
  <Sidebar variant="dashboard" activeItem={currentPath} user={user} />
  <main className="flex-1 ml-[280px] overflow-y-auto">
    <div className="p-8">
      {children}
    </div>
  </main>
</div>
```

---

## 1. Dashboard General (`/dashboard`)

**Archivo:** `app/(dashboard)/dashboard/page.tsx`

### Datos a fetchear (Server Component)

```ts
const [stats, recentActivity, listings] = await Promise.all([
  getSellerStats(userId),       // { publishedCount, totalViews, activeInquiries, totalListedRevenue }
  getRecentActivity(userId),    // últimas 5 actividades
  getListings({ sellerId: userId, limit: 4 })  // preview de activos
])
```

### Secciones

#### 1.1 Header

```tsx
<div>
  <h1 className="text-2xl font-semibold text-slate-50">Dashboard</h1>
  <p className="text-slate-400 text-sm mt-1">Bienvenido, {user.name}</p>
</div>
```

#### 1.2 Stat Cards — grid 4 columnas

```tsx
<div className="grid grid-cols-4 gap-4">
  <StatCard
    label="Activos publicados"
    value={stats.publishedCount}
    icon={<Package size={20} className="text-amber-500" />}
  />
  <StatCard
    label="Vistas totales"
    value={formatNumber(stats.totalViews)}
    icon={<Eye size={20} className="text-amber-500" />}
    trend={{ value: '+12% este mes', positive: true }}
  />
  <StatCard
    label="Consultas activas"
    value={stats.activeInquiries}
    icon={<MessageCircle size={20} className="text-amber-500" />}
    pulse={stats.activeInquiries > 0}
  />
  <StatCard
    label="Revenue total listado"
    value={`$${formatNumber(stats.totalListedRevenue)} USD`}
    icon={<DollarSign size={20} className="text-amber-500" />}
    highlight
  />
</div>
```

#### 1.3 Gráfico de vistas

Librería: **Recharts** (`recharts`). No usar otras.

```tsx
<Card className="p-6">
  <div className="flex justify-between items-center mb-4">
    <h2 className="font-semibold text-slate-50">Vistas de tus activos</h2>
    <Select options={periodOptions} />
  </div>
  <ResponsiveContainer width="100%" height={200}>
    <AreaChart data={viewsData}>
      <Area type="monotone" dataKey="views" stroke="#F59E0B" fill="rgba(245,158,11,0.1)" />
    </AreaChart>
  </ResponsiveContainer>
</Card>
```

#### 1.4 Actividad Reciente

```tsx
<Card className="p-6">
  <h2 className="font-semibold text-slate-50 mb-4">Actividad reciente</h2>
  {recentActivity.map(item => (
    <ActivityItem key={item.id} {...item} />
  ))}
</Card>
```

`<ActivityItem>`: dot de color + texto + timestamp `text-xs text-slate-500`.

| Tipo de actividad | Color del dot |
|---|---|
| Consulta recibida | `bg-blue-500` |
| Activo destacado | `bg-amber-500` |
| Vista nueva | `bg-slate-400` |
| Activo aprobado | `bg-emerald-500` |
| Consulta respondida | `bg-slate-400` |

#### 1.5 Preview "Mis activos"

Tabla compacta de 4 filas con columnas: Activo | Tipo | Precio | Estado | Vistas.
Link "Ver todos →" a `/mis-activos`.

---

## 2. Mis Activos (`/mis-activos`)

**Archivo:** `app/(dashboard)/mis-activos/page.tsx`

### searchParams

| Param | Valores |
|---|---|
| `status` | `all` \| `published` \| `draft` \| `pending` \| `sold` |
| `q` | string de búsqueda |

### Componente `<ListingsTable />`

**Columnas:** thumbnail + Activo | Tipo | Precio | Estado | Vistas | Consultas | Acciones

- **Thumbnail:** `40x40 rounded-lg object-cover bg-slate-800`
- **Estado badge:** usar `<Badge>` según status
- **Acciones:** `<DropdownMenu>` con ícono `MoreHorizontal`

```ts
const menuItems = [
  { label: 'Editar', href: `/mis-activos/${id}/editar`, icon: Pencil },
  { label: 'Ver página', href: `/explorar/${slug}`, icon: ExternalLink },
  { label: 'Pausar', action: 'pause', icon: PauseCircle },
  { label: 'Eliminar', action: 'delete', icon: Trash2, danger: true },
]
```

**Eliminar:** confirmar con Modal antes de ejecutar Server Action.

### Tabs de filtro

```tsx
const tabs = [
  { label: 'Todos', status: 'all', count: listings.total },
  { label: 'Publicados', status: 'published', count: listings.publishedCount },
  { label: 'Borradores', status: 'draft', count: listings.draftCount },
  { label: 'En revisión', status: 'pending', count: listings.pendingCount },
  { label: 'Vendidos', status: 'sold', count: listings.soldCount },
]
```

Tab activo: `border-b-2 border-amber-500 text-amber-500`

---

## 3. Crear Listado — Wizard (`/mis-activos/nuevo`)

**Archivo:** `app/(dashboard)/mis-activos/nuevo/page.tsx`

### Stepper

```tsx
const steps = [
  { id: 1, label: 'Información básica' },
  { id: 2, label: 'Métricas' },
  { id: 3, label: 'Imágenes' },
  { id: 4, label: 'Revisión' },
]
```

**Stepper visual:** círculo con número. Activo: `bg-amber-500 text-navy-950`. Completado: `bg-emerald-500`. Pendiente: `bg-slate-800 text-slate-400`.
Línea entre pasos: completada en `bg-amber-500`, pendiente en `bg-slate-800`.

### Paso 1 — Información básica

Campos:
- Título del activo — `<Input>`
- Tipo de activo — `<Select>` opciones: Sitio Web | Dominio | SaaS/MVP | E-commerce | Proyecto
- URL del activo — `<Input prefix="https://">`
- Descripción — `<Textarea rows={6} maxLength={2000}>`
- Precio + Moneda — 2 columnas: `<Input prefix="$" type="number">` + `<Select options={['USD','ARS']}>`
- Tech Stack — `<TagInput>`: input con chips. Validación: max 10 tags, cada uno max 30 chars
- Tags — `<TagInput>`: max 8 tags

### Paso 2 — Métricas

Campos dinámicos según tipo de activo:

| Tipo | Métricas disponibles |
|---|---|
| WEBSITE | Visitas/mes, Domain Authority, Edad |
| DOMAIN | Domain Authority, Año de registro |
| SAAS/MVP | MRR, Usuarios activos, Churn rate, Edad |
| ECOMMERCE | Órdenes/mes, Revenue mensual, Productos |
| PROJECT | Usuarios activos, Edad |

Cada métrica: `<Input type="number" label="..." helper="Fuente: ej. Google Analytics">` + campo "Fuente/evidencia".

### Paso 3 — Imágenes

`<ImageUploader>`:
- Drop zone: `border-2 border-dashed border-slate-800 rounded-xl p-8 text-center`
- Drag active: `border-amber-500`
- Máximo: 5 imágenes
- Tamaño máximo: 2MB por imagen
- Formatos: JPG, PNG, WebP
- Preview con botón × para eliminar
- Orden: drag & drop para reordenar

### Paso 4 — Revisión

Resumen read-only de todos los datos ingresados. Botones:
- "Guardar como borrador" (outline)
- "Enviar a revisión" (solid amber) → cambia status a `PENDING_REVIEW`, redirige a `/mis-activos`

### Persistencia del wizard

Guardar estado en `sessionStorage` con key `new-listing-draft`. Al abandonar y volver, preguntar si retomar.

---

## 4. Editar Listado (`/mis-activos/[id]/editar`)

**Archivo:** `app/(dashboard)/mis-activos/[id]/editar/page.tsx`

Layout: contenido principal (70%) + sidebar de estado (30%).

### Tabs

```tsx
const tabs = ['Información', 'Métricas', 'Imágenes', 'Configuración']
```

Cada tab es el formulario correspondiente del wizard, pero pre-populado.

### Sidebar de estado

```tsx
<Card className="p-6 sticky top-24">
  <h3 className="font-semibold text-sm text-slate-400 uppercase tracking-wider mb-4">
    Estado del listado
  </h3>
  <StatusBadge status={listing.status} />
  <p className="text-xs text-slate-500 mt-1">Desde {formatDate(listing.publishedAt)}</p>

  <div className="flex flex-col gap-2 mt-4">
    <Button variant="outline" size="sm">Pausar publicación</Button>
    <Button variant="outline-success" size="sm">Marcar como vendido</Button>
    <Divider />
    <Button variant="outline-danger" size="sm">Eliminar listado</Button>
  </div>

  <Divider className="my-4" />

  <div className="space-y-2 text-sm">
    <p className="text-slate-400">Vistas: <span className="text-slate-50">{listing.views}</span></p>
    <p className="text-slate-400">Consultas: <span className="text-slate-50">{listing.inquiries}</span></p>
    <p className="text-slate-400">Favoritos: <span className="text-slate-50">{listing.favorites}</span></p>
  </div>
</Card>
```

---

## 5. Favoritos (`/favoritos`)

**Archivo:** `app/(dashboard)/favoritos/page.tsx`

Grid 2 columnas de `<ListingCard>` con `isFavorited={true}`.

Click en corazón → Server Action `removeFavorite(listingId)` → optimistic update (quitar card con animación).

Estado vacío: `<EmptyState icon={Heart} title="Todavía no guardaste activos" description="Explorá el catálogo y guardá los que te interesen" cta={<Button href="/explorar">Explorar activos</Button>} />`

---

## 6. Consultas — Lista (`/consultas`)

**Archivo:** `app/(dashboard)/consultas/page.tsx`

### Tabs

```
Todas (n) | Abiertas (n) | Respondidas (n) | Cerradas (n)
```

### InquiryCard

Stack vertical de cards. Cada una:

```
bg-navy-900 border border-slate-800 rounded-xl p-5
hover:bg-slate-800 cursor-pointer transition-colors
```

No leída: `border-l-4 border-l-amber-500`

Contenido:
- Row: avatar + nombre vendedor + "·" + nombre activo (link amber)
- Preview de último mensaje: `text-sm text-slate-400 truncate`
- Row: timestamp + badge de estado

Click → navega a `/consultas/{id}`

---

## 7. Consultas — Chat (`/consultas/[id]`)

**Archivo:** `app/(dashboard)/consultas/[id]/page.tsx`

### Layout

```
grid grid-cols-[1fr_380px] gap-6
```

### Columna principal — Chat

**Thread de mensajes:**

Mensajes propios (alineados derecha):
```tsx
<div className="flex justify-end">
  <div className="max-w-[70%] bg-amber-500/15 border border-amber-500/20 rounded-xl p-4">
    <p className="text-sm text-slate-50">{message.content}</p>
    <p className="text-xs text-slate-500 text-right mt-1">{formatTime(message.createdAt)}</p>
  </div>
</div>
```

Mensajes del otro (alineados izquierda):
```tsx
<div className="flex gap-3">
  <Avatar initials={sender.initials} size="sm" />
  <div className="max-w-[70%] bg-navy-900 border border-slate-800 rounded-xl p-4">
    <p className="text-xs text-slate-400 mb-1">{sender.name}</p>
    <p className="text-sm text-slate-50">{message.content}</p>
    <p className="text-xs text-slate-500 mt-1">{formatTime(message.createdAt)}</p>
  </div>
</div>
```

**Input sticky abajo:**
```tsx
<div className="sticky bottom-0 border-t border-slate-800 bg-navy-950 p-4">
  <div className="flex gap-3">
    <Textarea
      rows={2}
      placeholder="Escribí tu mensaje..."
      value={message}
      onChange={setMessage}
      onKeyDown={handleKeyDown}  // Enter sin Shift → envía
    />
    <Button variant="solid" onClick={sendMessage} icon={<Send size={16} />}>
      Enviar
    </Button>
  </div>
</div>
```

Envío: Server Action `sendInquiryMessage(inquiryId, content)` con optimistic update.

### Columna derecha — Info del activo

```tsx
<Card className="p-5 sticky top-24">
  <img src={listing.screenshot} className="w-full h-32 object-cover rounded-lg mb-4" />
  <h3 className="font-semibold text-slate-50">{listing.title}</h3>
  <p className="text-xl font-bold text-amber-500 mt-1">${listing.priceUsd.toLocaleString()} USD</p>
  <Badge variant="success">Verificado</Badge>
  <Divider className="my-4" />
  <div className="space-y-1 text-sm">
    <MetricRow label="MRR" value={`$${listing.mrr}`} />
    <MetricRow label="Usuarios" value={listing.users} />
    <MetricRow label="Churn" value={`${listing.churn}%`} />
  </div>
  <Divider className="my-4" />
  <div className="flex items-center gap-2">
    <Avatar initials={seller.initials} size="sm" />
    <div>
      <p className="text-sm text-slate-50">{seller.name}</p>
      <p className="text-xs text-emerald-500">Vendedor verificado ✓</p>
    </div>
  </div>
  <Button variant="link" href={`/explorar/${listing.slug}`} className="mt-3">
    Ver listado completo →
  </Button>
</Card>
```

---

## 8. Perfil (`/perfil`)

**Archivo:** `app/(dashboard)/perfil/page.tsx`

### Cards en stack vertical

1. **Card Avatar** — layout horizontal: avatar 80px con iniciales + nombre + email + "Miembro desde..." + botón "Cambiar foto"
2. **Card Información personal** — 2 columnas de inputs, bio textarea, botón guardar
3. **Card Seguridad** — cambiar contraseña, sesiones activas, cerrar todas
4. **Card Notificaciones** — toggles switch

**Email field:** siempre `disabled`. Mostrar "Verificado ✓" en `text-emerald-500 text-xs`.

**Formulario:** usar `react-hook-form` + `zod` para validación. Server Action `updateProfile(data)`.

---

## 9. Panel Admin

Ver `docs/frontend/05-admin.md` para especificación completa.
