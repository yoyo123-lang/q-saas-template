// Tests for the listings data access layer.
// Run with: npx vitest (requires vitest to be installed)
//
// These tests mock the Prisma client so no real DB connection is needed.

import { describe, it, expect, vi, beforeEach } from 'vitest'

// Mock the prisma module before importing the functions under test
const mockListing_internal = {
  findMany: vi.fn(),
  findFirst: vi.fn(),
  count: vi.fn(),
  update: vi.fn(),
}

vi.mock('@/lib/prisma', () => ({
  getPrisma: () => ({
    listing: mockListing_internal,
  }),
}))

const prisma = { listing: mockListing_internal }
import { getListings, getListing, getRelatedListings, incrementListingViews } from '../listings'

const mockListing = {
  id: 'uuid-1',
  slug: 'test-listing',
  title: 'Test SaaS',
  description: 'A test description',
  type: 'SAAS',
  status: 'PUBLISHED',
  verificationStatus: 'UNVERIFIED',
  askingPrice: '15000.00',
  currency: 'USD',
  monthlyRevenue: '1200.00',
  monthlyTraffic: 5000,
  techStack: ['Next.js', 'Stripe'],
  tags: [],
  screenshotUrls: [],
  featuredUntil: null,
  viewCount: 42,
  sellerId: 'seller-uuid',
  categoryId: 'cat-uuid',
  createdAt: new Date(),
  updatedAt: new Date(),
  publishedAt: new Date(),
  rejectionReason: null,
  domainAge: null,
  url: null,
  seller: { id: 'seller-uuid', email: 'test@test.com', fullName: 'Test Seller' },
  metrics: [],
  category: { id: 'cat-uuid', slug: 'saas', name: 'SaaS' },
}

beforeEach(() => {
  vi.clearAllMocks()
})

describe('getListings', () => {
  it('returns published listings with default params', async () => {
    const mockFindMany = vi.mocked(prisma.listing.findMany)
    const mockCount = vi.mocked(prisma.listing.count)
    mockFindMany.mockResolvedValue([mockListing] as never)
    mockCount.mockResolvedValue(1)

    const result = await getListings()

    expect(result.items).toHaveLength(1)
    expect(result.total).toBe(1)
    expect(mockFindMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ status: 'PUBLISHED' }),
        take: 20,
        skip: 0,
      })
    )
  })

  it('applies text search filter when q is provided', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ q: 'saas' })

    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          OR: expect.arrayContaining([
            expect.objectContaining({ title: expect.objectContaining({ contains: 'saas' }) }),
          ]),
        }),
      })
    )
  })

  it('applies category filter', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ category: 'saas' })

    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          category: { slug: 'saas' },
        }),
      })
    )
  })

  it('applies price range filter', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ priceMin: 1000, priceMax: 50000 })

    const call = vi.mocked(prisma.listing.findMany).mock.calls[0][0]
    expect(call.where?.askingPrice).toBeDefined()
  })

  it('applies verified filter', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ verified: true })

    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ verificationStatus: 'VERIFIED' }),
      })
    )
  })

  it('paginates correctly — page 2', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ page: 2 })

    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({ skip: 20, take: 20 })
    )
  })

  it('caps page size at MAX_PAGE_SIZE (100)', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ limit: 999 })

    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({ take: 100 })
    )
  })

  it('returns empty items when no results', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    const result = await getListings({ q: 'nonexistent-xyz' })

    expect(result.items).toHaveLength(0)
    expect(result.total).toBe(0)
  })

  it('sorts by price ascending when sort=price_asc', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ sort: 'price_asc' })

    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({ orderBy: { askingPrice: 'asc' } })
    )
  })

  it('ignores empty q string', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([] as never)
    vi.mocked(prisma.listing.count).mockResolvedValue(0)

    await getListings({ q: '   ' })

    const call = vi.mocked(prisma.listing.findMany).mock.calls[0][0]
    expect(call.where?.OR).toBeUndefined()
  })
})

describe('getListing', () => {
  it('returns a listing by slug', async () => {
    vi.mocked(prisma.listing.findFirst).mockResolvedValue(mockListing as never)

    const result = await getListing('test-listing')

    expect(result).toEqual(mockListing)
    expect(prisma.listing.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { slug: 'test-listing', status: 'PUBLISHED' },
      })
    )
  })

  it('returns null when listing not found', async () => {
    vi.mocked(prisma.listing.findFirst).mockResolvedValue(null)

    const result = await getListing('non-existent-slug')

    expect(result).toBeNull()
  })
})

describe('getRelatedListings', () => {
  it('returns related listings excluding current', async () => {
    vi.mocked(prisma.listing.findMany).mockResolvedValue([mockListing] as never)

    const result = await getRelatedListings('uuid-1', 'SAAS', 3)

    expect(result).toHaveLength(1)
    expect(prisma.listing.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          type: 'SAAS',
          id: { not: 'uuid-1' },
        }),
        take: 3,
      })
    )
  })
})

describe('incrementListingViews', () => {
  it('increments view count', async () => {
    vi.mocked(prisma.listing.update).mockResolvedValue(mockListing as never)

    await incrementListingViews('uuid-1')

    expect(prisma.listing.update).toHaveBeenCalledWith({
      where: { id: 'uuid-1' },
      data: { viewCount: { increment: 1 } },
    })
  })
})
