'use client'

import { useRef, useState } from 'react'
import type { FileAnswer } from './types'

const ACCEPTED_EXT = '.pdf,.doc,.docx,.txt'
const MAX_SIZE_BYTES = 10 * 1024 * 1024 // 10 MB
const ACCEPTED_EXTENSIONS = new Set(['.pdf', '.doc', '.docx', '.txt'])

export function FileUploadInput({
  value,
  onChange,
  disabled,
  placeholder,
}: {
  value: FileAnswer | null
  onChange: (v: unknown) => void
  disabled: boolean
  placeholder?: string
}) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver] = useState(false)
  const [sizeError, setSizeError] = useState(false)
  const [typeError, setTypeError] = useState(false)

  function handleFile(file: File) {
    setSizeError(false)
    setTypeError(false)
    const ext = '.' + file.name.split('.').pop()?.toLowerCase()
    if (!ACCEPTED_EXTENSIONS.has(ext)) {
      setTypeError(true)
      return
    }
    if (file.size > MAX_SIZE_BYTES) {
      setSizeError(true)
      return
    }
    onChange({ name: file.name, size: file.size, mimeType: file.type } satisfies FileAnswer)
  }

  function formatSize(bytes: number) {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  if (value) {
    return (
      <div className="flex items-center gap-3 px-4 py-3 bg-[#0B0F1A] border border-[#8B5CF6]/40 rounded-lg">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" strokeWidth="1.5" aria-hidden="true">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" strokeLinecap="round" />
        </svg>
        <div className="flex-1 min-w-0">
          <p className="text-white text-sm truncate">{value.name}</p>
          <p className="text-[#64748B] text-xs">{formatSize(value.size)}</p>
        </div>
        {!disabled && (
          <button
            type="button"
            onClick={() => { onChange(null); setSizeError(false) }}
            className="text-[#475569] hover:text-[#94A3B8] transition-colors"
            aria-label="Eliminar archivo"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
            </svg>
          </button>
        )}
      </div>
    )
  }

  return (
    <div>
      <button
        type="button"
        disabled={disabled}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragOver(false)
          const file = e.dataTransfer.files[0]
          if (file) handleFile(file)
        }}
        className={`w-full rounded-lg border-2 border-dashed px-6 py-8 text-center transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
          dragOver ? 'border-[#8B5CF6] bg-[#8B5CF6]/5' : 'border-[#1E293B] hover:border-[#334155]'
        }`}
      >
        <svg className="mx-auto mb-3" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="1.5" aria-hidden="true">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <path d="M17 8l-5-5-5 5M12 3v12" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <p className="text-[#64748B] text-sm">
          {placeholder ?? 'Arrastrá un archivo o hacé clic para seleccionar'}
        </p>
        <p className="text-[#475569] text-xs mt-1">PDF, DOC, DOCX o TXT — máx. 10 MB</p>
      </button>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED_EXT}
        className="sr-only"
        aria-hidden="true"
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) handleFile(file)
          e.target.value = ''
        }}
      />
      {typeError && (
        <p className="text-[#EF4444] text-xs mt-2">Tipo de archivo no permitido. Solo se aceptan: PDF, DOC, DOCX, TXT.</p>
      )}
      {sizeError && (
        <p className="text-[#EF4444] text-xs mt-2">El archivo supera el límite de 10 MB.</p>
      )}
    </div>
  )
}
