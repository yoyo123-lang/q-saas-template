'use client'

import { useState, useTransition, useEffect } from 'react'
import { ChangePasswordForm } from './ChangePasswordForm'
import { InfoRow } from './InfoRow'

const PLAN_LABELS: Record<string, string> = {
  BASE: 'Base',
  COMPLETO: 'Completo',
  PREMIUM: 'Premium',
}

const STATUS_LABELS: Record<string, string> = {
  DISCOVERY: 'Descubrimiento',
  RESEARCH: 'Investigación',
  BRAND: 'Marca',
  WEBSITE: 'Sitio web',
  CAMPAIGNS: 'Campañas',
  MEDIA: 'Medios',
  LAUNCHED: 'Lanzado',
  PAUSED: 'Pausado',
}

type OrgData = {
  name: string
  industry: string
  plan: string
  status: string
  createdAt: Date
  websiteUrl: string | null
}

type Props = {
  displayName: string
  email: string
  avatarUrl: string | null
  authProvider: string
  isLegacy: boolean
  orgData: OrgData | null
}

export function AccountTab({ displayName: initialName, email, avatarUrl: initialAvatarUrl, authProvider, isLegacy, orgData }: Props) {
  const [isPending, startTransition] = useTransition()
  const [displayName, setDisplayName] = useState(initialName)
  const [avatarUrl, setAvatarUrl] = useState(initialAvatarUrl ?? '')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    if (!success) return
    const timer = setTimeout(() => setSuccess(false), 3000)
    return () => clearTimeout(timer)
  }, [success])

  function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    const trimmed = displayName.trim()
    if (!trimmed) {
      setError('El nombre no puede estar vacío')
      return
    }

    startTransition(async () => {
      const res = await fetch('/api/settings/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName: trimmed, avatarUrl: avatarUrl.trim() || null }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error ?? 'Error al guardar')
        return
      }
      setSuccess(true)
    })
  }

  const memberSince = orgData?.createdAt
    ? new Date(orgData.createdAt).toLocaleDateString('es-AR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      })
    : null

  return (
    <div className="flex flex-col gap-6">
      {/* Perfil */}
      <section>
        <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
          Tu cuenta
        </h2>
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl px-5 py-4">
          <form onSubmit={handleSave} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label htmlFor="account-name" className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
                Nombre
              </label>
              <input
                id="account-name"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                maxLength={150}
                disabled={isPending}
                className="bg-[#0B1120] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label htmlFor="account-avatar" className="text-[#94A3B8] text-xs font-medium uppercase tracking-wider">
                URL de avatar <span className="normal-case font-normal">(opcional)</span>
              </label>
              <input
                id="account-avatar"
                type="url"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://..."
                disabled={isPending}
                className="bg-[#0B1120] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-white placeholder-[#475569] focus:outline-none focus:border-[#8B5CF6] disabled:opacity-50"
              />
            </div>

            <InfoRow label="Email" value={email} />

            {error && (
              <div className="bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444] text-sm rounded-lg px-4 py-2">
                {error}
              </div>
            )}

            {success && (
              <div className="bg-[#10B981]/10 border border-[#10B981]/30 text-[#34D399] text-sm rounded-lg px-4 py-2">
                Cambios guardados correctamente.
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={isPending}
                className="bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
              >
                {isPending ? 'Guardando…' : 'Guardar cambios'}
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Cambiar contraseña */}
      <section>
        <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
          Contraseña
        </h2>
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl px-5 py-4">
          <ChangePasswordForm authProvider={authProvider} />
        </div>
      </section>

      {/* Negocio (solo legacy) */}
      {isLegacy && orgData && (
        <section>
          <h2 className="text-[#64748B] text-xs font-semibold uppercase tracking-wider mb-3">
            Tu negocio
          </h2>
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl px-5">
            <InfoRow label="Nombre" value={orgData.name} />
            <InfoRow label="Rubro" value={orgData.industry} />
            <InfoRow label="Plan" value={PLAN_LABELS[orgData.plan] ?? orgData.plan} />
            <InfoRow label="Estado del proyecto" value={STATUS_LABELS[orgData.status] ?? orgData.status} />
            {memberSince && <InfoRow label="Cliente desde" value={memberSince} />}
            {orgData.websiteUrl && (
              <div className="flex items-center justify-between py-3">
                <span className="text-[#94A3B8] text-sm">Sitio web</span>
                <a
                  href={orgData.websiteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#A78BFA] text-sm font-medium hover:underline"
                >
                  {orgData.websiteUrl}
                </a>
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  )
}
