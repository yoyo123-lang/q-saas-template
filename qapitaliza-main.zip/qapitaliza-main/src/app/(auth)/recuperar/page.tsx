'use client'

import { useState, useTransition } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import Link from 'next/link'
import { CheckCircle } from 'lucide-react'
import { toast } from 'sonner'
import { requestPasswordReset } from '@/lib/actions/auth'
import { recuperarSchema, type RecuperarData } from '@/lib/schemas/auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function RecuperarPage() {
  const [submitted, setSubmitted] = useState(false)
  const [isPending, startTransition] = useTransition()

  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields },
  } = useForm<RecuperarData>({
    resolver: zodResolver(recuperarSchema),
    mode: 'onBlur',
  })

  const onSubmit = (data: RecuperarData) => {
    startTransition(async () => {
      const redirectTo = `${window.location.origin}/nueva-contrasena`
      const result = await requestPasswordReset(data.email, redirectTo)
      if (!result.success && result.error) {
        toast.error(result.error)
        return
      }
      // Siempre mostrar la vista de éxito (no revelar si el email existe o no)
      setSubmitted(true)
    })
  }

  if (submitted) {
    return (
      <div className="w-full max-w-sm space-y-6 text-center">
        <div className="flex justify-center">
          <CheckCircle className="text-emerald-500" size={48} />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-slate-50">Revisá tu email</h1>
          <p className="text-sm text-slate-400 mt-2">
            Si existe una cuenta con ese email, recibirás las instrucciones en los próximos minutos.
          </p>
        </div>
        <Link
          href="/login"
          className="block text-sm text-amber-500 hover:text-amber-400"
        >
          Volver al inicio de sesión
        </Link>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-sm space-y-4">
      <div>
        <h1 className="text-2xl font-semibold text-slate-50">Recuperar contraseña</h1>
        <p className="text-sm text-slate-400 mt-1">
          Ingresá tu email y te enviamos las instrucciones.
        </p>
      </div>

      <Input
        label="Email"
        type="email"
        placeholder="tu@email.com"
        autoComplete="email"
        {...register('email')}
        error={touchedFields.email ? errors.email?.message : undefined}
      />

      <Button type="submit" variant="solid" size="full" loading={isPending}>
        Enviar instrucciones
      </Button>

      <p className="text-sm text-center text-slate-400">
        <Link href="/login" className="text-amber-500 hover:text-amber-400">
          Volver al inicio de sesión
        </Link>
      </p>
    </form>
  )
}
