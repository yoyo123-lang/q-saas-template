import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'
import { generateVariants } from '@qautiva/stitch'

export const maxDuration = 120

interface VariantsBody {
  templateId: string
  prompt: string
  count?: number
}

function isValidUUID(id: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
}

const MAX_VARIANTS = 5

/**
 * POST /api/stitch/variants
 * Genera variantes de un template Stitch existente.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: VariantsBody
  try {
    body = (await req.json()) as VariantsBody
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { templateId, prompt, count } = body

  if (!templateId || !isValidUUID(templateId)) {
    return NextResponse.json({ error: 'templateId debe ser un UUID válido' }, { status: 400 })
  }
  if (!prompt || !prompt.trim()) {
    return NextResponse.json({ error: 'prompt es requerido' }, { status: 400 })
  }
  if (count !== undefined && count > MAX_VARIANTS) {
    return NextResponse.json(
      { error: `count no puede superar ${MAX_VARIANTS}` },
      { status: 400 },
    )
  }

  const template = await prisma.webTemplate.findUnique({
    where: { id: templateId },
    select: {
      id: true,
      source: true,
      stitchProjectId: true,
      stitchScreenId: true,
    },
  })

  if (!template) {
    return NextResponse.json({ error: 'Template no encontrado' }, { status: 404 })
  }
  if (template.source !== 'STITCH') {
    return NextResponse.json(
      { error: 'Este template no fue creado con Stitch' },
      { status: 400 },
    )
  }
  if (!template.stitchProjectId || !template.stitchScreenId) {
    return NextResponse.json(
      { error: 'El template no tiene stitchProjectId o stitchScreenId' },
      { status: 400 },
    )
  }

  try {
    const variants = await generateVariants({
      stitchProjectId: template.stitchProjectId,
      stitchScreenId: template.stitchScreenId,
      prompt,
      count,
    })

    return NextResponse.json({ variants })
  } catch (err) {
    console.error('[stitch:variants] error', err instanceof Error ? err.message : String(err))
    return NextResponse.json({ error: 'Error interno al generar variantes' }, { status: 500 })
  }
}
