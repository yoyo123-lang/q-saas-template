import { prisma } from '@qautiva/db'
import type { UsageSource } from '@qautiva/db'

export interface UpdateBillingConsumptionParams {
  teamId: string | null
  source: UsageSource
  tokensIn: number
  tokensOut: number
  totalUsd: number
}

/**
 * Actualiza el `BillingAccount` del team según la fuente de consumo:
 * - TRIAL: incrementa `trialTokensUsed` por `tokensIn + tokensOut`.
 * - QAUTIVA_HOSTED: decrementa `balanceUsd` por `totalUsd`.
 * - BYOK: no-op (el usuario paga su propia API key).
 *
 * Si `teamId` es null, no hace nada.
 * Lanza error ruidoso (CRITICAL) si la operación de DB falla.
 */
export async function updateBillingConsumption(params: UpdateBillingConsumptionParams): Promise<void> {
  const { teamId, source, tokensIn, tokensOut, totalUsd } = params

  if (!teamId) return
  if (source === 'BYOK') return

  try {
    if (source === 'TRIAL') {
      await prisma.billingAccount.update({
        where: { teamId },
        data: { trialTokensUsed: { increment: tokensIn + tokensOut } },
      })
    } else if (source === 'QAUTIVA_HOSTED') {
      await prisma.billingAccount.update({
        where: { teamId },
        data: { balanceUsd: { decrement: totalUsd } },
      })
    }
  } catch (err) {
    const msg = `CRITICAL: Error al actualizar BillingAccount para teamId=${teamId} source=${source}`
    console.error(msg, { err, tokensIn, tokensOut, totalUsd })
    throw err
  }
}
