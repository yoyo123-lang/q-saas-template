'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { MoreHorizontal, User, RefreshCw, Ban, Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils/cn'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Modal } from '@/components/ui/modal'
import { suspendUser, changeUserRole, deleteUser } from '@/lib/actions/admin'
import type { AdminUserItem } from '@/lib/data/admin'

const ROLE_LABELS: Record<string, string> = {
  SELLER: 'Vendedor',
  BUYER: 'Comprador',
  ADMIN: 'Admin',
}

const ROLE_VARIANTS: Record<string, 'info' | 'muted' | 'amber'> = {
  SELLER: 'info',
  BUYER: 'muted',
  ADMIN: 'amber',
}

const ROLE_AVATAR_COLORS: Record<string, string> = {
  SELLER: 'bg-amber-500 text-navy-950',
  BUYER: 'bg-blue-500 text-white',
  ADMIN: 'bg-purple-500 text-white',
}

const ROLE_OPTIONS = [
  { label: 'Comprador', value: 'BUYER' },
  { label: 'Vendedor', value: 'SELLER' },
  { label: 'Admin', value: 'ADMIN' },
]

type ModalType = 'changeRole' | 'suspend' | 'delete' | null

interface Props {
  users: AdminUserItem[]
}

export function AdminUsersTable({ users }: Props) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [openMenu, setOpenMenu] = useState<string | null>(null)
  const [modal, setModal] = useState<{ type: ModalType; userId: string } | null>(null)
  const [newRole, setNewRole] = useState('BUYER')
  const [suspendReason, setSuspendReason] = useState('')
  const [loading, setLoading] = useState(false)
  const [modalError, setModalError] = useState<string | null>(null)

  function closeModal() {
    setModal(null)
    setSuspendReason('')
    setNewRole('BUYER')
    setModalError(null)
  }

  async function handleChangeRole() {
    if (!modal) return
    setLoading(true)
    setModalError(null)
    const result = await changeUserRole(modal.userId, newRole as 'BUYER' | 'SELLER' | 'ADMIN')
    setLoading(false)
    if (!result.success) {
      setModalError(result.error ?? 'Error al cambiar el rol.')
      return
    }
    closeModal()
    startTransition(() => router.refresh())
  }

  async function handleSuspend() {
    if (!modal || !suspendReason.trim()) return
    setLoading(true)
    setModalError(null)
    const result = await suspendUser(modal.userId, suspendReason.trim())
    setLoading(false)
    if (!result.success) {
      setModalError(result.error ?? 'Error al suspender el usuario.')
      return
    }
    closeModal()
    startTransition(() => router.refresh())
  }

  async function handleDelete() {
    if (!modal) return
    setLoading(true)
    setModalError(null)
    const result = await deleteUser(modal.userId)
    setLoading(false)
    if (!result.success) {
      setModalError(result.error ?? 'Error al eliminar el usuario.')
      return
    }
    closeModal()
    startTransition(() => router.refresh())
  }

  return (
    <>
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/50">
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide">
                Usuario
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden md:table-cell">
                Email
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide">
                Rol
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden lg:table-cell">
                Listados
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden lg:table-cell">
                Registrado
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wide hidden md:table-cell">
                Estado
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-slate-400 uppercase tracking-wide">
                ⋯
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {users.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center text-slate-500">
                  No hay usuarios para mostrar.
                </td>
              </tr>
            ) : (
              users.map((user) => {
                const name = user.fullName ?? user.email ?? 'Usuario'
                const initials = name.split(' ').slice(0, 2).map((n) => n[0]?.toUpperCase() ?? '').join('')
                const isSuspended = !!user.suspendedAt

                return (
                  <tr key={user.id} className="hover:bg-slate-800/30 transition-colors">
                    {/* Avatar + name */}
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            'size-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0',
                            ROLE_AVATAR_COLORS[user.role] ?? 'bg-slate-700 text-slate-200'
                          )}
                        >
                          {initials || 'U'}
                        </div>
                        <span className="text-slate-200 font-medium truncate max-w-[140px]">{name}</span>
                      </div>
                    </td>

                    {/* Email */}
                    <td className="px-4 py-3 text-slate-400 text-xs hidden md:table-cell truncate max-w-[200px]">
                      {user.email}
                    </td>

                    {/* Role */}
                    <td className="px-4 py-3">
                      <Badge variant={ROLE_VARIANTS[user.role] ?? 'muted'}>
                        {ROLE_LABELS[user.role] ?? user.role}
                      </Badge>
                    </td>

                    {/* Listings count */}
                    <td className="px-4 py-3 text-slate-400 text-sm hidden lg:table-cell">
                      {user._count.listings}
                    </td>

                    {/* Registered */}
                    <td className="px-4 py-3 text-slate-500 text-xs hidden lg:table-cell whitespace-nowrap">
                      {new Date(user.createdAt).toLocaleDateString('es-AR')}
                    </td>

                    {/* Status */}
                    <td className="px-4 py-3 hidden md:table-cell">
                      {isSuspended ? (
                        <Badge variant="danger">Suspendido</Badge>
                      ) : (
                        <Badge variant="success">Activo</Badge>
                      )}
                    </td>

                    {/* Menu */}
                    <td className="px-4 py-3 text-right relative">
                      <button
                        onClick={() => setOpenMenu(openMenu === user.id ? null : user.id)}
                        className="p-1.5 text-slate-400 hover:text-slate-50 hover:bg-slate-800 rounded-lg transition-colors"
                        aria-label="Más opciones"
                      >
                        <MoreHorizontal className="size-4" />
                      </button>

                      {openMenu === user.id && (
                        <>
                          <div
                            className="fixed inset-0 z-10"
                            onClick={() => setOpenMenu(null)}
                          />
                          <div className="absolute right-4 top-full mt-1 z-20 w-44 bg-navy-900 border border-slate-800 rounded-xl shadow-xl overflow-hidden">
                            <Link
                              href={`/admin/usuarios/${user.id}`}
                              className="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-300 hover:bg-slate-800 hover:text-slate-50 transition-colors"
                              onClick={() => setOpenMenu(null)}
                            >
                              <User className="size-3.5" />
                              Ver perfil
                            </Link>
                            <button
                              className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-slate-300 hover:bg-slate-800 hover:text-slate-50 transition-colors"
                              onClick={() => { setModal({ type: 'changeRole', userId: user.id }); setNewRole(user.role); setOpenMenu(null) }}
                            >
                              <RefreshCw className="size-3.5" />
                              Cambiar rol
                            </button>
                            <button
                              className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 transition-colors"
                              onClick={() => { setModal({ type: 'suspend', userId: user.id }); setOpenMenu(null) }}
                            >
                              <Ban className="size-3.5" />
                              Suspender
                            </button>
                            <button
                              className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 transition-colors"
                              onClick={() => { setModal({ type: 'delete', userId: user.id }); setOpenMenu(null) }}
                            >
                              <Trash2 className="size-3.5" />
                              Eliminar
                            </button>
                          </div>
                        </>
                      )}
                    </td>
                  </tr>
                )
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Change role modal */}
      <Modal
        open={modal?.type === 'changeRole'}
        onClose={closeModal}
        title="Cambiar rol de usuario"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-400">Seleccioná el nuevo rol para este usuario.</p>
          {modalError && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
              <p className="text-xs text-red-400">{modalError}</p>
            </div>
          )}
          <select
            value={newRole}
            onChange={(e) => setNewRole(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            {ROLE_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <div className="flex gap-3">
            <Button variant="solid" size="md" onClick={handleChangeRole} loading={loading} className="flex-1">
              Confirmar
            </Button>
            <Button variant="ghost" size="md" onClick={closeModal} className="flex-1">
              Cancelar
            </Button>
          </div>
        </div>
      </Modal>

      {/* Suspend modal */}
      <Modal
        open={modal?.type === 'suspend'}
        onClose={closeModal}
        title="Suspender usuario"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-400">
            El usuario no podrá acceder a la plataforma. Ingresá el motivo.
          </p>
          {modalError && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
              <p className="text-xs text-red-400">{modalError}</p>
            </div>
          )}
          <textarea
            className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-500 resize-none focus:outline-none focus:ring-2 focus:ring-amber-500"
            placeholder="Motivo de la suspensión..."
            value={suspendReason}
            onChange={(e) => setSuspendReason(e.target.value)}
            rows={3}
            autoFocus
          />
          <div className="flex gap-3">
            <Button
              variant="outline-danger"
              size="md"
              onClick={handleSuspend}
              loading={loading}
              disabled={!suspendReason.trim()}
              className="flex-1"
            >
              Suspender
            </Button>
            <Button variant="ghost" size="md" onClick={closeModal} className="flex-1">
              Cancelar
            </Button>
          </div>
        </div>
      </Modal>

      {/* Delete modal */}
      <Modal
        open={modal?.type === 'delete'}
        onClose={closeModal}
        title="Eliminar usuario"
        size="sm"
      >
        <div className="space-y-4">
          {modalError && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
              <p className="text-xs text-red-400">{modalError}</p>
            </div>
          )}
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-sm font-medium text-red-400">⚠ Acción irreversible</p>
            <p className="text-xs text-red-400/80 mt-1">
              El usuario será eliminado en 90 días. Sus listados pasarán a estado PAUSED.
            </p>
          </div>
          <p className="text-sm text-slate-400">¿Confirmás la eliminación de este usuario?</p>
          <div className="flex gap-3">
            <Button
              variant="outline-danger"
              size="md"
              onClick={handleDelete}
              loading={loading}
              className="flex-1"
            >
              Eliminar
            </Button>
            <Button variant="ghost" size="md" onClick={closeModal} className="flex-1">
              Cancelar
            </Button>
          </div>
        </div>
      </Modal>
    </>
  )
}
