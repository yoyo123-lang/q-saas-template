/**
 * Tests TDD para checkTeamPermission().
 *
 * Cubre:
 * - OWNER pasa para ['OWNER']
 * - ADMIN pasa para ['ADMIN', 'OWNER']
 * - MEMBER falla para ['ADMIN', 'OWNER']
 * - Usuario no miembro del team → no autorizado
 * - Usuario inexistente (sin UserProfile) → no autorizado
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const { mockUserProfileFindUnique } = vi.hoisted(() => ({
  mockUserProfileFindUnique: vi.fn(),
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    userProfile: { findUnique: mockUserProfileFindUnique },
  },
}))

// ── Imports ───────────────────────────────────────────────────────────────────

import { checkTeamPermission } from '../check-team-permission'

// ── Helpers ───────────────────────────────────────────────────────────────────

function mockMembership(role: 'OWNER' | 'ADMIN' | 'MEMBER') {
  mockUserProfileFindUnique.mockResolvedValueOnce({
    teamMemberships: [{ role }],
  })
}

function mockNoProfile() {
  mockUserProfileFindUnique.mockResolvedValueOnce(null)
}

function mockNoMembership() {
  mockUserProfileFindUnique.mockResolvedValueOnce({
    teamMemberships: [],
  })
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('checkTeamPermission', () => {
  beforeEach(() => {
    mockUserProfileFindUnique.mockReset()
  })

  it('OWNER pasa para requiredRoles=[OWNER]', async () => {
    mockMembership('OWNER')
    const result = await checkTeamPermission('auth-user-1', 'team-1', ['OWNER'])
    expect(result.authorized).toBe(true)
    expect(result.role).toBe('OWNER')
  })

  it('OWNER pasa para requiredRoles=[ADMIN, OWNER]', async () => {
    mockMembership('OWNER')
    const result = await checkTeamPermission('auth-user-1', 'team-1', ['ADMIN', 'OWNER'])
    expect(result.authorized).toBe(true)
    expect(result.role).toBe('OWNER')
  })

  it('ADMIN pasa para requiredRoles=[ADMIN, OWNER]', async () => {
    mockMembership('ADMIN')
    const result = await checkTeamPermission('auth-user-1', 'team-1', ['ADMIN', 'OWNER'])
    expect(result.authorized).toBe(true)
    expect(result.role).toBe('ADMIN')
  })

  it('MEMBER falla para requiredRoles=[ADMIN, OWNER]', async () => {
    mockMembership('MEMBER')
    const result = await checkTeamPermission('auth-user-1', 'team-1', ['ADMIN', 'OWNER'])
    expect(result.authorized).toBe(false)
    expect(result.role).toBe('MEMBER')
  })

  it('MEMBER falla para requiredRoles=[OWNER]', async () => {
    mockMembership('MEMBER')
    const result = await checkTeamPermission('auth-user-1', 'team-1', ['OWNER'])
    expect(result.authorized).toBe(false)
    expect(result.role).toBe('MEMBER')
  })

  it('ADMIN falla para requiredRoles=[OWNER] (solo OWNER puede)', async () => {
    mockMembership('ADMIN')
    const result = await checkTeamPermission('auth-user-1', 'team-1', ['OWNER'])
    expect(result.authorized).toBe(false)
    expect(result.role).toBe('ADMIN')
  })

  it('usuario sin UserProfile → no autorizado, role=null', async () => {
    mockNoProfile()
    const result = await checkTeamPermission('auth-user-ghost', 'team-1', ['ADMIN', 'OWNER'])
    expect(result.authorized).toBe(false)
    expect(result.role).toBeNull()
  })

  it('usuario sin membresía en el team específico → no autorizado, role=null', async () => {
    mockNoMembership()
    const result = await checkTeamPermission('auth-user-1', 'team-otro', ['ADMIN', 'OWNER'])
    expect(result.authorized).toBe(false)
    expect(result.role).toBeNull()
  })

  it('consulta con el teamId correcto (filtrado en DB, no en memoria)', async () => {
    mockMembership('ADMIN')
    await checkTeamPermission('auth-user-1', 'team-xyz', ['ADMIN', 'OWNER'])
    const call = mockUserProfileFindUnique.mock.calls[0]![0]
    // Debe filtrar teamMemberships por teamId en la query
    expect(call.select.teamMemberships.where?.teamId).toBe('team-xyz')
  })

  it('requiredRoles=[] → siempre deniega (fail-closed)', async () => {
    mockMembership('OWNER')
    const result = await checkTeamPermission('auth-user-1', 'team-1', [])
    expect(result.authorized).toBe(false)
    expect(result.role).toBe('OWNER')
  })
})
