# Business Logic Review
**Fecha:** 2026-03-25
**Archivos revisados:**
- `prisma/schema.prisma`
- `src/lib/tenant.ts`
- `prisma/seed.ts`

---

## Hallazgos

### CRÍTICO

#### BL-01 — No hay enforcement del plan activo al crear comprobantes
**Archivo:** `prisma/schema.prisma:180-196` + `prisma/schema.prisma:369-397`
**Descripción:** Un tenant puede tener `Subscription.status = CANCELLED` (o SUSPENDED) y aún así crear facturas e invoices via `withTenant`. No hay ningún check que valide si el tenant tiene una suscripción activa antes de permitirle operar. El sistema cobrará incorrectamente (o no cobrará) por tenants que deberían estar bloqueados.
**Escenario de riesgo:** Un tenant en SUSPENDED crea 500 facturas durante el período de suspensión. Cuando se reactive, ¿esas facturas son válidas? ¿Se cobra el período suspendido?
**Fix sugerido:** Implementar middleware/guard que verifique `Subscription.status IN ('ACTIVE', 'TRIAL')` antes de cada operación de escritura en modelos core (Invoice, Sale). El `withTenant` podría extenderse para incluir este check.

---

### ALTO

#### BL-02 — Cálculo de stock actual no existe como campo persistido
**Archivo:** `prisma/schema.prisma:506-531`
**Descripción:** `StockMovement` guarda `previousStock` y `newStock` (snapshot), pero no hay un modelo `ProductStock` o campo `currentStock` en `Product`. Para saber el stock actual de un producto, hay que consultar el último `StockMovement` por `(productId, warehouseId)` ordenado por `createdAt DESC`. Esto es costoso y no-obvio.
**Fix sugerido:** Agregar un modelo `ProductStock { organizationId, productId, warehouseId, quantity Decimal }` con unique constraint en `(productId, warehouseId)`. Actualizar este modelo en la misma transacción que el `StockMovement`.

#### BL-03 — `StockMovement.quantity` puede ser positivo o negativo sin constraint
**Archivo:** `prisma/schema.prisma:513`
**Descripción:** `quantity Decimal` sin constraint de signo. Para PURCHASE y TRANSFER_IN debería ser positivo. Para SALE, TRANSFER_OUT, RETURN podría ser positivo (y el tipo indica la dirección) o podría ser negativo. La convención no está documentada ni enforced. Un movimiento PURCHASE con `quantity = -10` sería semánticamente inválido pero técnicamente guardaría.
**Fix sugerido:** Documentar la convención (¿siempre positivo con el tipo indicando dirección?) y agregar validación en la capa de aplicación.

#### BL-04 — Múltiples listas de precios sin mecanismo de precedencia
**Archivo:** `prisma/schema.prisma:273-307`
**Descripción:** `PriceList` con `isDefault Boolean`. Pero si hay múltiples price lists, no hay lógica que defina cuál aplica a un contacto dado o a una venta. Un contact no tiene `priceListId`. No hay regla de negocio de "customer X usa price list Y".
**Fix sugerido:** Agregar `priceListId String?` a `Contact` para asignar una lista específica por cliente, o documentar que la selección de lista de precios es manual en cada venta.

---

### MEDIO

#### BL-05 — `PaymentRecord` puede referenciarse a una venta CANCELLED
**Archivo:** `prisma/schema.prisma:572-590`
**Descripción:** `PaymentRecord.saleId` es FK a `Sale` sin restricción de `Sale.status`. Se puede crear un pago para una venta cancelada. No hay constraint que impida `PaymentRecord` sobre `Sale.status = CANCELLED`.
**Fix sugerido:** Agregar validación de negocio: al crear un `PaymentRecord`, verificar que `Sale.status != CANCELLED`.

#### BL-06 — `Invoice.number Int` — posible desbordamiento o reuso si se cancela una factura
**Archivo:** `prisma/schema.prisma:373`
**Descripción:** AFIP requiere que los números de comprobante no se reusen aunque la factura sea cancelada. Un número `Int` que se genera con MAX+1 no garantiza que el número de una factura CANCELLED nunca sea reasignado si hay lógica que filtre por status antes de calcular el MAX.
**Fix sugerido:** La lógica de incremento de número debe considerar TODAS las facturas (incluso canceladas) para ese tipo/serie, nunca filtrar por status al calcular el siguiente número.

#### BL-07 — `Membership.role` no linkea con `Plan.maxUsers` en ninguna capa
**Archivo:** `prisma/schema.prisma:133-147` vs `prisma/schema.prisma:158-171`
**Descripción:** El plan define `maxUsers` pero no hay ningún mecanismo que al agregar un `Membership` verifique si el tenant ya llegó al límite de usuarios del plan. Una org MICRO (maxUsers=1) puede tener 10 memberships sin ningún error.
**Fix sugerido:** Implementar la validación en el endpoint/Server Action de creación de Membership: verificar `COUNT(memberships WHERE organizationId = x) < plan.maxUsers`.

---

### BAJO

#### BL-08 — `ContactType.BOTH` — semánticamente ambiguo para facturación
**Archivo:** `prisma/schema.prisma:319-323`
**Descripción:** `ContactType.BOTH` indica que un contacto es cliente Y proveedor. En el contexto de AFIP, cliente y proveedor tienen tratamientos fiscales diferentes. Un contacto BOTH requiere lógica adicional para determinar en qué contexto actúa (ej: al emitir una factura A, actúa como cliente).
**Fix sugerido:** Documentar cómo se maneja BOTH en los flujos de facturación. Asegurarse de que la UI lo explicite claramente.

---

## Resumen
| Severidad | Cantidad |
|-----------|----------|
| CRÍTICO   | 1        |
| ALTO      | 3        |
| MEDIO     | 3        |
| BAJO      | 1        |
| **Total** | **8**    |
