'use client'

import type { QuestionBlock } from '@/app/_lib/interview/types'

export function RatingInput({
  value,
  onChange,
  min,
  max,
  options,
  disabled,
}: {
  value: number | null
  onChange: (v: unknown) => void
  min: number
  max: number
  options?: QuestionBlock['options']
  disabled: boolean
}) {
  const steps = Array.from({ length: max - min + 1 }, (_, i) => min + i)
  const useStars = max <= 5

  function labelFor(n: number): string | undefined {
    return options?.find((o) => o.value === String(n))?.label
  }

  if (useStars) {
    return (
      <div>
        <div className="flex gap-2" role="radiogroup" aria-label="Calificación">
          {steps.map((star) => (
            <button
              key={star}
              type="button"
              role="radio"
              aria-checked={value === star}
              aria-label={labelFor(star) ?? `${star} ${star === 1 ? 'estrella' : 'estrellas'}`}
              disabled={disabled}
              onClick={() => onChange(star)}
              className="p-0.5 transition-transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill={value !== null && star <= value ? '#F59E0B' : 'none'}
                stroke={value !== null && star <= value ? '#F59E0B' : '#334155'}
                strokeWidth="1.5"
                aria-hidden="true"
              >
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
            </button>
          ))}
        </div>
        {value !== null && (
          <p className="text-[#94A3B8] text-xs mt-2">
            {labelFor(value) ?? `${value} de ${max}`}
          </p>
        )}
      </div>
    )
  }

  return (
    <div>
      <div className="flex gap-1.5 flex-wrap" role="radiogroup">
        {steps.map((n) => (
          <button
            key={n}
            type="button"
            role="radio"
            aria-checked={value === n}
            aria-label={labelFor(n) ?? String(n)}
            disabled={disabled}
            onClick={() => onChange(n)}
            className={`w-10 h-10 rounded-lg border text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
              value === n
                ? 'bg-[#8B5CF6] border-[#8B5CF6] text-white'
                : 'bg-[#0B0F1A] border-[#1E293B] text-[#94A3B8] hover:border-[#334155] hover:text-white'
            }`}
          >
            {n}
          </button>
        ))}
      </div>
      {options && options.length >= 2 && (
        <div className="flex justify-between mt-1.5">
          <span className="text-[#64748B] text-xs">{options[0]?.label}</span>
          <span className="text-[#64748B] text-xs">{options[options.length - 1]?.label}</span>
        </div>
      )}
    </div>
  )
}
