'use client'

import type { ActionState } from '@/app/(protected)/configuracion/actions'

export function SubmitButton({
  label = 'Guardar',
  size = 'md',
  pending = false,
}: {
  label?: string
  size?: 'sm' | 'md'
  pending?: boolean
}) {
  const cls = size === 'sm'
    ? 'px-3 py-1.5 text-xs'
    : 'px-4 py-2 text-sm'
  return (
    <button
      type="submit"
      disabled={pending}
      className={`${cls} bg-[#8B5CF6] text-white font-medium rounded-lg hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors`}
    >
      {pending ? 'Guardando...' : label}
    </button>
  )
}

export function StatusMessage({ state }: { state: ActionState | null }) {
  if (!state) return null
  if (state.ok) return <p className="text-sm text-green-400">Guardado correctamente.</p>
  return <p className="text-sm text-red-400">{state.error}</p>
}
