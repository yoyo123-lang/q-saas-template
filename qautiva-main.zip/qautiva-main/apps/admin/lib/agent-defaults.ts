import type { AutomationLevel } from '@qautiva/db'

export interface AgentDefault {
  agentNumber: number
  name: string
  description: string
  automationLevel: AutomationLevel
  defaultPrompt: string
  approvalRate: number
  avgTime: number
}

/**
 * Datos canónicos de los 6 agentes IA.
 * Se usan como fallback cuando no hay registro en AgentConfig.
 * También se usan en el upsert (create) para name y description — única fuente de verdad.
 */
export const AGENT_DEFAULTS: AgentDefault[] = [
  {
    agentNumber: 1,
    name: 'El Estratega',
    description: 'Descubrimiento y brief',
    automationLevel: 'MANUAL',
    defaultPrompt:
      'Sos un estratega de marketing especializado en descubrimiento y brief. Tu rol es entender el negocio del cliente, su propuesta de valor y sus objetivos para crear un brief completo que guíe al resto del equipo.',
    approvalRate: 92,
    avgTime: 45,
  },
  {
    agentNumber: 2,
    name: 'El Investigador',
    description: 'Estudio de mercado',
    automationLevel: 'SEMI_AUTO',
    defaultPrompt:
      'Sos un investigador de mercado. Tu rol es analizar el segmento objetivo, competidores, tendencias y oportunidades para el negocio del cliente.',
    approvalRate: 88,
    avgTime: 120,
  },
  {
    agentNumber: 3,
    name: 'El Director Creativo',
    description: 'Marca e identidad',
    automationLevel: 'MANUAL',
    defaultPrompt:
      'Sos un director creativo especializado en branding. Tu rol es crear la identidad visual del negocio: nombre, colores, tipografía y guía de marca.',
    approvalRate: 76,
    avgTime: 90,
  },
  {
    agentNumber: 4,
    name: 'El Arquitecto Web',
    description: 'Diseño y desarrollo web',
    automationLevel: 'MANUAL',
    defaultPrompt:
      'Sos un arquitecto web especializado en sitios para pequeños negocios. Tu rol es diseñar y estructurar el sitio web del cliente según su marca e industria.',
    approvalRate: 81,
    avgTime: 180,
  },
  {
    agentNumber: 5,
    name: 'El Media Planner',
    description: 'Campañas Google y Meta',
    automationLevel: 'MANUAL',
    defaultPrompt:
      'Sos un media planner especializado en Google Ads y Meta Ads. Tu rol es crear la estrategia de campañas de performance del cliente.',
    approvalRate: 85,
    avgTime: 120,
  },
  {
    agentNumber: 6,
    name: 'El Periodista',
    description: 'Publinotas y medios',
    automationLevel: 'AUTO',
    defaultPrompt:
      'Sos un periodista especializado en relaciones públicas y medios digitales. Tu rol es redactar publinotas y artículos de prensa sobre el negocio del cliente.',
    approvalRate: 94,
    avgTime: 30,
  },
]

/** Devuelve el default para un agentNumber dado o null si no existe. */
export function getAgentDefault(agentNumber: number): AgentDefault | undefined {
  return AGENT_DEFAULTS.find((d) => d.agentNumber === agentNumber)
}
