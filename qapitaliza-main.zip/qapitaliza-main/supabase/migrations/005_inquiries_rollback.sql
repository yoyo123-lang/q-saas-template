-- ============================================================
-- ROLLBACK 005 — Inquiries
-- ============================================================

DROP TABLE IF EXISTS public.inquiry_messages CASCADE;
DROP TABLE IF EXISTS public.inquiries        CASCADE;

DROP TYPE IF EXISTS inquiry_status CASCADE;
