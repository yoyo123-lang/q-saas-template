# Sesión 5: Facturación ARCA (backend)

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 5
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Servicio de facturación funcional que genera comprobantes reales (o en modo testing de ARCA).

## Pre-requisitos

Sesión 4 completada (clientes con datos fiscales).

## Etapas

### Etapa 1: Instalar y configurar Afip SDK
- Instalar `@afipsdk/afip.js` (open source, 100k+ descargas)
- Crear servicio `AfipService` con métodos:
  - crearFactura(tipo: A|B|C, datos)
  - crearNotaCredito(facturaOriginal, datos)
  - crearNotaDebito(facturaOriginal, datos)
  - consultarUltimoComprobante(puntoVenta, tipoComprobante)
- Configurar modo testing (homologación) por defecto

### Etapa 2: Gestión de certificados digitales
- Almacenamiento seguro de certificados por tenant
- Modelo para guardar cert + key (encriptados en DB o env vars)
- Servicio de renovación/validación de certificados
- NUNCA guardar certificados en texto plano

### Etapa 3: API routes de facturación
- POST /api/invoices — crear comprobante
- GET /api/invoices — listar comprobantes (con filtros)
- GET /api/invoices/:id — obtener comprobante por ID
- GET /api/invoices/last-number — consultar último número
- Todas scoped por tenant

### Etapa 4: Tests con modo testing ARCA
- Tests que crean facturas A, B, C en homologación
- Tests de notas de crédito/débito
- Tests de error handling (CUIT inválido, datos faltantes, servicio caído)
- Mock del servicio de ARCA para tests unitarios (no depender de red)

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
