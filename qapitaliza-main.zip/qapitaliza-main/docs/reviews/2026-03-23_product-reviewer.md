# Revisión: Product Reviewer
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de Product Reviewer

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 2 altos, 2 medios, 1 bajo

## Hallazgos

### [ALTO → CORREGIDO] Stats falsas en el hero de la landing
- Dónde: `src/app/page.tsx:54`
- Problema: "127 activos listados · $2.4M en transacciones · 340+ emprendedores" son datos inventados. En un marketplace financiero, mostrar números falsos daña la credibilidad y podría ser misleading.
- Fix aplicado: Reemplazados con tagline genérico "El marketplace de activos digitales para Latinoamérica".

### [ALTO → CORREGIDO] Counts de categorías hardcodeados eran inventados
- Dónde: `src/app/page.tsx`, `src/components/shared/category-pill.tsx`
- Problema: Mostrar "42 activos" en una categoría que tiene 0 genera desconfianza cuando el usuario llega al catálogo vacío.
- Fix aplicado: `count` es ahora prop opcional en `CategoryPill`. La landing no pasa counts.

### [MEDIO] Falta robots.txt — páginas internas podrían indexarse
- Dónde: ausente
- Fix aplicado: `src/app/robots.ts` creado.

### [MEDIO] El CTA "Consultar al vendedor" y "Guardar en favoritos" redirigen a `/login` sin mensaje explicativo
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Problema: El usuario llega a login sin saber por qué. Debería ver "Iniciá sesión para consultar al vendedor".
- Recomendación: Agregar `?message=Para+consultar+necesitás+una+cuenta` al redirect en Sesión 03.

### [BAJO] Descripción de activos sin formato Markdown
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Problema: La descripción se muestra con `whitespace-pre-line` pero sin soporte de Markdown. Los vendedores que escriban `**negrita**` ven los asteriscos literalmente.
- Recomendación: Integrar un renderer de Markdown básico en Sesión 03.

## Lo que está bien
- Propósito del marketplace claro en 5 segundos: H1 descriptivo, subtítulo explicativo ✓
- Flujo de usuario lógico: explorar → ver detalle → consultar → registrarse ✓
- CTAs visibles y bien ubicados en cada página ✓
- Textos en español argentino natural ✓
- `/como-funciona` explica el proceso de punta a punta con timelines claros ✓
- FAQ cubre las 6 dudas más frecuentes ✓
- Open Graph tags implementados en detalle del activo para sharing en redes ✓
- Sitemap dinámico con todos los listings publicados ✓
- Breadcrumb en detalle del activo — el usuario sabe dónde está ✓
- Estados vacíos diseñados (catálogo sin resultados, activos destacados vacíos) ✓
- URLs descriptivas: `/explorar/nombre-del-activo` ✓

## Recomendaciones generales
- Agregar mensaje de contexto en redirect a login.
- Evaluar soporte básico de Markdown en descripciones de activos.
- Cuando la DB tenga datos reales, mostrar contadores reales en el hero (GMV, total activos, usuarios).
