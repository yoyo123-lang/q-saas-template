import { getPrisma } from '@/lib/prisma'

// ─── Types ────────────────────────────────────────────────────

export interface InquiryParticipant {
  id: string
  fullName: string | null
  email: string
  role: 'BUYER' | 'SELLER' | 'ADMIN'
}

export interface InquiryMessageData {
  id: string
  inquiryId: string
  senderId: string
  content: string
  createdAt: Date
  sender: InquiryParticipant
}

export interface InquiryListingData {
  id: string
  title: string
  slug: string
  sellerId: string
  askingPrice: string
  monthlyRevenue: string | null
  screenshotUrls: string[]
  verificationStatus: string
  seller: InquiryParticipant
}

export interface InquiryWithMessages {
  id: string
  listingId: string
  buyerId: string
  status: 'OPEN' | 'REPLIED' | 'CLOSED' | 'CONVERTED'
  createdAt: Date
  updatedAt: Date
  listing: InquiryListingData
  buyer: InquiryParticipant
  messages: InquiryMessageData[]
}

export interface InquiryListItem {
  id: string
  listingId: string
  buyerId: string
  status: 'OPEN' | 'REPLIED' | 'CLOSED' | 'CONVERTED'
  createdAt: Date
  updatedAt: Date
  listing: {
    id: string
    title: string
    slug: string
    sellerId: string
  }
  buyer: InquiryParticipant
  lastMessage: {
    content: string
    createdAt: Date
    senderId: string
  } | null
}

export interface InquiryQueryParams {
  status?: 'OPEN' | 'REPLIED' | 'CLOSED' | 'CONVERTED'
  page?: number
}

export interface PaginatedInquiries {
  items: InquiryListItem[]
  total: number
  page: number
  pageSize: number
}

const INQUIRY_PAGE_SIZE = 20

/** Max messages returned in the getInquiry detail view (paginación futura). */
const MAX_MESSAGES_PER_INQUIRY = 200

// ─── Queries ──────────────────────────────────────────────────

/**
 * Returns all inquiries where the user is buyer OR seller of the listing.
 * Used for the /consultas list page.
 */
export async function getInquiries(
  userId: string,
  params: InquiryQueryParams = {}
): Promise<PaginatedInquiries> {
  const prisma = getPrisma()
  const page = Math.max(1, params.page ?? 1)
  const skip = (page - 1) * INQUIRY_PAGE_SIZE

  const where = {
    OR: [
      { buyerId: userId },
      { listing: { sellerId: userId } },
    ],
    ...(params.status ? { status: params.status } : {}),
  }

  const [total, rawItems] = await Promise.all([
    prisma.inquiry.count({ where }),
    prisma.inquiry.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      skip,
      take: INQUIRY_PAGE_SIZE,
      include: {
        listing: {
          select: { id: true, title: true, slug: true, sellerId: true },
        },
        buyer: {
          select: { id: true, fullName: true, email: true, role: true },
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1,
          select: { content: true, createdAt: true, senderId: true },
        },
      },
    }),
  ])

  const items: InquiryListItem[] = rawItems.map((inq) => ({
    id: inq.id,
    listingId: inq.listingId,
    buyerId: inq.buyerId,
    status: inq.status as InquiryListItem['status'],
    createdAt: inq.createdAt,
    updatedAt: inq.updatedAt,
    listing: inq.listing,
    buyer: inq.buyer as InquiryParticipant,
    lastMessage: inq.messages[0] ?? null,
  }))

  return { items, total, page, pageSize: INQUIRY_PAGE_SIZE }
}

/**
 * Returns a single inquiry with messages (up to MAX_MESSAGES_PER_INQUIRY).
 * Verifies that userId is either the buyer or the seller of the listing.
 * Returns null if not found or if the user is not a participant.
 */
export async function getInquiry(
  id: string,
  userId: string
): Promise<InquiryWithMessages | null> {
  const prisma = getPrisma()

  const inq = await prisma.inquiry.findUnique({
    where: { id },
    include: {
      listing: {
        select: {
          id: true,
          title: true,
          slug: true,
          sellerId: true,
          askingPrice: true,
          monthlyRevenue: true,
          screenshotUrls: true,
          verificationStatus: true,
          seller: {
            select: { id: true, fullName: true, email: true, role: true },
          },
        },
      },
      buyer: {
        select: { id: true, fullName: true, email: true, role: true },
      },
      messages: {
        orderBy: { createdAt: 'asc' },
        take: MAX_MESSAGES_PER_INQUIRY,
        include: {
          sender: {
            select: { id: true, fullName: true, email: true, role: true },
          },
        },
      },
    },
  })

  if (!inq) return null

  // Participant check: only buyer or seller can view
  const isBuyer = inq.buyerId === userId
  const isSeller = inq.listing.sellerId === userId
  if (!isBuyer && !isSeller) return null

  return {
    id: inq.id,
    listingId: inq.listingId,
    buyerId: inq.buyerId,
    status: inq.status as InquiryWithMessages['status'],
    createdAt: inq.createdAt,
    updatedAt: inq.updatedAt,
    listing: {
      ...inq.listing,
      askingPrice: inq.listing.askingPrice.toString(),
      monthlyRevenue: inq.listing.monthlyRevenue?.toString() ?? null,
      seller: inq.listing.seller as InquiryParticipant,
    },
    buyer: inq.buyer as InquiryParticipant,
    messages: inq.messages.map((msg) => ({
      id: msg.id,
      inquiryId: msg.inquiryId,
      senderId: msg.senderId,
      content: msg.content,
      createdAt: msg.createdAt,
      sender: msg.sender as InquiryParticipant,
    })),
  }
}

/**
 * Returns messages for an inquiry.
 * Requires the caller to have already verified participant access.
 * Exported for admin/internal use only — do NOT call without an access check.
 *
 * @internal Use getInquiry instead for user-facing access.
 */
export async function getInquiryMessages(
  inquiryId: string,
  verifiedUserId: string
): Promise<InquiryMessageData[]> {
  const prisma = getPrisma()

  // Re-verify participant access before returning messages
  const inquiry = await prisma.inquiry.findUnique({
    where: { id: inquiryId },
    select: {
      buyerId: true,
      listing: { select: { sellerId: true } },
    },
  })

  if (!inquiry) return []

  const isBuyer = inquiry.buyerId === verifiedUserId
  const isSeller = inquiry.listing.sellerId === verifiedUserId
  if (!isBuyer && !isSeller) return []

  const messages = await prisma.inquiryMessage.findMany({
    where: { inquiryId },
    orderBy: { createdAt: 'asc' },
    take: MAX_MESSAGES_PER_INQUIRY,
    include: {
      sender: {
        select: { id: true, fullName: true, email: true, role: true },
      },
    },
  })

  return messages.map((msg) => ({
    id: msg.id,
    inquiryId: msg.inquiryId,
    senderId: msg.senderId,
    content: msg.content,
    createdAt: msg.createdAt,
    sender: msg.sender as InquiryParticipant,
  }))
}
