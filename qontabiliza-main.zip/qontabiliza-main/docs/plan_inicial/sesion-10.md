# Sesión 10: Reportes, dashboard y suscripciones

## Objetivo
Dashboard con métricas clave (ventas, stock, facturas). Reportes de ventas (diario/mensual/producto), libro IVA ventas, cuentas a cobrar. Sistema de planes de suscripción con enforcement de límites. Al terminar, el administrador tiene visibilidad del negocio y el SaaS puede limitar uso por plan.

## Pre-requisitos
- Sesión 09 completada (POS funcional, ventas registrándose)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `src/lib/services/sale-service.ts` — método `getSaleSummary`
3. Leer `src/lib/services/stock-service.ts` — método `getLowStockProducts`
4. Leer `prisma/schema.prisma` — modelo Plan, Invoice, Sale
5. Leer `src/app/dashboard/page.tsx` — dashboard actual (probablemente vacío o con ejemplo)

---

## Etapa 1: Dashboard con widgets

### Tarea 1.1: API de métricas del dashboard
**Archivo nuevo**: `src/app/api/v1/dashboard/route.ts`

Endpoint GET que retorna todas las métricas del dashboard en una sola llamada:

```typescript
// Response:
// {
//   salesToday: { total: number, count: number },
//   salesMonth: { total: number, count: number },
//   lowStockCount: number,
//   pendingInvoices: { total: number, count: number }, // Facturas sin cobrar
//   topProducts: { name: string, quantity: number, revenue: number }[], // Top 5 del mes
//   salesByDay: { date: string, total: number }[], // Últimos 30 días
//   salesByPaymentMethod: { method: string, total: number }[], // Desglose del mes
// }
```

Todas las queries scoped por tenant. Usar SQL raw para las agregaciones complejas si Prisma es lento.

### Tarea 1.2: Página de dashboard
**Archivo a modificar**: `src/app/dashboard/page.tsx`

Reemplazar contenido actual con dashboard de Qontabiliza:

**Fila 1 — KPIs** (4 cards):
- Ventas de hoy ($X.XXX,XX — formato argentino)
- Ventas del mes ($XX.XXX,XX)
- Facturas pendientes de cobro ($X.XXX,XX — count)
- Productos con stock bajo (count — con color rojo si > 0)

**Fila 2 — Gráfico de ventas**:
- Gráfico de barras/línea: ventas por día de los últimos 30 días
- Usar una lib de charts ligera (recharts o chart.js)
- Eje X: fechas (formato dd/mm), Eje Y: montos en ARS

**Fila 3 — Dos columnas**:
- **Izquierda**: Top 5 productos más vendidos del mes (tabla simple)
- **Derecha**: Desglose por medio de pago (donut chart o lista)

**Fila 4 — Accesos rápidos**:
- "Nueva venta" → /dashboard/pos
- "Nueva factura" → /dashboard/invoices/new
- "Ver stock bajo" → /dashboard/stock?filter=low

### Tarea 1.3: Instalar dependencia de charts
**Comando**: `npm install recharts`

Usar recharts — es React-native, ligero, y tiene buena integración con Tailwind.

**Commit**: `feat(dashboard): add dashboard with KPIs, sales chart and quick actions`

---

## Etapa 2: Reportes de ventas

### Tarea 2.1: API de reportes
**Archivo nuevo**: `src/app/api/v1/reports/sales/route.ts`

Endpoint GET con query params: dateFrom, dateTo, groupBy (day|week|month), productId?, contactId?

Response:
```typescript
// {
//   summary: { total: number, count: number, averageTicket: number },
//   items: { period: string, total: number, count: number }[],
//   byProduct: { productId, name, quantity, revenue }[],
//   byPaymentMethod: { method, total, count }[],
// }
```

**Archivo nuevo**: `src/app/api/v1/reports/iva-book/route.ts`

Endpoint GET con query params: month (YYYY-MM)

Libro IVA Ventas:
```typescript
// {
//   month: string,
//   entries: {
//     date: string,
//     voucherType: string,
//     voucherNumber: string,
//     clientName: string,
//     clientCuit: string,
//     netoGravado: number,
//     iva21: number,
//     iva105: number,
//     iva27: number,
//     otherTaxes: number,
//     total: number,
//   }[],
//   totals: { netoGravado, iva21, iva105, iva27, otherTaxes, total }
// }
```

**Archivo nuevo**: `src/app/api/v1/reports/accounts-receivable/route.ts`

Cuentas a cobrar:
```typescript
// {
//   items: {
//     contactId, contactName, contactCuit,
//     invoiceId, invoiceNumber, invoiceDate, invoiceTotal,
//     paidAmount, pendingAmount, daysPending,
//   }[],
//   totalPending: number,
// }
```

### Tarea 2.2: Página de reportes de ventas
**Archivo nuevo**: `src/app/dashboard/reports/page.tsx`

Página con tabs:
- **Ventas**: selector de período + gráfico + tabla resumen
- **Libro IVA**: selector de mes + tabla con formato fiscal
- **Cuentas a cobrar**: tabla con saldo pendiente por cliente/factura

### Tarea 2.3: Reporte de ventas
**Archivo nuevo**: `src/app/dashboard/reports/sales/page.tsx`

- Selector de rango de fechas (presets: Hoy, Esta semana, Este mes, Mes anterior, Custom)
- Agrupación: por día, semana, mes
- Gráfico de barras con ventas por período
- Tabla resumen debajo
- Tabla de productos más vendidos
- Desglose por medio de pago
- Botón "Exportar CSV" (genera descarga)

### Tarea 2.4: Libro IVA Ventas
**Archivo nuevo**: `src/app/dashboard/reports/iva-book/page.tsx`

- Selector de mes (YYYY-MM)
- Tabla con formato del libro IVA estándar argentino:
  - Fecha | Tipo | Número | Cliente | CUIT | Neto Grav. | IVA 21% | IVA 10,5% | IVA 27% | Total
- Fila de totales al final
- Todos los montos en formato argentino
- Botón "Exportar CSV" (para importar en sistemas contables)

**Commit**: `feat(reports): add sales reports, IVA book and accounts receivable`

---

## Etapa 3: Cuentas a cobrar

### Tarea 3.1: Página de cuentas a cobrar
**Archivo nuevo**: `src/app/dashboard/reports/accounts-receivable/page.tsx`

- Tabla con columnas: Cliente, CUIT, Factura, Fecha, Total, Pagado, Pendiente, Días
- Filtros: cliente, rango de fechas, solo pendientes
- Color coding: >30 días = amarillo, >60 días = rojo
- Resumen arriba: total pendiente de cobro
- Click en fila → ir al detalle de la factura

### Tarea 3.2: Badge de facturas pendientes en navegación
**Archivo a modificar**: `src/components/layout/nav-config.ts` o sidebar

Agregar badge con count de facturas pendientes de cobro en el item de navegación "Facturación" o "Reportes".

**Commit**: `feat(reports): add accounts receivable page with aging indicators`

---

## Etapa 4: Suscripciones y límites

### Tarea 4.1: PlanService
**Archivo nuevo**: `src/lib/services/plan-service.ts`

```typescript
// Servicio que gestiona los planes y el enforcement de límites.
//
// Métodos:
//
// checkLimit(organizationId, resource: 'users' | 'invoices' | 'products'): Promise<LimitCheck>
//   - Consulta el plan de la org
//   - Cuenta el uso actual del recurso en el período (mes actual para invoices)
//   - Retorna: { allowed: boolean, current: number, limit: number, planName: string }
//
// enforceLimit(organizationId, resource): Promise<void>
//   - Llama checkLimit, si !allowed lanza error 402 con mensaje descriptivo:
//     "Has alcanzado el límite de X comprobantes del plan [planName]. Actualizá tu plan para continuar."
//
// getUsageSummary(organizationId): Promise<UsageSummary>
//   - Retorna uso actual vs límites para todos los recursos
//   - Se usa en la página de billing/plan
//
// getAllPlans(): Promise<Plan[]>
//   - Lista planes activos para mostrar en página de upgrade
```

### Tarea 4.2: Integrar enforcement en APIs críticas
**Archivos a modificar**:
- `src/app/api/v1/invoices/route.ts` (POST) — enforceLimit('invoices') antes de crear
- `src/app/api/v1/products/route.ts` (POST) — enforceLimit('products') antes de crear
- `src/app/api/v1/organizations/[id]/members/route.ts` (POST) — enforceLimit('users') antes de invitar

### Tarea 4.3: Página de plan y billing
**Archivo nuevo**: `src/app/dashboard/settings/billing/page.tsx`

Página en Settings → Plan y facturación:
- Plan actual con nombre y precio
- Barras de progreso de uso: comprobantes (X/1000 este mes), productos (X/ilimitado), usuarios (X/3)
- Tabla comparativa de planes (Micro, Starter, Pro, Max)
- Botón "Cambiar plan" (en MVP: lleva a contacto/WhatsApp — el upgrade real se implementa con Qobra en Fase 2)
- Si está en plan Micro y se acerca al límite → banner amarillo de advertencia

### Tarea 4.4: Seed de planes
**Archivo a modificar**: `prisma/seed.ts`

Asegurar que los planes estén seeded con los valores correctos:
```
Micro:   $25.000/mes,  1 usuario,  200 comprobantes,  500 productos
Starter: $55.000/mes,  3 usuarios, 1000 comprobantes,  0 (ilimitado) productos
Pro:     $110.000/mes, 10 usuarios, 5000 comprobantes,  0 productos
Max:     $190.000/mes, 30 usuarios, 0 (ilimitado) comprobantes, 0 productos
```

**Commit**: `feat(billing): add plan enforcement, usage tracking and billing page`

---

## Checklist de cierre de sesión

- [ ] Dashboard con KPIs, gráfico de ventas, top productos, accesos rápidos
- [ ] Reporte de ventas con gráficos y filtros
- [ ] Libro IVA Ventas con formato fiscal argentino
- [ ] Cuentas a cobrar con indicadores de aging
- [ ] Exportar a CSV funciona
- [ ] Sistema de planes con enforcement de límites
- [ ] PlanService integrado en APIs de facturas, productos, miembros
- [ ] Página de billing con uso actual y comparativa de planes
- [ ] Charts con recharts
- [ ] Todos los montos en formato argentino
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
