import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { prisma } from '@qautiva/db'
import { MediumStatus, ProductType, LinkType, MediumPlatform } from '@qautiva/db'
import { PLATFORM_LABEL, PLATFORM_COLOR } from '../lib/constants'
import { formatARS, formatNumber } from '@/lib/format'

// ── Labels ────────────────────────────────────────────────────────────────────

const PRODUCT_TYPE_LABEL: Record<ProductType, string> = {
  ARTICLE: 'Artículo con enlace',
  LINK_INSERTION: 'Inserción de enlace',
  POST: 'Post en feed',
  STORY: 'Historia',
  REEL: 'Reel / Short / TikTok',
  MENTION: 'Mención de marca',
  THREAD: 'Hilo',
  VIDEO: 'Video dedicado',
}

// ── Data fetching ─────────────────────────────────────────────────────────────

async function getMedium(id: string) {
  return prisma.medium.findFirst({
    where: { id, status: MediumStatus.ACTIVE, deletedAt: null },
    select: {
      id: true,
      name: true,
      platform: true,
      handle: true,
      url: true,
      description: true,
      country: true,
      language: true,
      verified: true,
      followersCount: true,
      monthlyVisits: true,
      domainAuthority: true,
      linkType: true,
      publishesOnHome: true,
      maxLinks: true,
      completedOrders: true,
      avgRating: true,
      responseRate: true,
      categories: {
        select: {
          isPrimary: true,
          category: { select: { id: true, name: true, slug: true } },
        },
        orderBy: { isPrimary: 'desc' },
      },
      products: {
        where: { active: true },
        select: {
          id: true,
          type: true,
          name: true,
          description: true,
          price: true,
          deliveryDays: true,
          includesWriting: true,
          conditions: true,
        },
        orderBy: { price: 'asc' },
      },
      user: { select: { displayName: true, avatarUrl: true } },
      orders: {
        where: { status: 'COMPLETED', rating: { not: null } },
        select: {
          id: true,
          rating: true,
          ratingComment: true,
          completedAt: true,
          advertiser: { select: { displayName: true } },
        },
        orderBy: { completedAt: 'desc' },
        take: 10,
      },
    },
  })
}

// ── Metadata dinámica ─────────────────────────────────────────────────────────

export async function generateMetadata({
  params,
}: {
  params: { mediumId: string }
}): Promise<Metadata> {
  const medium = await getMedium(params.mediumId)
  if (!medium) return { title: 'Medio no encontrado — Qautiva' }
  const description = medium.description ?? `${PLATFORM_LABEL[medium.platform]} disponible en el marketplace de Qautiva.`
  return {
    title: `${medium.name} — Marketplace Qautiva`,
    description,
    openGraph: {
      title: `${medium.name} — Marketplace Qautiva`,
      description,
    },
  }
}

// ── Componentes de apoyo ──────────────────────────────────────────────────────

function StarRating({ rating, exact }: { rating: number; exact?: number }) {
  const label = exact !== undefined
    ? `${exact.toFixed(1).replace('.', ',')} de 5 estrellas`
    : `${rating} de 5 estrellas`
  return (
    <span aria-label={label} className="text-yellow-400 text-sm">
      {'★'.repeat(rating)}{'☆'.repeat(5 - rating)}
    </span>
  )
}

function MetricItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4 text-center">
      <p className="text-white text-xl font-bold">{value}</p>
      <p className="text-[#64748B] text-xs mt-1">{label}</p>
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default async function MediumDetailPage({
  params,
}: {
  params: { mediumId: string }
}) {
  const medium = await getMedium(params.mediumId)
  if (!medium) notFound()

  const platformLabel = PLATFORM_LABEL[medium.platform]
  const platformColor = PLATFORM_COLOR[medium.platform]
  const isWebsite = medium.platform === MediumPlatform.WEBSITE

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Breadcrumb */}
      <nav aria-label="Navegación" className="text-sm text-[#64748B] mb-6 flex items-center gap-2">
        <Link href="/marketplace" className="hover:text-[#94A3B8] transition-colors">
          Marketplace
        </Link>
        <span>/</span>
        <span className="text-[#94A3B8]">{medium.name}</span>
      </nav>

      {/* Header del medio */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-start gap-4">
          <div className="flex-1 min-w-0">
            {/* Plataforma + verificado */}
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${platformColor}`}>
                {platformLabel}
              </span>
              {medium.country && (
                <span className="text-xs text-[#64748B]">{medium.country.toUpperCase()}</span>
              )}
              {medium.verified && (
                <span className="text-xs bg-[#0F2E2A] text-[#34D399] px-2 py-0.5 rounded-full">
                  ✓ Verificado
                </span>
              )}
            </div>

            <h1 className="text-2xl font-bold text-white mb-1">{medium.name}</h1>

            {medium.handle && (
              <p className="text-[#64748B] text-sm mb-1">{medium.handle}</p>
            )}
            {medium.user.displayName && (
              <p className="text-[#64748B] text-sm">por {medium.user.displayName}</p>
            )}

            {medium.description && (
              <p className="text-[#94A3B8] text-sm mt-3 leading-relaxed">{medium.description}</p>
            )}

            {/* Categorías */}
            {medium.categories.length > 0 && (
              <div className="flex gap-1 flex-wrap mt-3">
                {medium.categories.map(({ category, isPrimary }: { category: { id: string; name: string; slug: string }; isPrimary: boolean }) => (
                  <span
                    key={category.id}
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      isPrimary
                        ? 'bg-[#1E3A5F] text-[#60A5FA]'
                        : 'bg-[#1E293B] text-[#94A3B8]'
                    }`}
                  >
                    {category.name}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Reputación */}
          <div className="shrink-0 text-right sm:text-right">
            {medium.avgRating !== null && (
              <div className="mb-1">
                <StarRating rating={Math.round(medium.avgRating)} exact={medium.avgRating} />
                <p className="text-[#64748B] text-xs">
                  {medium.avgRating.toFixed(1)} · {medium.completedOrders} {medium.completedOrders === 1 ? 'entrega' : 'entregas'}
                </p>
              </div>
            )}
            {medium.responseRate !== null && (
              <p className="text-[#64748B] text-xs">
                {Math.round(medium.responseRate * 100)}% tasa de respuesta
              </p>
            )}
            {medium.url && (
              <a
                href={medium.url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-block text-xs text-[#60A5FA] hover:underline"
              >
                Ver sitio ↗
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Métricas */}
      {(medium.followersCount !== null || medium.monthlyVisits !== null || medium.domainAuthority !== null) && (
        <section aria-label="Métricas del medio" className="mb-6">
          <h2 className="text-white font-semibold mb-3">Métricas</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {medium.followersCount !== null && (
              <MetricItem
                label={isWebsite ? 'Visitas/mes' : 'Seguidores'}
                value={formatNumber(medium.followersCount)}
              />
            )}
            {medium.monthlyVisits !== null && (
              <MetricItem label="Visitas/mes" value={formatNumber(medium.monthlyVisits)} />
            )}
            {medium.domainAuthority !== null && (
              <MetricItem label="Domain Authority" value={`DA ${medium.domainAuthority}`} />
            )}
            {isWebsite && medium.linkType && (
              <MetricItem
                label="Tipo de enlace"
                value={medium.linkType === LinkType.DOFOLLOW ? 'Dofollow' : 'Nofollow'}
              />
            )}
            {isWebsite && medium.publishesOnHome !== null && (
              <MetricItem
                label="Portada"
                value={medium.publishesOnHome ? 'Sí' : 'No'}
              />
            )}
            {isWebsite && medium.maxLinks !== null && (
              <MetricItem label="Máx. enlaces" value={String(medium.maxLinks)} />
            )}
          </div>
        </section>
      )}

      {/* Productos */}
      <section aria-label="Productos disponibles" className="mb-6">
        <h2 className="text-white font-semibold mb-3">Productos disponibles</h2>
        {medium.products.length === 0 ? (
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-6 text-center">
            <p className="text-[#94A3B8]">Este medio no tiene productos activos por el momento.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {medium.products.map((product: { id: string; type: ProductType; name: string; description: string | null; price: { toNumber: () => number }; deliveryDays: number; includesWriting: boolean; conditions: unknown }) => (
              <div
                key={product.id}
                className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col sm:flex-row sm:items-center gap-4"
              >
                {/* Info del producto */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-xs bg-[#1E293B] text-[#94A3B8] px-2 py-0.5 rounded-full">
                      {PRODUCT_TYPE_LABEL[product.type] ?? product.type}
                    </span>
                    {product.includesWriting && (
                      <span className="text-xs bg-[#0F2942] text-[#93C5FD] px-2 py-0.5 rounded-full">
                        Incluye redacción
                      </span>
                    )}
                  </div>
                  <h3 className="text-white font-medium text-sm">{product.name}</h3>
                  {product.description && (
                    <p className="text-[#94A3B8] text-xs mt-1 leading-relaxed">{product.description}</p>
                  )}
                  <p className="text-[#64748B] text-xs mt-2">
                    Entrega en {product.deliveryDays} {product.deliveryDays === 1 ? 'día' : 'días'}
                  </p>
                </div>

                {/* Precio + CTA */}
                <div className="shrink-0 flex flex-col items-end gap-2">
                  <p className="text-white font-bold text-lg">{formatARS(product.price.toNumber())}</p>
                  <Link
                    href={`/marketplace/${medium.id}/comprar/${product.id}`}
                    aria-label={`Comprar ${product.name} — ${formatARS(product.price.toNumber())}`}
                    className="bg-[#1E3A5F] hover:bg-[#1E4D8C] text-[#60A5FA] text-sm font-medium px-4 py-2 rounded-lg transition-colors whitespace-nowrap"
                  >
                    Comprar
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Reseñas */}
      {medium.orders.length > 0 && (
        <section aria-label="Reseñas de anunciantes">
          <h2 className="text-white font-semibold mb-3">Reseñas</h2>
          <div className="flex flex-col gap-3">
            {medium.orders.map((order: { id: string; rating: number | null; ratingComment: string | null; completedAt: Date | null; advertiser: { displayName: string | null } }) => (
              <div key={order.id} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-4">
                <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <StarRating rating={order.rating!} />
                    {order.advertiser.displayName && (
                      <span className="text-[#64748B] text-xs">{order.advertiser.displayName}</span>
                    )}
                  </div>
                  {order.completedAt && (
                    <span className="text-[#475569] text-xs">
                      {new Date(order.completedAt).toLocaleDateString('es-AR', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  )}
                </div>
                {order.ratingComment && (
                  <p className="text-[#94A3B8] text-sm leading-relaxed">{order.ratingComment}</p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
