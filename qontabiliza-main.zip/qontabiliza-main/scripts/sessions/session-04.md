# Sesión 4: Productos avanzado + Clientes y proveedores

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 4
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Listas de precios funcionales. CRUD completo de clientes/proveedores con datos fiscales.

## Pre-requisitos

Sesión 3 completada (productos y catálogo).

## Etapas

### Etapa 1: Listas de precios
- API routes para PriceList CRUD
- Asignar precios por producto/variante a cada lista
- UI: página de gestión de listas de precios
- Resolución de precio: producto → lista del cliente → lista default → precio base

### Etapa 2: Códigos de barras
- Campo de código de barras en producto y variante
- Búsqueda por código de barras (exacta)
- Validación de formato EAN-13/EAN-8/UPC
- UI: campo en formulario de producto + búsqueda rápida

### Etapa 3: Validaciones y API de Contact
- Schema Zod para Contact (cliente/proveedor)
- Validación de CUIT argentino (algoritmo de verificación)
- Condiciones de IVA: Responsable Inscripto, Monotributista, Exento, Consumidor Final
- API routes CRUD scoped por tenant

### Etapa 4: UI de clientes/proveedores
- Listado con filtros (tipo, condición IVA, búsqueda)
- Formulario con: razón social, CUIT, condición IVA, domicilio fiscal, email, teléfono
- Separación visual entre clientes y proveedores (tabs o filtro)

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
