'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Pencil, ExternalLink, PauseCircle, PlayCircle, Trash2, CheckCircle } from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { DropdownMenu } from '@/components/ui/dropdown-menu'
import { Modal } from '@/components/ui/modal'
import { Button } from '@/components/ui/button'
import { deleteListing, pauseListing, resumeListing, markAsSold } from '@/lib/actions/listings'
import { cn } from '@/lib/utils/cn'
import { statusBadgeVariant, statusLabels, typeLabels } from '@/lib/constants/listing-labels'
import type { SellerListingItem } from '@/lib/data/listings'

interface ListingsTableProps {
  listings: SellerListingItem[]
  onMutate?: () => void
}

export function ListingsTable({ listings, onMutate }: ListingsTableProps) {
  const router = useRouter()
  const notifyMutate = onMutate ?? (() => router.refresh())
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [deletingTitle, setDeletingTitle] = useState<string>('')
  const [loadingId, setLoadingId] = useState<string | null>(null)

  const handleDelete = async () => {
    if (!deletingId) return
    setLoadingId(deletingId)
    const result = await deleteListing(deletingId)
    setLoadingId(null)
    setDeletingId(null)
    if (result.success) {
      toast.success('Listado eliminado')
      notifyMutate()
    } else {
      toast.error(result.error ?? 'Error al eliminar')
    }
  }

  const handlePause = async (id: string, currentStatus: string) => {
    setLoadingId(id)
    const result = currentStatus === 'PAUSED'
      ? await resumeListing(id)
      : await pauseListing(id)
    setLoadingId(null)
    if (result.success) {
      toast.success(currentStatus === 'PAUSED' ? 'Listado reactivado' : 'Listado pausado')
      notifyMutate()
    } else {
      toast.error(result.error ?? 'Error')
    }
  }

  const handleMarkSold = async (id: string) => {
    setLoadingId(id)
    const result = await markAsSold(id)
    setLoadingId(null)
    if (result.success) {
      toast.success('Marcado como vendido')
      notifyMutate()
    } else {
      toast.error(result.error ?? 'Error')
    }
  }

  if (listings.length === 0) {
    return (
      <div className="text-center py-12 text-slate-500 text-sm">
        No hay listados para mostrar.
      </div>
    )
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-800">
              {['Activo', 'Tipo', 'Precio', 'Estado', 'Vistas', 'Consultas', ''].map((h, i) => (
                <th
                  key={i}
                  className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500 whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {listings.map((listing) => {
              const thumbnail = listing.screenshotUrls?.[0]
              const isPaused = listing.status === 'PAUSED'
              const inquiryCount = listing._count?.inquiries ?? 0
              const isLoading = loadingId === listing.id

              const menuItems = [
                {
                  label: 'Editar',
                  icon: <Pencil className="size-4" />,
                  href: `/mis-activos/${listing.id}/editar`,
                },
                {
                  label: 'Ver página pública',
                  icon: <ExternalLink className="size-4" />,
                  href: `/explorar/${listing.slug}`,
                },
                {
                  label: isPaused ? 'Reanudar' : 'Pausar',
                  icon: isPaused
                    ? <PlayCircle className="size-4" />
                    : <PauseCircle className="size-4" />,
                  onClick: () => handlePause(listing.id, listing.status),
                },
                {
                  label: 'Marcar como vendido',
                  icon: <CheckCircle className="size-4" />,
                  onClick: () => handleMarkSold(listing.id),
                },
                {
                  label: 'Eliminar',
                  icon: <Trash2 className="size-4" />,
                  onClick: () => { setDeletingId(listing.id); setDeletingTitle(listing.title) },
                  danger: true,
                },
              ]

              return (
                <tr
                  key={listing.id}
                  className={cn(
                    'border-b border-slate-800 last:border-0 hover:bg-slate-800/40 transition-colors',
                    isLoading && 'opacity-50 pointer-events-none'
                  )}
                >
                  {/* Activo */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-lg overflow-hidden bg-slate-800 flex-shrink-0">
                        {thumbnail ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={thumbnail} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900" />
                        )}
                      </div>
                      <Link
                        href={`/mis-activos/${listing.id}/editar`}
                        className="text-sm font-medium text-slate-200 hover:text-amber-500 transition-colors line-clamp-1 max-w-[200px]"
                      >
                        {listing.title}
                      </Link>
                    </div>
                  </td>

                  {/* Tipo */}
                  <td className="px-4 py-3">
                    <Badge variant="info">{typeLabels[listing.type] ?? listing.type}</Badge>
                  </td>

                  {/* Precio */}
                  <td className="px-4 py-3 text-sm text-slate-300 whitespace-nowrap">
                    ${Number(listing.askingPrice).toLocaleString()} {listing.currency}
                  </td>

                  {/* Estado */}
                  <td className="px-4 py-3">
                    <Badge variant={statusBadgeVariant[listing.status] ?? 'muted'}>
                      {statusLabels[listing.status] ?? listing.status}
                    </Badge>
                  </td>

                  {/* Vistas */}
                  <td className="px-4 py-3 text-sm text-slate-400">{listing.viewCount}</td>

                  {/* Consultas */}
                  <td className="px-4 py-3 text-sm text-slate-400">{inquiryCount}</td>

                  {/* Acciones */}
                  <td className="px-4 py-3">
                    {isLoading ? (
                      <div className="size-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <DropdownMenu items={menuItems} align="right" />
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Confirm delete modal */}
      <Modal
        open={!!deletingId}
        onClose={() => setDeletingId(null)}
        title="Eliminar listado"
        size="sm"
      >
        <p className="text-sm text-slate-400 mb-6">
          ¿Estás seguro de que querés eliminar{' '}
          <span className="font-medium text-slate-200">{deletingTitle}</span>?
          Esta acción no se puede deshacer.
        </p>
        <div className="flex gap-3 justify-end">
          <Button variant="ghost" onClick={() => setDeletingId(null)}>
            Cancelar
          </Button>
          <Button
            variant="outline-danger"
            onClick={handleDelete}
            loading={!!loadingId}
          >
            Eliminar
          </Button>
        </div>
      </Modal>
    </>
  )
}
