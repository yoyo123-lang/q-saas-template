import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

/**
 * GET /api/stitch/queue/config
 * Devuelve la configuración global de la cola Stitch (estado de pausa).
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireAdminSession()

    const config = await prisma.stitchQueueConfig.findUnique({ where: { id: 1 } })
    return NextResponse.json({ paused: config?.paused ?? false })
  } catch (err) {
    if (err instanceof Error && err.message === 'Unauthorized') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }
    return NextResponse.json({ error: 'Error al obtener configuración' }, { status: 500 })
  }
}

/**
 * PATCH /api/stitch/queue/config
 * Actualiza el estado de pausa de la cola.
 * Body: { paused: boolean }
 */
export async function PATCH(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()

    const body = (await req.json()) as unknown
    if (typeof body !== 'object' || body === null || typeof (body as Record<string, unknown>)['paused'] !== 'boolean') {
      return NextResponse.json({ error: 'El campo paused debe ser boolean' }, { status: 400 })
    }

    const { paused } = body as { paused: boolean }

    const config = await prisma.stitchQueueConfig.upsert({
      where: { id: 1 },
      create: { id: 1, paused },
      update: { paused },
    })

    console.info(`[stitch:queue:config] Cola ${config.paused ? 'PAUSADA' : 'REANUDADA'}`)
    return NextResponse.json({ paused: config.paused })
  } catch (err) {
    if (err instanceof Error && err.message === 'Unauthorized') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }
    return NextResponse.json({ error: 'Error al actualizar configuración' }, { status: 500 })
  }
}
