import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { MediumStatus, ProductType, Prisma } from '@qautiva/db'
import { getProfileOrUnauthorized, serializeDecimalPrice } from '@/lib/api/marketplace-helpers'

// ── GET /api/marketplace/products?mediumId=X ──────────────────────────────────
// Público: retorna productos activos de un medio con paginación.
// Si el usuario autenticado es el dueño, incluye también los productos inactivos.

export async function GET(request: NextRequest): Promise<NextResponse> {
  const sp = request.nextUrl.searchParams
  const mediumId = sp.get('mediumId')
  const page = Math.max(1, parseInt(sp.get('page') ?? '1', 10))
  const take = Math.min(50, Math.max(1, parseInt(sp.get('take') ?? '20', 10)))

  if (!mediumId) {
    return NextResponse.json({ error: 'El parámetro mediumId es requerido' }, { status: 400 })
  }

  const medium = await prisma.medium.findUnique({
    where: { id: mediumId },
    select: { id: true, userId: true, deletedAt: true },
  })
  if (!medium || medium.deletedAt !== null) {
    return NextResponse.json({ error: 'Medio no encontrado' }, { status: 404 })
  }

  // Detectar ownership — opcional, no bloquea si no autenticado
  let isOwner = false
  try {
    const cookieStore = cookies()
    const supabase = createServerClient(cookieStore)
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      const profile = await prisma.userProfile.findUnique({
        where: { authUserId: user.id },
        select: { id: true },
      })
      if (profile?.id === medium.userId) isOwner = true
    }
  } catch {
    // Sin auth — continúa como público
  }

  const where = {
    mediumId,
    ...(isOwner ? {} : { active: true }),
  }

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where,
      select: {
        id: true,
        mediumId: true,
        type: true,
        name: true,
        description: true,
        price: true,
        deliveryDays: true,
        includesWriting: true,
        active: true,
        conditions: true,
        createdAt: true,
        updatedAt: true,
      },
      orderBy: [{ active: 'desc' }, { price: 'asc' }],
      skip: (page - 1) * take,
      take,
    }),
    prisma.product.count({ where }),
  ])

  return NextResponse.json({
    products: products.map(serializeDecimalPrice),
    pagination: { page, take, total, pages: Math.ceil(total / take) },
  })
}

// ── Validación de precio ───────────────────────────────────────────────────────
// Decimal(12,2): máximo 2 decimales, rango 0.01 – 99_999_999.99

function validatePrice(price: unknown): string | null {
  if (typeof price !== 'number' || price <= 0) return 'El precio debe ser un número mayor a 0'
  if (price > 99_999_999) return 'El precio no puede superar 99.999.999'
  // Verificar que no tenga más de 2 decimales (truncado silencioso en Decimal(12,2))
  if (Math.round(price * 100) !== price * 100) return 'El precio no puede tener más de 2 decimales'
  return null
}

// ── POST /api/marketplace/products ────────────────────────────────────────────
// Crea un producto para un medio del editor autenticado.
// El medio debe pertenecer al editor y no estar REJECTED o SUSPENDED.

type CreateProductBody = {
  mediumId: string
  type: string
  name: string
  description?: string
  price: number
  deliveryDays: number
  includesWriting?: boolean
  conditions?: Record<string, unknown>
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: CreateProductBody
  try {
    body = (await request.json()) as CreateProductBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { mediumId, type, name, description, price, deliveryDays, includesWriting, conditions } = body

  if (!mediumId) {
    return NextResponse.json({ error: 'El campo mediumId es requerido' }, { status: 400 })
  }
  if (!type || !Object.values(ProductType).includes(type as ProductType)) {
    return NextResponse.json({ error: 'Tipo de producto inválido o requerido' }, { status: 400 })
  }
  if (!name || name.trim().length < 3 || name.trim().length > 100) {
    return NextResponse.json({ error: 'El nombre debe tener entre 3 y 100 caracteres' }, { status: 400 })
  }
  if (description !== undefined && description.length > 1000) {
    return NextResponse.json({ error: 'La descripción no puede superar los 1000 caracteres' }, { status: 400 })
  }
  const priceError = validatePrice(price)
  if (priceError) return NextResponse.json({ error: priceError }, { status: 400 })

  if (!Number.isInteger(deliveryDays) || deliveryDays <= 0) {
    return NextResponse.json({ error: 'deliveryDays debe ser un entero mayor a 0' }, { status: 400 })
  }
  if (conditions !== undefined && JSON.stringify(conditions).length > 5000) {
    return NextResponse.json({ error: 'El campo conditions supera el tamaño permitido (5000 chars)' }, { status: 400 })
  }

  // Ownership check del medio
  const medium = await prisma.medium.findUnique({
    where: { id: mediumId },
    select: { userId: true, deletedAt: true, status: true },
  })
  if (!medium || medium.deletedAt !== null) {
    return NextResponse.json({ error: 'Medio no encontrado' }, { status: 404 })
  }
  if (medium.userId !== profile.id) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }
  if (medium.status === MediumStatus.REJECTED || medium.status === MediumStatus.SUSPENDED) {
    return NextResponse.json(
      { error: 'No podés agregar productos a un medio rechazado o suspendido' },
      { status: 403 },
    )
  }

  try {
    const product = await prisma.product.create({
      data: {
        mediumId,
        type: type as ProductType,
        name: name.trim(),
        description: description?.trim() ?? null,
        price: new Prisma.Decimal(price),
        deliveryDays,
        includesWriting: includesWriting ?? false,
        conditions: conditions
          ? (conditions as Prisma.InputJsonValue)
          : Prisma.JsonNull,
      },
    })

    console.info('[POST /api/marketplace/products]', { reqId, productId: product.id, mediumId, userId: profile.id })

    return NextResponse.json({ product: serializeDecimalPrice(product) }, { status: 201 })
  } catch (err) {
    console.error('[POST /api/marketplace/products] Prisma create failed', {
      reqId,
      mediumId,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al crear el producto' }, { status: 500 })
  }
}

// ── PATCH /api/marketplace/products ───────────────────────────────────────────
// Actualiza un producto. Solo el dueño del medio puede editar.

type UpdateProductBody = {
  id: string
  name?: string
  description?: string
  price?: number
  deliveryDays?: number
  includesWriting?: boolean
  active?: boolean
  conditions?: Record<string, unknown> | null
}

export async function PATCH(request: NextRequest): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: UpdateProductBody
  try {
    body = (await request.json()) as UpdateProductBody
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { id, name, description, price, deliveryDays, includesWriting, active, conditions } = body

  if (!id) {
    return NextResponse.json({ error: 'El campo id es requerido' }, { status: 400 })
  }
  if (name !== undefined && (name.trim().length < 3 || name.trim().length > 100)) {
    return NextResponse.json({ error: 'El nombre debe tener entre 3 y 100 caracteres' }, { status: 400 })
  }
  if (description !== undefined && description.length > 1000) {
    return NextResponse.json({ error: 'La descripción no puede superar los 1000 caracteres' }, { status: 400 })
  }
  if (price !== undefined) {
    const priceError = validatePrice(price)
    if (priceError) return NextResponse.json({ error: priceError }, { status: 400 })
  }
  if (deliveryDays !== undefined && (!Number.isInteger(deliveryDays) || deliveryDays <= 0)) {
    return NextResponse.json({ error: 'deliveryDays debe ser un entero mayor a 0' }, { status: 400 })
  }
  if (conditions !== undefined && conditions !== null && JSON.stringify(conditions).length > 5000) {
    return NextResponse.json({ error: 'El campo conditions supera el tamaño permitido (5000 chars)' }, { status: 400 })
  }

  // Ownership check via relación con el medio
  const existing = await prisma.product.findUnique({
    where: { id },
    select: { medium: { select: { userId: true, deletedAt: true } } },
  })
  if (!existing || existing.medium.deletedAt !== null) {
    return NextResponse.json({ error: 'Producto no encontrado' }, { status: 404 })
  }
  if (existing.medium.userId !== profile.id) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  try {
    const updated = await prisma.product.update({
      where: { id },
      data: {
        ...(name !== undefined ? { name: name.trim() } : {}),
        // description vacío se normaliza a null
        ...(description !== undefined ? { description: description.trim() || null } : {}),
        ...(price !== undefined ? { price: new Prisma.Decimal(price) } : {}),
        ...(deliveryDays !== undefined ? { deliveryDays } : {}),
        ...(includesWriting !== undefined ? { includesWriting } : {}),
        ...(active !== undefined ? { active } : {}),
        ...(conditions !== undefined
          ? { conditions: conditions ? (conditions as Prisma.InputJsonValue) : Prisma.JsonNull }
          : {}),
      },
    })

    console.info('[PATCH /api/marketplace/products]', { reqId, productId: id, userId: profile.id })

    return NextResponse.json({ product: serializeDecimalPrice(updated) })
  } catch (err) {
    console.error('[PATCH /api/marketplace/products] Prisma update failed', {
      reqId,
      productId: id,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al actualizar el producto' }, { status: 500 })
  }
}

// ── DELETE /api/marketplace/products ──────────────────────────────────────────
// Desactiva un producto (active = false). No hay hard delete para preservar historial de órdenes.
// Bloquea si hay órdenes activas sobre este producto.

export async function DELETE(request: NextRequest): Promise<NextResponse> {
  const reqId = request.headers.get('x-request-id') ?? crypto.randomUUID()

  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  let body: { id: string }
  try {
    body = (await request.json()) as { id: string }
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const { id } = body
  if (!id) {
    return NextResponse.json({ error: 'El campo id es requerido' }, { status: 400 })
  }

  // Ownership check
  const existing = await prisma.product.findUnique({
    where: { id },
    select: { active: true, medium: { select: { userId: true, deletedAt: true } } },
  })
  if (!existing || existing.medium.deletedAt !== null) {
    return NextResponse.json({ error: 'Producto no encontrado' }, { status: 404 })
  }
  if (existing.medium.userId !== profile.id) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }
  if (!existing.active) {
    return NextResponse.json({ error: 'El producto ya está inactivo' }, { status: 409 })
  }

  // Verificar que no haya órdenes activas (PENDING o ACCEPTED)
  const activeOrders = await prisma.order.count({
    where: {
      productId: id,
      status: { in: ['PENDING', 'ACCEPTED'] },
    },
  })
  if (activeOrders > 0) {
    return NextResponse.json(
      { error: 'No podés desactivar un producto con órdenes activas pendientes' },
      { status: 409 },
    )
  }

  try {
    await prisma.product.update({
      where: { id },
      data: { active: false },
    })

    console.info('[DELETE /api/marketplace/products]', { reqId, productId: id, userId: profile.id })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[DELETE /api/marketplace/products] Prisma update failed', {
      reqId,
      productId: id,
      userId: profile.id,
      error: err instanceof Error ? err.message : String(err),
      stack: err instanceof Error ? err.stack : undefined,
    })
    return NextResponse.json({ error: 'Error al desactivar el producto' }, { status: 500 })
  }
}
