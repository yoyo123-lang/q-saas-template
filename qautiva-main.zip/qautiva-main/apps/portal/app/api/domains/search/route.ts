import { NextResponse, type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'
import { OpenSrsProvider } from '@qautiva/domains'
import { getProfileOrUnauthorized } from '@/lib/api/marketplace-helpers'

const DEFAULT_TLDS = ['com', 'net', 'org', 'com.ar']

function calcFinalPriceArs(
  registrationPriceUsd: { toString(): string },
  marginType: string,
  marginValue: { toString(): string },
  exchangeRate: number,
): number {
  const costUsd = Number(registrationPriceUsd.toString())
  const margin = Number(marginValue.toString())
  if (marginType === 'PERCENTAGE') {
    return (costUsd * exchangeRate) * (1 + margin / 100)
  }
  return (costUsd * exchangeRate) + margin
}

function extractNamePart(q: string): string {
  const dotIndex = q.indexOf('.')
  return dotIndex === -1 ? q : q.slice(0, dotIndex)
}

/**
 * GET /api/domains/search?q=midominio
 *
 * Busca disponibilidad y precio para un nombre de dominio en múltiples TLDs.
 */
export async function GET(request: NextRequest) {
  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response

  const { searchParams } = new URL(request.url)
  const raw = searchParams.get('q') ?? ''
  const q = raw.trim().toLowerCase()

  if (!q) {
    return NextResponse.json({ error: 'El parámetro q es requerido' }, { status: 400 })
  }
  if (q.includes(' ')) {
    return NextResponse.json({ error: 'El dominio no puede contener espacios' }, { status: 400 })
  }
  if (q.length < 3 || q.length > 253) {
    return NextResponse.json({ error: 'El dominio debe tener entre 3 y 253 caracteres' }, { status: 400 })
  }

  const hasDot = q.includes('.')
  const namePart = extractNamePart(q)
  const tldsToSearch = hasDot ? [q.slice(namePart.length + 1)] : DEFAULT_TLDS

  const exchangeRate = parseFloat(process.env.EXCHANGE_RATE_USD_ARS ?? '1200')
  const provider = new OpenSrsProvider()

  const reqId = crypto.randomUUID()

  console.info('[GET /api/domains/search]', { reqId, q, tldsToSearch })

  try {
    const [lookupResults, tldPricings] = await Promise.all([
      Promise.allSettled(
        tldsToSearch.map((tld) => {
          const domainName = hasDot ? q : `${namePart}.${tld}`
          return provider.checkAvailability(domainName).then((res) => ({ tld, domainName, res }))
        }),
      ),
      prisma.tldPricing.findMany({
        where: { tld: { in: tldsToSearch }, isActive: true },
        select: { tld: true, registrationPriceUsd: true, marginType: true, marginValue: true },
      }),
    ])

    const pricingByTld = new Map(tldPricings.map((p) => [p.tld, p]))

    const results: Array<{
      domain: string
      tld: string
      available: boolean
      priceArs: number
      costUsd: number
    }> = []

    for (const settled of lookupResults) {
      if (settled.status === 'rejected') continue
      const { tld, domainName, res } = settled.value
      if (!res.success) continue

      const tldPricing = pricingByTld.get(tld)
      if (!tldPricing) continue

      const finalPriceArs = calcFinalPriceArs(
        tldPricing.registrationPriceUsd,
        tldPricing.marginType,
        tldPricing.marginValue,
        exchangeRate,
      )

      results.push({
        domain: domainName,
        tld,
        available: res.data.isAvailable,
        priceArs: Math.round(finalPriceArs),
        costUsd: Number(tldPricing.registrationPriceUsd.toString()),
      })
    }

    return NextResponse.json({ results })
  } catch (err) {
    console.error('[GET /api/domains/search] provider error', {
      reqId,
      q,
      error: err instanceof Error ? err.message : String(err),
    })
    return NextResponse.json({ error: 'Error al consultar disponibilidad' }, { status: 500 })
  }
}
