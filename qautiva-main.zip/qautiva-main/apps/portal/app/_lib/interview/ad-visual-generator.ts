/**
 * Generador de piezas gráficas para Meta Ads usando Gemini Flash Image.
 *
 * Flujo:
 * 1. Descarga el logo del cliente de Supabase Storage (si existe)
 * 2. Construye 6 prompts (2 ángulos × 3 formatos) con ad-visual-prompt-builder
 * 3. Llama a Gemini Flash Image en lotes de 3 (MAX_CONCURRENT_GEMINI_CALLS)
 * 4. Valida magic bytes + sube cada pieza al bucket privado ad-visuals
 * 5. Retorna AdVisuals con signed URLs de 24h
 *
 * Umbrales de degradación:
 * - Si ≥1 pieza por formato existe: guardar parcial (degradación aceptable)
 * - Si falta un formato completo: error total
 * - Budget de tiempo: 180s totales; pasado ese punto acepta lo generado hasta ahora
 *
 * Ver ADR-0024 para decisiones de arquitectura.
 */

import type { GenerationConfig, InlineDataPart } from '@google/generative-ai'
import { getGeminiImageModel } from './ai-config'
import { getGeminiClient } from './gemini-client'
import {
  ensureBucket,
  resizeImageForPayload,
  uploadImageToStorage,
  validateImageBytes,
} from './image-utils'
import {
  AD_VISUALS_DISCLAIMER,
  buildAdVisualPrompts,
  type BuildPromptsInput,
  type VisualPromptSpec,
} from './ad-visual-prompt-builder'
import type { AdVisual, AdVisualFormat, AdVisuals, BrandOptions } from './types'

// ── Constantes ────────────────────────────────────────────────────────────────

/** Timeout individual por llamada a Gemini Image (45s vs 30s de logos).
 *  Los prompts son más largos y pueden incluir imagen de logo como inlineData. */
const GEMINI_TIMEOUT_MS = 45_000

/** Concurrencia máxima de llamadas a Gemini Image por lote. Limita RPM. */
const MAX_CONCURRENT_GEMINI_CALLS = 3

/** Budget máximo de tiempo para toda la generación visual (ms).
 *  Pasado este punto se aceptan las piezas ya generadas. */
const TOTAL_BUDGET_MS = 180_000

/** Nombre del bucket privado donde se guardan las piezas de Meta Ads. */
const AD_VISUALS_BUCKET = 'ad-visuals'

/** Timeout para descargar el logo del cliente desde Supabase Storage. */
const LOGO_FETCH_TIMEOUT_MS = 5_000

// ── Tipos internos ────────────────────────────────────────────────────────────

type GenerationSuccess = {
  status: 'fulfilled'
  spec: VisualPromptSpec
  imageUrl: string
  attempt: number
}

type GenerationFailure = {
  status: 'rejected'
  spec: VisualPromptSpec
  error: string
  attempt: number
}

type GenerationResult = GenerationSuccess | GenerationFailure

// ── Descarga de logo ──────────────────────────────────────────────────────────

/**
 * Extrae la URL del logo de la primera opción del deliverable BRAND_OPTIONS.
 */
function extractLogoUrl(brandOptions: BrandOptions | null): string | null {
  if (!brandOptions?.options?.length) return null
  return brandOptions.options[0]?.logoUrl ?? null
}

/**
 * Descarga el logo del cliente con timeout de 5s.
 * Valida que la URL sea HTTPS y del dominio de Supabase Storage (prevención SSRF).
 * Devuelve null en cualquier fallo — degradación aceptable.
 */
async function fetchLogoBuffer(logoUrl: string, context: string): Promise<Buffer | null> {
  // Validar protocolo y dominio para prevenir SSRF
  try {
    const parsed = new URL(logoUrl)
    if (parsed.protocol !== 'https:') {
      console.warn(`[ad-visual-generator][${context}] logo URL con protocolo no HTTPS — sin logo`)
      return null
    }
    // Solo permitir dominios de Supabase Storage
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    if (supabaseUrl) {
      const allowedHost = new URL(supabaseUrl).hostname
      if (parsed.hostname !== allowedHost) {
        console.warn(`[ad-visual-generator][${context}] logo URL de dominio no permitido (${parsed.hostname}) — sin logo`)
        return null
      }
    }
  } catch {
    console.warn(`[ad-visual-generator][${context}] logo URL inválida — sin logo`)
    return null
  }

  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), LOGO_FETCH_TIMEOUT_MS)

  try {
    const response = await fetch(logoUrl, { signal: controller.signal })
    if (!response.ok) {
      console.warn(`[ad-visual-generator][${context}] logo fetch falló (${response.status}) — sin logo`)
      return null
    }
    const arrayBuffer = await response.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)
    validateImageBytes(buffer, `logo/${context}`)
    return await resizeImageForPayload(buffer, `logo/${context}`)
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    console.warn(`[ad-visual-generator][${context}] error descargando logo: ${msg} — sin logo`)
    return null
  } finally {
    clearTimeout(timeoutId)
  }
}

// ── Generación con Gemini ─────────────────────────────────────────────────────

/**
 * Genera UNA imagen con Gemini Flash Image dado un prompt y logo opcional.
 *
 * @returns Buffer con los bytes de la imagen generada
 * @throws Error si Gemini falla, no devuelve imagen, o se supera el timeout
 */
async function generateSingleImage(
  spec: VisualPromptSpec,
  logoBuffer: Buffer | null,
  geminiModel: string,
  logContext: string,
): Promise<Buffer> {
  const client = getGeminiClient()
  const startMs = Date.now()

  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), GEMINI_TIMEOUT_MS)

  try {
    const model = client.getGenerativeModel({
      model: geminiModel,
      generationConfig: {
        responseModalities: ['IMAGE'],
      } as unknown as GenerationConfig,
    })

    const parts: Array<{ text: string } | InlineDataPart> = [{ text: spec.prompt }]

    if (logoBuffer) {
      parts.push({
        inlineData: {
          mimeType: 'image/png',
          data: logoBuffer.toString('base64'),
        },
      } as InlineDataPart)
    }

    const result = await model.generateContent(
      { contents: [{ role: 'user', parts }] },
      { signal: controller.signal },
    )

    const candidate = result.response.candidates?.[0]
    if (!candidate) throw new Error('Sin candidatos en la respuesta de Gemini')

    const imagePart = candidate.content.parts.find(
      (p): p is InlineDataPart => 'inlineData' in p && !!p.inlineData,
    )
    if (!imagePart) throw new Error('Respuesta de Gemini sin parte de imagen (inlineData)')

    const buffer = Buffer.from(imagePart.inlineData.data, 'base64')

    console.log(`[ad-visual-generator][${logContext}] gemini ok`, {
      format: spec.format,
      angle: spec.angle,
      sizeBytes: buffer.length,
      durationMs: Date.now() - startMs,
    })

    return buffer
  } catch (err) {
    const errorType = err instanceof Error ? err.constructor.name : typeof err
    const errorMsg = err instanceof Error ? err.message : String(err)
    console.error(`[ad-visual-generator][${logContext}] gemini failed`, {
      format: spec.format,
      angle: spec.angle,
      durationMs: Date.now() - startMs,
      errorType,
      error: errorMsg,
      aborted: controller.signal.aborted,
    })
    throw err
  } finally {
    clearTimeout(timeoutId)
  }
}

// ── Generación + upload de una pieza ─────────────────────────────────────────

/**
 * Genera, valida y sube UNA pieza. Devuelve GenerationResult (nunca lanza).
 */
async function generateAndUploadOne(
  spec: VisualPromptSpec,
  logoBuffer: Buffer | null,
  geminiModel: string,
  projectId: string,
  attempt: number,
  logContext: string,
): Promise<GenerationResult> {
  try {
    const imageBuffer = await generateSingleImage(spec, logoBuffer, geminiModel, logContext)
    validateImageBytes(imageBuffer, logContext)

    const fileName = `${spec.format}-${spec.angle.replace(' ', '-')}-${Date.now()}.png`
    const filePath = `${projectId}/${fileName}`
    const imageUrl = await uploadImageToStorage(imageBuffer, AD_VISUALS_BUCKET, filePath, false)

    return { status: 'fulfilled', spec, imageUrl, attempt }
  } catch (err) {
    return {
      status: 'rejected',
      spec,
      error: err instanceof Error ? err.message : String(err),
      attempt,
    }
  }
}

// ── Validación de cobertura mínima ────────────────────────────────────────────

/**
 * Verifica que haya al menos una pieza exitosa por cada formato requerido.
 * Lanza Error si falta un formato completo.
 */
function assertMinimumCoverage(results: GenerationResult[]): void {
  const requiredFormats: AdVisualFormat[] = ['feed_square', 'feed_portrait', 'story']
  for (const format of requiredFormats) {
    const hasOne = results.some((r) => r.spec.format === format && r.status === 'fulfilled')
    if (!hasOne) {
      throw new Error(`[ad-visual-generator] Formato '${format}' sin ninguna pieza exitosa — error total`)
    }
  }
}

// ── Función principal ─────────────────────────────────────────────────────────

// Omit<BuildPromptsInput, 'logoAvailable'>: el generador calcula logoAvailable internamente
// (según si logra descargar el logo), así que el caller no lo pasa.
export type GenerateAdVisualsInput = Omit<BuildPromptsInput, 'logoAvailable'> & {
  projectId: string
  sessionId: string
  brandOptions: BrandOptions | null
}

/**
 * Regenera UNA pieza gráfica dado su visualId (formato "format-angle").
 * Usado por el orquestador para reemplazar piezas con score bajo tras la validación.
 *
 * @returns AdVisual regenerado (attempt=2), o null si falla
 */
export async function regenerateAdVisual(
  visualId: string,
  input: GenerateAdVisualsInput,
  preloadedLogoBuffer?: Buffer | null,
): Promise<AdVisual | null> {
  const { projectId, sessionId, brandOptions } = input
  const logCtx = `session:${sessionId.slice(0, 8)}/regen`

  // Usar logo pre-descargado si está disponible (evita re-descarga por pieza)
  const logoBuffer = preloadedLogoBuffer !== undefined
    ? preloadedLogoBuffer
    : (extractLogoUrl(brandOptions) ? await fetchLogoBuffer(extractLogoUrl(brandOptions)!, logCtx) : null)

  const { specs } = buildAdVisualPrompts({ ...input, logoAvailable: logoBuffer !== null })
  const spec = specs.find((s) => `${s.format}-${s.angle}` === visualId)

  if (!spec) {
    console.warn(`[ad-visual-generator][${logCtx}] spec no encontrado para visualId=${visualId}`)
    return null
  }

  const geminiModel = await getGeminiImageModel()
  const result = await generateAndUploadOne(spec, logoBuffer, geminiModel, projectId, 2, `${logCtx}/${visualId}`)

  if (result.status === 'rejected') {
    console.warn(`[ad-visual-generator][${logCtx}] regeneración fallida para ${visualId}: ${(result as GenerationFailure).error}`)
    return null
  }

  const r = result as GenerationSuccess
  return {
    format: r.spec.format,
    aspectRatio: r.spec.aspectRatio,
    resolution: r.spec.resolution,
    imageUrl: r.imageUrl,
    angle: r.spec.angle,
    generatedAt: new Date().toISOString(),
    attempt: 2,
  }
}

/**
 * Genera piezas gráficas para Meta Ads usando Gemini Flash Image.
 *
 * Genera 2 ángulos × 3 formatos = 6 piezas, en lotes de 3.
 * Degradación aceptable: si falla un ángulo pero queda el otro en un formato, continúa.
 * Error total: si un formato queda completamente sin piezas.
 *
 * @throws Error si algún formato queda sin cobertura
 */
export async function generateAdVisuals(input: GenerateAdVisualsInput): Promise<AdVisuals> {
  const { projectId, sessionId, brandOptions } = input
  const budgetStart = Date.now()
  const logCtx = `session:${sessionId.slice(0, 8)}`

  console.log(`[ad-visual-generator][${logCtx}] started`, {
    sessionId,
    projectId,
    hasLogo: !!extractLogoUrl(brandOptions),
  })

  // 1. Preparar bucket privado
  await ensureBucket(AD_VISUALS_BUCKET, false)

  // 2. Descargar logo (degradación aceptable si falla)
  const logoUrl = extractLogoUrl(brandOptions)
  const logoBuffer = logoUrl ? await fetchLogoBuffer(logoUrl, logCtx) : null

  // 3. Construir prompts
  const { specs, brandContext } = buildAdVisualPrompts({
    ...input,
    logoAvailable: logoBuffer !== null,
  })

  // 4. Modelo Gemini configurado
  const geminiModel = await getGeminiImageModel()
  console.log(`[ad-visual-generator][${logCtx}] model: ${geminiModel}, specs: ${specs.length}`)

  // 5. Generar en lotes de MAX_CONCURRENT_GEMINI_CALLS
  const allResults: GenerationResult[] = []

  for (let i = 0; i < specs.length; i += MAX_CONCURRENT_GEMINI_CALLS) {
    if (Date.now() - budgetStart > TOTAL_BUDGET_MS) {
      const remaining = specs.slice(i)
      console.warn(`[ad-visual-generator][${logCtx}] budget agotado — saltando ${remaining.length} piezas restantes`)
      for (const spec of remaining) {
        allResults.push({ status: 'rejected', spec, error: 'Budget de tiempo agotado', attempt: 1 })
      }
      break
    }

    const batch = specs.slice(i, i + MAX_CONCURRENT_GEMINI_CALLS)
    const batchNum = Math.floor(i / MAX_CONCURRENT_GEMINI_CALLS) + 1
    const totalBatches = Math.ceil(specs.length / MAX_CONCURRENT_GEMINI_CALLS)

    console.log(`[ad-visual-generator][${logCtx}] batch ${batchNum}/${totalBatches}`)

    const batchResults = await Promise.all(
      batch.map((spec, idx) => {
        const imageNum = i + idx + 1
        const imgCtx = `${logCtx}/img-${imageNum}-attempt-1`
        return generateAndUploadOne(spec, logoBuffer, geminiModel, projectId, 1, imgCtx)
      }),
    )

    allResults.push(...batchResults)
  }

  const succeeded = allResults.filter((r) => r.status === 'fulfilled')
  const failed = allResults.filter((r) => r.status === 'rejected')

  console.log(`[ad-visual-generator][${logCtx}] generation done`, {
    total: allResults.length,
    succeeded: succeeded.length,
    failed: failed.length,
    totalElapsedMs: Date.now() - budgetStart,
  })

  if (failed.length > 0) {
    console.warn(`[ad-visual-generator][${logCtx}] ${failed.length} piezas fallidas`, {
      failures: failed.map((r) => ({
        format: r.spec.format,
        angle: r.spec.angle,
        error: (r as GenerationFailure).error,
      })),
    })
  }

  // 6. Validar cobertura mínima
  assertMinimumCoverage(allResults)

  // 7. Ensamblar AdVisuals
  const visuals: AdVisual[] = (succeeded as GenerationSuccess[]).map((r) => ({
    format: r.spec.format,
    aspectRatio: r.spec.aspectRatio,
    resolution: r.spec.resolution,
    imageUrl: r.imageUrl,
    angle: r.spec.angle,
    generatedAt: new Date().toISOString(),
    attempt: r.attempt,
  }))

  return {
    visuals,
    brandContext,
    disclaimer: AD_VISUALS_DISCLAIMER,
  }
}
