import { Suspense } from 'react'
import { prisma } from '@qautiva/db'
import { ConfigTabs } from '@/components/configuracion/ConfigTabs'
import { GeneralTab } from '@/components/configuracion/GeneralTab'
import { IntegracionesTab } from '@/components/configuracion/IntegracionesTab'
import { LimitesTab } from '@/components/configuracion/LimitesTab'
import { NotificacionesTab } from '@/components/configuracion/NotificacionesTab'

const VALID_TABS = ['general', 'integraciones', 'limites', 'notificaciones'] as const
type TabId = typeof VALID_TABS[number]

const TAB_TITLES: Record<TabId, { title: string; subtitle: string }> = {
  general:        { title: 'General',        subtitle: 'Trial, modelo de IA y configuración base del sistema.' },
  integraciones:  { title: 'Integraciones',  subtitle: 'API keys de servicios externos y bot de Telegram.' },
  limites:        { title: 'Límites',        subtitle: 'Fees por plan y fuente de clave de IA.' },
  notificaciones: { title: 'Notificaciones', subtitle: 'Templates de email enviados a clientes.' },
}

export default async function ConfiguracionPage({
  searchParams,
}: {
  searchParams: { tab?: string }
}) {
  const rawTab = searchParams.tab ?? 'general'
  const activeTab: TabId = (VALID_TABS as readonly string[]).includes(rawTab)
    ? (rawTab as TabId)
    : 'general'
  const meta = TAB_TITLES[activeTab]

  // Cargar solo los datos del tab activo para evitar queries innecesarias
  const [trialConfig, telegramConfig, feeConfigs, integrations, templates] =
    await Promise.all([
      activeTab === 'general'
        ? prisma.trialConfig.findUnique({ where: { id: 1 } })
        : Promise.resolve(null),
      activeTab === 'integraciones'
        ? prisma.telegramConfig.findUnique({ where: { id: 1 } })
        : Promise.resolve(null),
      activeTab === 'limites'
        ? prisma.feeConfig.findMany({ orderBy: [{ plan: 'asc' }, { keySource: 'asc' }] })
        : Promise.resolve([]),
      activeTab === 'integraciones'
        ? prisma.integrationConfig.findMany({ orderBy: { service: 'asc' } })
        : Promise.resolve([]),
      activeTab === 'notificaciones'
        ? prisma.notificationTemplate.findMany({ orderBy: { type: 'asc' } })
        : Promise.resolve([]),
    ])

  return (
    <div className="p-8 max-w-4xl">
      {/* Encabezado */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">{meta.title}</h1>
        <p className="text-[#94A3B8] text-sm mt-1">{meta.subtitle}</p>
      </div>

      {/* Tabs — Suspense requerido porque ConfigTabs usa useSearchParams */}
      <Suspense fallback={<div className="h-10 border-b border-[#1E293B]" />}>
        <ConfigTabs activeTab={activeTab} />
      </Suspense>

      {/* Contenido del tab activo */}
      {activeTab === 'general' && (
        <GeneralTab trialConfig={trialConfig} />
      )}
      {activeTab === 'integraciones' && (
        <IntegracionesTab integrations={integrations} telegramConfig={telegramConfig} />
      )}
      {activeTab === 'limites' && (
        <LimitesTab feeConfigs={feeConfigs} />
      )}
      {activeTab === 'notificaciones' && (
        <NotificacionesTab templates={templates} />
      )}
    </div>
  )
}
