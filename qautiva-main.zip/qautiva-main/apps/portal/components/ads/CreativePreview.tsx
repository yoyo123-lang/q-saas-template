'use client'

import type { AdCopyVariant } from '../../app/_lib/interview/types'

type Platform = 'GOOGLE_ADS' | 'META'
type Format = 'SEARCH' | 'FEED' | 'STORY'

interface CreativePreviewProps {
  variant: AdCopyVariant
  platform: Platform
  format: Format
  /** Nombre del negocio para usar en el mockup de Google Search */
  businessName?: string
}

/**
 * Muestra un mockup visual del anuncio según plataforma y formato.
 * NO es un componente interactivo — solo presenta la pieza.
 */
export function CreativePreview({ variant, platform, format, businessName }: CreativePreviewProps) {
  if (platform === 'GOOGLE_ADS' && format === 'SEARCH') {
    return <GoogleSearchPreview variant={variant} businessName={businessName ?? 'Tu negocio'} />
  }

  if (platform === 'META' && format === 'FEED') {
    return <MetaFeedPreview variant={variant} />
  }

  if (platform === 'META' && format === 'STORY') {
    return <MetaStoryPreview variant={variant} />
  }

  return null
}

// ── Google Search Preview ────────────────────────────────────────────────────

function GoogleSearchPreview({ variant, businessName }: { variant: AdCopyVariant; businessName: string }) {
  return (
    <div className="rounded-lg border border-white/10 bg-zinc-900 p-4 font-sans">
      <p className="text-xs text-zinc-500 mb-1">Anuncio · {businessName.toLowerCase().replace(/\s+/g, '')}.com.ar</p>
      <p className="text-base font-medium text-blue-400 leading-snug">{variant.headline}</p>
      <p className="mt-1 text-sm text-zinc-300 leading-relaxed">{variant.description}</p>
      <p className="mt-2 text-xs text-emerald-400 font-medium">{variant.callToAction} →</p>
      <div className="mt-3 flex items-center gap-2">
        <span className="inline-flex items-center gap-1 rounded bg-zinc-700/50 px-2 py-0.5 text-xs text-zinc-400">
          <span>G</span> Google Search
        </span>
        <span className="text-xs text-zinc-600">
          {variant.headline.length}/30 · {variant.description.length}/90 chars
        </span>
      </div>
    </div>
  )
}

// ── Meta Feed Preview ────────────────────────────────────────────────────────

function MetaFeedPreview({ variant }: { variant: AdCopyVariant }) {
  return (
    <div className="rounded-lg border border-white/10 bg-zinc-900 overflow-hidden font-sans">
      {/* Sponsored header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-xs font-bold text-white">
          N
        </div>
        <div>
          <p className="text-sm font-medium text-white">Nombre del negocio</p>
          <p className="text-xs text-zinc-500">Publicidad patrocinada · Feed</p>
        </div>
      </div>
      {/* Primary text */}
      <div className="px-4 py-3">
        <p className="text-sm text-zinc-200 leading-relaxed">{variant.description}</p>
      </div>
      {/* Image placeholder */}
      <div className="mx-4 h-36 rounded-lg bg-white/5 flex items-center justify-center border border-white/5">
        <p className="text-xs text-zinc-600">Imagen del anuncio</p>
      </div>
      {/* Headline + CTA */}
      <div className="flex items-center justify-between px-4 py-3 border-t border-white/5">
        <div>
          <p className="text-sm font-medium text-white">{variant.headline}</p>
        </div>
        <span className="rounded-md bg-zinc-700 px-3 py-1.5 text-xs font-medium text-white">
          {variant.callToAction}
        </span>
      </div>
      <div className="px-4 pb-3">
        <span className="text-xs text-zinc-600">
          {variant.headline.length}/40 · {variant.description.length}/125 chars
        </span>
      </div>
    </div>
  )
}

// ── Meta Story Preview ───────────────────────────────────────────────────────

function MetaStoryPreview({ variant }: { variant: AdCopyVariant }) {
  return (
    <div className="mx-auto w-48 rounded-2xl border border-white/10 bg-zinc-900 overflow-hidden font-sans aspect-[9/16] flex flex-col">
      {/* Top bar */}
      <div className="flex items-center gap-2 px-3 py-2">
        <div className="h-6 w-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex-shrink-0" />
        <p className="text-xs text-zinc-300 truncate">Nombre del negocio</p>
        <span className="ml-auto text-xs text-zinc-500">Anuncio</span>
      </div>
      {/* Background placeholder */}
      <div className="flex-1 bg-white/5 flex flex-col items-center justify-end p-3">
        {/* Headline overlay */}
        <div className="w-full rounded-lg bg-black/60 px-3 py-2 text-center mb-3">
          <p className="text-xs font-semibold text-white leading-snug">{variant.headline}</p>
        </div>
        {/* CTA button */}
        <span className="w-full rounded-lg bg-white px-3 py-2 text-xs font-bold text-black text-center block">
          {variant.callToAction}
        </span>
      </div>
      <div className="px-3 py-2 text-center">
        <span className="text-[10px] text-zinc-600">
          {variant.headline.length}/40 · Story
        </span>
      </div>
    </div>
  )
}
