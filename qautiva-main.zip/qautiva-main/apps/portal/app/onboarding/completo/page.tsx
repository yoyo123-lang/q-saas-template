import { redirect } from 'next/navigation'

/**
 * El onboarding de cuenta está completo. Redirige al hub de proyectos.
 * El usuario verá /proyectos donde puede crear su primer proyecto.
 */
export default function CompletePage() {
  redirect('/proyectos')
}
