import { z } from 'zod'

export const sendMessageSchema = z.object({
  content: z.string().min(1, 'El mensaje no puede estar vacío.').max(5000, 'El mensaje no puede superar los 5000 caracteres.'),
})

export type SendMessageData = z.infer<typeof sendMessageSchema>
