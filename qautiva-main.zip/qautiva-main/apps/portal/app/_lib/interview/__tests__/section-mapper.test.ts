import { describe, it, expect } from 'vitest';
import {
  getRequiredSections,
  getCommercialLeads,
  isValidWebAnswer,
  VALID_WEB_ANSWERS,
} from '../section-mapper';

describe('getRequiredSections', () => {
  it('always includes hero and about', () => {
    const result = getRequiredSections({});
    expect(result).toContain('hero');
    expect(result).toContain('about');
  });

  it('adds services for mostrar_servicios objective', () => {
    const result = getRequiredSections({ web_objetivo: 'mostrar_servicios' });
    expect(result).toContain('services');
    expect(result).not.toContain('contact');
    expect(result).not.toContain('pricing');
  });

  it('adds contact for captar_consultas objective', () => {
    const result = getRequiredSections({ web_objetivo: 'captar_consultas' });
    expect(result).toContain('contact');
  });

  it('adds pricing for vender_online objective', () => {
    const result = getRequiredSections({ web_objetivo: 'vender_online' });
    expect(result).toContain('pricing');
  });

  it('does not add extra sections for informar objective', () => {
    const result = getRequiredSections({ web_objetivo: 'informar' });
    expect(result).toEqual(['hero', 'about']);
  });

  it('adds booking when web_agenda is si', () => {
    const result = getRequiredSections({ web_agenda: 'si' });
    expect(result).toContain('booking');
  });

  it('does NOT add booking when web_agenda is me_interesa', () => {
    const result = getRequiredSections({ web_agenda: 'me_interesa' });
    expect(result).not.toContain('booking');
  });

  it('does NOT add booking when web_agenda is no', () => {
    const result = getRequiredSections({ web_agenda: 'no' });
    expect(result).not.toContain('booking');
  });

  it('adds payments when web_pagos is si', () => {
    const result = getRequiredSections({ web_pagos: 'si' });
    expect(result).toContain('payments');
  });

  it('does NOT add payments when web_pagos is me_interesa', () => {
    const result = getRequiredSections({ web_pagos: 'me_interesa' });
    expect(result).not.toContain('payments');
  });

  it('adds careers when web_empleo is si', () => {
    const result = getRequiredSections({ web_empleo: 'si' });
    expect(result).toContain('careers');
  });

  it('adds blog when web_blog is si', () => {
    const result = getRequiredSections({ web_blog: 'si' });
    expect(result).toContain('blog');
  });

  it('combines multiple sections correctly', () => {
    const result = getRequiredSections({
      web_objetivo: 'mostrar_servicios',
      web_agenda: 'si',
      web_pagos: 'si',
      web_empleo: 'si',
      web_blog: 'si',
    });
    expect(result).toContain('hero');
    expect(result).toContain('about');
    expect(result).toContain('services');
    expect(result).toContain('booking');
    expect(result).toContain('payments');
    expect(result).toContain('careers');
    expect(result).toContain('blog');
    expect(result).toHaveLength(7);
  });

  it('returns no duplicates', () => {
    const result = getRequiredSections({ web_objetivo: 'informar' });
    const unique = [...new Set(result)];
    expect(result).toEqual(unique);
  });

  it('handles empty answers gracefully', () => {
    const result = getRequiredSections({});
    expect(result).toEqual(['hero', 'about']);
  });

  it('ignores unknown answer keys', () => {
    const result = getRequiredSections({ unknown_key: 'si' });
    expect(result).toEqual(['hero', 'about']);
  });

  it('ignores invalid answer values', () => {
    const result = getRequiredSections({ web_objetivo: 'invalid_value' });
    expect(result).toEqual(['hero', 'about']);
  });
});

describe('getCommercialLeads', () => {
  it('returns empty array when no me_interesa answers', () => {
    const result = getCommercialLeads({ web_agenda: 'si', web_pagos: 'no' });
    expect(result).toEqual([]);
  });

  it('returns qontacta when web_agenda is me_interesa', () => {
    const result = getCommercialLeads({ web_agenda: 'me_interesa' });
    expect(result).toEqual(['qontacta']);
  });

  it('returns qobra when web_pagos is me_interesa', () => {
    const result = getCommercialLeads({ web_pagos: 'me_interesa' });
    expect(result).toEqual(['qobra']);
  });

  it('returns both when both are me_interesa', () => {
    const result = getCommercialLeads({
      web_agenda: 'me_interesa',
      web_pagos: 'me_interesa',
    });
    expect(result).toEqual(['qontacta', 'qobra']);
  });

  it('handles empty answers', () => {
    const result = getCommercialLeads({});
    expect(result).toEqual([]);
  });

  it('ignores invalid values (uppercase, typos)', () => {
    const result = getCommercialLeads({
      web_agenda: 'ME_INTERESA',
      web_pagos: 'interested',
    });
    expect(result).toEqual([]);
  });

  it('ignores unknown keys', () => {
    const result = getCommercialLeads({ web_unknown: 'me_interesa' });
    expect(result).toEqual([]);
  });
});

describe('isValidWebAnswer', () => {
  it('accepts valid web_objetivo values', () => {
    for (const value of VALID_WEB_ANSWERS.web_objetivo) {
      expect(isValidWebAnswer('web_objetivo', value)).toBe(true);
    }
  });

  it('rejects invalid web_objetivo values', () => {
    expect(isValidWebAnswer('web_objetivo', 'hacking')).toBe(false);
    expect(isValidWebAnswer('web_objetivo', '')).toBe(false);
  });

  it('accepts valid web_agenda values', () => {
    for (const value of VALID_WEB_ANSWERS.web_agenda) {
      expect(isValidWebAnswer('web_agenda', value)).toBe(true);
    }
  });

  it('rejects invalid web_agenda values', () => {
    expect(isValidWebAnswer('web_agenda', 'maybe')).toBe(false);
  });

  it('always accepts web_extra (free text)', () => {
    expect(isValidWebAnswer('web_extra', 'anything goes')).toBe(true);
    expect(isValidWebAnswer('web_extra', '<script>alert(1)</script>')).toBe(true);
    expect(isValidWebAnswer('web_extra', '')).toBe(true);
  });

  it('rejects unknown question ids', () => {
    expect(isValidWebAnswer('unknown_question', 'value')).toBe(false);
  });
});
