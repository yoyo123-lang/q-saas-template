'use client'

import { useState } from 'react'
import { TEMPLATE_STYLES, INDUSTRY_VERTICALS } from '@qautiva/shared'

interface QueueJob {
  id: string
  queueStatus: 'QUEUED' | 'GENERATING' | 'DONE' | 'ERROR'
  queuedAt: string | null
  styleId: string | null
  compatibleIndustries: string[]
  status: 'DRAFT' | 'ACTIVE'
  queueError: string | null
  stitchAccount: { id: string; label: string } | null
  createdAt: string
  updatedAt: string
}

interface JobsTableProps {
  jobs: QueueJob[]
  hasCredits: boolean
  onRun: (jobId: string) => Promise<void>
  onDelete: (jobId: string) => Promise<void>
}

const STATUS_BADGE: Record<
  QueueJob['queueStatus'],
  { label: string; className: string }
> = {
  QUEUED: { label: 'QUEUED', className: 'bg-blue-500/20 text-blue-400' },
  GENERATING: { label: 'GENERATING', className: 'bg-yellow-500/20 text-yellow-400' },
  DONE: { label: 'DONE', className: 'bg-green-500/20 text-green-400' },
  ERROR: { label: 'ERROR', className: 'bg-red-500/20 text-red-400' },
}

const ALL_VERTICALS = INDUSTRY_VERTICALS.map((v) => v.vertical)

function getStyleLabel(styleId: string | null): string {
  if (!styleId) return '—'
  return TEMPLATE_STYLES.find((s) => s.id === styleId)?.label ?? styleId
}

function getIndustry(job: QueueJob): string {
  return job.compatibleIndustries[0] ?? '—'
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('es-AR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function JobsTable({ jobs, hasCredits, onRun, onDelete }: JobsTableProps) {
  const [runningId, setRunningId] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  // Filtros
  const [filterStatus, setFilterStatus] = useState<string>('')
  const [filterVertical, setFilterVertical] = useState<string>('')
  const [filterStyle, setFilterStyle] = useState<string>('')

  async function handleRun(jobId: string) {
    setRunningId(jobId)
    try {
      await onRun(jobId)
    } finally {
      setRunningId(null)
    }
  }

  async function handleDelete(jobId: string) {
    if (!confirm('¿Cancelar y eliminar este job?')) return
    setDeletingId(jobId)
    try {
      await onDelete(jobId)
    } finally {
      setDeletingId(null)
    }
  }

  // Aplicar filtros en el cliente (la tabla ya viene paginada desde el server)
  const filteredJobs = jobs.filter((job) => {
    if (filterStatus && job.queueStatus !== filterStatus) return false
    if (filterStyle && job.styleId !== filterStyle) return false
    if (filterVertical) {
      const industry = getIndustry(job)
      const vertical = INDUSTRY_VERTICALS.find((v) =>
        (v.industries as readonly string[]).includes(industry),
      )?.vertical
      if (vertical !== filterVertical) return false
    }
    return true
  })

  return (
    <div className="flex flex-col gap-4">
      {/* Filtros */}
      <div className="flex items-center gap-2 flex-wrap">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-1.5 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-sm text-[#94A3B8] focus:outline-none focus:border-[#8B5CF6]"
        >
          <option value="">Todos los estados</option>
          <option value="QUEUED">QUEUED</option>
          <option value="GENERATING">GENERATING</option>
          <option value="DONE">DONE</option>
          <option value="ERROR">ERROR</option>
        </select>

        <select
          value={filterVertical}
          onChange={(e) => setFilterVertical(e.target.value)}
          className="px-3 py-1.5 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-sm text-[#94A3B8] focus:outline-none focus:border-[#8B5CF6]"
        >
          <option value="">Todos los verticales</option>
          {ALL_VERTICALS.map((v) => (
            <option key={v} value={v}>
              {v}
            </option>
          ))}
        </select>

        <select
          value={filterStyle}
          onChange={(e) => setFilterStyle(e.target.value)}
          className="px-3 py-1.5 bg-[#0B0F1A] border border-[#1E293B] rounded-lg text-sm text-[#94A3B8] focus:outline-none focus:border-[#8B5CF6]"
        >
          <option value="">Todos los estilos</option>
          {TEMPLATE_STYLES.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>

        <span className="ml-auto text-xs text-[#475569]">
          {filteredJobs.length} jobs
        </span>
      </div>

      {/* Tabla */}
      {filteredJobs.length === 0 ? (
        <div className="border border-[#1E293B] rounded-lg p-8 text-center text-[#475569] text-sm">
          No hay jobs que coincidan con los filtros.
        </div>
      ) : (
        <div className="border border-[#1E293B] rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-[#0F172A] border-b border-[#1E293B]">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#64748B] uppercase tracking-wide">
                  Industria
                </th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#64748B] uppercase tracking-wide">
                  Estilo
                </th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#64748B] uppercase tracking-wide">
                  Estado
                </th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#64748B] uppercase tracking-wide">
                  Cuenta
                </th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#64748B] uppercase tracking-wide">
                  Solicitado
                </th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#64748B] uppercase tracking-wide">
                  Acción
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]">
              {filteredJobs.map((job) => {
                const badge = STATUS_BADGE[job.queueStatus]
                const canRun = (job.queueStatus === 'QUEUED' || job.queueStatus === 'ERROR') && hasCredits

                return (
                  <tr key={job.id} className="hover:bg-[#0F172A]/50 transition-colors">
                    <td className="px-4 py-3 text-[#CBD5E1]">{getIndustry(job)}</td>
                    <td className="px-4 py-3 text-[#94A3B8] text-xs">{getStyleLabel(job.styleId)}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${badge.className}`}>
                        {badge.label}
                      </span>
                      {job.queueStatus === 'ERROR' && job.queueError && (
                        <p className="text-xs text-red-400 mt-1 max-w-[200px] truncate" title={job.queueError}>
                          {job.queueError}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs">
                      {job.stitchAccount?.label ?? '—'}
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs">
                      {job.queuedAt ? formatDate(job.queuedAt) : '—'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {canRun && (
                          <button
                            onClick={() => void handleRun(job.id)}
                            disabled={runningId === job.id}
                            className="px-3 py-1 bg-[#8B5CF6] text-white text-xs rounded hover:bg-[#7C3AED] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            {runningId === job.id
                              ? 'Ejecutando...'
                              : job.queueStatus === 'ERROR'
                              ? 'Reintentar'
                              : 'Ejecutar'}
                          </button>
                        )}
                        {job.queueStatus === 'QUEUED' && (
                          <button
                            onClick={() => void handleDelete(job.id)}
                            disabled={deletingId === job.id}
                            className="px-3 py-1 text-xs text-[#64748B] border border-[#1E293B] rounded hover:text-red-400 hover:border-red-400/50 disabled:opacity-50 transition-colors"
                          >
                            {deletingId === job.id ? 'Cancelando...' : 'Cancelar'}
                          </button>
                        )}
                        {job.queueStatus === 'DONE' && (
                          <a
                            href={`/templates/${job.id}`}
                            className="px-3 py-1 text-xs text-[#94A3B8] border border-[#1E293B] rounded hover:text-white transition-colors"
                          >
                            Ver template
                          </a>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
