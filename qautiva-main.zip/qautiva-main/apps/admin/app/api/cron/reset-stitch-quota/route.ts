import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'

/**
 * GET /api/cron/reset-stitch-quota
 *
 * Cron diario: resetea usedToday=0 en todas las cuentas Stitch activas.
 * Protegido por CRON_SECRET para evitar ejecuciones no autorizadas.
 *
 * Configurar en vercel.json:
 * { "path": "/api/cron/reset-stitch-quota", "schedule": "0 3 * * *" }
 * (3 AM UTC — medianoche en Buenos Aires GMT-3)
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env['CRON_SECRET']

  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  try {
    const result = await prisma.stitchAccount.updateMany({
      where: { active: true },
      data: {
        usedToday: 0,
        lastResetAt: new Date(),
      },
    })

    console.info(`[cron:reset-stitch-quota] Reset ${result.count} cuentas Stitch`)

    return NextResponse.json({ reset: result.count, timestamp: new Date().toISOString() })
  } catch (err) {
    console.error('[cron:reset-stitch-quota] Error al resetear cuotas:', err)
    return NextResponse.json({ error: 'Error al resetear cuotas' }, { status: 500 })
  }
}
