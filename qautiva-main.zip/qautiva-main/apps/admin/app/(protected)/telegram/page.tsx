export default function TelegramPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-white">Bot de Telegram</h1>
      <p className="text-[#94A3B8] mt-2">Configuración y gestión del bot de Telegram.</p>
    </div>
  )
}
