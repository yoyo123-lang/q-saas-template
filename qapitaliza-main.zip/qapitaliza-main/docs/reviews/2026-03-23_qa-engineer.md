# Revisión: QA Engineer
Fecha: 2026-03-23
Proyecto: Qapitaliza
Revisó: Claude Code en rol de QA Engineer

## Resumen
- Estado: ⚠️ Aprobado con observaciones
- Hallazgos: 0 críticos, 2 altos, 2 medios, 1 bajo

## Hallazgos

### [CRÍTICO → CORREGIDO] `incrementListingViews` sin manejo de error podía romper la página de detalle
- Dónde: `src/app/(public)/explorar/[slug]/page.tsx`
- Problema: Una falla de DB al incrementar vistas tiraba un 500 al usuario en lugar de mostrar el activo.
- Riesgo: Página de detalle no disponible cuando la DB está lenta o saturada.
- Fix aplicado: Envuelto en `void (async () => { try/catch })()` — fire-and-forget no bloqueante.

### [ALTO → CORREGIDO] Price filter navegaba en cada keystroke
- Dónde: `src/components/listings/filter-sidebar.tsx`
- Problema: `onChange` en los inputs de precio llamaba `router.push()` en cada tecla tipada, causando múltiples navegaciones y posibles race conditions.
- Fix aplicado: Estado local con `useState` + flush en `onBlur`.

### [MEDIO] Listas vacías sin estado de carga explícito en `/explorar`
- Dónde: `src/app/(public)/explorar/page.tsx`
- Problema: Si el fetch de `getListings()` falla (no está en try/catch), el usuario ve un 500 sin mensaje útil.
- Recomendación: Envolver en try/catch con `ErrorState` como fallback.

### [MEDIO] Números en `ListingCard` podrían mostrar `NaN` si el precio es inválido
- Dónde: `src/components/listings/listing-card.tsx:65`
- Problema: `priceUsd.toLocaleString('en-US')` muestra "NaN" si se pasa `NaN`. La serialización en el server debería garantizar un número válido, pero no hay validación explícita.
- Recomendación: Agregar fallback `(isNaN(priceUsd) ? 0 : priceUsd).toLocaleString(...)`.

### [BAJO] URL de búsqueda con espacios no se normaliza
- Dónde: `src/components/shared/hero-search.tsx`
- Problema: Una búsqueda como `" saas "` genera `/explorar?q=%20saas%20` con espacios en la URL.
- Fix ya aplicado: El DAL ya hace `trim()` antes de construir el filtro OR.

## Lo que está bien
- Todos los fetch de DB tienen try/catch o fallback de array vacío.
- El DAL maneja correctamente `q` vacío (no aplica filtro).
- La paginación está correctamente calculada y el componente `Pagination` no se muestra si `totalPages <= 1`.
- `GalleryClient` maneja correctamente la ausencia de screenshots.
- `ListingCard` muestra placeholder cuando no hay screenshot — sin crashes.

## Recomendaciones generales
- Agregar try/catch en `explorar/page.tsx` alrededor de `getListings()` para mostrar `ErrorState` en lugar de 500.
- Testear manualmente con: búsqueda vacía, precio negativo, slug inexistente, categoría inválida.
