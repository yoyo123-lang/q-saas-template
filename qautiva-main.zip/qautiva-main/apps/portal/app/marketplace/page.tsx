import { Suspense } from 'react'
import type { Metadata } from 'next'
import { unstable_cache } from 'next/cache'
import { prisma } from '@qautiva/db'
import { MediumPlatform, MediumStatus, Prisma } from '@qautiva/db'
import { MediaCard, type MediaCardData } from './components/MediaCard'
import { MediaFilters } from './components/MediaFilters'
import { UUID_REGEX } from './lib/constants'

export const metadata: Metadata = {
  title: 'Marketplace — Qautiva',
  description: 'Encontrá medios para publicitar tu marca. Filtrá por plataforma, categoría y precio.',
  openGraph: {
    title: 'Marketplace — Qautiva',
    description: 'Encontrá medios para publicitar tu marca.',
  },
}

const TAKE = 12

// ── Validación de inputs ──────────────────────────────────────────────────────

function safeNumericString(value: string): string | undefined {
  if (!value) return undefined
  const n = Number(value)
  if (isNaN(n) || n < 0) return undefined
  return value
}

function safePlatformValue(value: string): string | undefined {
  if (!value) return undefined
  return Object.values(MediumPlatform).includes(value as MediumPlatform) ? value : undefined
}

function safeCategoryId(value: string): string | undefined {
  if (!value) return undefined
  return UUID_REGEX.test(value) ? value : undefined
}

// ── Data fetching con cache ───────────────────────────────────────────────────

type CatalogParams = {
  platform?: string
  categoryId?: string
  sort?: string
  page?: number
  minPrice?: string
  maxPrice?: string
}

const getCatalog = unstable_cache(
  async (params: CatalogParams) => {
    const { platform, categoryId, sort, page = 1, minPrice, maxPrice } = params

    const where: Prisma.MediumWhereInput = {
      status: MediumStatus.ACTIVE,
      deletedAt: null,
      ...(platform ? { platform: platform as MediumPlatform } : {}),
      ...(categoryId ? { categories: { some: { categoryId } } } : {}),
      ...(minPrice ?? maxPrice
        ? {
            products: {
              some: {
                active: true,
                price: {
                  ...(minPrice ? { gte: new Prisma.Decimal(minPrice) } : {}),
                  ...(maxPrice ? { lte: new Prisma.Decimal(maxPrice) } : {}),
                },
              },
            },
          }
        : {}),
    }

    const orderBy: Prisma.MediumOrderByWithRelationInput =
      sort === 'seguidores-desc' ? { followersCount: 'desc' } : { createdAt: 'desc' }

    const [media, total] = await Promise.all([
      prisma.medium.findMany({
        where,
        orderBy,
        skip: (page - 1) * TAKE,
        take: TAKE,
        select: {
          id: true,
          name: true,
          platform: true,
          description: true,
          country: true,
          followersCount: true,
          monthlyVisits: true,
          domainAuthority: true,
          categories: {
            select: { category: { select: { id: true, name: true, slug: true } } },
          },
          // Solo el producto más barato activo — la card solo muestra precio mínimo
          products: {
            where: { active: true },
            select: { id: true, type: true, name: true, price: true, deliveryDays: true },
            orderBy: { price: 'asc' },
            take: 1,
          },
          user: { select: { displayName: true, avatarUrl: true } },
        },
      }),
      prisma.medium.count({ where }),
    ])

    // Serializar Decimal → number
    type RawProduct = { id: string; type: string; name: string; price: Prisma.Decimal; deliveryDays: number }
    type RawMedium = Omit<MediaCardData, 'products'> & { products: RawProduct[] }
    const serialized: MediaCardData[] = (media as RawMedium[]).map((m) => ({
      ...m,
      products: m.products.map((p: RawProduct) => ({ ...p, price: p.price.toNumber() })),
    }))

    return { media: serialized, total, pages: Math.ceil(total / TAKE) }
  },
  ['marketplace-catalog'],
  { revalidate: 30, tags: ['marketplace-catalog'] },
)

const getCategories = unstable_cache(
  async () =>
    prisma.category.findMany({
      where: { parentId: null },
      select: { id: true, name: true, slug: true },
      orderBy: { name: 'asc' },
    }),
  ['marketplace-categories'],
  { revalidate: 300 },
)

// ── Page ──────────────────────────────────────────────────────────────────────

type SearchParams = Record<string, string | string[] | undefined>

function getString(sp: SearchParams, key: string): string {
  const v = sp[key]
  return typeof v === 'string' ? v : ''
}

function getPage(sp: SearchParams): number {
  const v = parseInt(getString(sp, 'page') || '1', 10)
  return isNaN(v) || v < 1 ? 1 : v
}

export default async function MarketplacePage({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const platform = safePlatformValue(getString(searchParams, 'platform'))
  const categoryId = safeCategoryId(getString(searchParams, 'categoryId'))
  const sort = getString(searchParams, 'sort') || 'relevancia'
  const minPrice = safeNumericString(getString(searchParams, 'minPrice'))
  const maxPrice = safeNumericString(getString(searchParams, 'maxPrice'))
  const page = getPage(searchParams)

  // Si min > max, ignorar ambos para no devolver resultados vacíos sin explicación
  const [safeMin, safeMax] =
    minPrice && maxPrice && Number(minPrice) > Number(maxPrice)
      ? [undefined, undefined]
      : [minPrice, maxPrice]

  const [{ media, total, pages }, categories] = await Promise.all([
    getCatalog({
      platform,
      categoryId,
      sort,
      page,
      minPrice: safeMin,
      maxPrice: safeMax,
    }),
    getCategories(),
  ])

  const hasPrev = page > 1
  const hasNext = page < pages

  function pageLink(p: number): string {
    const params = new URLSearchParams()
    if (platform) params.set('platform', platform)
    if (categoryId) params.set('categoryId', categoryId)
    if (sort !== 'relevancia') params.set('sort', sort)
    if (safeMin) params.set('minPrice', safeMin)
    if (safeMax) params.set('maxPrice', safeMax)
    params.set('page', String(p))
    return `/marketplace?${params.toString()}`
  }

  const minMaxWarning =
    minPrice && maxPrice && Number(minPrice) > Number(maxPrice)

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Encabezado */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Marketplace</h1>
        <p className="text-[#94A3B8] text-sm mt-1">
          Encontrá medios para publicitar tu marca
        </p>
      </div>

      <div className="flex gap-6 flex-col lg:flex-row">
        {/* Filtros — Suspense requerido porque MediaFilters usa useSearchParams */}
        <Suspense fallback={<div className="w-64 h-80 bg-[#0F172A] border border-[#1E293B] rounded-xl animate-pulse" />}>
          <MediaFilters
            categories={categories}
            currentPlatform={platform ?? ''}
            currentCategoryId={categoryId ?? ''}
            currentSort={sort}
            currentMinPrice={minPrice ?? ''}
            currentMaxPrice={maxPrice ?? ''}
            minMaxError={!!minMaxWarning}
          />
        </Suspense>

        {/* Contenido */}
        <div className="flex-1 min-w-0">
          {/* Contador de resultados */}
          <p className="text-[#64748B] text-sm mb-4">
            {total === 0
              ? 'No se encontraron medios'
              : `${total} ${total === 1 ? 'medio' : 'medios'} encontrados`}
          </p>

          {/* Grid */}
          {media.length === 0 ? (
            <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-8 text-center">
              <p className="text-[#94A3B8]">
                No hay medios disponibles con los filtros seleccionados.
              </p>
              <a href="/marketplace" className="text-[#60A5FA] text-sm mt-3 inline-block hover:underline">
                Ver todos los medios
              </a>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {media.map((medium: MediaCardData) => (
                <MediaCard key={medium.id} medium={medium} />
              ))}
            </div>
          )}

          {/* Paginación */}
          {pages > 1 && (
            <nav aria-label="Paginación" className="flex items-center justify-between mt-6">
              {hasPrev ? (
                <a
                  href={pageLink(page - 1)}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E293B] text-white hover:bg-[#334155] transition-colors"
                >
                  ← Anterior
                </a>
              ) : (
                <span className="px-4 py-2 rounded-lg text-sm font-medium bg-[#0F172A] text-[#475569] select-none">
                  ← Anterior
                </span>
              )}
              <span className="text-[#64748B] text-sm">
                Página {page} de {pages}
              </span>
              {hasNext ? (
                <a
                  href={pageLink(page + 1)}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1E293B] text-white hover:bg-[#334155] transition-colors"
                >
                  Siguiente →
                </a>
              ) : (
                <span className="px-4 py-2 rounded-lg text-sm font-medium bg-[#0F172A] text-[#475569] select-none">
                  Siguiente →
                </span>
              )}
            </nav>
          )}
        </div>
      </div>
    </div>
  )
}
