import type { DeliverableStatus, DeliverableType, Plan, StageStatus } from '@qautiva/db'

// ── Plan ───────────────────────────────────────────────────────────────────────

export const PLAN_BADGE: Record<Plan, { label: string; className: string }> = {
  BASE:     { label: 'Base',     className: 'bg-[#1E293B] text-[#64748B] border border-[#334155]' },
  COMPLETO: { label: 'Completo', className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  PREMIUM:  { label: 'Premium',  className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
}

// ── Stage ──────────────────────────────────────────────────────────────────────

export const STAGE_STATUS_BADGE: Record<StageStatus, { label: string; className: string; pulse?: boolean }> = {
  PENDING:       { label: 'Pendiente',       className: 'bg-[#1E293B] text-[#64748B]' },
  IN_PROGRESS:   { label: 'En progreso',     className: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30' },
  ADMIN_REVIEW:  { label: 'Espera revisión', className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30', pulse: true },
  CLIENT_REVIEW: { label: 'Espera cliente',  className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  REVISION:      { label: 'Revisión',        className: 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30' },
  COMPLETED:     { label: 'Completada',      className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  FAILED:        { label: 'Fallida',         className: 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30' },
}

// ── Deliverable ────────────────────────────────────────────────────────────────

export const DELIVERABLE_STATUS_BADGE: Record<DeliverableStatus, { label: string; className: string }> = {
  DRAFT:              { label: 'Borrador',     className: 'bg-[#1E293B] text-[#64748B]' },
  ADMIN_APPROVED:     { label: 'Admin aprobó', className: 'bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30' },
  SENT_TO_CLIENT:     { label: 'Enviado',      className: 'bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30' },
  CLIENT_APPROVED:    { label: 'Aprobado',     className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  REVISION_REQUESTED: { label: 'Pide cambios', className: 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30' },
  REGENERATING:       { label: 'Regenerando',  className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  GENERATING:         { label: 'Generando',    className: 'bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/30' },
  READY:              { label: 'Listo',         className: 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30' },
  FAILED:             { label: 'Fallido',       className: 'bg-[#EF4444]/15 text-[#F87171] border border-[#EF4444]/30' },
}

export const DELIVERABLE_TYPE_LABEL: Record<DeliverableType, string> = {
  BRIEF:           'Brief',
  MARKET_STUDY:    'Estudio de mercado',
  BRAND_MANUAL:    'Manual de marca',
  BRAND_OPTIONS:   'Opciones de marca',
  WEBSITE_PREVIEW: 'Preview web',
  CAMPAIGN_PLAN:   'Plan de campañas',
  AD_CREATIVES:    'Piezas publicitarias',
  AD_VISUALS:      'Piezas gráficas',
  MEDIA_ARTICLES:  'Artículos de medios',
}
