import { NextResponse, type NextRequest } from 'next/server'
import { prisma } from '@qautiva/db'
import { getProfileOrUnauthorized } from '@/lib/api/marketplace-helpers'

async function getTeamId(profileId: string): Promise<string | null> {
  const userProfile = await prisma.userProfile.findUnique({
    where: { id: profileId },
    select: {
      teamMemberships: {
        select: { teamId: true },
        orderBy: { createdAt: 'asc' },
      },
    },
  })
  return userProfile?.teamMemberships[0]?.teamId ?? null
}

/**
 * GET /api/domains/[id]
 *
 * Retorna el detalle de un dominio, incluyendo las últimas 10 transacciones.
 * Verifica ownership: el dominio debe pertenecer al team del usuario autenticado.
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } },
) {
  const authResult = await getProfileOrUnauthorized()
  if (authResult.unauthorized) return authResult.response
  const { profile } = authResult

  const teamId = await getTeamId(profile.id)
  if (!teamId) {
    return NextResponse.json({ error: 'No se encontró el team del usuario' }, { status: 404 })
  }

  const domain = await prisma.domain.findFirst({
    where: { id: params.id, teamId, deletedAt: null },
    select: {
      id: true,
      domainName: true,
      tld: true,
      status: true,
      period: true,
      costUsd: true,
      paidAmountArs: true,
      exchangeRate: true,
      registrantInfo: true,
      opensrsOrderId: true,
      opensrsDomainId: true,
      registeredAt: true,
      expiresAt: true,
      autoRenew: true,
      whoisPrivacy: true,
      lastError: true,
      retryCount: true,
      createdAt: true,
      transactions: {
        select: {
          id: true,
          operation: true,
          status: true,
          responseCode: true,
          responseText: true,
          durationMs: true,
          errorMessage: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      },
    },
  })

  if (!domain) {
    return NextResponse.json({ error: 'Dominio no encontrado' }, { status: 404 })
  }

  const serialized = {
    ...domain,
    costUsd: domain.costUsd?.toString() ?? null,
    paidAmountArs: domain.paidAmountArs?.toString() ?? null,
    exchangeRate: domain.exchangeRate?.toString() ?? null,
  }

  return NextResponse.json({ domain: serialized })
}
