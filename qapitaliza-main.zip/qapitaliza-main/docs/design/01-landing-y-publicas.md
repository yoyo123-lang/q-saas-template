# Prompts para Gemini — Páginas públicas

> Cada prompt es autocontenido. Copiá y pegá uno a la vez en Gemini.

---

## PROMPT 1: Landing Page (`/`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales (sitios web, dominios, MVPs, proyectos digitales). Es parte del ecosistema Q Company.

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A (negro azulado profundo)
- Fondo cards: #0F172A (navy oscuro)
- Fondo hover/inputs: #1E293B (navy medio)
- Acento primario: #F59E0B (amber/dorado) — CTAs, badges, elementos destacados
- Acento hover: #FBBF24 (amber claro)
- Glow sutil: rgba(245, 158, 11, 0.15)
- Texto primario: #F8FAFC (blanco suave)
- Texto secundario: #94A3B8 (gris azulado)
- Texto apagado: #64748B
- Bordes: #1E293B
- Success: #10B981 | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans (Google Fonts). Pesos: 400 body, 500 emphasis, 600 headings, 700 hero/display.
Mono: JetBrains Mono (para tech stacks).

Bordes: Cards rounded 12px. Buttons rounded 8px. Badges rounded full.

Logo: cuadrado con esquinas redondeadas 8px, fondo #F59E0B, letra "Q" en #0B0F1A bold. Al lado texto "qapitaliza" en #F8FAFC.

Idioma: español argentino (vos, "Explorá", "Descubrí", "Invertí").

PÁGINA: Landing page principal

ESTRUCTURA (de arriba a abajo):

1. NAVBAR (fijo arriba)
   - Fondo: #0B0F1A con blur sutil, borde inferior 1px #1E293B
   - Izquierda: logo Q amber + "qapitaliza"
   - Centro: links de navegación en #94A3B8 — "Explorar", "Cómo funciona", "Categorías"
   - Derecha: botón "Iniciar sesión" (outline amber) + botón "Registrate" (sólido amber con texto oscuro)

2. HERO SECTION (altura ~70vh)
   - Fondo: #0B0F1A con un radial gradient circular muy sutil de amber al 8% de opacidad, centrado, con efecto de movimiento lento (mesh gradient)
   - Título grande (48px bold, #F8FAFC): "Comprá, vendé e invertí en activos digitales"
   - Subtítulo (18px, #94A3B8, max-width 600px centrado): "El marketplace donde emprendedores compran y venden sitios web, dominios, MVPs y proyectos digitales con métricas verificadas"
   - Barra de búsqueda grande centrada: fondo #0F172A, borde #1E293B, placeholder "Buscá sitios web, dominios, SaaS...", ícono de lupa, botón "Explorar" amber a la derecha
   - Debajo de la barra: 3 stats en línea con texto #64748B — "127 activos listados" · "$2.4M en transacciones" · "340+ emprendedores"

3. CATEGORÍAS (sección)
   - Heading: "Categorías" en 12px uppercase tracking-wider #64748B
   - 5 cards horizontales con ícono, nombre y cantidad:
     - 🌐 Sitios Web (42) | 🔗 Dominios (28) | 💻 SaaS / MVPs (31) | 🛒 E-commerce (18) | 📁 Proyectos (8)
   - Cards: fondo #0F172A, borde #1E293B, rounded 12px, hover con borde amber sutil

4. ACTIVOS DESTACADOS (sección principal)
   - Heading: "Activos destacados" + link "Ver todos →" en amber
   - Grilla 3 columnas de ListingCards:

   Card 1: "CryptoAlerts.io" — SaaS — $18,000 USD — badge "Verificado" en verde — métricas: "$2,100 MRR" y "1.2k usuarios" — tech: Next.js, Stripe — screenshot de la app
   Card 2: "DevTools.pro" — Herramienta Dev — $32,000 USD — badge "Destacado" en amber — métricas: "$4,800 MRR" y "3.4k usuarios" — tech: React, Node.js
   Card 3: "RecetasVegan.ar" — Sitio Web — $4,500 USD — métricas: "12k visitas/mes" y "DA 34" — tech: WordPress
   Card 4: "TuMascota.shop" — E-commerce — $7,200 USD — badge "Verificado" en verde — métricas: "340 orders/mes" y "$8.2k revenue" — tech: Shopify
   Card 5: "Viajeros.com.ar" — Dominio Premium — $15,000 USD — badge "Premium" en amber — métricas: "DA 52" y "Registrado en 2008"
   Card 6: "FitnessPlan.app" — MVP — $2,800 USD — métricas: "1,200 usuarios" y "3 meses online" — tech: React Native

   Cada card: fondo #0F172A, borde #1E293B, rounded 12px, hover con shadow y borde amber al 30%. Arriba screenshot/placeholder. Precio grande en #F8FAFC. Tipo como badge pill. Métricas en #94A3B8 con íconos pequeños. Tech stack como pills pequeñas en font mono.

5. CÓMO FUNCIONA (sección)
   - Heading: "Cómo funciona"
   - 3 columnas con número grande amber (01, 02, 03), título en blanco, descripción en #94A3B8:
     - 01: "Publicá tu activo" — "Listá tu sitio web, dominio o proyecto con métricas verificables"
     - 02: "Recibí consultas" — "Los compradores interesados te contactan a través de la plataforma"
     - 03: "Cerrá la venta" — "Coordiná la transferencia de forma segura con nuestro soporte"

6. CTA FINAL
   - Fondo con gradiente sutil amber al 5% — "¿Tenés un activo digital para vender?" — Botón "Publicá gratis" en amber

7. FOOTER
   - Fondo #0B0F1A, borde top 1px #1E293B
   - Logo + "Parte del ecosistema Q Company"
   - Columnas: Producto (Explorar, Categorías, Precios) | Empresa (Sobre nosotros, Blog, Contacto) | Legal (Términos, Privacidad)
   - Abajo: "© 2026 Qapitaliza" en #64748B
```

---

## PROMPT 2: Catálogo / Explorar (`/explorar`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales (sitios web, dominios, MVPs, proyectos digitales).

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A (negro azulado profundo)
- Fondo cards: #0F172A (navy oscuro)
- Fondo hover/inputs: #1E293B (navy medio)
- Acento primario: #F59E0B (amber/dorado)
- Acento hover: #FBBF24
- Texto primario: #F8FAFC | Texto secundario: #94A3B8 | Texto apagado: #64748B
- Bordes: #1E293B
- Success: #10B981 | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans. Pesos: 400, 500, 600, 700. Mono: JetBrains Mono.
Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" oscuro + "qapitaliza" en blanco.
Idioma: español argentino.

PÁGINA: Catálogo de activos — página de exploración con filtros

ESTRUCTURA:

1. NAVBAR (igual que landing — logo, links, botones auth)

2. HEADER DE PÁGINA
   - Fondo #0B0F1A
   - Título: "Explorar activos" (32px semibold #F8FAFC)
   - Subtítulo: "Encontrá tu próxima inversión digital" (#94A3B8)
   - Barra de búsqueda ancha: fondo #0F172A, borde #1E293B, placeholder "Buscá por nombre, tecnología, categoría..."

3. CONTENIDO PRINCIPAL — layout 2 columnas (sidebar filtros 280px + grilla)

   SIDEBAR FILTROS (izquierda, 280px):
   - Fondo: #0F172A, borde derecho #1E293B, rounded 12px, padding 20px
   - Sección "Categoría": checkboxes — Sitios Web (42), Dominios (28), SaaS/MVPs (31), E-commerce (18), Proyectos (8)
   - Sección "Rango de precio": 2 inputs (Mínimo / Máximo) en USD, fondo #1E293B
   - Sección "Revenue mensual": dropdown — Cualquiera, > $500, > $1,000, > $5,000
   - Sección "Verificación": toggle — Solo verificados
   - Sección "Tech Stack": pills seleccionables — React, Next.js, WordPress, Shopify, Node.js, Python, Laravel
   - Botón "Limpiar filtros" en #64748B, pequeño

   GRILLA DE RESULTADOS (derecha):
   - Barra superior: "127 resultados" (#94A3B8) + dropdown "Ordenar por: Más recientes ▾"
   - Grilla 3 columnas de ListingCards (mismo estilo que landing):

   Row 1:
   - "CryptoAlerts.io" — SaaS — $18,000 USD — badge verde "Verificado" — $2,100 MRR — 1.2k usuarios — Next.js, Stripe
   - "DevTools.pro" — Herramienta — $32,000 USD — badge amber "Destacado" — $4,800 MRR — React, Node.js
   - "RecetasVegan.ar" — Sitio Web — $4,500 USD — 12k visitas/mes — DA 34 — WordPress

   Row 2:
   - "TuMascota.shop" — E-commerce — $7,200 USD — badge verde "Verificado" — 340 orders/mes — Shopify
   - "Viajeros.com.ar" — Dominio — $15,000 USD — badge amber "Premium" — DA 52 — Reg. 2008
   - "FitnessPlan.app" — MVP — $2,800 USD — 1,200 usuarios — React Native

   Row 3:
   - "MiContador.ar" — SaaS — $9,500 USD — $890 MRR — Laravel, Vue
   - "NotiTech.com" — Sitio Web — $6,200 USD — 28k visitas/mes — DA 41 — Ghost
   - "Streaming.lat" — Dominio — $22,000 USD — DA 38 — Reg. 2015

   - Paginación abajo: « 1 2 3 4 5 ... 14 » (botones rounded, activo en amber)

4. Sin footer visible (scroll infinito o paginación)
```

---

## PROMPT 3: Detalle del activo (`/explorar/[slug]`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A | Fondo cards: #0F172A | Fondo hover: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24
- Texto: #F8FAFC (primario), #94A3B8 (secundario), #64748B (apagado)
- Bordes: #1E293B | Success: #10B981 | Error: #EF4444 | Info: #3B82F6

Tipografía: DM Sans (400, 500, 600, 700). Mono: JetBrains Mono.
Cards: rounded 12px. Buttons: rounded 8px. Badges: rounded full.
Logo: cuadrado amber con "Q" + "qapitaliza". Idioma: español argentino.

PÁGINA: Detalle de un activo digital — "CryptoAlerts.io"

ESTRUCTURA:

1. NAVBAR (logo + links + auth)

2. BREADCRUMB
   - "Explorar > SaaS / MVPs > CryptoAlerts.io" en #64748B, links en #94A3B8

3. CONTENIDO PRINCIPAL — 2 columnas (contenido 65% + sidebar 35%)

   COLUMNA IZQUIERDA (contenido principal):

   a) HEADER DEL ACTIVO
   - Título: "CryptoAlerts.io" (32px semibold #F8FAFC)
   - Badges en línea: "SaaS" (pill #3B82F6 al 15%), "Verificado" (pill #10B981 al 15% con ícono ✓), "Destacado" (pill amber)
   - Texto: "Publicado hace 5 días por Martín R." en #64748B
   - Precio grande: "$18,000 USD" (28px bold #F59E0B)

   b) SCREENSHOT/PREVIEW
   - Imagen grande del sitio (placeholder de una app SaaS oscura con gráficos), fondo #0F172A, borde #1E293B, rounded 12px
   - Galería de thumbnails abajo (3-4 screenshots más pequeñas)

   c) DESCRIPCIÓN
   - Heading "Descripción" (16px semibold)
   - Texto (14px #94A3B8, interlineado 1.6):
     "Plataforma SaaS de alertas de criptomonedas en tiempo real. Los usuarios configuran alertas de precio para cualquier criptomoneda y reciben notificaciones por email, Telegram y push. Incluye dashboard con gráficos históricos, integración con 5 exchanges (Binance, Coinbase, Kraken, Bitfinex, KuCoin), y sistema de suscripción mensual con 3 planes."
   - "El proyecto tiene 14 meses de operación, crecimiento orgánico sostenido, y churn rate del 4.2% mensual. Se vende por falta de tiempo para mantenerlo."

   d) TECH STACK
   - Heading "Stack tecnológico"
   - Pills en font mono JetBrains: Next.js | TypeScript | PostgreSQL | Redis | Stripe | Vercel | Tailwind CSS
   - Cada pill: fondo #1E293B, texto #F8FAFC, rounded full, padding 4px 12px

   e) MÉTRICAS DETALLADAS
   - Heading "Métricas"
   - Grilla 2x3 de stat cards (fondo #0F172A, borde #1E293B, rounded 12px):
     - Revenue mensual: $2,100 (con ícono 📈, label "MRR", trend "+12% vs mes anterior" en verde)
     - Usuarios activos: 1,247 (ícono 👥, label "MAU")
     - Tráfico mensual: 8,400 (ícono 📊, label "visitas/mes")
     - Churn rate: 4.2% (ícono 📉, label "mensual")
     - Domain Authority: 28 (ícono 🔗, label "DA Moz")
     - Edad: 14 meses (ícono 📅, label "online")
   - Nota: "Métricas verificadas por Qapitaliza ✓" en #10B981

   COLUMNA DERECHA (sidebar sticky):

   a) CARD DE ACCIÓN (fondo #0F172A, borde #1E293B, rounded 12px, padding 24px)
   - Precio: "$18,000 USD" (24px bold amber)
   - Botón grande: "Consultar al vendedor" (fondo amber, texto oscuro, full width, rounded 8px)
   - Botón secundario: "♡ Guardar en favoritos" (outline amber, full width)
   - Divider line #1E293B
   - Info del vendedor:
     - Avatar circular placeholder + "Martín Rodríguez"
     - "Vendedor verificado ✓" en #10B981
     - "12 activos listados · Miembro desde 2025"
     - Link "Ver perfil →" en amber

   b) CARD DE SEGURIDAD (fondo #0F172A con borde amber al 20%, rounded 12px)
   - "🔒 Transacción segura"
   - 3 items con check verde: "Métricas verificadas", "Vendedor verificado", "Soporte Qapitaliza"

4. ACTIVOS RELACIONADOS (abajo, full width)
   - Heading: "Activos similares"
   - 3 ListingCards horizontales (mismos estilos de siempre): FitnessPlan.app, MiContador.ar, NotiTech.com

5. FOOTER
```

---

## PROMPT 4: Cómo funciona (`/como-funciona`)

```
Generá un diseño UI de alta fidelidad para esta página web. Mostrá la página completa renderizada como se vería en un navegador a 1440px de ancho. No incluyas wireframes ni esquemas — quiero ver el diseño final con colores, tipografía y contenido real.

PRODUCTO: Qapitaliza — marketplace de activos digitales.

SISTEMA DE DISEÑO:

Paleta:
- Fondo principal: #0B0F1A | Fondo cards: #0F172A | Fondo hover: #1E293B
- Acento: #F59E0B (amber) | Hover: #FBBF24
- Texto: #F8FAFC (primario), #94A3B8 (secundario), #64748B (apagado)
- Bordes: #1E293B | Success: #10B981

Tipografía: DM Sans (400, 500, 600, 700). Cards: rounded 12px. Buttons: rounded 8px.
Logo: cuadrado amber con "Q" + "qapitaliza". Idioma: español argentino.

PÁGINA: "Cómo funciona" — página explicativa del marketplace

ESTRUCTURA:

1. NAVBAR (logo + links + auth)

2. HERO
   - Fondo #0B0F1A con glow amber sutil centrado
   - Título: "Cómo funciona Qapitaliza" (40px bold #F8FAFC)
   - Subtítulo: "Comprá y vendé activos digitales de forma simple y segura" (#94A3B8)

3. SECCIÓN VENDEDORES — "Para vendedores"
   - Heading con badge amber "Vendedores"
   - 4 pasos verticales con línea conectora (timeline vertical, línea #1E293B, dots amber):

   Paso 1: "Registrate gratis"
   - Ícono amber grande (user-plus)
   - "Creá tu cuenta en 30 segundos con email o Google"

   Paso 2: "Publicá tu activo"
   - Ícono amber (upload)
   - "Completá la ficha con descripción, métricas, screenshots y precio. Nuestro equipo lo revisa en menos de 24hs."

   Paso 3: "Recibí consultas"
   - Ícono amber (message-circle)
   - "Los compradores interesados te contactan a través de la plataforma. Respondé a tu ritmo."

   Paso 4: "Cerrá la venta"
   - Ícono amber (handshake)
   - "Coordiná la transferencia del activo. Qapitaliza te acompaña en todo el proceso."

4. SECCIÓN COMPRADORES — "Para compradores"
   - Misma estructura timeline pero con 3 pasos:

   Paso 1: "Explorá el catálogo"
   - "Filtrá por categoría, precio, revenue, tech stack. Todos los activos tienen métricas verificadas."

   Paso 2: "Consultá al vendedor"
   - "Hacé preguntas, pedí más datos, negociá. Todo queda registrado en la plataforma."

   Paso 3: "Adquirí tu activo"
   - "Cerrá el trato con soporte de Qapitaliza. Recibí todos los accesos y documentación."

5. SECCIÓN VERIFICACIÓN — "Métricas verificadas"
   - Card grande centrada (fondo #0F172A, borde amber al 20%)
   - 3 columnas con ícono check verde:
     - "Revenue verificado" — "Validamos los ingresos con capturas de analytics y pasarelas de pago"
     - "Tráfico real" — "Verificamos el tráfico con Google Analytics y herramientas SEO"
     - "Tech stack auditado" — "Revisamos la infraestructura y dependencias del proyecto"

6. FAQ — "Preguntas frecuentes"
   - 6 preguntas en acordeón (fondo #0F172A, borde #1E293B, rounded 12px):
     - "¿Cuánto cuesta publicar un activo?"
     - "¿Qué tipos de activos puedo vender?"
     - "¿Cómo verifican las métricas?"
     - "¿Cuánto tarda en venderse un activo?"
     - "¿Qué pasa si el comprador no está conforme?"
     - "¿Puedo listar activos en pesos argentinos?"

7. CTA FINAL
   - "¿Listo para empezar?" — Dos botones: "Publicá tu activo" (amber sólido) + "Explorá el catálogo" (outline amber)

8. FOOTER
```
