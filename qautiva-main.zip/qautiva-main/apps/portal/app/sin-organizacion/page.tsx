export default function SinOrganizacionPage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-[#0B0F1A] px-4">
      <div className="max-w-md w-full text-center">
        <h1 className="text-2xl font-bold text-white mb-4">Cuenta sin proyecto asignado</h1>
        <p className="text-[#94A3B8] text-sm leading-relaxed mb-6">
          Tu cuenta todavía no está vinculada a ningún proyecto. Para acceder al portal,
          necesitás que el equipo de qautiva active tu acceso.
        </p>
        <p className="text-[#64748B] text-xs">
          Si creés que esto es un error, escribinos a{' '}
          <a
            href="mailto:hola@qautiva.ar"
            className="text-[#8B5CF6] hover:underline"
          >
            hola@qautiva.ar
          </a>
        </p>
      </div>
    </main>
  )
}
