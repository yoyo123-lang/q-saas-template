import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const { id } = params

  // Verificar ownership vía team membership
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    include: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m) => m.teamId)

  const deliverable = await prisma.deliverable.findFirst({
    where: { id, teamId: { in: teamIds } },
    select: { id: true },
  })

  if (!deliverable) {
    return NextResponse.json({ error: 'Entregable no encontrado' }, { status: 404 })
  }

  const now = Date.now()
  const [totalViews, last7Days, last30Days] = await Promise.all([
    prisma.deliverableView.count({ where: { deliverableId: id } }),
    prisma.deliverableView.count({
      where: {
        deliverableId: id,
        viewedAt: { gte: new Date(now - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
    prisma.deliverableView.count({
      where: {
        deliverableId: id,
        viewedAt: { gte: new Date(now - 30 * 24 * 60 * 60 * 1000) },
      },
    }),
  ])

  return NextResponse.json({ totalViews, last7Days, last30Days })
}
