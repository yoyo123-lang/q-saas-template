/** Metadatos del archivo seleccionado. El contenido binario se procesa en B2. */
export type FileAnswer = {
  name: string
  size: number
  mimeType: string
}

export type BudgetAnswer = {
  min: number | null
  max: number | null
}
