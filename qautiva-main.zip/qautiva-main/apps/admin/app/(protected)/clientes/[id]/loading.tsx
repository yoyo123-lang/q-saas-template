function SkeletonBlock({ className }: { className?: string }) {
  return <div className={`bg-[#1E293B] rounded-lg animate-pulse ${className ?? ''}`} />
}

export default function ClienteLoading() {
  return (
    <div className="flex flex-col h-full p-6 gap-5">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 rounded-xl bg-[#0F172A] border border-[#1E293B]">
        <SkeletonBlock className="h-14 w-14 rounded-full flex-shrink-0" />
        <div className="flex flex-col gap-2 flex-1">
          <SkeletonBlock className="h-6 w-48" />
          <div className="flex gap-2">
            <SkeletonBlock className="h-5 w-20 rounded-full" />
            <SkeletonBlock className="h-5 w-24 rounded-full" />
            <SkeletonBlock className="h-5 w-16 rounded-full" />
          </div>
        </div>
        <SkeletonBlock className="h-9 w-28 rounded-lg ml-auto" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1">
        {Array.from({ length: 4 }).map((_, i) => (
          <SkeletonBlock key={i} className="h-9 w-28 rounded-lg" />
        ))}
      </div>

      {/* Content */}
      <div className="flex flex-col gap-3 flex-1">
        {Array.from({ length: 3 }).map((_, i) => (
          <SkeletonBlock key={i} className="h-24 w-full rounded-xl" />
        ))}
      </div>
    </div>
  )
}
