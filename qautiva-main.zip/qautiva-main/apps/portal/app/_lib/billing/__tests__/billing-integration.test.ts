/**
 * Test de integración de billing: simula una generación completa
 * y verifica que TokenUsage se crea con costUsd > 0, feeUsd >= 0,
 * totalUsd > 0, y que trialTokensUsed se incrementó.
 *
 * Estrategia: mocks de prisma y de las llamadas a AI (executeToolCall ya integrado).
 * Verifica el flujo completo: recordTokenUsage → updateBillingConsumption.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockAiModelPricingFindUnique = vi.fn()
const mockBillingAccountFindUnique = vi.fn()
const mockFeeConfigFindFirst = vi.fn()
const mockTokenUsageCreate = vi.fn()
const mockBillingAccountUpdate = vi.fn()

vi.mock('@qautiva/db', () => ({
  prisma: {
    aiModelPricing: { findUnique: mockAiModelPricingFindUnique },
    billingAccount: {
      findUnique: mockBillingAccountFindUnique,
      update: mockBillingAccountUpdate,
    },
    feeConfig: { findFirst: mockFeeConfigFindFirst },
    tokenUsage: { create: mockTokenUsageCreate },
    $transaction: vi.fn().mockImplementation(async (fn) =>
      fn({
        tokenUsage: { create: mockTokenUsageCreate },
        billingAccount: { update: mockBillingAccountUpdate },
      }),
    ),
  },
  UsageSource: { TRIAL: 'TRIAL', BYOK: 'BYOK', QAUTIVA_HOSTED: 'QAUTIVA_HOSTED' },
  AiProvider: { ANTHROPIC: 'ANTHROPIC', OPENAI: 'OPENAI', GOOGLE_GEMINI: 'GOOGLE_GEMINI' },
  BillingPlan: { FREE_TRIAL: 'FREE_TRIAL', PREPAID: 'PREPAID', MONTHLY: 'MONTHLY', YEARLY: 'YEARLY' },
  ApiKeySource: { BYOK: 'BYOK', QAUTIVA_HOSTED: 'QAUTIVA_HOSTED' },
}))

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('Billing Integration — flujo completo', () => {
  beforeEach(() => {
    mockAiModelPricingFindUnique.mockReset()
    mockBillingAccountFindUnique.mockReset()
    mockFeeConfigFindFirst.mockReset()
    mockTokenUsageCreate.mockReset()
    mockBillingAccountUpdate.mockReset()
  })

  it('generación con plan TRIAL: TokenUsage con costUsd > 0 y trialTokensUsed incrementado', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce({
      inputPer1M: { toNumber: () => 3.0 },
      outputPer1M: { toNumber: () => 15.0 },
    })
    mockBillingAccountFindUnique.mockResolvedValueOnce({
      plan: 'FREE_TRIAL',
      preferredKeySource: 'QAUTIVA_HOSTED',
    })
    mockFeeConfigFindFirst.mockResolvedValueOnce({
      feePercentage: { toNumber: () => 20.0 },
    })
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-integration-1' })
    mockBillingAccountUpdate.mockResolvedValueOnce({ id: 'ba-1' })

    await registerAiUsage({
      teamId: 'team-integration',
      projectId: 'proj-integration',
      provider: 'ANTHROPIC',
      model: 'claude-3-5-sonnet-20241022',
      operation: 'brief_generation',
      source: 'TRIAL',
      tokensIn: 2000,
      tokensOut: 800,
    })

    // Verifica que TokenUsage se creó
    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    const tokenUsageData = mockTokenUsageCreate.mock.calls[0][0].data

    // costUsd = 2000 * 3.0/1M + 800 * 15.0/1M = 0.006 + 0.012 = 0.018
    expect(Number(tokenUsageData.costUsd)).toBeGreaterThan(0)
    expect(Number(tokenUsageData.costUsd)).toBeCloseTo(0.018, 6)

    // feeUsd = 0.018 * 20/100 = 0.0036
    expect(Number(tokenUsageData.feeUsd)).toBeGreaterThanOrEqual(0)
    expect(Number(tokenUsageData.feeUsd)).toBeCloseTo(0.0036, 6)

    // totalUsd > 0
    expect(Number(tokenUsageData.totalUsd)).toBeGreaterThan(0)
    expect(Number(tokenUsageData.totalUsd)).toBeCloseTo(0.0216, 6)

    // Verifica que trialTokensUsed se incrementó
    expect(mockBillingAccountUpdate).toHaveBeenCalledOnce()
    const updateData = mockBillingAccountUpdate.mock.calls[0][0].data
    expect(updateData.trialTokensUsed).toEqual({ increment: 2800 }) // 2000 + 800
  })

  it('generación con plan PREPAID (QAUTIVA_HOSTED): balanceUsd decrementado', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce({
      inputPer1M: { toNumber: () => 3.0 },
      outputPer1M: { toNumber: () => 15.0 },
    })
    mockBillingAccountFindUnique.mockResolvedValue({
      plan: 'PREPAID',
      preferredKeySource: 'QAUTIVA_HOSTED',
    })
    mockFeeConfigFindFirst.mockResolvedValueOnce({
      feePercentage: { toNumber: () => 15.0 },
    })
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-integration-2' })
    mockBillingAccountUpdate.mockResolvedValueOnce({ id: 'ba-2' })

    await registerAiUsage({
      teamId: 'team-prepaid',
      projectId: 'proj-integration',
      provider: 'ANTHROPIC',
      model: 'claude-3-5-sonnet-20241022',
      operation: 'market_study',
      source: 'QAUTIVA_HOSTED',
      tokensIn: 5000,
      tokensOut: 3000,
    })

    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    expect(mockBillingAccountUpdate).toHaveBeenCalledOnce()
    const updateData = mockBillingAccountUpdate.mock.calls[0][0].data
    // balanceUsd decrementado, no trialTokensUsed
    expect(updateData.balanceUsd).toEqual({ decrement: expect.any(Number) })
    expect(updateData.trialTokensUsed).toBeUndefined()
  })

  it('tokens OpenAI con usage=null: registra tokensIn=0, tokensOut=0 sin fallar', async () => {
    // Simula el caso donde OpenAI no retorna usage (ej: error parcial o modelo nuevo)
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce({
      inputPer1M: { toNumber: () => 3.0 },
      outputPer1M: { toNumber: () => 15.0 },
    })
    mockBillingAccountFindUnique.mockResolvedValue({
      plan: 'PREPAID',
      preferredKeySource: 'QAUTIVA_HOSTED',
    })
    mockFeeConfigFindFirst.mockResolvedValueOnce({
      feePercentage: { toNumber: () => 15.0 },
    })
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-integration-null' })
    mockBillingAccountUpdate.mockResolvedValueOnce({ id: 'ba-3' })

    // tokensIn=0, tokensOut=0 simula el ?? 0 fallback en ai-tool-call
    await registerAiUsage({
      teamId: 'team-openai-null',
      projectId: 'proj-integration',
      provider: 'OPENAI',
      model: 'gpt-4o',
      operation: 'website_copy',
      source: 'QAUTIVA_HOSTED',
      tokensIn: 0,
      tokensOut: 0,
    })

    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    const tokenUsageData = mockTokenUsageCreate.mock.calls[0][0].data
    expect(tokenUsageData.tokensIn).toBe(0)
    expect(tokenUsageData.tokensOut).toBe(0)
    // costUsd = 0, totalUsd = 0
    expect(Number(tokenUsageData.costUsd)).toBe(0)
    expect(Number(tokenUsageData.totalUsd)).toBe(0)
  })

  it('generación con BYOK: TokenUsage se crea pero BillingAccount no se modifica', async () => {
    const { registerAiUsage } = await import('../register-ai-usage')

    mockAiModelPricingFindUnique.mockResolvedValueOnce({
      inputPer1M: { toNumber: () => 3.0 },
      outputPer1M: { toNumber: () => 15.0 },
    })
    mockBillingAccountFindUnique.mockResolvedValue({
      plan: 'PREPAID',
      preferredKeySource: 'BYOK',
    })
    mockFeeConfigFindFirst.mockResolvedValueOnce({
      feePercentage: { toNumber: () => 0 },
    })
    mockTokenUsageCreate.mockResolvedValueOnce({ id: 'tu-integration-3' })

    await registerAiUsage({
      teamId: 'team-byok',
      projectId: 'proj-integration',
      provider: 'OPENAI',
      model: 'gpt-4o',
      operation: 'brand_concepts',
      source: 'BYOK',
      tokensIn: 1000,
      tokensOut: 500,
    })

    expect(mockTokenUsageCreate).toHaveBeenCalledOnce()
    // BYOK: no se modifica el BillingAccount
    expect(mockBillingAccountUpdate).not.toHaveBeenCalled()
  })
})
