import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

interface SaveBody {
  templateId: string
  name: string
  description?: string
}

/**
 * POST /api/stitch/generate/save
 *
 * Confirma un draft de Stitch: le asigna nombre y descripción.
 * El template ya fue generado en background por /api/stitch/generate.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  let body: SaveBody
  try {
    body = (await req.json()) as SaveBody
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  const { templateId, name, description } = body

  if (!templateId || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(templateId)) {
    return NextResponse.json({ error: 'templateId inválido' }, { status: 400 })
  }
  if (!name || !name.trim()) {
    return NextResponse.json({ error: 'name es requerido' }, { status: 400 })
  }
  if (name.trim().length > 200) {
    return NextResponse.json({ error: 'name no puede superar 200 caracteres' }, { status: 400 })
  }

  const template = await prisma.webTemplate.findUnique({
    where: { id: templateId },
    select: { id: true, htmlBase: true, generatingAt: true },
  })

  if (!template) {
    return NextResponse.json({ error: 'Template no encontrado' }, { status: 404 })
  }
  if (!template.htmlBase) {
    return NextResponse.json({ error: 'El template aún no fue generado' }, { status: 409 })
  }
  if (template.generatingAt !== null) {
    return NextResponse.json({ error: 'El template aún está generándose' }, { status: 409 })
  }

  try {
    const saved = await prisma.webTemplate.update({
      where: { id: templateId },
      data: {
        name: name.trim(),
        description: description?.trim() || null,
      },
      select: { id: true, name: true },
    })

    return NextResponse.json({ id: saved.id, name: saved.name })
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    if (msg.includes('Unique constraint') || msg.includes('unique')) {
      return NextResponse.json({ error: 'Ya existe un template con ese nombre' }, { status: 409 })
    }
    console.error('[stitch:save] error', msg)
    return NextResponse.json({ error: 'Error al guardar el template' }, { status: 500 })
  }
}
