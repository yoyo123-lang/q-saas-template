import Link from 'next/link'
import { cn } from '@/lib/utils/cn'
import { Badge } from '@/components/ui/badge'
import { AdminListingsTable } from '@/components/admin/admin-listings-table'
import { Pagination } from '@/components/ui/pagination'
import { getAllListings } from '@/lib/data/admin'

const STATUS_TABS = [
  { label: 'Todos', value: 'all' },
  { label: 'Pendientes', value: 'pending', danger: true },
  { label: 'Publicados', value: 'published' },
  { label: 'Destacados', value: 'featured' },
  { label: 'Rechazados', value: 'rejected' },
  { label: 'Vendidos', value: 'sold' },
] as const

const TYPE_OPTIONS = [
  { label: 'Todos los tipos', value: '' },
  { label: 'Sitio web', value: 'WEBSITE' },
  { label: 'Dominio', value: 'DOMAIN' },
  { label: 'SaaS', value: 'SAAS' },
  { label: 'E-commerce', value: 'ECOMMERCE' },
  { label: 'Proyecto', value: 'PROJECT' },
]

const SORT_OPTIONS = [
  { label: 'Más recientes', value: 'newest' },
  { label: 'Más antiguos', value: 'oldest' },
  { label: 'Precio ↑', value: 'price_asc' },
  { label: 'Precio ↓', value: 'price_desc' },
]

const PAGE_SIZE = 20

interface PageProps {
  searchParams: Promise<{
    status?: string
    type?: string
    sort?: string
    q?: string
    page?: string
  }>
}

export default async function AdminListadosPage({ searchParams }: PageProps) {
  const params = await searchParams
  const status = (params.status ?? 'all') as 'all' | 'pending' | 'published' | 'featured' | 'rejected' | 'sold'
  const type = params.type ?? ''
  const sort = (params.sort ?? 'newest') as 'newest' | 'oldest' | 'price_asc' | 'price_desc'
  const q = params.q ?? ''
  const page = Math.max(1, parseInt(params.page ?? '1', 10))

  const listings = await getAllListings({ status, type: type || undefined, sort, q, page, limit: PAGE_SIZE })

  const totalPages = Math.ceil(listings.total / PAGE_SIZE)

  function buildHref(overrides: Record<string, string>) {
    const p = new URLSearchParams({ status, type, sort, q, page: String(page), ...overrides })
    // Clean up empty values
    Array.from(p.entries()).forEach(([k, v]) => { if (!v) p.delete(k) })
    return `/admin/listados?${p.toString()}`
  }

  const tabCounts: Record<string, number> = {
    all: listings.total,
    pending: listings.pendingCount,
    published: listings.publishedCount,
    featured: listings.featuredCount,
    rejected: listings.rejectedCount,
    sold: listings.soldCount,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-50">Moderación de listados</h1>
        <p className="text-slate-400 text-sm mt-0.5">Revisá, aprobá o rechazá los listados del marketplace.</p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-800">
        {STATUS_TABS.map((tab) => {
          const isActive = status === tab.value
          return (
            <Link
              key={tab.value}
              href={buildHref({ status: tab.value, page: '1' })}
              className={cn(
                'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px',
                isActive
                  ? 'border-amber-500 text-amber-500'
                  : 'border-transparent text-slate-400 hover:text-slate-50'
              )}
            >
              {tab.label}
              {tab.value === 'pending' && listings.pendingCount > 0 && (
                <span className="relative flex size-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                  <span className="relative inline-flex rounded-full size-2 bg-red-500" />
                </span>
              )}
              {tabCounts[tab.value] != null && (
                <span
                  className={cn(
                    'text-xs px-1.5 py-0.5 rounded-full font-medium',
                    isActive
                      ? 'bg-amber-500/20 text-amber-500'
                      : 'bg-slate-800 text-slate-400'
                  )}
                >
                  {tabCounts[tab.value]}
                </span>
              )}
            </Link>
          )
        })}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <form method="GET" action="/admin/listados" className="flex-1 flex items-center gap-3">
          <input type="hidden" name="status" value={status} />
          <input
            type="search"
            name="q"
            defaultValue={q}
            placeholder="Buscar por título o vendedor..."
            className="flex-1 max-w-sm bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <select
            name="type"
            defaultValue={type}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            {TYPE_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <select
            name="sort"
            defaultValue={sort}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            {SORT_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <button
            type="submit"
            className="px-4 py-2 bg-amber-500 text-navy-950 text-sm font-medium rounded-lg hover:bg-amber-400 transition-colors"
          >
            Filtrar
          </button>
        </form>
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">
          {listings.total} resultado{listings.total !== 1 ? 's' : ''}
        </p>
        {listings.pendingCount > 0 && (
          <Badge variant="danger" dot>
            {listings.pendingCount} pendiente{listings.pendingCount !== 1 ? 's' : ''}
          </Badge>
        )}
      </div>

      {/* Table */}
      <AdminListingsTable listings={listings.items} />

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center pt-4">
          <nav className="flex items-center gap-1">
            {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => i + 1).map((p) => (
              <Link
                key={p}
                href={buildHref({ page: String(p) })}
                className={cn(
                  'min-w-[36px] h-9 rounded-lg text-sm font-medium flex items-center justify-center transition-colors',
                  p === page
                    ? 'bg-amber-500 text-navy-950'
                    : 'text-slate-400 hover:text-slate-50 hover:bg-slate-800'
                )}
              >
                {p}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </div>
  )
}
