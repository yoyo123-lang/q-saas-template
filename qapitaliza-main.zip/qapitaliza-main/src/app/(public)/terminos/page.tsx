export const metadata = {
  title: 'Términos de uso — Qapitaliza',
  description: 'Términos y condiciones de uso de la plataforma Qapitaliza.',
}

export default function TerminosPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-slate-50 mb-2">Términos de uso</h1>
      <p className="text-sm text-slate-500 mb-10">Última actualización: marzo 2026</p>

      <div className="prose prose-invert prose-slate max-w-none space-y-8 text-slate-300">
        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">1. Aceptación de los términos</h2>
          <p className="leading-relaxed">
            Al acceder y utilizar Qapitaliza, aceptás estos Términos de Uso en su totalidad. Si no estás de acuerdo con alguna parte de estos términos, no podés usar nuestra plataforma.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">2. Descripción del servicio</h2>
          <p className="leading-relaxed">
            Qapitaliza es un marketplace de activos digitales que permite a vendedores publicar sitios web, dominios, SaaS, e-commerce y proyectos digitales, y a compradores explorarlos y realizar consultas. La plataforma actúa como intermediario pero no es parte de las transacciones entre usuarios.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">3. Cuentas de usuario</h2>
          <p className="leading-relaxed">
            Para publicar o consultar activos debés crear una cuenta. Sos responsable de mantener la confidencialidad de tus credenciales y de toda actividad que ocurra bajo tu cuenta. Debés notificarnos inmediatamente si detectás uso no autorizado.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">4. Publicación de activos</h2>
          <p className="leading-relaxed">
            Los vendedores garantizan que tienen los derechos legales para vender los activos publicados y que la información proporcionada es verdadera y precisa. Qapitaliza se reserva el derecho de rechazar o eliminar publicaciones que no cumplan con nuestras políticas.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">5. Responsabilidad</h2>
          <p className="leading-relaxed">
            Qapitaliza no garantiza la exactitud de la información publicada por los usuarios, ni es responsable por transacciones que ocurran fuera de la plataforma. Recomendamos realizar la debida diligencia antes de cualquier operación.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">6. Modificaciones</h2>
          <p className="leading-relaxed">
            Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios entran en vigencia al publicarse en esta página. El uso continuo de la plataforma implica la aceptación de los nuevos términos.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-slate-50 mb-3">7. Contacto</h2>
          <p className="leading-relaxed">
            Si tenés preguntas sobre estos términos, escribinos a{' '}
            <span className="text-amber-500">legal@qapitaliza.com</span>.
          </p>
        </section>
      </div>
    </div>
  )
}
