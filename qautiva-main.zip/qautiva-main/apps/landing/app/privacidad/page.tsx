import Link from 'next/link'

export const metadata = {
  title: 'Política de Privacidad — qautiva Marketing',
}

export default function PrivacidadPage() {
  return (
    <main className="min-h-screen bg-navy-950 flex flex-col items-center justify-center px-6 py-24">
      <div className="max-w-2xl w-full text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Política de Privacidad</h1>
        <p className="text-slate-400 text-lg mb-8">
          Esta página está en construcción. Próximamente encontrarás aquí nuestra política de privacidad.
        </p>
        <Link
          href="/"
          className="inline-flex items-center text-slate-400 hover:text-white text-sm transition-colors duration-200 underline underline-offset-2"
        >
          Volver al inicio
        </Link>
      </div>
    </main>
  )
}
