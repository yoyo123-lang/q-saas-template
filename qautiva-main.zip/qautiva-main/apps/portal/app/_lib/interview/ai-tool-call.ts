import Anthropic from '@anthropic-ai/sdk'
import OpenAI from 'openai'
import type { UsageSource } from '@qautiva/db'
import { registerAiUsage } from '../billing/register-ai-usage'
import { getAiConfig, type AiProviderType } from './ai-config'

// ── Singletons ───────────────────────────────────────────────────────────────

let _anthropicClient: Anthropic | null = null
function getAnthropicClient(): Anthropic {
  if (!_anthropicClient) {
    _anthropicClient = new Anthropic({ timeout: 55_000, maxRetries: 2 })
  }
  return _anthropicClient
}

let _openaiClient: OpenAI | null = null
function getOpenAIToolClient(): OpenAI {
  if (!_openaiClient) {
    const apiKey = process.env['OPENAI_API_KEY']
    if (!apiKey) {
      throw new Error('[ai-tool-call] OPENAI_API_KEY no está configurada')
    }
    _openaiClient = new OpenAI({ apiKey, timeout: 55_000 })
  }
  return _openaiClient
}

// ── Types ────────────────────────────────────────────────────────────────────

export interface ToolDefinition {
  name: string
  description: string
  input_schema: Record<string, unknown>
}

/** Contexto de billing para registrar consumo de tokens. Opcional. */
export interface BillingContext {
  teamId: string | null
  projectId: string
  /** Fuente de la API key / tipo de consumo */
  source: UsageSource
  /** Nombre de la operación para el registro (ej: "brief_generation") */
  operation: string
}

export interface ToolCallParams {
  /** System prompt */
  system: string
  /** User message content */
  userMessage: string
  /** Tool that the model must call */
  tool: ToolDefinition
  /** Max tokens for the response */
  maxTokens: number
  /** Log prefix for error messages */
  logPrefix: string
  /**
   * Contexto de billing. Si se provee, se registra el consumo de tokens
   * automáticamente después de cada llamada exitosa.
   */
  billingContext?: BillingContext
}

export interface ToolCallResult {
  /** Parsed JSON input from the tool call */
  input: unknown
  /** Which provider was actually used */
  provider: AiProviderType
  /** Which model was actually used */
  model: string
  /** Tokens consumidos en la llamada (disponibles si se tuvo billing context) */
  tokensIn?: number
  tokensOut?: number
}

// ── Main function ────────────────────────────────────────────────────────────

/**
 * Ejecuta una llamada a AI con tool_use forzado, abstrayendo el provider (Anthropic/OpenAI).
 *
 * Lee provider/model de TrialConfig (vía ai-config.ts con cache de 5min).
 * Si el provider configurado falla, NO hace fallback automático al otro — lanza el error
 * para que el caller (generator) lo maneje con su propio retry/error flow.
 *
 * @returns El input parseado del tool_use, junto con info de qué provider/model se usó.
 * @throws Error si el provider falla, la respuesta se trunca, o el modelo no llama al tool.
 */
export async function executeToolCall(params: ToolCallParams): Promise<ToolCallResult> {
  const config = await getAiConfig()

  console.info(`[${params.logPrefix}] AI call — provider=${config.provider}, model=${config.model}`)

  if (config.provider === 'ANTHROPIC') {
    return callAnthropic(params, config.model)
  }

  return callOpenAI(params, config.model)
}

// ── Anthropic implementation ─────────────────────────────────────────────────

async function callAnthropic(params: ToolCallParams, model: string): Promise<ToolCallResult> {
  const client = getAnthropicClient()

  const anthropicTool: Anthropic.Tool = {
    name: params.tool.name,
    description: params.tool.description,
    input_schema: params.tool.input_schema as Anthropic.Tool['input_schema'],
  }

  const startMs = Date.now()
  let response
  try {
    response = await client.messages.create({
      model,
      max_tokens: params.maxTokens,
      system: params.system,
      tools: [anthropicTool],
      tool_choice: { type: 'tool', name: params.tool.name },
      messages: [{ role: 'user', content: params.userMessage }],
    })
  } catch (err) {
    const elapsedMs = Date.now() - startMs
    console.error(`[${params.logPrefix}] Anthropic API call failed`, {
      model,
      elapsedMs,
      error: err instanceof Error ? err.message : String(err),
    })
    throw err
  }

  const elapsedMs = Date.now() - startMs
  console.info(`[${params.logPrefix}] Anthropic response received`, {
    model,
    elapsedMs,
    stopReason: response.stop_reason,
    hasToolUse: response.content.some((b) => b.type === 'tool_use'),
    usage: { input: response.usage.input_tokens, output: response.usage.output_tokens },
  })

  if (response.stop_reason === 'max_tokens') {
    throw new Error(`[${params.logPrefix}] Respuesta truncada por max_tokens`)
  }

  const toolUseBlock = response.content.find(
    (b): b is Anthropic.ToolUseBlock => b.type === 'tool_use',
  )

  if (!toolUseBlock || toolUseBlock.name !== params.tool.name) {
    throw new Error(
      `[${params.logPrefix}] Claude no llamó a ${params.tool.name} — stop_reason: ${response.stop_reason}`,
    )
  }

  const tokensIn = response.usage.input_tokens
  const tokensOut = response.usage.output_tokens

  if (params.billingContext) {
    await registerAiUsage({
      teamId: params.billingContext.teamId,
      projectId: params.billingContext.projectId,
      provider: 'ANTHROPIC',
      model,
      operation: params.billingContext.operation,
      source: params.billingContext.source,
      tokensIn,
      tokensOut,
    })
  }

  return { input: toolUseBlock.input, provider: 'ANTHROPIC', model, tokensIn, tokensOut }
}

// ── OpenAI implementation ────────────────────────────────────────────────────

/**
 * Detecta modelos de razonamiento de OpenAI (o-series, gpt-5 family)
 * que requieren max_completion_tokens y no soportan tool_choice con nombre específico.
 */
function isReasoningModel(model: string): boolean {
  return /^(o[1-9]|gpt-5)/.test(model)
}

async function callOpenAI(params: ToolCallParams, model: string): Promise<ToolCallResult> {
  const client = getOpenAIToolClient()
  const reasoning = isReasoningModel(model)

  const openaiTool: OpenAI.ChatCompletionTool = {
    type: 'function',
    function: {
      name: params.tool.name,
      description: params.tool.description,
      parameters: params.tool.input_schema,
      strict: true,
    },
  }

  // Reasoning models (o-series, gpt-5 family):
  // - Requieren max_completion_tokens en vez de max_tokens
  // - No soportan tool_choice con nombre específico, solo "required" o "auto"
  // - No soportan system role, se usa developer role
  const startMs = Date.now()
  let response
  try {
    response = await client.chat.completions.create({
      model,
      ...(reasoning
        ? { max_completion_tokens: params.maxTokens }
        : { max_tokens: params.maxTokens }
      ),
      messages: [
        { role: reasoning ? 'developer' : 'system', content: params.system },
        { role: 'user', content: params.userMessage },
      ],
      tools: [openaiTool],
      // Solo se pasa un tool, así que "required" garantiza que lo llame.
      // parallel_tool_calls: false requerido por strict mode (solo hay un tool, pero lo forzamos igual).
      tool_choice: reasoning
        ? 'required'
        : { type: 'function', function: { name: params.tool.name } },
      parallel_tool_calls: false,
    })
  } catch (err) {
    const elapsedMs = Date.now() - startMs
    console.error(`[${params.logPrefix}] OpenAI API call failed`, {
      model,
      reasoning,
      elapsedMs,
      error: err instanceof Error ? err.message : String(err),
    })
    throw err
  }

  const elapsedMs = Date.now() - startMs
  const choice = response.choices[0]
  console.info(`[${params.logPrefix}] OpenAI response received`, {
    model,
    reasoning,
    elapsedMs,
    finishReason: choice?.finish_reason,
    hasToolCalls: !!choice?.message?.tool_calls?.length,
    usage: response.usage ? { prompt: response.usage.prompt_tokens, completion: response.usage.completion_tokens } : null,
  })

  if (!choice) {
    throw new Error(`[${params.logPrefix}] OpenAI no devolvió choices`)
  }

  if (choice.finish_reason === 'length') {
    throw new Error(`[${params.logPrefix}] Respuesta truncada por max_tokens (OpenAI)`)
  }

  const toolCall = choice.message?.tool_calls?.[0]
  if (!toolCall || toolCall.type !== 'function' || toolCall.function.name !== params.tool.name) {
    throw new Error(
      `[${params.logPrefix}] OpenAI no llamó a ${params.tool.name} — finish_reason: ${choice.finish_reason}`,
    )
  }

  let parsed: unknown
  try {
    parsed = JSON.parse(toolCall.function.arguments)
  } catch {
    throw new Error(
      `[${params.logPrefix}] OpenAI devolvió JSON inválido en tool_call arguments`,
    )
  }

  const tokensIn = response.usage?.prompt_tokens ?? 0
  const tokensOut = response.usage?.completion_tokens ?? 0

  if (!response.usage) {
    console.warn(`[${params.logPrefix}] OpenAI no retornó usage — billing registrado con tokens=0`, { model })
  }

  if (params.billingContext) {
    await registerAiUsage({
      teamId: params.billingContext.teamId,
      projectId: params.billingContext.projectId,
      provider: 'OPENAI',
      model,
      operation: params.billingContext.operation,
      source: params.billingContext.source,
      tokensIn,
      tokensOut,
    })
  }

  return { input: parsed, provider: 'OPENAI', model, tokensIn, tokensOut }
}
