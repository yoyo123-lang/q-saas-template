import type { Metadata } from 'next'
import { Suspense } from 'react'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma } from '@qautiva/db'
import { TemplateTabs } from './_components/TemplateTabs'
import { TabInfo } from './_components/TabInfo'
import { TabSecciones } from './_components/TabSecciones'
import { TabCodigo } from './_components/TabCodigo'

export const metadata: Metadata = { title: 'Editar template | Qautiva Admin' }

const VALID_TABS = ['info', 'secciones', 'codigo'] as const
type TabId = (typeof VALID_TABS)[number]

export default async function TemplateDetailPage({
  params,
  searchParams,
}: {
  params: { id: string }
  searchParams: { tab?: string; imported?: string }
}) {
  const isImported = searchParams.imported === '1'
  const rawTab = searchParams.tab ?? 'info'
  const activeTab: TabId = (VALID_TABS as readonly string[]).includes(rawTab)
    ? (rawTab as TabId)
    : 'info'

  // Select parcial: htmlBase y css solo se traen en la tab Código
  const template = await prisma.webTemplate.findUnique({
    where: { id: params.id },
    select: {
      id: true,
      name: true,
      description: true,
      thumbnail: true,
      status: true,
      usageCount: true,
      compatibleIndustries: true,
      sections: true,
      variables: true,
      ...(activeTab === 'codigo' ? { htmlBase: true, css: true } : {}),
    },
  })

  if (!template) notFound()

  const sections = (template.sections as Record<string, boolean>) ?? {}
  const compatibleIndustries = (template.compatibleIndustries as string[]) ?? []
  const variables = (template.variables as Record<string, string> | null) ?? null

  return (
    <div className="p-8 max-w-4xl">
      {isImported && (
        <div className="mb-6 px-4 py-3 rounded-lg border bg-green-400/10 border-green-400/20 text-green-400 text-sm">
          ✓ Template importado como borrador. Revisá los detalles y activalo cuando esté listo.
        </div>
      )}
      <Link
        href="/templates"
        className="inline-flex items-center gap-1 text-sm text-[#64748B] hover:text-[#94A3B8] mb-6 transition-colors"
      >
        ← Templates web
      </Link>

      <div className="mb-6">
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="text-2xl font-bold text-white">{template.name}</h1>
          <span
            className={`px-2 py-0.5 text-xs rounded-full font-medium ${
              template.status === 'ACTIVE'
                ? 'bg-green-400/10 text-green-400'
                : 'bg-[#1E293B] text-[#64748B]'
            }`}
          >
            {template.status === 'ACTIVE' ? 'Activo' : 'Borrador'}
          </span>
          <Link
            href={`/api/templates/${params.id}/preview`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1 text-xs text-[#64748B] border border-[#1E293B] rounded hover:text-white hover:border-[#334155] transition-colors"
          >
            Ver preview ↗
          </Link>
        </div>
        <p className="text-[#64748B] text-sm mt-1">
          {template.usageCount} uso(s) · {compatibleIndustries.length} industria(s) compatible(s)
        </p>
      </div>

      <Suspense fallback={<div className="h-10 border-b border-[#1E293B]" />}>
        <TemplateTabs activeTab={activeTab} templateId={params.id} />
      </Suspense>

      <div className="mt-6">
        {activeTab === 'info' && (
          <TabInfo
            templateId={params.id}
            name={template.name}
            description={template.description ?? ''}
            thumbnail={template.thumbnail ?? ''}
            status={template.status}
            compatibleIndustries={compatibleIndustries}
          />
        )}
        {activeTab === 'secciones' && (
          <TabSecciones templateId={params.id} sections={sections} />
        )}
        {activeTab === 'codigo' && (
          <TabCodigo
            templateId={params.id}
            htmlBase={('htmlBase' in template ? template.htmlBase : null) ?? ''}
            css={('css' in template ? template.css : null) ?? ''}
            variables={variables}
          />
        )}
      </div>
    </div>
  )
}
