# Plan — Etapa 5: Campañas publicitarias (Google Ads + Meta Ads)

> **Fecha**: 2026-03-18
> **Estado**: Propuesta — pendiente de aprobación
> **Autor**: Claude Code

---

## Cambio de concepto

La Etapa 5 actual ("Integración y pulido") se redefine completamente. Ya no es una etapa técnica de cierre sino la **implementación de la estrategia publicitaria** del cliente.

**Antes**: Entrevista simple → entregable estático (plan de campaña PDF)
**Ahora**: Flujo completo de conexión, estrategia, creación de piezas y gestión de campañas

---

## Alcance

### Lo que incluye

1. **Conexión de cuentas** — OAuth con Google Ads y Meta Ads Business
2. **Estrategia publicitaria con IA** — generación de plan de campaña basado en datos previos del proyecto (brief, mercado, marca, web)
3. **Creación de piezas publicitarias** — copy + creativos (imágenes/banners) con IA
4. **Panel de gestión en portal** — el cliente ve sus campañas, métricas reales, y piezas
5. **Panel admin de campañas** — el admin gestiona cuentas de ads, revisa estrategias, activa campañas

### Lo que NO incluye (futuro)

- Activación automática de campañas sin intervención humana
- Optimización automática de pujas/presupuestos
- Reporting avanzado (dashboards tipo Data Studio)
- Integración con TikTok Ads, LinkedIn Ads u otras plataformas

---

## Dependencias externas (paquetes npm)

| Paquete | Propósito | Versión |
|---------|-----------|---------|
| `google-ads-api` (Opteo) | SDK Google Ads API — TypeScript, gRPC, MIT | ^23.0.0 |
| `google-auth-library` | OAuth 2.0 para Google | latest |
| `facebook-nodejs-business-sdk` | SDK oficial Meta Marketing API | ^24.0.1 |
| `@types/facebook-nodejs-business-sdk` | Tipos TS para Meta SDK | ^23.0.0 |

No se agrega ningún paquete de generación de imágenes por ahora — se usa Anthropic SDK (ya existente) para copy y se evalúa API externa para imágenes en una fase posterior.

---

## Cambios al modelo de datos (Prisma)

### Nuevos modelos

```prisma
model AdAccount {
  id             String       @id @default(uuid())
  projectId      String
  project        Project      @relation(fields: [projectId], references: [id])
  teamId         String
  platform       AdPlatform   // GOOGLE_ADS | META
  externalId     String       // ID de la cuenta en la plataforma
  name           String       // Nombre descriptivo
  accessToken    String       // Encriptado con AES-256-GCM (lib/encryption.ts)
  refreshToken   String       // Encriptado
  tokenExpiresAt DateTime?
  status         AdAccountStatus @default(PENDING_AUTH)
  metadata       Json?        // Datos extra de la plataforma (currency, timezone, etc.)
  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  campaigns      Campaign[]

  @@unique([projectId, platform, externalId])
  @@index([projectId])
  @@index([teamId])
}

model Campaign {
  id             String         @id @default(uuid())
  adAccountId    String
  adAccount      AdAccount      @relation(fields: [adAccountId], references: [id])
  externalId     String?        // ID en Google/Meta (null si no se publicó aún)
  name           String
  objective      String         // CONVERSIONS, TRAFFIC, AWARENESS, LEADS, etc.
  status         CampaignStatus @default(DRAFT)
  dailyBudget    Int?           // En centavos (moneda de la cuenta)
  startDate      DateTime?
  endDate        DateTime?
  targeting      Json?          // Segmentación (audiences, keywords, locations, etc.)
  platformConfig Json?          // Config específica de plataforma (bidStrategy, etc.)
  createdAt      DateTime       @default(now())
  updatedAt      DateTime       @updatedAt

  adSets         AdSet[]
  creatives      AdCreative[]
  metrics        CampaignMetric[]

  @@index([adAccountId])
  @@index([status])
}

model AdSet {
  id             String       @id @default(uuid())
  campaignId     String
  campaign       Campaign     @relation(fields: [campaignId], references: [id])
  externalId     String?
  name           String
  status         CampaignStatus @default(DRAFT)
  targeting      Json?        // Segmentación específica del ad set
  dailyBudget    Int?
  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  ads            Ad[]

  @@index([campaignId])
}

model Ad {
  id             String       @id @default(uuid())
  adSetId        String
  adSet          AdSet        @relation(fields: [adSetId], references: [id])
  externalId     String?
  name           String
  creativeId     String?
  creative       AdCreative?  @relation(fields: [creativeId], references: [id])
  status         CampaignStatus @default(DRAFT)
  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  @@index([adSetId])
  @@index([creativeId])
}

model AdCreative {
  id             String       @id @default(uuid())
  campaignId     String
  campaign       Campaign     @relation(fields: [campaignId], references: [id])
  projectId      String
  type           CreativeType // COPY | IMAGE | VIDEO
  headline       String?
  description    String?
  callToAction   String?
  imageUrl       String?      // URL en storage
  videoUrl       String?
  platform       AdPlatform   // Para qué plataforma fue diseñado
  format         String?      // FEED, STORY, SEARCH, DISPLAY, etc.
  aiGenerated    Boolean      @default(false)
  approvedAt     DateTime?
  approvedBy     String?
  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt

  ads            Ad[]

  @@index([campaignId])
  @@index([projectId])
}

model CampaignMetric {
  id             String     @id @default(uuid())
  campaignId     String
  campaign       Campaign   @relation(fields: [campaignId], references: [id])
  date           DateTime   @db.Date
  impressions    Int        @default(0)
  clicks         Int        @default(0)
  conversions    Int        @default(0)
  spend          Int        @default(0) // En centavos
  ctr            Float?     // click-through rate
  cpc            Float?     // cost per click
  cpa            Float?     // cost per acquisition
  source         MetricSource @default(MANUAL) // MANUAL | API_SYNC
  createdAt      DateTime   @default(now())

  @@unique([campaignId, date, source])
  @@index([campaignId])
  @@index([date])
}
```

### Nuevos enums

```prisma
enum AdPlatform {
  GOOGLE_ADS
  META
}

enum AdAccountStatus {
  PENDING_AUTH   // Esperando OAuth
  ACTIVE         // Conectada y funcionando
  EXPIRED        // Token expirado, requiere re-auth
  DISCONNECTED   // Desconectada por el usuario
  ERROR          // Error de API
}

enum CampaignStatus {
  DRAFT          // Creada en Qautiva, no publicada
  PENDING_REVIEW // Esperando aprobación admin
  APPROVED       // Aprobada, lista para publicar
  ACTIVE         // Publicada y corriendo
  PAUSED         // Pausada en la plataforma
  COMPLETED      // Finalizada
  ERROR          // Error al sincronizar
}

enum CreativeType {
  COPY
  IMAGE
  VIDEO
}

enum MetricSource {
  MANUAL
  API_SYNC
}
```

### Cambios a modelos existentes

- `Project`: agregar relación `adAccounts AdAccount[]`
- Eliminar dependencia de `Metric.adSpendGoogle` / `Metric.adSpendMeta` para datos de campañas (migrar a `CampaignMetric`)
- `ActivationRequest`: se mantiene como está — representa "activar campañas manualmente por el equipo Qautiva"

---

## Arquitectura de la integración

### Nuevo package: `packages/ads`

Wrapper tipado sobre los SDKs de Google y Meta. Server-only.

```
packages/ads/
├── src/
│   ├── index.ts              // Re-exporta todo
│   ├── google/
│   │   ├── client.ts         // Inicialización GoogleAdsApi
│   │   ├── auth.ts           // OAuth flow (authorization URL, token exchange)
│   │   ├── campaigns.ts      // CRUD de campañas
│   │   ├── reporting.ts      // Queries GAQL para métricas
│   │   └── types.ts          // Tipos internos
│   ├── meta/
│   │   ├── client.ts         // Inicialización FacebookAdsApi
│   │   ├── auth.ts           // OAuth flow
│   │   ├── campaigns.ts      // CRUD de campañas
│   │   ├── reporting.ts      // Métricas via Insights API
│   │   └── types.ts
│   └── shared/
│       ├── token-manager.ts  // Encrypt/decrypt tokens, refresh automático
│       └── errors.ts         // Error types unificados
├── package.json
├── tsconfig.json
└── __tests__/
```

### Config Next.js (apps/admin y apps/portal)

```js
// next.config.mjs — agregar en ambas apps
serverExternalPackages: [
  "google-ads-api",
  "google-ads-node",
  "@grpc/grpc-js",
  "@grpc/proto-loader"
]
```

---

## Flujo del cliente en el Portal (Stage CAMPAIGNS)

El flujo cambia de ser una entrevista simple a un proceso multi-paso:

### Paso 1 — Conectar cuentas (nuevo)
- UI para conectar Google Ads y/o Meta Ads via OAuth
- El cliente autoriza acceso a su cuenta publicitaria
- Se guardan tokens encriptados en `AdAccount`
- Si no tiene cuenta, se muestra guía para crear una

### Paso 2 — Generar estrategia (reemplaza entrevista)
- La IA genera un plan de campaña usando datos de etapas previas:
  - Brief estratégico (etapa 1)
  - Estudio de mercado (etapa 2)
  - Identidad de marca (etapa 3)
  - Sitio web (etapa 4)
- El plan incluye: objetivos, presupuesto sugerido, audiencias, tipos de campaña, calendario
- Se genera como `Deliverable` tipo `CAMPAIGN_PLAN`
- El cliente revisa y aprueba (o pide ajustes)

### Paso 3 — Crear piezas publicitarias (nuevo)
- La IA genera opciones de copy para cada plataforma/formato
- Variantes de headlines, descriptions, CTAs
- Preview de cómo se verían los ads
- El cliente selecciona/edita las piezas que quiere usar

### Paso 4 — Revisión y activación (nuevo)
- El admin revisa la estrategia y piezas en el backoffice
- Si está todo OK, puede:
  a) Crear las campañas via API en la plataforma (status PAUSED)
  b) O marcar como "ActivationRequest" para gestión manual
- El cliente ve el estado en su dashboard

---

## Panel Admin — Nuevo tab "Campañas"

En la ficha de cliente (`/clientes/[id]?tab=campanas`):

### Vista de cuentas conectadas
- Lista de `AdAccount` del proyecto
- Status de conexión (activa, expirada, error)
- Botón para reconectar si token expirado

### Vista de campañas
- Lista de `Campaign` con status, presupuesto, métricas
- Acciones: aprobar, pausar, ver detalle
- Vista de piezas creativas asociadas

### Vista de métricas
- Datos reales de las APIs (impressions, clicks, conversions, spend)
- Sync manual o automático (cron job futuro)

---

## Sub-etapas de implementación

### 5.1 — Schema y package ads (foundation)
1. Agregar nuevos modelos y enums al schema Prisma
2. Crear migración
3. Crear `packages/ads` con estructura base
4. Configurar `serverExternalPackages` en ambas apps
5. Tests unitarios para token-manager (encrypt/decrypt)

### 5.2 — OAuth flows
1. Route handlers para OAuth de Google Ads (`/api/ads/google/auth`, `/api/ads/google/callback`)
2. Route handlers para OAuth de Meta (`/api/ads/meta/auth`, `/api/ads/meta/callback`)
3. UI en portal para conectar cuentas
4. Server Actions en admin para ver estado de conexiones
5. Tests de integración para los flows de OAuth

### 5.3 — Generador de estrategia con IA
1. `campaign-strategy-generator.ts` — prompt que toma datos de etapas 1-4 y genera plan
2. Session processor para stage CAMPAIGNS
3. UI de presentación del plan en portal (deliverable CAMPAIGN_PLAN)
4. Flujo de aprobación/ajustes por el cliente
5. Tests del generador

### 5.4 — Generador de piezas publicitarias
1. `ad-creative-generator.ts` — genera variantes de copy por plataforma/formato
2. UI de preview de anuncios (Google Search, Meta Feed, Meta Story)
3. Flujo de selección/edición por el cliente
4. Almacenamiento de `AdCreative` aprobados
5. Tests del generador

### 5.5 — Panel admin de campañas
1. Nuevo tab "Campañas" en ficha de cliente
2. Server Actions para gestión de campañas (aprobar, pausar, etc.)
3. Vista de cuentas conectadas con status
4. Vista de piezas creativas con preview
5. Integración con ActivationRequest existente

### 5.6 — Sync de métricas
1. Funciones para traer métricas de Google Ads (GAQL queries)
2. Funciones para traer métricas de Meta (Insights API)
3. Server Action de sync manual desde admin
4. Guardar en `CampaignMetric` con source API_SYNC
5. Migrar dashboard de métricas del portal para usar datos reales
6. Tests de integración

---

## Riesgos y mitigaciones

| Riesgo | Impacto | Mitigación |
|--------|---------|------------|
| gRPC de Google Ads no bundlea en Vercel | Deploy roto | `serverExternalPackages` + `outputFileTracingIncludes` para proto files |
| Rate limits de Meta (200/hora/usuario) | Sync lenta | Batch requests + cache + sync incremental |
| Tokens OAuth expiran | Cuentas desconectadas | Refresh automático en `token-manager.ts` + alerta en admin |
| El cliente no tiene cuenta de ads | Bloquea el flujo | Paso 1 permite continuar sin conectar (genera estrategia igual) |
| Tipos de Meta SDK incompletos (v23 vs v24) | Errores TS | `declare module` shim + wrapper tipado en `packages/ads` |

---

## Variables de entorno nuevas

```env
# Google Ads
GOOGLE_ADS_CLIENT_ID=
GOOGLE_ADS_CLIENT_SECRET=
GOOGLE_ADS_DEVELOPER_TOKEN=
GOOGLE_ADS_REDIRECT_URI=

# Meta Ads
META_APP_ID=
META_APP_SECRET=
META_REDIRECT_URI=
```

---

## Orden de ejecución sugerido

```
5.1 Schema + package → 5.2 OAuth → 5.3 Estrategia IA → 5.4 Piezas → 5.5 Admin → 5.6 Métricas
```

Cada sub-etapa es un bloque independiente que compila y pasa tests antes de avanzar.

---

## Revisión por roles (docs/roles/)

Aplicamos los 6 roles de revisión al plan para anticipar problemas antes de implementar.

---

### 1. Code Reviewer (Tech Lead)

**Estructura y organización**
- `packages/ads` sigue el patrón existente de `packages/db` y `packages/domains` — un package por dominio con exports limpios
- Separación `google/` vs `meta/` vs `shared/` evita archivos de 300+ líneas
- Cada archivo tiene una responsabilidad clara (auth, campaigns, reporting)

**Requisitos de implementación**
- [ ] Los wrappers de SDK deben seguir las convenciones de `docs/CONVENTIONS.md` (naming, imports, error handling)
- [ ] `token-manager.ts` reutiliza el patrón de `lib/encryption.ts` existente en admin — NO duplicar la lógica de encripción, importar desde un lugar compartido
- [ ] Los Server Actions nuevos de campañas NO van en `lib/actions.ts` de admin (ya tiene 657 líneas). Crear `lib/campaign-actions.ts` siguiendo el mismo patrón (requireAdminSession, FormData, revalidatePath)
- [ ] Los tipos de campaña (`Campaign`, `AdAccount`, etc.) deben vivir en `packages/db` (generados por Prisma) — no crear tipos manuales duplicados
- [ ] El tab "Campañas" en admin sigue el patrón de URL-based tabs (ADR-0006) — `?tab=campanas`
- [ ] Los badges de status de campañas (`CampaignStatus`, `AdAccountStatus`) van en `lib/badges.ts` siguiendo el patrón `Record<Enum, {label, className}>`

**Banderas rojas a evitar**
- No mezclar lógica de Google y Meta en el mismo archivo — siempre separados con interfaz común
- No hardcodear nombres de campañas como hace `CampaignCard.tsx` actual ("Campaña búsqueda")
- No poner lógica de API en componentes React — todo en `packages/ads` o Server Actions

---

### 2. QA Engineer (Tester)

**Flujos principales que deben funcionar end-to-end**
- [ ] OAuth Google: click "Conectar" → redirect a Google → autorizar → callback → cuenta guardada en DB → status ACTIVE visible
- [ ] OAuth Meta: mismo flujo con Facebook Login
- [ ] Generar estrategia: con etapas 1-4 completas → click "Generar" → IA produce plan → se muestra como Deliverable → cliente aprueba
- [ ] Crear piezas: seleccionar plataforma/formato → IA genera variantes → cliente selecciona → se guardan como AdCreative
- [ ] Admin aprueba campaña: ve campaña PENDING_REVIEW → click "Aprobar" → status cambia a APPROVED

**Casos borde críticos**
- [ ] ¿Qué pasa si el cliente revoca permisos en Google/Meta después de conectar? → La app debe detectar token inválido y mostrar "Reconectar"
- [ ] ¿Qué pasa si el OAuth callback recibe un error (usuario canceló)? → Redirect al portal con mensaje de error claro
- [ ] ¿Qué pasa si la IA genera copy que excede los límites de caracteres de Google/Meta? → Validar contra límites reales (Google: 30 chars headline, 90 chars description; Meta: 40 chars headline, 125 chars primary text)
- [ ] ¿Qué pasa si el cliente no completó etapas 1-4? → El generador de estrategia debe funcionar con datos parciales o mostrar qué falta
- [ ] ¿Qué pasa con presupuestos en $0 o negativos? → Validar server-side, rechazar con mensaje descriptivo
- [ ] ¿Qué pasa si se hace doble click en "Generar estrategia"? → Deshabilitar botón durante procesamiento
- [ ] ¿Qué pasa si la API de Google/Meta está caída durante sync de métricas? → Timeout + error descriptivo + no perder datos anteriores
- [ ] ¿Qué pasa con un proyecto que no tiene servicios CAMPAIGNS seleccionados? → No mostrar la etapa 5

**Estados de UI requeridos**
- [ ] Loading: skeleton mientras se generan piezas con IA (puede tardar 10-30s)
- [ ] Empty: "No hay campañas aún" con CTA para empezar
- [ ] Error: mensajes en español argentino, sin stack traces, con acción sugerida
- [ ] Success: feedback visual al conectar cuenta, aprobar campaña, generar piezas

**Datos y formatos**
- [ ] Presupuestos en ARS con formato argentino ($ 1.000,50)
- [ ] Fechas en formato argentino (18/03/2026)
- [ ] Métricas con separador de miles correcto
- [ ] CTR/CPC/CPA con 2 decimales máximo

---

### 3. Security Auditor

**OAuth y tokens (CRÍTICO)**
- [ ] Tokens de acceso y refresh encriptados con AES-256-GCM antes de guardar en DB — usar `lib/encryption.ts` existente
- [ ] NUNCA loguear tokens en console.log — ni en dev. Agregar a la lista de secrets que el linter debe bloquear
- [ ] El `state` parameter de OAuth debe ser un token random verificable para prevenir CSRF
- [ ] Los callbacks de OAuth deben validar `state` antes de intercambiar el code por token
- [ ] Los tokens de Meta tienen scopes limitados: `ads_management`, `ads_read` — no pedir más de lo necesario
- [ ] Google Ads requiere `developer_token` — este NUNCA se expone al frontend, solo server-side
- [ ] Implementar token rotation: al refrescar, invalidar el anterior

**Autorización (CRÍTICO)**
- [ ] TODA operación con cuentas de ads verifica que el `projectId` pertenezca al usuario/organización autenticada — prevenir IDOR
- [ ] Server Actions de admin usan `requireAdminSession()` — sin excepciones
- [ ] Los route handlers de OAuth callback validan que el usuario que inició el flow es el mismo que recibe el callback (via session + state)
- [ ] Un cliente NO puede ver/editar cuentas de ads de otro proyecto — validar ownership en cada query

**Datos sensibles**
- [ ] Variables de entorno nuevas (`GOOGLE_ADS_CLIENT_SECRET`, `META_APP_SECRET`) documentadas en `.env.example` sin valores reales
- [ ] Las credenciales de ads platforms NO se envían al frontend — solo IDs y status
- [ ] Los errores de API de Google/Meta NO se muestran raw al usuario — podrían contener tokens o datos internos
- [ ] Agregar `AdAccount.accessToken` y `AdAccount.refreshToken` a la lista de campos que Prisma select NUNCA debe incluir en queries que van al frontend

**Rate limiting y abuso**
- [ ] Limitar cantidad de reconexiones OAuth por hora por usuario (prevenir abuse del flow)
- [ ] Limitar cantidad de generaciones de estrategia por proyecto (prevenir spam de IA)
- [ ] Las operaciones de sync de métricas solo las puede triggear un admin (no el cliente)

---

### 4. Performance Engineer

**Base de datos**
- [ ] `CampaignMetric` va a crecer rápido (1 row por campaña por día). Índice compuesto en `[campaignId, date]` ya está — verificar que las queries usen el índice
- [ ] Las queries de métricas deben filtrar siempre por rango de fechas — NUNCA traer todo el histórico sin LIMIT
- [ ] La query de la ficha de cliente en admin ya trae stages + deliverables + messages — NO agregar campaigns + metrics + creatives a la misma query. Hacer lazy loading del tab "Campañas"
- [ ] Paginación obligatoria en listados de campañas y métricas

**APIs externas**
- [ ] Timeout de 15s para llamadas a Google Ads API (gRPC puede ser lento)
- [ ] Timeout de 10s para llamadas a Meta Marketing API
- [ ] NUNCA llamar a APIs externas dentro de loops — usar batch requests
- [ ] Meta: usar `fields` parameter para pedir solo los campos necesarios (no traer todo el objeto Campaign de la API)
- [ ] Google: usar GAQL con SELECT explícito (no SELECT *)
- [ ] Cachear resultados de métricas por al menos 15 minutos — no syncear en cada page load

**Frontend**
- [ ] Las previews de anuncios pueden tener imágenes — lazy loading obligatorio
- [ ] El generador de estrategia/piezas con IA tarda: usar streaming (ya existe el patrón con Anthropic SDK)
- [ ] Los componentes de métricas (gráficos, tablas) deben usar `dynamic(() => import(...), { ssr: false })` si son pesados
- [ ] `google-ads-api` + `google-ads-node` pesan ~115 MB — verificar que `serverExternalPackages` evite que entren en el bundle del cliente

**Escalabilidad**
- [ ] Con 100 clientes × 2 plataformas × 5 campañas × 365 días = 365.000 rows en CampaignMetric por año — el modelo aguanta pero necesita partition o archivado eventualmente
- [ ] Sync de métricas masivo (todos los clientes) debe ser batch, no concurrente — respetar rate limits de ambas APIs

---

### 5. DevOps / SRE

**Deploy y configuración**
- [ ] 6 variables de entorno nuevas — documentar TODAS en `.env.example` con descripción
- [ ] Las variables de Google Ads y Meta Ads son diferentes por entorno (dev/staging/prod) — documentar cómo obtener credenciales de sandbox
- [ ] Google Ads requiere un "test account" para desarrollo — documentar setup en README o en un doc específico
- [ ] Meta requiere una "test app" en Meta Developers — documentar setup
- [ ] `serverExternalPackages` con proto files puede romper deploy en Vercel — agregar `outputFileTracingIncludes` para las proto files de gRPC
- [ ] Verificar que Railway (donde corre admin) soporte los binarios nativos de gRPC

**Rollback**
- [ ] La migración de Prisma agrega 6 tablas nuevas + 4 enums — es aditiva, rollback seguro (drop tables)
- [ ] Si se migra datos de `Metric.adSpendGoogle/Meta` a `CampaignMetric`, hacer la migración en dos pasos: primero agregar nuevo, después deprecar viejo — no borrar en la misma migración

**Logs y observabilidad**
- [ ] Loguear TODA operación OAuth: inicio, callback exitoso, callback con error, token refresh, token expirado — con `projectId` y `platform` para trazar
- [ ] Loguear TODA llamada a APIs externas: endpoint, duración, status code, error si hubo — SIN tokens ni datos sensibles
- [ ] Loguear generaciones de IA: projectId, tipo (estrategia/copy), duración, tokens usados, modelo
- [ ] Los errores de sync de métricas no deben ser silenciosos — alertar si una cuenta falla sync 3 veces seguidas

**Health checks**
- [ ] Agregar verificación de conectividad con Google Ads y Meta APIs al health check existente (si hay)
- [ ] Monitorear expiración de tokens — alertar cuando una cuenta tiene token a punto de expirar (< 24h)

**Secretos y rotación**
- [ ] Plan de rotación de `GOOGLE_ADS_CLIENT_SECRET` y `META_APP_SECRET` si se filtran
- [ ] Los tokens de usuario en DB se pueden invalidar en masa si hay breach — agregar campo `revokedAt` a `AdAccount` (o usar `status: DISCONNECTED`)

---

### 6. Product Reviewer (UX/Producto)

**Flujo del usuario — Paso 1 (Conectar cuentas)**
- [ ] ¿El cliente entiende POR QUÉ tiene que conectar su cuenta? → Explicar beneficio: "Conectá tu cuenta para que podamos crear y gestionar tus campañas"
- [ ] ¿Qué pasa si no tiene cuenta? → CTA claro: "¿No tenés cuenta? Te ayudamos a crearla" con guía paso a paso
- [ ] ¿Puede saltear este paso? → Sí, puede generar estrategia sin conectar (modo "manual")
- [ ] ¿Se ve profesional el flow de OAuth? → No mandar al usuario a URLs raras, mostrar loading mientras se procesa
- [ ] ¿El usuario sabe que sus datos están seguros? → Mostrar badge de seguridad ("Conexión segura — tus credenciales están encriptadas")

**Flujo del usuario — Paso 2 (Estrategia)**
- [ ] ¿El plan generado es entendible por un emprendedor no técnico? → Lenguaje claro, sin jerga de marketing digital. Explicar cada concepto (CPC, segmentación, etc.)
- [ ] ¿El cliente puede pedir cambios? → Sí, botón "Pedir ajustes" con campo de texto para feedback
- [ ] ¿Se muestra de dónde salen las recomendaciones? → "Basado en tu estudio de mercado y tu marca..."
- [ ] ¿Los presupuestos son realistas? → Mostrar rango sugerido basado en el rubro + explicar qué esperar con ese presupuesto

**Flujo del usuario — Paso 3 (Piezas)**
- [ ] ¿El preview de anuncios se parece a cómo se verían en la plataforma real? → Mockups fieles de Google Search, Meta Feed, Meta Story
- [ ] ¿El cliente puede editar el copy generado? → Sí, campos editables con contador de caracteres y límite visual
- [ ] ¿Se muestran las restricciones de cada plataforma? → "Google Search: máximo 30 caracteres en título"
- [ ] ¿Puede regenerar una pieza individual? → Sí, botón "Generar otra opción" por pieza

**Flujo del usuario — Paso 4 (Activación)**
- [ ] ¿El cliente entiende qué pasa después de aprobar? → Explicar: "Un especialista va a revisar tu campaña y activarla en las próximas 24-48hs"
- [ ] ¿Hay feedback de que algo pasó? → Email/notificación cuando la campaña se activa
- [ ] ¿El cliente puede ver el estado en cualquier momento? → Sí, en su dashboard con status claro

**Contenido y copy**
- [ ] Todos los textos en español argentino natural (vos, no tú)
- [ ] Los mensajes de error explican qué hacer: "No pudimos conectar tu cuenta. Intentá de nuevo o contactanos"
- [ ] Los estados vacíos tienen CTAs claros, no solo "No hay datos"
- [ ] Las métricas incluyen contexto: "$ 5.230 invertidos → 132 clics → 8 consultas" (no solo números sueltos)

**Accesibilidad**
- [ ] Los botones de conectar cuentas son lo suficientemente grandes para mobile
- [ ] Los previews de anuncios son legibles en pantalla chica
- [ ] Contraste suficiente en badges de status de campañas

---

## Checklist pre-implementación

Antes de comenzar cada sub-etapa, verificar:

- [ ] El plan está aprobado por el usuario
- [ ] Las variables de entorno de sandbox están configuradas
- [ ] Las cuentas de test de Google Ads y Meta están creadas
- [ ] Los ADRs necesarios están escritos (mínimo: ADR-0019 para arquitectura de packages/ads)
- [ ] La migración de Prisma está probada en un branch separado
