const steps = [
  {
    number: '01',
    title: 'Publicá tu activo',
    description:
      'Completá el formulario con los datos de tu sitio, app o dominio. El proceso tarda menos de 10 minutos.',
  },
  {
    number: '02',
    title: 'Recibí consultas',
    description:
      'Compradores interesados te contactan directamente. Vos decidís con quién negociar y en qué términos.',
  },
  {
    number: '03',
    title: 'Cerrá la venta',
    description:
      'Acordá los términos con el comprador y coordiná la transferencia del activo de forma segura.',
  },
]

export function HowItWorks() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {steps.map((step) => (
        <div key={step.number} className="flex flex-col items-start">
          <span className="text-4xl font-bold text-amber-500 mb-4">{step.number}</span>
          <h3 className="text-lg font-semibold text-slate-50 mb-2">{step.title}</h3>
          <p className="text-sm text-slate-400 leading-relaxed">{step.description}</p>
        </div>
      ))}
    </div>
  )
}
