import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils/cn'

interface SelectOption {
  value: string
  label: string
}

interface SelectProps {
  label?: string
  options: SelectOption[]
  value?: string
  onChange?: (value: string) => void
  placeholder?: string
  error?: string
  helper?: string
  id?: string
  className?: string
  disabled?: boolean
}

export function Select({
  label,
  options,
  value,
  onChange,
  placeholder,
  error,
  helper,
  id,
  className,
  disabled,
}: SelectProps) {
  const selectId = id ?? label?.toLowerCase().replace(/\s+/g, '-')
  const errorId = selectId ? `${selectId}-error` : undefined
  const helperId = selectId ? `${selectId}-helper` : undefined

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label
          htmlFor={selectId}
          className="text-sm font-medium text-slate-400 block"
        >
          {label}
        </label>
      )}

      <div className="relative">
        <select
          id={selectId}
          value={value ?? ''}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.value)}
          aria-invalid={!!error}
          aria-describedby={error ? errorId : helper ? helperId : undefined}
          className={cn(
            'w-full appearance-none bg-slate-800 border border-slate-800 rounded-lg px-3 py-2.5 pr-9',
            'text-sm text-slate-50',
            'focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent',
            'transition-all duration-150',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            !value && 'text-slate-500',
            error && 'border-red-500 focus:ring-red-500',
            className
          )}
        >
          {placeholder && (
            <option value="" disabled>
              {placeholder}
            </option>
          )}
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-slate-400 pointer-events-none" />
      </div>

      {error ? (
        <span id={errorId} className="text-xs text-red-400">
          {error}
        </span>
      ) : helper ? (
        <span id={helperId} className="text-xs text-slate-500">
          {helper}
        </span>
      ) : null}
    </div>
  )
}
