import { type LucideIcon } from 'lucide-react'

interface TimelineStep {
  icon: LucideIcon
  title: string
  description: string
}

interface TimelineProps {
  steps: TimelineStep[]
}

export function Timeline({ steps }: TimelineProps) {
  return (
    <div className="relative ml-6">
      {/* Vertical line */}
      <div className="absolute left-0 top-3 bottom-3 w-0.5 bg-slate-800" aria-hidden />

      <div className="flex flex-col gap-8">
        {steps.map((step, i) => {
          const Icon = step.icon
          return (
            <div key={i} className="relative flex gap-6">
              {/* Dot */}
              <div className="absolute -left-[7px] top-1 size-3 rounded-full bg-amber-500 ring-4 ring-navy-950 flex-shrink-0" />

              {/* Content */}
              <div className="pl-6">
                <div className="flex items-center gap-2 mb-1">
                  <Icon className="size-4 text-amber-500" />
                  <h3 className="text-base font-semibold text-slate-50">{step.title}</h3>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">{step.description}</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
