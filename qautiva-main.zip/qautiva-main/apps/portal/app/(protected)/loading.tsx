export default function ProtectedLoading() {
  return (
    <div className="p-6 max-w-4xl mx-auto animate-pulse">
      <div className="mb-6">
        <div className="h-8 w-44 bg-[#1E293B] rounded-lg mb-2" />
        <div className="h-4 w-56 bg-[#1E293B] rounded" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
            <div className="h-5 w-32 bg-[#1E293B] rounded mb-3" />
            <div className="h-3 w-full bg-[#1E293B] rounded mb-2" />
            <div className="h-3 w-2/3 bg-[#1E293B] rounded" />
          </div>
        ))}
      </div>
    </div>
  )
}
