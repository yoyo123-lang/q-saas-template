# Sesión 05 — Interacción Comprador-Vendedor

> Pegá este prompt completo al inicio de la sesión de Claude Code.

---

## Contexto

Proyecto: **Qapitaliza** — marketplace de activos digitales.

**Sesión anterior completada:** Sesión 04 — Dashboard vendedor completo con wizard de creación, edición con tabs, StatCards y gráficos.

Esta sesión construye el lado comprador: favoritos, sistema de consultas mediadas (lista + chat), y las notificaciones por email.

Leer antes de empezar:
- `PLAN.md` — Etapa 6
- `docs/frontend/04-dashboards.md` — §5 (favoritos), §6 (lista consultas), §7 (chat)
- `docs/frontend/02-componentes-base.md` — componentes existentes

## Estado actual

Ya existe:
- Dashboard layout con Sidebar
- `<ListingCard />` con prop `isFavorited` y `onFavoriteToggle` (no conectados aún)
- Botón "Consultar al vendedor" en `/explorar/[slug]` (redirige a login por ahora)
- Botón "♡ Guardar" en `/explorar/[slug]` (redirige a login por ahora)

## Tarea de esta sesión

### 1. Sistema de favoritos

#### `src/lib/data/favorites.ts`

```ts
export async function getFavorites(userId: string): Promise<Listing[]>
export async function isFavorited(userId: string, listingId: string): Promise<boolean>
export async function getFavoriteIds(userId: string): Promise<string[]>  // para marcar cards en catálogo
```

#### `src/lib/actions/favorites.ts`

```ts
export async function toggleFavorite(listingId: string): Promise<ActionResult<{ isFavorited: boolean }>>
```

- Verificar sesión. Sin sesión → retornar `{ success: false, redirect: '/login' }`
- Si existe → borrar (unfavorite). Si no existe → insertar (favorite)
- Trackear `FAVORITE_ADDED` / `FAVORITE_REMOVED` en AuditLog

#### Conectar favoritos en el catálogo

En `src/app/(public)/explorar/page.tsx` y `/explorar/[slug]/page.tsx`:
- Si hay sesión: obtener `favoriteIds` del usuario y pasarlos a los `<ListingCard />`
- Click en ♥: llamar a `toggleFavorite()` con optimistic update (el corazón cambia inmediatamente, se revierte si falla)

#### Página de favoritos `src/app/(dashboard)/favoritos/page.tsx`

Grid 2 columnas de `<ListingCard>` con `isFavorited={true}`. Click ♥ → `toggleFavorite()` con animación de salida (la card desaparece con fade out si se desfavoritea).

`<EmptyState icon={Heart} title="Todavía no guardaste activos" description="Explorá el catálogo y guardá los que te interesen" cta={<Button href="/explorar">Explorar activos</Button>} />`

### 2. Componente Avatar

`src/components/ui/avatar.tsx` ya debe existir desde la Sesión 01. Verificar que tiene colores por rol: amber=vendedor, blue=comprador, purple=admin.

### 3. Botón "Consultar al vendedor"

Actualizar en `src/app/(public)/explorar/[slug]/page.tsx`:
- Si no hay sesión → redirigir a `/login?next=/explorar/{slug}`
- Si hay sesión y `currentUser.id === listing.sellerId` → mostrar "Este es tu activo" (button disabled con tooltip)
- Si hay sesión y puede consultar → llamar a `createInquiry(listingId)` y redirigir a `/consultas/{id}` recién creada

### 4. Data access layer `src/lib/data/inquiries.ts`

```ts
export async function getInquiries(userId: string, params: InquiryQueryParams): Promise<PaginatedInquiries>
export async function getInquiry(id: string, userId: string): Promise<InquiryWithMessages | null>
export async function getInquiryMessages(inquiryId: string): Promise<InquiryMessage[]>
```

`getInquiry`: verificar que el usuario es comprador O vendedor del listing antes de retornar datos.

### 5. Server Actions `src/lib/actions/inquiries.ts`

```ts
export async function createInquiry(listingId: string): Promise<ActionResult<{ inquiryId: string }>>
export async function sendMessage(inquiryId: string, content: string): Promise<ActionResult<InquiryMessage>>
export async function closeInquiry(inquiryId: string): Promise<ActionResult>
```

**`createInquiry` validaciones:**
- Verificar sesión
- `listing.sellerId !== currentUser.id` — no puede consultar su propio activo
- `listing.status === 'PUBLISHED'` — solo activos publicados
- No existe otra `inquiry` del mismo comprador en el mismo listing (unique constraint en DB)
- Rate limiting: máx 10 consultas nuevas por día por usuario (con Upstash Redis)
- Trackear `INQUIRY_SENT` en AuditLog

**`sendMessage` validaciones:**
- Verificar sesión
- Verificar que el usuario es comprador O vendedor de la consulta (no terceros)
- `inquiry.status !== 'CLOSED'` — no se puede escribir en consultas cerradas
- Content mínimo 1 char, máximo 5000

**`closeInquiry` validaciones:**
- Solo el comprador puede cerrar la consulta
- Trackear `INQUIRY_CLOSED` en AuditLog

### 6. Componente `<InquiryCard />`

`src/components/listings/inquiry-card.tsx`. Props: inquiry con buyer/seller/listing data.

Estructura:
```
bg-navy-900 border border-slate-800 rounded-xl p-5
hover:bg-slate-800 cursor-pointer transition-colors
```

No leída: `border-l-4 border-l-amber-500`

Contenido: `<Avatar />` + nombre del otro participante (si soy comprador: nombre del vendedor; si soy vendedor: nombre del comprador) + "·" + nombre del activo (link amber a `/explorar/{slug}`) + preview del último mensaje (truncado) + timestamp + `<Badge>` de estado.

### 7. Lista de consultas `/consultas`

`src/app/(dashboard)/consultas/page.tsx`.

Tabs: Todas | Abiertas | Respondidas | Cerradas (con conteo). Implementado como searchParam `?status=`.

Stack vertical de `<InquiryCard>`. Click → navega a `/consultas/{id}`.

`<EmptyState>` si no hay consultas.

### 8. Chat `/consultas/[id]`

`src/app/(dashboard)/consultas/[id]/page.tsx` — Client Component (necesita estado local para el input y optimistic updates).

Ver `docs/frontend/04-dashboards.md` §7.

**Layout 2 columnas:**
- 65%: thread de mensajes + input sticky
- 35%: card info del activo sticky

**Thread de mensajes:**
- Mensajes propios (auth.uid() === message.senderId): alineados derecha, burbuja `bg-amber-500/15 border-amber-500/20`
- Mensajes del otro: alineados izquierda, `bg-navy-900 border-slate-800` con `<Avatar />` + nombre arriba

**Scroll automático:** `useEffect` que hace scroll al último mensaje cuando cambia la lista.

**Input sticky:**
```tsx
<Textarea rows={2} placeholder="Escribí tu mensaje..." />
<Button variant="solid" icon={<Send />}>Enviar</Button>
```
- Enter sin Shift → enviar
- Shift+Enter → nueva línea
- **Optimistic update:** agregar el mensaje localmente antes de que la Server Action responda. Si falla: remover y mostrar toast de error.

**Columna info del activo:** screenshot mini, título, precio amber, badge verificado, métricas clave, info vendedor con `<Avatar />`, link "Ver listado completo →".

**Header del chat:** breadcrumb, título "Consulta sobre {activo}", `<Badge>` estado, botón "Cerrar consulta" (outline gris, pequeño) → Modal confirm → `closeInquiry()`.

### 9. Notificaciones por email

`src/lib/notifications/email.ts`:

```ts
export async function sendNewInquiryEmail(to: string, listingTitle: string, buyerName: string): Promise<void>
export async function sendNewMessageEmail(to: string, listingTitle: string, senderName: string): Promise<void>
```

Usar Resend (`resend` npm package). Templates en texto plano para el MVP (sin HTML complejo).

Llamar desde las Server Actions:
- `createInquiry` → email al vendedor
- `sendMessage` → email al otro participante (si la última notificación fue hace más de 1 hora, para no spamear)

### 10. Schema Zod `src/lib/schemas/inquiry.ts`

```ts
export const sendMessageSchema = z.object({
  content: z.string().min(1).max(5000),
})
```

### 11. Tests

`src/lib/actions/__tests__/inquiries.test.ts`:
- `createInquiry` con propio activo → error
- `createInquiry` exitoso → inquiry creada, AuditLog generado
- `sendMessage` de tercero → error
- `sendMessage` en consulta cerrada → error
- Rate limiting: 11va consulta en el día → rechazada
- `closeInquiry` por el vendedor → error (solo comprador)
- `toggleFavorite`: crear y borrar favorito

## Reglas

- El optimistic update del chat debe revertirse si la Server Action falla — nunca dejar un mensaje fantasma
- Las validaciones de permisos (IDOR, participante) van en la Server Action, NO solo en el cliente
- El rate limiting de consultas es por `userId`, no por IP

## Checkpoint

La sesión está completa cuando:
- [ ] Favoritos: toggle funciona con optimistic update desde catálogo y desde `/favoritos`
- [ ] "Consultar al vendedor": flujo completo (no logueado → login, propio activo → disabled, funciona → crea inquiry)
- [ ] Lista de consultas con tabs y cards
- [ ] Chat con mensajes en burbujas diferenciadas, Enter-para-enviar, optimistic update
- [ ] Botón "Cerrar consulta" con Modal de confirmación funcional
- [ ] Emails enviados al crear consulta y al enviar mensaje
- [ ] Rate limiting activo (11va consulta rechazada)
- [ ] Tests pasan
- [ ] `npm run build` sin errores
