'use client'

import { useState, useTransition } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Search } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'
import { ListingCard } from '@/components/listings/listing-card'
import { Pagination } from '@/components/ui/pagination'
import { SkeletonCard } from '@/components/ui/skeleton-card'
import { EmptyState } from '@/components/shared/empty-state'
import { toggleFavorite } from '@/lib/actions/favorites'

const sortOptions = [
  { value: 'newest', label: 'Más recientes' },
  { value: 'price_asc', label: 'Precio: menor a mayor' },
  { value: 'price_desc', label: 'Precio: mayor a menor' },
  { value: 'views', label: 'Más vistos' },
]

interface ListingItem {
  id: string
  slug: string
  title: string
  type: string
  askingPrice: number | string
  screenshotUrls: string[]
  techStack: string[]
  verificationStatus: string
  featuredUntil?: Date | string | null
  monthlyRevenue?: number | string | null
  monthlyTraffic?: number | null
}

interface ResultsGridProps {
  items: ListingItem[]
  total: number
  currentPage: number
  pageSize?: number
  loading?: boolean
  /** IDs of listings favorited by the current user. Only passed when authenticated. */
  initialFavoriteIds?: string[]
  /** Whether the user is authenticated. Controls whether favorite toggle is enabled. */
  isAuthenticated?: boolean
}

export function ResultsGrid({
  items,
  total,
  currentPage,
  pageSize = 20,
  loading = false,
  initialFavoriteIds = [],
  isAuthenticated = false,
}: ResultsGridProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const totalPages = Math.ceil(total / pageSize)
  const sort = searchParams.get('sort') ?? 'newest'

  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(
    new Set(initialFavoriteIds)
  )
  const [, startTransition] = useTransition()

  function setSort(value: string) {
    const params = new URLSearchParams(searchParams.toString())
    params.set('sort', value)
    params.delete('page')
    router.push(`/explorar?${params.toString()}`)
  }

  function setPage(page: number) {
    const params = new URLSearchParams(searchParams.toString())
    if (page === 1) {
      params.delete('page')
    } else {
      params.set('page', page.toString())
    }
    router.push(`/explorar?${params.toString()}`)
  }

  function handleFavoriteToggle(listingId: string) {
    // Optimistic update
    setFavoriteIds((prev) => {
      const next = new Set(prev)
      if (next.has(listingId)) {
        next.delete(listingId)
      } else {
        next.add(listingId)
      }
      return next
    })

    startTransition(async () => {
      const result = await toggleFavorite(listingId)
      if (!result.success) {
        // Revert
        setFavoriteIds((prev) => {
          const next = new Set(prev)
          if (next.has(listingId)) {
            next.delete(listingId)
          } else {
            next.add(listingId)
          }
          return next
        })
        toast.error(result.error ?? 'Error al actualizar favoritos.')
        return
      }
      if (result.data) {
        toast.success(result.data.isFavorited ? 'Guardado en favoritos' : 'Eliminado de favoritos')
      }
    })
  }

  return (
    <div className="flex-1 flex flex-col gap-6">
      {/* Top bar */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">
          <span className="font-semibold text-slate-50">{total}</span> resultados
        </p>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-slate-50 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
        >
          {sortOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={<Search className="size-6" />}
          title="Sin resultados"
          description="Probá con otros filtros o términos de búsqueda."
          cta={<Link href="/explorar" className="text-sm text-amber-500 hover:underline">Limpiar filtros</Link>}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item) => {
            const price = typeof item.askingPrice === 'string'
              ? parseFloat(item.askingPrice)
              : item.askingPrice

            const mrr = item.monthlyRevenue != null
              ? (typeof item.monthlyRevenue === 'string'
                  ? parseFloat(item.monthlyRevenue)
                  : item.monthlyRevenue)
              : undefined

            const badges: ('verified' | 'featured' | 'premium')[] = []
            if (item.verificationStatus === 'VERIFIED') badges.push('verified')
            if (item.featuredUntil && new Date(item.featuredUntil) > new Date())
              badges.push('featured')

            return (
              <ListingCard
                key={item.id}
                id={item.id}
                slug={item.slug}
                title={item.title}
                type={item.type}
                priceUsd={price}
                screenshot={item.screenshotUrls[0]}
                metrics={{
                  mrr: mrr ?? undefined,
                  monthlyVisits: item.monthlyTraffic ?? undefined,
                }}
                techStack={item.techStack}
                badges={badges}
                isFavorited={favoriteIds.has(item.id)}
                onFavoriteToggle={isAuthenticated ? handleFavoriteToggle : undefined}
              />
            )
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center mt-4">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setPage}
          />
        </div>
      )}
    </div>
  )
}
