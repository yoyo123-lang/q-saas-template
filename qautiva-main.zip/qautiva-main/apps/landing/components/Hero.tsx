/** Visualización de los 6 nodos del proceso — solo desktop */
function ProcessNodes() {
  const nodes = [
    { n: 1, done: true },
    { n: 2, done: true },
    { n: 3, done: false, active: true },
    { n: 4, done: false },
    { n: 5, done: false },
    { n: 6, done: false },
  ]

  return (
    <div className="flex flex-col items-center gap-0" aria-hidden="true">
      {nodes.map(({ n, done, active }, i) => (
        <div key={n} className="flex flex-col items-center">
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold border-2 ${
              active
                ? 'bg-accent border-accent text-white'
                : done
                ? 'bg-transparent border-status-success text-status-success'
                : 'bg-transparent border-navy-800 text-slate-600'
            }`}
            style={
              active
                ? { boxShadow: '0 0 20px rgba(139,92,246,0.6), 0 0 40px rgba(139,92,246,0.2)' }
                : done
                ? { boxShadow: '0 0 8px rgba(16,185,129,0.3)' }
                : undefined
            }
          >
            {done ? (
              <svg
                width="14"
                height="14"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              n
            )}
          </div>
          {i < nodes.length - 1 && (
            <div
              className="w-0.5 h-7"
              style={{
                background: done
                  ? '#10B981'
                  : active
                  ? 'linear-gradient(to bottom, #8B5CF6, #374151)'
                  : '#1E293B',
              }}
            />
          )}
        </div>
      ))}
    </div>
  )
}

export function Hero() {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center bg-navy-950 overflow-hidden"
    >
      {/* Mesh gradient animado */}
      <div className="hero-mesh absolute inset-0 pointer-events-none" aria-hidden="true" />

      <div className="relative max-w-6xl mx-auto px-6 pt-24 pb-16 w-full">
        <div className="flex items-center justify-between gap-16">
          {/* Contenido izquierdo */}
          <div className="flex-1 max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight mb-6 animate-fade-up">
              Tu negocio online en{' '}
              <span className="text-accent">una semana.</span>
            </h1>

            <p className="text-lg text-slate-400 mb-8 leading-relaxed animate-fade-up delay-100">
              La IA hace todo: marca, web, campañas y presencia en medios.
              <br className="hidden sm:block" />
              Vos solo aprobás.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 mb-6 animate-fade-up delay-200">
              <a
                href="#precios"
                className="inline-flex items-center justify-center bg-accent hover:bg-accent-light text-white font-medium px-6 py-3 rounded-lg transition-colors duration-200"
              >
                Lanzá tu negocio
              </a>
              <a
                href="#como-funciona"
                className="inline-flex items-center justify-center border border-accent text-accent hover:bg-accent hover:text-white font-medium px-6 py-3 rounded-lg transition-colors duration-200"
              >
                Ver cómo funciona
              </a>
            </div>

            <p className="text-sm text-slate-500 animate-fade-up delay-300">
              Sin compromiso. Sin reuniones. Todo online.
            </p>
          </div>

          {/* Visual derecha — solo desktop */}
          <div className="hidden lg:flex items-center justify-center w-56 shrink-0 animate-fade-in delay-400">
            <div
              className="relative p-8 rounded-2xl border border-navy-800"
              style={{ background: 'rgba(15,23,42,0.8)', backdropFilter: 'blur(8px)' }}
            >
              <p className="text-xs text-slate-500 tracking-widest uppercase mb-6 text-center">
                Tu proceso
              </p>
              <ProcessNodes />
              <p className="text-xs text-accent text-center mt-6 font-medium">
                Etapa 3 activa
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
