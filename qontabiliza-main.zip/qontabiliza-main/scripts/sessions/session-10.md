# Sesión 10: Reportes, dashboard y suscripciones

## Contexto

Leé estos archivos antes de empezar:
- ROADMAP.md → Sesión 10
- SESSION_LOG.md → qué se hizo antes
- docs/PLANNING.md, docs/TDD.md, docs/CONVENTIONS.md

## Objetivo

Dashboard con métricas clave, reportes de ventas, libro IVA, cuentas a cobrar. Planes de suscripción con límites.

## Pre-requisitos

Sesión 9 completada (POS funcional).

## Etapas

### Etapa 1: Dashboard
- Widgets: ventas del día (monto), ventas del mes, stock bajo (cantidad), facturas pendientes de cobro
- Gráfico de ventas de los últimos 30 días (línea)
- Top 5 productos más vendidos del mes
- Accesos rápidos: nueva venta, nuevo producto, nueva factura

### Etapa 2: Reportes de ventas
- Reporte diario: ventas por medio de pago, total
- Reporte mensual: ventas por día, gráfico de barras
- Reporte por producto: unidades vendidas, monto, rentabilidad
- Filtros de fecha y exportación a CSV/PDF

### Etapa 3: Libro IVA y cuentas a cobrar
- Libro IVA ventas: listado de comprobantes con IVA discriminado (requerido por ARCA)
- Filtro por período fiscal (mes/año)
- Cuentas a cobrar: facturas emitidas sin cobrar, antigüedad de saldos
- Exportación a CSV

### Etapa 4: Sistema de planes y billing
- Modelo Plan: Micro (gratis), Starter, Pro, Max
- Límites por plan: cantidad de usuarios, comprobantes/mes, productos
- Enforcement en API: si se alcanza el límite, retornar 402 con mensaje claro
- Página de billing: plan actual, uso, botón de upgrade
- Preparar integración con pasarela de pago (interfaz, no implementación real)

## Proceso obligatorio

1. Creá el IMPLEMENTATION_PLAN.md para esta sesión
2. TDD: test primero → código después
3. Un commit por tarea atómica
4. Al terminar: build + lint + test deben pasar
