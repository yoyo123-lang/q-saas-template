import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

const mockRequireAdminSession = vi.fn()
const mockMediumFindUnique = vi.fn()
const mockMediumUpdate = vi.fn()

vi.mock('@/lib/supabase-server', () => ({
  requireAdminSession: mockRequireAdminSession,
}))

vi.mock('@qautiva/db', () => ({
  prisma: {
    medium: {
      findUnique: mockMediumFindUnique,
      update: mockMediumUpdate,
    },
  },
}))

function makeRequest(
  body: unknown,
  id = 'medium-1',
): [NextRequest, { params: { id: string } }] {
  const req = new NextRequest(
    `http://localhost:3001/api/marketplace/media/${id}`,
    {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
  )
  return [req, { params: { id } }]
}

describe('PATCH /api/marketplace/media/[id]', () => {
  beforeEach(() => {
    vi.resetModules()
    mockRequireAdminSession.mockReset()
    mockMediumFindUnique.mockReset()
    mockMediumUpdate.mockReset()
  })

  it('devuelve 401 si no hay sesión de admin', async () => {
    mockRequireAdminSession.mockRejectedValueOnce(new Error('No autorizado'))

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(401)
  })

  it('devuelve 400 si el body es inválido', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const req = new NextRequest('http://localhost:3001/api/marketplace/media/m-1', {
      method: 'PATCH',
      body: 'not-json',
    })
    const res = await PATCH(req, { params: { id: 'm-1' } })

    expect(res.status).toBe(400)
  })

  it('devuelve 400 si action no es "approve" ni "reject"', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'suspend' })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/approve.*reject/i)
  })

  it('devuelve 400 si action es "reject" sin reason', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'reject' })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
    const data = await res.json()
    expect(data.error).toMatch(/reason/i)
  })

  it('devuelve 400 si action es "reject" con reason solo espacios', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'reject', reason: '   ' })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
  })

  it('devuelve 400 si reason supera 1000 caracteres', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'reject', reason: 'x'.repeat(1001) })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(400)
  })

  it('devuelve 404 si el medio no existe', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce(null)

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(404)
  })

  it('devuelve 409 si el medio no está en PENDING_REVIEW', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({
      id: 'medium-1',
      status: 'ACTIVE',
      name: 'Test Blog',
    })

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(409)
    const data = await res.json()
    expect(data.error).toMatch(/pendiente/i)
  })

  it('aprueba un medio PENDING_REVIEW → ACTIVE', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({
      id: 'medium-1',
      status: 'PENDING_REVIEW',
      name: 'Test Blog',
    })
    mockMediumUpdate.mockResolvedValueOnce({ id: 'medium-1', status: 'ACTIVE' })

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'approve' })
    const res = await PATCH(req, ctx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(data.status).toBe('ACTIVE')
    expect(mockMediumUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'ACTIVE' }),
      }),
    )
  })

  it('rechaza un medio PENDING_REVIEW → REJECTED con motivo', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({
      id: 'medium-1',
      status: 'PENDING_REVIEW',
      name: 'Test Blog',
    })
    mockMediumUpdate.mockResolvedValueOnce({ id: 'medium-1', status: 'REJECTED' })

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'reject', reason: 'Contenido inapropiado' })
    const res = await PATCH(req, ctx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.ok).toBe(true)
    expect(data.status).toBe('REJECTED')
    expect(mockMediumUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: 'REJECTED',
          rejectionReason: 'Contenido inapropiado',
        }),
      }),
    )
  })

  it('acepta reason exactamente de 1000 caracteres', async () => {
    mockRequireAdminSession.mockResolvedValueOnce(undefined)
    mockMediumFindUnique.mockResolvedValueOnce({
      id: 'medium-1',
      status: 'PENDING_REVIEW',
      name: 'Test Blog',
    })
    mockMediumUpdate.mockResolvedValueOnce({ id: 'medium-1', status: 'REJECTED' })

    const { PATCH } = await import('../../../app/api/marketplace/media/[id]/route')
    const [req, ctx] = makeRequest({ action: 'reject', reason: 'x'.repeat(1000) })
    const res = await PATCH(req, ctx)

    expect(res.status).toBe(200)
  })
})
