# Sesión 07: Stock básico

## Objetivo
Control de stock con un depósito: movimientos de entrada/salida, vista de stock actual por producto, alertas de stock bajo, historial de movimientos, ajuste manual de inventario. Al terminar, el sistema trackea stock y está listo para integrarse con ventas (S08).

## Pre-requisitos
- Sesión 03 completada (productos)
- Modelos Warehouse y StockMovement ya existen en schema (S01)

## Al iniciar
1. Leer `ROADMAP.md`
2. Leer `prisma/schema.prisma` — modelos Warehouse, StockMovement, Product (campo trackStock, minStock)
3. Leer `src/app/api/v1/products/` (para entender la API de productos existente)
4. Leer `src/components/shared/product-search.tsx` (se reutiliza)

**Nota**: Esta sesión puede ejecutarse en paralelo con S04-S06 si se usa un worktree separado (depende solo de S03).

---

## Etapa 1: Servicio de stock

### Tarea 1.1: StockService
**Archivo nuevo**: `src/lib/services/stock-service.ts`

```typescript
// Servicio que gestiona el stock del sistema.
//
// Métodos:
//
// getCurrentStock(organizationId, productId, warehouseId?): Promise<number>
//   - SUM de stockMovements.quantity filtrado por org + producto + warehouse
//   - Si no se pasa warehouseId, suma de todos los warehouses (para Fase 1 hay uno solo)
//
// getStockByProduct(organizationId, warehouseId?): Promise<ProductStock[]>
//   - Retorna array de { productId, productName, currentStock, minStock, isLow }
//   - isLow = currentStock <= minStock
//   - Ordenado por nombre de producto
//   - Solo productos con trackStock = true
//
// getLowStockProducts(organizationId): Promise<ProductStock[]>
//   - Filtra solo los productos con isLow = true
//
// registerMovement(params: RegisterMovementParams): Promise<StockMovement>
//   - Crea un StockMovement
//   - params: { organizationId, warehouseId, productId, type, quantity, reference?, referenceId?, notes? }
//   - quantity es siempre positivo en params. El servicio determina el signo:
//     PURCHASE, RETURN, INITIAL, ADJUSTMENT(positivo) → +quantity
//     SALE, ADJUSTMENT(negativo) → -quantity
//   - Para SALE: validar que hay stock suficiente (si trackStock = true)
//     Si no hay stock suficiente, lanzar error descriptivo
//
// registerSaleMovements(organizationId, warehouseId, saleItems: SaleItem[]): Promise<void>
//   - Bulk: registra un movimiento SALE por cada item
//   - Transaccional: si uno falla, se revierte todo
//   - Este método lo usa SaleService en S08
//
// adjustStock(organizationId, warehouseId, productId, newQuantity: number, notes?: string): Promise<void>
//   - Calcula diferencia entre stock actual y newQuantity
//   - Registra movimiento ADJUSTMENT con la diferencia
//   - Ej: stock actual 10, newQuantity 8 → movimiento -2
```

### Tarea 1.2: Tests unitarios de StockService
**Archivo nuevo**: `src/lib/services/__tests__/stock-service.test.ts`

Tests:
- `getCurrentStock` suma movimientos correctamente (positivos y negativos)
- `getCurrentStock` retorna 0 si no hay movimientos
- `registerMovement` tipo SALE resta stock
- `registerMovement` tipo PURCHASE suma stock
- `registerMovement` tipo SALE falla si no hay stock suficiente
- `adjustStock` calcula diferencia correctamente
- `getStockByProduct` retorna isLow correcto
- `getLowStockProducts` filtra solo los que tienen stock bajo

**Commit**: `feat(stock): add StockService with movement tracking and validation`

---

## Etapa 2: API routes de stock

### Tarea 2.1: Validaciones Zod
**Archivo nuevo**: `src/lib/validations/stock.ts`

Schemas:
- `registerMovementSchema`:
  - productId (cuid, requerido)
  - warehouseId (cuid, requerido)
  - type (enum: PURCHASE, SALE, ADJUSTMENT, RETURN, INITIAL)
  - quantity (number, min 0.0001, requerido)
  - notes (optional string)
- `adjustStockSchema`:
  - productId (cuid, requerido)
  - warehouseId (cuid, requerido)
  - newQuantity (number, min 0)
  - notes (optional string)
- `stockFilterSchema`: productId, warehouseId, type, dateFrom, dateTo, page, perPage

### Tarea 2.2: API routes
**Archivos nuevos**:
- `src/app/api/v1/stock/route.ts` — GET (stock actual por producto, paginado y filtrable)
- `src/app/api/v1/stock/movements/route.ts` — GET (historial de movimientos), POST (registrar movimiento)
- `src/app/api/v1/stock/adjust/route.ts` — POST (ajuste de inventario)
- `src/app/api/v1/stock/low/route.ts` — GET (productos con stock bajo)

Comportamiento:
- GET stock: retorna lista de productos con stock actual, filtrable por warehouse, búsqueda
- GET movements: historial paginado, filtrable por producto, tipo, rango de fechas
- POST movement: solo roles OWNER, ADMIN, SELLER
- POST adjust: solo roles OWNER, ADMIN

### Tarea 2.3: Tests de integración
**Archivo nuevo**: `src/app/api/v1/stock/__tests__/stock.test.ts`

Tests:
- Registrar movimiento de entrada, verificar stock
- Registrar movimiento de salida, verificar stock
- Intentar venta sin stock suficiente → error
- Ajuste de inventario
- Listar stock con filtros
- Historial de movimientos
- Tenant isolation

**Commit**: `feat(api): add stock endpoints (current stock, movements, adjustments)`

---

## Etapa 3: Frontend — Stock actual y alertas

### Tarea 3.1: Hook useStock
**Archivo nuevo**: `src/hooks/use-stock.ts`

Hook que expone:
- `stockItems`: lista de productos con stock actual
- `lowStockItems`: productos con stock bajo
- `isLoading`, `error`
- `registerMovement(data)`, `adjustStock(data)`
- `filters`, `setFilters`, `pagination`, `setPage`

### Tarea 3.2: Página de stock actual
**Archivo nuevo**: `src/app/dashboard/stock/page.tsx`

Layout:
- Título "Stock" con breadcrumb
- Alerta superior si hay productos con stock bajo: "⚠️ X productos con stock bajo" (link a filtro)
- Barra de filtros: búsqueda, categoría
- DataTable con columnas:
  - Producto (nombre)
  - SKU
  - Stock actual (número con color: rojo si bajo, verde si OK)
  - Stock mínimo
  - Estado (badge: "OK", "Bajo", "Sin stock")
  - Acciones: "Ajustar", "Ver movimientos"
- Botón "Registrar movimiento" (entrada manual)

Formato: cantidades con hasta 4 decimales si corresponde, sino enteros.

### Tarea 3.3: Componente de alerta de stock bajo
**Archivo nuevo**: `src/components/stock/low-stock-alert.tsx`

Componente reutilizable que se puede mostrar en:
- Página de stock (banner superior)
- Dashboard (widget)
- Sidebar (badge con count)

Muestra: icono de alerta + "X productos con stock bajo" + link a la página de stock filtrada.

**Commit**: `feat(ui): add stock current view with low stock alerts`

---

## Etapa 4: Frontend — Movimientos y ajustes

### Tarea 4.1: Página de historial de movimientos
**Archivo nuevo**: `src/app/dashboard/stock/movements/page.tsx`

Layout:
- Título "Movimientos de stock"
- Filtros: producto (dropdown o búsqueda), tipo de movimiento (dropdown), rango de fechas
- DataTable con columnas:
  - Fecha (formato argentino)
  - Producto
  - Tipo (badge con color: verde=entrada, rojo=salida, amarillo=ajuste)
  - Cantidad (con signo: +10, -5)
  - Referencia (ej: "Venta #123", "Ajuste manual")
  - Notas
- Paginación
- Exportar (nice-to-have, omitir si no alcanza el tiempo)

### Tarea 4.2: Formulario de registrar movimiento
**Archivo nuevo**: `src/app/dashboard/stock/movements/new/page.tsx`

Formulario:
- Tipo de movimiento: dropdown (Compra/Ingreso, Ajuste, Devolución, Carga inicial)
  - SALE no aparece acá — las ventas generan movimientos automáticos en S08
- Producto: usar `ProductSearch`
- Cantidad (input numérico, positivo)
- Notas (textarea opcional)
- Botón "Registrar"

### Tarea 4.3: Dialog de ajuste de inventario
**Archivo nuevo**: `src/components/stock/adjust-stock-dialog.tsx`

Dialog/modal (se abre desde la acción "Ajustar" en la tabla de stock):
- Muestra: producto, stock actual
- Input: "Stock real" (el número que contó el usuario)
- Cálculo automático: "Diferencia: +X / -X"
- Input: notas (ej: "Conteo físico mensual")
- Botón "Aplicar ajuste"

**Commit**: `feat(ui): add stock movements page and inventory adjustment`

---

## Checklist de cierre de sesión

- [ ] StockService con cálculo de stock, movimientos, y validaciones
- [ ] API routes de stock (actual, movimientos, ajustes, stock bajo)
- [ ] Página de stock actual con tabla y alertas de stock bajo
- [ ] Historial de movimientos con filtros
- [ ] Formulario de registrar movimiento manual
- [ ] Dialog de ajuste de inventario
- [ ] Componente de alerta de stock bajo (reutilizable)
- [ ] Tests unitarios y de integración
- [ ] Tenant isolation verificado
- [ ] `npm run build` pasa sin errores
- [ ] Todos los commits pusheados
- [ ] `SESSION_LOG.md` actualizado
