type Platform = 'google' | 'meta'

type CampaignCardProps = {
  platform: Platform
  name: string
  monthlySpend: number
  clicks?: number
  conversions?: number
  isActive: boolean
}

function PlatformIcon({ platform }: { platform: Platform }) {
  if (platform === 'google') {
    return (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-label="Google">
        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
      </svg>
    )
  }
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="#1877F2" aria-label="Meta">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
    </svg>
  )
}

import { formatARSPerMonth as formatARS } from '@/lib/format'

/**
 * Card de campaña publicitaria (Google Ads o Meta Ads).
 * Muestra solo datos reales disponibles en DB (spend mensual).
 * Los campos clicks y conversions son opcionales — no se muestran si no hay datos reales.
 * @param clicks - clics reales de la plataforma (no estimados). Omitir si no hay dato.
 * @param conversions - conversiones reales. Omitir si no hay dato.
 */
export function CampaignCard({
  platform,
  name,
  monthlySpend,
  clicks,
  conversions,
  isActive,
}: CampaignCardProps) {
  return (
    <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#1E293B] flex items-center justify-center flex-shrink-0">
            <PlatformIcon platform={platform} />
          </div>
          <div>
            <p className="text-[#64748B] text-xs">{platform === 'google' ? 'Google Ads' : 'Meta Ads'}</p>
            <p className="text-white font-semibold text-sm">{name}</p>
          </div>
        </div>
        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
          isActive
            ? 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30'
            : 'bg-[#64748B]/15 text-[#64748B] border border-[#64748B]/30'
        }`}>
          {isActive ? 'Activa' : 'Pausada'}
        </span>
      </div>

      <div className={`grid gap-3 ${clicks !== undefined || conversions !== undefined ? 'grid-cols-3' : 'grid-cols-1'}`}>
        <div>
          <p className="text-[#64748B] text-xs mb-0.5">Inversión</p>
          <p className="text-white font-semibold text-sm">{formatARS(monthlySpend)}</p>
        </div>
        {clicks !== undefined && (
          <div>
            <p className="text-[#64748B] text-xs mb-0.5">Clics</p>
            <p className="text-white font-semibold text-sm">{clicks.toLocaleString('es-AR')}</p>
          </div>
        )}
        {conversions !== undefined && (
          <div>
            <p className="text-[#64748B] text-xs mb-0.5">Consultas</p>
            <p className="text-white font-semibold text-sm">{conversions.toLocaleString('es-AR')}</p>
          </div>
        )}
      </div>

      {clicks !== undefined && clicks > 0 && conversions !== undefined && conversions > 0 && (
        <p className="text-[#64748B] text-xs mt-3">
          De cada 100 personas que ven tu anuncio,{' '}
          <span className="text-[#94A3B8]">{Math.round((conversions / clicks) * 100)} hacen clic</span>
        </p>
      )}
    </div>
  )
}
