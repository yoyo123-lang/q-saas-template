import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import Link from 'next/link'
import { cookies } from 'next/headers'
import { prisma } from '@qautiva/db'
import { createServerClient } from '@/lib/supabase-server'
import { OrderStatusBadge } from '@/lib/order-status'
import { EditorActions } from './EditorActions'
import { OrderChatBox } from '@/components/OrderChatBox'
import { formatARS, formatDate } from '@/lib/format'

export const metadata: Metadata = { title: 'Detalle de venta — Qautiva' }

export default async function VentaDetailPage({
  params,
}: {
  params: { orderId: string }
}) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect(`/login?next=/mis-ventas/${params.orderId}`)

  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { id: true },
  })
  if (!profile) redirect('/login')

  const order = await prisma.order.findUnique({
    where: { id: params.orderId },
    select: {
      id: true,
      advertiserId: true,
      status: true,
      brief: true,
      targetUrl: true,
      anchorText: true,
      price: true,
      commission: true,
      editorPayout: true,
      deliveryUrl: true,
      deliveryNotes: true,
      expiresAt: true,
      deliveryDeadline: true,
      createdAt: true,
      acceptedAt: true,
      deliveredAt: true,
      completedAt: true,
      cancelledAt: true,
      cancellationReason: true,
      rating: true,
      ratingComment: true,
      product: { select: { id: true, name: true, type: true, deliveryDays: true } },
      medium: { select: { id: true, name: true, platform: true, userId: true } },
      advertiser: { select: { displayName: true } },
    },
  })

  if (!order) notFound()
  // Solo el editor del medio puede ver esta venta
  if (order.medium.userId !== profile.id) notFound()

  return (
    <div className="p-6 max-w-3xl mx-auto flex flex-col gap-6">
      {/* Breadcrumb */}
      <nav aria-label="Navegación" className="text-sm text-[#64748B] flex items-center gap-2 flex-wrap">
        <Link href="/mis-ventas" className="hover:text-[#94A3B8] transition-colors">Mis Ventas</Link>
        <span>/</span>
        <span className="text-[#94A3B8] truncate">{order.product.name}</span>
      </nav>

      {/* Header */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
        <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <OrderStatusBadge status={order.status} />
            </div>
            <h1 className="text-white font-bold text-lg">{order.product.name}</h1>
            <p className="text-[#64748B] text-sm">
              {order.medium.name}
              {order.advertiser.displayName ? ` · de ${order.advertiser.displayName}` : ''}
            </p>
          </div>
          <div className="text-right">
            <p className="text-[#34D399] font-bold text-xl">{formatARS(order.editorPayout?.toNumber() ?? 0)}</p>
            <p className="text-[#475569] text-xs">Tu pago neto</p>
            <p className="text-[#475569] text-xs">Creado: {formatDate(order.createdAt)}</p>
          </div>
        </div>

        {/* Fechas clave */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <p className="text-[#64748B]">Expira (aceptación)</p>
            <p className="text-[#94A3B8]">{formatDate(order.expiresAt)}</p>
          </div>
          {order.acceptedAt && (
            <div>
              <p className="text-[#64748B]">Aceptado</p>
              <p className="text-[#94A3B8]">{formatDate(order.acceptedAt)}</p>
            </div>
          )}
          {order.deliveryDeadline && (
            <div>
              <p className="text-[#64748B]">Entrega límite</p>
              <p className="text-[#94A3B8]">{formatDate(order.deliveryDeadline)}</p>
            </div>
          )}
          {order.completedAt && (
            <div>
              <p className="text-[#64748B]">Completado</p>
              <p className="text-[#34D399]">{formatDate(order.completedAt)}</p>
            </div>
          )}
          {order.cancelledAt && (
            <div>
              <p className="text-[#64748B]">Cancelado</p>
              <p className="text-red-400">{formatDate(order.cancelledAt)}</p>
            </div>
          )}
        </div>
      </div>

      {/* Brief del anunciante */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-4">
        <h2 className="text-white font-semibold">Brief del anunciante</h2>
        <p className="text-[#94A3B8] text-sm leading-relaxed whitespace-pre-wrap">{order.brief}</p>
        {order.targetUrl && (
          <div>
            <p className="text-[#64748B] text-xs mb-1">URL destino del enlace</p>
            <a href={order.targetUrl} target="_blank" rel="noopener noreferrer" className="text-[#60A5FA] text-sm hover:underline break-all">
              {order.targetUrl}
            </a>
          </div>
        )}
        {order.anchorText && (
          <div>
            <p className="text-[#64748B] text-xs mb-1">Texto ancla deseado</p>
            <p className="text-[#94A3B8] text-sm">{order.anchorText}</p>
          </div>
        )}
        {order.cancellationReason && (
          <div>
            <p className="text-[#64748B] text-xs mb-1">Correcciones solicitadas</p>
            <p className="text-orange-400 text-sm leading-relaxed">{order.cancellationReason}</p>
          </div>
        )}
      </div>

      {/* Tu entrega */}
      {order.deliveryUrl && (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5 flex flex-col gap-3">
          <h2 className="text-white font-semibold">Tu entrega</h2>
          <div>
            <p className="text-[#64748B] text-xs mb-1">URL publicada</p>
            <a href={order.deliveryUrl} target="_blank" rel="noopener noreferrer" className="text-[#60A5FA] text-sm hover:underline break-all">
              {order.deliveryUrl}
            </a>
          </div>
          {order.deliveryNotes && (
            <p className="text-[#94A3B8] text-sm leading-relaxed">{order.deliveryNotes}</p>
          )}
          <p className="text-[#475569] text-xs">Entregado: {formatDate(order.deliveredAt)}</p>
        </div>
      )}

      {/* Financiero */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
        <h2 className="text-white font-semibold mb-3">Financiero</h2>
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Precio del producto</span>
            <span className="text-white">{formatARS(order.price?.toNumber() ?? 0)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#94A3B8]">Comisión Qautiva (10%)</span>
            <span className="text-red-400">− {formatARS(order.commission?.toNumber() ?? 0)}</span>
          </div>
          <hr className="border-[#1E293B]" />
          <div className="flex justify-between font-semibold">
            <span className="text-white">Tu pago neto</span>
            <span className="text-[#34D399]">{formatARS(order.editorPayout?.toNumber() ?? 0)}</span>
          </div>
        </div>
      </div>

      {/* Calificación del anunciante (si completado) */}
      {order.rating !== null && (
        <div className="bg-[#0F172A] border border-[#1E293B] rounded-xl p-5">
          <h2 className="text-white font-semibold mb-2">Calificación del anunciante</h2>
          <p className="text-yellow-400 text-lg mb-1">
            {'★'.repeat(order.rating)}{'☆'.repeat(5 - order.rating)}
          </p>
          {order.ratingComment && (
            <p className="text-[#94A3B8] text-sm leading-relaxed">{order.ratingComment}</p>
          )}
        </div>
      )}

      {/* Acciones del editor */}
      <EditorActions orderId={order.id} currentStatus={order.status} />

      {/* Chat */}
      <OrderChatBox orderId={order.id} profileId={profile.id} orderStatus={order.status} />
    </div>
  )
}
