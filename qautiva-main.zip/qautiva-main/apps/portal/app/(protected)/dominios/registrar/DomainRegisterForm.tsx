'use client'

import { useEffect, useState } from 'react'
import { formatARS } from '@/lib/format'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

type ContactInfo = {
  firstName: string
  lastName: string
  orgName: string
  address1: string
  city: string
  state: string
  postalCode: string
  country: string
  phone: string
  email: string
}

const INITIAL_CONTACT: ContactInfo = {
  firstName: '',
  lastName: '',
  orgName: '',
  address1: '',
  city: '',
  state: '',
  postalCode: '',
  country: 'AR',
  phone: '',
  email: '',
}

type Props = { domain: string }

function FormField({
  label,
  id,
  value,
  onChange,
  required,
  hint,
  type = 'text',
}: {
  label: string
  id: string
  value: string
  onChange: (v: string) => void
  required?: boolean
  hint?: string
  type?: string
}) {
  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={id} className="text-[#94A3B8] text-sm font-medium">
        {label}
        {required && <span className="text-[#EF4444] ml-0.5">*</span>}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className="bg-[#0F172A] border border-[#1E293B] rounded-lg px-3 py-2 text-[#F8FAFC] placeholder-[#64748B] focus:outline-none focus:border-[#8B5CF6] transition-colors duration-200 text-sm"
      />
      {hint && <p className="text-[#64748B] text-xs">{hint}</p>}
    </div>
  )
}

export function DomainRegisterForm({ domain }: Props) {
  const router = useRouter()
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [contact, setContact] = useState<ContactInfo>(INITIAL_CONTACT)
  const [priceArs, setPriceArs] = useState<number | null>(null)
  const [loadingPrice, setLoadingPrice] = useState(true)

  useEffect(() => {
    if (!domain) return
    fetch(`/api/domains/search?q=${encodeURIComponent(domain)}`)
      .then(r => r.json())
      .then((data: { results: Array<{ domain: string; priceArs: number }> }) => {
        const match = data.results.find(r => r.domain === domain)
        if (match) setPriceArs(match.priceArs)
      })
      .catch((err: unknown) => { console.warn('[DomainRegisterForm] No se pudo obtener precio (no bloqueante)', err) }) // precio no es bloqueante
      .finally(() => setLoadingPrice(false))
  }, [domain])

  function setField(field: keyof ContactInfo) {
    return (value: string) => setContact((prev) => ({ ...prev, [field]: value }))
  }

  if (!domain) {
    return (
      <div className="text-center py-8">
        <p className="text-[#94A3B8] mb-4">Seleccioná un dominio primero.</p>
        <Link
          href="/dominios/buscar"
          className="text-[#8B5CF6] text-sm font-medium hover:text-[#A78BFA] transition-colors duration-200"
        >
          Buscar un dominio
        </Link>
      </div>
    )
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    // Validación básica
    if (!contact.firstName.trim() || !contact.lastName.trim()) {
      setError('El nombre y apellido son requeridos.')
      return
    }
    if (!contact.address1.trim() || !contact.city.trim() || !contact.state.trim() || !contact.postalCode.trim()) {
      setError('Los campos de dirección son requeridos.')
      return
    }
    if (!contact.phone.trim() || !contact.phone.startsWith('+')) {
      setError('El teléfono debe comenzar con + (ej: +54.1112345678).')
      return
    }
    if (!contact.email.trim() || !contact.email.includes('@')) {
      setError('El email no es válido.')
      return
    }

    setSubmitting(true)

    try {
      const res = await fetch('/api/domains/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain, period: 1, contact }),
      })

      if (!res.ok) {
        const body = await res.json().catch((err: unknown) => { console.error('[DomainRegisterForm] Failed to parse error response', err); return {} })
        setError(body?.error ?? 'Ocurrió un error al registrar el dominio. Intentá de nuevo.')
        return
      }

      router.push('/dominios?registered=1')
    } catch {
      setError('No se pudo conectar con el servidor. Revisá tu conexión e intentá de nuevo.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      {/* Dominio seleccionado */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-lg px-4 py-3 mb-6">
        <p className="text-[#94A3B8] text-xs mb-1">Dominio a registrar</p>
        <p className="text-[#F8FAFC] font-semibold text-lg">{domain}</p>
      </div>

      {error && (
        <div
          role="alert"
          className="mb-6 px-4 py-3 rounded-lg bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40 text-sm"
        >
          {error}
        </div>
      )}

      <div className="flex flex-col gap-4 mb-6">
        <h2 className="text-[#F8FAFC] font-semibold text-base">Datos de contacto del titular</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            label="Nombre"
            id="firstName"
            value={contact.firstName}
            onChange={setField('firstName')}
            required
          />
          <FormField
            label="Apellido"
            id="lastName"
            value={contact.lastName}
            onChange={setField('lastName')}
            required
          />
        </div>

        <FormField
          label="Organización / Empresa"
          id="orgName"
          value={contact.orgName}
          onChange={setField('orgName')}
        />

        <FormField
          label="Dirección"
          id="address1"
          value={contact.address1}
          onChange={setField('address1')}
          required
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            label="Ciudad"
            id="city"
            value={contact.city}
            onChange={setField('city')}
            required
          />
          <FormField
            label="Provincia / Estado"
            id="state"
            value={contact.state}
            onChange={setField('state')}
            required
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            label="Código postal"
            id="postalCode"
            value={contact.postalCode}
            onChange={setField('postalCode')}
            required
          />
          <FormField
            label="País"
            id="country"
            value={contact.country}
            onChange={setField('country')}
            required
          />
        </div>

        <FormField
          label="Teléfono"
          id="phone"
          value={contact.phone}
          onChange={setField('phone')}
          required
          hint="Formato: +54.1112345678"
          type="tel"
        />

        <FormField
          label="Email"
          id="email"
          value={contact.email}
          onChange={setField('email')}
          required
          type="email"
        />
      </div>

      {/* Resumen de precio */}
      <div className="bg-[#0F172A] border border-[#1E293B] rounded-lg p-4 mb-6">
        <p className="text-[#94A3B8] text-sm mb-1">Total a pagar</p>
        {loadingPrice ? (
          <p className="text-[#64748B] text-sm">Calculando precio...</p>
        ) : priceArs !== null ? (
          <p className="text-[#F8FAFC] text-2xl font-bold">{formatARS(priceArs)}<span className="text-[#94A3B8] text-sm font-normal ml-1">/año</span></p>
        ) : (
          <p className="text-[#94A3B8] text-sm">Precio no disponible</p>
        )}
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="w-full py-3 rounded-lg bg-[#8B5CF6] text-white font-semibold hover:bg-[#A78BFA] transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {submitting ? 'Registrando...' : 'Confirmar registro'}
      </button>
    </form>
  )
}
