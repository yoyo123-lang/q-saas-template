import type { QuestionBlock } from './types'

/** Labels en español para las keys de secciones del WebTemplate */
const SECTION_LABELS: Record<string, string> = {
  hero: 'Hero / Inicio',
  services: 'Servicios / Menú',
  about: 'Sobre nosotros',
  contact: 'Contacto / WhatsApp',
  gallery: 'Galería',
  testimonials: 'Testimonios',
  map: 'Ubicación / Mapa',
  pricing: 'Precios',
}

/**
 * Construye las preguntas de personalización del template web seleccionado.
 * Se agregan al final del flowDefinition de la etapa WEBSITE, después de las
 * preguntas base (AgentConfig + IndustryTemplate).
 *
 * Las preguntas tienen ids prefijados con "tpl_" para distinguirlas del resto.
 * La IA (E4) usará estas respuestas junto con el htmlBase del template para
 * generar el copy y configurar las secciones.
 *
 * @param sections - Record<string, boolean> del WebTemplate.sections
 * @returns Array de QuestionBlock listo para concatenar al flowDefinition
 */
export function buildTemplatePersonalizationQuestions(
  sections: Record<string, boolean>,
): QuestionBlock[] {
  const activeSections = Object.entries(sections)
    .filter(([, active]) => active)
    .map(([key]) => ({
      value: key,
      label: SECTION_LABELS[key] ?? key,
    }))

  const questions: QuestionBlock[] = []

  // 1. Secciones a incluir — solo si hay más de una opción disponible
  if (activeSections.length > 1) {
    questions.push({
      id: 'tpl_sections',
      question: '¿Qué secciones querés incluir en tu sitio?',
      helpText:
        'El template que elegiste incluye estas secciones. Podés desactivar las que no apliquen a tu negocio.',
      inputType: 'multi_select',
      options: activeSections,
      category: 'Personalización',
      validation: { required: true },
    })
  }

  // 2. Tono de comunicación
  questions.push({
    id: 'tpl_tone',
    question: '¿Cuál es el tono de comunicación que querés transmitir en tu sitio?',
    inputType: 'multiple_choice',
    options: [
      { value: 'amigable', label: 'Amigable y cercano' },
      { value: 'profesional', label: 'Profesional y serio' },
      { value: 'inspiracional', label: 'Inspiracional y motivador' },
      { value: 'tecnico', label: 'Técnico y experto' },
    ],
    category: 'Personalización',
    validation: { required: true },
  })

  // 3. Call to action principal
  questions.push({
    id: 'tpl_cta',
    question: '¿Cuál es la acción principal que querés que haga quien visite tu sitio?',
    helpText: 'Esto aparecerá en el botón principal de tu sitio.',
    inputType: 'text',
    placeholder: 'Ej: Reservar turno, Pedir cotización, Contactanos',
    category: 'Personalización',
    validation: { required: true, maxLength: 60 },
  })

  // 4. Eslogan (opcional)
  questions.push({
    id: 'tpl_slogan',
    question: '¿Tenés un eslogan o frase que defina tu negocio?',
    helpText: 'Si no tenés uno, lo generamos a partir de tu información.',
    inputType: 'text',
    placeholder: 'Ej: Calidad que se nota desde el primer día',
    category: 'Personalización',
    skippable: true,
    validation: { required: false, maxLength: 100 },
  })

  // 5. Horarios de atención (opcional)
  questions.push({
    id: 'tpl_hours',
    question: '¿Cuáles son tus horarios de atención?',
    helpText: 'Se mostrará en la sección de contacto de tu sitio.',
    inputType: 'textarea',
    placeholder: 'Ej: Lunes a viernes de 9 a 18 hs. Sábados de 9 a 13 hs.',
    category: 'Personalización',
    skippable: true,
    validation: { required: false, maxLength: 200 },
  })

  // 6. Información adicional a destacar (opcional)
  questions.push({
    id: 'tpl_extra',
    question: '¿Hay algo especial de tu negocio que querés destacar en el sitio?',
    helpText: 'Premios, certificaciones, años de experiencia, garantías, etc.',
    inputType: 'textarea',
    placeholder: 'Ej: 10 años de experiencia. Certificados por...',
    category: 'Personalización',
    skippable: true,
    validation: { required: false, maxLength: 400 },
  })

  // 7. WhatsApp / teléfono de contacto (opcional)
  questions.push({
    id: 'tpl_whatsapp',
    question: '¿Cuál es tu número de WhatsApp o teléfono de contacto?',
    helpText: 'Se mostrará en los botones de contacto y en la sección de contacto.',
    inputType: 'text',
    placeholder: 'Ej: +54 9 11 1234-5678',
    category: 'Contacto',
    skippable: true,
    validation: { required: false, maxLength: 30 },
  })

  // 8. Email de contacto (opcional)
  questions.push({
    id: 'tpl_email',
    question: '¿Cuál es el email de contacto de tu negocio?',
    helpText: 'Se mostrará en la sección de contacto de tu sitio.',
    inputType: 'text',
    placeholder: 'Ej: hola@miegocio.com',
    category: 'Contacto',
    skippable: true,
    validation: { required: false, maxLength: 100 },
  })

  // 9. Redes sociales (opcional)
  questions.push({
    id: 'tpl_redes',
    question: '¿Tenés redes sociales que quieras incluir en el sitio?',
    helpText: 'Podés poner el usuario o la URL completa de cada red.',
    inputType: 'textarea',
    placeholder: 'Ej: Instagram: @minegocio\nFacebook: facebook.com/minegocio',
    category: 'Contacto',
    skippable: true,
    validation: { required: false, maxLength: 300 },
  })

  return questions
}

/**
 * Detecta si un flowDefinition ya contiene las preguntas de personalización
 * del template (identificadas por el prefijo "tpl_" en el id).
 * Usado para evitar agregar las preguntas dos veces.
 */
export function hasTemplatePersonalizationQuestions(flow: { id: string }[]): boolean {
  return flow.some((q) => q.id.startsWith('tpl_'))
}
