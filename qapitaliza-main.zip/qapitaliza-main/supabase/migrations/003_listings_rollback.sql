-- ============================================================
-- ROLLBACK 003 — Listings
-- ADVERTENCIA: borra todos los listados. Irreversible sin backup.
-- ============================================================

DROP TABLE IF EXISTS public.listings CASCADE;

DROP TYPE IF EXISTS listing_type        CASCADE;
DROP TYPE IF EXISTS listing_status      CASCADE;
DROP TYPE IF EXISTS verification_status CASCADE;
DROP TYPE IF EXISTS currency_type       CASCADE;
