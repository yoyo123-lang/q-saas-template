import { describe, it, expect } from 'vitest'
import { loginSchema, registerSchema } from '@/lib/schemas/auth'

describe('loginSchema', () => {
  it('válido con email y password correctos', () => {
    const result = loginSchema.safeParse({
      email: 'test@example.com',
      password: 'Password1',
    })
    expect(result.success).toBe(true)
  })

  it('inválido con email malformado', () => {
    const result = loginSchema.safeParse({
      email: 'no-es-email',
      password: 'Password1',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].path).toContain('email')
    }
  })

  it('inválido con password menor a 8 caracteres', () => {
    const result = loginSchema.safeParse({
      email: 'test@example.com',
      password: 'abc123',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues[0].path).toContain('password')
    }
  })

  it('inválido sin campos', () => {
    const result = loginSchema.safeParse({})
    expect(result.success).toBe(false)
  })
})

describe('registerSchema', () => {
  const validData = {
    nombre: 'Juan García',
    email: 'juan@example.com',
    password: 'Secure123',
    confirmPassword: 'Secure123',
    rol: 'BUYER' as const,
    acceptTerms: true,
  }

  it('válido con todos los campos correctos', () => {
    const result = registerSchema.safeParse(validData)
    expect(result.success).toBe(true)
  })

  it('inválido si nombre es muy corto', () => {
    const result = registerSchema.safeParse({ ...validData, nombre: 'J' })
    expect(result.success).toBe(false)
  })

  it('inválido si password no tiene mayúscula', () => {
    const result = registerSchema.safeParse({
      ...validData,
      password: 'lowercase1',
      confirmPassword: 'lowercase1',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      const msgs = result.error.issues.map((i) => i.message)
      expect(msgs.some((m) => m.includes('mayúscula'))).toBe(true)
    }
  })

  it('inválido si password no tiene número', () => {
    const result = registerSchema.safeParse({
      ...validData,
      password: 'NoNumber!',
      confirmPassword: 'NoNumber!',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      const msgs = result.error.issues.map((i) => i.message)
      expect(msgs.some((m) => m.includes('número'))).toBe(true)
    }
  })

  it('inválido si las contraseñas no coinciden', () => {
    const result = registerSchema.safeParse({
      ...validData,
      password: 'Secure123',
      confirmPassword: 'Different1',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      const msgs = result.error.issues.map((i) => i.message)
      expect(msgs.some((m) => m.includes('no coinciden'))).toBe(true)
    }
  })

  it('inválido si acceptTerms es false', () => {
    const result = registerSchema.safeParse({ ...validData, acceptTerms: false })
    expect(result.success).toBe(false)
    if (!result.success) {
      const msgs = result.error.issues.map((i) => i.message)
      expect(msgs.some((m) => m.includes('términos'))).toBe(true)
    }
  })

  it('inválido con rol no permitido', () => {
    const result = registerSchema.safeParse({ ...validData, rol: 'MODERATOR' })
    expect(result.success).toBe(false)
  })

  it('acepta rol SELLER', () => {
    const result = registerSchema.safeParse({ ...validData, rol: 'SELLER' })
    expect(result.success).toBe(true)
  })
})

describe('middleware logic (unit)', () => {
  // Tests de la lógica de redirección del middleware
  // Simulamos las condiciones sin montar el middleware completo

  it('rutas protegidas requieren usuario autenticado', () => {
    const protectedPrefixes = ['/dashboard', '/mis-activos', '/favoritos', '/consultas', '/perfil']
    const isProtected = (path: string) => protectedPrefixes.some((p) => path.startsWith(p))

    expect(isProtected('/dashboard')).toBe(true)
    expect(isProtected('/mis-activos/nuevo')).toBe(true)
    expect(isProtected('/perfil')).toBe(true)
    expect(isProtected('/explorar')).toBe(false)
    expect(isProtected('/login')).toBe(false)
  })

  it('rutas admin requieren rol ADMIN', () => {
    const adminPrefixes = ['/admin']
    const isAdmin = (path: string) => adminPrefixes.some((p) => path.startsWith(p))

    expect(isAdmin('/admin')).toBe(true)
    expect(isAdmin('/admin/users')).toBe(true)
    expect(isAdmin('/dashboard')).toBe(false)
  })

  it('redirect post-login va a /dashboard por defecto', () => {
    const redirectAfterLogin = (role: string, next: string | null) => {
      if (next && next.startsWith('/')) return next
      if (role === 'ADMIN') return '/admin'
      return '/dashboard'
    }

    expect(redirectAfterLogin('BUYER', null)).toBe('/dashboard')
    expect(redirectAfterLogin('SELLER', null)).toBe('/dashboard')
    expect(redirectAfterLogin('ADMIN', null)).toBe('/admin')
    expect(redirectAfterLogin('BUYER', '/mis-activos')).toBe('/mis-activos')
    // next param externo no debería ser aceptado
    expect(redirectAfterLogin('BUYER', 'https://evil.com')).toBe('/dashboard')
  })
})
