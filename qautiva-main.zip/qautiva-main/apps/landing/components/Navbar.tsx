'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 border-b transition-all duration-300 ${
        scrolled
          ? 'bg-navy-950/90 backdrop-blur-md border-navy-800'
          : 'bg-navy-950 border-navy-800'
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="#" aria-label="Ir al inicio">
          <Image
            src="/logo.png"
            alt="Qautiva Marketing"
            width={480}
            height={160}
            className="h-32 w-auto"
            priority
          />
        </a>

        <div className="hidden md:flex items-center gap-8">
          <a
            href="#como-funciona"
            className="text-slate-400 hover:text-white text-sm transition-colors duration-200"
          >
            Cómo funciona
          </a>
          <a
            href="#que-recibis"
            className="text-slate-400 hover:text-white text-sm transition-colors duration-200"
          >
            Qué recibís
          </a>
          <a
            href="#precios"
            className="text-slate-400 hover:text-white text-sm transition-colors duration-200"
          >
            Precios
          </a>
          <a
            href="https://app.qautiva.ar"
            className="text-slate-400 border border-slate-600 text-sm font-medium px-4 py-2 rounded-lg hover:text-white hover:border-slate-400 transition-colors duration-200"
          >
            Ingresá
          </a>
          <a
            href="#precios"
            className="bg-accent text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-accent-light transition-colors duration-200"
          >
            Empezá
          </a>
        </div>

        <button
          className="md:hidden text-slate-400 hover:text-white p-2"
          aria-label={mobileOpen ? 'Cerrar menú' : 'Abrir menú'}
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((prev) => !prev)}
        >
          {mobileOpen ? (
            <svg
              width="20"
              height="20"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg
              width="20"
              height="20"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>
      </div>

      {mobileOpen && (
        <div
          className="md:hidden w-full border-t border-navy-800 flex flex-col"
          style={{ backgroundColor: '#0B0F1A' }}
        >
          <a
            href="#como-funciona"
            className="text-slate-400 hover:text-white text-sm px-6 py-4 transition-colors duration-200 border-b border-navy-800"
            onClick={() => setMobileOpen(false)}
          >
            Cómo funciona
          </a>
          <a
            href="#que-recibis"
            className="text-slate-400 hover:text-white text-sm px-6 py-4 transition-colors duration-200 border-b border-navy-800"
            onClick={() => setMobileOpen(false)}
          >
            Qué recibís
          </a>
          <a
            href="#precios"
            className="text-slate-400 hover:text-white text-sm px-6 py-4 transition-colors duration-200 border-b border-navy-800"
            onClick={() => setMobileOpen(false)}
          >
            Precios
          </a>
          <a
            href="https://app.qautiva.ar"
            className="text-slate-400 hover:text-white text-sm px-6 py-4 transition-colors duration-200 border-b border-navy-800"
            onClick={() => setMobileOpen(false)}
          >
            Ingresá
          </a>
          <a
            href="#precios"
            className="text-white bg-accent text-sm font-medium px-6 py-4 transition-colors duration-200 hover:bg-accent-light"
            onClick={() => setMobileOpen(false)}
          >
            Empezá
          </a>
        </div>
      )}
    </nav>
  )
}
