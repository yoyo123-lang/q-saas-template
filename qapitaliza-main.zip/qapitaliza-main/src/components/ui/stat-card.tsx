import { cn } from '@/lib/utils/cn'

interface StatCardProps {
  label: string
  value: string | number
  icon: React.ReactNode
  trend?: { value: string; positive: boolean }
  pulse?: boolean
  highlight?: boolean
  className?: string
}

export function StatCard({ label, value, icon, trend, pulse, highlight, className }: StatCardProps) {
  return (
    <div
      className={cn(
        'bg-navy-900 border border-slate-800 rounded-xl p-5 flex flex-col gap-3',
        className
      )}
    >
      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-500">{label}</span>
        <span className="size-9 rounded-lg bg-amber-500/10 flex items-center justify-center">
          {icon}
        </span>
      </div>

      <div className="flex items-end gap-2">
        {pulse && (
          <span className="relative flex size-2 mt-1 mb-1 mr-1">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-500 opacity-75" />
            <span className="relative inline-flex rounded-full size-2 bg-amber-500" />
          </span>
        )}
        <span
          className={cn(
            'text-3xl font-bold',
            highlight ? 'text-amber-500' : 'text-slate-50'
          )}
        >
          {value}
        </span>
      </div>

      {trend && (
        <span
          className={cn(
            'text-sm font-medium',
            trend.positive ? 'text-emerald-500' : 'text-red-400'
          )}
        >
          {trend.positive ? '▲' : '▼'} {trend.value}
        </span>
      )}
    </div>
  )
}
