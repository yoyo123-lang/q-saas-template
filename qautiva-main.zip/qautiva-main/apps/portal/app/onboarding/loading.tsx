export default function OnboardingLoading() {
  return (
    <div className="min-h-screen bg-[#0B0F1A] flex items-center justify-center p-6">
      <div className="w-full max-w-md animate-pulse">
        <div className="text-center mb-8">
          <div className="h-8 w-48 bg-[#1E293B] rounded-lg mx-auto mb-2" />
          <div className="h-4 w-64 bg-[#1E293B] rounded mx-auto" />
        </div>
        <div className="flex flex-col gap-4">
          <div className="h-12 w-full bg-[#1E293B] rounded-lg" />
          <div className="h-12 w-full bg-[#1E293B] rounded-lg" />
          <div className="h-12 w-full bg-[#1E293B] rounded-lg" />
        </div>
      </div>
    </div>
  )
}
