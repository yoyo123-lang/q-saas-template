import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { CampaignPlan, StrategicBrief } from '../../app/_lib/interview/types'

// ── Mocks (vi.hoisted para evitar TDZ con vi.mock factories) ─────────────────

const { mockCreate } = vi.hoisted(() => {
  return { mockCreate: vi.fn() }
})

// Mock de @qautiva/db: necesario para evitar "server-only" import en ai-config.ts
// y para que getAiConfig() use ANTHROPIC (así se llama mockCreate)
vi.mock('@qautiva/db', () => ({
  prisma: {
    trialConfig: {
      findUnique: vi.fn().mockResolvedValue({
        qautivaProvider: 'ANTHROPIC',
        qautivaModel: 'claude-opus-4-6',
      }),
    },
  },
}))

vi.mock('@anthropic-ai/sdk', () => ({
  default: vi.fn().mockImplementation(() => ({
    messages: { create: mockCreate },
  })),
}))

// ── Fixtures ──────────────────────────────────────────────────────────────────

const mockCampaignPlan: CampaignPlan = {
  resumen: {
    objetivos: 'Aumentar el reconocimiento de marca en CABA y generar leads cualificados.',
    duracionEstimada: '3 meses',
    presupuestoRecomendado: {
      min: 150000,
      max: 300000,
      justificacion: 'Suficiente para alcanzar frecuencia mínima en ambas plataformas en CABA.',
    },
  },
  plataformas: [
    {
      nombre: 'GOOGLE_ADS',
      razon: 'Alta intención de compra en búsqueda para este servicio.',
      formatos: [
        {
          tipo: 'SEARCH',
          descripcion: 'Anuncios de texto en búsquedas de alta intención.',
          presupuestoSugerido: 100000,
        },
      ],
    },
    {
      nombre: 'META',
      razon: 'Ideal para awareness en el segmento de dueños de PyMEs gastronómicas.',
      formatos: [
        {
          tipo: 'FEED',
          descripcion: 'Creatividades con casos de éxito.',
          presupuestoSugerido: 80000,
        },
      ],
    },
  ],
  audiencias: [
    {
      nombre: 'Dueños de restaurantes en CABA',
      descripcion: 'Propietarios de locales gastronómicos con 5-20 empleados.',
      tamanioEstimado: '45K usuarios',
      criterios: ['edad 30-55', 'ubicación CABA', 'intereses: gastronomía'],
    },
  ],
  oferta: {
    mensajePrincipal: 'El sistema que entiende tu restaurante',
    variantesCreativas: [
      'Reducí 2 horas de administración por día',
      'El software que ya usan 50 restaurantes en Palermo',
    ],
    callToAction: 'Probá 30 días gratis',
  },
  calendario: [
    {
      fase: 'Lanzamiento',
      duracion: 'Semanas 1-2',
      actividades: ['Configurar campañas', 'Definir audiencias'],
      presupuesto: 60000,
    },
  ],
  metricas: {
    kpisObjetivo: [
      {
        nombre: 'CPA',
        meta: 'Máximo $1.500 ARS por lead',
        razon: 'LTV justifica hasta $3.000 de adquisición.',
      },
    ],
    reportingFrecuencia: 'Semanal',
  },
  riesgos: [
    {
      riesgo: 'Alta competencia en keywords',
      probabilidad: 'alta',
      mitigacion: 'Usar keywords long-tail.',
    },
  ],
  disclaimer: 'Plan generado por IA como propuesta inicial. Presupuestos estimativos.',
}

const mockBrief: StrategicBrief = {
  negocio: {
    descripcion: 'Software de gestión para PYMEs gastronómicas',
    estado: 'operando',
    antiguedad: '2 años',
    recursosDisponibles: 'Equipo de 5',
    restricciones: [],
  },
  mercado: {
    zonaGeografica: 'CABA',
    alcance: 'Local',
    competidores: [],
    espaciosVacios: [],
    tendencias: [],
  },
  audiencia: {
    perfilCliente: 'Dueño de PYME gastronómica',
    comoCompra: 'Por recomendación',
    dolorPrincipal: 'Tareas manuales',
    canalAdquisicion: 'Referidos',
  },
  posicionamiento: {
    estrategia: 'enfoque',
    nichoEspecifico: 'Restaurantes en CABA',
    ventajaCompetitiva: 'Único sistema para gastronomía',
    riesgos: [],
    justificacion: 'Nicho sin cubrir',
  },
  direccionComunicacional: {
    mensajeCentral: 'El sistema que entiende tu restaurante',
    tonoSugerido: 'Directo',
    territoriosTematicos: [],
    queNoDecir: [],
    rangoPrecios: 'Suscripción mensual',
  },
  decisionesPendientes: [],
}

// Invalidar cache de ai-config entre tests para que re-lea el mock
beforeEach(async () => {
  mockCreate.mockReset()
  const { invalidateAiConfigCache } = await import(
    '../../app/_lib/interview/ai-config'
  )
  invalidateAiConfigCache()
})

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('generateCampaignPlan', () => {
  it('retorna el CampaignPlan cuando Claude llama generate_campaign_plan', async () => {
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [
        {
          type: 'tool_use',
          id: 'plan_1',
          name: 'generate_campaign_plan',
          input: mockCampaignPlan,
        },
      ],
      stop_reason: 'tool_use',
      usage: { input_tokens: 100, output_tokens: 500 },
    })

    const result = await generateCampaignPlan({
      flowDefinition: [],
      answers: {},
      project: { name: 'Mi Restaurante', industry: 'Gastronomía', country: 'Argentina' },
      previousDeliverables: [{ type: 'BRIEF', content: mockBrief }],
    })

    expect(result.plataformas).toHaveLength(2)
    expect(result.plataformas[0]!.nombre).toBe('GOOGLE_ADS')
    expect(result.resumen.presupuestoRecomendado.min).toBe(150000)
    expect(result.oferta.mensajePrincipal).toBe('El sistema que entiende tu restaurante')
  })

  it('pasa tool_choice: { type: tool, name: generate_campaign_plan } a la API', async () => {
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: mockCampaignPlan }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    await generateCampaignPlan({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
    })

    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        tool_choice: { type: 'tool', name: 'generate_campaign_plan' },
      }),
    )
  })

  it('incluye el mensajeCentral del brief en el prompt', async () => {
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: mockCampaignPlan }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    await generateCampaignPlan({
      flowDefinition: [],
      answers: {},
      project: { name: 'Mi Restaurante', industry: 'Gastronomía', country: 'Argentina' },
      previousDeliverables: [{ type: 'BRIEF', content: mockBrief }],
    })

    const callArgs = mockCreate.mock.calls[0]![0] as Record<string, unknown>
    const messages = callArgs.messages as Array<{ role: string; content: string }>
    const userContent = messages[0]!.content
    expect(userContent).toContain('El sistema que entiende tu restaurante')
    expect(userContent).toContain('Mi Restaurante')
  })

  it('incluye preguntas y respuestas de la entrevista en el prompt', async () => {
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: mockCampaignPlan }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    await generateCampaignPlan({
      flowDefinition: [
        { id: 'camp_q1', question: '¿Cuál es tu presupuesto mensual?', inputType: 'budget_range' },
      ],
      answers: { camp_q1: 'ARS 200.000' },
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
    })

    const callArgs = mockCreate.mock.calls[0]![0] as Record<string, unknown>
    const messages = callArgs.messages as Array<{ role: string; content: string }>
    const userContent = messages[0]!.content
    expect(userContent).toContain('¿Cuál es tu presupuesto mensual?')
    expect(userContent).toContain('ARS 200.000')
  })

  it('lanza si Claude no llama generate_campaign_plan', async () => {
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'text', text: 'Acá te dejo el plan...' }],
      stop_reason: 'end_turn',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    await expect(
      generateCampaignPlan({
        flowDefinition: [],
        answers: {},
        project: { name: 'Test', industry: null, country: null },
        previousDeliverables: [],
      }),
    ).rejects.toThrow('[campaign-strategy-generator]')
  })

  describe('validateCampaignPlan — errores de validación', () => {
    it('lanza si falta resumen', async () => {
      const { generateCampaignPlan } = await import(
        '../../app/_lib/interview/campaign-strategy-generator'
      )

      const invalid = { ...mockCampaignPlan, resumen: undefined }
      mockCreate.mockResolvedValueOnce({
        content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: invalid }],
        stop_reason: 'tool_use',
        usage: { input_tokens: 10, output_tokens: 10 },
      })

      await expect(
        generateCampaignPlan({ flowDefinition: [], answers: {}, project: { name: 'T', industry: null, country: null }, previousDeliverables: [] }),
      ).rejects.toThrow('[campaign-strategy-generator] Falta resumen')
    })

    it('lanza si plataforma tiene nombre inválido', async () => {
      const { generateCampaignPlan } = await import(
        '../../app/_lib/interview/campaign-strategy-generator'
      )

      const invalid = {
        ...mockCampaignPlan,
        plataformas: [{ nombre: 'TIKTOK', razon: 'X', formatos: [] }],
      }
      mockCreate.mockResolvedValueOnce({
        content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: invalid }],
        stop_reason: 'tool_use',
        usage: { input_tokens: 10, output_tokens: 10 },
      })

      await expect(
        generateCampaignPlan({ flowDefinition: [], answers: {}, project: { name: 'T', industry: null, country: null }, previousDeliverables: [] }),
      ).rejects.toThrow('GOOGLE_ADS o META')
    })

    it('lanza si riesgo tiene probabilidad inválida', async () => {
      const { generateCampaignPlan } = await import(
        '../../app/_lib/interview/campaign-strategy-generator'
      )

      const invalid = {
        ...mockCampaignPlan,
        riesgos: [{ riesgo: 'Algo', probabilidad: 'muy-alta', mitigacion: 'X' }],
      }
      mockCreate.mockResolvedValueOnce({
        content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: invalid }],
        stop_reason: 'tool_use',
        usage: { input_tokens: 10, output_tokens: 10 },
      })

      await expect(
        generateCampaignPlan({ flowDefinition: [], answers: {}, project: { name: 'T', industry: null, country: null }, previousDeliverables: [] }),
      ).rejects.toThrow('alta/media/baja')
    })

    it('lanza si presupuestoRecomendado.min no es número', async () => {
      const { generateCampaignPlan } = await import(
        '../../app/_lib/interview/campaign-strategy-generator'
      )

      const invalid = {
        ...mockCampaignPlan,
        resumen: {
          ...mockCampaignPlan.resumen,
          presupuestoRecomendado: { min: 'mucho', max: 100, justificacion: 'x' },
        },
      }
      mockCreate.mockResolvedValueOnce({
        content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: invalid }],
        stop_reason: 'tool_use',
        usage: { input_tokens: 10, output_tokens: 10 },
      })

      await expect(
        generateCampaignPlan({ flowDefinition: [], answers: {}, project: { name: 'T', industry: null, country: null }, previousDeliverables: [] }),
      ).rejects.toThrow('presupuestoRecomendado.min/max')
    })
  })

  it('no falla si previousDeliverables tiene content null', async () => {
    // Verifica que buildContextSummary no tira TypeError con content null
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: mockCampaignPlan }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    // No debe lanzar aunque el content sea null
    const result = await generateCampaignPlan({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [
        { type: 'BRIEF', content: null },
        { type: 'UNKNOWN_TYPE', content: { foo: 'bar' } },
      ],
    })

    expect(result.disclaimer).toBeTruthy()
  })

  it('antepone el disclaimer mínimo garantizado al disclaimer generado por IA', async () => {
    const { generateCampaignPlan } = await import(
      '../../app/_lib/interview/campaign-strategy-generator'
    )

    const planWithShortDisclaimer = { ...mockCampaignPlan, disclaimer: 'Estimativo.' }
    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_campaign_plan', input: planWithShortDisclaimer }],
      stop_reason: 'tool_use',
      usage: { input_tokens: 10, output_tokens: 10 },
    })

    const result = await generateCampaignPlan({
      flowDefinition: [],
      answers: {},
      project: { name: 'Test', industry: null, country: null },
      previousDeliverables: [],
    })

    // El disclaimer final debe incluir la advertencia mínima + lo que generó el modelo
    expect(result.disclaimer).toContain('generado por inteligencia artificial')
    expect(result.disclaimer).toContain('Estimativo.')
  })
})
