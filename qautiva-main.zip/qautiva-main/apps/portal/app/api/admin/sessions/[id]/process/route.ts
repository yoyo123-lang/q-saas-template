import { NextResponse, type NextRequest } from 'next/server'
import { prisma, createServiceClient } from '@qautiva/db'
import { processSession } from '@/app/_lib/interview/session-processor'
import { waitUntil } from '@vercel/functions'

// maxDuration alto: el procesamiento corre en background vía waitUntil
// y puede tomar hasta 90s en Anthropic. 300s da margen de sobra (Vercel Pro).
export const maxDuration = 300

/**
 * POST /api/admin/sessions/[id]/process
 *
 * Fuerza el procesamiento (o reprocesamiento) de una sesión de entrevista.
 * Autenticación: Bearer token de Supabase de un usuario con rol ADMIN.
 *
 * A diferencia de /api/interview/sessions/[id]/process:
 * - No requiere ownership de la sesión (verifica rol ADMIN)
 * - Acepta sesiones en estado PROCESSING o ERROR
 * - Resetea retryCount a 0 para bypasear el límite de reintentos
 *
 * Fire-and-forget: usa waitUntil() para procesar en background.
 */
export async function POST(
  _request: NextRequest,
  { params }: { params: { id: string } },
) {
  const authHeader = _request.headers.get('authorization')
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null
  if (!token) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  // Verificar que el token pertenece a un usuario con rol ADMIN
  const supabaseAdmin = createServiceClient()
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(token)
  if (error || !user || user.app_metadata?.['role'] !== 'ADMIN') {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  const session = await prisma.interviewSession.findFirst({
    where: { id: params.id, project: { deletedAt: null } },
    select: {
      id: true,
      status: true,
      flowDefinition: true,
      answers: true,
      retryCount: true,
      maxRetries: true,
      stageId: true,
      projectId: true,
      teamId: true,
      selectedWebTemplateId: true,
      stage: { select: { stageKey: true } },
      project: { select: { brandKit: true } },
    },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  if (session.status === 'COMPLETED') {
    return NextResponse.json({ ok: true, alreadyCompleted: true })
  }

  if (session.status !== 'PROCESSING' && session.status !== 'ERROR') {
    return NextResponse.json(
      { error: `Estado inválido para procesar: ${session.status}` },
      { status: 409 },
    )
  }

  // Admin bypass: si la sesión está en ERROR o está al límite de reintentos,
  // resetear el estado a PROCESSING con retryCount = 0
  const needsReset = session.status === 'ERROR' || session.retryCount >= session.maxRetries
  if (needsReset) {
    await prisma.interviewSession.update({
      where: { id: params.id },
      data: {
        status: 'PROCESSING',
        retryCount: 0,
        lastError: null,
        processingStartedAt: new Date(),
      },
    })
  } else {
    // Si ya está en PROCESSING sin necesitar reset, reclamar atomic lock
    // para evitar duplicar llamadas a Anthropic si /process o el cron están procesando.
    const PROCESSING_LOCK_MS = 2 * 60 * 1000
    const claimed = await prisma.interviewSession.updateMany({
      where: {
        id: params.id,
        status: 'PROCESSING',
        OR: [
          { processingStartedAt: null },
          { processingStartedAt: { lt: new Date(Date.now() - PROCESSING_LOCK_MS) } },
        ],
      },
      data: { processingStartedAt: new Date() },
    })
    if (claimed.count === 0) {
      return NextResponse.json({ ok: true, alreadyProcessing: true }, { status: 202 })
    }
  }

  console.info('[admin/sessions/process] starting (background)', { sessionId: params.id, adminUserId: user.id })

  // Fire-and-forget: procesar en background, responder inmediatamente.
  const sessionToProcess = {
    ...(needsReset ? { ...session, retryCount: 0 } : session),
    stageKey: session.stage?.stageKey ?? '',
  }
  waitUntil(
    processSession(sessionToProcess, 'admin/sessions/process')
      .catch(async (err) => {
        const errorMsg = err instanceof Error ? err.message : String(err)
        console.error('[admin/sessions/process] unhandled error in background', {
          sessionId: params.id,
          error: errorMsg,
        })
        // Best-effort: transicionar a ERROR para no dejar la sesión pegada en PROCESSING
        try {
          await prisma.interviewSession.update({
            where: { id: params.id, status: 'PROCESSING' },
            data: { status: 'ERROR', lastError: `Unhandled: ${errorMsg}`.slice(0, 500) },
          })
        } catch { /* P2025 si otro actor ya cambió el estado — OK */ }
      }),
  )

  return NextResponse.json({ ok: true, processing: true }, { status: 202 })
}
