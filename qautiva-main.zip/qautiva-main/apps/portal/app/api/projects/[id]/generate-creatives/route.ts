/**
 * POST /api/projects/[id]/generate-creatives
 *
 * Inicia la generación asíncrona de piezas visuales para Meta Ads.
 * Valida auth, ownership, rol (ADMIN/OWNER), rate limit y billing antes de encolar.
 * Retorna { jobId } para polling via GET /generate-creatives/[jobId].
 *
 * Rate limit: máx 10 generaciones por proyecto por día (contado en DB).
 * Input: { message: string } — mensaje del usuario (max 500 chars).
 */

import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { randomUUID } from 'crypto'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { generateAdVisuals } from '@/app/_lib/interview/ad-visual-generator'
import { checkBillingEligibility } from '@/app/_lib/billing/check-eligibility'
import { registerAiUsage } from '@/app/_lib/billing/register-ai-usage'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'
import { getGeminiImageModel } from '@/app/_lib/interview/ai-config'
import type { BrandOptions } from '@/app/_lib/interview/types'
import { createJob, updateJob, addInflightProject, removeInflightProject, isProjectInflight } from './_lib/job-store'
import { MAX_DAILY_AD_VISUALS } from './_lib/constants'

// ── Constantes ─────────────────────────────────────────────────────────────────

const MAX_MESSAGE_LENGTH = 500
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

/**
 * Estimación de tokens por generación (6 imágenes × ~300 tokens de prompt).
 * Gemini Image no devuelve conteo real de tokens — esto es una aproximación
 * para mantener la contabilidad de costos consistente con el resto del sistema.
 */
const ESTIMATED_TOKENS_IN_PER_GENERATION = 1_800
const ESTIMATED_TOKENS_OUT_PER_GENERATION = 0

// ── Rate limit ─────────────────────────────────────────────────────────────────

async function countTodayGenerations(projectId: string): Promise<number> {
  const startOfDay = new Date()
  startOfDay.setUTCHours(0, 0, 0, 0)
  return prisma.deliverable.count({
    where: { projectId, type: 'AD_VISUALS', createdAt: { gte: startOfDay } },
  })
}

// ── Handler ────────────────────────────────────────────────────────────────────

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  // 1. Auth
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  }

  // 2. Validar formato del projectId
  const projectId = params.id
  if (!UUID_RE.test(projectId)) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // 3. Validar body
  let body: { message?: unknown }
  try {
    body = await request.json() as { message?: unknown }
  } catch {
    return NextResponse.json({ error: 'Cuerpo de solicitud inválido' }, { status: 400 })
  }

  const rawMessage = body.message
  if (typeof rawMessage !== 'string' || rawMessage.trim().length === 0) {
    return NextResponse.json(
      { error: 'El campo "message" es obligatorio y no puede estar vacío' },
      { status: 400 },
    )
  }

  if (rawMessage.trim().length > MAX_MESSAGE_LENGTH) {
    return NextResponse.json(
      { error: `El mensaje no puede superar los ${MAX_MESSAGE_LENGTH} caracteres` },
      { status: 400 },
    )
  }

  const userMessage = rawMessage.trim()

  // 4. Verificar ownership del proyecto
  const profile = await prisma.userProfile.findUnique({
    where: { authUserId: user.id },
    select: { teamMemberships: { select: { teamId: true } } },
  })

  if (!profile || profile.teamMemberships.length === 0) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const teamIds = profile.teamMemberships.map((m: { teamId: string }) => m.teamId)

  const project = await prisma.project.findFirst({
    where: { id: projectId, teamId: { in: teamIds }, deletedAt: null },
    select: { id: true, name: true, industry: true, country: true, teamId: true },
  })

  if (!project) {
    return NextResponse.json({ error: 'Proyecto no encontrado' }, { status: 404 })
  }

  // 5. Verificar rol: solo ADMIN y OWNER pueden generar creativos
  const perm = await checkTeamPermission(user.id, project.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden generar creativos.' },
      { status: 403 },
    )
  }

  // 6. Guard de concurrencia: un proyecto solo puede tener una generación activa a la vez
  if (isProjectInflight(projectId)) {
    return NextResponse.json(
      { error: 'Ya hay una generación en curso para este proyecto. Esperá a que termine.' },
      { status: 409 },
    )
  }

  // 7. Rate limit: máx 10 generaciones por proyecto por día
  const todayCount = await countTodayGenerations(projectId)
  if (todayCount >= MAX_DAILY_AD_VISUALS) {
    return NextResponse.json(
      {
        error: `Límite diario alcanzado (${MAX_DAILY_AD_VISUALS} generaciones por día por proyecto). Intentá mañana.`,
        dailyCount: todayCount,
        dailyLimit: MAX_DAILY_AD_VISUALS,
      },
      { status: 429 },
    )
  }

  // 8. Verificar elegibilidad de billing
  // SKIP_BILLING_CHECK=true en .env.local permite saltear este check en desarrollo/testing.
  let billingSource: string
  if (process.env.SKIP_BILLING_CHECK === 'true') {
    billingSource = 'QAUTIVA_HOSTED'
  } else {
    try {
      const billing = await checkBillingEligibility(project.teamId)
      if (!billing.eligible) {
        return NextResponse.json(
          { error: billing.reason ?? 'Plan sin créditos disponibles.' },
          { status: 402 },
        )
      }
      billingSource = billing.source
    } catch (err) {
      console.error('[generate-creatives] billing check failed', {
        projectId,
        teamId: project.teamId,
        error: err instanceof Error ? err.message : String(err),
      })
      return NextResponse.json(
        { error: 'Error al verificar el estado de tu cuenta. Intentá de nuevo.' },
        { status: 500 },
      )
    }
  }

  // 9. Cargar deliverables anteriores y stage CAMPAIGNS
  const [previousDeliverables, campaignsStage] = await Promise.all([
    prisma.deliverable.findMany({
      where: {
        projectId,
        type: { in: ['BRIEF', 'BRAND_OPTIONS', 'CAMPAIGN_PLAN', 'AD_CREATIVES'] },
        isActive: true,
      },
      select: { type: true, content: true },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.stage.findFirst({
      where: { projectId, stageKey: 'CAMPAIGNS' },
      select: { id: true },
      orderBy: { number: 'asc' },
    }),
  ])

  const stageId = campaignsStage?.id ?? (await prisma.stage.findFirst({
    where: { projectId },
    select: { id: true },
    orderBy: { number: 'asc' },
  }).then((s: { id: string } | null) => s?.id))

  if (!stageId) {
    return NextResponse.json(
      { error: 'El proyecto no tiene etapas configuradas. Completá la entrevista inicial primero.' },
      { status: 409 },
    )
  }

  const brandOptionsDeliverable = previousDeliverables.find((d: { type: string }) => d.type === 'BRAND_OPTIONS')
  const brandOptions = (brandOptionsDeliverable?.content as BrandOptions | null) ?? null

  // 10. Crear job, marcar proyecto como en vuelo y encolar generación
  const jobId = randomUUID()
  createJob(jobId, projectId)
  addInflightProject(projectId)

  const visualInput = {
    project: { name: project.name, industry: project.industry, country: project.country },
    previousDeliverables,
    projectId,
    sessionId: jobId,
    brandOptions,
    userMessage,
  }

  // Fire and forget — la generación corre en background
  void (async () => {
    updateJob(jobId, { status: 'running' })
    try {
      const adVisuals = await generateAdVisuals(visualInput)

      // Persistir el deliverable en DB — desactivar el previo en la misma transacción
      // para mantener la invariante: un solo deliverable AD_VISUALS activo por stage
      await prisma.$transaction(async (tx) => {
        await tx.deliverable.updateMany({
          where: { projectId, stageId, type: 'AD_VISUALS', isActive: true },
          data: { isActive: false },
        })
        await tx.deliverable.create({
          data: {
            projectId,
            teamId: project.teamId,
            stageId,
            type: 'AD_VISUALS',
            title: 'Piezas visuales Meta Ads',
            content: adVisuals as unknown as Parameters<typeof prisma.deliverable.create>[0]['data']['content'],
            status: 'READY',
            isActive: true,
          },
        })
      })

      // Registrar consumo de tokens para billing (no lanza — swallows errors internamente)
      const geminiModel = await getGeminiImageModel()
      void registerAiUsage({
        teamId: project.teamId,
        projectId,
        provider: 'GOOGLE_GEMINI',
        model: geminiModel,
        operation: 'ad_visuals_generation',
        source: billingSource as Parameters<typeof registerAiUsage>[0]['source'],
        tokensIn: ESTIMATED_TOKENS_IN_PER_GENERATION,
        tokensOut: ESTIMATED_TOKENS_OUT_PER_GENERATION,
      })

      updateJob(jobId, { status: 'done', result: adVisuals })

      console.info('[generate-creatives] job completed', {
        jobId,
        projectId,
        visualsCount: adVisuals.visuals.length,
      })
    } catch (err) {
      // C3: loguear el error completo server-side, exponer solo mensaje genérico al cliente
      console.error('[generate-creatives] job failed', {
        jobId,
        projectId,
        error: err instanceof Error ? err.message : String(err),
      })
      updateJob(jobId, { status: 'failed', error: 'Error en la generación. Intentá de nuevo.' })
    } finally {
      removeInflightProject(projectId)
    }
  })()

  return NextResponse.json({ jobId, dailyCount: todayCount + 1, dailyLimit: MAX_DAILY_AD_VISUALS })
}
