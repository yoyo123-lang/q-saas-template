import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@qautiva/db'
import { requireAdminSession } from '@/lib/supabase-server'

function isValidUUID(id: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
}

/**
 * DELETE /api/stitch/queue/:id
 *
 * Cancela y elimina un job QUEUED de la cola.
 * Solo se puede cancelar si el job está en estado QUEUED.
 */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } },
): Promise<NextResponse> {
  try {
    await requireAdminSession()
  } catch {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  const { id } = params

  if (!isValidUUID(id)) {
    return NextResponse.json({ error: 'id inválido' }, { status: 400 })
  }

  const job = await prisma.webTemplate.findUnique({
    where: { id },
    select: { id: true, queueStatus: true },
  })

  if (!job) {
    return NextResponse.json({ error: 'Job no encontrado' }, { status: 404 })
  }

  if (job.queueStatus !== 'QUEUED') {
    return NextResponse.json(
      { error: 'Solo se puede cancelar un job en estado QUEUED' },
      { status: 409 },
    )
  }

  await prisma.webTemplate.delete({ where: { id } })

  return NextResponse.json({ success: true })
}
