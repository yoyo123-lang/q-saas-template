import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { QuestionBlock, StrategicBrief } from '../../app/_lib/interview/types'

// ── Mock de @anthropic-ai/sdk ─────────────────────────────────────────────────

const mockCreate = vi.fn()

vi.mock('@anthropic-ai/sdk', () => ({
  default: vi.fn().mockImplementation(() => ({
    messages: { create: mockCreate },
  })),
}))

// ── Fixtures ──────────────────────────────────────────────────────────────────

const mockBrief: StrategicBrief = {
  negocio: {
    descripcion: 'Software de gestión para PYMEs',
    estado: 'operando',
    antiguedad: '2 años',
    recursosDisponibles: 'Equipo de 5, presupuesto mensual ARS 200K',
    restricciones: ['No puede hacer publicidad televisiva'],
  },
  mercado: {
    zonaGeografica: 'Buenos Aires, CABA',
    alcance: 'Local',
    competidores: [{ nombre: 'CompetidorX', fortaleza: 'Gran red', debilidad: 'Precio alto' }],
    espaciosVacios: ['PYMEs del sector gastronómico sin digitalizar'],
    tendencias: ['Digitalización acelerada post-pandemia'],
  },
  audiencia: {
    perfilCliente: 'Dueño de PYME con 5-20 empleados',
    comoCompra: 'Por recomendación de colegas',
    dolorPrincipal: 'Perder tiempo en tareas manuales',
    canalAdquisicion: 'Referidos',
  },
  posicionamiento: {
    estrategia: 'enfoque',
    nichoEspecifico: 'PYMEs gastronómicas de CABA',
    ventajaCompetitiva: 'Único sistema diseñado específicamente para el rubro gastronómico',
    riesgos: ['Nicho pequeño', 'Posible entrada de actores grandes'],
    justificacion: 'Ningún competidor se especializa en gastronomía — hay un hueco claro',
  },
  direccionComunicacional: {
    mensajeCentral: 'El sistema que entiende tu restaurante',
    tonoSugerido: 'Directo, sin tecnicismos, confiable',
    territoriosTematicos: ['Ahorro de tiempo', 'Crecimiento sin caos'],
    queNoDecir: ['No hablar de "tecnología de punta"'],
    rangoPrecios: 'Comunicar como inversión mensual baja, comparable a contratar un empleado part-time',
  },
  decisionesPendientes: [
    {
      tema: 'Modelo de precios',
      opciones: [
        { opcion: 'Suscripción mensual', pro: 'Predecible', contra: 'Barrera de entrada' },
        { opcion: 'Pago único', pro: 'Venta más fácil', contra: 'Sin recurrencia' },
      ],
    },
  ],
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('generateStrategicBrief', () => {
  beforeEach(() => {
    mockCreate.mockReset()
  })

  it('retorna el StrategicBrief cuando Claude llama generate_brief', async () => {
    const { generateStrategicBrief } = await import(
      '../../app/_lib/interview/brief-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [
        {
          type: 'tool_use',
          id: 'brief_1',
          name: 'generate_brief',
          input: mockBrief,
        },
      ],
      stop_reason: 'tool_use',
    })

    const flow: QuestionBlock[] = [
      { id: 'q1', question: '¿Qué hace tu negocio?', inputType: 'textarea' },
    ]
    const answers = { q1: 'Software para PYMEs' }

    const result = await generateStrategicBrief(flow, answers)

    expect(result).toEqual(mockBrief)
    expect(result.posicionamiento.estrategia).toBe('enfoque')
    expect(result.direccionComunicacional.mensajeCentral).toBe(
      'El sistema que entiende tu restaurante',
    )
  })

  it('pasa tool_choice: { type: tool, name: generate_brief } a la API', async () => {
    const { generateStrategicBrief } = await import(
      '../../app/_lib/interview/brief-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_brief', input: mockBrief }],
      stop_reason: 'tool_use',
    })

    await generateStrategicBrief([], {})

    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        tool_choice: { type: 'tool', name: 'generate_brief' },
      }),
    )
  })

  it('lanza si Claude no llama generate_brief', async () => {
    const { generateStrategicBrief } = await import(
      '../../app/_lib/interview/brief-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'text', text: 'Acá te dejo el brief...' }],
      stop_reason: 'end_turn',
    })

    await expect(generateStrategicBrief([], {})).rejects.toThrow('[brief-generator]')
  })

  it('incluye las preguntas y respuestas en el prompt del usuario', async () => {
    const { generateStrategicBrief } = await import(
      '../../app/_lib/interview/brief-generator'
    )

    mockCreate.mockResolvedValueOnce({
      content: [{ type: 'tool_use', id: 'x', name: 'generate_brief', input: mockBrief }],
      stop_reason: 'tool_use',
    })

    const flow: QuestionBlock[] = [
      { id: 'q1', question: '¿Cuál es tu negocio?', inputType: 'textarea' },
    ]
    await generateStrategicBrief(flow, { q1: 'Vendo ropa' })

    const callArgs = mockCreate.mock.calls[0]![0] as Record<string, unknown>
    const messages = callArgs.messages as Array<{ role: string; content: string }>
    const userContent = messages[0]!.content
    expect(userContent).toContain('¿Cuál es tu negocio?')
    expect(userContent).toContain('Vendo ropa')
  })
})
