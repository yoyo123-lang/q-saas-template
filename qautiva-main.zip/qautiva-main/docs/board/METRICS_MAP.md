# Mapeo de Métricas — Qautiva

> Este archivo mapea cada métrica que Qautiva reporta al Board con el rol AI que la consume,
> el framework de análisis donde se usa, y el tipo de decisión que informa.
>
> **Sincronizado** con el repo de qautiva.ar (`docs/board/`) y con `docs/bu/qautiva/` en q-company.

---

## Roles AI del Board

| Rol | Qué analiza | Frecuencia |
|-----|------------|------------|
| **CFO** | Salud financiera: revenue, unit economics, runway | Semanal (lunes) |
| **CTO** | Salud técnica: uptime, incidentes, deuda técnica | Semanal (lunes) |
| **CRO** | Pipeline: leads, conversión, retención, oportunidades | Semanal (lunes) |
| **CSO** | Estrategia: posicionamiento, competencia, riesgos | Semanal (lunes) |
| **VP Product** | Producto: adopción, uso de features, satisfacción | Semanal (lunes) |
| **VP Engineering** | Ingeniería: calidad de código, CI/CD, infra | Semanal (lunes) |

---

## Métricas → Roles

### `monthly_revenue` — Facturación del mes

- **Qué mide**: total facturado por Qautiva en el período (créditos IA + dominios + servicios)
- **Unidad**: CURRENCY (ARS)
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CFO** → Framework: Revenue Health → Sección: MRR por BU
    - *Para qué*: evalúa si Qautiva es rentable y su contribución al revenue total del grupo. Si cae >20% mes a mes, sugiere directiva de revisión de pricing o estrategia comercial.
    - *Threshold de alerta*: caída >20% vs mes anterior → WARNING
  - **CSO** → Framework: Strategy Review → Sección: Revenue diversification
    - *Para qué*: evalúa la dependencia del grupo en cada fuente de ingreso

---

### `credits_revenue` — Revenue por créditos IA

- **Qué mide**: ingreso generado exclusivamente por consumo de créditos de agentes IA
- **Unidad**: CURRENCY (ARS)
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CFO** → Framework: Unit Economics → Sección: Gross margin
    - *Para qué*: calcula el margen entre lo que cobra Qautiva por créditos y lo que paga al provider (OpenAI/Anthropic). Si el margen cae, sugiere ajustar pricing o cambiar provider.

---

### `domains_revenue` — Revenue por dominios

- **Qué mide**: ingreso por venta y renovación de dominios (precio Qautiva - costo OpenSRS)
- **Unidad**: CURRENCY (ARS)
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CFO** → Framework: Revenue Health → Sección: Revenue por BU
    - *Para qué*: evalúa el aporte de la línea de dominios al total. Si es insignificante, sugiere no invertir más en ese canal.

---

### `active_clients` — Clientes activos

- **Qué mide**: clientes con al menos un proyecto activo en el período
- **Unidad**: COUNT
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CRO** → Framework: Customer Retention → Sección: Clientes en riesgo
    - *Para qué*: detecta tendencias de pérdida de clientes. Si baja mes a mes, sugiere directiva de retención (ej: campaña de reactivación, mejora de onboarding).
  - **CFO** → Framework: Unit Economics → Sección: LTV
    - *Para qué*: combinado con `monthly_revenue`, calcula ARPU y estima LTV

---

### `avg_project_value` — Valor promedio por proyecto

- **Qué mide**: `monthly_revenue / projects_completed` en el período
- **Unidad**: CURRENCY (ARS)
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CFO** → Framework: Unit Economics → Sección: Deal size
    - *Para qué*: detecta si el ticket promedio sube o baja. Si baja, puede indicar que se están atrayendo clientes de menor valor o que los planes baratos dominan.
  - **CRO** → Framework: Sales Pipeline → Sección: Deal size promedio
    - *Para qué*: evalúa si la estrategia comercial está atrayendo el segmento correcto

---

### `client_retention_rate` — Tasa de retención

- **Qué mide**: % de clientes que renuevan o mantienen actividad en el siguiente período
- **Unidad**: PERCENTAGE
- **Frecuencia de envío**: quarterly
- **Roles que la consumen**:
  - **CRO** → Framework: Customer Retention → Sección: Churn por segmento
    - *Para qué*: indicador inverso de churn. Si cae por debajo del 70%, sugiere investigar causas y directiva de retención.
    - *Threshold de alerta*: < 70% → WARNING, < 50% → CRITICAL
  - **CSO** → Framework: Strategy Review → Sección: Competitive moat
    - *Para qué*: retención alta indica ventaja competitiva sostenible

---

### `trial_conversion_rate` — Tasa conversión trial → pago

- **Qué mide**: % de trials que se convierten en plan pago
- **Unidad**: PERCENTAGE
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CRO** → Framework: Sales Pipeline → Sección: Conversión por etapa
    - *Para qué*: métrica crítica del funnel. Si es < 5%, el producto no está convenciendo o el trial es insuficiente. Sugiere directivas de mejora de onboarding o extensión de trial.
    - *Threshold de alerta*: < 5% → WARNING, < 2% → CRITICAL
  - **VP Product** → Framework: Product Adoption → Sección: Activation rate
    - *Para qué*: evalúa si el "aha moment" del producto ocurre durante el trial

---

### `arpu` — Revenue promedio por usuario

- **Qué mide**: `monthly_revenue / active_clients`
- **Unidad**: CURRENCY (ARS)
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CFO** → Framework: Unit Economics → Sección: ARPU
    - *Para qué*: base para calcular LTV. Si ARPU sube, el negocio se vuelve más rentable por usuario.
  - **CRO** → Framework: Revenue Opportunities → Sección: Upsell/cross-sell
    - *Para qué*: ARPU bajo indica oportunidad de upsell o cross-sell con otras BUs del grupo

---

### `avg_tokens_per_launch` — Consumo promedio por lanzamiento

- **Qué mide**: tokens de IA consumidos en promedio para un lanzamiento completo (todas las etapas de un proyecto)
- **Unidad**: COUNT
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CFO** → Framework: Cash & Runway → Sección: Burn rate
    - *Para qué*: combinado con el costo por token del provider, calcula el costo real de entregar un proyecto. Si sube, el margen se comprime.
  - **VP Product** → Framework: Product Usage → Sección: Feature adoption
    - *Para qué*: detecta si los usuarios están usando todas las etapas o solo algunas. Informa priorización del roadmap.
  - **CTO** → Framework: Architecture Review → Sección: Escalabilidad
    - *Para qué*: si el consumo crece desproporcionalmente, puede indicar prompts ineficientes o falta de cache

---

### `projects_in_progress` — Proyectos activos

- **Qué mide**: proyectos con al menos una etapa activa y no completada
- **Unidad**: COUNT
- **Frecuencia de envío**: weekly
- **Roles que la consumen**:
  - **VP Product** → Framework: Product Usage → Sección: Engagement
    - *Para qué*: indicador de actividad actual. Junto con `projects_completed`, mide la velocidad de delivery.
  - **CTO** → Framework: Technical Health → Sección: Load
    - *Para qué*: muchos proyectos simultáneos pueden estresar la infra (API calls a providers, colas de procesamiento)

---

### `projects_completed` — Proyectos entregados

- **Qué mide**: proyectos donde todas las etapas activas están finalizadas en el período
- **Unidad**: COUNT
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **VP Product** → Framework: Product Velocity → Sección: Features entregadas
    - *Para qué*: mide throughput del producto. Combinado con `avg_project_duration`, evalúa eficiencia.
  - **CRO** → Framework: Sales Pipeline → Sección: Deals closed
    - *Para qué*: cada proyecto completado es un caso de éxito potencial para venta

---

### `avg_project_duration` — Duración promedio en días

- **Qué mide**: días promedio desde inicio hasta completar todas las etapas activas
- **Unidad**: DURATION (días)
- **Frecuencia de envío**: monthly
- **Roles que la consumen**:
  - **CTO** → Framework: Product Velocity → Sección: Ciclo de deploy
    - *Para qué*: si la duración sube, puede indicar cuellos de botella técnicos (API lenta, errores de agentes, procesamiento de imágenes).
  - **VP Product** → Framework: Product Usage → Sección: Time to value
    - *Para qué*: menor duración = el usuario obtiene valor más rápido = mejor retención

---

## Eventos → Roles

| Evento | Roles que lo consumen | Para qué |
|--------|----------------------|----------|
| `lead_captured` | CRO | Mide el tope del funnel. Volumen de interesados. |
| `signup_completed` | CRO, VP Product | Conversión lead→signup. ¿El landing convence? |
| `intake_completed` | VP Product | ¿Cuántos completan el intake? ¿Es muy largo/confuso? |
| `first_deliverable_generated` | VP Product, CTO | "Aha moment". ¿La IA genera algo útil en el primer intento? |
| `trial_credits_exhausted` | CFO, CRO | ¿Los créditos de trial son suficientes para el aha moment? |
| `plan_selected` | CFO, CRO | ¿Qué planes eligen? ¿BYOK o hosted? |
| `trial_converted` | CFO, CRO | Evento más crítico del funnel. Revenue real. |
| `project_completed` | VP Product, CRO | Satisfacción y caso de éxito. |
| `domain_purchased` | CFO | Revenue incremental por dominios. |

---

## Métricas que faltan

| Métrica faltante | Rol que la necesita | Prioridad | Notas |
|-----------------|--------------------|-----------| ------|
| `nps_score` | VP Product, CRO | Media | No hay encuesta de satisfacción implementada |
| `cac` | CFO | Alta | No hay tracking de costo de adquisición (requiere Google/Meta Ads integration) |
| `byok_vs_hosted_ratio` | CFO | Media | Proporción de usuarios con API key propia vs hosted — afecta margen |
| `agent_error_rate` | CTO | Alta | Tasa de error de los agentes IA — no se trackea como métrica agregada |
| `avg_time_to_first_deliverable` | VP Product | Media | Tiempo desde signup hasta primer entregable — mide time to value |

---

## Historial de cambios

| Fecha | Qué cambió | Por qué |
|-------|-----------|---------|
| 2026-03-22 | Documento inicial | Onboarding de Qautiva al Board — mapeo completo de métricas a roles |
