import type { Metadata } from 'next'
import { prisma } from '@qautiva/db'
import { RevisionQueue } from '@/components/RevisionQueue'
import { RevisionPanel } from '@/components/RevisionPanel'
import type { Plan, DeliverableType, DeliverableStatus } from '@qautiva/db'

export const metadata: Metadata = {
  title: 'Cola de revisión | Qautiva Admin',
}

export const dynamic = 'force-dynamic'

// ── Tipos ─────────────────────────────────────────────────────────────────────

export interface StageForReview {
  id: string
  number: number
  name: string
  updatedAt: Date
  organization: {
    id: string
    name: string
    industry: string
    plan: Plan
  }
  deliverables: {
    id: string
    title: string
    type: DeliverableType
    status: DeliverableStatus
  }[]
}

export interface StageDetail extends StageForReview {
  adminApproved: boolean
  clientApproved: boolean
  startedAt: Date | null
}

// ── Queries ────────────────────────────────────────────────────────────────────

async function getQueue(): Promise<StageForReview[]> {
  const stages = await prisma.stage.findMany({
    where: { status: 'ADMIN_REVIEW', organizationId: { not: null } },
    orderBy: { updatedAt: 'asc' }, // más antiguas primero
    take: 100,
    select: {
      id: true,
      number: true,
      name: true,
      updatedAt: true,
      organization: {
        select: { id: true, name: true, industry: true, plan: true },
      },
      deliverables: {
        select: { id: true, title: true, type: true, status: true },
      },
    },
  })
  return stages.filter((s) => s.organization !== null) as StageForReview[]
}

async function getStageDetail(stageId: string): Promise<StageDetail | null> {
  const stage = await prisma.stage.findUnique({
    where: { id: stageId, status: 'ADMIN_REVIEW' },
    select: {
      id: true,
      number: true,
      name: true,
      updatedAt: true,
      adminApproved: true,
      clientApproved: true,
      startedAt: true,
      organization: {
        select: { id: true, name: true, industry: true, plan: true },
      },
      deliverables: {
        orderBy: { createdAt: 'asc' },
        select: { id: true, title: true, type: true, status: true },
      },
    },
  })
  if (!stage || !stage.organization) return null
  return stage as StageDetail
}

// ── Página ─────────────────────────────────────────────────────────────────────

interface PageProps {
  searchParams: { org?: string; stage?: string }
}

export default async function RevisionPage({ searchParams }: PageProps) {
  const stageId = searchParams.stage
  const queue = await getQueue()

  // Modo detalle: viene con ?org=X&stage=Y desde ProgresoTab o ClientHeader
  if (stageId) {
    const detail = await getStageDetail(stageId)
    return (
      <div className="flex flex-col h-full p-6 gap-5">
        <RevisionPanel
          stage={detail}
          queueCount={queue.length}
          requestedStageId={stageId}
        />
      </div>
    )
  }

  // Modo cola: lista todas las etapas pendientes
  return (
    <div className="flex flex-col h-full p-6 gap-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-xl font-bold">Cola de revisión</h1>
          <p className="text-[#64748B] text-sm mt-0.5">
            {queue.length === 0
              ? 'Sin etapas pendientes.'
              : `${queue.length} etapa${queue.length !== 1 ? 's' : ''} esperando revisión`}
          </p>
        </div>
      </div>
      <RevisionQueue items={queue} />
    </div>
  )
}
