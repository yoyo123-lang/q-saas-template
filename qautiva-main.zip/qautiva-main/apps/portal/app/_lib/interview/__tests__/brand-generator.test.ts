/**
 * Tests del Brand Generator (Etapa BRAND, stage 3).
 *
 * Estrategia: mocks de OpenAI, Gemini y Supabase Storage.
 * Sin llamadas a APIs externas ni a la DB.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'

// ── Fixtures ──────────────────────────────────────────────────────────────────

/** PNG mínimo válido (magic bytes 89 50 4E 47 + resto) */
const VALID_PNG_BUFFER = Buffer.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
])
const VALID_PNG_BASE64 = VALID_PNG_BUFFER.toString('base64')

/** JPEG mínimo válido (magic bytes FF D8 FF) */
const VALID_JPEG_BUFFER = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10])
const VALID_JPEG_BASE64 = VALID_JPEG_BUFFER.toString('base64')

/** Bytes inválidos (no PNG ni JPEG) */
const INVALID_IMAGE_BUFFER = Buffer.from([0x00, 0x01, 0x02, 0x03])
const INVALID_IMAGE_BASE64 = INVALID_IMAGE_BUFFER.toString('base64')

/** 3 conceptos de marca válidos que devolvería OpenAI */
const VALID_CONCEPTS = {
  options: [
    {
      id: 'option-a',
      label: 'Profesional Moderno',
      colors: [
        { hex: '#1A2B3C', name: 'Marino Profundo' },
        { hex: '#4D7AB5', name: 'Azul Corporativo' },
        { hex: '#F5F5F0', name: 'Blanco Cálido' },
        { hex: '#E8D5B7', name: 'Arena' },
      ],
      headingFont: 'Inter',
      bodyFont: 'Source Serif Pro',
      brandPersonality: ['confiable', 'profesional', 'sólido'],
      logoPrompt: 'A minimalist professional logo for a consulting firm...',
    },
    {
      id: 'option-b',
      label: 'Energético Dinámico',
      colors: [
        { hex: '#FF4500', name: 'Rojo Energía' },
        { hex: '#FF8C00', name: 'Naranja Vivo' },
        { hex: '#1C1C1C', name: 'Negro' },
        { hex: '#F8F8F8', name: 'Gris Claro' },
      ],
      headingFont: 'Montserrat',
      bodyFont: 'Open Sans',
      brandPersonality: ['dinámico', 'audaz', 'innovador'],
      logoPrompt: 'A bold dynamic logo with geometric shapes...',
    },
    {
      id: 'option-c',
      label: 'Natural Orgánico',
      colors: [
        { hex: '#4A7C59', name: 'Verde Bosque' },
        { hex: '#8FBC8F', name: 'Verde Suave' },
        { hex: '#D2B48C', name: 'Tan Natural' },
        { hex: '#FFFFF0', name: 'Marfil' },
      ],
      headingFont: 'Playfair Display',
      bodyFont: 'Lato',
      brandPersonality: ['natural', 'auténtico', 'cercano'],
      logoPrompt: 'An organic natural logo with leaf motifs...',
    },
  ],
}

const FLOW_DEFINITION = [
  { id: 'brand_1', question: '¿Preferencia de colores?', inputType: 'textarea' as const },
]
const ANSWERS = { brand_1: 'Me gustan los tonos azules' }
const PROJECT_ID = 'proj-test-123'
const LOGO_URL_A = 'https://supabase.io/storage/v1/object/public/brand-logos/proj-test-123/option-a-123.png'
const LOGO_URL_B = 'https://supabase.io/storage/v1/object/public/brand-logos/proj-test-123/option-b-123.png'
const LOGO_URL_C = 'https://supabase.io/storage/v1/object/public/brand-logos/proj-test-123/option-c-123.png'

// ── Mocks ─────────────────────────────────────────────────────────────────────

const mockOpenAICreate = vi.fn()
const mockGeminiGenerateContent = vi.fn()
const mockStorageFrom = vi.fn()
const mockListBuckets = vi.fn()
const mockCreateBucket = vi.fn()
const mockGetPublicUrl = vi.fn()
const mockUpload = vi.fn()

vi.mock('../openai-client', () => ({
  getOpenAIClient: () => ({
    chat: {
      completions: {
        create: mockOpenAICreate,
      },
    },
  }),
}))

vi.mock('../gemini-client', () => ({
  getGeminiClient: () => ({
    getGenerativeModel: () => ({
      generateContent: mockGeminiGenerateContent,
    }),
  }),
}))

vi.mock('@qautiva/db', () => ({
  createServiceClient: () => ({
    storage: {
      listBuckets: mockListBuckets,
      createBucket: mockCreateBucket,
      from: mockStorageFrom,
    },
  }),
}))

vi.mock('../brief-generator', () => ({
  buildInterviewSummary: () => 'Pregunta 1: ¿Preferencia de colores?\nRespuesta: Me gustan los tonos azules',
}))

// ── Helpers de configuración de mocks ─────────────────────────────────────────

function setupOpenAISuccess() {
  mockOpenAICreate.mockResolvedValue({
    choices: [
      {
        finish_reason: 'stop',
        message: { content: JSON.stringify(VALID_CONCEPTS) },
      },
    ],
    usage: { prompt_tokens: 500, completion_tokens: 800 },
  })
}

function setupGeminiSuccess(base64Data = VALID_PNG_BASE64) {
  mockGeminiGenerateContent.mockResolvedValue({
    response: {
      candidates: [
        {
          content: {
            parts: [{ inlineData: { mimeType: 'image/png', data: base64Data } }],
          },
        },
      ],
    },
  })
}

function setupStorageSuccess() {
  mockListBuckets.mockResolvedValue({ data: [{ name: 'brand-logos' }], error: null })
  mockUpload.mockResolvedValue({ error: null })
  mockGetPublicUrl.mockImplementation((fileName: string) => ({
    data: { publicUrl: `https://supabase.io/storage/v1/object/public/brand-logos/${fileName}` },
  }))
  mockStorageFrom.mockReturnValue({
    upload: mockUpload,
    getPublicUrl: mockGetPublicUrl,
  })
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('generateBrandOptions', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    // Resetear flag de caché del bucket entre tests para que cada test
    // pueda controlar el comportamiento de ensureBrandLogosBucket().
    const { _resetBucketCacheForTesting } = await import('../brand-generator')
    _resetBucketCacheForTesting()
  })

  it('genera 3 opciones completas en el caso happy path', async () => {
    setupOpenAISuccess()
    setupGeminiSuccess()
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    const result = await generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)

    expect(result.options).toHaveLength(3)
    expect(result.disclaimer).toBeTruthy()

    for (const opt of result.options) {
      expect(opt.id).toBeTruthy()
      expect(opt.label).toBeTruthy()
      expect(opt.colors.length).toBeGreaterThanOrEqual(2)
      expect(opt.headingFont).toBeTruthy()
      expect(opt.bodyFont).toBeTruthy()
      expect(opt.brandPersonality.length).toBeGreaterThanOrEqual(1)
      expect(opt.logoUrl).toBeTruthy()
      // logoPrompt es un prompt interno para Gemini y NO debe persistirse en el
      // deliverable: exponerlo al cliente revelaría detalles de implementación.
      expect((opt as { logoPrompt?: string }).logoPrompt).toBeUndefined()
    }
  })

  it('resultado es JSON serializable (puede persistirse en Prisma como JSON)', async () => {
    setupOpenAISuccess()
    setupGeminiSuccess()
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    const result = await generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)

    // Verifica que el resultado se pueda serializar y deserializar sin pérdida.
    // Esto garantiza que el JSON guardado en Deliverable.content es round-trip safe.
    const json = JSON.stringify(result)
    expect(json).toBeTruthy()
    const parsed = JSON.parse(json) as typeof result
    expect(parsed.options).toHaveLength(3)
    expect(parsed.disclaimer).toBe(result.disclaimer)
  })

  it('acepta imágenes JPEG válidas además de PNG', async () => {
    setupOpenAISuccess()
    setupGeminiSuccess(VALID_JPEG_BASE64)
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    const result = await generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)
    expect(result.options).toHaveLength(3)
  })

  it('degradación elegante: 1/3 logos falla → 2 opciones tienen logoUrl, 1 no', async () => {
    setupOpenAISuccess()
    // Primera llamada a Gemini falla, las otras 2 funcionan
    mockGeminiGenerateContent
      .mockRejectedValueOnce(new Error('Gemini timeout'))
      .mockResolvedValue({
        response: {
          candidates: [
            {
              content: {
                parts: [{ inlineData: { mimeType: 'image/png', data: VALID_PNG_BASE64 } }],
              },
            },
          ],
        },
      })
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    const result = await generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)

    expect(result.options).toHaveLength(3)
    const withLogo = result.options.filter((o) => o.logoUrl)
    const withoutLogo = result.options.filter((o) => !o.logoUrl)
    expect(withLogo).toHaveLength(2)
    expect(withoutLogo).toHaveLength(1)
  })

  it('2/3 logos fallan → lanza error (umbral de fallo)', async () => {
    setupOpenAISuccess()
    mockGeminiGenerateContent
      .mockRejectedValueOnce(new Error('Gemini error 1'))
      .mockRejectedValueOnce(new Error('Gemini error 2'))
      .mockResolvedValueOnce({
        response: {
          candidates: [
            {
              content: {
                parts: [{ inlineData: { mimeType: 'image/png', data: VALID_PNG_BASE64 } }],
              },
            },
          ],
        },
      })
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow(
      /2\/3 logos fallaron/,
    )
  })

  it('3/3 logos fallan → lanza error', async () => {
    setupOpenAISuccess()
    mockGeminiGenerateContent.mockRejectedValue(new Error('Gemini down'))
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow()
  })

  it('OpenAI falla → lanza error descriptivo', async () => {
    mockOpenAICreate.mockRejectedValue(new Error('OpenAI rate limit'))

    const { generateBrandOptions } = await import('../brand-generator')
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow(
      /OpenAI rate limit/,
    )
  })

  it('OpenAI devuelve respuesta truncada por max_tokens → lanza error', async () => {
    mockOpenAICreate.mockResolvedValue({
      choices: [{ finish_reason: 'length', message: { content: '{"options":[' } }],
      usage: { prompt_tokens: 500, completion_tokens: 4096 },
    })

    const { generateBrandOptions } = await import('../brand-generator')
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow(
      /truncada por max_tokens/,
    )
  })

  it('rechaza output de OpenAI con hex inválido', async () => {
    const invalidConcepts = {
      options: [
        {
          ...VALID_CONCEPTS.options[0],
          colors: [{ hex: 'rojo', name: 'Rojo' }, { hex: '#111111', name: 'Negro' }], // primer hex inválido
        },
        VALID_CONCEPTS.options[1],
        VALID_CONCEPTS.options[2],
      ],
    }
    mockOpenAICreate.mockResolvedValue({
      choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(invalidConcepts) } }],
      usage: { prompt_tokens: 500, completion_tokens: 800 },
    })

    const { generateBrandOptions } = await import('../brand-generator')
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow(
      /hex debe ser #RRGGBB/,
    )
  })

  it('rechaza output de OpenAI con menos de 3 opciones', async () => {
    mockOpenAICreate.mockResolvedValue({
      choices: [
        { finish_reason: 'stop', message: { content: JSON.stringify({ options: [VALID_CONCEPTS.options[0]] }) } },
      ],
      usage: {},
    })

    const { generateBrandOptions } = await import('../brand-generator')
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow(
      /Se esperaban 3 opciones/,
    )
  })

  it('rechaza imagen con magic bytes incorrectos', async () => {
    setupOpenAISuccess()
    mockGeminiGenerateContent.mockResolvedValue({
      response: {
        candidates: [
          {
            content: {
              parts: [{ inlineData: { mimeType: 'image/png', data: INVALID_IMAGE_BASE64 } }],
            },
          },
        ],
      },
    })
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    // 3/3 imágenes inválidas → umbral superado → error
    await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow()
  })

  it('crea el bucket si no existe (create-if-not-exists)', async () => {
    setupOpenAISuccess()
    setupGeminiSuccess()
    mockListBuckets.mockResolvedValue({ data: [], error: null }) // bucket no existe
    mockCreateBucket.mockResolvedValue({ error: null })
    mockUpload.mockResolvedValue({ error: null })
    mockGetPublicUrl.mockReturnValue({ data: { publicUrl: 'https://example.com/logo.png' } })
    mockStorageFrom.mockReturnValue({ upload: mockUpload, getPublicUrl: mockGetPublicUrl })

    const { generateBrandOptions } = await import('../brand-generator')
    const result = await generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)

    expect(mockCreateBucket).toHaveBeenCalledWith('brand-logos', expect.objectContaining({ public: true }))
    expect(result.options).toHaveLength(3)
  })

  it('el disclaimer está presente en el resultado', async () => {
    setupOpenAISuccess()
    setupGeminiSuccess()
    setupStorageSuccess()

    const { generateBrandOptions } = await import('../brand-generator')
    const result = await generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)

    expect(result.disclaimer).toBeTruthy()
    expect(result.disclaimer.length).toBeGreaterThan(20)
  })
})

// ── Tests de validación de colores ────────────────────────────────────────────

describe('validateBrandConcepts (via generateBrandOptions)', () => {
  beforeEach(() => vi.clearAllMocks())

  const hexCases: Array<[string, boolean]> = [
    ['#1A2B3C', true],
    ['#ffffff', true],
    ['#FFFFFF', true],
    ['#ABC', false],          // formato corto
    ['1A2B3C', false],        // sin #
    ['#GGGGGG', false],       // caracteres inválidos
    ['#1A2B3C4D', false],     // demasiado largo
    ['', false],
  ]

  it.each(hexCases)('hex "%s" → válido: %s', async (hex, isValid) => {
    const concepts = {
      options: [
        { ...VALID_CONCEPTS.options[0], colors: [{ hex, name: 'Test' }, { hex: '#111111', name: 'B' }] },
        VALID_CONCEPTS.options[1],
        VALID_CONCEPTS.options[2],
      ],
    }
    mockOpenAICreate.mockResolvedValue({
      choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(concepts) } }],
      usage: {},
    })

    const { generateBrandOptions } = await import('../brand-generator')

    if (isValid) {
      // Si el hex es válido, la validación pasa (continúa hacia Gemini)
      // Solo verificamos que el error NO sea sobre hex
      setupStorageSuccess()
      mockGeminiGenerateContent.mockRejectedValue(new Error('gemini-mock-stop'))
      const promise = generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)
      await expect(promise).rejects.toThrow(/gemini-mock-stop|logos fallaron/)
    } else {
      await expect(generateBrandOptions(FLOW_DEFINITION, ANSWERS, PROJECT_ID, null, null)).rejects.toThrow(
        /hex debe ser #RRGGBB/,
      )
    }
  })
})
