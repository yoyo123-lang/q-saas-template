import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { createServerClient } from '@/lib/supabase-server'
import { prisma } from '@qautiva/db'
import { getUserTeamIds } from '@/app/_lib/interview/get-user-team-ids'
import { checkTeamPermission } from '@/app/_lib/auth/check-team-permission'

/**
 * POST /api/interview/sessions/[id]/feedback
 *
 * Guarda el feedback post-entrevista del usuario en la sesión.
 * Idempotente: si ya hay feedback, lo sobreescribe.
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  }

  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.id)) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  const teamIds = await getUserTeamIds(user.id)
  if (!teamIds) {
    return NextResponse.json({ error: 'Sin acceso' }, { status: 403 })
  }

  const session = await prisma.interviewSession.findFirst({
    where: { id: params.id, teamId: { in: teamIds }, project: { deletedAt: null } },
    select: { id: true, teamId: true, status: true },
  })

  if (!session) {
    return NextResponse.json({ error: 'Sesión no encontrada' }, { status: 404 })
  }

  // Fail-closed: verificar teamId antes de cualquier guard
  if (!session.teamId) {
    console.error('[feedback] session sin teamId — error de datos, bloqueando ejecución', {
      sessionId: params.id,
    })
    return NextResponse.json({ error: 'Error interno de configuración de la sesión.' }, { status: 500 })
  }

  // Guard de permisos: MEMBER solo tiene lectura
  const perm = await checkTeamPermission(user.id, session.teamId, ['ADMIN', 'OWNER'])
  if (!perm.authorized) {
    return NextResponse.json(
      { error: 'Permisos insuficientes. Solo ADMIN y OWNER pueden realizar esta acción.' },
      { status: 403 },
    )
  }

  if (session.status !== 'COMPLETED') {
    return NextResponse.json({ error: 'Solo se puede dar feedback de sesiones completadas' }, { status: 409 })
  }

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Body inválido' }, { status: 400 })
  }

  // Validación básica de estructura
  const { rating, useful, wouldChange, comments } = (body ?? {}) as Record<string, unknown>
  if (typeof rating !== 'number' || rating < 1 || rating > 5) {
    return NextResponse.json({ error: 'rating debe ser un número entre 1 y 5' }, { status: 400 })
  }

  await prisma.interviewSession.update({
    where: { id: params.id },
    data: {
      feedback: {
        rating,
        useful: Array.isArray(useful) ? useful : [],
        wouldChange: typeof wouldChange === 'string' ? wouldChange : null,
        comments: typeof comments === 'string' ? comments : '',
        submittedAt: new Date().toISOString(),
      },
    },
  })

  return NextResponse.json({ ok: true })
}
